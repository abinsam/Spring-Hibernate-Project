package org.balajicables.salesmanager;

import java.util.ArrayList;
import java.util.Collection;

import org.balajicables.salesmanager.model.Role;
import org.balajicables.salesmanager.model.User;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


@Service("assembler")
public class Assembler {

  @Transactional(readOnly = true)
public
  CustomUser buildUserFromUserEntity(User user) {

	  //The userName is the emailId
  //  String username = user.getEmailId();
    String username = user.getUserName();
    String firstName = user.getFirstName();
    String lastName = user.getLastName();
    String password = user.getPassword();
    boolean enabled = user.isEnabled();
    boolean accountNonExpired = user.isEnabled();
    boolean credentialsNonExpired = user.isEnabled();
    boolean accountNonLocked = user.isEnabled();

    Collection<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
    for (Role role : user.getRoles()) {
      authorities.add(new SimpleGrantedAuthority(role.getAuthority()));
    }

    CustomUser customUser = new CustomUser(username, firstName, lastName, password, enabled,
      accountNonExpired, credentialsNonExpired, accountNonLocked, authorities);
    return customUser;
  }
}