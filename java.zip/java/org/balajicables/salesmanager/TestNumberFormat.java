package org.balajicables.salesmanager;

import java.text.DecimalFormat;

public class TestNumberFormat {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println(String.format("0000", new Integer(2)));
		DecimalFormat decimalFormat = new DecimalFormat("0000");
		System.out.println(decimalFormat.format(new Integer(2)));

	}

}
