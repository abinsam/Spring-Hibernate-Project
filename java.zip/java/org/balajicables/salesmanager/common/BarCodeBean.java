package org.balajicables.salesmanager.common;


/**
 * @author 10604393
 * 
 */
public class BarCodeBean {
	String barCodeType = "datamatrix";
	String fileLocation;
	String fileName;
	String fileType = "image/jpeg";
	int resolution;
	String itemCode;
	String salesOrderId;
	String workOrderId;
	String bundleSize;
	Integer qtyPerCoil;
	String customerName;
	String customerCode;
	Long customerId;
	String itemDescription;
	String itemLabel;
	String noOfCoils;
	Double quantity;
	Double totalQuantity;
	String area;
	String assortedType;
	String cableStd;
	String partNo;
	Long workOrderItemId;
	String poDetails;
	
	  public String getPoDetails() {
		return poDetails;
	}
	public void setPoDetails(String poDetails) {
		this.poDetails = poDetails;
	}
	public Long getWorkOrderItemId() {
		return workOrderItemId;
	}
	public void setWorkOrderItemId(Long workOrderItemId) {
		this.workOrderItemId = workOrderItemId;
	}
	public String getPartNo() {
			return partNo;
		}
		public void setPartNo(String partNo) {
			this.partNo = partNo;
		}
	
	public Long getCustomerId() {
		return customerId;
	}
	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}
	
	public Double getTotalQuantity() {
		return totalQuantity;
	}
	public void setTotalQuantity(Double totalQuantity) {
		this.totalQuantity = totalQuantity;
	}
	   public String getCableStd() {
		return cableStd;
	}
	public void setCableStd(String cableStd) {
		this.cableStd = cableStd;
	}
	public String getArea() {
			return area;
		}
		public void setArea(String area) {
			this.area = area;
		}
		public String getItemLabel() {
			return itemLabel;
		}
		public void setItemLabel(String itemLabel) {
			this.itemLabel = itemLabel;
		}
		
		
	public String getAssortedType() {
			return assortedType;
		}
		public void setAssortedType(String assortedType) {
			this.assortedType = assortedType;
		}
	public String getCustomerCode() {
		return customerCode;
	}
	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}
	
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getItemDescription() {
		return itemDescription;
	}
	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}
	public String getNoOfCoils() {
		return noOfCoils;
	}
	public void setNoOfCoils(String noOfCoils) {
		this.noOfCoils = noOfCoils;
	}
	public Double getQuantity() {
		return quantity;
	}
	public void setQuantity(Double quantity) {
		this.quantity = quantity;
	}
	public String getBarCodeType() {
		return barCodeType;
	}
	public void setBarCodeType(String barCodeType) {
		this.barCodeType = barCodeType;
	}
	public String getFileLocation() {
		return fileLocation;
	}
	public void setFileLocation(String fileLocation) {
		this.fileLocation = fileLocation;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getFileType() {
		return fileType;
	}
	public void setFileType(String fileType) {
		this.fileType = fileType;
	}
	public int getResolution() {
		return resolution;
	}
	public void setResolution(int resolution) {
		this.resolution = resolution;
	}
	public String getItemCode() {
		return itemCode;
	}
	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}
	public String getSalesOrderId() {
		return salesOrderId;
	}
	public void setSalesOrderId(String salesOrderId) {
		this.salesOrderId = salesOrderId;
	}
	public String getWorkOrderId() {
		return workOrderId;
	}
	public void setWorkOrderId(String workOrderId) {
		this.workOrderId = workOrderId;
	}
	public String getBundleSize() {
		return bundleSize;
	}
	public void setBundleSize(String bundleSize) {
		this.bundleSize = bundleSize;
	}
	public Integer getQtyPerCoil() {
		return qtyPerCoil;
	}
	public void setQtyPerCoil(Integer qtyPerCoil) {
		this.qtyPerCoil = qtyPerCoil;
	}
}
