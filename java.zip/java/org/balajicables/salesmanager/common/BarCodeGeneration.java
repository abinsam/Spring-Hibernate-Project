package org.balajicables.salesmanager.common;

import java.awt.image.BufferedImage;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import org.apache.avalon.framework.configuration.Configuration;
import org.apache.avalon.framework.configuration.ConfigurationException;
import org.apache.avalon.framework.configuration.DefaultConfiguration;
import org.krysalis.barcode4j.BarcodeException;
import org.krysalis.barcode4j.BarcodeGenerator;
import org.krysalis.barcode4j.BarcodeUtil;
import org.krysalis.barcode4j.output.bitmap.BitmapCanvasProvider;

	public class BarCodeGeneration {

	  /*	  
	   * This method will generate a bar code at a specified location.
	   * @param barCodeType = "datamatrix"
	   * @param fileLocation = Location where you want to store the generated file. 
	   * @param fileName = Name of the generated file. Eg BarCode128.jpg
	   * @param fileType = image/jpeg
	   * @param resolution = 200. This is discussed with client.	   
	   * @param itemCode
	   * @param salesOrderId
	   * @param workOrderId
	   * @param bundleSize	   
	   * @throws BarcodeException 
	   * @throws ConfigurationException 
	   * @throws IOException*/
	   
	 public void createBarCode(String barCodeType, String fileLocation, String fileName, String fileType, int resolution,
						 String itemCode, String salesOrderId, String workOrderId, String bundleSize) 
						 throws ConfigurationException, BarcodeException, IOException {

	    BarcodeUtil util = BarcodeUtil.getInstance();
	    BarcodeGenerator gen = util.createBarcodeGenerator(buildCfg(barCodeType));
		
		String fileLocationName = fileLocation + fileName;
	    OutputStream fout = new FileOutputStream(fileLocationName);
	    
	    BitmapCanvasProvider canvas = new BitmapCanvasProvider(
	        fout, fileType, resolution, BufferedImage.TYPE_BYTE_BINARY, false, 0);
	   
	   
	    String strBarCode = itemCode + salesOrderId + workOrderId + bundleSize;
	   
	    gen.generateBarcode(canvas, strBarCode);
	    canvas.finish();
	   
	  }

	  private static Configuration buildCfg(String type) {
	    DefaultConfiguration cfg = new DefaultConfiguration("barcode");

	    //Bar code type
	    DefaultConfiguration child = new DefaultConfiguration(type);
	      cfg.addChild(child);
	    
	      //Human readable text position
	      DefaultConfiguration attr = new DefaultConfiguration("human-readable");
	      DefaultConfiguration subAttr = new DefaultConfiguration("placement");
	        subAttr.setValue("bottom");
	        attr.addChild(subAttr);
	        attr.setValue("none");
	        child.addChild(attr);
	    return cfg;
	  }
	 
	/* private static Configuration buildCfg(String type) {
		    DefaultConfiguration cfg = new DefaultConfiguration("barcode");

		    //Bar code type
		    DefaultConfiguration child = new DefaultConfiguration(type);

		      cfg.addChild(child);
		    
		      //Human readable text position
		      DefaultConfiguration attr = new DefaultConfiguration("human-readable");
//		      DefaultConfiguration subAttr = new DefaultConfiguration("placement");
//		        subAttr.setValue("bottom");
		       // attr.addChild(subAttr);
		        attr.setValue("none");
		        child.addChild(attr);
		        

		    return cfg;
		  }*/
	 
}


