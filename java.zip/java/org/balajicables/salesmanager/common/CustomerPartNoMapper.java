package org.balajicables.salesmanager.common;

import java.util.ArrayList;
import java.util.List;
import org.balajicables.salesmanager.model.CustomerPartNo;
import org.balajicables.salesmanager.dto.CustomerPartNoDTO;

public class CustomerPartNoMapper {

	public static CustomerPartNoDTO map(CustomerPartNo customerPartNo) {
		CustomerPartNoDTO dto = new CustomerPartNoDTO();
		

		dto.setCustomerName(customerPartNo.getCustomer().getCustomerName());
		dto.setCustomerId(customerPartNo.getCustomer().getCustomerId());
		dto.setItemCode(customerPartNo.getItems().getItemCode());
		dto.setItemDescription(customerPartNo.getItems().getItemDescription());
		dto.setItemId(customerPartNo.getItems().getItemId());
		dto.setPartNo(customerPartNo.getPartNo());
		dto.setPartNoId(customerPartNo.getPartNoId());
		return dto;
	}
	
	public static List<CustomerPartNoDTO> map(List<CustomerPartNo> customerPartNo) {
		List<CustomerPartNoDTO> dtos = new ArrayList<CustomerPartNoDTO>();
		
		for (CustomerPartNo partNo: customerPartNo) {
			dtos.add(map(partNo));
		}
		return dtos;
	}

}