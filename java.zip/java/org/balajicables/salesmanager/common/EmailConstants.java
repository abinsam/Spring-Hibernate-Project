package org.balajicables.salesmanager.common;

public class EmailConstants {

	public static String SMTP_AUTH_USER;
	public static String SMTP_AUTH_PWD;
	public static String getSMTP_AUTH_USER() {
		return SMTP_AUTH_USER;
	}
	public static void setSMTP_AUTH_USER(String sMTP_AUTH_USER) {
		SMTP_AUTH_USER = sMTP_AUTH_USER;
	}
	public static String getSMTP_AUTH_PWD() {
		return SMTP_AUTH_PWD;
	}
	public static void setSMTP_AUTH_PWD(String sMTP_AUTH_PWD) {
		SMTP_AUTH_PWD = sMTP_AUTH_PWD;
	}

}
