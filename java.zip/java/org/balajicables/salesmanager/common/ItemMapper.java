package org.balajicables.salesmanager.common;

import java.util.ArrayList;
import java.util.List;
import org.balajicables.salesmanager.model.Item;
import org.balajicables.salesmanager.dto.ItemDTO;

public class ItemMapper {

	public static ItemDTO map(Item item) {
		ItemDTO dto = new ItemDTO();
		
		dto.setArea(item.getArea().getArea());
		dto.setAreaValue(item.getArea().getAreaValue());
		dto.setAssortedType(item.getAssortedType());
		dto.setCableStdKey(item.getCableStdPvc().getCableStdKey());
		dto.setCopperKey(item.getCopperStrandDiameter().getCopperkey());
		dto.setMainColourItem(item.getMainColour().getColor());
		dto.setInnerColourItem(item.getInnerColour().getColor());
		dto.setInnerColorKey(item.getInnerColour().getColorKey());
		dto.setInputSize(item.getInputSize());
		dto.setItemCode(item.getItemCode());
		dto.setItemDescription(item.getItemDescription());
		dto.setItemId(item.getItemId());
		dto.setItemLabel(item.getItemLabel());
		dto.setItemType(item.getItemType());
		dto.setLayLength(item.getLayLength());
		dto.setLayType(item.getLayType());
		dto.setMainColorKey(item.getMainColour().getColorKey());
		dto.setNumberOfCopperStrand(item.getNumberOfCopperStrands());
		dto.setOdLabel(item.getOdLabel());
		dto.setOuterDiameter(item.getOuterDiameter());
		dto.setProductTypeKey(item.getProductType().getProductKey());
		dto.setPvcWeight(item.getPvcWeight());
	    dto.setSpecificDetails(item.getSpecificDetails());
	    dto.setUnitId(item.getUnit().getUnitId());
	    dto.setWeight(item.getCopperWeight());
	    
		return dto;
	}

	public static List<ItemDTO> map(List<Item> item) {
		List<ItemDTO> dtos = new ArrayList<ItemDTO>();
		for (Item items: item) {
			dtos.add(map(items));
		}
		return dtos;
	}
}