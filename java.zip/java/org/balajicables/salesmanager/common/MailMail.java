package org.balajicables.salesmanager.common;

import java.util.HashMap;
import java.util.Map;

import javax.mail.internet.MimeMessage;
import org.apache.velocity.app.VelocityEngine;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.FileSystemResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.ui.velocity.VelocityEngineUtils;

 
public class MailMail 
{


	private JavaMailSender mailSender;

	
	@Autowired
	public void setMailSender(JavaMailSender mailSender) {
	    this.mailSender = mailSender;
	}

	
public void sendEmailsWithAttachment(final String[] toEmailAddresses,  final String subject, final String[] fileName,String velocityTemplate,Map<String, String> model) {
sendEmailsAttachments(toEmailAddresses,  subject, fileName,velocityTemplate,model);

}
public void sendEmailsWithOutAttachment(String[] toEmailIds,
		 String subject, String velocityTemplate,
		HashMap<String, String> model) {
	sendEmailNoAttachments(toEmailIds, subject,velocityTemplate,model);
	
}
private void sendEmailsAttachments(final String[] toEmailAddresses, 
             final String subject, final String[] attachmentFileName,final String velocityTemplate,
             final Map<String, String> model) {

MimeMessagePreparator preparator = new MimeMessagePreparator() {
@Override
public void prepare(MimeMessage mimeMessage) throws Exception {

	
	
MimeMessageHelper message = new MimeMessageHelper(mimeMessage, true);
  message.setTo(toEmailAddresses);
  message.setSubject(subject);
  ApplicationContext context =new ClassPathXmlApplicationContext("Spring-Mail.xml");
  VelocityEngine velocityEngine = (VelocityEngine) context.getBean("velocityEngine");
   String text = VelocityEngineUtils.mergeTemplateIntoString(velocityEngine, "org/balajicables/salesmanager/templates/"+velocityTemplate,"UTF-8", model);
   message.setText(text, true);
  if(attachmentFileName!=null && attachmentFileName.length>0){
	 for( int i = 0; i < attachmentFileName.length; i++ ) {
	      FileSystemResource file= new FileSystemResource(attachmentFileName[i]);
	      message.addAttachment(file.getFilename(), file);
		 }
 }
 }
};
this.mailSender.send(preparator);
}



private void sendEmailNoAttachments(final String[] toEmailIds,
		final String subject, final String velocityTemplate,
		final HashMap<String, String> model) {

MimeMessagePreparator preparator = new MimeMessagePreparator() {
@Override
public void prepare(MimeMessage mimeMessage) throws Exception {
MimeMessageHelper message = new MimeMessageHelper(mimeMessage, true);
  message.setTo(toEmailIds);
  message.setSubject(subject);
  ApplicationContext context =new ClassPathXmlApplicationContext("Spring-Mail.xml");
  VelocityEngine velocityEngine = (VelocityEngine) context.getBean("velocityEngine");
   String text = VelocityEngineUtils.mergeTemplateIntoString(velocityEngine, "org/balajicables/salesmanager/templates/"+velocityTemplate,"UTF-8", model);
   message.setText(text, true);
}
};
this.mailSender.send(preparator);
}
}
