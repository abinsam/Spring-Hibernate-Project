package org.balajicables.salesmanager.common;

import java.io.FileOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.List;
import org.apache.avalon.framework.configuration.ConfigurationException;
import org.balajicables.salesmanager.common.BarCodeGeneration;
import org.krysalis.barcode4j.BarcodeException;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.Font;

/**
 * @author 10604393
 * 
 */
/**
 * It is a utility for generating multiple image file in single PDF file.
 * 
 * @author 10604393
 * 
 */
public class PDFGeneration {
	public final static String filePath = "D:\\Barcodes\\";

	public static void main(String[] args) {

	}

	/**
	 * Generate PDF based on List<BarCodeBean> barcodes provide.
	 * 
	 * @param barcodes
	 */
	public static void generatePDF(List<BarCodeBean> barcodes) {

		Document document = new Document();

		try {
			PdfWriter.getInstance(document, new FileOutputStream(filePath
					+ barcodes.get(0).getWorkOrderId() + ".pdf"));
			document.open();

			PdfPTable table = createTable(barcodes);

			document.add(table);
			document.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void generatePDFForLineItem(List<BarCodeBean> barcodes) {

		Document document = new Document();

		try {
			/*PdfWriter.getInstance(document, new FileOutputStream(filePath
					+ barcodes.get(0).getWorkOrderId() +"-"+ barcodes.get(0).getItemCode()+".pdf"));*/
			PdfWriter.getInstance(document, new FileOutputStream(filePath
					+ barcodes.get(0).getWorkOrderId() +"-"+ barcodes.get(0).getCustomerName()+".pdf"));
			document.open();

			PdfPTable table = createTable(barcodes);

			document.add(table);
			document.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static PdfPTable createTable(List<BarCodeBean> barcodes)
			throws DocumentException, MalformedURLException, IOException {

		PdfPTable table = new PdfPTable(2);
		table.setWidthPercentage(110);
		for (BarCodeBean barCodeBean : barcodes) {
			Image image = Image.getInstance(filePath
					+ barCodeBean.getFileName());
			image.setAlignment(Image.ALIGN_LEFT);
			image.setIndentationLeft(50f);
			image.scalePercent(50f);

			Paragraph p1 = new Paragraph("Balaji Wires");
			p1.setIndentationLeft(100f);
			Paragraph p = new Paragraph("Description :"
					+ barCodeBean.getItemDescription() + "\n" + "SO No: "
					+ barCodeBean.getSalesOrderId()+"    " + "PO NO: "
					+ barCodeBean.getPoDetails() + "    " + "Vendor Id : "
					+ barCodeBean.getCustomerId()+ "    " + "Batch No : "
					+ barCodeBean.getWorkOrderId() + "/"
					+ barCodeBean.getBundleSize() + "\n" + "Quantity : "
					+ barCodeBean.getQuantity() + "   " + "Customer Part No : "
					+ barCodeBean.getPartNo() + "\n" + "STD : "
					+ barCodeBean.getCableStd() + "    " + "Area(Sq mm): "
					+ barCodeBean.getArea());

			p.setFont(FontFactory.getFont(FontFactory.TIMES_ROMAN, 8,
					Font.BOLD, new BaseColor(0, 0, 0)));
			p1.setFont(FontFactory.getFont(FontFactory.TIMES_ROMAN, 8,
					Font.NORMAL, new BaseColor(0, 0, 0)));
			PdfPCell cell = new PdfPCell();

			cell.addElement(p1);
			cell.addElement(p);
			cell.addElement(image);

			table.addCell(cell);
		}
		if (barcodes.size() % 2 != 0) {
			Image image = Image.getInstance(filePath
					+ barcodes.get(0).getFileName());
			image.setAlignment(Image.ALIGN_LEFT);
			image.setIndentationLeft(50f);
			image.scalePercent(50f);

			Paragraph p1 = new Paragraph("Balaji Wires");
			p1.setIndentationLeft(100f);
			Paragraph p = new Paragraph("Description :"
					+ barcodes.get(0).getItemDescription() + "\n" + "SO No: "
					+ barcodes.get(0).getSalesOrderId() + "    "+ "PO NO: "
							+ barcodes.get(0).getPoDetails() + "    " 
					+ "Vendor Id : " + barcodes.get(0).getCustomerId()+"    "
					+ "Batch No : " + barcodes.get(0).getWorkOrderId() + "/" + barcodes.get(0).getBundleSize() + "\n" 
					+ "Quantity : " + barcodes.get(0).getQuantity() + "   "
					+ "Customer Part No : " + barcodes.get(0).getPartNo() + "\n" 
					+ "STD : " + barcodes.get(0).getCableStd() + "    "
					+ "Area(Sq mm): " + barcodes.get(0).getArea() + "\n");

			p.setFont(FontFactory.getFont(FontFactory.TIMES_ROMAN, 8,
					Font.BOLD, new BaseColor(0, 0, 0)));
			p1.setFont(FontFactory.getFont(FontFactory.TIMES_ROMAN, 8,
					Font.NORMAL, new BaseColor(0, 0, 0)));
			PdfPCell cell = new PdfPCell();

			cell.addElement(p1);
			cell.addElement(p);
			cell.addElement(image);

			table.addCell(cell);
		}
		return table;
	}

	public static void generateBarCode(List<BarCodeBean> barcodes) {
	BarCodeGeneration bcg = new BarCodeGeneration();
	try {
		for (BarCodeBean barCodeBean : barcodes) {
			bcg.createBarCode("datamatrix", filePath,
					barCodeBean.getFileName(), "image/jpeg", 200,
					barCodeBean.getItemCode(),
					barCodeBean.getSalesOrderId(),
					barCodeBean.getWorkOrderId(),
					barCodeBean.getBundleSize());
		}
	} catch (ConfigurationException e) {

		e.printStackTrace();
	} catch (BarcodeException e) {

		e.printStackTrace();
	} catch (IOException e) {

		e.printStackTrace();
	}
}

	
/*	public static void generateBarCode(List<BarCodeBean> barcodes) {
		BarCodeGeneration bcg = new BarCodeGeneration();
		try {
			for (BarCodeBean barCodeBean : barcodes) {
				bcg.createBarCode("code128", filePath,
						barCodeBean.getFileName(), "image/jpeg", 200,
						barCodeBean.getItemCode(),
						barCodeBean.getSalesOrderId(),
						barCodeBean.getWorkOrderId(),
						barCodeBean.getBundleSize());
			}
		} catch (ConfigurationException e) {

			e.printStackTrace();
		} catch (BarcodeException e) {

			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		}
	}*/
	
}
