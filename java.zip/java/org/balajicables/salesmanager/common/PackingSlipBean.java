package org.balajicables.salesmanager.common;

public class PackingSlipBean {
	
	String fileLocation;
	String fileName;
	String deliveryChallanNo;
	String inputSize;
    Integer noOfRolls;
    String itemCode;
    String itemDescription;
    String packingSlipNo;
    Double weight;
    Double quanityPerRoll;
    Double totalQuantity;
    String customerName;
	String customerCode;
	String challanDate;
	
	public String getChallanDate() {
		return challanDate;
	}
	public void setChallanDate(String challanDate) {
		this.challanDate = challanDate;
	}
	public String getFileLocation() {
		return fileLocation;
	}
	public void setFileLocation(String fileLocation) {
		this.fileLocation = fileLocation;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getDeliveryChallanNo() {
		return deliveryChallanNo;
	}
	public void setDeliveryChallanNo(String deliveryChallanNo) {
		this.deliveryChallanNo = deliveryChallanNo;
	}
	public String getInputSize() {
		return inputSize;
	}
	public void setInputSize(String inputSize) {
		this.inputSize = inputSize;
	}
	public Integer getNoOfRolls() {
		return noOfRolls;
	}
	public void setNoOfRolls(Integer noOfRolls) {
		this.noOfRolls = noOfRolls;
	}
	public String getItemCode() {
		return itemCode;
	}
	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}
	public String getItemDescription() {
		return itemDescription;
	}
	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}
	
	public String getPackingSlipNo() {
		return packingSlipNo;
	}
	public void setPackingSlipNo(String packingSlipNo) {
		this.packingSlipNo = packingSlipNo;
	}
	public Double getWeight() {
		return weight;
	}
	public void setWeight(Double weight) {
		this.weight = weight;
	}
	
	public Double getQuanityPerRoll() {
		return quanityPerRoll;
	}
	public void setQuanityPerRoll(Double quanityPerRoll) {
		this.quanityPerRoll = quanityPerRoll;
	}
	public Double getTotalQuantity() {
		return totalQuantity;
	}
	public void setTotalQuantity(Double totalQuantity) {
		this.totalQuantity = totalQuantity;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerCode() {
		return customerCode;
	}
	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}
    
    
    
}
