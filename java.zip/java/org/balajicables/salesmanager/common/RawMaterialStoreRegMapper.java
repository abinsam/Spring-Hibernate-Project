package org.balajicables.salesmanager.common;

import java.util.ArrayList;
import java.util.List;

import org.balajicables.salesmanager.dto.RawMaterialStoreRegDTO;
import org.balajicables.salesmanager.model.RawMaterialStoreReg;





public class RawMaterialStoreRegMapper {

	public static RawMaterialStoreRegDTO map(RawMaterialStoreReg rawMaterialStoreReg) {
		RawMaterialStoreRegDTO dto = new RawMaterialStoreRegDTO();
		dto.setRwStoreRegId(rawMaterialStoreReg.getRwStoreRegId());
		dto.setStoreId(rawMaterialStoreReg.getStore().getStoreId());
		dto.setPurchaseOrderItemId(rawMaterialStoreReg.getPurchaseOrderItem().getPurchaseOrderItemId());
		//dto.setSupervisorCode(rawMaterialStoreReg.getSupervisor().getSupervisorCode());
		dto.setDateTime(rawMaterialStoreReg.getDateTime().toString());
		dto.setQcStatus(rawMaterialStoreReg.getQcStatus());
		dto.setQcSupervisor(rawMaterialStoreReg.getQcSupervisor());
		dto.setGrossWeight(rawMaterialStoreReg.getGrossWeight());
		dto.setNetWeight(rawMaterialStoreReg.getNetWeight());
		dto.setTareWeight(rawMaterialStoreReg.getTareWeight());
		dto.setCustomerCode(rawMaterialStoreReg.getPurchaseOrderItem().getPurchaseOrder().getCustomer().getCustomerCode());
		dto.setCustomerName(rawMaterialStoreReg.getPurchaseOrderItem().getPurchaseOrder().getCustomer().getCustomerName());
		dto.setItemCode(rawMaterialStoreReg.getPurchaseOrderItem().getItem().getItemCode());
		dto.setItemDescription(rawMaterialStoreReg.getPurchaseOrderItem().getItem().getItemDescription());
		 return dto;
	}
	
	public static List<RawMaterialStoreRegDTO> map(List<RawMaterialStoreReg> rawMaterilaStoreRegs) {
		List<RawMaterialStoreRegDTO> dtos = new ArrayList<RawMaterialStoreRegDTO>();
		for (RawMaterialStoreReg rawMaterilaStoreReg: rawMaterilaStoreRegs) {
			dtos.add(map(rawMaterilaStoreReg));
		}
		return dtos;
	}

}