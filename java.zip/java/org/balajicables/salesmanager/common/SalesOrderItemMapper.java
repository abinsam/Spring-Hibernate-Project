package org.balajicables.salesmanager.common;

import java.util.ArrayList;
import java.util.List;

import org.balajicables.salesmanager.dto.SalesOrderItemsDTO;
import org.balajicables.salesmanager.model.SalesOrderItem;
import org.balajicables.salesmanager.utils.Utility;

public class SalesOrderItemMapper {

	public static SalesOrderItemsDTO map(SalesOrderItem soItem) {
		SalesOrderItemsDTO dto = new SalesOrderItemsDTO();
		dto.setOrderDetailId(soItem.getOrderDetailId());

		dto.setOrderId(soItem.getOrder().getOrderId());
		dto.setCustomerCode(soItem.getOrder().getCustomer().getCustomerCode());
		dto.setCustomerName(soItem.getOrder().getCustomer().getCustomerName());
		dto.setCustomerId(soItem.getOrder().getCustomer().getCustomerId());
		dto.setStatus(soItem.getOrder().getOrderStatus().getStatus());

		dto.setItemId(soItem.getItem().getItemId());
		dto.setItemCode(soItem.getItem().getItemCode());
		dto.setItemDescription(soItem.getItem().getItemDescription());
		dto.setNumberOfCopperStrands(soItem.getItem()
				.getNumberOfCopperStrands());

		String cuKey = String.valueOf((Double.valueOf(soItem.getItem()
				.getCopperStrandDiameter().getCopperkey())) / 1000);
		dto.setCopperkey(cuKey);

		String od = String.valueOf(Double.valueOf(soItem.getItem()
				.getOuterDiameter()) / 100);
		dto.setOuterDiameter(od);

		dto.setOdLabel(soItem.getItem().getOdLabel());
		dto.setMainColour(soItem.getItem().getMainColour().getColor());
		dto.setInnerColour(soItem.getItem().getInnerColour().getColor());
		dto.setCableStdKey(soItem.getItem().getCableStdPvc().getCableStdKey());
		dto.setProductKey(soItem.getItem().getProductType().getProductKey());
		dto.setLayLength(soItem.getItem().getLayLength());
		dto.setLayType(soItem.getItem().getLayType());
		dto.setQuantity(soItem.getQuantity());
		dto.setBalanceQty(soItem.getBalanceQty());
		dto.setBundleSize(soItem.getBundleSize());
		dto.setProductionQty(soItem.getProductionQty());
		dto.setCompletedQty(soItem.getCompletedQty());
		dto.setDispatchedQty(soItem.getDispatchedQty());
		if (soItem.getOrder().getOrderAcceptanceDate() != null)
			dto.setOrderAcceptanceDate(Utility.formDateFormatter.print(soItem
					.getOrder().getOrderAcceptanceDate().getTime()));
		dto.setWoQty((double) 0);
		dto.setUnit(soItem.getItem().getUnit().getUnits());
		dto.setWeight(soItem.getWeight());
		dto.setPvcWeight(soItem.getWeight());
		return dto;
	}

	public static List<SalesOrderItemsDTO> map(List<SalesOrderItem> soItems) {
		List<SalesOrderItemsDTO> dtos = new ArrayList<SalesOrderItemsDTO>();
		for (SalesOrderItem soItem : soItems) {
			dtos.add(map(soItem));
		}
		return dtos;
	}
}