package org.balajicables.salesmanager.common;

import java.util.List;

import org.balajicables.salesmanager.dto.OrderDTO;
import org.balajicables.salesmanager.model.SalesOrder;
import org.balajicables.salesmanager.utils.Utility;

public class SalesOrderUpdate {

	public SalesOrder updateSoOrder(String orderId, List<SalesOrder> soOrderDetailsList, Double inputQty) {
		    	OrderDTO salesOrderDTO=new OrderDTO();
				salesOrderDTO.setOrderId(orderId);
				if(soOrderDetailsList.get(0).getOrderRecDate()!=null)
				salesOrderDTO.setOrderRecDate(Utility.formDateFormatter.print(soOrderDetailsList.get(0).getOrderRecDate().getTime()));
				if(soOrderDetailsList.get(0).getOrderAcceptanceDate()!=null)
				salesOrderDTO.setOrderAcceptanceDate(Utility.formDateFormatter.print(soOrderDetailsList.get(0).getOrderAcceptanceDate().getTime()));
				if(soOrderDetailsList.get(0).getOrderDeliveryDate()!=null)
				salesOrderDTO.setOrderDeliveryDate(Utility.formDateFormatter.print(soOrderDetailsList.get(0).getOrderDeliveryDate().getTime()));
				salesOrderDTO.setCustomerId(soOrderDetailsList.get(0).getCustomer().getCustomerId());
				salesOrderDTO.setPoDetails(soOrderDetailsList.get(0).getPoDetails());
				salesOrderDTO.setModeOfReceipt(soOrderDetailsList.get(0).getModeOfReceipt());
				salesOrderDTO.setOrderStatusId(soOrderDetailsList.get(0).getOrderStatus().getOrderStatusId());
				salesOrderDTO.setCreatedTime(soOrderDetailsList.get(0).getCreatedTime().toString());
				if(soOrderDetailsList.get(0).getTargetDate()!=null)
				salesOrderDTO.setTargetDate(Utility.formDateFormatter.print(soOrderDetailsList.get(0).getTargetDate().getTime()));
				salesOrderDTO.setCreatedBy(soOrderDetailsList.get(0).getCreatedBy());
				salesOrderDTO.setUpdatedBy(soOrderDetailsList.get(0).getUpdatedBy());
				salesOrderDTO.setUpdatedTime(soOrderDetailsList.get(0).getUpdatedTime().toString());
				salesOrderDTO.setMailStatus(soOrderDetailsList.get(0).getMailStatus());
				salesOrderDTO.setLmeDetails(soOrderDetailsList.get(0).getLmeDetails());
				salesOrderDTO.setInputQuantity(inputQty);
			    SalesOrder order =salesOrderDTO.getOrder();
		return order;
	}
       


}