package org.balajicables.salesmanager.common;
import org.balajicables.salesmanager.model.ProductionWorkOrder;
import org.balajicables.salesmanager.dto.ProductionWorkOrderDTO;

public class SaveProductionWorkOrder {
       
	
	public   ProductionWorkOrder saveProductionWorkOrder(String newWorkOrderNo,
		Long rbdWoMachineNo, String rbdWoSupervisor, String rbdStartDate,
		String rbdCompletionDate, Integer processId) {
		ProductionWorkOrderDTO productionWorkOrderDTO = new ProductionWorkOrderDTO();
		productionWorkOrderDTO.setWorkOrderNo(newWorkOrderNo);
		productionWorkOrderDTO.setMachineNo(rbdWoMachineNo);
		productionWorkOrderDTO.setStartDate(rbdStartDate);
		productionWorkOrderDTO.setEndDate(rbdCompletionDate);
	    productionWorkOrderDTO.setProcessId(processId);
	    productionWorkOrderDTO.setCreatedBy(rbdWoSupervisor);
	    productionWorkOrderDTO.setStatus("Created");
	    productionWorkOrderDTO.setInputWeight(Double.valueOf(0));
	    productionWorkOrderDTO.setBalanceWeight(Double.valueOf(0));
	    productionWorkOrderDTO.setOutputWeight(Double.valueOf(0));
		ProductionWorkOrder prdnWorkOrder = productionWorkOrderDTO.getPdnWorkOrder();
		return prdnWorkOrder;
	}
	


}