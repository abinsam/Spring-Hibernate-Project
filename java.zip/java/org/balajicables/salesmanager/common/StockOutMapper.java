package org.balajicables.salesmanager.common;
import java.util.ArrayList;
import java.util.List;

import org.balajicables.salesmanager.model.StockOut;
import org.balajicables.salesmanager.dto.StockOutDTO;

public class StockOutMapper {

	public static StockOutDTO map(StockOut stockOut) {
		StockOutDTO dto = new StockOutDTO();
		dto.setStockOutId(stockOut.getStockOutId());
		dto.setStoreId(stockOut.getStore().getStoreId());
		dto.setOrderDetailId(stockOut.getSalesOrderItem().getOrderDetailId());
		dto.setOrderId(stockOut.getSalesOrderItem().getOrder().getOrderId());
		dto.setItemId(stockOut.getSalesOrderItem().getItem().getItemId());
		dto.setItemCode(stockOut.getSalesOrderItem().getItem().getItemCode());
		dto.setItemDescription(stockOut.getSalesOrderItem().getItem().getItemDescription());
		dto.setSoItemQty(stockOut.getSalesOrderItem().getQuantity());
		dto.setWorkOrderNo(stockOut.getProductionWorkOrder().getWorkOrderNo());
		//stockOutDTO.setStockOutDateTime(stockOut.getStockOutDateTime().toString());
		dto.setStockOutQty(stockOut.getStockOutQty());
		dto.setQcStatus(stockOut.getQcStatus());
		dto.setQcSupervisor(stockOut.getQcSupervisor());
		dto.setCustomerName(stockOut.getSalesOrderItem().getOrder().getCustomer().getCustomerName());
		dto.setBundleId(stockOut.getBundleId());
		dto.setWeight(stockOut.getWeight());
		dto.setConfirmStatus(stockOut.getConfirmStatus());
		dto.setUnits(stockOut.getSalesOrderItem().getItem().getUnit().getUnits());
		dto.setPackingSlipNo(stockOut.getPackingSlipNo());
		dto.setBagWeight(stockOut.getBagWeight());
		dto.setRemarks(stockOut.getRemarks());
		dto.setStatus(stockOut.getSalesOrderItem().getOrder().getOrderStatus().getStatus());
	   return dto;
	}
	
	public static List<StockOutDTO> map(List<StockOut> stockOut) {
		List<StockOutDTO> dtos = new ArrayList<StockOutDTO>();
		for (StockOut stockOutItem: stockOut) {
			dtos.add(map(stockOutItem));
		}
		return dtos;
	}

}