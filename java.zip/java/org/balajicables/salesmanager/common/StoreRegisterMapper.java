package org.balajicables.salesmanager.common;

import java.util.ArrayList;
import java.util.List;
import org.balajicables.salesmanager.model.StoreRegister;
import org.balajicables.salesmanager.dto.StoreRegisterDTO;

public class StoreRegisterMapper {

	public static StoreRegisterDTO map(StoreRegister storeRegister) {
		StoreRegisterDTO dto = new StoreRegisterDTO();
		
		dto.setStoreRegisterId(storeRegister.getStoreRegisterId());
		dto.setStoreId(storeRegister.getStore().getStoreId());
		dto.setStoreAddress(storeRegister.getStore().getStoreAddress());
		dto.setItemId(storeRegister.getSalesOrderItem().getItem().getItemId());
		dto.setItemCode(storeRegister.getSalesOrderItem().getItem().getItemCode());
		dto.setOrderId(storeRegister.getSalesOrderItem().getOrder().getOrderId());
		dto.setWorkOrderNo(storeRegister.getProductionWorkOrder().getWorkOrderNo());
		dto.setStockQty(storeRegister.getStockQty());
		dto.setOrderDetailId(storeRegister.getSalesOrderItem().getOrderDetailId());
		dto.setCustomerName(storeRegister.getSalesOrderItem().getOrder().getCustomer().getCustomerName());
		dto.setCustomerCode(storeRegister.getSalesOrderItem().getOrder().getCustomer().getCustomerCode());
		dto.setCustomerId(storeRegister.getSalesOrderItem().getOrder().getCustomer().getCustomerId());
	    dto.setItemDescription(storeRegister.getSalesOrderItem().getItem().getItemDescription());
	    dto.setUnits(storeRegister.getSalesOrderItem().getItem().getUnit().getUnits());
	    dto.setBundleId(storeRegister.getBundleId());
	    dto.setWeight(storeRegister.getWeight());
	    dto.setPackingSlipNo(storeRegister.getPackingSlipNo());
	    dto.setBagWeight(storeRegister.getBagWeight());
	    dto.setStatus(storeRegister.getSalesOrderItem().getOrder().getOrderStatus().getStatus());
	    dto.setQcStatus(storeRegister.getQcStatus());
	    dto.setQcSupervisor(storeRegister.getQcSupervisor());
		return dto;
	}
	
	public static List<StoreRegisterDTO> map(List<StoreRegister> storeRegister) {
		List<StoreRegisterDTO> dtos = new ArrayList<StoreRegisterDTO>();
		for (StoreRegister storeRegItem: storeRegister) {
			dtos.add(map(storeRegItem));
		}
		return dtos;
	}

}