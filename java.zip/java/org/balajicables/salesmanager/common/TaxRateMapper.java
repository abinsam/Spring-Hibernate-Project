package org.balajicables.salesmanager.common;

import java.util.ArrayList;
import java.util.List;
import org.balajicables.salesmanager.model.TaxRate;
import org.balajicables.salesmanager.dto.TaxRateDTO;

public class TaxRateMapper {

	public static TaxRateDTO map(TaxRate taxRate) {
		TaxRateDTO dto = new TaxRateDTO();
		

		dto.setCustomerName(taxRate.getCustomer().getCustomerName());
		dto.setCustomerId(taxRate.getCustomer().getCustomerId());
	    dto.setCustomerCode(taxRate.getCustomer().getCustomerCode());
	    dto.setEduCess(taxRate.getEduCess());
	    dto.setExciseDuty(taxRate.getExciseDuty());
	    dto.setHigherEduCess(taxRate.getHigherEduCess());
	    dto.setSalesTax(taxRate.getCst());
	    dto.setCst(taxRate.getCst());
	    dto.setTaxRateId(taxRate.getTaxRateId());
	    dto.setVat(taxRate.getVat());
	    dto.setFreight(taxRate.getFreight());
	    dto.setPaymentTerms(taxRate.getPaymentTerms());
	    
		return dto;
	}
	
	public static List<TaxRateDTO> map(List<TaxRate> taxRate) {
		List<TaxRateDTO> dtos = new ArrayList<TaxRateDTO>();
		
		for (TaxRate taxRateItem: taxRate) {
			dtos.add(map(taxRateItem));
		}
		return dtos;
	}

}