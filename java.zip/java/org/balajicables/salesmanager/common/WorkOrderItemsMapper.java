package org.balajicables.salesmanager.common;
import java.util.ArrayList;
import java.util.List;

import org.balajicables.salesmanager.model.WorkOrderItems;
import org.balajicables.salesmanager.dto.WorkOrderItemsDTO;

public class WorkOrderItemsMapper {

	public static WorkOrderItemsDTO map(WorkOrderItems workOrderItems) {
		WorkOrderItemsDTO workOrderItemDTO = new WorkOrderItemsDTO();
		
		workOrderItemDTO.setWorkOrderItemId(workOrderItems.getWorkOrderItemId());
		workOrderItemDTO.setWorkOrderNo(workOrderItems.getProductionWorkOrder().getWorkOrderNo());
		workOrderItemDTO.setOrderDetailId(workOrderItems.getSalesOrderItem().getOrderDetailId());
		workOrderItemDTO.setNumberOfCopperStrands(workOrderItems.getSalesOrderItem().getItem().getNumberOfCopperStrands());
		
		String cuKeyValue=String.valueOf(Double.valueOf(workOrderItems.getSalesOrderItem().getItem().getCopperStrandDiameter().getCopperkey())/1000) ;
		workOrderItemDTO.setCopperlabel(workOrderItems.getSalesOrderItem().getItem().getNumberOfCopperStrands()+"/"+cuKeyValue+"("+workOrderItems.getSalesOrderItem().getItem().getLayLength()+")");
       
		
		workOrderItemDTO.setPoDetails(workOrderItems.getSalesOrderItem().getOrder().getPoDetails());
    	String cuKey=String.valueOf(Double.valueOf(workOrderItems.getSalesOrderItem().getItem().getCopperStrandDiameter().getCopperkey())/100) ;
		workOrderItemDTO.setCopperKey(cuKey);
		workOrderItemDTO.setArea(workOrderItems.getSalesOrderItem().getItem().getArea().getAreaValue());
		workOrderItemDTO.setOuterDiameter(workOrderItems.getSalesOrderItem().getItem().getOuterDiameter());
		workOrderItemDTO.setOdLabel(workOrderItems.getSalesOrderItem().getItem().getOdLabel());
		workOrderItemDTO.setMainColour(workOrderItems.getSalesOrderItem().getItem().getMainColour().getColor());
		workOrderItemDTO.setInnerColour(workOrderItems.getSalesOrderItem().getItem().getInnerColour().getColor());
		workOrderItemDTO.setCableStd(workOrderItems.getSalesOrderItem().getItem().getCableStdPvc().getCableStd());
		workOrderItemDTO.setOrderId(workOrderItems.getSalesOrderItem().getOrder().getOrderId());
		workOrderItemDTO.setCustomerId(workOrderItems.getSalesOrderItem().getOrder().getCustomer().getCustomerId());
		workOrderItemDTO.setCustomerName(workOrderItems.getSalesOrderItem().getOrder().getCustomer().getCustomerName());
		workOrderItemDTO.setCustomerCode(workOrderItems.getSalesOrderItem().getOrder().getCustomer().getCustomerCode());
		workOrderItemDTO.setNoOfCoils(workOrderItems.getNoOfCoils());
		workOrderItemDTO.setQtyPerCoil(workOrderItems.getSalesOrderItem().getBundleSize());
		workOrderItemDTO.setTotalQuantity(workOrderItems.getTotalQuantity());
		workOrderItemDTO.setPackingType(workOrderItems.getPackingType());
		workOrderItemDTO.setPvcGrade(workOrderItems.getPvcGrade());
		workOrderItemDTO.setMasterBatch(workOrderItems.getMasterBatch());
		workOrderItemDTO.setToBeLabelled(workOrderItems.getToBeLabelled());
		workOrderItemDTO.setItemDescription(workOrderItems.getSalesOrderItem().getItem().getItemDescription());
		workOrderItemDTO.setItemCode(workOrderItems.getSalesOrderItem().getItem().getItemCode());
		workOrderItemDTO.setStockInQty(workOrderItems.getStockInQty());
		workOrderItemDTO.setStockInStatus(workOrderItems.getStockInStatus());
		workOrderItemDTO.setMainOrderSequence(workOrderItems.getSalesOrderItem().getItem().getMainColour().getOrderSequence());
		workOrderItemDTO.setStripeOrderSequence(workOrderItems.getSalesOrderItem().getItem().getInnerColour().getOrderSequence());
		return workOrderItemDTO;
	}
	
	public static List<WorkOrderItemsDTO> map(List<WorkOrderItems> workOrderItem) {
		List<WorkOrderItemsDTO> dtos = new ArrayList<WorkOrderItemsDTO>();
		for (WorkOrderItems workOrderItems: workOrderItem) {
			dtos.add(map(workOrderItems));
		}
		return dtos;
	}

}