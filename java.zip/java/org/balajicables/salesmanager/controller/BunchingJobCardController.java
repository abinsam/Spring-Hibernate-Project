package org.balajicables.salesmanager.controller;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
import javax.annotation.Resource;
import org.balajicables.salesmanager.CustomUser;
import org.balajicables.salesmanager.common.JqgridResponse;
import org.balajicables.salesmanager.common.StatusResponse;
import org.balajicables.salesmanager.dto.BunchingWOInputDTO;
import org.balajicables.salesmanager.dto.SalesOrderItemsDTO;
import org.balajicables.salesmanager.dto.SemifinishedStockOutDTO;
import org.balajicables.salesmanager.dto.StockInDTO;
import org.balajicables.salesmanager.dto.StoreRegisterDTO;
import org.balajicables.salesmanager.dto.WorkOrderOutputDTO;
import org.balajicables.salesmanager.model.BunchingWOInput;
import org.balajicables.salesmanager.model.ProductionWorkOrder;
import org.balajicables.salesmanager.model.SalesOrderItem;
import org.balajicables.salesmanager.model.SemifinishedStockOut;
import org.balajicables.salesmanager.model.StockIn;
import org.balajicables.salesmanager.model.StoreRegister;
import org.balajicables.salesmanager.model.WorkOrderOutput;
import org.balajicables.salesmanager.repository.BunchingWOInputRepository;
import org.balajicables.salesmanager.repository.ItemRepository;
import org.balajicables.salesmanager.repository.ProductionWorkOrderRepository;
import org.balajicables.salesmanager.repository.WorkOrderOutputRepository;
import org.balajicables.salesmanager.service.BunchingWOInputService;
import org.balajicables.salesmanager.service.OrderDetailsService;
import org.balajicables.salesmanager.service.ProductionWorkOrderService;
import org.balajicables.salesmanager.service.SemifinishedStockOutService;
import org.balajicables.salesmanager.service.StockInService;
import org.balajicables.salesmanager.service.StoreRegisterService;
import org.balajicables.salesmanager.service.WorkOrderOutputService;
import org.balajicables.salesmanager.utils.Utility;
import org.joda.time.DateTime;
import org.springframework.data.domain.Page;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
/**
* This class demonstrates Bunching Job Card Process.
* @author Abin Sam
*/
@Controller
@RequestMapping("/viewBunchingWorkOrder")
public class BunchingJobCardController {

	@Resource
	private StoreRegisterService storeRegisterService;
	
	@Resource
	private ProductionWorkOrderService productionWorkOrderService;
	
	@Resource
	private SemifinishedStockOutService semifinishedStockOutService;	
	
	@Resource
	private BunchingWOInputService bunchingWorkOrderInputService;
	
	@Resource
	BunchingWOInputRepository bunchingWorkOrderRepository;
	
	@Resource
	WorkOrderOutputRepository workOrderOutputRepository;
	
	@Resource
	WorkOrderOutputService workOrderOutputService;
		
	@Resource
	ItemRepository itemRepository;
	
	@Resource
	private OrderDetailsService orderDetailsService;
	
	@Resource 
	private ProductionWorkOrderRepository productionWorkOrderRepository;

	@Resource
	private StockInService stockInService;

	
	 /**
	   * This method returns bunchingJobCard.jsp.
	   * Fetch all Bunching Work Order Nos that have status pending and are in current month and year
	   * @param Model to set the attribute.
	   * @return bunchingJobCard.jsp.
	   */
	@RequestMapping(method = RequestMethod.GET)
	public String viewBunchingWorkOrder(Model model) {
		ArrayList<String> woNosList = new ArrayList<>();
		DateTime dt = new DateTime();  // current time
		int month =dt.getMonthOfYear();
		int year=dt.getYear();
		String bunching = "Bunching";
        String status="Pending";
        /*Method to fetch list of bunching work orders of current month,year and status Pending*/
		List<ProductionWorkOrder> productionWorkOrders = productionWorkOrderService.findByProcessTypeAndStatusAndMonthYear(bunching, status, month, year);// fetch all bunching work order have status pending and are in current month and year to a list
		for (int iterator = 0; iterator < productionWorkOrders.size(); iterator++) {
			if (productionWorkOrders.get(iterator).getWorkOrderNo() != null
					&& productionWorkOrders.get(iterator).getWorkOrderNo() != "") {
				String woNo = productionWorkOrders.get(iterator).getWorkOrderNo();
				if (!woNosList.contains(woNo)) {
					woNosList.add(woNo);
				}
			}
			/*sorts the list of RBD Work Order numbers into descending order*/
			Collections.sort(woNosList,Collections.reverseOrder());
		}
		model.addAttribute("workOrderNo", woNosList);// set bunching work order nos to model attribute
		return "bunchingJobCard";
	}
	
	 /**
	   * This POST method is to fetch details of a Work order No.
	   * @param Work Order No  .
	   * @return Work Order details List.
	   */
	@RequestMapping(value="/getWODetails/{woNo}", produces="application/json", method=RequestMethod.POST)
	public @ResponseBody
	List<String> getWODetails(@PathVariable("woNo") String woNo) {
		
		List<ProductionWorkOrder> pdnWorkOrder = productionWorkOrderRepository.findByWorkOrderNo(woNo);// fetch all work order details to a list
		List<String> pdnWoValuesList =  new ArrayList<String>();
		pdnWoValuesList.add(Utility.formDateFormatter.print(pdnWorkOrder.get(0).getStartDate().getTime()));//add start date of work order to List to be returned
		pdnWoValuesList.add(Utility.formDateFormatter.print(pdnWorkOrder.get(0).getEndDate().getTime()));//add end date of work order to List to be returned
		pdnWoValuesList.add(pdnWorkOrder.get(0).getMachine().getDescription());//add machine details of work order to List to be returned
		pdnWoValuesList.add(pdnWorkOrder.get(0).getStatus());//add status of work order to List to be returned
		
		List<String> sizeList =  new ArrayList<String>();	
		
		List<BunchingWOInput> bunchingWOInput =bunchingWorkOrderRepository.findByProductionWorkOrderWorkOrderNo(woNo);//fetch bunching work order input details of a work order no to a list
		/*Iterating the List to get distinct values of Work Order No*/
		for(int iterator=0; iterator < bunchingWOInput.size();iterator++){
			if(!(sizeList.contains(bunchingWOInput.get(iterator)))){
				sizeList.add(bunchingWOInput.get(iterator).getSize());
			}// end of if loop		
		}//end of for loop
		pdnWoValuesList.add(sizeList.toString());
		return pdnWoValuesList;
	}
	
	 /**
	   * This POST method is to fetch Bunching Work Order Details for JQ grid.
	   * @param Work Order No  .
	   * @return JqgridResponse<BunchingWOInputDTO>response  .
	   */
	@RequestMapping(value="/populateWODetailsGrid/{woNo}", produces="application/json", method=RequestMethod.POST)
	public @ResponseBody 
	JqgridResponse<BunchingWOInputDTO> populateWODetailsGrid(
			@PathVariable("woNo") String woNo,
			@RequestParam(value="filters", required=false) String filters,
			@RequestParam(value = "page", required = false) Integer pageNumber,
			@RequestParam(value = "rows", required = false) Integer rowsPerPage,
			@RequestParam(value = "sidx", required = false) String sortColName,
			@RequestParam(value = "sord", required = false, defaultValue = "asc") String sortOrder) {

		/*JQGrid column sorting*/
		if(sortColName.equalsIgnoreCase("customerCode")){
			sortColName="salesOrderItem.orders.customer.customerCode";
		}

		if(sortColName.equalsIgnoreCase("customerName")){
			sortColName="salesOrderItem.orders.customer.customerName";
		}
		if(sortColName.equalsIgnoreCase("customerCode")){
			sortColName="salesOrderItem.orders.customer.customerCode";
		}
	    	/*Method to fetch JQGRID paged records of Bunching Workorder Output items based on woNo*/
			Page<BunchingWOInput> bunchingWorkOrderOutput = bunchingWorkOrderInputService.getPagedOrders(woNo, pageNumber -1, rowsPerPage, sortColName, sortOrder);
			/*Intialize JQ grid response of type BunchingWOInputDTO*/	
			JqgridResponse<BunchingWOInputDTO> response = new JqgridResponse<BunchingWOInputDTO>();
			/*Method to set Bunching Workorder Output items list to BunchingWOInputDTO*/
			List<BunchingWOInputDTO> bunchingWorkOrderDTOs = convertToBunchingWoDTO(bunchingWorkOrderOutput.getContent(),woNo);// calling method to set the Page result to BunchingWOInputDTO object
			response.setRows(bunchingWorkOrderDTOs);
			response.setRecords(Long.valueOf(bunchingWorkOrderOutput.getTotalElements()).toString());
			response.setTotal(Long.valueOf(bunchingWorkOrderOutput.getTotalPages()).toString());
			response.setPage(Integer.valueOf(bunchingWorkOrderOutput.getNumber()+1).toString());
			return response;
	}
	
	 /**
	   * This  method is to set the Page result to BunchingWOInputDTO object.
	   * @param List<BunchingWOInput>,Work Order No .
	   * @return List<BunchingWOInputDTO>  .
	   */
	private List<BunchingWOInputDTO> convertToBunchingWoDTO(
			List<BunchingWOInput> bunchingWorkOrders, String woNo) {
		List<BunchingWOInputDTO> bunchingWoDTOs = new ArrayList<>();
		for(BunchingWOInput bunchingWo : bunchingWorkOrders) {
			BunchingWOInputDTO bunchingWoDTO = new BunchingWOInputDTO();
			bunchingWoDTO.setBunchWoInputId(bunchingWo.getBunchWoInputId());
			bunchingWoDTO.setWorkOrderNo(bunchingWo.getProductionWorkOrder().getWorkOrderNo());
			bunchingWoDTO.setSize(bunchingWo.getSize());
			bunchingWoDTO.setNoOfDrums(bunchingWo.getNoOfDrums());
			bunchingWoDTO.setNetLength(bunchingWo.getNetLength());
			bunchingWoDTO.setLengthPerDrum(bunchingWo.getLengthPerDrum());
			bunchingWoDTO.setLayLength(bunchingWo.getLayLength());
			bunchingWoDTO.setCustomerName(bunchingWo.getCustomerName());
			bunchingWoDTO.setCustomerCode(bunchingWo.getSalesOrderItem().getOrder().getCustomer().getCustomerCode());
			bunchingWoDTO.setStatus(bunchingWo.getStatus());
			bunchingWoDTO.setTotalQty(bunchingWo.getTotalQty());
			bunchingWoDTO.setSelectStatus(bunchingWo.getSelectStatus());
			bunchingWoDTOs.add(bunchingWoDTO);
		}// end of for lop
		return bunchingWoDTOs;
	}
	 /**
	   * Crud Functionality of Bunching Work Order Input Grid.
	   * @param Bunching Work Order Input Grid Data .
	   * @return StatusResponse  .
	   */
	@RequestMapping(value = "/crudForFirstGrid", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	StatusResponse crudForFirstGrid(@RequestParam Long id,
			@RequestParam String oper,
			@RequestParam(required = false) String workOrderNo,
			@RequestParam(required = false) String bunchingSize,
			@RequestParam (required=false)  Long noOfDrums,
			@RequestParam (required=false)  String lengthPerDrum,
			@RequestParam (required=false)  Integer layLength,
			@RequestParam (required=false)  String customerName
			) {
		
		boolean match =false;
		Boolean result = false;
		Double newLengthPerDrum=Double.valueOf(lengthPerDrum);
		/*fetch user name based on login user*/
		CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();;
	 	String userName = user.getFirstName()+" "+user.getLastName();
	 	
		BunchingWOInput bunchingWOInput = null;
		List<BunchingWOInput> exBunchingWOInput =bunchingWorkOrderRepository.findByBunchWoInputId(id);//fetch Bunching Work Order Input table details
	
		if(oper.equalsIgnoreCase("edit")){
			String decimalPattern = "((-|\\+)?[0-9]+(\\.[0-9]+)?)+";  
			match = Pattern.matches(decimalPattern, lengthPerDrum);
			
			if(match==true){
			 if(exBunchingWOInput.size()>0){
				    BunchingWOInputDTO bunchingWOInputDTO =  new BunchingWOInputDTO();
	        	    bunchingWOInputDTO.setBunchWoInputId(exBunchingWOInput.get(0).getBunchWoInputId());
	        	    bunchingWOInputDTO.setOrderDetailId(exBunchingWOInput.get(0).getSalesOrderItem().getOrderDetailId());
	    		    bunchingWOInputDTO.setWorkOrderNo(exBunchingWOInput.get(0).getProductionWorkOrder().getWorkOrderNo());
	    			bunchingWOInputDTO.setSize(exBunchingWOInput.get(0).getSize());
	    			bunchingWOInputDTO.setNetLength(exBunchingWOInput.get(0).getNetLength());
	    			bunchingWOInputDTO.setNoOfDrums(exBunchingWOInput.get(0).getNoOfDrums());
	    			bunchingWOInputDTO.setLengthPerDrum(newLengthPerDrum);
	    			bunchingWOInputDTO.setLayLength(exBunchingWOInput.get(0).getLayLength());
	    			bunchingWOInputDTO.setCustomerName(exBunchingWOInput.get(0).getCustomerName());
	    			bunchingWOInputDTO.setUpdatedBy(userName);
	    			bunchingWOInputDTO.setStatus(exBunchingWOInput.get(0).getStatus());
	    			bunchingWOInputDTO.setCreatedBy(exBunchingWOInput.get(0).getCreatedBy());
	    			bunchingWOInputDTO.setTotalQty(exBunchingWOInput.get(0).getTotalQty());
	    			bunchingWOInputDTO.setSelectStatus(exBunchingWOInput.get(0).getSelectStatus());
	    			bunchingWOInput = bunchingWOInputDTO.getBunchingWOInput();
	    	
		}// end of list size check if loop
			 }// end of if(match==true) loop
			  }//end of if(oper.equalsIgnoreCase("edit")) loop
				switch (oper) {
    			case "edit":
    				if(match==true){
    				result = bunchingWorkOrderInputService.update(bunchingWOInput);
    				}//end of if(match==true) loop 
    				break;
    			case "del":
    			    Long salesOrderItemId=exBunchingWOInput.get(0).getSalesOrderItem().getOrderDetailId();
    			    String orderId=exBunchingWOInput.get(0).getSalesOrderItem().getOrder().getOrderId();
    			    Double balQty=exBunchingWOInput.get(0).getSalesOrderItem().getBalanceQty();
    			    Double pdnQty=exBunchingWOInput.get(0).getSalesOrderItem().getProductionQty();
    			    Double woQty=exBunchingWOInput.get(0).getTotalQty();
    			    Double totalQty=exBunchingWOInput.get(0).getSalesOrderItem().getQuantity();
    			    Double newBalQty=0.0;
    			    Double newPdnQty=0.0;
    			    Double newTotalQty=0.0;
    			    if(orderId.equalsIgnoreCase("BS000001")){
    			    	newBalQty=0.0;
    			    	if(woQty<totalQty){
    			    		newTotalQty=totalQty-woQty;
    					  	newPdnQty=pdnQty-woQty;
    				     }
    			    }//end of if(orderId.equalsIgnoreCase("BS000001")) loop
    			    else{
    			    	newTotalQty=totalQty;
    			    	newBalQty=balQty+woQty;
    			    	if(pdnQty>woQty)
    			    		newPdnQty=pdnQty-woQty;
    			    }//else of else loop
    			    bunchingWorkOrderRepository.delete(id);
    			    result=orderDetailsService.updateBalPdnQty(salesOrderItemId,newTotalQty,newBalQty,newPdnQty);
    		        break;

    			}//end of switch loop
          	return new StatusResponse(result);
	}
      /** Method to Create Bunching Work Order Output.
	   * @param array of bunching work order input ids .
	   * @return StatusResponse  .
	   */
	@RequestMapping(value="/createBunchingWoOutput", produces="application/json", method=RequestMethod.POST)
	public @ResponseBody
	StatusResponse createBunchingWoOutput(
			@RequestParam(value = "idsOfSelectedRows[]", required = false) Long[] idsOfSelectedRows) {
		/*fetch user name based on login user*/
		CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();;
	 	String userName = user.getFirstName()+" "+user.getLastName();	
	 	Boolean pdnWorkOrderOutputResult=false;
	 	Boolean result=false;
		String newBatchNo;
	 	for (int i = 0; i < idsOfSelectedRows.length; i++) {
	 		/*List of Bunching work order input based on Ids*/
	 		List<BunchingWOInput> bunchingWoInputWorkOrder =bunchingWorkOrderInputService.findById(idsOfSelectedRows[i]);
			
	 		/*List of latest bunching work output*/
	 		List<WorkOrderOutput> existBatchNoList = workOrderOutputService.fetchLatestBatchNo(bunchingWoInputWorkOrder.get(0).getProductionWorkOrder().getWorkOrderNo());
			String existBatchNo = "";
			if (existBatchNoList.size() > 0)
				existBatchNo = existBatchNoList.get(0).getBatchNo();

			if (!existBatchNo.isEmpty()) {
				String existBatchNoWo = existBatchNo.substring(0, 8);
				String existBatchNoId = existBatchNo.substring(9, 11);
				int serialNoInt = 0;
				serialNoInt = Integer.parseInt(existBatchNoId) + 1;

				if (serialNoInt < 10) {
					newBatchNo = existBatchNoWo + "/0"+ String.valueOf(serialNoInt);
				} else {
					newBatchNo = existBatchNoWo + "/"+ String.valueOf(serialNoInt);
				}
			}// end of if loop of checking existing sales no
			else {
				newBatchNo = bunchingWoInputWorkOrder.get(0).getProductionWorkOrder().getWorkOrderNo()+ "/" + "01";
			}	
		    if(bunchingWoInputWorkOrder.size()>0){
		    	//Setting Work Order Output
		    	WorkOrderOutputDTO workOrderOutputDTO = new WorkOrderOutputDTO();
				workOrderOutputDTO.setWorkOrderNo(bunchingWoInputWorkOrder.get(0).getProductionWorkOrder().getWorkOrderNo());
				workOrderOutputDTO.setBatchNo(newBatchNo);
				workOrderOutputDTO.setNetLength(bunchingWoInputWorkOrder.get(0).getLengthPerDrum());
				workOrderOutputDTO.setNetWeight(0.0);
				workOrderOutputDTO.setGrossWeight(0.0);
				workOrderOutputDTO.setTareWeight(0.0);
	            workOrderOutputDTO.setOrderDetailId(bunchingWoInputWorkOrder.get(0).getSalesOrderItem().getOrderDetailId());
				workOrderOutputDTO.setAnnealingPercent(null);
				workOrderOutputDTO.setSize(bunchingWoInputWorkOrder.get(0).getSize());
				workOrderOutputDTO.setSpeed("0");
				workOrderOutputDTO.setUpdatedBy(userName);
				workOrderOutputDTO.setStockIn("No");
				workOrderOutputDTO.setOuterDiameter("0");
				WorkOrderOutput workOrderOutput = workOrderOutputDTO.getWorkOrderOutput();
				WorkOrderOutput createdWoOutput = workOrderOutputService.create(workOrderOutput);//Save Work Order Output
				if (createdWoOutput != null) {
					pdnWorkOrderOutputResult = true;
				}
	            if(pdnWorkOrderOutputResult==true){
	            	//Setting BunchingWOInputDTO with status "Yes"
                	BunchingWOInputDTO bunchingWOInputDTO = new BunchingWOInputDTO();
                	bunchingWOInputDTO.setBunchWoInputId(bunchingWoInputWorkOrder.get(0).getBunchWoInputId());
                	bunchingWOInputDTO.setWorkOrderNo(bunchingWoInputWorkOrder.get(0).getProductionWorkOrder().getWorkOrderNo());
                	bunchingWOInputDTO.setOrderDetailId(bunchingWoInputWorkOrder.get(0).getSalesOrderItem().getOrderDetailId());
                	bunchingWOInputDTO.setSize(bunchingWoInputWorkOrder.get(0).getSalesOrderItem().getItem().getInputSize());
                	bunchingWOInputDTO.setNetLength(bunchingWoInputWorkOrder.get(0).getNetLength());
                    
                	bunchingWOInputDTO.setBunchWoInputId(bunchingWoInputWorkOrder.get(0).getBunchWoInputId());
	        	    bunchingWOInputDTO.setOrderDetailId(bunchingWoInputWorkOrder.get(0).getSalesOrderItem().getOrderDetailId());
	    		    bunchingWOInputDTO.setWorkOrderNo(bunchingWoInputWorkOrder.get(0).getProductionWorkOrder().getWorkOrderNo());
	    			bunchingWOInputDTO.setSize(bunchingWoInputWorkOrder.get(0).getSize());
	    			bunchingWOInputDTO.setNetLength(bunchingWoInputWorkOrder.get(0).getNetLength());
	    			bunchingWOInputDTO.setNoOfDrums(bunchingWoInputWorkOrder.get(0).getNoOfDrums());
	    			bunchingWOInputDTO.setLengthPerDrum(bunchingWoInputWorkOrder.get(0).getLengthPerDrum());
	    			bunchingWOInputDTO.setLayLength(bunchingWoInputWorkOrder.get(0).getLayLength());
	    			bunchingWOInputDTO.setCustomerName(bunchingWoInputWorkOrder.get(0).getCustomerName());
	    			bunchingWOInputDTO.setCustomerCode(bunchingWoInputWorkOrder.get(0).getSalesOrderItem().getOrder().getCustomer().getCustomerCode());
	    			bunchingWOInputDTO.setUpdatedBy(bunchingWoInputWorkOrder.get(0).getUpdatedBy());
	    			bunchingWOInputDTO.setStatus(bunchingWoInputWorkOrder.get(0).getStatus());
	    			bunchingWOInputDTO.setCreatedBy(bunchingWoInputWorkOrder.get(0).getCreatedBy());
	    			bunchingWOInputDTO.setTotalQty(bunchingWoInputWorkOrder.get(0).getTotalQty());
	    			bunchingWOInputDTO.setSelectStatus("Yes");
	   
	    			BunchingWOInput bunchingWorkOrderInput=bunchingWOInputDTO.getBunchingWOInput();
    				result=bunchingWorkOrderInputService.update(bunchingWorkOrderInput);//update bunchingWorkOrderInput
                }//end of if(pdnWorkOrderOutputResult==true) loop
		    }// end of if(bunchingWoInputWorkOrder.size()>0) loop
			}//end of for loop

		return new StatusResponse(result);
	}

	  /** Method to fetch bunching work order output records and set to grid
	   * @param workOrderNo,filters,pageNumber,rowsPerPage,sortColName,sortOrder
	   * @return JqgridResponse<WorkOrderOutputDTO>   .
	   */
	@RequestMapping(value="/records/{woNo}", produces="application/json", method=RequestMethod.POST)
	public @ResponseBody
	JqgridResponse<WorkOrderOutputDTO> records(
			@PathVariable("woNo") String workOrderNo,
    		@RequestParam("_search") Boolean search,
    		@RequestParam(value="filters", required=false) String filters,
			@RequestParam(value = "page", required = false) Integer pageNumber,
			@RequestParam(value = "rows", required = false) Integer rowsPerPage,
			@RequestParam(value = "sidx", required = false) String sortColName,
			@RequestParam(value = "sord", required = false, defaultValue = "asc") String sortOrder) {
		//fetch paged list of bunching work order output based on work order no
		Page<WorkOrderOutput> workOrderOutputs= workOrderOutputService.getWoOutputPagedList(workOrderNo, pageNumber -1, rowsPerPage, sortColName, sortOrder);
		
		JqgridResponse<WorkOrderOutputDTO> response = new JqgridResponse<WorkOrderOutputDTO>();
        //setting fetch result to WorkOrderOutputDTO
		List<WorkOrderOutputDTO> workOrderOutputDTOs = convertToDTO(workOrderOutputs.getContent());
		response.setRows(workOrderOutputDTOs);
		response.setRecords(Long.valueOf(workOrderOutputs.getTotalElements()).toString());
		response.setTotal(Long.valueOf(workOrderOutputs.getTotalPages()).toString());
		response.setPage(Integer.valueOf(workOrderOutputs.getNumber()+1).toString());

		return response;
	}
	
	  /**setting bunching WorkOrderOutput records to WorkOrderOutputDTO
	   * @param List<WorkOrderOutput>
	   * @return List<WorkOrderOutputDTO> .
	   */
	private List<WorkOrderOutputDTO> convertToDTO(List<WorkOrderOutput> workOrderOutputs) {
		List<WorkOrderOutputDTO> BunchingWOOutputDTOs = new ArrayList<>();
		for(WorkOrderOutput workOrderOutput : workOrderOutputs) {
			WorkOrderOutputDTO workOrderDTO = new WorkOrderOutputDTO();
			workOrderDTO.setWoOutPutId(workOrderOutput.getWoOutPutId());
			workOrderDTO.setWorkOrderNo(workOrderOutput.getProductionWorkOrder().getWorkOrderNo());
			workOrderDTO.setNetLength(workOrderOutput.getNetLength());
			workOrderDTO.setGrossWeight(workOrderOutput.getGrossWeight());
			workOrderDTO.setTareWeight(workOrderOutput.getTareWeight());
			workOrderDTO.setNetWeight(workOrderOutput.getNetWeight());
			workOrderDTO.setNoOfStrands(workOrderOutput.getNoOfStrands());
			workOrderDTO.setSize(workOrderOutput.getSize());
			workOrderDTO.setSpeed(workOrderOutput.getSpeed());
			workOrderDTO.setAnnealingPercent(workOrderOutput.getAnnealingPercent());
			workOrderDTO.setOuterDiameter(workOrderOutput.getOuterDiameter());
			workOrderDTO.setUpdatedBy(workOrderOutput.getUpdatedBy());
			workOrderDTO.setBatchNo(workOrderOutput.getBatchNo());
			workOrderDTO.setStockIn(workOrderOutput.getStockIn());
			workOrderDTO.setOrderDetailId(workOrderOutput.getSalesOrderItem().getOrderDetailId());
			
			BunchingWOOutputDTOs.add(workOrderDTO);
			}//end of for loop
		return BunchingWOOutputDTOs;
	}
	
	
	
	  /**crud functionality of bunching work order outputs
	   * @param WoOutPutId,oper, workOrderNo, batchNo, size,bunchingSize, netLength, grossWeight,
	   *   tareWeight,outerDiameter,noOfStrands,stockIn
	   * @return StatusResponse .
	   */
		
	@RequestMapping(value = "/crud", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	StatusResponse crud(@RequestParam Long id,
			@RequestParam String oper,
			@RequestParam(required = false) String workOrderNo,
			@RequestParam(required = false) String batchNo,
			@RequestParam(required = false) String size,
			@RequestParam(required = false) String bunchingSize,
			@RequestParam (required=false)  String netLength,
			@RequestParam (required=false)  String grossWeight,
			@RequestParam (required=false)  String tareWeight,
			@RequestParam (required=false)  String outerDiameter,
			@RequestParam (required=false)  Integer noOfStrands,
			@RequestParam(required = false) String stockIn
			) {
		
		Boolean result = false;
		boolean netLengthMatch = false;
		boolean grossWeightMatch =false;
		boolean tareWeightMatch = false;
		boolean odMatch = false;
		/*fetch user name based on login user*/
		CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();;
		String userName = user.getFirstName()+" "+user.getLastName();
		     Double newNetLength=0.0;
		    Double newGrossWeight=0.0;
		    Double newTareWeight=0.0;
	 
		if(oper.equalsIgnoreCase("edit")){
			String decimalPattern = "((-|\\+)?[0-9]+(\\.[0-9]+)?)+";  
			// regex pattern matching of netlength, weight and od
			netLengthMatch = Pattern.matches(decimalPattern, netLength);
			grossWeightMatch = Pattern.matches(decimalPattern, grossWeight);
			tareWeightMatch = Pattern.matches(decimalPattern, tareWeight);
			odMatch = Pattern.matches(decimalPattern, outerDiameter);
			
			if(netLengthMatch==true && grossWeightMatch==true && tareWeightMatch==true && odMatch==true ){
				 newNetLength=Double.valueOf(netLength);
				  newGrossWeight=Double.valueOf(grossWeight);
				  newTareWeight=Double.valueOf(tareWeight);
			 
		}// end of inner if loop
		}//end of if(oper.equalsIgnoreCase("edit")) loop

			switch (oper) {
			case "edit":
				if(netLengthMatch==true && grossWeightMatch==true && tareWeightMatch==true && odMatch==true ){
			   if(newGrossWeight>newTareWeight || newGrossWeight==newTareWeight || (newGrossWeight==0.0 && newTareWeight==0.0)){
				   List<WorkOrderOutput>woOutputList=workOrderOutputService.findByWoOutputId(id);//fetch workorder output by Id
				if(woOutputList.size()>0){
					WorkOrderOutputDTO workOrderOutputDTO = new WorkOrderOutputDTO();
	    		workOrderOutputDTO.setWoOutPutId(id);
				workOrderOutputDTO.setWorkOrderNo(woOutputList.get(0).getProductionWorkOrder().getWorkOrderNo());
				workOrderOutputDTO.setBatchNo(woOutputList.get(0).getBatchNo());
				workOrderOutputDTO.setSize(woOutputList.get(0).getSize());
				workOrderOutputDTO.setNetLength(newNetLength);
				workOrderOutputDTO.setGrossWeight(Math.round(newGrossWeight*100.0)/100.0);
				workOrderOutputDTO.setTareWeight(Math.round(newTareWeight*100.0)/100.0);
	     		Double netWeight = newGrossWeight - newTareWeight;
				if (netWeight > 0.0) {
					workOrderOutputDTO.setNetWeight(Math.round(netWeight*100.0)/100.0);
				}else{
					workOrderOutputDTO.setNetWeight(0.0);
				}

				workOrderOutputDTO.setAnnealingPercent(null);
				workOrderOutputDTO.setStockIn(stockIn);	
				workOrderOutputDTO.setOrderDetailId(woOutputList.get(0).getSalesOrderItem().getOrderDetailId());
				workOrderOutputDTO.setSpeed(null);
				workOrderOutputDTO.setUpdatedBy(userName);
				workOrderOutputDTO.setCreatedTime(woOutputList.get(0).getCreatedTime().toString());
				workOrderOutputDTO.setOuterDiameter(outerDiameter);
				workOrderOutputDTO.setNoOfStrands(noOfStrands);
		        WorkOrderOutput workOrderOutput = workOrderOutputDTO.getWorkOrderOutput();
				result = workOrderOutputService.update(workOrderOutput);//update workOrderOutput
				}//end of if(woOutputList.size()>0) loop
				}
			   }
				break;
			  case "del":
				result = workOrderOutputService.delete(id);//delete workOrderOutput
				break;
			}// end of 	switch (oper)  loop
	    	return new StatusResponse(result);
	}
	  /**submit BunchingWorkOrder
	   * @param  workOrderNo
	   * @return void .
	   */
	@RequestMapping(value="/submitBunchingWorkOrder/{woNo}", produces="application/json", method=RequestMethod.POST)
	public @ResponseBody
	void submitBunchingWorkOrder(
			@PathVariable("woNo") String woNo) {
		String updateStatus="Submitted";
		productionWorkOrderService.updateWorkOrderStatus(woNo,updateStatus);//method to update work order status
		
	}
	  /**stock in  BunchingWorkOrder outputs
	   * @param  BunchingWorkOrder output id
	   * @return StatusResponse .
	   */
	@RequestMapping(value="/stockInBunching/{id}", produces="application/json", method=RequestMethod.POST)
	public @ResponseBody
	StatusResponse stockIn(@PathVariable("id") Long id) {
		Long orderDetailId=null;
		String salesOrder=null;
		String itemCode=null;
		String workOrderNo=null;
		Double stockInWeight=0.0;
		Boolean  updateWorkOrderOutput=false;
		Boolean  updateSoItemResult=false;
		Boolean  updateStockInResult=false;
		Boolean updateStoreReg=false;
		StockIn createdStockIn=null;
		StoreRegister createdStoreReg=null;
		
		//fetch login username 
		CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();;
		String userName = user.getFirstName()+" "+user.getLastName();
		 String bundleNo=null;
		 
		 //fetch WorkOrderOutput by WorkOrderOutputId
		List<WorkOrderOutput> workOrderOutput = workOrderOutputRepository.findByWoOutPutId(id);
		if(workOrderOutput.size()>0){
			if(workOrderOutput.get(0).getGrossWeight()>workOrderOutput.get(0).getTareWeight()){
			
				orderDetailId=workOrderOutput.get(0).getSalesOrderItem().getOrderDetailId();// get order detail id
				salesOrder=workOrderOutput.get(0).getSalesOrderItem().getOrder().getOrderId();
				itemCode=workOrderOutput.get(0).getSalesOrderItem().getItem().getItemCode();
                workOrderNo=workOrderOutput.get(0).getProductionWorkOrder().getWorkOrderNo();
				if(workOrderOutput.get(0).getSalesOrderItem().getItem().getUnit().getUnits().equalsIgnoreCase("Kgs") || workOrderOutput.get(0).getSalesOrderItem().getItem().getUnit().getUnits().equalsIgnoreCase("Kg") )                
                   stockInWeight=workOrderOutput.get(0).getNetWeight();// get net weight
				else
					stockInWeight=workOrderOutput.get(0).getNetLength();	
				WorkOrderOutputDTO workOrderOutputDTO= new WorkOrderOutputDTO();
				
				workOrderOutputDTO.setWoOutPutId(workOrderOutput.get(0).getWoOutPutId());
				workOrderOutputDTO.setWorkOrderNo(workOrderOutput.get(0).getProductionWorkOrder().getWorkOrderNo());
				workOrderOutputDTO.setNetLength(workOrderOutput.get(0).getNetLength());
				workOrderOutputDTO.setGrossWeight(workOrderOutput.get(0).getGrossWeight());
				workOrderOutputDTO.setTareWeight(workOrderOutput.get(0).getTareWeight());
				workOrderOutputDTO.setNetWeight(workOrderOutput.get(0).getNetWeight());
				workOrderOutputDTO.setNoOfStrands(workOrderOutput.get(0).getNoOfStrands());
				workOrderOutputDTO.setSize(workOrderOutput.get(0).getSize());
				workOrderOutputDTO.setSpeed(workOrderOutput.get(0).getSpeed());
				workOrderOutputDTO.setAnnealingPercent(workOrderOutput.get(0).getAnnealingPercent());
				workOrderOutputDTO.setOuterDiameter(workOrderOutput.get(0).getOuterDiameter());
				workOrderOutputDTO.setCreatedTime(workOrderOutput.get(0).getCreatedTime().toString());
				workOrderOutputDTO.setUpdatedBy(workOrderOutput.get(0).getUpdatedBy());
				workOrderOutputDTO.setBatchNo(workOrderOutput.get(0).getBatchNo());
				workOrderOutputDTO.setStockIn("Yes");
				bundleNo="0"+workOrderOutput.get(0).getBatchNo().substring(9);// formatting bundle id from batch no
				workOrderOutputDTO.setOrderDetailId(workOrderOutput.get(0).getSalesOrderItem().getOrderDetailId());
				WorkOrderOutput woOutput=workOrderOutputDTO.getWorkOrderOutput();
				updateWorkOrderOutput=workOrderOutputService.update(woOutput);
				
				if(orderDetailId!=null && updateWorkOrderOutput==true){
					// fetching sales order item based on id
					List<SalesOrderItem>soItemList=orderDetailsService.findById(orderDetailId);
					if(soItemList.size()>0){
						Double totalQtyOrdered=soItemList.get(0).getQuantity();
						Double newStockedInQty=soItemList.get(0).getCompletedQty() + stockInWeight;
                     	Double stockedOutQty=soItemList.get(0).getDispatchedQty();
						Double oldPdnQty=soItemList.get(0).getProductionQty();
						Double newBalQty=0.0;
						Double newPdnQty=0.0;
			            if(oldPdnQty<(newStockedInQty+stockedOutQty)){
			            	newPdnQty=0.0;
			            }else{
			            	newPdnQty=oldPdnQty-(newStockedInQty+stockedOutQty);
			            }
						if(totalQtyOrdered<(newPdnQty+newStockedInQty+stockedOutQty)){
							newBalQty=0.0;
						}else{
							newBalQty=totalQtyOrdered-(newPdnQty+newStockedInQty+stockedOutQty);
						}
							//setting SalesOrderItemsDTO
						SalesOrderItemsDTO soitemsDTO = new SalesOrderItemsDTO();
						soitemsDTO.setOrderDetailId(soItemList.get(0).getOrderDetailId());
						soitemsDTO.setOrderId(soItemList.get(0).getOrder().getOrderId());
						soitemsDTO.setItemId(soItemList.get(0).getItem().getItemId());
						soitemsDTO.setQuantity(totalQtyOrdered);
						soitemsDTO.setBalanceQty(newBalQty);
						soitemsDTO.setProductionQty(newPdnQty);
						soitemsDTO.setCompletedQty(newStockedInQty);
						soitemsDTO.setDispatchedQty(stockedOutQty);
						soitemsDTO.setWoQty(soItemList.get(0).getWoQty());
						soitemsDTO.setWeight(soItemList.get(0).getWeight());
						soitemsDTO.setBundleSize(soItemList.get(0).getBundleSize());
						soitemsDTO.setRate(soItemList.get(0).getRate());
						soitemsDTO.setItemCode(soItemList.get(0).getItemCode());
						soitemsDTO.setUpdatedBy(soItemList.get(0).getUpdatedBy());
						soitemsDTO.setUpdatedTime(soItemList.get(0).getUpdatedTime().toString());
						soitemsDTO.setPvcWeight(soItemList.get(0).getPvcWeight());
						SalesOrderItem soitem=soitemsDTO.getOrderDetail();
						updateSoItemResult=orderDetailsService.update(soitem);// update SalesOrderItems
					
			}	// end of if(soItemList.size()>0) loop		
					if(updateSoItemResult==true && salesOrder!=null && itemCode!=null && workOrderNo!=null){
						String confirmStatus="No";
						//List<StockIn>stockInList=stockInService.findByOrderDetailIdBundleIdWorkOrderNo(orderDetailId, soItemList.get(0).getBundleSize().toString(), workOrderOutput.get(0).getProductionWorkOrder().getWorkOrderNo());
						List<StockIn>stockInList=stockInService.findByOrderIdAndItemCodeAndWoNoAndBundleIdAndConfirmStatus(salesOrder, itemCode, workOrderNo, soItemList.get(0).getBundleSize().toString(), confirmStatus);

						List<StoreRegister>storeRegExistList=storeRegisterService.findByOrderDetailIdAndBundleIdAndWorkOrderNo(orderDetailId, bundleNo, workOrderOutput.get(0).getProductionWorkOrder().getWorkOrderNo());
						    StockInDTO stockInDTO = new StockInDTO();
							stockInDTO.setStoreId(1);
							stockInDTO.setOrderDetailId(orderDetailId);
							stockInDTO.setOrderId(soItemList.get(0).getOrder().getOrderId());
							stockInDTO.setItemId(soItemList.get(0).getItem().getItemId());
							stockInDTO.setItemCode(soItemList.get(0).getItem().getItemCode());
							stockInDTO.setSoItemQty(soItemList.get(0).getQuantity());
							stockInDTO.setWorkOrderNo(workOrderOutput.get(0).getProductionWorkOrder().getWorkOrderNo());
							stockInDTO.setQcStatus("Approved");
							stockInDTO.setCustomerName(soItemList.get(0).getOrder().getCustomer().getCustomerName());
							stockInDTO.setBundleId(bundleNo);
							stockInDTO.setBatchNo(workOrderOutput.get(0).getBatchNo());
							stockInDTO.setConfirmStatus("Yes");
							stockInDTO.setStockQty(workOrderOutput.get(0).getNetLength());
							stockInDTO.setWeight(workOrderOutput.get(0).getNetWeight());
					        stockInDTO.setSupervisor(userName);
							StockIn stockInObj=null;
							if(stockInList.size()==0 && storeRegExistList.size()==0 ){
								  stockInObj=stockInDTO.getStockIn();
								 createdStockIn=stockInService.create(stockInObj);
								 if(createdStockIn!=null)
								 updateStockInResult=true;
								 else
									 updateStockInResult=false;	 
							}
							
							if(updateStockInResult==true && storeRegExistList.size()==0){
								//setting to StoreRegisterDTO
								StoreRegisterDTO storeRegDTO=new StoreRegisterDTO();
								storeRegDTO.setItemCode(soItemList.get(0).getItem().getItemCode());
								storeRegDTO.setStoreId(1);
								storeRegDTO.setWorkOrderNo(workOrderOutput.get(0).getProductionWorkOrder().getWorkOrderNo());
								storeRegDTO.setCustomerName(soItemList.get(0).getOrder().getCustomer().getCustomerName());
								storeRegDTO.setBundleId(bundleNo);
								
								storeRegDTO.setOrderId(soItemList.get(0).getOrder().getOrderId());
								storeRegDTO.setOrderDetailId(orderDetailId);
								storeRegDTO.setItemId(soItemList.get(0).getItem().getItemId());
								storeRegDTO.setSupervisor(userName);
								
								if(soItemList.get(0).getOrder().getOrderId().equalsIgnoreCase("BS000001")){
									storeRegDTO.setPackingSlipNo((long)1);
									storeRegDTO.setBagWeight(1.0);
									}// end of if loop
								storeRegDTO.setStockQty(workOrderOutput.get(0).getNetLength());
								storeRegDTO.setWeight(workOrderOutput.get(0).getNetWeight());
								storeRegDTO.setQcStatus("Pending");
								storeRegDTO.setQcSupervisor("");
								storeRegDTO.setRejectStatus("");
								StoreRegister storeReg=storeRegDTO.getStoreRegister();
								createdStoreReg=storeRegisterService.create(storeReg);//update StoreRegister
								if(createdStoreReg!=null)
									updateStoreReg=true;
						}//end of if(updateStockInResult==true && storeRegExistList.size()==0) loop
					}//end of if(updateSoItemResult==true) loop
	      }//end of if(orderDetailId!=null && updateWorkOrderOutput==true) loop
			}// end of if(workOrderOutput.get(0).getGrossWeight()>workOrderOutput.get(0).getTareWeight()) loop
			}//end of if(workOrderOutput.size()>0)
			return new StatusResponse(updateStoreReg);

}
	  /** Method to fetch Semifinished stock out for JQ grid 
	   * @param  woNo,filterspageNumber,rowsPerPage,sortColName, sortOrder
	   * @return JqgridResponse .
	   */	
	@RequestMapping(value="/woStockOutRecords/{woNo}", produces="application/json", method=RequestMethod.POST)
	public @ResponseBody 
	JqgridResponse<SemifinishedStockOutDTO> woStockOutRecords(
			@PathVariable("woNo") String woNo,
			@RequestParam(value="filters", required=false) String filters,
			@RequestParam(value = "page", required = false) Integer pageNumber,
			@RequestParam(value = "rows", required = false) Integer rowsPerPage,
			@RequestParam(value = "sidx", required = false) String sortColName,
			@RequestParam(value = "sord", required = false, defaultValue = "asc") String sortOrder) {
		   //JQ grid sorting column name  
	    	if(sortColName.equalsIgnoreCase("itemDescription")){
			sortColName="salesOrderItem.items.itemDescription";
	    	}
	    	if(sortColName.equalsIgnoreCase("workOrderNo")){
				sortColName="productionWorkOrders.workOrderNo";
		    }	
			if(sortColName.equalsIgnoreCase("workOrderNo")){
				sortColName="productionWorkOrder.workOrderNo";
			}
			if(sortColName.equalsIgnoreCase("itemDescription")){
				sortColName="salesOrderItem.items.itemDescription";
			}
			String confrimStatus="Yes";	
	    	/*Method to fetch JQGRID paged records of Semifinished StockOut items based on woNo and confrimStatus*/
			Page<SemifinishedStockOut> semiFimishedStockOutOutput = semifinishedStockOutService.getConfirmedSemifinishedStockOut(woNo,confrimStatus, pageNumber -1, rowsPerPage, sortColName, sortOrder);
			/*Intialize JQ grid response of type SemifinishedStockOutDTO*/	
			JqgridResponse<SemifinishedStockOutDTO> response = new JqgridResponse<SemifinishedStockOutDTO>();
			if(semiFimishedStockOutOutput.getContent().size()>0){
		    /*Method to set Semifinished StockOut items list to SemifinishedStockOutDTO*/
			List<SemifinishedStockOutDTO> semifinishedStockOutDTOs = convertToSemifinishedStockOut(semiFimishedStockOutOutput.getContent());
			response.setRows(semifinishedStockOutDTOs);
			response.setRecords(Long.valueOf(semiFimishedStockOutOutput.getTotalElements()).toString());
			response.setTotal(Long.valueOf(semiFimishedStockOutOutput.getTotalPages()).toString());
			response.setPage(Integer.valueOf(semiFimishedStockOutOutput.getNumber()+1).toString());
			}//end of if loop
			return response;
	}
	  /** Method to set SemifinishedStockOutDTO with fetch result
	   * @param  woNo,List<SemifinishedStockOut>
	   * @return JqgridResponse .
	   */	
	private List<SemifinishedStockOutDTO> convertToSemifinishedStockOut(
			List<SemifinishedStockOut> semiFinishedStockOuts) {
		List<SemifinishedStockOutDTO> semifinishedStockOutDTOs = new ArrayList<>();
		for(SemifinishedStockOut semifinishedStockOut : semiFinishedStockOuts) {
			SemifinishedStockOutDTO semifinishedStockOutDTO = new SemifinishedStockOutDTO();
			semifinishedStockOutDTO.setSemifinishedStockOutId(semifinishedStockOut.getSemifinishedStockOutId());
			semifinishedStockOutDTO.setWorkOrderNo(semifinishedStockOut.getProductionWorkOrders().getWorkOrderNo());
			semifinishedStockOutDTO.setStockOutQty(semifinishedStockOut.getStockOutQty());
			semifinishedStockOutDTO.setBundleId(semifinishedStockOut.getBundleId());
			semifinishedStockOutDTO.setItemCode(semifinishedStockOut.getItemCode());
			semifinishedStockOutDTO.setItemDescription(semifinishedStockOut.getSalesOrderItem().getItem().getItemDescription());
			semifinishedStockOutDTO.setWeight(semifinishedStockOut.getWeight());
			semifinishedStockOutDTOs.add(semifinishedStockOutDTO);
		}//end of for loop
		return semifinishedStockOutDTOs;
	}
	 /** Method to generate BUNCHING JOB CARD report
	   * @param  workOrderNo
	   * @return void .
	   */	
	@RequestMapping(value = "/bunchingJobCardReport", produces = "application/pdf", method = RequestMethod.GET)
	
	public void BunchingJobCardReport(@RequestParam(value = "workOrderNo", required = true) String workOrderNo,javax.servlet.http.HttpServletResponse response) throws IOException, InterruptedException{
		
		if(workOrderNo!=null && workOrderNo!=""){
		InputStream inputStream = getClass().getClassLoader().getResourceAsStream("/org/balajicables/salesmanager/report/BunchingJobCardReport.jrxml");
    	
    	 Map<String, Object> hm= new HashMap<String, Object>();
         hm.put("WORK ORDER NO", workOrderNo);//set report param
         byte[] content = ReportGenerator.newReportGenerator(inputStream,hm);//call report generator method
	       
	    response.setContentType("application/pdf");
		response.setHeader("Content-Disposition", "attachment;filename=" + "BunchingJobCard"+workOrderNo+".pdf");
		response.setContentLength(content.length);
	    FileCopyUtils.copy(content, response.getOutputStream());
		}//end of if loop
   }
	 /** Method to generate semiFinishedLabelreport
	   * @param  woOutPutId
	   * @return void
	   */	
	@RequestMapping(value = "/semiFinishedLabelReport", produces = "application/pdf", method = RequestMethod.GET)
	public void SemiFinishedLabelReport(@RequestParam(value = "woId", required = true) String woOutPutId,javax.servlet.http.HttpServletResponse response)	throws IOException, InterruptedException {
		
		
		if(woOutPutId!=null && woOutPutId!=""){
		InputStream inputStream = getClass().getClassLoader().getResourceAsStream("/org/balajicables/salesmanager/report/SemiFinishedLabelReport.jrxml");
		
		Map<String, Object> hm = new HashMap<String, Object>();
		hm.put("WO_OUTPUT_ID", Integer.parseInt(woOutPutId));//set report param
		byte[] content = ReportGenerator.newReportGenerator(inputStream, hm);//call report generator method
		
		response.setContentType("application/pdf");
		response.setHeader("Content-Disposition", "attachment;filename="+ "SemiFinishedLabel" + woOutPutId + ".pdf");//Bunching Jobcard Report file name
		response.setContentLength(content.length);
		
		FileCopyUtils.copy(content, response.getOutputStream());
		}
	}	
}