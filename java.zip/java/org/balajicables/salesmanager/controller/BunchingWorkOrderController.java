package org.balajicables.salesmanager.controller;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
import javax.annotation.Resource;
import org.balajicables.salesmanager.CustomUser;
import org.balajicables.salesmanager.common.JqgridResponse;
import org.balajicables.salesmanager.common.SaveProductionWorkOrder;
import org.balajicables.salesmanager.common.StatusResponse;
import org.balajicables.salesmanager.dto.BunchingWOInputDTO;
import org.balajicables.salesmanager.dto.OrderDTO;
import org.balajicables.salesmanager.dto.SalesOrderItemsDTO;
import org.balajicables.salesmanager.model.BunchingWOInput;
import org.balajicables.salesmanager.model.Customer;
import org.balajicables.salesmanager.model.Item;
import org.balajicables.salesmanager.model.OrderStatus;
import org.balajicables.salesmanager.model.ProductionProcess;
import org.balajicables.salesmanager.model.ProductionWorkOrder;
import org.balajicables.salesmanager.model.SalesOrder;
import org.balajicables.salesmanager.model.SalesOrderItem;
import org.balajicables.salesmanager.repository.BunchingWOInputRepository;
import org.balajicables.salesmanager.service.BunchingWOInputService;
import org.balajicables.salesmanager.service.CustomerService;
import org.balajicables.salesmanager.service.ItemService;
import org.balajicables.salesmanager.service.MachineService;
import org.balajicables.salesmanager.service.OrderDetailsService;
import org.balajicables.salesmanager.service.OrderService;
import org.balajicables.salesmanager.service.OrderStatusService;
import org.balajicables.salesmanager.service.ProductTypeService;
import org.balajicables.salesmanager.service.ProductionProcessService;
import org.balajicables.salesmanager.service.ProductionWorkOrderService;
import org.joda.time.DateTime;
import org.springframework.data.domain.Page;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
/**
* This class demonstrates Bunching WorkOrder Process.
* @author Abin Sam
*/
@Controller
@RequestMapping("/createBunchingWorkOrder")
public class BunchingWorkOrderController {

	@Resource
	BunchingWOInputRepository bunchingWorkOrderRepository;

	@Resource
	private MachineService machineService;

	@Resource
	private ProductionWorkOrderService prodWorkOrderService;

	@Resource
	private BunchingWOInputService bunchingWOInputService;
	
	@Resource
	private BunchingWOInputRepository bunchingWOInputRepository;
	
	@Resource
	private ProductionWorkOrderService productionWorkOrderService;
	
	@Resource
	private OrderStatusService orderStatusService;
	
	@Resource
	private OrderService orderService;

	@Resource
	private CustomerService customerService;

	@Resource
	private OrderDetailsService orderDetailsService;
	
	@Resource
	private ProductTypeService productTypeService;
	
	@Resource
	private ItemService itemService;
	
	@Resource
	private ProductionProcessService productionProcessService;
	/**
	   * This method returns bunchingWorkOrder.jsp.
	   * Fetch all customers and workorder number based on process type
	   * @param Model to set the attribute.
	   * @return bunchingWorkOrder.jsp.
	   */
	@RequestMapping
	public String getCreateWoPage(Model model) {
		/*Method to fetch all customers and also*/
		List<Customer> customers = customerService.findAll();
		model.addAttribute("customers", customers);
		
		String processType = "Bunching";
		String status="Created";
		/*Initializing empty arraylist of type string*/
		ArrayList<String> woNosList = new ArrayList<>();
		/*Method to fetch bunching work order numbers of Created status*/
		List<ProductionWorkOrder> productionWorkOrders = productionWorkOrderService.findByProcessTypeAndStatus(processType, status);
		for (int iterator = 0; iterator < productionWorkOrders.size(); iterator++) {
			if (productionWorkOrders.get(iterator).getWorkOrderNo() != null	&& productionWorkOrders.get(iterator).getWorkOrderNo() != "") {
				String woNo = productionWorkOrders.get(iterator).getWorkOrderNo();
				if (!woNosList.contains(woNo)) {
					woNosList.add(woNo);
				}//end of inner if condition
			}//end of outer if condition
		}//end of for loop
		Collections.sort(woNosList,Collections.reverseOrder());//sorts the list of Bunching Work Order numbers into descending order
		model.addAttribute("workOrderNo",woNosList);//set bunching work order nos to model attribute
		model.addAttribute("machine",machineService.findProcessMachineNo(processType));//set bunching machine number to model attribute
		return "bunchingWorkOrder";
	}
	/**
	   * Fetch product types based on the processType 
	   * @param processType
	   * @return productTypeList
	   */
	@RequestMapping(value="/fetchProductType", produces="application/json", method=RequestMethod.GET)
	public @ResponseBody List<String> fetchProductType
	(@RequestParam("processType") String processType){
		/*Method to fetch product type list based on process type*/
		List<String>productTypeList=productTypeService.findProductTypeByProcessType(processType);
		return productTypeList;
		
	}
	/**
	   * Fetch number of copper strands based on the product type
	   * @param productType
	   * @return numberOfCopperStrandsList
	   */
	@RequestMapping(value="/fetchCuStrands", produces="application/json", method=RequestMethod.GET)
	public @ResponseBody ArrayList<String> fetchCuStrands
	(@RequestParam("productType") String productType){
		/*Method to fetch number of copper strand list based on product type*/
		List<Item> itemList =itemService.getItemProductType(productType);	
		/*Initializing empty arraylist of type string*/
		ArrayList<String> numberOfCopperStrandsList = new ArrayList<>();
		for (int iterator = 0; iterator < itemList.size(); iterator++) {
			if (itemList.get(iterator).getNumberOfCopperStrands() != null) {
				String numberOfCopperStrands = itemList.get(iterator).getNumberOfCopperStrands().toString();
				if (!numberOfCopperStrandsList.contains(numberOfCopperStrands)) {
					numberOfCopperStrandsList.add(numberOfCopperStrands);
				}//end of if (!numberOfCopperStrandsList.contains(numberOfCopperStrands))
			}//end of if (itemList.get(iterator).getNumberOfCopperStrands() != null) 
		}//end of for loop	
		return numberOfCopperStrandsList;
	}
	/**
	   * Fetch copper diameter based on the product type and number of copper strands
	   * @param productType,numberOfCopperStrand
	   * @return cuDiamtereList
	   */
	@RequestMapping(value = "/getCuDiamter", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	ArrayList<String> getCuDiameter(
			@RequestParam("numberOfCopperStrand") Integer numberOfCopperStrand, 
			@RequestParam("productType") String productType) {
		/*Initializing empty arraylist of type string*/
		ArrayList<String> cuDiamtereList = new ArrayList<>();
		/*Method to fetch copper diameter list based on product type and number of copper strands*/
		List<Item>itemList=itemService.findByProductTypeAndNumberOfCuStrands(productType,numberOfCopperStrand);

		for (int iterator = 0; iterator < itemList.size(); iterator++) {
			if(itemList.get(iterator).getCopperStrandDiameter().getCopperkey()!=null && itemList.get(iterator).getCopperStrandDiameter().getCopperkey()!=""){
			String cuDiameter = itemList.get(iterator).getCopperStrandDiameter().getCopperkey();
			if (!cuDiamtereList.contains(cuDiameter)) {
				cuDiamtereList.add(cuDiameter);
			}//end of if (!cuDiamtereList.contains(cuDiameter)) 
			}//end of outer if loop
		}//end of for loop  
		return cuDiamtereList;
	}
	/**
	   * Fetch lay length based on the number of copper strands and copper diameter
	   * @param productType,numberOfCopperStrand,Model model
	   * @return layLengthList
	   */
	@RequestMapping(value = "/getLayLength", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	ArrayList<String> getLayLength(
			@RequestParam(required = false) Integer numberOfCopperStrandsSelect,
			@RequestParam(required = false) String copperDiameterSelect, Model model) {
		/*Initializing empty arraylist of type string*/
		ArrayList<String> layLengthList = new ArrayList<>();
		/*Method to fetch lay length list based on number of copper strands and copper diameter*/
		List<Item>itemList=itemService.findByItemTypeAndNumberOfCuStrandsAndCopperStrandDia("Bunching",numberOfCopperStrandsSelect,copperDiameterSelect);

		for (int iterator = 0; iterator < itemList.size(); iterator++) {
			if(itemList.get(iterator).getLayLength()!=null){
			String layLength = itemList.get(iterator).getLayLength().toString();
			if (!layLengthList.contains(layLength)) {
				layLengthList.add(layLength);
			}//end of inner if loop
			}//endof outer ifloop
		}//end of for loop
		return layLengthList;
	}
	/**
	   * Fetch bunching work order numbers list based on process type and status
	   * @return bunchingWoNo
	   */
	@RequestMapping(value = "/getBunchingWoNos", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	List<String> getMwdWoNos() {
		String processType = "Bunching";
		String status="Created";
		/*Initializing empty arraylist of type string*/
		ArrayList<String>bunchingWoNo=new ArrayList<String>();
		/*Method to fetch bunching work order list based on processType and status*/
		List<ProductionWorkOrder>bunchingWoNoList=productionWorkOrderService.findByProcessTypeAndStatus(processType, status);
		for (int iterator = 0; iterator < bunchingWoNoList.size(); iterator++) {
			if(bunchingWoNoList.get(iterator).getWorkOrderNo()!=null && bunchingWoNoList.get(iterator).getWorkOrderNo()!="")
				bunchingWoNo.add(bunchingWoNoList.get(iterator).getWorkOrderNo());
		}//end of for loop
		/*sorts the list of RBD Work Order numbers into descending order*/
    	Collections.sort(bunchingWoNo,Collections.reverseOrder());
		return bunchingWoNo;
	}
	/**
	   * Method to create bunching work order
	   * @RequestParam bunchingStartDate,bunchingCompletionDate,bunchingWoMachineNoSelect,bunchingWorkOrderNoTag
	   * @return bunchingWoNo
	   */
	@RequestMapping(value = "/createProdWO", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	List<String> createProdWO(@RequestParam String bunchingStartDate,
			@RequestParam String bunchingCompletionDate,
			@RequestParam Long bunchingWoMachineNoSelect,
			@RequestParam(required = false) String bunchingWorkOrderNoTag) {
		/*fetch user name based on login user*/
		CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();;
		String userName = user.getFirstName()+" "+user.getLastName();
		/*Initializing empty list of type string*/
		List<String> newCreatedList = new ArrayList<String>();
		if (bunchingWorkOrderNoTag.isEmpty() || bunchingWorkOrderNoTag == "") {

			String newWorkOrderNo;
			String yearNo = String.valueOf(new DateTime().getYear() % 1000);
			String monthNo = "";
			if (new DateTime().getMonthOfYear() > 9)
				monthNo = String.valueOf(new DateTime().getMonthOfYear());
			else
				monthNo = "0" + String.valueOf(new DateTime().getMonthOfYear());

			String processType = "Bunching";
			/*Method to fetch existing bunching work order numbers based on process type*/
			List<ProductionWorkOrder> existWorkOrderList = prodWorkOrderService.fetchLatestWorkOrder(processType);

			String existWorkOrderNo = "";
			if (existWorkOrderList.size() > 0)
				existWorkOrderNo = existWorkOrderList.get(0).getWorkOrderNo();

			if (!existWorkOrderNo.isEmpty()) {
				String existWOYear = existWorkOrderNo.substring(1, 3);
				String existWOMonth = existWorkOrderNo.substring(3, 5);
				String existWONoParse = existWorkOrderNo.substring(1, 8);
				if ((yearNo.equalsIgnoreCase(existWOYear))
						&& (monthNo.equalsIgnoreCase(existWOMonth))) {
					int workOrderInt = Integer.parseInt(existWONoParse) + 1;
					newWorkOrderNo = "B" + String.valueOf(workOrderInt);
				} else {
					newWorkOrderNo = "B" + yearNo + monthNo + "001";
				}
			}// end of if loop of checking existing sales no
			else {
				newWorkOrderNo = "B" + yearNo + monthNo + "001";
			}
			/*Method to fetch process Id based on process type*/
			List<ProductionProcess>pdnProcess=productionProcessService.findByProcessType("Bunching");
			Integer processId = pdnProcess.get(0).getProcessId();
			List<ProductionWorkOrder>pdnWoList=productionWorkOrderService.findByProductionWorkOrderNo(newWorkOrderNo);
			if(pdnWoList.size()==0){
			/*Creating a new instance of class SaveProductionWorkOrder*/	
			SaveProductionWorkOrder saveProductionWorkOrder = new SaveProductionWorkOrder();
            /*Method to save bunching work order number in ProductionWorkOrder */
			ProductionWorkOrder prdnWorkOrder = saveProductionWorkOrder.saveProductionWorkOrder(newWorkOrderNo,	bunchingWoMachineNoSelect, userName,bunchingStartDate, bunchingCompletionDate,processId);
			/*Method to create Bunching work order*/
			ProductionWorkOrder createdPdnWorkOrder = prodWorkOrderService.create(prdnWorkOrder);
			if (createdPdnWorkOrder != null) {
				newCreatedList.add(prdnWorkOrder.getWorkOrderNo());
     			bunchingWorkOrderNoTag = createdPdnWorkOrder.getWorkOrderNo();
			}//end of if (createdPdnWorkOrder != null) 
			}//end of if(pdnWoList.size()==0)
		}//end of if (bunchingWorkOrderNoTag.isEmpty() || bunchingWorkOrderNoTag == "") 
		return newCreatedList;
	}
	/**
	   * Method to save bunching work order input
	   * @param idsSelected,workOrderNo
	   * @return workOrderList
	   */
	@RequestMapping(value="/saveBunchingWorkOrderInput", produces="application/json" ,method = RequestMethod.POST)
	public @ResponseBody
	List<String> saveWoItems(
   	 @RequestParam(value = "idsOfSelectedRows[]", required = false) Long[] idsSelected,
   	 @RequestParam(value="workOrderNo",required=true) String workOrderNo) {
		/*Initializing empty list of type string*/
		List<String> workOrderList=new ArrayList<String>();
        Boolean soItemQtyUpdate=false;
        Boolean result=false;
		/*fetch user name based on login user*/ 
		CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();;
		String userName = user.getFirstName()+" "+user.getLastName();
	
		for(int i=0;i<idsSelected.length;i++){
			List<SalesOrderItem> salesOrderItem=orderDetailsService.findById(idsSelected[i]);
			if(salesOrderItem.size()>0){
	
				Double newNetLength=0.0;
				Double newQty=0.0;
				newQty=salesOrderItem.get(0).getWoQty();
				Double noOfCuStrand=(double)salesOrderItem.get(0).getItem().getNumberOfCopperStrands();
				Double stranddDiameter=Double.valueOf(salesOrderItem.get(0).getItem().getCopperStrandDiameter().getCopperkey())/1000;
				Double roundUpWeight=noOfCuStrand*stranddDiameter*stranddDiameter*0.6985*1.015;
				Long netL=(long) ((newQty*100)/Double.valueOf(roundUpWeight));
				newNetLength=Double.valueOf(netL);
			
				Integer bundleSize=salesOrderItem.get(0).getBundleSize();
				Long noOfDrum=(long) 0;
			
				if(bundleSize!=0)
				 noOfDrum=(long)Math.ceil((newQty/(double)bundleSize));
				Double lengthPerDrum=0.0;
				if(noOfDrum!=0)
				lengthPerDrum=Double.valueOf((long)(newNetLength/noOfDrum));
			
				BunchingWOInputDTO bunchingWoInputDTO = new BunchingWOInputDTO();
				bunchingWoInputDTO.setWorkOrderNo(workOrderNo);
				bunchingWoInputDTO.setOrderDetailId(salesOrderItem.get(0).getOrderDetailId());
				bunchingWoInputDTO.setSize(salesOrderItem.get(0).getItem().getInputSize());
				bunchingWoInputDTO.setNetLength(newNetLength);
				bunchingWoInputDTO.setLayLength(salesOrderItem.get(0).getItem().getLayLength());
				bunchingWoInputDTO.setLengthPerDrum(lengthPerDrum);
				bunchingWoInputDTO.setNoOfDrums(noOfDrum);
				bunchingWoInputDTO.setCustomerName(salesOrderItem.get(0).getOrder().getCustomer().getCustomerName());
				bunchingWoInputDTO.setCreatedBy(userName);
				bunchingWoInputDTO.setUpdatedBy(userName);
				bunchingWoInputDTO.setStatus("Pending");
				bunchingWoInputDTO.setTotalQty(newQty);
				bunchingWoInputDTO.setSelectStatus("No");
				BunchingWOInput bunchingWOsInput=bunchingWoInputDTO.getBunchingWOInput();
				BunchingWOInput createdBunchingWoInput=bunchingWOInputService.create(bunchingWOsInput);
				if(createdBunchingWoInput!=null)
					result=true;

		   if(result==true ){
			   Boolean balQtyresult = false;
		       Boolean pdnQtyResult=false;
		       Double workOrderQty=salesOrderItem.get(0).getWoQty();
		       Double balanceQuantity=salesOrderItem.get(0).getBalanceQty();
		       Double pdnQuantity=salesOrderItem.get(0).getProductionQty();
		       Double totalQty=salesOrderItem.get(0).getQuantity();
		       Double dispatchedQty=salesOrderItem.get(0).getDispatchedQty();
		       Double storeQty=salesOrderItem.get(0).getCompletedQty();
		       Long salesOrderItemId=salesOrderItem.get(0).getOrderDetailId();
		    if(workOrderQty<=balanceQuantity && workOrderQty!=null ){
				Double newPdnQty=pdnQuantity+workOrderQty;
		  		Double newBalanceQty=totalQty-(newPdnQty+dispatchedQty+storeQty);
                if(newBalanceQty<0)
                	newBalanceQty=0.0;
				balQtyresult=orderDetailsService.updateBalQty(salesOrderItemId,newBalanceQty,workOrderQty);
				pdnQtyResult=orderDetailsService.updatePdnQty(salesOrderItemId,newPdnQty,workOrderQty);
				if(balQtyresult==true && pdnQtyResult==true)
					soItemQtyUpdate=true;
			}//end of   if(workOrderQty<=balanceQuantity && workOrderQty!=null )
		    if(soItemQtyUpdate==true)
		    	workOrderList.add(workOrderNo);
			}// created if loop
			}//end of if(salesOrderItem.size()>0)
		}//end of for loop
		return workOrderList;
	}
	 /**
	   * crud functionality of bunching work order 
	   * @param id,oper,workOrderNo,bunchingSize,noOfDrums,lengthPerDrum,layLength,customerName
	   * @return StatusResponse
	   */
	@RequestMapping(value = "/crud", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	StatusResponse crud(@RequestParam Long id,
			@RequestParam String oper,
			@RequestParam(required = false) String workOrderNo,
			@RequestParam(required = false) String bunchingSize,
			@RequestParam(required = false) String noOfDrums,
			@RequestParam(required = false) String lengthPerDrum,
			@RequestParam(required = false) Integer layLength,
			@RequestParam(required = false) String customerName) {
		Boolean updateBunchingWoInput=false;
		/*fetch user name based on login user*/ 
		CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();;
		String userName = user.getFirstName()+" "+user.getLastName();
		
		BunchingWOInput bunchingWorkOrder=null;
		List<BunchingWOInput>bunchingList=bunchingWOInputService.findById(id);
		 boolean match=false;
		 boolean drumNoMatch=false;
		 Double newWoQtyKg=null;
		 Long netTotalLengthValue=null;
		if(oper.equalsIgnoreCase("edit")){
			String decimalPattern = "((-|\\+)?[0-9]+(\\.[0-9]+)?)+";  
			 match = Pattern.matches(decimalPattern, lengthPerDrum);
			  if (noOfDrums.matches("[0-9]+"))
				  drumNoMatch=true;
			if(match==true && drumNoMatch==true){
			Double newLengthPerDrum=Double.valueOf(lengthPerDrum);
			Long drumCount=Long.valueOf(noOfDrums);
		    netTotalLengthValue=(newLengthPerDrum.longValue())*drumCount;
		   
		    Double noOfCuStrand=(double)bunchingList.get(0).getSalesOrderItem().getItem().getNumberOfCopperStrands();
			Double stranddDiameter=Double.valueOf(bunchingList.get(0).getSalesOrderItem().getItem().getCopperStrandDiameter().getCopperkey())/1000;
			Double roundUpWeight=(noOfCuStrand*stranddDiameter*stranddDiameter*0.6985*1.015)/100;
			Double qty = Double.valueOf(netTotalLengthValue)*roundUpWeight;
			Long woQtyKg= Math.round(qty);
			newWoQtyKg=Double.valueOf(woQtyKg);
		
			BunchingWOInputDTO bunchingWoInputDTO=null;
		    if(bunchingList.size()>0){
		    	bunchingWoInputDTO=new BunchingWOInputDTO();
		    	bunchingWoInputDTO.setBunchWoInputId(bunchingList.get(0).getBunchWoInputId());
				bunchingWoInputDTO.setWorkOrderNo(bunchingList.get(0).getProductionWorkOrder().getWorkOrderNo());
				bunchingWoInputDTO.setOrderDetailId(bunchingList.get(0).getSalesOrderItem().getOrderDetailId());
				bunchingWoInputDTO.setSize(bunchingList.get(0).getSize());
				bunchingWoInputDTO.setNetLength((double)netTotalLengthValue);
				bunchingWoInputDTO.setLayLength(bunchingList.get(0).getLayLength());
				bunchingWoInputDTO.setLengthPerDrum(newLengthPerDrum);
				bunchingWoInputDTO.setNoOfDrums(drumCount);
				bunchingWoInputDTO.setCustomerName(bunchingList.get(0).getCustomerName());
				bunchingWoInputDTO.setCreatedBy(bunchingList.get(0).getCreatedBy());
				bunchingWoInputDTO.setUpdatedBy(userName);
				bunchingWoInputDTO.setStatus(bunchingList.get(0).getStatus());
				bunchingWoInputDTO.setTotalQty(newWoQtyKg);
				bunchingWoInputDTO.setSelectStatus(bunchingList.get(0).getSelectStatus());
			 }//end of  if(bunchingList.size()>0)
			bunchingWorkOrder=bunchingWoInputDTO.getBunchingWOInput();
	      }//end of if(match==true && drumNoMatch==true)
		}//end of if(oper.equalsIgnoreCase("edit"))
		switch (oper) {
		case "edit":
			if(match==true && drumNoMatch==true){
			updateBunchingWoInput = bunchingWOInputService.update(bunchingWorkOrder);
		    Long salesOrderItemId=bunchingList.get(0).getSalesOrderItem().getOrderDetailId();
		    String orderId=bunchingList.get(0).getSalesOrderItem().getOrder().getOrderId();
		    Double totalQty=bunchingList.get(0).getSalesOrderItem().getQuantity();
		    Double pdnQty=bunchingList.get(0).getSalesOrderItem().getProductionQty();
		    Double oldWoQtyLength=bunchingList.get(0).getNetLength();
		    Double newWoQtyLength=(double)netTotalLengthValue;
		    Double newWoQty=newWoQtyKg;
		    Double oldWoQty=bunchingList.get(0).getTotalQty();
		    Double newBalQty=0.0;
		    Double newPdnQty=0.0;
		    Double newTotalQty=0.0;

		    if(orderId.equalsIgnoreCase("BS000001")){
		       	newTotalQty=totalQty-oldWoQtyLength+newWoQtyLength;
		    	newPdnQty=pdnQty-oldWoQtyLength+newWoQtyLength;
	
		    }else{
		      	newTotalQty=totalQty;
		    	newPdnQty=pdnQty-oldWoQty+newWoQty;
		    	newBalQty=newTotalQty-(newPdnQty+bunchingList.get(0).getSalesOrderItem().getCompletedQty()+bunchingList.get(0).getSalesOrderItem().getDispatchedQty());
	
		    }//end of if else loop
		    updateBunchingWoInput=orderDetailsService.updateBalPdnQty(salesOrderItemId,newTotalQty,newBalQty,newPdnQty);

			}//end of if(match==true && drumNoMatch==true)
			break;
		case "del":
		        Long salesOrderItemId=bunchingList.get(0).getSalesOrderItem().getOrderDetailId();
 			    String orderId=bunchingList.get(0).getSalesOrderItem().getOrder().getOrderId();
			    Double balQty=bunchingList.get(0).getSalesOrderItem().getBalanceQty();
			    Double pdnQty=bunchingList.get(0).getSalesOrderItem().getProductionQty();
			    Double woQtyLength=bunchingList.get(0).getNetLength();
			    Double totalQty=bunchingList.get(0).getSalesOrderItem().getQuantity();
			    Double woQty=bunchingList.get(0).getTotalQty();
			    Double newBalQty=0.0;
			    Double newPdnQty=0.0;
			    Double newTotalQty=0.0;
			    if(orderId.equalsIgnoreCase("BS000001")){
			    	newBalQty=0.0;
			    	if(woQtyLength<totalQty){
			    		newTotalQty=totalQty-woQtyLength;
					  	newPdnQty=pdnQty-woQtyLength;
				     }
			    }else{
			    	newTotalQty=totalQty;;
			    	newBalQty=balQty+woQty;
			    	if(pdnQty>woQty)
			    		newPdnQty=pdnQty-woQty;
			    }//end of if else loop
			    bunchingWOInputRepository.delete(id);
			    updateBunchingWoInput=orderDetailsService.updateBalPdnQty(salesOrderItemId,newTotalQty,newBalQty,newPdnQty);
		break;
		}//end of switch cases
		return new StatusResponse(updateBunchingWoInput);
		}
	/** Method to fetch bunching work order input records and set to grid
	   * @param workOrderNo,search,filters,pageNumber,rowsPerPage,sortColName,sortOrder
	   * @return JqgridResponse<WorkOrderOutputDTO>   .
	   */
	@RequestMapping(value = "/records/{woNo}", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	JqgridResponse<BunchingWOInputDTO> records(
			@PathVariable("woNo") String workOrderNo,
			@RequestParam("_search") Boolean search,
			@RequestParam(value = "filters", required = false) String filters,
			@RequestParam(value = "page", required = false) Integer pageNumber,
			@RequestParam(value = "rows", required = false) Integer rowsPerPage,
			@RequestParam(value = "sidx", required = false) String sortColName,
			@RequestParam(value = "sord", required = false, defaultValue = "asc") String sortOrder) {
        /*JQGrid column sorting*/
		if(sortColName.equalsIgnoreCase("customerCode")){
			sortColName="salesOrderItem.orders.customer.customerCode";
		}

		if(sortColName.equalsIgnoreCase("customerName")){
			sortColName="salesOrderItem.orders.customer.customerName";
		}
		if(sortColName.equalsIgnoreCase("customerCode")){
			sortColName="salesOrderItem.orders.customer.customerCode";
		}
        /*Method to fetch JQGRID paged records of bunching work order input based on work order no*/
		Page<BunchingWOInput> bunchingWOInput = bunchingWOInputService.getPagedOrders(workOrderNo, pageNumber - 1, rowsPerPage,
						sortColName, sortOrder);
		/*Intialize JQ grid response of type BunchingWOInputDTO*/
		JqgridResponse<BunchingWOInputDTO> response = new JqgridResponse<BunchingWOInputDTO>();
		/*Method to set Bunching work order number list to BunchingWOInputDTO*/
		List<BunchingWOInputDTO> bunchingWOInputDTOs = convertToDTO(bunchingWOInput.getContent());
		response.setRows(bunchingWOInputDTOs);
		response.setRecords(Long.valueOf(bunchingWOInput.getTotalElements()).toString());
		response.setTotal(Long.valueOf(bunchingWOInput.getTotalPages()).toString());
		response.setPage(Integer.valueOf(bunchingWOInput.getNumber() + 1).toString());
		return response;
	}
	 /**
	   * This Method to set Invoice item list to BunchingWOInputDTO
	   * @param List<BunchingWOInput> BunchingWOInput
	   * @return List<BunchingWOInputDTO> response
	   */
	private List<BunchingWOInputDTO> convertToDTO(List<BunchingWOInput> bunchingWOInputs) {
		List<BunchingWOInputDTO> bunchingWOInputDTOs = new ArrayList<>();
		for (BunchingWOInput bunchingWOInput : bunchingWOInputs) {
      	BunchingWOInputDTO bunchingWOInputDTO = new BunchingWOInputDTO();
		    bunchingWOInputDTO.setBunchWoInputId(bunchingWOInput.getBunchWoInputId());
		    bunchingWOInputDTO.setOrderDetailId(bunchingWOInput.getSalesOrderItem().getOrderDetailId());
			bunchingWOInputDTO.setWorkOrderNo(bunchingWOInput.getProductionWorkOrder().getWorkOrderNo());
    		bunchingWOInputDTO.setSize(bunchingWOInput.getSize());
			bunchingWOInputDTO.setNoOfDrums(bunchingWOInput.getNoOfDrums());
			bunchingWOInputDTO.setLengthPerDrum(bunchingWOInput.getLengthPerDrum());
			bunchingWOInputDTO.setNetLength(bunchingWOInput.getNetLength());
			bunchingWOInputDTO.setLayLength(bunchingWOInput.getLayLength());
			bunchingWOInputDTO.setCustomerCode(bunchingWOInput.getSalesOrderItem().getOrders().getCustomer().getCustomerCode());
			bunchingWOInputDTO.setTotalQty(bunchingWOInput.getTotalQty());
			bunchingWOInputDTO.setSelectStatus(bunchingWOInput.getSelectStatus());
			bunchingWOInputDTOs.add(bunchingWOInputDTO);
		}//end of for loop
		return bunchingWOInputDTOs;

	}
	 /**
	   * This Method to create bunching work order number
	   * @param bunchingStartDate,bunchingCompletionDate,bunchingWoMachineNoSelect,numberOfCopperStrandsSelect,copperDiameterSelect,
	   * layLengthSelect,productType,noOfDrums,lengthPerDrum,bunchingWorkOrderNoTag
	   * @return newCreatedList
	   */
	@RequestMapping(value = "/createBunchingWo", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	List<String>  createBunchingWo(
			@RequestParam String bunchingStartDate,
			@RequestParam String bunchingCompletionDate,
			@RequestParam Long bunchingWoMachineNoSelect,
			@RequestParam(required = false) Integer numberOfCopperStrandsSelect,
			@RequestParam(required = false) String copperDiameterSelect,
			@RequestParam(required = false) Integer layLengthSelect,
			@RequestParam(required = false) String productType,
			@RequestParam(required = false) Long noOfDrums,
			@RequestParam(required = false) Double lengthPerDrum,
			@RequestParam(required = false) String bunchingWorkOrderNoTag) {
		DecimalFormat oneDForm=new DecimalFormat("0.0");
		/*fetch user name based on login user*/ 
		CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();;
		String userName = user.getFirstName()+" "+user.getLastName();
		
		Double netLength=lengthPerDrum*noOfDrums;
		/*Initialization of empty list of type String*/
		List<String> newCreatedList = new ArrayList<String>();
		/*Method to get Item list*/
		List<Item> itemIdList=itemService.findByCuDiameterAndCuStrandAndLayLengthAndProductType(copperDiameterSelect,numberOfCopperStrandsSelect,layLengthSelect,productType);
		
		if(itemIdList.size()>0){
		String itemCode=itemIdList.get(0).getItemCode();
		String bunchingSizeSelect=itemIdList.get(0).getInputSize();
	
		Long itemId=itemIdList.get(0).getItemId();
		Integer layLengthValue=itemIdList.get(0).getLayLength();
		Double noOfCuStrand=(double)itemIdList.get(0).getNumberOfCopperStrands();
		Double stranddDiameter=Double.valueOf(itemIdList.get(0).getCopperStrandDiameter().getCopperkey())/1000;
		Double roundUpWeight=noOfCuStrand*stranddDiameter*stranddDiameter*0.6985*1.015;
		String weightVal=oneDForm.format((Double.valueOf(roundUpWeight)/100)*netLength);
	    Double netQuantity=Double.valueOf(weightVal);
			
		if (bunchingWorkOrderNoTag.isEmpty() || bunchingWorkOrderNoTag == "") {
			String newWorkOrderNo;
			String yearNo = String.valueOf(new DateTime().getYear() % 1000);
			String monthNo = "";
			if (new DateTime().getMonthOfYear() > 9)
				monthNo = String.valueOf(new DateTime().getMonthOfYear());
			else
				monthNo = "0" + String.valueOf(new DateTime().getMonthOfYear());

			String processType = "Bunching";
			List<ProductionWorkOrder> existWorkOrderList = prodWorkOrderService.fetchLatestWorkOrder(processType);
            List<ProductionProcess>pdnProcessList=productionProcessService.findByProcessType(processType);
			String existWorkOrderNo = "";
			if (existWorkOrderList.size() > 0)
				existWorkOrderNo = existWorkOrderList.get(0).getWorkOrderNo();

			if (!existWorkOrderNo.isEmpty()) {
				String existWOYear = existWorkOrderNo.substring(1, 3);
				String existWOMonth = existWorkOrderNo.substring(3, 5);
				String existWONoParse = existWorkOrderNo.substring(1, 8);
				if ((yearNo.equalsIgnoreCase(existWOYear))
						&& (monthNo.equalsIgnoreCase(existWOMonth))) {
					int workOrderInt = Integer.parseInt(existWONoParse) + 1;
					newWorkOrderNo = "B" + String.valueOf(workOrderInt);
				} else {
					newWorkOrderNo = "B" + yearNo + monthNo + "001";
				}//end of inner if else ladder
			}// end of if loop of checking existing sales no
			else {
				newWorkOrderNo = "B" + yearNo + monthNo + "001";
			}//end of if (!existWorkOrderNo.isEmpty())  else ladder
			Integer processId = pdnProcessList.get(0).getProcessId();
			List<ProductionWorkOrder>pdnWoList=productionWorkOrderService.findByProductionWorkOrderNo(newWorkOrderNo);
			if(pdnWoList.size()==0){
			
			SaveProductionWorkOrder saveProductionWorkOrder = new SaveProductionWorkOrder();
			ProductionWorkOrder prdnWorkOrder = saveProductionWorkOrder.saveProductionWorkOrder(newWorkOrderNo,	bunchingWoMachineNoSelect, userName, bunchingStartDate,bunchingCompletionDate, processId);
			ProductionWorkOrder createdPdnWorkOrder = prodWorkOrderService.create(prdnWorkOrder);
			if (createdPdnWorkOrder != null) {
				bunchingWorkOrderNoTag = createdPdnWorkOrder.getWorkOrderNo();
			}//end of if (createdPdnWorkOrder != null)

		}//end of if(pdnWoList.size()==0)
	}//end of if (bunchingWorkOrderNoTag.isEmpty() || bunchingWorkOrderNoTag == "")
		List<SalesOrderItem>soItemsList=orderDetailsService.findByOrdersOrderIdItemsItemCode("BS000001", itemCode);
		Boolean soItemResult=false;
		Long soItemsId=null;
		        List<OrderStatus> orderStatusList=orderStatusService.findByStatus("Approved");
			    Integer orderStatusId=null;
			    if(orderStatusList.size()>0)
			    orderStatusId=orderStatusList.get(0).getOrderStatusId();
			    
		    	Long customerId=(long) 1;	
		 		Boolean soResult = false;
		 	    OrderDTO orderDTO = new OrderDTO();
				orderDTO.setOrderId("BS000001");
				orderDTO.setCreatedTime("1980-01-01 00:00:00.0");
				orderDTO.setCustomerId(customerId);
				orderDTO.setOrderStatusId(orderStatusId);
				orderDTO.setCreatedBy(userName);
				orderDTO.setUpdatedBy(userName);
				orderDTO.setInputQuantity(netLength);
				orderDTO.setMailStatus("No");
				orderDTO.setLmeDetails("");
			    
				java.util.Date date= new java.util.Date();
				orderDTO.setUpdatedTime(new Timestamp(date.getTime()).toString());
			  
				SalesOrder order = orderDTO.getOrder();
				
				List<SalesOrder> salesOrders = orderService.findBySalesOrderNoId("BS000001");
				
				if(salesOrders.size()== 0){
					SalesOrder createdOrder = orderService.create(order);
					if (createdOrder != null) {
						soResult = true;
					}
				}
				else{
					soResult=orderService.update(order);
				}
						
			SalesOrderItem createdSoItem =null;	
			if(soResult==true){
			if(soItemsList.size()==0){
				SalesOrderItemsDTO soitemsDTO = new SalesOrderItemsDTO();
				
					soitemsDTO.setOrderId("BS000001");
					soitemsDTO.setItemId(itemId);
					soitemsDTO.setItemCode(itemCode);
					soitemsDTO.setQuantity(netLength);
					soitemsDTO.setBalanceQty(0.0);
					soitemsDTO.setCompletedQty(0.0);
					soitemsDTO.setProductionQty(netLength);
					soitemsDTO.setWoQty(netLength);
					soitemsDTO.setDispatchedQty(0.0);
					soitemsDTO.setBundleSize(1);
					soitemsDTO.setWeight(netQuantity);
					soitemsDTO.setPvcWeight(netQuantity);
					soitemsDTO.setUpdatedBy(userName);
					soitemsDTO.setUpdatedTime(new Timestamp(date.getTime()).toString());
					SalesOrderItem soitem = soitemsDTO.getOrderDetail();
					createdSoItem = orderDetailsService.create(soitem);
					if (createdSoItem != null) {
						soItemsId=createdSoItem.getOrderDetailId();
						soItemResult = true;
					}
			}		
		else{
			SalesOrderItemsDTO soItemsDTO=new SalesOrderItemsDTO();
			Double newTotalQty=soItemsList.get(0).getQuantity()+netLength;
			Double newPdnQty=soItemsList.get(0).getProductionQty()+netLength;
			soItemsDTO.setOrderDetailId(soItemsList.get(0).getOrderDetailId());
			soItemsDTO.setOrderId(soItemsList.get(0).getOrder().getOrderId());
			soItemsDTO.setItemId(soItemsList.get(0).getItem().getItemId());
			soItemsDTO.setItemCode(soItemsList.get(0).getItem().getItemCode());
			soItemsDTO.setQuantity(newTotalQty);
			soItemsDTO.setBalanceQty(0.0);
			soItemsDTO.setCompletedQty(soItemsList.get(0).getCompletedQty());
			soItemsDTO.setProductionQty(newPdnQty);
			soItemsDTO.setWoQty(netLength);
			soItemsDTO.setDispatchedQty(soItemsList.get(0).getDispatchedQty());
			soItemsDTO.setBundleSize(soItemsList.get(0).getBundleSize());
			soItemsDTO.setWeight(soItemsList.get(0).getWeight());
			soItemsDTO.setPvcWeight(soItemsList.get(0).getPvcWeight());
			soItemsDTO.setUpdatedBy(userName);
			SalesOrderItem soItemObj=soItemsDTO.getOrderDetail();
			Boolean updateSoItemObj=orderDetailsService.update(soItemObj);
			if(updateSoItemObj==true){
				soItemsId=soItemsList.get(0).getOrderDetailId();
				soItemResult=true;
			}
				
		}
		}
	
		if(soItemResult==true){
		BunchingWOInputDTO bunchingWoInputDTO = new BunchingWOInputDTO();
		bunchingWoInputDTO.setWorkOrderNo(bunchingWorkOrderNoTag);
		bunchingWoInputDTO.setOrderDetailId(soItemsId);
		bunchingWoInputDTO.setSize(bunchingSizeSelect);
		bunchingWoInputDTO.setNetLength(netLength);
		bunchingWoInputDTO.setCustomerName("Balaji");
		bunchingWoInputDTO.setCreatedBy(userName);
		bunchingWoInputDTO.setStatus("Pending");
		bunchingWoInputDTO.setUpdatedBy(userName);
		bunchingWoInputDTO.setTotalQty(netQuantity);
		bunchingWoInputDTO.setLayLength(layLengthValue);
		bunchingWoInputDTO.setNoOfDrums(noOfDrums);
		bunchingWoInputDTO.setLengthPerDrum(lengthPerDrum);
		bunchingWoInputDTO.setSelectStatus("No");
		
		
		BunchingWOInput bunchingWorkOrder = bunchingWoInputDTO.getBunchingWOInput();
		
		BunchingWOInput createdBunchingWo = bunchingWOInputService.create(bunchingWorkOrder);
		String woNo="";
		 if(createdBunchingWo!=null)
			 woNo= bunchingWorkOrder.getProductionWorkOrder().getWorkOrderNo();
		
		newCreatedList.add(woNo);

	 }
	}
	   return newCreatedList;

	}
	 /**
	   * This Method to fetch copper weight
	   * @param numberOfCuStrand,cuDiameter,layLength,productType
	   * @return cuWeightList
	   */
	@RequestMapping(value = "/fetchCuWeight", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	List<String>  fetchCuWeight(
			@RequestParam(required = false) Integer numberOfCuStrand,
			@RequestParam(required = false) String cuDiameter,
			@RequestParam(required = false) Integer layLength,
			@RequestParam(required = false) String productType){
	
		   List<Item> itemIdList=itemService.findByCuDiameterAndCuStrandAndLayLengthAndProductType(cuDiameter,numberOfCuStrand,layLength,productType);
	       List<String> cuWeightList = new ArrayList<String>();
	       double cuWeight=0.0;
		if(itemIdList.size()>0){
			if(itemIdList.get(0).getCopperWeight()!=null)
			cuWeight=itemIdList.get(0).getCopperWeight();
		}
		cuWeightList.add(String.valueOf(cuWeight));
		return cuWeightList;	
	}
	 /**
	   * This Method generate bunching work order report
	   * @param workOrderNo,response
	   * @return void
	   */
	@RequestMapping(value = "/bunchingWorkOrderReport", produces = "application/pdf", method = RequestMethod.GET)
	public void bunchingWorkOrderReport(@RequestParam(value = "workOrderNo", required = true) String workOrderNo,javax.servlet.http.HttpServletResponse response) throws IOException, InterruptedException{
		if(workOrderNo!=null && workOrderNo!=""){
		InputStream inputStream = getClass().getClassLoader().getResourceAsStream("/org/balajicables/salesmanager/report/BunchingWorkOrderReport.jrxml");
    
    	 Map<String, Object> hm= new HashMap<String, Object>();
         hm.put("WORK ORDER NO", workOrderNo);//set report parameter
         byte[] content = ReportGenerator.newReportGenerator(inputStream,hm);//call report generator method
        
        response.setContentType("application/pdf");	
		response.setHeader("Content-Disposition", "attachment;filename=" + "BunchingWorkOrderReport"+workOrderNo+".pdf");//Bunching WorkOrder Report file name
		response.setContentLength(content.length);
	    FileCopyUtils.copy(content, response.getOutputStream());
	} 
   }
}

