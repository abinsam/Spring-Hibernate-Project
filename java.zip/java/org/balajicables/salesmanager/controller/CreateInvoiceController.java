package org.balajicables.salesmanager.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import org.balajicables.salesmanager.CustomUser;
import org.balajicables.salesmanager.common.EnglishNumberToWords;
import org.balajicables.salesmanager.common.JqgridResponse;
import org.balajicables.salesmanager.dto.DeliveryChallanDTO;
import org.balajicables.salesmanager.dto.DeliveryChallanItemsDTO;
import org.balajicables.salesmanager.dto.InvoiceDTO;
import org.balajicables.salesmanager.dto.InvoiceItemsDTO;
import org.balajicables.salesmanager.model.Customer;
import org.balajicables.salesmanager.model.DeliveryChallan;
import org.balajicables.salesmanager.model.DeliveryChallanItems;
import org.balajicables.salesmanager.model.Invoice;
import org.balajicables.salesmanager.model.InvoiceItems;
import org.balajicables.salesmanager.model.PackingSlip;
import org.balajicables.salesmanager.model.TaxRate;
import org.balajicables.salesmanager.service.CustomerService;
import org.balajicables.salesmanager.service.DeliveryChallanItemsService;
import org.balajicables.salesmanager.service.DeliveryChallanService;
import org.balajicables.salesmanager.service.InvoiceItemsService;
import org.balajicables.salesmanager.service.InvoiceService;
import org.balajicables.salesmanager.service.PackingSlipService;
import org.balajicables.salesmanager.service.TaxRateService;
import org.balajicables.salesmanager.utils.Utility;
import org.joda.time.DateTime;
import org.springframework.data.domain.Page;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
/**
* This class demonstrates Create Invoice Process.
* @author Abin Sam
*/
@Controller
@RequestMapping("/createInvoice")

public class CreateInvoiceController {

	@Resource
	private CustomerService customerService;
	@Resource
	private TaxRateService taxRateService;
	@Resource
	private InvoiceService invoiceService;
	@Resource
	private InvoiceItemsService invoiceItemsService;
	@Resource
	private DeliveryChallanItemsService deliveryChallanItemsService;
	@Resource
	private DeliveryChallanService deliveryChallanService;
	@Resource
	private PackingSlipService packingSlipService;

	
	 /**
	   * This method returns createInvoice.jsp.
	   * Fetch all customers and Delivery ChallanNos based on month and year selected
	   * @param Model to set the attribute.
	   * @return createInvoice.jsp.
	   */
	
	@SuppressWarnings("deprecation")
	@RequestMapping
	public String getItemsPage(Model model) {
		List<Customer> customers = customerService.findAll();
		DateTime dt = new DateTime();  // current time
		int month =dt.getMonthOfYear();
		int year=dt.getYear(); 
		
	    //method to fetch all Delivery Challan Nos based on moth and year
		List<DeliveryChallan> deliveryChallanNos =deliveryChallanService.finddByStockOutsAndMonthYear(month,year);
		//set customers and delivery challan nos to model
		model.addAttribute("customers", customers);
		model.addAttribute("deliveryChallans", deliveryChallanNos);	
		
		Date date= new java.util.Date();
		String month1= String.valueOf(date.getMonth()+1);
		String day = String.valueOf(date.getDate());
		String year1= String.valueOf(date.getYear()+1900);

		String sysDate = day + '-' + month1 + '-' + year1;
		
		model.addAttribute("date", sysDate);	
	      
		return "createInvoice";
	}// end of loop method getItemsPage

	 /**
	   * This method to populate Create Invoice Grid
	   * Fetch details of Delivery Challan No
	   * @param deliveryChallanNo,filters,pageNumber,rowsPerPage,sortColName,sortOrder
	   * @return JqgridResponse<DeliveryChallanItemsDTO> response
	   */
	
	@RequestMapping(value="/records", produces="application/json", method=RequestMethod.POST)
	public @ResponseBody
	JqgridResponse<DeliveryChallanItemsDTO> records(
			@RequestParam("deliveryChallanNo") String deliveryChallanNo,
    		@RequestParam("_search") Boolean search,
    		@RequestParam(value="filters", required=false) String filters,
			@RequestParam(value = "page", required = false) Integer pageNumber,
			@RequestParam(value = "rows", required = false) Integer rowsPerPage,
			@RequestParam(value = "sidx", required = false) String sortColName,
			@RequestParam(value = "sord", required = false, defaultValue = "asc") String sortOrder) {
	
		String invoiceStatus="No";
	    //method to fetch delivery challan items rcords based on parameter delivery challan number
		Page<DeliveryChallanItems> deliveryChallan = deliveryChallanItemsService.getPagedRecords(pageNumber - 1,
				rowsPerPage, sortColName, sortOrder,invoiceStatus,deliveryChallanNo);
	    
		JqgridResponse<DeliveryChallanItemsDTO> response = new JqgridResponse<DeliveryChallanItemsDTO>();
		List<DeliveryChallanItemsDTO>deliveryChallanDTOs = convertToDeliveryChallanItemsDTO(deliveryChallan.getContent());
		response.setRows(deliveryChallanDTOs);
		response.setRecords(Long.valueOf(deliveryChallan.getTotalElements()).toString());
		response.setTotal(Long.valueOf(deliveryChallan.getTotalPages()).toString());
		response.setPage(Integer.valueOf(deliveryChallan.getNumber()+1).toString());

		return response;
	
	}


	 /**
	   * Method to set delivery challan items records to DTO 
	   * @param List<DeliveryChallanItems>
	   * @return List<DeliveryChallanItemsDTO>
	   */
	private List<DeliveryChallanItemsDTO> convertToDeliveryChallanItemsDTO(List<DeliveryChallanItems> deliveryChallans) {
		List<DeliveryChallanItemsDTO> deliveryChallanItemsDTOs = new ArrayList<>();
		for(DeliveryChallanItems deliveryChallan : deliveryChallans) {
			DeliveryChallanItemsDTO deliveryChallanItemsDTO=new DeliveryChallanItemsDTO();
			
			deliveryChallanItemsDTO.setDcItemId(deliveryChallan.getDcItemId());
			deliveryChallanItemsDTO.setDeliveryChallanNo(deliveryChallan.getDeliveryChallan().getDeliveryChallanNo());
			deliveryChallanItemsDTO.setItemDescription(deliveryChallan.getItemDescription());
			deliveryChallanItemsDTO.setNoOfRolls(deliveryChallan.getNoOfRolls());
			deliveryChallanItemsDTO.setQtyPerRoll(deliveryChallan.getQtyPerRoll());
			deliveryChallanItemsDTO.setTotalQty(deliveryChallan.getTotalQty());
			deliveryChallanItemsDTO.setUnits(deliveryChallan.getUnits());
			deliveryChallanItemsDTO.setRate(deliveryChallan.getRate());
			deliveryChallanItemsDTO.setProductTypeKey(deliveryChallan.getProductTypeKey());
			deliveryChallanItemsDTO.setItemId(deliveryChallan.getItem().getItemId());
			deliveryChallanItemsDTOs.add(deliveryChallanItemsDTO);
		}// end of for loop
		return deliveryChallanItemsDTOs;
	}

	
	 /**
	   * Method to Create Invoice 
	   * @param deliveryChallanNo,invoiceDate,transportDetails,transportMode,transportCharges,customerId
	   * @return List<DeliveryChallanItemsDTO>
	   */
@RequestMapping(value="/crud", produces="application/json" ,method = RequestMethod.POST)
	public @ResponseBody
	List<String> saveInvoiceDetails(
     @RequestParam(value = "deliveryChallanNo", required = true) String deliveryChallanNo,
    @RequestParam(value = "invoiceDate", required = true) String invoiceDate,
    @RequestParam(value = "transportDetails", required = true) String transportDetails,
    @RequestParam(value = "transportMode", required = true) String transportMode,
    @RequestParam(value = "transportCharges", required = true) Double transportCharges,
     @RequestParam(value = "customerId", required = true) Long customerId) {
	
	/*Intialize variables*/
	List<String> invoiceNoList=new ArrayList<>();
	String newdInvoiceNo=deliveryChallanNo;
	String amtRuppeString="";
		String amtPaiseString="";
	Float rateOfDuty=(float) 0;
  	Float eduCess=(float) 0;
  	Float higherEduCess=(float) 0;
  	Float cst=(float) 0;
  	Float vat=(float) 0;
    Double roundUpTransportCharge=0.0;
	Boolean finalresult=false;
	Boolean  invoiceItemresult=false;
   	Boolean updateResult=false;
    
    if(transportCharges!=null)
	  roundUpTransportCharge=Math.round(transportCharges*100.0)/100.0;//if loop 

   	//fetching logged in user
   	CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();;
   	String userName = user.getFirstName()+" "+user.getLastName();
	
   	//fetching tax details for invoice amount calculation
  	List<TaxRate> taxRateList=taxRateService.findByCustomerId(customerId);
  	if(taxRateList.size()>0){
  		rateOfDuty=taxRateList.get(0).getExciseDuty();// get excise duty
  		eduCess=taxRateList.get(0).getEduCess();// get EduCess
  		higherEduCess=taxRateList.get(0).getHigherEduCess();// get HigherEduCess
  		if(taxRateList.get(0).getCst()!=null && taxRateList.get(0).getCst()!=0)
  		cst=taxRateList.get(0).getCst();// get Cst
  		else
  		vat=taxRateList.get(0).getVat();// get Vat
  	}//end of 	if(taxRateList.size()>0) loop

   	  String invoiceStatus="No";
   	  
   	  //method to fetch delivery challan details for which invoice should be created
	  List<DeliveryChallanItems> deliveryChallanItemList=deliveryChallanItemsService.findByDeliveryChallanDeliveryChallanNoAndDeliveryChallanInvoiceStatus(deliveryChallanNo,invoiceStatus);
	  Long bagCount= (long) 0;
	  ArrayList<String> bagNoList = new ArrayList<>();
	  
	//method to fetch packing slip details based on delivery challan number
	  List<PackingSlip> packingSlipList=packingSlipService.findByDeliveryChallanNo(deliveryChallanNo);
	    if(packingSlipList.size()>0){
			for (int iterator = 0; iterator < packingSlipList.size(); iterator++) {
				String bagNo = packingSlipList.get(iterator).getPackingSlipNo();
				if (!bagNoList.contains(bagNo)) {
					bagNoList.add(bagNo);
				}// end of if (!bagNoList.contains(bagNo)) loop
			}// end of for loop iterator
	    }// end of  if(packingSlipList.size()>0) loop 
	    if(bagNoList.size()>0){
	    	bagCount=(long) bagNoList.size();
	    }//end of  if(bagNoList.size()>0) loop

	  if(deliveryChallanItemList.size()>0){
		  //Hash Map to set delivery 
			Map<String, List<DeliveryChallanItems>> map = new HashMap<String, List<DeliveryChallanItems>>();
    	    	for (DeliveryChallanItems deliveryChallanItems : deliveryChallanItemList) {
        		   String key = deliveryChallanItems.getAssortedType();
        		   if (map.get(key) == null) {
        		     map.put(key, new ArrayList<DeliveryChallanItems>());
        		     
        		     }// end of  if (map.get(key) == null) loop
        		   map.get(key).add(deliveryChallanItems);
        		}// end of for loop
        		for (List<DeliveryChallanItems> value : map.values()) {
        	    		   String assortedType=value.get(0).getAssortedType();//get assorted type
        	    		   String productTypeKey=value.get(0).getProductTypeKey();//get product key type
        	    		   String units=value.get(0).getUnits();//get units
        	    		   Long noOfRolls=(long) 0;
        	    		   Float rate=value.get(0).getRate();//get rate
        	    		   Double totalQty=0.0;
        	    		   
        	    		   for(int m=0;m<value.size();m++){
        	    			   noOfRolls=noOfRolls+value.get(m).getNoOfRolls();
        	    			   totalQty=totalQty+value.get(m).getTotalQty();  
        	    		   }// end of inner for loop
        	    		   Double totalValue=Double.valueOf(rate)*totalQty;
                           //Calculation of taxes on item value
        	    		   Double totalDuty=(double) 0;
        	    			if(rateOfDuty!=null && rateOfDuty!=0){
        	    				totalDuty=(totalValue*rateOfDuty)/100;//calculating total duty
        	       			}//end of if loop
        	    			Double totalEduCess=0.0;
        	    			if(eduCess!=null && eduCess!=0){
        	    				totalEduCess=(totalDuty*eduCess)/100;//calculating edu cess
        	       			}
        	    			Double totalHigherEduCess=0.0;
        	    			if(higherEduCess!=null && higherEduCess!=0){
        	    				totalHigherEduCess=(totalDuty*higherEduCess)/100;//calculating higher edu cess
        	       			}
        	    			
        	    			Double totalCst=0.0;
        	    			Double totalVat=0.0;
        	    			Double totalValueWithTax=totalValue+totalDuty+totalEduCess+totalHigherEduCess;
        	    			if(cst!=null && cst!=0){
        	    				totalCst=(totalValueWithTax*cst)/100;//calculating cst value
        	       			}else{
        	       				totalVat=(totalValueWithTax*vat)/100;//calculating vat value
        	       			}

        	    			
        	    		//calculation of final amount
        	    		   Double amount=0.0;
        	    			if(totalCst!=null && totalCst!=0.0)   
        	    				amount= Math.round(totalDuty*100.0)/100.0+
        	    						Math.round(totalValue*100.0)/100.0+
        	    						   Math.round(totalEduCess*100.0)/100.0+
        	    						    Math.round(totalHigherEduCess*100.0)/100.0+
        	    						    Math.round(totalCst*100.0)/100.0;//calculating invoice amount based on cst
        	    			else
        	    				amount= Math.round(totalDuty*100.0)/100.0+
        	    						Math.round(totalValue*100.0)/100.0+
        	    						   Math.round(totalEduCess*100.0)/100.0+
        	    						    Math.round(totalHigherEduCess*100.0)/100.0+
        	    						    Math.round(totalVat*100.0)/100.0;	//calculating invoice amount based on vat
        	    			
        	    			
        	 
        	    	//Setting invoiceDTO
        	    		  InvoiceDTO invoiceDTO=new InvoiceDTO();
        	    		  invoiceDTO.setInvoiceDate(invoiceDate);
        	    		  invoiceDTO.setInvoiceNo(newdInvoiceNo);
          	     		  invoiceDTO.setTransportDetails(transportDetails);
          	     		  invoiceDTO.setTransportCharges(roundUpTransportCharge);
          	     		  invoiceDTO.setModeOfTransport(transportMode);
          	    		  invoiceDTO.setCustomerId(customerId);
          	     	      invoiceDTO.setDeliveryChallanNo(deliveryChallanNo);
          	     	      invoiceDTO.setMailStatus("No");
          	              invoiceDTO.setBagCount(bagCount);
          	              invoiceDTO.setStatus("Created");
          	              invoiceDTO.setRemarks("");
          	              invoiceDTO.setLrmailStatus("No");
        	    		  Invoice invoice=invoiceDTO.getInvoice();
        	    		  Invoice createdInvoice=invoiceService.save(invoice);//craete Invoice
        	              if(createdInvoice!=null)	  
        	    		      finalresult=true;
                          if(finalresult==true){
                        	//Setting invoiceItems DTO  
             	    	    InvoiceItemsDTO invoiceItemsDTO=new InvoiceItemsDTO();
             	    		invoiceItemsDTO.setInvoiceNo(newdInvoiceNo);
             	    		invoiceItemsDTO.setAssortedItem(assortedType);
             	    		invoiceItemsDTO.setProductTypeKey(productTypeKey);
             	    		invoiceItemsDTO.setNoOfRolls(noOfRolls);
             	    		invoiceItemsDTO.setRatePerUnit(rate);
             	    		invoiceItemsDTO.setTotalValue(Math.round(totalValue*100.0)/100.0);
             	    		invoiceItemsDTO.setRateOfDuty(rateOfDuty);
             	    		//invoiceItemsDTO.setAmount(Math.round(amount*100.0)/100.0);
             	    		invoiceItemsDTO.setAmount(amount);
             	    		invoiceItemsDTO.setTotalDuty(Math.round(totalDuty*100.0)/100.0);
             	    		invoiceItemsDTO.setTotalEduCess(Math.round(totalEduCess*100.0)/100.0);
             	    		invoiceItemsDTO.setTotalHigherEduCess(Math.round(totalHigherEduCess*100.0)/100.0);
        	         	    invoiceItemsDTO.setTotalVat(Math.round(totalVat*100.0)/100.0);
        	         	    invoiceItemsDTO.setTotalCst(Math.round(totalCst*100.0)/100.0);
        	         	    
             	    		invoiceItemsDTO.setTotalQuantity(totalQty);
             	    		invoiceItemsDTO.setUnits(units);
             	    		
             	    		  InvoiceItems invoiceItems=invoiceItemsDTO.getInvoiceItems();
            	    		  InvoiceItems createdInvoiceItems=invoiceItemsService.save(invoiceItems);//craete invoice Items
        	              if(createdInvoiceItems!=null)	  
        	    		      invoiceItemresult=true;
                     	}// end of   if(finalresult==true) loop    		
           }// end of for loop
           if(invoiceItemresult==true){
        	   Double invoiceAmount=0.0;
        	   //fetch invoice items of newly created inoice
        	   List<InvoiceItems> invoiceItemList=invoiceItemsService.findByInvoiceNo(newdInvoiceNo);
        	   for(int k=0;k<invoiceItemList.size();k++){
        		   invoiceAmount=invoiceAmount+invoiceItemList.get(k).getAmount();//calculating final amount of invoice
             }//e dn of for loop
        		Double finalAmount=0.0;
        	    finalAmount=invoiceAmount+roundUpTransportCharge;//calculating Invoice final amount with transport charges
        	    
        	    /*@10603708 EnglishNumberToWords is a class with convert method that accepts invoice final amount and converts digits to words*/
        	    String finalAmountString="";
                finalAmountString=Double.toString(Math.round(finalAmount*100.0)/100.0);
        	     
        	     String finalAmtRupeeString="";
        	     String finalAmtPaiseString="";
        	     
        	 	if(!finalAmountString.isEmpty()){
        	 		
        	 		finalAmtRupeeString=finalAmountString.substring(0,finalAmountString.indexOf("."));	
        	 		finalAmtPaiseString=finalAmountString.substring(finalAmountString.indexOf(".")+1);
        	 		long finalAmtRupeelong=Long.parseLong(finalAmtRupeeString);
        	 		long finalAmtPaiselong=Long.parseLong(finalAmtPaiseString);
        	 		
        	 		if(finalAmtPaiselong<10 && finalAmtPaiseString.length()==1)
        	 		{
        	 			finalAmtPaiselong=Long.parseLong(finalAmtPaiselong+"0");
        	 		}
        	 		
        	 	 amtRuppeString=EnglishNumberToWords.convert(finalAmtRupeelong);
        	     amtPaiseString=EnglishNumberToWords.convert(finalAmtPaiselong);
        	 	}//end of if loop
        	 	   List<Invoice> invoiceDetailsList=invoiceService.findByInvoiceNo(newdInvoiceNo);//fetch invoice list based on invoice no
               if(invoiceDetailsList.size()>0){
            	  InvoiceDTO invoiceDTOs=new InvoiceDTO();
            	  invoiceDTOs.setInvoiceDate(invoiceDate);
            	  invoiceDTOs.setInvoiceNo(newdInvoiceNo);
            	  invoiceDTOs.setTransportDetails(transportDetails);
            	  invoiceDTOs.setTransportCharges(roundUpTransportCharge);
            	  invoiceDTOs.setModeOfTransport(transportMode);
            	  invoiceDTOs.setCustomerId(customerId);
            	  invoiceDTOs.setDeliveryChallanNo(deliveryChallanNo);
            	  invoiceDTOs.setMailStatus("No");
            	  invoiceDTOs.setLrmailStatus("No");
            	  invoiceDTOs.setBagCount(bagCount);
            	  invoiceDTOs.setAmount(Math.round(invoiceAmount*100.0)/100.0);
            	  invoiceDTOs.setInvoiceSupervisor(userName);
            	  invoiceDTOs.setStatus("Created");
            	  invoiceDTOs.setRemarks("");
            	  invoiceDTOs.setFinalAmount(Math.round(finalAmount*100.0)/100.0);
            	  if(amtRuppeString!=null){
            	  if(amtPaiseString!=null && amtPaiseString!="" )
                      invoiceDTOs.setInvoiceAmtInWords(amtRuppeString+" Rupees and "+amtPaiseString+" Paise");  
            	  else
                	  invoiceDTOs.setInvoiceAmtInWords(amtRuppeString+" Ruppees");
                
 	    		  }
            	  Invoice invoices=invoiceDTOs.getInvoice();
 	    		  Invoice createdInvoices=invoiceService.save(invoices);//updating invoice with final amount of all items
 	              if(createdInvoices!=null)	  
 	    		      finalresult=true;
            
               }//end of  if(invoiceDetailsList.size()>0) loop
        	     
           }
	       if(finalresult==true && invoiceItemresult==true){
	    	 //Fetching Delivery Challan List
            List<DeliveryChallan> deliveryChallanListIds=deliveryChallanService.findByDeliveryChallanNo(deliveryChallanNo);
             for(int i=0;i<deliveryChallanListIds.size();i++){
            	 DeliveryChallanDTO deliveryChallanDTO=new DeliveryChallanDTO();
            	 deliveryChallanDTO.setDeliveryChallanNo(deliveryChallanListIds.get(i).getDeliveryChallanNo());
            	 if(deliveryChallanListIds.get(i).getChallanDate()!=null){
      			 deliveryChallanDTO.setChallanDate(Utility.formDateFormatter.print(deliveryChallanListIds.get(i).getChallanDate().getTime()));
            	 }// end of  if(deliveryChallanListIds.get(i).getChallanDate()!=null) loop 
      			 deliveryChallanDTO.setCreatedTime(deliveryChallanListIds.get(i).getCreatedTime().toString());
      			 deliveryChallanDTO.setInvoiceStatus("Yes");
      			 deliveryChallanDTO.setOrderId(deliveryChallanListIds.get(i).getOrders().getOrderId());
      			 deliveryChallanDTO.setInvoiceNo(newdInvoiceNo);
      	         deliveryChallanDTO.setDcSupervisor(userName);
      	         deliveryChallanDTO.setStatus(deliveryChallanListIds.get(i).getStatus());
      	         deliveryChallanDTO.setRemarks(deliveryChallanListIds.get(i).getRemarks());
      			 DeliveryChallan dcItem=deliveryChallanDTO.getDeliveryChallan();
     			 DeliveryChallan createddc=deliveryChallanService.create(dcItem);//update delivery challan 
                 if(createddc!=null)
                	 updateResult=true;
     	
             }//end of for loop
      if(updateResult==true)
	     invoiceNoList.add(newdInvoiceNo);
            }// end of   if(finalresult==true && invoiceItemresult==true) loop
	       }//end of if(deliveryChallanItemList.size()>0)
       return invoiceNoList;

}
}