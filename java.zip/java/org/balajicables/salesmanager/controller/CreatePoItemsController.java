package org.balajicables.salesmanager.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import javax.annotation.Resource;

import org.balajicables.salesmanager.service.ItemService;
import org.balajicables.salesmanager.common.JqgridResponse;
import org.balajicables.salesmanager.common.StatusResponse;
import org.balajicables.salesmanager.dto.PurchaseOrderItemDTO;
import org.balajicables.salesmanager.dto.TaxRateDTO;
import org.balajicables.salesmanager.model.Item;
import org.balajicables.salesmanager.model.PurchaseOrder;
import org.balajicables.salesmanager.model.PurchaseOrderItem;
import org.balajicables.salesmanager.model.TaxRate;
import org.balajicables.salesmanager.service.PurchaseOrderItemService;
import org.balajicables.salesmanager.service.PurchaseOrderService;
import org.balajicables.salesmanager.service.TaxRateService;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
/**
* This class demonstrates Create Purchase Order Items Process.
* @author Abin Sam
*/
@Controller
@RequestMapping("/createpoitems")
public class CreatePoItemsController {

	@Resource
	private PurchaseOrderService purchaseOrderService;
	@Resource
	private PurchaseOrderItemService purchaseOrderItemService;
	@Resource
	private ItemService itemService;
	@Resource
	private TaxRateService taxRateService;


	 /**
	   * This method returns createPurchaseOrderItems.jsp.
	   * Fetch all Purcahse Order Details
	   * @param Model to set the attribute.
	   * @return createInvoice.jsp.
	   */
	@RequestMapping(method = RequestMethod.GET)
	public String getPurchaseOrderItemsPage(Model model,
			@RequestParam(value = "poNo") String poNo) {
		PurchaseOrder purchaseOrder = purchaseOrderService
				.findByIdWithCustomer(poNo);
		model.addAttribute("poNo", poNo);	//set purchase order no  to model
		model.addAttribute("purchaseOrder", purchaseOrder);	//set purchase order details to model
		
		List<PurchaseOrder>poList=purchaseOrderService.findByPoNo(poNo);
		List<TaxRate> taxRateList=null;
		Long customerId=null;
		if(poList.size()>0){
			customerId=poList.get(0).getCustomer().getCustomerId();
		}//end of if(poList.size()>0) loop
		taxRateList=taxRateService.findByCustomerId(customerId);
		if(taxRateList.size()>0){
			if(taxRateList.get(0).getExciseDuty()!=null)
			model.addAttribute("exciseDuty", taxRateList.get(0).getExciseDuty());	//set customer excise duty to model
			if(taxRateList.get(0).getCst()!=null && taxRateList.get(0).getCst()!=0)
			model.addAttribute("cst", taxRateList.get(0).getCst());//set customer CST to model
			else
			model.addAttribute("cst", taxRateList.get(0).getVat());//set customer VAT to model
		}// end of if(taxRateList.size()>0) loop
	
		model.addAttribute("customerId", customerId);
		return "createPurchaseOrderItems";
	}
	

	 /**
	   * This method returns list of all item codes form item master.
	   * @return List<String>itemCodesList.
	   */
	@RequestMapping(value="/fetchPoItemCode", produces="application/json", method=RequestMethod.GET)
	public @ResponseBody List<String> fetchItemCode(){
		List<String>itemCodesList=itemService.selectAllItemCodes();
		return itemCodesList;
		
	}
	
	
	 /**
	   * This method to populate Purchase Order Item Grid
	   * Fetch details of Purchase Order Item 
	   * @param poNo,filters,pageNumber,rowsPerPage,sortColName,sortOrder
	   * @return JqgridResponse<DeliveryChallanItemsDTO> response
	   */

	@RequestMapping(value = "/addedItems/{poNo}", produces = "application/json", method = RequestMethod.GET)
	public @ResponseBody
	JqgridResponse<PurchaseOrderItemDTO> records(
			@PathVariable("poNo") String poNo,
			@RequestParam("_search") Boolean search,
			@RequestParam(value = "filters", required = false) String filters,
			@RequestParam(value = "page", required = false) Integer pageNumber,
			@RequestParam(value = "rows", required = false) Integer rowsPerPage,
			@RequestParam(value = "sidx", required = false) String sortColName,
			@RequestParam(value = "sord", required = false, defaultValue = "asc") String sortOrder) {
	    //JQGrid column sorting
		if(sortColName.equalsIgnoreCase("itemCode")){
			sortColName="item.itemCode";
		}
		if(sortColName.equalsIgnoreCase("itemDescription")){
			sortColName="item.itemDescription";
		}
		if(sortColName.equalsIgnoreCase("unit")){
			sortColName="item.unit.units";
		}
		//method to fetch PurchaseOrder items records based on parameter PurchaseOrder number
		Page<PurchaseOrderItem> poItemOutputOutput = purchaseOrderItemService.getPagedPurchaseOrderItems(poNo, pageNumber - 1, rowsPerPage,	sortColName, sortOrder);
		JqgridResponse<PurchaseOrderItemDTO> response = new JqgridResponse<PurchaseOrderItemDTO>();
		List<PurchaseOrderItemDTO> purchaseOrderItemDTOs = convertToPoItemDTO(poItemOutputOutput.getContent(), poNo);
		response.setRows(purchaseOrderItemDTOs);
		response.setRecords(Long.valueOf(poItemOutputOutput.getTotalElements()).toString());
		response.setTotal(Long.valueOf(poItemOutputOutput.getTotalPages()).toString());
		response.setPage(Integer.valueOf(poItemOutputOutput.getNumber() + 1).toString());
		return response;
	}

	
	 /**
	   * Method to set PurchaseOrder items records to DTO 
	   * @param List<PurchaseOrderItem>
	   * @return List<PurchaseOrderItemDTO>
	   */
	private List<PurchaseOrderItemDTO> convertToPoItemDTO(
			List<PurchaseOrderItem> poItems, String poNo) {
		    List<PurchaseOrderItemDTO> poItemsDTOs = new ArrayList<>();
		for (PurchaseOrderItem poItem : poItems) {	
			//setting list items to PurchaseOrderItemDTO
			PurchaseOrderItemDTO purchaseOrderItemDTO = new PurchaseOrderItemDTO();
			purchaseOrderItemDTO.setPurchaseOrderItemId(poItem.getPurchaseOrderItemId());
			purchaseOrderItemDTO.setPoNo(poItem.getPurchaseOrder().getPoNo());
			purchaseOrderItemDTO.setItemId(poItem.getItem().getItemId());
			purchaseOrderItemDTO.setItemCode(poItem.getItem().getItemCode());
			purchaseOrderItemDTO.setDescription(poItem.getItem().getItemDescription());
			purchaseOrderItemDTO.setQuantity(poItem.getQuantity());
			purchaseOrderItemDTO.setRate(poItem.getRate());
			purchaseOrderItemDTO.setPrice(poItem.getPrice());
			purchaseOrderItemDTO.setUnit(poItem.getItem().getUnit().getUnits());
			poItemsDTOs.add(purchaseOrderItemDTO);
		}// end of for loop
		return poItemsDTOs;
	}

	 /**
	   * Method to Create/Edit Purchase Order Items 
	   * @param operation(edit/create),poNo,invoiceDate,itemId,description,rate,quantity
	   * @return StatusResponse
	   */	
	@RequestMapping(value = "/editFunc", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	StatusResponse crud(@RequestParam Long id, @RequestParam String oper,
			@RequestParam(required = false) String poNo,
			@RequestParam(required = false) Long itemId,
			@RequestParam(required = false) String description,
			@RequestParam(required = false) String rate,
			@RequestParam(required = false) String quantity) {
		Boolean updatedPO=false;
		//Pattern matching for valid rate and quantity
		String decimalPattern = "((-|\\+)?[0-9]+(\\.[0-9]+)?)+";  
		boolean qtyMatch = Pattern.matches(decimalPattern, quantity);
		boolean rateMatch = Pattern.matches(decimalPattern, rate);
		
		if(qtyMatch==true && rateMatch==true){
			Double newQuantity=Double.valueOf(quantity);
			Float newRate=Float.valueOf(rate);			
		//intialize varables	
		Boolean result = false;
		Double poTotalQty=0.0;
		Double poBalanceTotQty=0.0;
		Double existQuantity=0.0;
		Double balQty=0.0;
		
		
		PurchaseOrderItemDTO poItemDTO = new PurchaseOrderItemDTO();
		if(id != null && id!=0) {
		poItemDTO.setPurchaseOrderItemId(id);
		poItemDTO.setQuantity(newQuantity);
		
		List<PurchaseOrderItem> poItemList=purchaseOrderItemService.findByPoItemId(id);
		if(poItemList.size()>0){
		 existQuantity=poItemList.get(0).getQuantity();
		 balQty=poItemList.get(0).getBalanceQty();
		  if(newQuantity>existQuantity){
			  balQty=balQty+(newQuantity-existQuantity);  
		  }//end of if loop
		  else{
			  balQty=balQty-(existQuantity-newQuantity);
		  }//end of else loop
		}// end of if loop poitemlist size check
	     poItemDTO.setBalanceQty(balQty);
		}// end of if loop id null check
		
		else{
		poItemDTO.setQuantity(0.0);
		poItemDTO.setBalanceQty(0.0);
		}// end of else loop
		poItemDTO.setPoNo(poNo);
		poItemDTO.setItemId(itemId);
		poItemDTO.setDescription(description);
		poItemDTO.setRate(newRate);
			
		if (rate != null && quantity != null)
			poItemDTO.setPrice((double) (newRate * newQuantity));
		PurchaseOrderItem poItemObj = poItemDTO.getPoItem();
		switch (oper) {
		case "add":
			PurchaseOrderItem createdPoItem = purchaseOrderItemService
					.create(poItemObj);//method to save poitems
			if (createdPoItem != null) {
				result = true;
			}
			break;
		case "edit":
			result = purchaseOrderItemService.update(poItemObj);//method to update poitems
			break;
		case "del":
			break;
		}//end of switch loop
	if (result == true) {
			List<PurchaseOrderItem> poItemList = purchaseOrderItemService.findByPoNo(poNo);
               if(poItemList.size()>0){
            	   for(int i=0;i<poItemList.size();i++){
            	   poTotalQty=poTotalQty+poItemList.get(i).getQuantity();
            	   poBalanceTotQty=poBalanceTotQty+poItemList.get(i).getBalanceQty();
            	 }//end of for loop
               }// end of  if(poItemList.size()>0) loop
             List<PurchaseOrder> poList=purchaseOrderService.findByPoNo(poNo);
             if(poList.size()>0){
            	 poList.get(0).setQuantity(poTotalQty);
            	 poList.get(0).setBalanceQuantity(poBalanceTotQty);
            	 updatedPO=purchaseOrderService.update(poList.get(0));
             }// end of if(poList.size()>0) loop
			}// end of if(qtyMatch==true && rateMatch==true) loop 
	}// end of if(qtyMatch==true && rateMatch==true) loop
		return new StatusResponse(updatedPO);
	}

	
	 /**
	   * Method to Check valid price exist for  Purchase Order Items 
	   * @param Purchase Order Number
	   * @return List<String>
	   */	
	
	@RequestMapping(value = "/checkPrice", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	List<String> checkRates(@RequestParam String poNo) {
		List<String> priceMsg = new ArrayList<String>();
		List<PurchaseOrderItem> poItemPriceList = new ArrayList<>();
		poItemPriceList = purchaseOrderItemService.checkPrice(poNo);//query to check invalid price po item entries
		if (poItemPriceList.size() > 0) {
			priceMsg.add("priceNotPresent");
		}//end ofif (poItemPriceList.size() > 0) loop
	   else{
			priceMsg.add("priceValid");
	   }// end of else loop
		return priceMsg;
	}

	
	
	 /**
	   * Method to Add Items of a Purchase Order 
	   * @param Purchase Order Number,itemCode,exciseDuty,cstValue,rate,quantity,customerId
	   * @return List<String>
	   */
	@RequestMapping(value = "/create", method = RequestMethod.POST)
	public @ResponseBody
    List<String> createOrderDetails(@RequestParam("poNo") String poNo,
			@RequestParam("item") String itemCode,
			Float exciseDuty,Float cstValue,
			@RequestParam(required = false) Float rate,
			@RequestParam(required = false) Double quantity,
			Long customerId
			)

	{
		if(quantity==null)
			quantity=0.0;
		List<String> statusMssgList=new ArrayList<String>();
		
		//Intialize variables
		Double poTotalQty=0.0;
		Double poBalanceTotQty=0.0;
		Boolean updatedPo = false;
		Boolean updatedTaxRate=false;
		
		//Fetch Tax details List of a customer
        List<TaxRate> taxRateList=taxRateService.findByCustomerId(customerId);
       
        if(taxRateList.size()>0){
        	//Setting Tax Rate DTO
        	TaxRateDTO taxRateDTO=new TaxRateDTO();
        	taxRateDTO.setTaxRateId(taxRateList.get(0).getTaxRateId());
        	taxRateDTO.setCustomerId(customerId);
        	taxRateDTO.setExciseDuty(exciseDuty);
        	taxRateDTO.setCst(cstValue);
        	taxRateDTO.setEduCess(taxRateList.get(0).getEduCess());
        	taxRateDTO.setHigherEduCess(taxRateList.get(0).getHigherEduCess());
           	taxRateDTO.setVat(taxRateList.get(0).getVat());
        	
        	TaxRate taxRate=taxRateDTO.getTaxRate();
        	 updatedTaxRate=taxRateService.update(taxRate);//Update Tax rate table
        	
        }// end of  if(taxRateList.size()>0) loop
        
		Boolean result = false;
		if(updatedTaxRate==true){
			// fetch Item List based on item Code
		List<Item> itemIdList = itemService.fetchItemId(itemCode);
		Long itemId = itemIdList.get(0).getItemId();//fetching item id from Item Details List
		String itemDescription = itemIdList.get(0).getItemDescription();//fetching item description  from Item Details List
		PurchaseOrderItemDTO poitemsDTO = new PurchaseOrderItemDTO();
		if (poNo != null && itemCode != null && itemId != null) {
			poitemsDTO.setPoNo(poNo);
			poitemsDTO.setItemId(itemId);
			poitemsDTO.setDescription(itemDescription);
			poitemsDTO.setQuantity(quantity);
			poitemsDTO.setBalanceQty(quantity);
			// check rate null or not
			if(rate!=null)
			poitemsDTO.setRate(rate);
			else 
				poitemsDTO.setRate((float)0);	
			if (rate != null && quantity != null)
				poitemsDTO.setPrice((double) (rate * quantity));
			else
				poitemsDTO.setPrice(0.0);
		}// end of if (poNo != null && itemCode != null && itemId != null) loop
		PurchaseOrderItem poitem = poitemsDTO.getPoItem();
		List<PurchaseOrderItem> poitemList = purchaseOrderItemService.findByPoNoItemId(poNo, itemCode);
		if (poitemList.size() == 0) {
			PurchaseOrderItem createdPoItem = purchaseOrderItemService.create(poitem);
			if (createdPoItem != null) {
				result = true;
			}// end of if (createdPoItem != null) loop
			statusMssgList.add("added");//adding message to return list
		}//end of if (poitemList.size() == 0) loop
		else{
			statusMssgList.add("exist");//adding message to return list
		}//end of else loop
		if (result == true) {
			List<PurchaseOrderItem> poItemList = purchaseOrderItemService.findByPoNo(poNo);
            if(poItemList.size()>0){
         	   for(int i=0;i<poItemList.size();i++){
         	   poTotalQty=poTotalQty+poItemList.get(i).getQuantity();
         	   poBalanceTotQty=poBalanceTotQty+poItemList.get(i).getBalanceQty();
         	 }
            }
          List<PurchaseOrder> poList=purchaseOrderService.findByPoNo(poNo);
          if(poList.size()>0){
         	 poList.get(0).setQuantity(poTotalQty);
         	 poList.get(0).setBalanceQuantity(poBalanceTotQty);
         	 updatedPo=purchaseOrderService.update(poList.get(0));//update Purchase Order Model
         	if(updatedPo==true)
         		result=true;
           }//end of   if(poList.size()>0) loop
		 }//end of if (result == true) loop
		}// end of if(updatedTaxRate==true) loop
		return statusMssgList;	
	}
	
	
	
	 /**
	   * Method to Delete  Purchase Order Items
	   * @param Purchase Order Number,purchaseOrderItemId
	   * @return List<String>
	   */
	
	@RequestMapping(value = "/delete/{purchaseOrderItemId}", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	StatusResponse deleteId(@PathVariable("purchaseOrderItemId") Long purchaseOrderItemId,
			@RequestParam(required = false) String poNo) {
		//Initialize variables
		Boolean result=false;
		Boolean updatedPO=false;
		Double poTotalQty =0.0;
		Double poBalanceTotQty =0.0;
		
		   result = purchaseOrderItemService.delete(purchaseOrderItemId);//delete purcahse order item
		   if(result==true){
			   //list to fetch Purchase Order Items based on purchase order no
				List<PurchaseOrderItem> poItemsList = purchaseOrderItemService.findByPoNo(poNo);
	               if(poItemsList.size()>0){
	            	   for(int i=0;i<poItemsList.size();i++){
	            	   poTotalQty=poTotalQty+poItemsList.get(i).getQuantity();
	            	   poBalanceTotQty=poBalanceTotQty+poItemsList.get(i).getBalanceQty();
	            	 }//end of for loop
	               }// end of  if(poItemsList.size()>0) loop
	             List<PurchaseOrder> poList=purchaseOrderService.findByPoNo(poNo);
	             if(poList.size()>0){
	            	 poList.get(0).setQuantity(poTotalQty);
	            	 poList.get(0).setBalanceQuantity(poBalanceTotQty);
	            	 updatedPO=purchaseOrderService.update(poList.get(0));
	             } // end of if(poList.size()>0) loop
		   }// end of  if(result==true) loop
			return new StatusResponse(updatedPO);
	}	
	
}
