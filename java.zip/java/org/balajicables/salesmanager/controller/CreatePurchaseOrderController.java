package org.balajicables.salesmanager.controller;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Resource;

import org.balajicables.salesmanager.CustomUser;
import org.balajicables.salesmanager.common.JqgridResponse;
import org.balajicables.salesmanager.common.StatusResponse;
import org.balajicables.salesmanager.dto.PurchaseOrderDTO;
import org.balajicables.salesmanager.repository.PurchaseOrderRepository;
import org.balajicables.salesmanager.model.Customer;
import org.balajicables.salesmanager.model.PurchaseOrder;
import org.balajicables.salesmanager.model.PurchaseOrderItem;
import org.balajicables.salesmanager.model.TaxRate;
import org.balajicables.salesmanager.service.CustomerService;
import org.balajicables.salesmanager.service.PurchaseOrderItemService;
import org.balajicables.salesmanager.service.PurchaseOrderService;
import org.balajicables.salesmanager.service.TaxRateService;
import org.balajicables.salesmanager.utils.Utility;
import org.joda.time.DateTime;
import org.springframework.data.domain.Page;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
/**
* This class demonstrates Create Purchase Order Process.
* @author Abin Sam
*/
@Controller
@RequestMapping("/createpurchaseorder")
public class CreatePurchaseOrderController {

	@Resource
	private PurchaseOrderService purchaseOrderService;
	@Resource
	private PurchaseOrderItemService purchaseOrderItemService;
	@Resource
	private TaxRateService taxRateService;
	@Resource
	private PurchaseOrderRepository purchaseOrderRepository;

	@Resource
	private CustomerService customerService;


	 /**
	   * This method returns createPurchaseOrder.jsp.
	   * Fetch all Customer
	   * @param Model to set the attribute.
	   * @return createPurchaseOrder.jsp.
	   */

	@RequestMapping(method = RequestMethod.GET)
	public String getPurchaseOrderPage(Model model) {
		List<Customer> customers = customerService.findAll();//list to fetch customer
		model.addAttribute("customers", customers);//setting customer to model attribute
		return "createPurchaseOrder";
	}

	
	
	 /**
	   * This method to populate Purchase Order Grid
	   * Fetch details of Purchase Order 
	   * @param poNo,filters,pageNumber,rowsPerPage,sortColName,sortOrder
	   * @return JqgridResponse<PurchaseOrderDTO> response
	   */

	@RequestMapping(value = "/records/{customerId}", produces = "application/json", method = RequestMethod.GET)
	public @ResponseBody
	JqgridResponse<PurchaseOrderDTO> records(
			@PathVariable("customerId") long customerId,
			@RequestParam("_search") Boolean search,
			@RequestParam(value = "filters", required = false) String filters,
			@RequestParam(value = "page", required = false) Integer pageNumber,
			@RequestParam(value = "rows", required = false) Integer rowsPerPage,
			@RequestParam(value = "sidx", required = false) String sortColName,
			@RequestParam(value = "sord", required = false, defaultValue = "asc") String sortOrder) {
         //fetch Purchase Order 
		Page<PurchaseOrder> poOrders = purchaseOrderService
				.getPagedOrders(customerId, pageNumber - 1, rowsPerPage,
						sortColName, sortOrder);

		JqgridResponse<PurchaseOrderDTO> response = new JqgridResponse<PurchaseOrderDTO>();
		List<PurchaseOrderDTO> poDTOs = convertToPoDTO(poOrders.getContent());
		response.setRows(poDTOs);
		response.setRecords(Long.valueOf(poOrders.getTotalElements())
				.toString());
		response.setTotal(Long.valueOf(poOrders.getTotalPages()).toString());
		response.setPage(Integer.valueOf(poOrders.getNumber() + 1).toString());

		return response;
	}
	 /**
	   * Method to set PurchaseOrder  records to DTO 
	   * @param List<PurchaseOrder>
	   * @return List<PurchaseOrderDTO>
	   */
	private List<PurchaseOrderDTO> convertToPoDTO(List<PurchaseOrder> poOrders) {
		List<PurchaseOrderDTO> poOrderDTOs = new ArrayList<>();
		for (PurchaseOrder poOrder : poOrders) {
			if ((poOrder.getPoStatus().equalsIgnoreCase("Pending"))) {
				PurchaseOrderDTO poDTO = new PurchaseOrderDTO();
				poDTO.setPoNo(poOrder.getPoNo());
				if (poOrder.getPoDate() != null)
					poDTO.setPoDate(Utility.formDateFormatter.print(poOrder
							.getPoDate().getTime()));//formatting and set po date
				poDTO.setCreatedBy(poOrder.getCreatedBy());
				poDTO.setUpdatedBy(poOrder.getUpdatedBy());
				poDTO.setCustomerId(poOrder.getCustomer().getCustomerId());
				poDTO.setCustomerName(poOrder.getCustomer().getCustomerName());
				poDTO.setBalanceQuantity(poOrder.getBalanceQuantity());
				poDTO.setQuantity(poOrder.getQuantity());
				poDTO.setPoStatus(poOrder.getPoStatus());
			    poDTO.setTotalPrice(poOrder.getTotalPrice());
			    poDTO.setExciseDuty(poOrder.getExciseDuty());
			    poDTO.setCstValue(poOrder.getCstValue());
			    poDTO.setAmount(poOrder.getAmount());
			    poDTO.setMailSent(poOrder.getMailSent());
			  	if (poOrder.getCreatedTime() != null)
					poDTO.setCreatedTime(poOrder.getCreatedTime().toString());
				poOrderDTOs.add(poDTO);
			}
		}
		return poOrderDTOs;
	}

	

	 /**
	   * Method to Create/Edit Purchase Order 
	   * @param operation(edit/create),createdBy,poDate,poStatus,createdTime,mailSent,customerId
	   * @return StatusResponse
	   */	
	@RequestMapping(value = "/crud", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	StatusResponse crud(@RequestParam String id, @RequestParam String oper,
			@RequestParam(required = false) String createdBy,
			@RequestParam(required = false) String poDate,
			@RequestParam(required = false) String poStatus,
			@RequestParam(required = false) String createdTime,
			@RequestParam(required = false) String mailSent,
			@RequestParam(required = true) long customerId) {
	   	//fetching logged in user
		CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();;
        Boolean saveResult=false;
		String userName = user.getFirstName()+" "+user.getLastName();
		String newPurchaseOrderNo="";
		Boolean result = false;
		PurchaseOrderDTO poDTO = new PurchaseOrderDTO();
		if (id != null && !"".equalsIgnoreCase(id.trim())
				&& !"_empty".equalsIgnoreCase(id.trim())
				&& !"new_row".equalsIgnoreCase(id.trim())) {
			poDTO.setPoNo(id);
			List<PurchaseOrder> poList = purchaseOrderService.findByPoNo(id);
			if (poList.size() > 0)
			poDTO.setBalanceQuantity(poList.get(0).getBalanceQuantity());
			poDTO.setCreatedTime(poList.get(0).getCreatedTime().toString());
			poDTO.setPoStatus(poStatus);
			poDTO.setQuantity(poList.get(0).getQuantity());
			poDTO.setCreatedBy(createdBy);
			poDTO.setMailSent(mailSent);
			poDTO.setUpdatedBy(userName);
			java.util.Date date = new java.util.Date();
			poDTO.setUpdatedTime(new Timestamp(date.getTime()).toString());
			poDTO.setPoDate(poDate);
			poDTO.setCustomerId(customerId);
			 saveResult=true;

		}//end of if loop
		else {
			String yearNo = String.valueOf(new DateTime().getYear() % 1000);
			String monthNo = "";
			if (new DateTime().getMonthOfYear() > 9)
				monthNo = String.valueOf(new DateTime().getMonthOfYear());
			else
				monthNo = "0" + String.valueOf(new DateTime().getMonthOfYear());

			List<PurchaseOrder> existPOList = purchaseOrderService
					.fetchLatestPO();//fetch latest po number 

			String existPONo = "";
			if (existPOList.size() > 0)
				existPONo = existPOList.get(0).getPoNo();

			if (!existPONo.isEmpty()) {
				String existPOYear = existPONo.substring(1, 3);
				String existPOMonth = existPONo.substring(3, 5);
				String existPONoParse = existPONo.substring(1, 8);
				if ((yearNo.equalsIgnoreCase(existPOYear))
						&& (monthNo.equalsIgnoreCase(existPOMonth))) {
					int purchaseOrderInt = Integer.parseInt(existPONoParse) + 1;
					newPurchaseOrderNo = "P" + String.valueOf(purchaseOrderInt);
				} else {
					newPurchaseOrderNo = "P" + yearNo + monthNo + "001";
				}
			}// end of if loop of checking existing sales no
			else {
				newPurchaseOrderNo = "P" + yearNo + monthNo + "001";
			}
			
			List<PurchaseOrder>poOrderList=purchaseOrderService.findByPoNo(newPurchaseOrderNo);//fetch purchase order details based on po number
			if(!(poOrderList.size()>0)){
			poDTO.setPoNo(newPurchaseOrderNo);
			poDTO.setPoStatus("Pending");
			poDTO.setBalanceQuantity(0.0);
			poDTO.setQuantity(0.0);
			poDTO.setCreatedBy(userName);
			poDTO.setMailSent("No");
			poDTO.setUpdatedBy(userName);
			java.util.Date date = new java.util.Date();
			poDTO.setUpdatedTime(new Timestamp(date.getTime()).toString());
			poDTO.setPoDate(poDate);
			poDTO.setCustomerId(customerId);
			 saveResult=true;
			}
		}

		PurchaseOrder purchaseorder = poDTO.getPurchaseOrder();
		switch (oper) {
		case "add":
			if(saveResult==true){
			PurchaseOrder createdOrder = purchaseOrderService.create(purchaseorder);//method to save purcahse order
			if (createdOrder != null) {
				result = true;
			}}
			break;
		case "edit":
			if(saveResult==true){
			result = purchaseOrderService.update(purchaseorder);//method to update purcahse order
			}
			break;
		case "del":
			purchaseOrderRepository.delete(id);//method to delete purcahse order
			break;
		}//end of switch loop
		
		return new StatusResponse(result);
	}

	
	 /**
	   * This method returns StatusResponse.
	   * Submit Purcahse order
	   * @param poNo.
	   * @return StatusResponse
	   */
	@RequestMapping(value = "/submitPoItems/{poNo}", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	StatusResponse submitPoItems(@PathVariable("poNo") String poNo) {

		Boolean updateProcessResult = false;
		List<PurchaseOrder> poList = purchaseOrderService.findByPoNo(poNo);//fetch purchase order details by PO No
		poList.get(0).setPoStatus("Submitted");//setting po status to submitted
		Long customerId = (long) 0;
        if(poList.size()>0){
    	customerId=poList.get(0).getCustomer().getCustomerId();//get customerId
       }//end of if loop
		
		Double totalPrice=0.0;
		Float exciseDuty=(float) 0;
		Float cstVatValue=(float) 0;
		Double amount=0.0;
		Double exciseDutyAmount=0.0;
		Double taxableAmount=0.0;
		Double cstVatAmount=0.0;
		
		List<PurchaseOrderItem> poItemList=purchaseOrderItemService.findByPoNo(poNo);//fetch Purchase order items based on PO No
			if(poItemList.size()>0){
				for(int k=0;k<poItemList.size();k++){
					totalPrice=totalPrice+poItemList.get(k).getPrice();
				}//end of for loop
				List<TaxRate>taxRateList=taxRateService.findByCustomerId(customerId);
				if(taxRateList.size()>0){
					if(taxRateList.get(0).getExciseDuty()!=null)
					exciseDuty=taxRateList.get(0).getExciseDuty();//get excise duty
					if(taxRateList.get(0).getCst()!=null && taxRateList.get(0).getCst()!=0)
						cstVatValue=taxRateList.get(0).getCst();//get cst  value
					else
						cstVatValue=taxRateList.get(0).getVat();//get vat value
				}//end of if(taxRateList.size()>0) loop 
				exciseDutyAmount=(totalPrice*exciseDuty)/100;//calculate excise duty
				taxableAmount=totalPrice+exciseDutyAmount;//total taxable amount on which tax is calculated
				cstVatAmount=(taxableAmount*cstVatValue)/100;//calculating cst/vat amount
				
				amount= Math.round(totalPrice*100.0)/100.0+
						Math.round(exciseDutyAmount*100.0)/100.0+
						   Math.round(cstVatAmount*100.0)/100.0;//calculating Purcahse Order final amount
			}//end of if(poItemList.size()>0) loop
			
			poList.get(0).setPoStatus("Submitted");
			poList.get(0).setTotalPrice(Math.round(totalPrice*100.0)/100.0);
			poList.get(0).setExciseDuty(Math.round(exciseDutyAmount*100.0)/100.0);
			poList.get(0).setCstValue(Math.round(cstVatAmount*100.0)/100.0);
			poList.get(0).setAmount(amount);
		updateProcessResult = purchaseOrderService.update(poList.get(0));//method to update Purcahse order
		return new StatusResponse(updateProcessResult);
	}
	 /**
	   * This method returns List<String>.
	   * Check Purchase Order Item Exist
	   * @param poNo.
	   * @return List<String>statusMessage.
	   */
	@RequestMapping(value = "/checkPOItems/{poNo}", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	List<String> checkPoItems(@PathVariable("poNo") String poNo) {
		
		List<String> statusMssgList=new ArrayList<String>();
		List<PurchaseOrderItem> poItems = purchaseOrderItemService.findByPoNo(poNo);//fetch Purcahse order items based on PO No
		if (poItems.size() == 0) {
			statusMssgList.add("noItems");
		}//end of if loop
		else{
			statusMssgList.add("exist");
		}//end of else loop
		return statusMssgList;
	}

	 /**
	   * This method StatusResponse.
	   * Delete Purchase Order 
	   * @param poNo.
	   * @return StatusResponse.
	   */
	@RequestMapping(value = "/delete/{poNo}", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	StatusResponse deleteId(@PathVariable("poNo") String poNo) {
		Boolean result = false;
		result = purchaseOrderService.delete(poNo);//method to delete purcahse order
		return new StatusResponse(result);
	}

}