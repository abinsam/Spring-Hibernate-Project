package org.balajicables.salesmanager.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.annotation.Resource;
import org.balajicables.salesmanager.CustomUser;
import org.balajicables.salesmanager.common.JqgridResponse;
import org.balajicables.salesmanager.common.SaveProductionWorkOrder;
import org.balajicables.salesmanager.common.StatusResponse;
import org.balajicables.salesmanager.dto.RawMaterialStoreRegDTO;
import org.balajicables.salesmanager.dto.RbdWorkOrderInputDTO;
import org.balajicables.salesmanager.model.Item;
import org.balajicables.salesmanager.model.MachineDetails;
import org.balajicables.salesmanager.model.ProductionProcess;
import org.balajicables.salesmanager.model.ProductionWorkOrder;
import org.balajicables.salesmanager.model.RawMaterialStoreReg;
import org.balajicables.salesmanager.model.RbdWorkOrderInput;
import org.balajicables.salesmanager.service.ItemService;
import org.balajicables.salesmanager.service.MachineService;
import org.balajicables.salesmanager.service.ProductionProcessService;
import org.balajicables.salesmanager.service.ProductionWorkOrderService;
import org.balajicables.salesmanager.service.RawMaterialStoreRegService;
import org.balajicables.salesmanager.service.RbdWorkOrderInputService;
import org.joda.time.DateTime;
import org.springframework.data.domain.Page;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
/**
* This class demonstrates Create RBD Work Order Process.
* @author Abin Sam
*/
@Controller
@RequestMapping("/createRBDWorkOrder")
public class CreateRbdWorkOrderController {
	@Resource
	private MachineService machineService;
	@Resource
	private RawMaterialStoreRegService rawMaterialStoreRegService;
	@Resource
	private ProductionWorkOrderService productionWorkOrderService;

	@Resource
	private RbdWorkOrderInputService rbdWorkOrderInputService;

	@Resource
	private ProductionProcessService productionProcessService;
	@Resource
	private ItemService itemService;
	 /**
	   * This method returns createRbdWorkOrder.jsp.
	   * Fetch all RBD Machine Details and RBD Work order Numbers
	   * @param Model to set the attribute.
	   * @return createInvoice.jsp.
	   */
	@RequestMapping
	public String getSalesOrdersPage(Model model) {
		String processType="RBD";
		List<MachineDetails> machineList = machineService.findProcessMachineNo(processType);
		model.addAttribute("machine",machineList);	//set machine number to model attribute
		List<ProductionWorkOrder> productionWorkOrders = productionWorkOrderService.findByProcess(processType);
		ArrayList<String> pdnWoValuesList = new ArrayList<String>();
		for (int iterator = 0; iterator < productionWorkOrders.size(); iterator++) {
			ProductionWorkOrder productionWorkOrder = productionWorkOrders.get(iterator);
			pdnWoValuesList.add(productionWorkOrder.getWorkOrderNo());
		}
			Collections.sort(pdnWoValuesList,Collections.reverseOrder());
		
		model.addAttribute("workOrderNo",pdnWoValuesList);
		return "createRbdWorkOrder";
	}
	 /**
	   * This method to populate RBD Work Order Grid
	   * Fetch details of RBD Work Order
	   * @param poNo,filters,pageNumber,rowsPerPage,sortColName,sortOrder
	   * @return JqgridResponse<RawMaterialStoreRegDTO> response
	   */
	@RequestMapping(value="/records", produces="application/json", method=RequestMethod.POST)
	public @ResponseBody
	JqgridResponse<RawMaterialStoreRegDTO> records(
			@RequestParam(value="searchObject", required=false) String searchObject,
			@RequestParam("_search") Boolean search,
    		@RequestParam(value="filters", required=false) String filters,
			@RequestParam(value = "page", required = false) Integer pageNumber,
			@RequestParam(value = "rows", required = false) Integer rowsPerPage,
			@RequestParam(value = "sidx", required = false) String sortColName,
			@RequestParam(value = "sord", required = false, defaultValue = "asc") String sortOrder) {
		
		//JQ grid sorting column name  
		if(sortColName.equalsIgnoreCase("customerCode")){
			sortColName="purchaseOrderItem.purchaseOrder.customer.customerCode";
		}
		if(sortColName.equalsIgnoreCase("customerName")){
			sortColName="purchaseOrderItem.purchaseOrder.customer.customerName";
		}
		if(sortColName.equalsIgnoreCase("itemCode")){
			sortColName="purchaseOrderItem.item.itemCode";
		}
		
		if(sortColName.equalsIgnoreCase("itemDescription")){
			sortColName="purchaseOrderItem.item.itemDescription";
		}
		if(sortColName.equalsIgnoreCase("units")){
			sortColName="purchaseOrderItem.item.unit.units";
		}
		
		String []productType={"RB","RI","RA"};//product type of raw materials
		/*Method to fetch JQGRID paged records of Raw Material Store Register based on productType*/
		Page<RawMaterialStoreReg> storeReg = rawMaterialStoreRegService.getPagedStoreAndProductType(pageNumber - 1,
					rowsPerPage, sortColName, sortOrder,productType);
		/*Intialize JQ grid response of type RawMaterialStoreRegDTO*/	
		JqgridResponse<RawMaterialStoreRegDTO> response = new JqgridResponse<RawMaterialStoreRegDTO>();
		/*Method to set Invoice item list to InvoiceItemsDTO*/
		List<RawMaterialStoreRegDTO> storeDTOs = convertToStoreDTO(storeReg.getContent());
		response.setRows(storeDTOs);
		response.setRecords(Long.valueOf(storeReg.getTotalElements()).toString());
		response.setTotal(Long.valueOf(storeReg.getTotalPages()).toString());
		response.setPage(Integer.valueOf(storeReg.getNumber()+1).toString());

		return response;
 }
	 /**
	   * Method to set RawMaterialStoreReg records to DTO 
	   * @param List<RawMaterialStoreReg>
	   * @return List<RawMaterialStoreRegDTO>
	   */
	private List<RawMaterialStoreRegDTO> convertToStoreDTO(List<RawMaterialStoreReg> storeRegs) {
		List<RawMaterialStoreRegDTO> storeRegDTOs = new ArrayList<>();
		for(RawMaterialStoreReg storeReg : storeRegs) {
			List<Item> item= itemService.getAllRawMaterials();
			
			for(int i = 0 ; i < item.size(); i++){
				
				if(item.get(i).getItemCode().equalsIgnoreCase(storeReg.getPurchaseOrderItem().getItem().getItemCode())){
					RawMaterialStoreRegDTO storeRegDTO=new RawMaterialStoreRegDTO();
				    storeRegDTO.setRwStoreRegId(storeReg.getRwStoreRegId());
					storeRegDTO.setCustomerCode(storeReg.getPurchaseOrderItem().getPurchaseOrder().getCustomer().getCustomerCode());
					storeRegDTO.setCustomerName(storeReg.getPurchaseOrderItem().getPurchaseOrder().getCustomer().getCustomerName());
					storeRegDTO.setItemCode(storeReg.getPurchaseOrderItem().getItem().getItemCode());
					storeRegDTO.setItemDescription(storeReg.getPurchaseOrderItem().getItem().getItemDescription());
					storeRegDTO.setGrossWeight(storeReg.getGrossWeight());
					storeRegDTO.setTareWeight(storeReg.getTareWeight());
					storeRegDTO.setNetWeight(storeReg.getNetWeight());
					storeRegDTO.setBatchNo(storeReg.getBatchNo());
					storeRegDTO.setNoOfBags(storeReg.getNoOfBags());
					storeRegDTO.setTotalQty(storeReg.getTotalQty());
					storeRegDTO.setQcStatus(storeReg.getQcStatus());
					storeRegDTO.setQcSupervisor(storeReg.getQcSupervisor());
					storeRegDTO.setUnits(storeReg.getPurchaseOrderItem().getItem().getUnit().getUnits());
					storeRegDTOs.add(storeRegDTO);
				}//end of if loop
				
			}//end of for loop	
			
		}
		return storeRegDTOs;
	}
	 /**
	   * Method to save  RBD Work Order 
	   * @param raw material store regsiter Ids,RBD start dtae,RBD end date and machine no
	   * @return List<String>
	   */
	@RequestMapping(value = "/saveRbdWorkOrder", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	List<String> crud(
		    @RequestParam(value = "idsOfSelectedRows[]", required = false) Long[] idsSelected,
			@RequestParam  String rbdStartDate,
			@RequestParam  String rbdCompletionDate,
			@RequestParam  Long rbdWoMachineNo
			) {
		// Initialize variables
		List<String> newCreatedList=new ArrayList<>();
		Boolean pdnWorkOrderResult=false;
		Boolean updateWeight=false;
		Double inputWeight=Double.valueOf(0);
		Double outputWeight=Double.valueOf(0);
		Double balanceWeight=Double.valueOf(0);
			
		String newWorkOrderNo;
		String yearNo=String.valueOf(new DateTime().getYear()%1000);
		String monthNo="";
		if(new DateTime().getMonthOfYear()>9)
			monthNo=String.valueOf(new DateTime().getMonthOfYear());
		else
		   monthNo="0"+String.valueOf(new DateTime().getMonthOfYear());
	   String processType="RBD";
		List<ProductionWorkOrder> existRbdWorkOrderList=productionWorkOrderService.fetchLatestWorkOrder(processType);//fetch latest RBd work order No
		String existWorkOrderNo="";
		if(existRbdWorkOrderList.size()>0)
			existWorkOrderNo=existRbdWorkOrderList.get(0).getWorkOrderNo();
		
		if(!existWorkOrderNo.isEmpty()){
		String existWOYear= existWorkOrderNo.substring(1,3); 
		String existWOMonth=existWorkOrderNo.substring(3,5);
		String existWONoParse=existWorkOrderNo.substring(1,8);
		if((yearNo.equalsIgnoreCase(existWOYear)) && (monthNo.equalsIgnoreCase(existWOMonth))){
			int workOrderInt=Integer.parseInt(existWONoParse)+1;
			newWorkOrderNo="R"+String.valueOf(workOrderInt);
		}
		else{
			newWorkOrderNo="R"+yearNo+monthNo+"001";
		}
		}//end of if loop of checking existing sales no
		else{
			newWorkOrderNo="R"+yearNo+monthNo+"001";
		}
		//fetch logged in user name
		CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();;
		String userName = user.getFirstName()+" "+user.getLastName();
	 	List<ProductionProcess>processList=productionProcessService.findByProcessType("RBD");//fetch production process details
	 	Integer processId=1;
		if(processList.size()>0)
	 	 processId= processList.get(0).getProcessId();//fetch rbd process id
		
		List<ProductionWorkOrder>productionWoList=productionWorkOrderService.findByProductionWorkOrderNo(newWorkOrderNo);
		if(productionWoList.size()==0){
		SaveProductionWorkOrder saveProductionWorkOrder=new SaveProductionWorkOrder();
		ProductionWorkOrder pdnWorkOrder=saveProductionWorkOrder.saveProductionWorkOrder(newWorkOrderNo,rbdWoMachineNo,userName,rbdStartDate,rbdCompletionDate,processId); 
	  	
		ProductionWorkOrder craetedPdnWorkOrder=productionWorkOrderService.create(pdnWorkOrder);
		if(craetedPdnWorkOrder!=null)
			pdnWorkOrderResult=true;		 
     
		if(pdnWorkOrderResult==true) {
        	for(int i=0;i<idsSelected.length;i++){
        		List<RawMaterialStoreReg> rawMaterialStoreRegList=rawMaterialStoreRegService.findById(idsSelected[i]);//fetch raw material store register records by Id
        	    if(rawMaterialStoreRegList.size()>0){
        		RbdWorkOrderInputDTO rbdWorkOrderInputDTO=new RbdWorkOrderInputDTO();
        	    rbdWorkOrderInputDTO.setWorkOrderNo(newWorkOrderNo);
        	    rbdWorkOrderInputDTO.setRwStoreRegId(idsSelected[i]);
        	    rbdWorkOrderInputDTO.setGrossWeight(rawMaterialStoreRegList.get(0).getGrossWeight());
        	    rbdWorkOrderInputDTO.setNetWeight(rawMaterialStoreRegList.get(0).getNetWeight());
        	    rbdWorkOrderInputDTO.setTareWeight(rawMaterialStoreRegList.get(0).getTareWeight());
        	   
        	    RbdWorkOrderInput rbdWorkOrderInput=rbdWorkOrderInputDTO.getRbdWorkOrderInput();
        	    rbdWorkOrderInput.setUpdatedBy(userName);
        	    RbdWorkOrderInput createdRbdWoInput=rbdWorkOrderInputService.create(rbdWorkOrderInput);
        	     if(createdRbdWoInput!=null){
        	    	  inputWeight=inputWeight+rawMaterialStoreRegList.get(0).getTotalQty();
        	    	  balanceWeight=balanceWeight+rawMaterialStoreRegList.get(0).getTotalQty();

        	    	 updateWeight=productionWorkOrderService.updateWorkOrderWeight(newWorkOrderNo,inputWeight,outputWeight,balanceWeight);//method to update RBd work Order
        	    	 if(updateWeight==true)
        	    	 newCreatedList.add(newWorkOrderNo);//set newly created RBD work order number to list
        	     }//end of  if(createdRbdWoInput!=null) loop
        	    }// end of  if(rawMaterialStoreRegList.size()>0) loop
        	}//end of for loop
        }// end of if(pdnWorkOrderResult==true)
		}
		return newCreatedList;
	}
	 /**
	   * Method to update RBD Work Order 
	   * @param raw material store regsiter Ids,RBD Work order no
	   * @return StatusResponse
	   */
	@RequestMapping(value = "/updateRbdWorkOrder", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	StatusResponse  updateWorkOrder(
		    @RequestParam(value = "idsOfSelectedRows[]", required = false) Long[] idsSelected,
			@RequestParam  String rbdWorkOrderNo) {
		
		Boolean updateWoWeightResult=false;
		//fetch logged in username
		CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();;
	 	String rbdWoSupervisor = user.getFirstName()+" "+user.getLastName();
		List<ProductionWorkOrder> pdnWorkOrderList=productionWorkOrderService.findByProductionWorkOrderNo(rbdWorkOrderNo);//fetch production work order details by work order No
		Double inputWeight=Double.valueOf(0);
		Double outputWeight=Double.valueOf(0);
		Double balanceWeight=Double.valueOf(0);
		
		
        if(pdnWorkOrderList.size()>0){
        	inputWeight=pdnWorkOrderList.get(0).getInputWeight();
            outputWeight=pdnWorkOrderList.get(0).getOutputWeight();
            balanceWeight=pdnWorkOrderList.get(0).getBalanceWeight();
        }//end of  if(pdnWorkOrderList.size()>0) loop
		
		for(int i=0;i<idsSelected.length;i++){
    		List<RawMaterialStoreReg> rawMaterialStoreRegList=rawMaterialStoreRegService.findById(idsSelected[i]);
    	    if(rawMaterialStoreRegList.size()>0){
    		RbdWorkOrderInputDTO rbdWorkOrderInputDTO=new RbdWorkOrderInputDTO();
    	    rbdWorkOrderInputDTO.setWorkOrderNo(rbdWorkOrderNo);
    	    rbdWorkOrderInputDTO.setRwStoreRegId(idsSelected[i]);
    	    rbdWorkOrderInputDTO.setGrossWeight(rawMaterialStoreRegList.get(0).getGrossWeight());
    	    rbdWorkOrderInputDTO.setNetWeight(rawMaterialStoreRegList.get(0).getNetWeight());
    	    rbdWorkOrderInputDTO.setTareWeight(rawMaterialStoreRegList.get(0).getTareWeight());
    	   
    	    RbdWorkOrderInput rbdWorkOrderInput=rbdWorkOrderInputDTO.getRbdWorkOrderInput();
    	    rbdWorkOrderInput.setUpdatedBy(rbdWoSupervisor);
    	    RbdWorkOrderInput createdRbdWoInput=rbdWorkOrderInputService.create(rbdWorkOrderInput);//method to create rbd work order
    	     if(createdRbdWoInput!=null){
    	    	 inputWeight=inputWeight+rawMaterialStoreRegList.get(0).getTotalQty();//caculating total input weight of RBD work order
    	    	 balanceWeight=inputWeight-outputWeight;//calculating total output weight of rbd
    	    	 updateWoWeightResult=productionWorkOrderService.updateWorkOrderWeight(rbdWorkOrderNo, inputWeight, outputWeight, balanceWeight);
    	     }//end of  if(createdRbdWoInput!=null) loop
           	}//end of  if(rawMaterialStoreRegList.size()>0) loop
    	}//end of for loop
	return new StatusResponse(updateWoWeightResult);
	}
	
	
	}
