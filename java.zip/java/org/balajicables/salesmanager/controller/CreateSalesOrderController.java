package org.balajicables.salesmanager.controller;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.balajicables.salesmanager.CustomUser;
import org.balajicables.salesmanager.common.JqgridResponse;
import org.balajicables.salesmanager.common.StatusResponse;
import org.balajicables.salesmanager.dto.OrderDTO;
import org.balajicables.salesmanager.model.Customer;
import org.balajicables.salesmanager.model.OrderStatus;
import org.balajicables.salesmanager.model.SalesOrder;
import org.balajicables.salesmanager.service.CustomerService;
import org.balajicables.salesmanager.service.OrderService;
import org.balajicables.salesmanager.service.OrderStatusService;
import org.balajicables.salesmanager.utils.Utility;
import org.joda.time.DateTime;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
/**
* This class demonstrates Create Sales Order Process.
* @author Abin Sam
*/
@Controller
@RequestMapping("/orders")
public class CreateSalesOrderController {
	
	@Resource
	private OrderService orderService;    
	@Resource
	private OrderStatusService orderStatusService;
	@Resource
	private CustomerService customerService;
	 /**
	   * This method returns customerOrder.jsp.
	   * Fetch all customers to create sales order
	   * @param Model to set the attribute.
	   * @return createInvoice.jsp.
	   */
	@RequestMapping
	public String getItemsPage(Model model) {
		List<Customer> customers = customerService.findAll();//fetch customer details
		model.addAttribute("customers", customers);//set customer to model attribute
		return "customerOrder";
	}
	 /**
	   * This method to fetch sales orders based on customer
	   * @param customerId
	   * @return sales orders list
	   */
	@RequestMapping(value="/orderId/{customerId}", produces="application/json", method=RequestMethod.POST)
	public @ResponseBody
	List<String> getSalesOrderNo(@PathVariable("customerId") Long customerId,Model model) {
		ArrayList<String> salesOrderNoList = new ArrayList<>();
		List<SalesOrder> soDetails = orderService.findByCustomerId(customerId);//fetch sales order based on customer Id
		for(int iterator=0;iterator < soDetails.size();iterator++ ){
			String salesOrderNo = soDetails.get(iterator).getOrderId();
			if(!salesOrderNoList.contains(salesOrderNo)){
				salesOrderNoList.add(salesOrderNo);
			}//end of if loop
		}//end of for loop
		return salesOrderNoList;
	}
	//unused method
	@RequestMapping(value = "/{id}", method=RequestMethod.PUT)
	@ResponseStatus(HttpStatus.NO_CONTENT)
	public void updateOrder(@PathVariable("id") long id,
			@Valid OrderDTO orderDTO) {
		
	}
    //unused method
	@RequestMapping(value="/{id}", method=RequestMethod.DELETE)
	@ResponseStatus(HttpStatus.NO_CONTENT)
	public void deleteOrder(@PathVariable("id") long id) {
		
	}	
	 /**
	   * This method to throw new BindException
	   * @param OrderDTO,BindingResult,HttpServletResponse
	   */
	@RequestMapping(method=RequestMethod.POST)
	@ResponseStatus(HttpStatus.CREATED)
	public @ResponseBody OrderDTO createOrder(@Valid OrderDTO orderDTO, BindingResult result,
					HttpServletResponse response) throws BindException {
		if(result.hasErrors()) {
			throw new BindException(result);
		}
		return null;
	}
	 /**
	   * This method is to fetch pending sales order details based on customer selected
	   * Fetch all sales order based on customer id
	   * @param customerId,search,filters,pageNumber,rowsPerPage,sortColName,sortOrder
	   * @return JqgridResponse<OrderDTO>
	   */
	@RequestMapping(value="/records/{customerId}", produces="application/json", method=RequestMethod.GET)
	public @ResponseBody
	JqgridResponse<OrderDTO> records(
			@PathVariable("customerId") long customerId,
    		@RequestParam("_search") Boolean search,
    		@RequestParam(value="filters", required=false) String filters,
			@RequestParam(value = "page", required = false) Integer pageNumber,
			@RequestParam(value = "rows", required = false) Integer rowsPerPage,
			@RequestParam(value = "sidx", required = false) String sortColName,
			@RequestParam(value = "sord", required = false, defaultValue = "asc") String sortOrder) {
		
		if(sortColName.equalsIgnoreCase("status")){
			sortColName="orderStatus.status";
		}
		String salesOrderStatus[]={"Created","Pending"};//String array of order status
		/*Method to fetch JQGRID paged records of Sales Order based on customerId,salesOrderStatus*/
		Page<SalesOrder>orders=orderService.getPagedCustomerPendingSalesorders(customerId,salesOrderStatus,pageNumber - 1,
				rowsPerPage, sortColName, sortOrder);
		/*Intialize JQ grid response of type OrderDTO*/
		JqgridResponse<OrderDTO> response = new JqgridResponse<OrderDTO>();
		/*Method to set Salesorder list to OrderDTO*/
		List<OrderDTO> orderDTOs = convertToDTO(orders.getContent());
		response.setRows(orderDTOs);
		response.setRecords(Long.valueOf(orders.getTotalElements()).toString());
		response.setTotal(Long.valueOf(orders.getTotalPages()).toString());
		response.setPage(Integer.valueOf(orders.getNumber()+1).toString());

		return response;
	}
	 /**
	   * Method to Create/Edit Sales Order
	   * @param operation(edit/create),sales order Id,poDetails,modeOfReceipt,orderRecDate,
	   *        orderDeliveryDate,orderAcceptanceDate,createdTime,targetDate,customerId
	   *        createdBy,mailStatus,lmeDetails
	   * @return StatusResponse
	   */	
	@RequestMapping(value = "/crud", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	StatusResponse crud(Model model, @RequestParam String id,
			@RequestParam String oper,
			@RequestParam(required = false) String poDetails,
			@RequestParam(required = false) String modeOfReceipt,
			@RequestParam(required = false) String orderRecDate,
			@RequestParam(required = false) String orderDeliveryDate,
			@RequestParam(required = false) String orderAcceptanceDate,
			@RequestParam (required=false)  String createdTime,
			@RequestParam(required = false) String targetDate,
			@RequestParam(required = true) long customerId,
			@RequestParam(required = true) String createdBy,
			@RequestParam(required = true) String mailStatus,
			@RequestParam(required = false) String lmeDetails
			
			) {
        /*fetch logged in user name*/
		CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();;
    	String firstName= user.getFirstName();
		String lastName=user.getLastName();
		String name=firstName+" "+lastName;
		Boolean saveResult=false;
 		Boolean result = false;
 	    OrderDTO orderDTO = new OrderDTO();
		if(id != null && !"".equalsIgnoreCase(id.trim()) &&
				!"_empty".equalsIgnoreCase(id.trim()) && 
				!"new_row".equalsIgnoreCase(id.trim())) {
			/*Method to fetch sales order list based on the id*/
			List<SalesOrder> soOrderList=orderService.findBySalesOrderNoId(id);
			orderDTO.setOrderId(id);
			if(soOrderList.size()>0){
				orderDTO.setCreatedTime(soOrderList.get(0).getCreatedTime().toString());
				orderDTO.setCreatedBy(soOrderList.get(0).getCreatedBy());
				orderDTO.setInputQuantity(soOrderList.get(0).getInputQuantity());
				orderDTO.setOrderStatusId(soOrderList.get(0).getOrderStatus().getOrderStatusId());
				orderDTO.setCustomerId(soOrderList.get(0).getCustomer().getCustomerId());
			}//end of if(soOrderList.size()>0) loop
			orderDTO.setPoDetails(poDetails);
			orderDTO.setMailStatus(mailStatus);
			orderDTO.setLmeDetails(lmeDetails);
			
			orderDTO.setOrderDeliveryDate(orderDeliveryDate);
			orderDTO.setOrderAcceptanceDate(orderAcceptanceDate);
			orderDTO.setOrderRecDate(orderRecDate);
			orderDTO.setModeOfReceipt(modeOfReceipt);
			java.util.Date date= new java.util.Date();
			orderDTO.setUpdatedTime(new Timestamp(date.getTime()).toString());//formatting updated timestamp
		    orderDTO.setUpdatedBy(name);
		    orderDTO.setInputQuantity(0.0);
	        
			 if(targetDate=="" || targetDate ==null){
				 if(orderRecDate!=null && orderRecDate!=""){
					 //Calculating target date( 8 days after order received date)					 
			 DateTime dtOrg = new DateTime(Utility.formDateFormatter.parseDateTime(orderRecDate).toDate());
			 DateTime dtPlusOne = dtOrg.plusDays(8);
			 orderDTO.setTargetDate(Utility.formDateFormatter.print(dtPlusOne));
				 }
			 }
			 else
				orderDTO.setTargetDate(targetDate);
			
			 saveResult=true;
		}//end of if(orderId!=null) loop
		else{
			String newSalesOrderNo;
			String yearNo=String.valueOf(new DateTime().getYear()%1000);
			String monthNo="";
			if(new DateTime().getMonthOfYear()>9)
				monthNo=String.valueOf(new DateTime().getMonthOfYear());
			else
			   monthNo="0"+String.valueOf(new DateTime().getMonthOfYear());
		    /*Method to fetch latest sales order number*/
			List<SalesOrder> existSalesOrderListo=orderService.fetchLatestSalesOrder();
			
			String existOrderNo="";
			if(existSalesOrderListo.size()>0)
				existOrderNo=existSalesOrderListo.get(0).getOrderId();
			
			if(!existOrderNo.isEmpty()){
				String existOrderYear= existOrderNo.substring(1,3); 
				String existOrderMonth=existOrderNo.substring(3,5);
				String existSoNoParse=existOrderNo.substring(1,8);
				
				if((yearNo.equalsIgnoreCase(existOrderYear)) && (monthNo.equalsIgnoreCase(existOrderMonth))){
					int salesOrderInt=Integer.parseInt(existSoNoParse)+1;
					newSalesOrderNo="S"+String.valueOf(salesOrderInt);
				}
				else{
					newSalesOrderNo="S"+yearNo+monthNo+"001";
				}
			}//end of if loop of checking existing sales no
			else{
				newSalesOrderNo="S"+yearNo+monthNo+"001";
			}//end of else loop
			List<SalesOrder>soOrderList=orderService.findBySalesOrderNoId(newSalesOrderNo);
			if(!(soOrderList.size()>0)){
				orderDTO.setOrderId(newSalesOrderNo);
				orderDTO.setCreatedBy(name);
				  String status="Created";
					List<OrderStatus> statusIdList=orderStatusService.findByStatus(status);
					if(statusIdList!=null)
						orderDTO.setOrderStatusId(statusIdList.get(0).getOrderStatusId());
					orderDTO.setMailStatus("No");
					orderDTO.setLmeDetails(lmeDetails);
					orderDTO.setPoDetails(poDetails);
					orderDTO.setCustomerId(customerId);
					orderDTO.setOrderDeliveryDate(orderDeliveryDate);
					orderDTO.setOrderAcceptanceDate(orderAcceptanceDate);
					orderDTO.setOrderRecDate(orderRecDate);
					orderDTO.setModeOfReceipt(modeOfReceipt);
					java.util.Date date= new java.util.Date();
					orderDTO.setUpdatedTime(new Timestamp(date.getTime()).toString());
				    orderDTO.setUpdatedBy(name);
				    orderDTO.setInputQuantity(0.0);
			        
					 if(targetDate=="" || targetDate ==null){
						 if(orderRecDate!=null && orderRecDate!=""){
							 //calculating target date
					 DateTime dtOrg = new DateTime(Utility.formDateFormatter.parseDateTime(orderRecDate).toDate());
					 DateTime dtPlusOne = dtOrg.plusDays(8);
					 orderDTO.setTargetDate(Utility.formDateFormatter.print(dtPlusOne));
						 }//end of if loop
					 }
					 else
						 
							orderDTO.setTargetDate(targetDate);
					 saveResult=true;
		  }//end of if(!(soOrderList.size()>0)) loop
		}
		SalesOrder order = orderDTO.getOrder();
		switch (oper) {
		case "add":
			if(saveResult==true){
			SalesOrder createdOrder = orderService.create(order);//method to create sales order
			if (createdOrder != null) {
				result = true;
			}//end of if loop
			}
			break;
		case "edit":
			if(saveResult==true){
			result = orderService.update(order);//method to update sales order
			}//end of if loop
			break;
		case "del":
			String orderIdToDelete = id;
			result = orderService.delete(orderIdToDelete);//method to delete sales order
			break;
		}//end of switch loop
		return new StatusResponse(result);
	}
	 /**
	   * Method to set SalesOrder records to DTO 
	   * @param List<SalesOrder>
	   * @return List<OrderDTO>
	   */
	private List<OrderDTO> convertToDTO(List<SalesOrder> orders) {
		List<OrderDTO> orderDTOs = new ArrayList<>();
		for(SalesOrder order : orders) {
			if((!(order.getOrderId().equalsIgnoreCase("BS000001")))){
			OrderDTO orderDTO = new OrderDTO();
			orderDTO.setOrderId(order.getOrderId());
			if(order.getOrderRecDate()!=null)
			orderDTO.setOrderRecDate(Utility.formDateFormatter.print(order.getOrderRecDate().getTime()));
			if(order.getOrderDeliveryDate()!=null)
			orderDTO.setOrderDeliveryDate(Utility.formDateFormatter.print(order.getOrderDeliveryDate().getTime()));
			if(order.getOrderAcceptanceDate()!=null)
			orderDTO.setOrderAcceptanceDate(Utility.formDateFormatter.print(order.getOrderAcceptanceDate().getTime()));
			if(order.getTargetDate()!=null)
			orderDTO.setTargetDate(Utility.formDateFormatter.print(order.getTargetDate().getTime()));
			orderDTO.setPoDetails(order.getPoDetails());
			orderDTO.setModeOfReceipt(order.getModeOfReceipt());
			orderDTO.setOrderStatusId(order.getOrderStatus().getOrderStatusId());
			orderDTO.setStatus(order.getOrderStatus().getStatus());
			if(order.getCreatedTime()!=null)
			orderDTO.setCreatedTime(order.getCreatedTime().toString());
			if(order.getUpdatedTime()!=null)
			orderDTO.setUpdatedTime(order.getUpdatedTime().toString());
			orderDTO.setUpdatedBy(order.getUpdatedBy());
			orderDTO.setCreatedBy(order.getCreatedBy());
			orderDTO.setMailStatus(order.getMailStatus());
			orderDTO.setLmeDetails(order.getLmeDetails());
		    orderDTOs.add(orderDTO);
			}//end of if loop
		}
		return orderDTOs;
	}
	 /**
	   * Method to submit SalesOrder 
	   * @param SalesOrder id
	   * @return StatusResponse
	   */
	@RequestMapping(value = "/submitSoItems/{orderId}", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	StatusResponse submitPoItems(
			@PathVariable("orderId") String orderId
			) {
	
		Boolean updateSoStatusResult=false;
		updateSoStatusResult=orderService.updateSoStatus(orderId);//update sales order
		return new StatusResponse(updateSoStatusResult);
	}
	 /**
	   * Method to delete SalesOrder (set status of sales order to Cancelled)
	   * @param SalesOrder id
	   * @return StatusResponse
	   */
	@RequestMapping(value = "/delete/{orderId}", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	StatusResponse deleteSalesOrder(@PathVariable("orderId") String orderId) {
		    Boolean setCancelledStatusResult=false;
		    int statusId=0;
		    String status="Cancelled";
			List<OrderStatus> statusIdList=orderStatusService.findByStatus(status);//fetch sales order status list
			if(statusIdList!=null)
			statusId=statusIdList.get(0).getOrderStatusId();//get status id
		    setCancelledStatusResult=orderService.updateOrderStatus(orderId, statusId);//update sales order status
		    return new StatusResponse(setCancelledStatusResult);
	}	

}