package org.balajicables.salesmanager.controller;

import java.util.ArrayList;
import java.util.List;
import javax.annotation.Resource;
import org.balajicables.salesmanager.common.JqgridResponse;
import org.balajicables.salesmanager.common.StatusResponse;
import org.balajicables.salesmanager.dto.CustomerDTO;
import org.balajicables.salesmanager.dto.TaxRateDTO;
import org.balajicables.salesmanager.model.Customer;
import org.balajicables.salesmanager.model.TaxRate;
import org.balajicables.salesmanager.service.CustomerService;
import org.balajicables.salesmanager.service.TaxRateService;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
/**
* This class demonstrates Customer fetch/Update/Create Process.
* @author Abin Sam
*/
@Controller
@RequestMapping("/customers")
public class CustomerController {
	@Resource 
	private CustomerService customerService;
	@Resource 
	private TaxRateService taxRateService;
	
	 /**
	   * This method returns customerConfiguration.jsp.
	   * Fetch all customers
	   * @param Model to set the attribute.
	   * @return customerConfiguration.jsp.
	   */
	@RequestMapping(method = RequestMethod.GET)
	public String getItemsPage(Model model) {
		
		List<Customer> customers = customerService.findAll();//fetch all customers
		model.addAttribute("customers", customers);//set customers to model attribute
		return "customerConfiguration";
	}
	
	 /**
	   * This method to populate Customer details grid
	   * Fetch details of Customers
	   * @param filters,pageNumber,rowsPerPage,sortColName,sortOrder
	   * @return JqgridResponse<CustomerDTO> response
	   */
	@RequestMapping(value="/records", produces="application/json")
	public @ResponseBody
	JqgridResponse<CustomerDTO> records(
    		@RequestParam("_search") Boolean search,
    		@RequestParam(value="filters", required=false) String filters,
			@RequestParam(value = "page", required = false) Integer pageNumber,
			@RequestParam(value = "rows", required = false) Integer rowsPerPage,
			@RequestParam(value = "sidx", required = false) String sortColName,
			@RequestParam(value = "sord", required = false, defaultValue = "asc") String sortOrder) {
        //fetch customers
		Page<Customer> customers = customerService.getPagedCustomers(pageNumber - 1,
				rowsPerPage, sortColName, sortOrder);
		
		JqgridResponse<CustomerDTO> response = new JqgridResponse<CustomerDTO>();
		List<CustomerDTO> customerDTOs = convertToDTO(customers.getContent());
		response.setRows(customerDTOs);
		response.setRecords(Long.valueOf(customers.getTotalElements()).toString());
		response.setTotal(Long.valueOf(customers.getTotalPages()).toString());
		response.setPage(Integer.valueOf(customers.getNumber()+1).toString());

		return response;
	}
	
	
	 /**
	   * Method to set customers records to DTO 
	   * @param List<Customer>
	   * @return List<CustomerDTO>
	   */
	private List<CustomerDTO> convertToDTO(List<Customer> customers) {
		List<CustomerDTO> customerDTOs = new ArrayList<>();
		for(Customer customer : customers) {
			
			CustomerDTO customerDTO = new CustomerDTO();
			
			customerDTO.setCustomerId(customer.getCustomerId());
			customerDTO.setCustomerName(customer.getCustomerName());
			customerDTO.setCustomerCode(customer.getCustomerCode());
			customerDTO.setContactPerson(customer.getContactPerson());
			customerDTO.setContactNo(customer.getContactNo());
			customerDTO.setAltContactNo(customer.getAltContactNo());
			customerDTO.setEmail(customer.getEmail());
			customerDTO.setAddress(customer.getAddress());
			customerDTO.setCity(customer.getCity());
			customerDTO.setState(customer.getState());
			customerDTO.setCountry(customer.getCountry());
			customerDTO.setPincode(customer.getPincode());
			customerDTO.setVatRegNo(customer.getVatRegNo());
			customerDTO.setCstRegNo(customer.getCstRegNo());
			customerDTO.setEccNo(customer.getEccNo());
			customerDTO.setTinNo(customer.getTinNo());
			customerDTO.setPanNo(customer.getPanNo());
	

			
			customerDTOs.add(customerDTO);
		}
		return customerDTOs;
	}

	@RequestMapping(value="/{id}", method=RequestMethod.DELETE)
	@ResponseStatus(HttpStatus.NO_CONTENT)
	public void deleteCustomer(@PathVariable("id") long customerIdToDelete) {
		
		customerService.delete(customerIdToDelete);
	}
	
	@RequestMapping(value = "/{id}", method=RequestMethod.PUT)
	@ResponseStatus(HttpStatus.NO_CONTENT)
	public void updateOrder(@PathVariable("id" ) long id,
			@RequestBody Customer customer) {
		customerService.update(customer);
	}
	
	
	 /**
	   * crud functionality of customer 
	   * @param oper(add/edit/del),customerId,customerName,customerCode,contactPerson,contactNo,altContactNo
	   *        email,address,city,state,country,pincode,vatRegNo,cstRegNo,eccNo,tinNo,panNo,frieght
	   * @return StatusResponse
	   */
	@RequestMapping(value = "/crud", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	StatusResponse create(@RequestParam String id,
			@RequestParam String oper,
			@RequestParam(required = false) String customerName,
			@RequestParam(required = false) String customerCode,
			@RequestParam(required = false) String contactPerson,
			@RequestParam(required = false) String contactNo,
			@RequestParam(required = false) String altContactNo,
			@RequestParam(required = false) String email,
			@RequestParam(required = false) String address,
			@RequestParam(required = false) String city,
			@RequestParam(required = false) String state,
			@RequestParam(required = false) String country,
			@RequestParam(required = false) String pincode,
			@RequestParam(required = false) String vatRegNo,
			@RequestParam(required = false) String cstRegNo,
			@RequestParam(required = false) String eccNo,
			@RequestParam(required = false) String tinNo,
			@RequestParam(required = false) String panNo,
			@RequestParam(required = false) String frieght
			
			) {
		Boolean result = false;
		//encapsulate atributes to customer DTO
		Customer customer = encapsulateCustomer(id, customerName, customerCode,
				contactPerson,contactNo,altContactNo,email,address, city, state,
				country,pincode,vatRegNo,cstRegNo,eccNo,tinNo,panNo,frieght);
	
		
		switch (oper) {
		case "add":
			result = customerService.create(customer);//method to create customer
			List<Customer>customerDetails=customerService.findByCustomerCode(customerCode);
			if(customerDetails.size()>0){
				TaxRateDTO taxRateDTO=new TaxRateDTO();
				taxRateDTO.setCustomerId(customerDetails.get(0).getCustomerId());
				taxRateDTO.setExciseDuty((float) 0);
				taxRateDTO.setEduCess((float) 0);
				taxRateDTO.setHigherEduCess((float) 0);
				taxRateDTO.setCst((float) 2);
				taxRateDTO.setVat((float) 0);
				taxRateDTO.setFreight("IMMEDIATE");
				taxRateDTO.setPaymentTerms("FREIGHT PAID");
                TaxRate taxRate=taxRateDTO.getTaxRate();	
                if(result==true)
                taxRateService.create(taxRate);//method to create tax
			}//end of if(customerDetails.size()>0) loop
			break;
		case "edit":
			result = customerService.update(customer);//method to update customer
			break;
		case "del":
			Long customerIdToDelete = Long.parseLong(id);
			List<TaxRate> taxDetailsList= taxRateService.findByCustomerId(customerIdToDelete);//fetch tax details based on customer id
			Long taxId = null;
			if(taxDetailsList.size()>0)
				taxId = taxDetailsList.get(0).getTaxRateId();//get tax rate
			if(taxId!=null)		
			taxRateService.delete(taxId);//method to delete tax record
			result = customerService.delete(customerIdToDelete);//method to delete customer record
			
			break;
		}//end of switch loop
		return new StatusResponse(result);
	}

	 /**
	   * method to encapsulate customer details to DTO
	   * @param oper(add/edit/del),customerId,customerName,customerCode,contactPerson,contactNo,altContactNo
	   *        email,address,city,state,country,pincode,vatRegNo,cstRegNo,eccNo,tinNo,panNo,frieght
	   * @return StatusResponse
	   */
	private Customer encapsulateCustomer(String id, String customerName,
			String customerCode, String contactPerson, String contactNo,
			String altContactNo, String email, String address, String city,
			String state, String country, String pincode, String vatRegNo,
			String cstRegNo, String eccNo, String tinNo, String panNo,String frieght) {
		Customer customer = new Customer();
		if(id != null && !"".equalsIgnoreCase(id.trim()) &&
				!"_empty".equalsIgnoreCase(id.trim())) {
			customer.setCustomerId(Long.parseLong(id));
		}//end of if loop
		customer.setCustomerName(customerName);
		customer.setCustomerCode(customerCode);
		customer.setContactPerson(contactPerson);
		customer.setContactNo(contactNo);
		customer.setAltContactNo(altContactNo);
		customer.setEmail(email);
		customer.setAddress(address);
		customer.setCity(city);
		customer.setState(state);
		customer.setCountry(country);
		if(pincode != null && !"".equalsIgnoreCase(pincode.trim())) {
			customer.setPincode(Integer.parseInt(pincode));
		}//end of if loop
		customer.setVatRegNo(vatRegNo);
		customer.setCstRegNo(cstRegNo);
		customer.setEccNo(eccNo);
		customer.setTinNo(tinNo);
		customer.setPanNo(panNo);
		
		return customer;
	}


	 /**
	   * method to set customerService

	   */
	public void setCustomerService(CustomerService customerService) {
		this.customerService = customerService;
	}

	
	 /**
	   * Method to fetch customer details 
	   * @param customerId
	   * @return List<String> 
	   */
	@RequestMapping(value = "/customerDetails", produces = "application/json",method=RequestMethod.POST)
	public @ResponseBody
	List<String> fetchCustomer(@RequestParam("customerId") Long customerId) {
		
		List<String> customerList=new ArrayList<>();
		List<Customer> customerDetails=	customerService.findById(customerId);//fetch customer details based on id
			
	if(customerDetails.size()>0){
		customerList.add(customerDetails.get(0).getCustomerName());
		customerList.add(customerDetails.get(0).getAddress());
		customerList.add(customerDetails.get(0).getTinNo());
		customerList.add(customerDetails.get(0).getCstRegNo());
	    Long custId=customerDetails.get(0).getCustomerId();
	    List<TaxRate>taxDetailsList=taxRateService.findByCustomerId(custId);
	    if(taxDetailsList.size()>0 )
	    	customerList.add(taxDetailsList.get(0).getPaymentTerms());
	}//end of if (customerDetails.size()>0) loop
	return customerList;
		
	}
	
	
	 /**
	   * Method to fetch customer details for grid
	   * @param customerId,filters,pageNumber,rowsPerPage,sortColName,sortOrder
	   * @return JqgridResponse<CustomerDTO>
	   */
	@RequestMapping(value = "/getCustomerDetails", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	JqgridResponse<CustomerDTO> getCustomerDetails(
			@RequestParam("customerId") Long customerId,
			@RequestParam(value = "filters", required = false) String filters,
			@RequestParam(value = "page", required = false) Integer pageNumber,
			@RequestParam(value = "rows", required = false) Integer rowsPerPage,
			@RequestParam(value = "sidx", required = false) String sortColName,
			@RequestParam(value = "sord", required = false, defaultValue = "asc") String sortOrder) {
			//fetch customer details based on customer Id
		 Page<Customer> customerDetails=customerService.findById(customerId, pageNumber-1, rowsPerPage,
					sortColName, sortOrder);
			
		JqgridResponse<CustomerDTO> response = new JqgridResponse<CustomerDTO>();
		List<CustomerDTO> customerDTOs = convertToDTO(customerDetails.getContent());
        response.setRows(customerDTOs);
		response.setRecords(Long.valueOf(customerDetails.getTotalElements()).toString());
		response.setTotal(Long.valueOf(customerDetails.getTotalPages()).toString());
		response.setPage(Integer.valueOf(customerDetails.getNumber() + 1).toString());

		return response;
	}
	
	 /**
	   * Method to fetch tax details
	   * @param customerId
	   * @return List<String>
	   */
	@RequestMapping(value = "/taxDetails", produces = "application/json",method=RequestMethod.POST)
	public @ResponseBody
	List<String> fetchTaxDetails(@RequestParam("customerId") Long customerId) {
		List<String> taxList=new ArrayList<String>();
		List<TaxRate> taxDetails=	taxRateService.findByCustomerId(customerId);//fetch tax details based on customer Id
	String customerName="";
	String address="";
	String tinNo="";
	String cstRegNo="";
	String salesTax="";
	String exciseDuty="";
	String eduCess="";
	String higherEduCess="";
	String vat="";
	String cst="";
	String paymentTerms="";
	String freight="";
		
	if(taxDetails.size()>0){
		if(taxDetails.get(0).getCustomer().getCustomerName()!=null)
			customerName=taxDetails.get(0).getCustomer().getCustomerName();
		if(taxDetails.get(0).getCustomer().getAddress()!=null)
			address=taxDetails.get(0).getCustomer().getAddress();
		if(taxDetails.get(0).getCustomer().getTinNo()!=null)
			tinNo=taxDetails.get(0).getCustomer().getTinNo();
		if(taxDetails.get(0).getCustomer().getCstRegNo()!=null)
			 cstRegNo=taxDetails.get(0).getCustomer().getCstRegNo();
		if(taxDetails.get(0).getExciseDuty()!=null)
			 exciseDuty=taxDetails.get(0).getExciseDuty().toString();
		if(taxDetails.get(0).getEduCess()!=null)
			eduCess=taxDetails.get(0).getEduCess().toString();					
		if(taxDetails.get(0).getHigherEduCess()!=null)
			higherEduCess=taxDetails.get(0).getHigherEduCess().toString();	
		if(taxDetails.get(0).getVat()!=null)
			vat=taxDetails.get(0).getVat().toString();	 
		if(taxDetails.get(0).getCst()!=null)
			cst=taxDetails.get(0).getCst().toString();	
		if(taxDetails.get(0).getPaymentTerms()!=null)
			paymentTerms=taxDetails.get(0).getPaymentTerms();
		if(taxDetails.get(0).getFreight()!=null)
			freight=taxDetails.get(0).getFreight();
		
	}
	//add details to list
		taxList.add(customerName);
		taxList.add(address);
		taxList.add(tinNo);
		taxList.add(cstRegNo);
		taxList.add(salesTax);
		taxList.add(exciseDuty);
		taxList.add(eduCess);
		taxList.add(higherEduCess);
		taxList.add(vat);
		taxList.add(cst);
		taxList.add(paymentTerms);
		taxList.add(freight);

	return taxList;
		
	}
	
}
