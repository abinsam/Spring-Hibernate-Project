package org.balajicables.salesmanager.controller;

import java.util.ArrayList;
import java.util.List;
import javax.annotation.Resource;
import org.balajicables.salesmanager.common.CustomerPartNoMapper;
import org.balajicables.salesmanager.common.JqgridFilter;
import org.balajicables.salesmanager.common.JqgridObjectMapper;
import org.balajicables.salesmanager.common.JqgridResponse;
import org.balajicables.salesmanager.common.StatusResponse;
import org.balajicables.salesmanager.dto.CustomerPartNoDTO;
import org.balajicables.salesmanager.model.Customer;
import org.balajicables.salesmanager.model.CustomerPartNo;
import org.balajicables.salesmanager.model.Item;
import org.balajicables.salesmanager.service.CustomerPartNoService;
import org.balajicables.salesmanager.service.CustomerService;
import org.balajicables.salesmanager.service.ItemService;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

@Controller
@RequestMapping("/partNo")

public class CustomerPartNoController {
	
	@Resource
	private CustomerService customerService;
	
	@Resource
	private CustomerPartNoService customerPartNoService;
	
	@Resource
	private ItemService itemService;
	
	 /**
	   * This method returns customerPartNo.jsp.
	   * Fetch all customers 
	   * @param Model to set the attribute.
	   * @return customerPartNo.jsp.
	   */
	
	@RequestMapping(method = RequestMethod.GET)
    public String rawMaterialStoreRegister(Model model) {
		List<Customer> customers = customerService.findAll();
		model.addAttribute("customers", customers);
		
		return "customerPartNo";

    }
	
	 /**
	   * This method to populate Customer Part No records in Grid
	   * Fetch details of Customer Part No
	   * @param filters,pageNumber,rowsPerPage,sortColName,sortOrder
	   * @return JqgridResponse<CustomerPartNoDTO> response
	   */
	
	@RequestMapping(value = "/records", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	JqgridResponse<CustomerPartNoDTO> records(
			@RequestParam(value = "searchObject", required = false) String searchObject,
			@RequestParam("_search") Boolean search,
			@RequestParam(value = "filters", required = false) String filters,
			@RequestParam(value = "page", required = false) Integer pageNumber,
			@RequestParam(value = "rows", required = false) Integer rowsPerPage,
			@RequestParam(value = "sidx", required = false) String sortColName,
			@RequestParam(value = "sord", required = false, defaultValue = "asc") String sortOrder) {
		/*grid column sorting*/
		  if(sortColName.equalsIgnoreCase("itemCode")){
				sortColName="items.itemCode";
			}
		  if(sortColName.equalsIgnoreCase("itemDescription")){
				sortColName="items.itemDescription";
			}
		  if(sortColName.equalsIgnoreCase("customerName")){
				sortColName="customer.customerName";
			}
		  if(sortColName.equalsIgnoreCase("customerCode")){
				sortColName="customer.customerCode";
			}
		 if (searchObject != null && !(searchObject.equalsIgnoreCase("allSearch"))) {

			return getFilteredRecords(searchObject, pageNumber - 1,
					rowsPerPage, sortColName, sortOrder);//fetch customer patch number details based on search
		} else {
			//fetch customer patch number details
			Page<CustomerPartNo> customerPartNos = customerPartNoService.getPagedTaxes(pageNumber - 1,rowsPerPage, sortColName, sortOrder);
			
			
			JqgridResponse<CustomerPartNoDTO> response = new JqgridResponse<CustomerPartNoDTO>();
			List<CustomerPartNoDTO> customerPartNoDTOs = convertToDTO(customerPartNos.getContent());
			response.setRows(customerPartNoDTOs);
			response.setRecords(Long.valueOf(customerPartNos.getTotalElements()).toString());
			response.setTotal(Long.valueOf(customerPartNos.getTotalPages()).toString());
			response.setPage(Integer.valueOf(customerPartNos.getNumber()+1).toString());

			return response;
		}
	}
	
	 /**
	   * This method to set filtered customer part no details to DTO
	   * Fetch details of customer part no
	   * @param filters,pageNumber,rowsPerPage,sortColName,sortOrder
	   * @return JqgridResponse<CustomerPartNoDTO> response
	   */
	
	private JqgridResponse<CustomerPartNoDTO> getFilteredRecords(String filters,
			int pagenumber, Integer rows, String sortColName, String sortOrder) {

		
		Long qCustomerId = null;
	    String qitemCode = null;

		JqgridFilter jqgridFilter = JqgridObjectMapper.map(filters);
		for (JqgridFilter.Rule rule : jqgridFilter.getRules()) {
	
			 if (rule.getField().equals("customerId")) {
				if (rule.getData() == "" || rule.getData() == null)
					qCustomerId = (long) 0;
				else
					qCustomerId = Long.valueOf(rule.getData());
			} //end of if loop
			 else if (rule.getField().equals("itemCode")) {
					if (rule.getData() == "" || rule.getData() == null)
						qitemCode = "";
					else
						qitemCode =rule.getData();
				}  //end of else if loop
			 
		}
		Long qitemId=(long) 0;
		JqgridResponse<CustomerPartNoDTO> response = new JqgridResponse<CustomerPartNoDTO>();

		List<Item>itemList=itemService.findByItemCode(qitemCode);//fetch item details based on itemcode
		if(itemList.size()>0){
			qitemId=itemList.get(0).getItemId();
		}//end of if loop
		List<CustomerPartNo> customerPartNo = customerPartNoService.fetchBySearch(
	    qCustomerId,qitemId, pagenumber, rows, sortColName, sortOrder);//fetch customer part no details

		List<CustomerPartNo> pagedList;
		int fromIndex = Math.min(customerPartNo.size(), pagenumber * rows);//from index of jqgrid
		int toIndex = Math.min(customerPartNo.size(), fromIndex + rows);//end index of jqgrid

		if (fromIndex == 0 && toIndex == (customerPartNo.size() - 1)) {
			pagedList = customerPartNo;
		} else {
			pagedList = customerPartNo.subList(fromIndex, toIndex);
		}

		List<CustomerPartNoDTO> customerPartNoDto = CustomerPartNoMapper.map(pagedList);


		response.setRows(customerPartNoDto);
		response.setRecords(Long.valueOf(customerPartNo.size()).toString());
		if (customerPartNo.size() > 0)
			response.setTotal(Integer.valueOf(
					(int) Math.ceil(Double.valueOf(customerPartNo.size())
							/ Double.valueOf(rows.toString()))).toString());
		else
			response.setTotal("0");
		response.setPage(Integer.valueOf(pagenumber + 1).toString());
		
		return response;

	}

	 /**
	   * This method to set customer part number to dto
	   * @param List<CustomerPartNo>
	   * @return  List<CustomerPartNoDTO> 
	   * 	   */
	
	private List<CustomerPartNoDTO> convertToDTO(List<CustomerPartNo> customerPartNos) {
		List<CustomerPartNoDTO> customerPartNoDTOs = new ArrayList<>();
		for(CustomerPartNo customerPartNo : customerPartNos) {
			
			CustomerPartNoDTO customerPartNoDTO = new CustomerPartNoDTO();
			
			customerPartNoDTO.setCustomerId(customerPartNo.getCustomer().getCustomerId());
			customerPartNoDTO.setCustomerName(customerPartNo.getCustomer().getCustomerName());
			customerPartNoDTO.setItemCode(customerPartNo.getItems().getItemCode());
			customerPartNoDTO.setItemId(customerPartNo.getItems().getItemId());
			customerPartNoDTO.setItemDescription(customerPartNo.getItems().getItemDescription());
			customerPartNoDTO.setPartNo(customerPartNo.getPartNo());
			customerPartNoDTO.setPartNoId(customerPartNo.getPartNoId());
			
			customerPartNoDTOs.add(customerPartNoDTO);
		}//end of for loop
		return customerPartNoDTOs;
	}

	
	 /**
	   * This method to save part number for a specific item of selected customer
	   * @param customer,itemId,part no
	   * @return  List<String> 
	   * 	   */
	@RequestMapping(value = "/addPartNo", produces = "application/json", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	public @ResponseBody List<String> addNewPartNo(
			@RequestParam("customerSelect") Long customerSelect,
		    @RequestParam("itemIdSelect") String itemIdSelect,
			@RequestParam("partNo") String partNo
			)
		 {
		List<String> statusMssgList=new ArrayList<String>();   
        List<Item>itemDetails=itemService.findByItemCode(itemIdSelect);//fetch item list based on id
        Long itemId=(long) 0;
		List<CustomerPartNo>partNoDetailsList=customerPartNoService.findByCustomerIdAndItemCode(customerSelect, itemIdSelect);//fetch customer part no details based on customer and item id
		if(itemDetails.size()>0)
			itemId=itemDetails.get(0).getItemId();
		if(!(partNoDetailsList.size()>0) && itemId!=0){
			CustomerPartNoDTO customerPartNoDTO = new CustomerPartNoDTO();

			customerPartNoDTO.setItemId(itemId);
			customerPartNoDTO.setCustomerId(customerSelect);
			customerPartNoDTO.setPartNo(partNo);
			 CustomerPartNo itemObj = customerPartNoDTO.getCustomerPartNo();
			 CustomerPartNo addedPartNo = customerPartNoService.create(itemObj);//method to craete customer aprt no
			 if(addedPartNo!=null)
				 statusMssgList.add("Added"); 
		}//end of if loop
	  else{
			 statusMssgList.add("Exist");
		}//end of else loop
		   

		 
		  return statusMssgList;
		
	}
	 /**
	   * curd functionality of customer part no module
	   * @param operation(add/edit/delete), customerpartNoId,part no
	   * @return  StatusResponse
	   * 	   */
	@RequestMapping(value = "/crud", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	StatusResponse crud(@RequestParam Integer id,
			@RequestParam String oper,
			@RequestParam(required = false) String partNo) {
		Boolean result=false;
		List<CustomerPartNo>partNoDetailsList=customerPartNoService.findById(id);//fetch customer part no details based on customerpartnoId
		CustomerPartNoDTO customerPartNoDTO = null;

		if(partNoDetailsList.size()>0){
			customerPartNoDTO=new CustomerPartNoDTO();
			customerPartNoDTO.setPartNoId(partNoDetailsList.get(0).getPartNoId());
			customerPartNoDTO.setItemId(partNoDetailsList.get(0).getItems().getItemId());
			customerPartNoDTO.setCustomerId(partNoDetailsList.get(0).getCustomer().getCustomerId());
			customerPartNoDTO.setPartNo(partNo);
		}//end of if loop
		 CustomerPartNo itemObj = customerPartNoDTO.getCustomerPartNo();

		switch (oper) {
		case "add":
			customerPartNoService.create(itemObj);//method to create customer part no
			break;
	
		case "edit":
			result = customerPartNoService.update(itemObj);//method to update customer part no
			break;
		case "del":
			 customerPartNoService.delete(id);//method to delete customer aprt no
			break;
		}//end of switch

		return new StatusResponse(result);
	}
}	 