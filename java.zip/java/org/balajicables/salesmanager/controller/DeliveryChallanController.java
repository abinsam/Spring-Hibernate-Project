package org.balajicables.salesmanager.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import org.balajicables.salesmanager.common.JqgridResponse;
import org.balajicables.salesmanager.dto.DeliveryChallanDTO;
import org.balajicables.salesmanager.dto.PackingSlipDTO;
import org.balajicables.salesmanager.dto.StockOutDTO;
import org.balajicables.salesmanager.model.Customer;
import org.balajicables.salesmanager.model.DeliveryChallan;
import org.balajicables.salesmanager.model.PackingSlip;
import org.balajicables.salesmanager.model.SalesOrder;
import org.balajicables.salesmanager.model.StockOut;
import org.balajicables.salesmanager.service.CustomerService;
import org.balajicables.salesmanager.service.DeliveryChallanService;
import org.balajicables.salesmanager.service.OrderService;
import org.balajicables.salesmanager.service.PackingSlipService;
import org.balajicables.salesmanager.service.StockOutService;
import org.joda.time.DateTime;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
/**
* This class demonstrates Create Delivery Challan Process.
* @author Abin Sam
*/
@Controller
@RequestMapping("/deliverychallan")

public class DeliveryChallanController {
	
	@Resource
	private OrderService orderService;
	@Resource
	private CustomerService customerService;
	@Resource
	private StockOutService stockOutService;
	@Resource
	private DeliveryChallanService deliveryChallanService;
	@Resource
	private PackingSlipService packingSlipService;
	
	 /**
	   * This method returns deliveryChallan.jsp.
	   * Fetch all customers 
	   * @param Model to set the attribute.
	   * @return createInvoice.jsp.
	   */
	@RequestMapping
	public String getItemsPage(Model model) {
		List<Customer> customers = customerService.findAll();
		model.addAttribute("customers", customers);
		return "deliveryChallan";
	}
	 /**
	   * This method to populate Delivery Challan Grid
	   * Fetch details of Delivery Challan
	   * @param customerId,search,filters,pageNumber,rowsPerPage,sortColName,sortOrder
	   * @return JqgridResponse<StockOutDTO> response
	   */
	@RequestMapping(value="/records/{customerId}", produces="application/json", method=RequestMethod.POST)
	public @ResponseBody
	JqgridResponse<StockOutDTO> records(
			@PathVariable("customerId") Long customerId,
    		@RequestParam("_search") Boolean search,
    		@RequestParam(required = true) String salesOrderNo,
    		@RequestParam(value="filters", required=false) String filters,
			@RequestParam(value = "page", required = false) Integer pageNumber,
			@RequestParam(value = "rows", required = false) Integer rowsPerPage,
			@RequestParam(value = "sidx", required = false) String sortColName,
			@RequestParam(value = "sord", required = false, defaultValue = "asc") String sortOrder) {
		/*Intialize JQ grid response of type StockOutDTO*/	
		JqgridResponse<StockOutDTO> response = new JqgridResponse<StockOutDTO>();

		return response;
	
	}

	@RequestMapping(value="/createDeliveryChallan", produces="application/json" ,method = RequestMethod.POST)
	public @ResponseBody
	List<String> saveDcDetails(
   	 @RequestParam(value = "idsOfSelectedRows[]", required = false) Long[] idsSelected,
    @RequestParam(value = "challanDate", required = false) String challanDate ) {

	List<String> dcNoList=new ArrayList<>();
    
   	Boolean finalresult=false;
 	String newdeliveryChallanNo;
	
 	List<DeliveryChallan> existdeliveryChallanList=deliveryChallanService.fetchLatestDeliveryChallan();
	
	String existDcNo="";
	if(existdeliveryChallanList.size()>0)
		existDcNo=existdeliveryChallanList.get(0).getDeliveryChallanNo();
	
	if(!existDcNo.isEmpty()){
		String existDcNumber = existDcNo.split("/")[0];
		String existDcFinancialYear=existDcNo.split("/")[1];
		String currentYear=String.valueOf(new DateTime().getYear()%1000);
		String previousYear=String.valueOf((new DateTime().getYear()-1)%1000);
		String nextYear=String.valueOf((new DateTime().getYear()+1)%1000);
		String cuurentFinacialYear=null;
		if(new DateTime().getMonthOfYear()>2)
			cuurentFinacialYear=currentYear+"-"+nextYear;
		else
			cuurentFinacialYear=previousYear+"-"+currentYear;
		if(cuurentFinacialYear.equalsIgnoreCase(existDcFinancialYear)){
			Long newDcNumber=Long.valueOf(existDcNumber)+1;
			String newDcNo="0000";
			if(newDcNumber<10)
			  newDcNo="000"+newDcNumber;
			else if(newDcNumber<100)
		      newDcNo="00"+newDcNumber;
			else if(newDcNumber<1000)
			  newDcNo="0"+newDcNumber;
			else
			  newDcNo=String.valueOf(newDcNumber);
			newdeliveryChallanNo=newDcNo+"("+cuurentFinacialYear+")";	
	 	}else{
			String currentYears=String.valueOf(new DateTime().getYear()%1000);
			String previousYears=String.valueOf((new DateTime().getYear()-1)%1000);
			String nextYears=String.valueOf((new DateTime().getYear()+1)%1000);
			String finacialYears=null;
			if(new DateTime().getMonthOfYear()>3)
				finacialYears=currentYears+"-"+nextYears;
			else
				finacialYears=previousYears+"-"+currentYears;
			newdeliveryChallanNo="0001("+finacialYears+")";	
		}
	}//end of if loop of checking existing sales no
	else{
		String currentYear=String.valueOf(new DateTime().getYear()%1000);
		String previousYear=String.valueOf((new DateTime().getYear()-1)%1000);
		String nextYear=String.valueOf((new DateTime().getYear()+1)%1000);
		String finacialYear=null;
		if(new DateTime().getMonthOfYear()>3)
			finacialYear=currentYear+"-"+nextYear;
		else
			finacialYear=previousYear+"-"+currentYear;
		newdeliveryChallanNo="0001("+finacialYear+")";
	}
  	
      for(int i=0;i<idsSelected.length;i++){
    	   List<StockOut> stockOutList=stockOutService.findByStockOutId(idsSelected[i]);
    		if(stockOutList.size()>0){
    			DeliveryChallanDTO deliveryChallanDTO=new DeliveryChallanDTO();
    			deliveryChallanDTO.setDeliveryChallanNo(newdeliveryChallanNo);
    			deliveryChallanDTO.setChallanDate(challanDate);
    			deliveryChallanDTO.setInvoiceStatus("No");
    			deliveryChallanDTO.setStatus("Created");
    			deliveryChallanDTO.setRemarks("");
    			deliveryChallanDTO.setOrderId(stockOutList.get(0).getSalesOrderItem().getOrder().getOrderId());
    			DeliveryChallan dcItem=deliveryChallanDTO.getDeliveryChallan();
    			DeliveryChallan createddc=null;
    			createddc = deliveryChallanService.create(dcItem);
 		 	    if(createddc!=null){
 		 	    	StockOutDTO stockOutDTO=new StockOutDTO();
 		 	    	stockOutDTO.setStockOutId(stockOutList.get(0).getStockOutId());
 		 	    	stockOutDTO.setStoreId(stockOutList.get(0).getStore().getStoreId());
 		 	    	stockOutDTO.setOrderDetailId(stockOutList.get(0).getSalesOrderItem().getOrderDetailId());
 		 	    	stockOutDTO.setOrderId(stockOutList.get(0).getSalesOrderItem().getOrder().getOrderId());
 		 	    	stockOutDTO.setItemId(stockOutList.get(0).getItemId());
 		 	    	stockOutDTO.setItemCode(stockOutList.get(0).getItemCode());
 		 	    	stockOutDTO.setSoItemQty(stockOutList.get(0).getSoItemQty());
 		 	    	stockOutDTO.setWorkOrderNo(stockOutList.get(0).getProductionWorkOrder().getWorkOrderNo());
 		 	    	stockOutDTO.setStockOutDateTime(stockOutList.get(0).getStockOutDateTime().toString());
 		 	    	stockOutDTO.setStockOutQty(stockOutList.get(0).getStockOutQty());
 		 	    	stockOutDTO.setQcStatus(stockOutList.get(0).getQcStatus());
 		 	    	stockOutDTO.setQcSupervisor(stockOutList.get(0).getQcSupervisor());
 		 	    	stockOutDTO.setCustomerName(stockOutList.get(0).getCustomerName());
 		 	    	stockOutDTO.setBundleId(stockOutList.get(0).getBundleId());
 		 	    	stockOutDTO.setPackingSlipNo(stockOutList.get(0).getPackingSlipNo());
 		 	    	stockOutDTO.setRemarks(stockOutList.get(0).getRemarks());
 		 	    	stockOutDTO.setSupervisor(stockOutList.get(0).getSupervisor());
 		 	    	stockOutDTO.setWeight(stockOutList.get(0).getWeight());
 		 	    	StockOut stockOut=stockOutDTO.getStockOut();
 		 	    	Boolean createdStockOut=stockOutService.update(stockOut);
 		 	    	if(createdStockOut==true){
 		 	  		Map<String, List<StockOut>> map = new HashMap<String, List<StockOut>>();
 		    		for (StockOut stockOutDetailsList :stockOutList) {
 		    		   String key =String.valueOf(stockOutDetailsList.getPackingSlipNo())+stockOutDetailsList.getSalesOrderItem().getItem().getInputSize()+stockOutDetailsList.getStockOutQty();
 		    		  if (map.get(key) == null) {
 		    		     map.put(key, new ArrayList<StockOut>());
 		    		     
 		    		     }
 		    		   map.get(key).add(stockOutDetailsList);
 		    		}//end of for loop
 		    		
 		    		//iterating over values only
 		    		for (List<StockOut> value : map.values()) {
 		    			String packingNo=null;
 		    			String stockOutBagNoString=null;
 		    			Long stockOutBagNo=value.get(0).getPackingSlipNo();
 		    			if(stockOutBagNo<10){
 		    				stockOutBagNoString="0"+stockOutBagNo;
 		    			}else
 		    				stockOutBagNoString=String.valueOf(stockOutBagNo);
 		    			packingNo=newdeliveryChallanNo+"/"+stockOutBagNoString;
 		    			 String sizeType=value.get(0).getSalesOrderItem().getItem().getInputSize();
 		    			 Integer noOfRolls=value.size();
 		    			 Double quantity=value.get(0).getStockOutQty();
 		    			 Double totalQuantity=Double.valueOf(noOfRolls)*quantity;
 		    				
 		    					PackingSlipDTO packingSlipDTO=new PackingSlipDTO();
 		    			        packingSlipDTO.setPackingSlipNo(packingNo);
 		    			        packingSlipDTO.setInputSize(sizeType);
 		    			        packingSlipDTO.setNoOfRolls(noOfRolls);
 		    			        packingSlipDTO.setQuanityPerRoll(quantity);
 		    			        packingSlipDTO.setTotalQuantity(totalQuantity);
 		    			        packingSlipDTO.setWeight(value.get(0).getWeight());
 		    			        PackingSlip packingSlip=packingSlipDTO.getPackingSlip();
 		    			        PackingSlip createdPackingSlip=packingSlipService.create(packingSlip);
 		    			        if(createdPackingSlip!=null)
 		    			        	  finalresult=true;
 		    		}// end of iterating for loop
 		 	      	 
 		 	    	}
 		 	    }
    		}
       }
       if(finalresult==true)
       dcNoList.add(newdeliveryChallanNo);
       return dcNoList;
  }
	 /**
	   * @param soOrderId
	   * @return statusList
	   */	
	@RequestMapping(value = "/checkOrderStatus", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	List<String> checkOrderStatus(@RequestParam  String soOrderId) {
		List<String> statusList=new ArrayList<String>();
		List<SalesOrder> salesOrderList=orderService.findBySalesOrderNoId(soOrderId);
	
		statusList.add(salesOrderList.get(0).getOrderStatus().getStatus());
	    return statusList;
	   }		
	
}