package org.balajicables.salesmanager.controller;

import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/exciseReport")
public class ExciseReportController {


	 /**
	   * This method returns exciseReport.jsp.
	   * @param Model to set the attribute.
	   * @return exciseReport.jsp.
	   */
	@RequestMapping(method = RequestMethod.GET)
	public String generateExciseReport(Model model) {
		
		return "exciseReport";
	}

	
	 /**
	   * This method returns report output as response
	   * create Revenue figures jasper report based on params
	   * @param fromDate,toDate
	   * @return createInvoice.jsp.
	   */
	@RequestMapping(value = "/revenueFiguresReport", produces = "application/pdf", method = RequestMethod.GET)

	public void RevenueFiguresReport(@RequestParam(value = "fromDate", required = true) String fromDate,
			                     @RequestParam(value = "toDate", required = true) String toDate,  
			                     javax.servlet.http.HttpServletResponse response) throws IOException, InterruptedException, ParseException{
		if(fromDate!=null && fromDate!="" && toDate!=null && toDate!=""){
		 InputStream inputStream = getClass().getClassLoader().getResourceAsStream("/org/balajicables/salesmanager/report/RevenueFiguresReport.jrxml");
		
		 
		 DateFormat df = new SimpleDateFormat("dd-MM-yyyy");
	     java.util.Date fromDt = df.parse(fromDate);
	     java.util.Date toDt = df.parse(toDate);
	 
		 Map<String, Object> hm= new HashMap<String, Object>();
	     hm.put("FROM_DATE", fromDt);
	     hm.put("TO_DATE", toDt);
	     byte[] content = ReportGenerator.newReportGenerator(inputStream,hm);
	    
		response.setContentType("application/pdf");
		response.setHeader("Content-Disposition", "attachment;filename=" + "RevenueFiguresReport"+fromDate+"-to-"+toDate+".pdf");
		response.setContentLength(content.length);
	    FileCopyUtils.copy(content, response.getOutputStream());
	}
	}
}