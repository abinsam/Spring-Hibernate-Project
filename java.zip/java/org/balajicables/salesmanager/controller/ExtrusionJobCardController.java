package org.balajicables.salesmanager.controller;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import org.balajicables.salesmanager.CustomUser;
import org.balajicables.salesmanager.common.JqgridResponse;
import org.balajicables.salesmanager.common.StatusResponse;
import org.balajicables.salesmanager.common.WorkOrderItemsMapper;
import org.balajicables.salesmanager.dto.LabelReportDTO;
import org.balajicables.salesmanager.dto.ProductionWorkOrderDTO;
import org.balajicables.salesmanager.dto.PvcStockOutDTO;
import org.balajicables.salesmanager.dto.SalesOrderItemsDTO;
import org.balajicables.salesmanager.dto.WorkOrderItemsDTO;
import org.balajicables.salesmanager.model.CustomerPartNo;
import org.balajicables.salesmanager.model.LabelReport;
import org.balajicables.salesmanager.model.ProductionWorkOrder;
import org.balajicables.salesmanager.model.PvcStockOut;
import org.balajicables.salesmanager.model.SalesOrderItem;
import org.balajicables.salesmanager.model.WorkOrderItems;
import org.balajicables.salesmanager.service.CustomerPartNoService;
import org.balajicables.salesmanager.service.LabelReportService;
import org.balajicables.salesmanager.service.OrderDetailsService;
import org.balajicables.salesmanager.service.ProductionWorkOrderService;
import org.balajicables.salesmanager.service.PvcStockOutService;
import org.balajicables.salesmanager.service.WorkOrderItemService;
import org.balajicables.salesmanager.utils.Utility;
import org.joda.time.DateTime;
import org.springframework.data.domain.Page;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
/**
* This class demonstrates Create Extrusion job card Process.
* @author Abin Sam
*/
@Controller

@RequestMapping("/viewworkorder")

public class ExtrusionJobCardController {
	

	@Resource
	private ProductionWorkOrderService productionWorkOrderService;
	
	@Resource
	private CustomerPartNoService customerPartNoService;
	
	@Resource
	private WorkOrderItemService workOrderItemService;
	
	@Resource
	private PvcStockOutService pvcStockOutService;

	@Resource
	private OrderDetailsService orderDetailsService;
	
	@Resource
	private LabelReportService labelReportService;
	 /**
	   * This method returns extrusionJobCard.jsp.
	   * Fetch all submitted extrusion work order nos created on current month.
	   * @param Model to set the attribute.
	   * @return extrusionJobCard.jsp.
	   */
	@RequestMapping(method = RequestMethod.GET)
     public String getWorkOrdersPage(Model model) {		
		DateTime dt = new DateTime();  // current time
		int month =dt.getMonthOfYear();
		int year=dt.getYear();
		String extrusion = "Extrusion";
        String status="Submitted";
    	List<ProductionWorkOrder> productionWorkOrders = productionWorkOrderService.findByProcessTypeAndStatusAndMonthYear(extrusion, status, month, year);
		ArrayList<String> woNosList = new ArrayList<>();

    	for (int iterator = 0; iterator < productionWorkOrders.size(); iterator++) {
			if (productionWorkOrders.get(iterator).getWorkOrderNo() != null
					&& productionWorkOrders.get(iterator).getWorkOrderNo() != "") {
				String woNo = productionWorkOrders.get(iterator).getWorkOrderNo();
				if (!woNosList.contains(woNo)) {
					woNosList.add(woNo);
				}
			}
		}
		Collections.sort(woNosList,Collections.reverseOrder());
		model.addAttribute("workOrderNo", woNosList);// set Multiwire work order nos to model attribute
             return "extrusionJobCard";

     }
	 /**
	   * This method to populate extrusion job card Grid
	   * Fetch details of extrusion job card
	   * @param workOrderNo,filters,pageNumber,rowsPerPage,sortColName,sortOrder
	   * @return JqgridResponse<WorkOrderItemsDTO> response
	   */
	
	@RequestMapping(value="/records/{woNo}", produces="application/json", method=RequestMethod.GET)
	public @ResponseBody
	JqgridResponse<WorkOrderItemsDTO> records(
			@PathVariable("woNo") String workOrderNo,
    		@RequestParam("_search") Boolean search,
    		@RequestParam(value="filters", required=false) String filters,
			@RequestParam(value = "page", required = false) Integer pagenumber,
			@RequestParam(value = "rows", required = false) Integer rowsPerPage,
			@RequestParam(value = "sidx", required = false) String sortColName,
			@RequestParam(value = "sord", required = false, defaultValue = "asc") String sortOrder) {

		int pageNumber=pagenumber-1;
		List<WorkOrderItems>woItemList=workOrderItemService.findWoItemList(workOrderNo);//fetch work order items based on work order item id

		List<WorkOrderItems> pagedList=null;
	        int fromIndex = Math.min(woItemList.size(), pageNumber * rowsPerPage);
	        int toIndex = Math.min(woItemList.size(), fromIndex + rowsPerPage);
	          if (fromIndex == 0 && toIndex == (woItemList.size() - 1))
	        {
	            pagedList = woItemList;
	        }
	        else
	        {
	           pagedList = woItemList.subList(fromIndex, toIndex);
	        }
	    	List<WorkOrderItemsDTO> workOrderItemsDto = WorkOrderItemsMapper.map(pagedList);
            JqgridResponse<WorkOrderItemsDTO> response = new JqgridResponse<WorkOrderItemsDTO>();
	        response.setRows(workOrderItemsDto);
	        response.setRecords(Long.valueOf(woItemList.size()).toString());
	        if(woItemList.size()>0)
	        response.setTotal(Integer.valueOf((int)Math.ceil(Double.valueOf(woItemList.size())/Double.valueOf(rowsPerPage.toString()))).toString());
	       else
	       response.setTotal("0");
	       response.setPage(Integer.valueOf(pageNumber+1).toString());
	       return response;
}
	 /**
	   * Crud functionality of extrsuion job card
	   * @param  oper,orderId, workOrderNo,orderDetailId,totalQuantity,noOfCoils, qtyPerCoil,
			 packingType,pvcGrade,masterBatch,toBeLabelled,stockInQty,stockInStatus,area
	   * @return StatusResponse
	   */
	@RequestMapping(value = "/crud", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	StatusResponse crud(@RequestParam Long id,
			@RequestParam String oper,
			@RequestParam(required = true) String orderId,
			@RequestParam(required = true) String workOrderNo,
			@RequestParam(required = true) Long orderDetailId,
			@RequestParam (required=false)  Double totalQuantity,
			@RequestParam(required = false) Integer noOfCoils,
			@RequestParam(required = false) Integer qtyPerCoil,
			@RequestParam(required = false) String packingType,
			@RequestParam (required=false)  String pvcGrade,
			@RequestParam (required=false)  String masterBatch,
			@RequestParam (required=false)  String toBeLabelled,
			@RequestParam (required=false)  Double stockInQty,
			@RequestParam (required=false)  String stockInStatus,
			@RequestParam (required=false)  String area
			
			) {
		//fetch logged in user
		CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();;
	 	String supervisor = user.getFirstName()+" "+user.getLastName();

		
 		Boolean result = false;
 		WorkOrderItemsDTO woItemsDTO = new WorkOrderItemsDTO();

		   woItemsDTO.setWorkOrderItemId(id);
		   woItemsDTO.setWorkOrderNo(workOrderNo);
		   woItemsDTO.setOrderDetailId(orderDetailId);
		   woItemsDTO.setOrderId(orderId);
		   woItemsDTO.setTotalQuantity(totalQuantity);
		   woItemsDTO.setNoOfCoils(noOfCoils);
		   woItemsDTO.setQtyPerCoil(qtyPerCoil);
		   woItemsDTO.setPackingType(packingType);
		   woItemsDTO.setPvcGrade(pvcGrade);
		   woItemsDTO.setMasterBatch(masterBatch);
		   woItemsDTO.setToBeLabelled(toBeLabelled);
		   woItemsDTO.setStockInQty(stockInQty);
		   woItemsDTO.setStockInStatus(stockInStatus);
		   woItemsDTO.setUpdatedBy(supervisor);
		   woItemsDTO.setArea(area);
		
		WorkOrderItems woItems = woItemsDTO.getWorkOrderItem();
		switch (oper) {
		case "add":
			WorkOrderItems createdWoItems = workOrderItemService.create(woItems);//create work order items
			if (createdWoItems != null) {
				result = true;
			}
			break;
		case "edit":
			result = workOrderItemService.update(woItems);//update work order items
			if(result==true){
				List<WorkOrderItems>woItemsList=workOrderItemService.findByProductionWorkOrderWorkOrderNo(workOrderNo);//fetch work order items by work order no
				if(woItemsList.size()>0){
					for(int i=0;i<woItemsList.size();i++){
						if(woItemsList.get(i).getPvcGrade()==null || woItemsList.get(i).getPvcGrade().equalsIgnoreCase("") ||  woItemsList.get(i).getMasterBatch()==null ||  woItemsList.get(i).getMasterBatch().equalsIgnoreCase("")){
						WorkOrderItemsDTO woItemDTO=new WorkOrderItemsDTO();
						woItemDTO.setWorkOrderItemId(woItemsList.get(i).getWorkOrderItemId());
						woItemDTO.setWorkOrderNo(woItemsList.get(i).getProductionWorkOrder().getWorkOrderNo());
						woItemDTO.setOrderDetailId(woItemsList.get(i).getSalesOrderItem().getOrderDetailId());
						woItemDTO.setOrderId(woItemsList.get(i).getSalesOrderItem().getOrder().getOrderId());
						woItemDTO.setQtyPerCoil(woItemsList.get(i).getQtyPerCoil());
						woItemDTO.setNoOfCoils(woItemsList.get(i).getNoOfCoils());
						woItemDTO.setTotalQuantity(woItemsList.get(i).getTotalQuantity());
						woItemDTO.setToBeLabelled(woItemsList.get(i).getToBeLabelled());
						woItemDTO.setStockInQty(woItemsList.get(i).getStockInQty());
						woItemDTO.setStockInStatus(woItemsList.get(i).getStockInStatus());
						woItemDTO.setUpdatedBy(supervisor);
                 			if(woItemsList.get(i).getPvcGrade()==null || woItemsList.get(i).getPvcGrade().equalsIgnoreCase(""))
								woItemDTO.setPvcGrade(pvcGrade);
							else
								woItemDTO.setPvcGrade(woItemsList.get(i).getPvcGrade());
							 if(woItemsList.get(i).getMasterBatch()==null || woItemsList.get(i).getMasterBatch().equalsIgnoreCase(""))
								 woItemDTO.setMasterBatch(masterBatch);
							 else
								 woItemDTO.setMasterBatch(woItemsList.get(i).getMasterBatch());
							 
							 if(woItemsList.get(i).getPackingType()==null || woItemsList.get(i).getPackingType().equalsIgnoreCase(""))
								 woItemDTO.setPackingType(packingType);
							 else
								 woItemDTO.setPackingType(woItemsList.get(i).getPackingType());
							 
							 WorkOrderItems workOrderItemsList=woItemDTO.getWorkOrderItem();
							 Boolean updateWoMasterBatchPvc=workOrderItemService.update(workOrderItemsList);
						  	 if(updateWoMasterBatchPvc==true)	
						  		 result=true;
					    }
			
			  }
				}
			}
			break;
		case "del":
			Long woItemIdToDelete = id;
			result = workOrderItemService.delete(woItemIdToDelete);
			break;
		}//end of switch loop
	return new StatusResponse(result);
	}
	 /**
	   * This method is to delete extrusion work order item based on the work Order Item id 
	   * @PathVariable woItemId
	   * @return StatusResponse
	   */	
	@RequestMapping(value = "/delete/{woItemId}", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	StatusResponse deleteId(@PathVariable("woItemId") Long woItemId) {
		    Boolean result=false;
		    Boolean updateResult=false;
		    List<WorkOrderItems> woItemsList=workOrderItemService.findById(woItemId);
		    Long salesOrderItemId=woItemsList.get(0).getSalesOrderItem().getOrderDetailId();
		    Double balQty=woItemsList.get(0).getSalesOrderItem().getBalanceQty();
		    Double pdnQty=woItemsList.get(0).getSalesOrderItem().getProductionQty();
		    Double woQty=woItemsList.get(0).getTotalQuantity();
		    Double totalQty=0.0;
		    Double newBalQty=balQty+woQty;
		    Double newPdnQty=pdnQty-woQty;
		    updateResult=orderDetailsService.updateBalPdnQty(salesOrderItemId,totalQty,newBalQty,newPdnQty);
		    if(updateResult==true)
		    result = workOrderItemService.delete(woItemId);
			return new StatusResponse(result);
	}
	 /**
	   * This method is to delete extrusion work order item based on the work Order Item id 
	   * @PathVariable woItemId
	   * @return StatusResponse
	   */
	@RequestMapping(value = "/fetchWoDetails/{woNo}", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	List<String> fetchWoDetails(@PathVariable("woNo") String workOrderNo) {
		  List<ProductionWorkOrder> workOrderList=productionWorkOrderService.findByProductionWorkOrderNo(workOrderNo);
		  List<String> workOrderDetailsList=new ArrayList<String>();
	if(workOrderList.get(0).getStartDate()!= null)
		  workOrderDetailsList.add(Utility.formDateFormatter.print(workOrderList.get(0).getStartDate().getTime()));
	else
		workOrderDetailsList.add("");
		if(workOrderList.get(0).getEndDate() != null)	
	workOrderDetailsList.add(Utility.formDateFormatter.print(workOrderList.get(0).getEndDate().getTime()));
		else workOrderDetailsList.add(""); 
		workOrderDetailsList.add(workOrderList.get(0).getCreatedBy());
		  workOrderDetailsList.add(workOrderList.get(0).getMachine().getDescription());
		  workOrderDetailsList.add(workOrderList.get(0).getStatus());
		  
		 return workOrderDetailsList;
	}
	 /**
	   * This method is to delete extrusion work order item based on the work Order Item id 
	   * @PathVariable woItemId
	   * @return StatusResponse
	   */
	@RequestMapping(value="/submitFunction/{woNo}", produces="application/json", method=RequestMethod.POST)
	public @ResponseBody
	void submitBunchingWorkOrder(
			@PathVariable("woNo") String woNo) {
		String updateStatus="Submitted";
		productionWorkOrderService.updateWorkOrderStatus(woNo,updateStatus);
		
	}
	 /**
	   * This method is to delete extrusion work order item based on the work Order Item id 
	   * @PathVariable woItemId
	   * @return StatusResponse
	   */	
	@RequestMapping(value="/labelReport", produces="application/pdf", method=RequestMethod.GET)
	public  void labelReport(
			@RequestParam(value="woNo" , required = true) String workOrderNo ,javax.servlet.http.HttpServletResponse response) throws IOException{
		Boolean result=true;
	
      List<LabelReport> labelReportDetailsList=labelReportService.findByWorkOrderNo(workOrderNo);
      Boolean deleteResult=false;
	
     if(labelReportDetailsList.size()>0){
		deleteResult=labelReportService.deleteByWorkOrderNo(workOrderNo);

		}else deleteResult=true;
     if(deleteResult==true){
		List<WorkOrderItems>woItemsList=workOrderItemService.findWoItemList(workOrderNo);
	if(woItemsList.size()>0){
		for(int k=0;k<woItemsList.size();k++){
			List<CustomerPartNo> customerPartList=customerPartNoService.findByCustomerIdAndItemId(woItemsList.get(k).getSalesOrderItem().getOrder().getCustomer().getCustomerId(), woItemsList.get(k).getSalesOrderItem().getItem().getItemId());
     		int noOfLabels=woItemsList.get(k).getNoOfCoils()+3;
     	  
			for(int i=1;i<=noOfLabels;i++){
				String bundleId=null;
				if(i<10)
		    		bundleId="00" +  i;
		    	else if(i<100)
		    		bundleId="0" +  i;
		    	else bundleId = String.valueOf(i);
				LabelReportDTO labelReportDTO=new LabelReportDTO();
				labelReportDTO.setArea(woItemsList.get(k).getSalesOrderItem().getItem().getArea().getAreaValue());
				labelReportDTO.setBatchNo(woItemsList.get(k).getProductionWorkOrder().getWorkOrderNo()+"/"+bundleId);
				labelReportDTO.setBundleId(bundleId);
				labelReportDTO.setCableStd(woItemsList.get(k).getSalesOrderItem().getItem().getCableStdPvc().getCableStd());
				labelReportDTO.setCustomerId(woItemsList.get(k).getSalesOrderItem().getOrder().getCustomer().getCustomerId());
				if(customerPartList.size()>0){
				   labelReportDTO.setPartNo(customerPartList.get(0).getPartNo());
				}
				else
					labelReportDTO.setPartNo(null);
								
				labelReportDTO.setItemDescription(woItemsList.get(k).getSalesOrderItem().getItem().getItemDescription());
				labelReportDTO.setPoNo(woItemsList.get(k).getSalesOrderItem().getOrder().getPoDetails());
				labelReportDTO.setQtyPerCoil(woItemsList.get(k).getQtyPerCoil());
				labelReportDTO.setSalesOrderNo(woItemsList.get(k).getSalesOrderItem().getOrder().getOrderId());
				labelReportDTO.setTotalQuantity(woItemsList.get(k).getTotalQuantity());
				labelReportDTO.setWorkOrderItemId(woItemsList.get(k).getWorkOrderItemId());
				labelReportDTO.setWorkOrderNo(woItemsList.get(k).getProductionWorkOrder().getWorkOrderNo());
				
				LabelReport labelReport=labelReportDTO.getLabelReport();
				LabelReport createdLabelReport=labelReportService.create(labelReport);
				if(createdLabelReport!=null)
					result=true;
	   		}
		}
		
     }
	if(result==true){
	if(workOrderNo!=null && workOrderNo!=""){
	InputStream inputStream = getClass().getClassLoader().getResourceAsStream("/org/balajicables/salesmanager/report/ExtrusionLabelReport.jrxml");
	 Map<String, Object> hm= new HashMap<String, Object>();
     hm.put("WORK_ORDER_NO", workOrderNo);
     byte[] content = ReportGenerator.newReportGenerator(inputStream,hm);
		
		response.setContentType("application/pdf");
		response.setHeader("Content-Disposition", "attachment;filename=" + "ExtrusionLabel"+workOrderNo+".pdf");
	response.setContentLength(content.length);
    FileCopyUtils.copy(content, response.getOutputStream());
	}
     }}
	}

	@RequestMapping(value = "/extrusionJobCardReport", produces = "application/pdf", method = RequestMethod.GET)
	public void ExtrusionJobCardReport(@RequestParam(value = "workOrderNo", required = true) String workOrderNo,javax.servlet.http.HttpServletResponse response) throws IOException, InterruptedException{
		if(workOrderNo!=null && workOrderNo!=""){
		InputStream inputStream = getClass().getClassLoader().getResourceAsStream("/org/balajicables/salesmanager/report/ExtrusionWorkOrderReport.jrxml");
    	
    	 Map<String, Object> hm= new HashMap<String, Object>();
         hm.put("WORK_ORDER_NO", workOrderNo);
         byte[] content = ReportGenerator.newReportGenerator(inputStream,hm);
	       
		response.setContentType("application/pdf");
		response.setHeader("Content-Disposition", "attachment;filename=" + "ExtrusionJobCard"+workOrderNo+".pdf");
		response.setContentLength(content.length);
	    FileCopyUtils.copy(content, response.getOutputStream());
		}
   }
	
	@RequestMapping(value = "/extrusionApprovalReport", produces = "application/pdf", method = RequestMethod.GET)
	public void ExtrusionApprovalReport(@RequestParam(value = "workOrderNo", required = true) String workOrderNo,javax.servlet.http.HttpServletResponse response) throws IOException, InterruptedException{
		if(workOrderNo!=null && workOrderNo!=""){
		InputStream inputStream = getClass().getClassLoader().getResourceAsStream("/org/balajicables/salesmanager/report/ExtrusionApprovalReport.jrxml");
    	
    	 Map<String, Object> hm= new HashMap<String, Object>();
         hm.put("WORK_ORDER_NO", workOrderNo);
         byte[] content = ReportGenerator.newReportGenerator(inputStream,hm);
	       
		response.setContentType("application/pdf");
		response.setHeader("Content-Disposition", "attachment;filename=" + "Extrusion_Approval_Report"+workOrderNo+".pdf");
		response.setContentLength(content.length);
	    FileCopyUtils.copy(content, response.getOutputStream());
		}
   }
	@RequestMapping(value = "/stockInReport", produces = "application/pdf", method = RequestMethod.GET)
	public void StockInReport(@RequestParam(value = "workOrderNo", required = true) String workOrderNo,javax.servlet.http.HttpServletResponse response) throws IOException, InterruptedException{
		if(workOrderNo!=null && workOrderNo!=""){
		InputStream inputStream = getClass().getClassLoader().getResourceAsStream("/org/balajicables/salesmanager/report/StockInReport.jrxml");
    	
    	 Map<String, Object> hm= new HashMap<String, Object>();
         hm.put("work_order_no", workOrderNo);
         byte[] content = ReportGenerator.newReportGenerator(inputStream,hm);
	       
		response.setContentType("application/pdf");
		response.setHeader("Content-Disposition", "attachment;filename=" + "StockInReport "+workOrderNo+".pdf");
		response.setContentLength(content.length);
	    FileCopyUtils.copy(content, response.getOutputStream());
		}
   }
	
	@RequestMapping(value="/pvcStockOutRecords/{woNo}", produces="application/json", method=RequestMethod.POST)
	public @ResponseBody 
	JqgridResponse<PvcStockOutDTO> pvcStockOutRecords(
			@PathVariable("woNo") String woNo,
			@RequestParam(value="filters", required=false) String filters,
			@RequestParam(value = "page", required = false) Integer pageNumber,
			@RequestParam(value = "rows", required = false) Integer rowsPerPage,
			@RequestParam(value = "sidx", required = false) String sortColName,
			@RequestParam(value = "sord", required = false, defaultValue = "asc") String sortOrder) {
		   //JQ grid sorting column name  
		   if(sortColName.equalsIgnoreCase("itemDescription")){
			sortColName="item.itemDescription";
		   }
			/*Method to fetch JQGRID paged records of PvcStockOut output based on woNo*/
			Page<PvcStockOut> pvcStockOutOutput = pvcStockOutService.getPvcStockOutRecords(woNo, pageNumber -1, rowsPerPage, sortColName, sortOrder);
			/*Intialize JQ grid response of type OrderDTO*/
			JqgridResponse<PvcStockOutDTO> response = new JqgridResponse<PvcStockOutDTO>();
			/*Method to set pvc stockout output list to PvcStockOutDTO*/
			List<PvcStockOutDTO> pvcStockOutDTOs = convertToPvcStockOut(pvcStockOutOutput.getContent(),woNo);
			response.setRows(pvcStockOutDTOs);
			response.setRecords(Long.valueOf(pvcStockOutOutput.getTotalElements()).toString());
			response.setTotal(Long.valueOf(pvcStockOutOutput.getTotalPages()).toString());
			response.setPage(Integer.valueOf(pvcStockOutOutput.getNumber()+1).toString());
			return response;
	}
	 /**
	   * Method to set PvcStockOut records to PvcStockOutDTO 
	   * @param List<PvcStockOut>
	   * @return List<PvcStockOutDTO>
	   */
	private List<PvcStockOutDTO> convertToPvcStockOut(List<PvcStockOut> pvcStockOuts, String woNo) {
		    List<PvcStockOutDTO> pvcStockOutDTOs = new ArrayList<>();
		    for(PvcStockOut pvcStockOut : pvcStockOuts) {
			PvcStockOutDTO pvcStockOutDTO = new PvcStockOutDTO();
			pvcStockOutDTO.setPvcStockOutId(pvcStockOut.getPvcStockOutID());
			pvcStockOutDTO.setBatch(pvcStockOut.getBatch());
			pvcStockOutDTO.setQuantity(pvcStockOut.getQuantity());
			pvcStockOutDTO.setWorkOrderNo(pvcStockOut.getProductionWorkOrder().getWorkOrderNo());
			pvcStockOutDTO.setItemId(pvcStockOut.getItem().getItemId());
			pvcStockOutDTO.setItemDescription(pvcStockOut.getItem().getItemDescription());
			pvcStockOutDTOs.add(pvcStockOutDTO);
			}//end of for loop
		return pvcStockOutDTOs;
	}
	
	
	
	 /**
	   * This method is to close  work order irrespective of stock in quantity
	    * @param work Order No
	   * @return StatusResponse
	   */	
	@RequestMapping(value = "/closeWorkOrder", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	StatusResponse closeWorkOrder(@RequestParam(value="woNo") String workOrderNo,
			@RequestParam(value="process") String process) {
	    Boolean result=false;
		if(workOrderNo!=null && workOrderNo!=""){
		
			CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();;
		 	String supervisor = user.getFirstName()+" "+user.getLastName();

			String stockInStatus="Pending";
			if(process.equalsIgnoreCase("Extrusion")){
				List<WorkOrderItems>woItemsList=workOrderItemService.findByProductionWorkOrderWorkOrderNoAndStockInStatus(workOrderNo,stockInStatus);
		        if(woItemsList.size()>0){
		        	List<ProductionWorkOrder>pdnList=productionWorkOrderService.findByProductionWorkOrderNo(workOrderNo);
		        	if(pdnList.size()>0)
		        		productionWorkOrderService.updateWorkOrderStatus(workOrderNo,"Completed");
			 
		          for(int k=0;k<woItemsList.size();k++){
  	            	  Long soItemId=woItemsList.get(k).getSalesOrderItem().getOrderDetailId();
		        	  Double totalQuantity=woItemsList.get(k).getTotalQuantity();
		        	  Double stockedInQuantity=woItemsList.get(k).getStockInQty();
		        	  Double balanceQty=totalQuantity-stockedInQuantity;
		        	 List<SalesOrderItem>soItemList=orderDetailsService.findById(soItemId);
		        	 if(soItemList.size()>0){
		          		 Double orderQuantity=soItemList.get(0).getQuantity();
		        		 Double productionQty=soItemList.get(0).getProductionQty();
		        		 Double completedQty=soItemList.get(0).getCompletedQty();
		        		 Double dispatchedQty=soItemList.get(0).getDispatchedQty();
		        		 Double newProductionQty=0.0;
		        		 Double newOrderBalanceQty=0.0;
		        		 if(productionQty>balanceQty){
		        			 newProductionQty=productionQty-balanceQty;
		        		 }
	        			 newOrderBalanceQty=orderQuantity-(newProductionQty+completedQty+dispatchedQty);
	        			
	        			 
	        			 
	        				SalesOrderItemsDTO salesOrderItemsDTO = new SalesOrderItemsDTO();
	        				salesOrderItemsDTO.setOrderDetailId(soItemList.get(0).getOrderDetailId());
	        				salesOrderItemsDTO.setOrderId(soItemList.get(0).getOrder().getOrderId());
	        				salesOrderItemsDTO.setItemId(soItemList.get(0).getItem().getItemId());
	        				salesOrderItemsDTO.setQuantity(soItemList.get(0).getQuantity());
	        				
	        				if(newOrderBalanceQty<0)
	        					salesOrderItemsDTO.setBalanceQty(0.0);
	        				else
	        					salesOrderItemsDTO.setBalanceQty(newOrderBalanceQty);
	        				salesOrderItemsDTO.setBalanceQty(newOrderBalanceQty);
	        				salesOrderItemsDTO.setProductionQty(newProductionQty);
	        				salesOrderItemsDTO.setCompletedQty(soItemList.get(0).getCompletedQty());
	        				salesOrderItemsDTO.setDispatchedQty(soItemList.get(0).getDispatchedQty());
	        				salesOrderItemsDTO.setWoQty(soItemList.get(0).getWoQty());
	        				salesOrderItemsDTO.setWeight(soItemList.get(0).getWeight());
	        				salesOrderItemsDTO.setUnit(soItemList.get(0).getItem().getUnit().getUnits());
	        				salesOrderItemsDTO.setBundleSize(soItemList.get(0).getBundleSize());
	        				salesOrderItemsDTO.setRate(soItemList.get(0).getRate());
	        				salesOrderItemsDTO.setItemCode(soItemList.get(0).getItem().getItemCode());
	        				salesOrderItemsDTO.setUpdatedBy(supervisor);
	        			    salesOrderItemsDTO.setPvcWeight(soItemList.get(0).getPvcWeight());
	             		
	        			    SalesOrderItem soItems=salesOrderItemsDTO.getOrderDetail();
	        			    result=orderDetailsService.update(soItems);
	        			
		        	 }
		          }
		        	
		        }
			}
		}
		
			return new StatusResponse(result);
	}
}	

