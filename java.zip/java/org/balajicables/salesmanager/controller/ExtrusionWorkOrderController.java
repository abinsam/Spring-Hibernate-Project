package org.balajicables.salesmanager.controller;

import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.annotation.Resource;
import org.balajicables.salesmanager.CustomUser;
import org.balajicables.salesmanager.common.JqgridResponse;
import org.balajicables.salesmanager.common.SaveProductionWorkOrder;
import org.balajicables.salesmanager.common.StatusResponse;
import org.balajicables.salesmanager.common.WorkOrderItemsMapper;
import org.balajicables.salesmanager.dto.OrderDTO;
import org.balajicables.salesmanager.dto.SalesOrderItemsDTO;
import org.balajicables.salesmanager.dto.WorkOrderItemsDTO;
import org.balajicables.salesmanager.model.Item;
import org.balajicables.salesmanager.model.OrderStatus;
import org.balajicables.salesmanager.model.ProductionWorkOrder;
import org.balajicables.salesmanager.model.PvcGrade;
import org.balajicables.salesmanager.model.SalesOrder;
import org.balajicables.salesmanager.model.SalesOrderItem;
import org.balajicables.salesmanager.model.WorkOrderItems;
import org.balajicables.salesmanager.model.WorkOrderOutput;
import org.balajicables.salesmanager.repository.PvcGradeRepository;
import org.balajicables.salesmanager.service.ItemService;
import org.balajicables.salesmanager.service.MachineService;
import org.balajicables.salesmanager.service.OrderDetailsService;
import org.balajicables.salesmanager.service.OrderService;
import org.balajicables.salesmanager.service.OrderStatusService;
import org.balajicables.salesmanager.service.ProductionWorkOrderService;
import org.balajicables.salesmanager.service.WorkOrderItemService;
import org.balajicables.salesmanager.service.WorkOrderOutputService;
import org.joda.time.DateTime;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
/**
* This class demonstrates Extrusion WorkOrder Process.
* @author Abin Sam
*/
@Controller
@RequestMapping("/workorder")

public class ExtrusionWorkOrderController {
	
	@Resource
	private WorkOrderItemService workOrderItemService;
	
	@Resource
	private ProductionWorkOrderService productionWorkOrderService;

	@Resource
	private PvcGradeRepository pvcGradeRepository;
	
	@Resource
	private WorkOrderOutputService workOrderOutputService;
	
	@Resource 
	private OrderService orderService;
	
	@Resource
	private OrderDetailsService orderDetailsService;
	
	@Resource
	private ItemService itemService;
	
	@Resource
	private OrderStatusService orderStatusService;
	
	@Resource
	private MachineService machineService;
	/**
	   * This method returns bunchingWorkOrder.jsp.
	   * Fetch all customers and workorder number based on process type
	   * @param Model to set the attribute.
	   * @return extrusionWorkOrder.jsp.
	   */
	@RequestMapping
	public String getCreateWoPage(Model model) {
		String status="Created";
		String processType="Extrusion";
		/*Initializing empty arraylist of type string*/
		ArrayList<String> woNosList = new ArrayList<>();
		/*Method to fetch Extrusion work order numbers of Created status*/
		List<ProductionWorkOrder> productionWorkOrders = productionWorkOrderService.findByProcessTypeAndStatus(processType, status);
		for (int iterator = 0; iterator < productionWorkOrders.size(); iterator++) {
			if (productionWorkOrders.get(iterator).getWorkOrderNo() != null
					&& productionWorkOrders.get(iterator).getWorkOrderNo() != "") {
				String woNo = productionWorkOrders.get(iterator).getWorkOrderNo();
				if (!woNosList.contains(woNo)) {
					woNosList.add(woNo);
				}//end of inner if condition
			}//end of outer if condition
		}//end of for loop
		Collections.sort(woNosList,Collections.reverseOrder());//sorts the list of extrusion Work Order numbers into descending order
		model.addAttribute("workOrderNo",woNosList);//set extrusion work order nos to model attribute
		model.addAttribute("machine",machineService.findProcessMachineNo(processType));//set extrusion machine number to model attribute
		
		return "extrusionWorkOrder";
	}
	/**
	   * Fetch extrusion itemcode based on itemtype
	   * @RequestParam itemType
	   * @return extrusionItemList
	   */	
	@RequestMapping(value="/fetchExtrusionItemCode", produces="application/json", method=RequestMethod.GET)
	public @ResponseBody List<String> fetchItemCode(@RequestParam  String itemType){
		if(itemType!=null){
		List<String> extrusionItemList=itemService.findByItemTypeQuery(itemType);
		return extrusionItemList;
		}else
			return null;	
	}	
	/**
	   * Fetch extrusion itemcode based on itemtype
	   * @return extrusionWoNo
	   */	
	@RequestMapping(value = "/getExtrusionWoNos", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	List<String> getMwdWoNos() {
		String processType = "Extrusion";
		String status="Created";
		/*Initializing empty arraylist of type string*/
		ArrayList<String>extrusionWoNo=new ArrayList<String>();
		/*Method to fetch Extrusion work order numbers of Created status*/
		List<ProductionWorkOrder>mwdWoNoList=productionWorkOrderService.findByProcessTypeAndStatus(processType, status);
		for (int iterator = 0; iterator < mwdWoNoList.size(); iterator++) {
			if(mwdWoNoList.get(iterator).getWorkOrderNo()!=null && mwdWoNoList.get(iterator).getWorkOrderNo()!="")
				extrusionWoNo.add(mwdWoNoList.get(iterator).getWorkOrderNo());
		}//end of for loop
		Collections.sort(extrusionWoNo,Collections.reverseOrder());//sorts the list of extrusion Work Order numbers into descending order
		return extrusionWoNo;
	}
	/**
	   * Method to save Extrusion WorkOrder 
	   * @RequestParam workOrderDate,workOrderTime,completionDate,completionTime,machineNo
	   * @return extrusionWoNo
	   */
	@RequestMapping(value = "/saveworkorder", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	List<String> crud(
			@RequestParam  String workOrderDate,
			@RequestParam  String workOrderTime,
			@RequestParam  String completionDate,
			@RequestParam  String completionTime,
			@RequestParam  Long machineNo
			) {
		/*Initializing empty list of type string*/
		List<String> newCreatedList=new ArrayList<>();
		String newWorkOrderNo;
		String yearNo=String.valueOf(new DateTime().getYear()%1000);
		String monthNo="";
		if(new DateTime().getMonthOfYear()>9)
			monthNo=String.valueOf(new DateTime().getMonthOfYear());
		else
		   monthNo="0"+String.valueOf(new DateTime().getMonthOfYear());
	    String processType="Extrusion";
		/*Method to fetch latest work order number*/
		List<ProductionWorkOrder> existWorkOrderList=productionWorkOrderService.fetchLatestWorkOrder(processType);
		String existWorkOrderNo="";
		if(existWorkOrderList.size()>0)
			existWorkOrderNo=existWorkOrderList.get(0).getWorkOrderNo();
		
		if(!existWorkOrderNo.isEmpty()){
		String existWOYear= existWorkOrderNo.substring(1,3); 
		String existWOMonth=existWorkOrderNo.substring(3,5);
		String existWONoParse=existWorkOrderNo.substring(1,8);
		if((yearNo.equalsIgnoreCase(existWOYear)) && (monthNo.equalsIgnoreCase(existWOMonth))){
			int workOrderInt=Integer.parseInt(existWONoParse)+1;
			newWorkOrderNo="W"+String.valueOf(workOrderInt);
		}
		else{
			newWorkOrderNo="W"+yearNo+monthNo+"001";
		}//end of inner if else ladder
		}//end of if loop of checking existing sales no
		else{
			newWorkOrderNo="W"+yearNo+monthNo+"001";
		}
		/*Fetch logged in user name*/
		CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
	 	String supervisor = user.getFirstName()+" "+user.getLastName();
	 	
		Integer processId= 4;
		/*Method to check if the newWorkOrderNo passed exists*/
		List<ProductionWorkOrder>productionWoList=productionWorkOrderService.findByProductionWorkOrderNo(newWorkOrderNo);
		if(productionWoList.size()==0){
		SaveProductionWorkOrder saveProductionWorkOrder=new SaveProductionWorkOrder();
		ProductionWorkOrder pdnWorkOrder=saveProductionWorkOrder.saveProductionWorkOrder(newWorkOrderNo,machineNo,supervisor,workOrderDate,completionDate,processId); 
		
		ProductionWorkOrder createdWO = productionWorkOrderService.create(pdnWorkOrder);
	    newCreatedList.add(createdWO.getWorkOrderNo());
		}//end of if(productionWoList.size()==0)
	     return newCreatedList;
	}
	/**
	   * Method to save Extrusion WorkOrder items
	   * @RequestParam idsSelected,workOrderNo
	   * @return workOrderList
	   */
	@RequestMapping(value="/saveWoItems", produces="application/json" ,method = RequestMethod.POST)
	public @ResponseBody
	List<String> saveWoItems(
   	 @RequestParam(value = "idsOfSelectedRows[]", required = false) Long[] idsSelected,
   	 @RequestParam(value="workOrderNo",required=true) String workOrderNo) {
		/*Initializing empty list of type string*/
		List<String> workOrderList=new ArrayList<String>();
		
        Boolean soItemQtyUpdate=false;
        WorkOrderItems createdWoItems=null;
    	Boolean updateWoItems=false;
    	/*Fetch logged in user name*/
		CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();;
	 	String supervisor = user.getFirstName()+" "+user.getLastName();
	
		for(int i=0;i<idsSelected.length;i++){
			List<SalesOrderItem> salesOrderItem=orderDetailsService.findById(idsSelected[i]);
			List<WorkOrderItems> workOrderItemList=workOrderItemService.findBySoItemIdAndWorkOrderNo(idsSelected[i],workOrderNo);
	
			if(salesOrderItem.size()>0){
			if(!(workOrderItemList.size()>0)){	
				WorkOrderItemsDTO workOrderItemDTO=new WorkOrderItemsDTO();
			    workOrderItemDTO.setWorkOrderNo(workOrderNo);
				workOrderItemDTO.setOrderDetailId(idsSelected[i]);
				workOrderItemDTO.setTotalQuantity(salesOrderItem.get(0).getWoQty());
				workOrderItemDTO.setQtyPerCoil(salesOrderItem.get(0).getBundleSize());
				workOrderItemDTO.setPackingType("");
				workOrderItemDTO.setMasterBatch("");
				workOrderItemDTO.setStockInQty(0.0);
				workOrderItemDTO.setStockInStatus("Pending");
				workOrderItemDTO.setUpdatedBy(supervisor);
							
				int bundlesize=0;
				if(salesOrderItem.get(0).getBundleSize()!=null)
				  bundlesize=salesOrderItem.get(0).getBundleSize();
			
				 if(bundlesize!=0)
				  workOrderItemDTO.setNoOfCoils((int)Math.ceil(salesOrderItem.get(0).getWoQty()/bundlesize));
					WorkOrderItems workOrderItems=workOrderItemDTO.getWorkOrderItem();
					 createdWoItems=workOrderItemService.create(workOrderItems);
			}// end of if loop of woItemList.size()
			else{
				 WorkOrderItemsDTO workOrderItemsDTO=new WorkOrderItemsDTO();
				Double woItemTotalQty=workOrderItemList.get(0).getTotalQuantity()+salesOrderItem.get(0).getWoQty();
				workOrderItemsDTO.setWorkOrderItemId(workOrderItemList.get(0).getWorkOrderItemId());
				workOrderItemsDTO.setWorkOrderNo(workOrderItemList.get(0).getProductionWorkOrder().getWorkOrderNo());
				workOrderItemsDTO.setOrderDetailId(idsSelected[i]);
			    workOrderItemsDTO.setTotalQuantity(woItemTotalQty);
				workOrderItemsDTO.setQtyPerCoil(salesOrderItem.get(0).getBundleSize());
				workOrderItemsDTO.setPackingType("");
				workOrderItemsDTO.setMasterBatch("");
				workOrderItemsDTO.setStockInQty(0.0);
				workOrderItemsDTO.setStockInStatus("Pending");
				workOrderItemsDTO.setUpdatedBy(supervisor);
				  int bundlesize=0;
					if(salesOrderItem.get(0).getBundleSize()!=null)
					  bundlesize=salesOrderItem.get(0).getBundleSize();
					 if(bundlesize!=0)
						 workOrderItemsDTO.setNoOfCoils((int)Math.ceil(woItemTotalQty/bundlesize));
						WorkOrderItems workOrderItems=workOrderItemsDTO.getWorkOrderItem();
			           updateWoItems=workOrderItemService.update(workOrderItems);
		
			}//end of if(!(workOrderItemList.size()>0)) else condition
		    if(createdWoItems!=null || updateWoItems==true ){
			   Boolean balQtyresult = false;
		       Boolean pdnQtyResult=false;
		       Double workOrderQty=salesOrderItem.get(0).getWoQty();
		       Double balanceQuantity=salesOrderItem.get(0).getBalanceQty();
		       Double pdnQuantity=salesOrderItem.get(0).getProductionQty();
		       Long salesOrderItemId=salesOrderItem.get(0).getOrderDetailId();
		    if(workOrderQty<=balanceQuantity && workOrderQty!=null ){
		  	
				   Double newPdnQty=pdnQuantity+workOrderQty;
			       Double totalQty=salesOrderItem.get(0).getQuantity();
			       Double dispatchedQty=salesOrderItem.get(0).getDispatchedQty();
			       Double storeQty=salesOrderItem.get(0).getCompletedQty();
			   	Double newBalanceQty=totalQty-(newPdnQty+storeQty+dispatchedQty);
			   	if(newBalanceQty<0)
			   		newBalanceQty=0.0;
				//balanceQty=quantity-woQty;
				balQtyresult=orderDetailsService.updateBalQty(salesOrderItemId,newBalanceQty,workOrderQty);
				pdnQtyResult=orderDetailsService.updatePdnQty(salesOrderItemId,newPdnQty,workOrderQty);
				if(balQtyresult==true && pdnQtyResult==true)
					soItemQtyUpdate=true;
			}//end of  if(workOrderQty<=balanceQuantity && workOrderQty!=null ) condition
		    if(soItemQtyUpdate==true)
		    	workOrderList.add(workOrderNo);
			}//end of if(createdWoItems!=null || updateWoItems==true) condition
			}//end of if(salesOrderItem.size()>0) condition
		}//end of for loop
	
		return workOrderList;
	}
	/**
	   * Method to fetch extrusion work order input records and set to grid
	   * @param workOrderNo,search,filters,pageNumber,rowsPerPage,sortColName,sortOrder
	   * @return response
	   */
	@RequestMapping(value="/records/{woNo}", produces="application/json", method=RequestMethod.POST)
	public @ResponseBody
	JqgridResponse<WorkOrderItemsDTO> records(
			@PathVariable("woNo") String workOrderNo,
    		@RequestParam("_search") Boolean search,
    		@RequestParam(value="filters", required=false) String filters,
			@RequestParam(value = "page", required = false) Integer pagenumber,
			@RequestParam(value = "rows", required = false) Integer rowsPerPage,
			@RequestParam(value = "sidx", required = false) String sortColName,
			@RequestParam(value = "sord", required = false, defaultValue = "asc") String sortOrder) {
	
		 /*  if(sortColName.equalsIgnoreCase("workOrderNo")){
				sortColName="productionWorkOrder.workOrderNo";
			}
		   if(sortColName.equalsIgnoreCase("orderId")){
				sortColName="salesOrderItem.orders.orderId";
			}
		   if(sortColName.equalsIgnoreCase("orderDetailId")){
				sortColName="salesOrderItem.orderDetailId";
			}
		   if(sortColName.equalsIgnoreCase("copperlabel")){
				sortColName="salesOrderItem.items.copperStrandDiameter.copperlabel";
			}
		   if(sortColName.equalsIgnoreCase("odLabel")){
				sortColName="salesOrderItem.items.odLabel";
			}
		   if(sortColName.equalsIgnoreCase("itemCode")){
				sortColName="salesOrderItem.items.itemCode";
			}
		   if(sortColName.equalsIgnoreCase("itemDescription")){
				sortColName="salesOrderItem.items.itemDescription";
			}
		   if(sortColName.equalsIgnoreCase("mainColour")){
				sortColName="salesOrderItem.items.mainColour.color";
			}
		   if(sortColName.equalsIgnoreCase("mainOrderSequence")){
				sortColName="salesOrderItem.items.mainColour.orderSequence";
			}
		   if(sortColName.equalsIgnoreCase("innerColour")){
				sortColName="salesOrderItem.orderDetailId";
			}
	
		   if(sortColName.equalsIgnoreCase("cableStd")){
				sortColName="salesOrderItem.orderDetailId";
			}
		   if(sortColName.equalsIgnoreCase("customerName")){
				sortColName="salesOrderItem.orderDetailId";
			}
		   if(sortColName.equalsIgnoreCase("customerCode")){
				sortColName="salesOrderItem.orderDetailId";
			}
		   if(sortColName.equalsIgnoreCase("noOfCoils")){
				sortColName="salesOrderItem.orderDetailId";
			}*/
		    int pageNumber=pagenumber-1;
		    /*Method to fetch WorkOrder item list based on the workOrderNo*/
			List<WorkOrderItems>woItemList=workOrderItemService.findWoItemList(workOrderNo);

			List<WorkOrderItems> pagedList=null;
		        int fromIndex = Math.min(woItemList.size(), pageNumber * rowsPerPage);
		        int toIndex = Math.min(woItemList.size(), fromIndex + rowsPerPage);
		          if (fromIndex == 0 && toIndex == (woItemList.size() - 1))
		        {
		            pagedList = woItemList;
		        }
		        else
		        {
		           pagedList = woItemList.subList(fromIndex, toIndex);
		        }
		    	List<WorkOrderItemsDTO> workOrderItemsDto = WorkOrderItemsMapper.map(pagedList);
	            JqgridResponse<WorkOrderItemsDTO> response = new JqgridResponse<WorkOrderItemsDTO>();
		        response.setRows(workOrderItemsDto);
		        response.setRecords(Long.valueOf(woItemList.size()).toString());
		        if(woItemList.size()>0)
		        response.setTotal(Integer.valueOf((int)Math.ceil(Double.valueOf(woItemList.size())/Double.valueOf(rowsPerPage.toString()))).toString());
		        else
		        response.setTotal("0");
		        response.setPage(Integer.valueOf(pageNumber+1).toString());
		   return response;
	}
	 /**
	   * crud functionality of extrusion work order 
	   * @param id,oper,orderId,workOrderNo,orderDetailId,totalQuantity,noOfCoils,qtyPerCoil,packingType,masterBatch,
	            toBeLabelled,stockInQty,stockInStatus
	   * @return StatusResponse
	   */
	@RequestMapping(value = "/crud", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	StatusResponse crud(@RequestParam Long id,
			@RequestParam String oper,
			@RequestParam(required = true) String orderId,
			@RequestParam(required = true) String workOrderNo,
			@RequestParam(required = true) Long orderDetailId,
			@RequestParam (required=false)  Double totalQuantity,
			@RequestParam(required = false) Integer noOfCoils,
			@RequestParam(required = false) Integer qtyPerCoil,
			@RequestParam(required = false) String packingType,
			@RequestParam (required=false)  String pvcGrade,
			@RequestParam (required=false)  String masterBatch,
			@RequestParam (required=false)  String toBeLabelled,
			@RequestParam (required=false)  Double stockInQty,
			@RequestParam (required=false)  String stockInStatus	
			) {
		Boolean result = false;
 		WorkOrderItemsDTO woItemsDTO = new WorkOrderItemsDTO();
 		/*Fetch logged in user name*/
		CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
	 	String supervisor = user.getFirstName()+" "+user.getLastName();

		   woItemsDTO.setWorkOrderItemId(id);
		   woItemsDTO.setWorkOrderNo(workOrderNo);
		   woItemsDTO.setOrderDetailId(orderDetailId);
		   woItemsDTO.setOrderId(orderId);
		   woItemsDTO.setQtyPerCoil(qtyPerCoil);
		   woItemsDTO.setNoOfCoils(noOfCoils);
		   woItemsDTO.setTotalQuantity(totalQuantity);
           woItemsDTO.setPackingType(packingType);
		   woItemsDTO.setPvcGrade(pvcGrade);
		   woItemsDTO.setMasterBatch(masterBatch);
		   woItemsDTO.setToBeLabelled(toBeLabelled);
		   woItemsDTO.setStockInQty(stockInQty);
		   woItemsDTO.setStockInStatus(stockInStatus);
		   woItemsDTO.setUpdatedBy(supervisor);
		WorkOrderItems woItems = woItemsDTO.getWorkOrderItem();
		switch (oper) {
	
		case "edit":
			result = workOrderItemService.update(woItems);
			if(result==true){
				List<WorkOrderItems>woItemsList=workOrderItemService.findByProductionWorkOrderWorkOrderNo(workOrderNo);
				if(woItemsList.size()>0){
					for(int i=0;i<woItemsList.size();i++){
						if(woItemsList.get(i).getPvcGrade()==null || woItemsList.get(i).getPvcGrade().equalsIgnoreCase("") ||  woItemsList.get(i).getMasterBatch()==null ||  woItemsList.get(i).getMasterBatch().equalsIgnoreCase("")){
						WorkOrderItemsDTO woItemDTO=new WorkOrderItemsDTO();
						woItemDTO.setWorkOrderItemId(woItemsList.get(i).getWorkOrderItemId());
						woItemDTO.setWorkOrderNo(woItemsList.get(i).getProductionWorkOrder().getWorkOrderNo());
						woItemDTO.setOrderDetailId(woItemsList.get(i).getSalesOrderItem().getOrderDetailId());
						woItemDTO.setOrderId(woItemsList.get(i).getSalesOrderItem().getOrder().getOrderId());
						woItemDTO.setQtyPerCoil(woItemsList.get(i).getQtyPerCoil());
						woItemDTO.setNoOfCoils(woItemsList.get(i).getNoOfCoils());
						woItemDTO.setTotalQuantity(woItemsList.get(i).getTotalQuantity());
						woItemDTO.setToBeLabelled(woItemsList.get(i).getToBeLabelled());
						woItemDTO.setStockInQty(woItemsList.get(i).getStockInQty());
						woItemDTO.setStockInStatus(woItemsList.get(i).getStockInStatus());
						woItemDTO.setUpdatedBy(supervisor);
                 			if(woItemsList.get(i).getPvcGrade()==null || woItemsList.get(i).getPvcGrade().equalsIgnoreCase(""))
								woItemDTO.setPvcGrade(pvcGrade);
							else
								woItemDTO.setPvcGrade(woItemsList.get(i).getPvcGrade());
							 if(woItemsList.get(i).getMasterBatch()==null || woItemsList.get(i).getMasterBatch().equalsIgnoreCase(""))
								 woItemDTO.setMasterBatch(masterBatch);
							 else
								 woItemDTO.setMasterBatch(woItemsList.get(i).getMasterBatch());
							 
							 if(woItemsList.get(i).getPackingType()==null || woItemsList.get(i).getPackingType().equalsIgnoreCase(""))
								 woItemDTO.setPackingType(packingType);
							 else
								 woItemDTO.setPackingType(woItemsList.get(i).getPackingType());
							 	 
							 WorkOrderItems workOrderItemsList=woItemDTO.getWorkOrderItem();
							 Boolean updateWoMasterBatchPvc=workOrderItemService.update(workOrderItemsList);
						  	 if(updateWoMasterBatchPvc==true)	
						  		 result=true;
					    }
			
			  }//end of for loop
				}//end of if(woItemsList.size()>0) condition
			}//end of if(result==true) condition
			break;
		case "del":
			Long woItemIdToDelete = id;
			result = workOrderItemService.delete(woItemIdToDelete);
			break;
		}//end os switch case
	return new StatusResponse(result);
	}
	/**
	   * Method to create dummy sales order
	   * @RequestParam woNo,itemCode,quantity,bundleSize
	   * @return StatusResponse
	   */
	@RequestMapping(value = "/createDummySO", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	StatusResponse createDummySales(
		 @RequestParam(value="woNo") String woNo,
   		 @RequestParam(value="itemCode") String itemCode,
   		 @RequestParam(value="quantity") Double quantity,
   		 @RequestParam(value="bundleSize") Integer bundleSize
   	) {
		/*Fetch logged in user name*/
		CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();;
	 	String userName = user.getFirstName()+" "+user.getLastName();
	 	
	    List<OrderStatus> orderStatusList=orderStatusService.findByStatus("Approved");
	    Integer orderStatusId=null;
	    if(orderStatusList.size()>0){
	    	orderStatusId=orderStatusList.get(0).getOrderStatusId();
	    }
    	Long customerId=(long) 1;	
 		Boolean soResult = false;
 		Boolean soItemResult=false;
 		Boolean woItemResult=false;
		OrderDTO orderDTO = new OrderDTO();
		orderDTO.setOrderId("BS000001");
		orderDTO.setCreatedTime("1980-01-01 00:00:00.0");
		orderDTO.setCustomerId(customerId);
		orderDTO.setOrderStatusId(orderStatusId);
		orderDTO.setCreatedBy(userName);
		orderDTO.setUpdatedBy(userName);
		orderDTO.setInputQuantity(quantity);
		orderDTO.setMailStatus("No");
		orderDTO.setLmeDetails("");
	
		java.util.Date date= new java.util.Date();
		orderDTO.setUpdatedTime(new Timestamp(date.getTime()).toString());
	  	
		SalesOrder order = orderDTO.getOrder();
		List<SalesOrder> salesOrders = orderService.findBySalesOrderNoId("BS000001");
	    if(salesOrders.size()== 0){
			SalesOrder createdOrder = orderService.create(order);
			if (createdOrder != null) 
				soResult = true;
		}
		else
			soResult=orderService.update(order);//end of if(salesOrders.size()== 0) else condition
					
	SalesOrderItem createdSoItem =null;	
	Long orderDetailId=null;
	Double quantities=null;
	int bundles=0;
	DecimalFormat threeDForm = new DecimalFormat("0.0");
	List<SalesOrderItem>soItemList=orderDetailsService.findByOrdersOrderIdItemsItemCode("BS000001", itemCode);
	if(soResult==true){
	if(soItemList.size()==0){
	            SalesOrderItemsDTO soitemsDTO = new SalesOrderItemsDTO();
				soitemsDTO.setOrderId("BS000001");
				List <Item> itemIdList=itemService.fetchItemId(itemCode);
				Long itemId=itemIdList.get(0).getItemId();
				Double weight=null;
			//String productKey=itemIdList.get(0).getProductType().getProductKey();
				Double noOfCuStrand=(double)itemIdList.get(0).getNumberOfCopperStrands();
				String units=itemIdList.get(0).getUnit().getUnits();
				Double stranddDiameter=Double.valueOf(itemIdList.get(0).getCopperStrandDiameter().getCopperkey())/1000;
		    /*	if(productKey.equalsIgnoreCase("BA") || productKey.equalsIgnoreCase("BC") || productKey.equalsIgnoreCase("CS") ||
						   productKey.equalsIgnoreCase("MS")|| productKey.equalsIgnoreCase("PA") || productKey.equalsIgnoreCase("PL") || productKey.equalsIgnoreCase("PS") ||
						   productKey.equalsIgnoreCase("PV") || productKey.equalsIgnoreCase("RA") || productKey.equalsIgnoreCase("RB") ||  productKey.equalsIgnoreCase("RI")){
		*/		
		    	if(units.equalsIgnoreCase("Kgs") || units.equalsIgnoreCase("Kg")){	
		    		weight=quantity;
				}
				else{
					Double roundUpWeight=noOfCuStrand*stranddDiameter*stranddDiameter*0.6985*1.015;
					   String weightVal=threeDForm.format((Double.valueOf(roundUpWeight)/100)*quantity);
					   weight=Double.valueOf(weightVal);
			    }		
				soitemsDTO.setItemId(itemId);
				soitemsDTO.setItemCode(itemCode);
				soitemsDTO.setQuantity(quantity);
				soitemsDTO.setBalanceQty(0.0);
				soitemsDTO.setCompletedQty(0.0);
				soitemsDTO.setProductionQty(quantity);
				soitemsDTO.setWoQty(quantity);
				soitemsDTO.setDispatchedQty(0.0);
				soitemsDTO.setBundleSize(bundleSize);
				soitemsDTO.setUpdatedBy(userName);
				soitemsDTO.setWeight(weight);
				soitemsDTO.setPvcWeight(weight);
				soitemsDTO.setUpdatedTime(new Timestamp(date.getTime()).toString());
				SalesOrderItem soitem = soitemsDTO.getOrderDetail();
				 
				createdSoItem = orderDetailsService.create(soitem);
				if (createdSoItem != null) 
					soItemResult = true;
				orderDetailId=createdSoItem.getOrderDetailId();
				quantities=createdSoItem.getQuantity();
				bundles=createdSoItem.getBundleSize();
	}//end of if(soItemList.size()==0) condition
	else{
		Double newWeight=0.0;
		Double newSoQty=soItemList.get(0).getQuantity()+quantity;
		Double newPdnQty=soItemList.get(0).getProductionQty()+quantity;
		String productKey=soItemList.get(0).getItem().getProductType().getProductKey();
		Double noOfCuStrand=(double)soItemList.get(0).getItem().getNumberOfCopperStrands();
		Double stranddDiameter=Double.valueOf(soItemList.get(0).getItem().getCopperStrandDiameter().getCopperkey())/1000;
	
		if(productKey.equalsIgnoreCase("BA") || productKey.equalsIgnoreCase("BC") || productKey.equalsIgnoreCase("CS") ||
				   productKey.equalsIgnoreCase("MS")|| productKey.equalsIgnoreCase("PA") || productKey.equalsIgnoreCase("PL") || productKey.equalsIgnoreCase("PS") ||
				   productKey.equalsIgnoreCase("PV") || productKey.equalsIgnoreCase("RA") || productKey.equalsIgnoreCase("RB") ||  productKey.equalsIgnoreCase("RI")){
			newWeight=quantity;
						}
		else{
			Double roundUpWeight=noOfCuStrand*stranddDiameter*stranddDiameter*0.6985*1.015;
			   String weightVal=threeDForm.format((Double.valueOf(roundUpWeight)/100)*quantity);
			   newWeight=Double.valueOf(weightVal);
	    }		

		  SalesOrderItemsDTO soitemDTO = new SalesOrderItemsDTO();
		  soitemDTO.setOrderDetailId(soItemList.get(0).getOrderDetailId());
		  soitemDTO.setOrderId(soItemList.get(0).getOrder().getOrderId());
		  soitemDTO.setItemId(soItemList.get(0).getItem().getItemId());
		  soitemDTO.setItemCode(soItemList.get(0).getItem().getItemCode());
		  soitemDTO.setQuantity(newSoQty);
		  soitemDTO.setBalanceQty(0.0);
		  soitemDTO.setCompletedQty(soItemList.get(0).getCompletedQty());
		  soitemDTO.setProductionQty(newPdnQty);
		  soitemDTO.setWoQty(quantity);
		  soitemDTO.setDispatchedQty(soItemList.get(0).getDispatchedQty());
		  soitemDTO.setBundleSize(soItemList.get(0).getBundleSize());
		  soitemDTO.setUpdatedBy(userName);
		  soitemDTO.setWeight(newWeight);
		  soitemDTO.setPvcWeight(newWeight);
		  soitemDTO.setUpdatedTime(new Timestamp(date.getTime()).toString());
		  orderDetailId=soItemList.get(0).getOrderDetailId();
		  quantities=soItemList.get(0).getQuantity();
		  bundles=soItemList.get(0).getBundleSize();
			SalesOrderItem soitemObj = soitemDTO.getOrderDetail();
			soItemResult=orderDetailsService.update(soitemObj);
     }
	}//end of if(soResult==true) condition
	
	  if(soItemResult == true){
		  WorkOrderItemsDTO woItemsDTO = new WorkOrderItemsDTO();
		  woItemsDTO.setWorkOrderNo(woNo);
		  woItemsDTO.setOrderDetailId(orderDetailId);
		  woItemsDTO.setTotalQuantity(quantities);
		  woItemsDTO.setPackingType("");
		  woItemsDTO.setStockInQty(0.0);
		  woItemsDTO.setStockInStatus("Pending");
		  woItemsDTO.setUpdatedBy(userName);
	
			    int bundlesize=bundles;
			    Double totQty=quantities;
			    int coilNo=(int)Math.ceil(totQty/bundlesize);
			    woItemsDTO.setNoOfCoils(coilNo);
			    woItemsDTO.setQtyPerCoil(bundleSize);
		 
		  WorkOrderItems woItems=woItemsDTO.getWorkOrderItem();
		  
		  WorkOrderItems createdWoItems = workOrderItemService.create(woItems);
			if (createdWoItems != null) {
				woItemResult = true;
			}
	   }//end of if(soItemResult == true) condition

		return new StatusResponse(woItemResult);
	}
	/**
	   * Method to delete work order item
	   * @PathVariable woItemId
	   * @return StatusResponse
	   */
	@RequestMapping(value = "/delete/{woItemId}", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody StatusResponse deleteId(@PathVariable("woItemId") Long woItemId) {
		    Boolean result=false;
		    Boolean updateResult=false;
		    /*Method to fetch work order item based on work order item id*/
		    List<WorkOrderItems> woItemsList=workOrderItemService.findById(woItemId);
		    Long salesOrderItemId=woItemsList.get(0).getSalesOrderItem().getOrderDetailId();
		    String orderId=woItemsList.get(0).getSalesOrderItem().getOrder().getOrderId();
		    Double balQty=woItemsList.get(0).getSalesOrderItem().getBalanceQty();
		    Double pdnQty=woItemsList.get(0).getSalesOrderItem().getProductionQty();
		    Double woQty=woItemsList.get(0).getTotalQuantity();
		    Double totalQty=woItemsList.get(0).getSalesOrderItem().getQuantity();
		    Double newBalQty=0.0;
		    Double newPdnQty=0.0;
		    Double newTotalQty=0.0;
		    if(orderId.equalsIgnoreCase("BS000001")){
		    	newBalQty=0.0;
		    	if(woQty<totalQty){
		    		newTotalQty=totalQty-woQty;
				  	newPdnQty=pdnQty-woQty;
			     }//end of if(woQty<totalQty) condition
		    }//end of  if(orderId.equalsIgnoreCase("BS000001")) condition
		    else{
		    	newTotalQty=totalQty;
		    	newBalQty=balQty+woQty;
		    	if(pdnQty>woQty)
		    		newPdnQty=pdnQty-woQty;
		    }
		    result = workOrderItemService.delete(woItemId);
		    if(result==true)
			    updateResult=orderDetailsService.updateBalPdnQty(salesOrderItemId,newTotalQty,newBalQty,newPdnQty);

			return new StatusResponse(updateResult);
	}	
	/**
	   * Method to check sales order item status
	   * @PathVariable soItemId
	   * @return soItemStatusList
	   */
	@RequestMapping(value = "/checkStatus/{soItemId}", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	List<String> checkStatus(@PathVariable("soItemId") Long soItemId) {
		Boolean pdnExist=false;
		    List<WorkOrderItems> woItemsList=workOrderItemService.findBySalesOrderItem(soItemId);
		    if(woItemsList.size()>0){
		    	pdnExist=true;
		    }else{
			    List<WorkOrderOutput> woOutputList=workOrderOutputService.findBySalesOrderItem(soItemId);
			    if(woOutputList.size()>0)
			    	pdnExist=true;
			    else
			    	pdnExist=false;

		    }
		    
		   List<String> soItemStatusList=new ArrayList<>();
		    if(pdnExist==true){
		    	soItemStatusList.add("exist")	;
		    }
		    else soItemStatusList.add("not exist");
		    
		   return soItemStatusList;
	}	
	/**
	   * Method to check sales order item status
	   * @PathVariable orderId
	   * @return soItemStatusList
	   */
	@RequestMapping(value = "/checkOrderStatus/{soId}", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	List<String> checkOrderStatus(@PathVariable("soId") String orderId) {
		 
		List<WorkOrderItems> woItemsList=workOrderItemService.findBySalesOrderItemOrdersOrderId(orderId);
		   List<String> soItemStatusList=new ArrayList<>();
		    if(woItemsList!=null  && woItemsList.size()>0){
		    	soItemStatusList.add("exist")	;
		    }
		    else soItemStatusList.add("not exist");
		   return soItemStatusList;
	}	
	/**
	   * Method to submit work order
	   * @PathVariable woNo
	   * @return StatusResponse
	   */
	@RequestMapping(value="/submitWorkOrder/{woNo}", produces="application/json", method=RequestMethod.POST)
	public @ResponseBody
	StatusResponse submitExtrusionWorkOrder(
			@PathVariable("woNo") String woNo) {

		Boolean result=false;
		String submitStatus="Submitted";
		result=productionWorkOrderService.updateWorkOrderStatus(woNo,submitStatus);
		
		return new StatusResponse(result);
	}
	/**
	   * Method to submit work order
	   * @RequestParam woNo,itemCode
	   * @return woItemExist
	   */
	@RequestMapping(value = "/checkDummyWoItemExist", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	List<String> checkDummyWoItemStatus(
			 @RequestParam(value="woNo") String woNo,
	   		 @RequestParam(value="itemCode") String itemCode) {
		
		    String dummySalesOrder="BS000001";
		    /*Initizlization of list of type String*/
		    List<String> woItemExist=new ArrayList<>();
		    /*Method to fetch work order items list*/
		    List<WorkOrderItems> woItemsList=workOrderItemService.findByOrderIdAndItemCodeAndWorkOrderNo(dummySalesOrder, itemCode, woNo);
		  
		    if(woItemsList.size()>0){
		    	woItemExist.add("Exist");
		    }
		    else{
		    	woItemExist.add("NotExist");
		    }
		   return woItemExist;
	}	
	/**
	   * Method to fetech pvc grade
	   * @return pvcGrade
	   */
	@RequestMapping(value="/pvcGrade", produces="application/json", method=RequestMethod.GET)
	public @ResponseBody
	List<String> pvcGrade() {
	/*Method to fetch pvc grade list*/
	List<PvcGrade> pvcGradeList=pvcGradeRepository.findAll();
	/*Initizlization of list of type String*/
	List<String> pvcGrade=new ArrayList<>();
	for(int k=0;k<pvcGradeList.size();k++){
		pvcGrade.add(pvcGradeList.get(k).getGrade());
	}//end of for loop
 	return pvcGrade;
	}
}


