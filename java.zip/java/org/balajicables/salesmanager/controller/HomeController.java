package org.balajicables.salesmanager.controller;

import java.text.DateFormat;

import java.util.Date;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {

	
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		logger.info("Welcome home! the client locale is "+ locale.toString());
		
		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		
		String formattedDate = dateFormat.format(date);
		/*	ArrayList<String> soNos = new ArrayList<String>();
		ArrayList<String> poNos = new ArrayList<String>();*/
		//String ar="";
		model.addAttribute("serverTime", formattedDate );
		/*List<SalesOrder>soList= orderService.findByOrderStatusStatus("Pending");
		List<PurchaseOrder>poList= purchaseOrderService.findByPurchaseOrderStatus("Submitted");
		if(soList.size()>0){
			for(int k=0;k<soList.size();k++)
				soNos.add(soList.get(k).getOrderId());
		
					model.addAttribute("orders", soNos );
    	}else{
    		model.addAttribute("orders", "No Sales Order for Approval" );
    	}
		if(poList.size()>0){
			for(int j=0;j<poList.size();j++)
				poNos.add(poList.get(j).getPoNo());
		
					model.addAttribute("purchaseOrders", poNos );
    	}else{
    		model.addAttribute("purchaseOrders", "No Purchase Order for Approval" );
    	}*/
		return "home";
	}
	
}
