package org.balajicables.salesmanager.controller;

import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;

import org.balajicables.salesmanager.CustomUser;
import org.balajicables.salesmanager.common.JqgridResponse;
import org.balajicables.salesmanager.dto.StockInDTO;
import org.balajicables.salesmanager.model.Item;
import org.balajicables.salesmanager.service.CustomerService;
import org.balajicables.salesmanager.service.ItemService;
import org.balajicables.salesmanager.service.StockInService;
import org.joda.time.DateTime;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
/**
* This class demonstartes Inventory Movement.
* @author Abin Sam
*/
@Controller
@RequestMapping("/inventoryMovement")
public class InventoryMovementController {

	@Resource
	private ItemService itemService;
	
	@Resource
	private StockInService stockInService;

	@Resource
	private CustomerService customerService;
	 /**
	   * This method returns inventoryMovement.jsp.
	   * @param Model to set the attribute.
	   * @return inventoryMovement.jsp.
	   */
	@RequestMapping(method = RequestMethod.GET)
	public String getStockOnDatePage(Model model) {
		/*Method to fetch Item list*/
		List<Item> itemList=itemService.getAllItems();
		
		ArrayList<Integer>layLengthList = new ArrayList<>();
		ArrayList<Integer>cuStrandsList = new ArrayList<>();
		ArrayList<String> layTypeList = new ArrayList<>();
		ArrayList<String> outerDiameterList = new ArrayList<>();
		ArrayList<String> cuDiameterList = new ArrayList<>();
		
		if(itemList.size()>0){
			
		for (int iterator = 0; iterator < itemList.size(); iterator++) {
			int layLength=itemList.get(iterator).getLayLength();
			String layType=itemList.get(iterator).getLayType();
			String outerDiameter=itemList.get(iterator).getOuterDiameter();
			int cuStrands=itemList.get(iterator).getNumberOfCopperStrands();
			String cuDiameter=itemList.get(iterator).getCopperStrandDiameter().getCopperkey();
        	if (!layLengthList.contains(layLength)) {
        		layLengthList.add(layLength);
			}
        	if (!layTypeList.contains(layType)) {
        		layTypeList.add(layType);
    			}
        	if (!outerDiameterList.contains(outerDiameter)) {
        		outerDiameterList.add(outerDiameter);
    			}
         	if (!cuStrandsList.contains(cuStrands)) {
         		cuStrandsList.add(cuStrands);
    			}
           	if (!cuDiameterList.contains(cuDiameter)) {
           		cuDiameterList.add(cuDiameter);
    			}
		}//end of for loop
		}//end of if(itemList.size()>0) condition
		model.addAttribute("customers", customerService.findAll());//set customers to model attribute
		model.addAttribute("colours", itemService.getAllColours());//set colors to model attribute
		model.addAttribute("copperDiameters", itemService.getAllCopperDiameters());//set copper diameters to model attribute
		model.addAttribute("productTypes", itemService.getAllProductTypes());//set product types to model attribute
		model.addAttribute("cableStdPvcs", itemService.getAllCableStdPvcs());//set cableStdPvcs to model attribute
		model.addAttribute("layLength",layLengthList);//set laylengths to model attribute
		model.addAttribute("layType",layTypeList);//set laytypes to model attribute
		model.addAttribute("outerDiameters",outerDiameterList);//set outerdiameters to model attribute
		model.addAttribute("cuStrands",cuStrandsList);//set copper strands to model attribute
		model.addAttribute("cuDiameters",cuDiameterList);//set copper diameters to model attribute
	
		return "inventoryMovement";
	}
	/** Method to generate InventoryMovement report
	   * @param  fromDate,toDate
	   * @return void
	   */
	@RequestMapping(value = "/revenueFiguresReport", produces = "application/pdf", method = RequestMethod.GET)

	public void RevenueFiguresReport(@RequestParam(value = "fromDate", required = true) String fromDate,
			                     @RequestParam(value = "toDate", required = true) String toDate,  
			                     javax.servlet.http.HttpServletResponse response) throws IOException, InterruptedException, ParseException{
		
		if(fromDate!=null && fromDate!="" && toDate!=null && toDate!=""){
		 InputStream inputStream = getClass().getClassLoader().getResourceAsStream("/org/balajicables/salesmanager/report/RevenueFiguresReport.jrxml");
		
		 
		 DateFormat df = new SimpleDateFormat("dd-MM-yyyy");
	     java.util.Date fromDt = df.parse(fromDate);
	     java.util.Date toDt = df.parse(toDate);
	 
		 Map<String, Object> hm= new HashMap<String, Object>();
	     hm.put("FROM_DATE", fromDt);//set report parameter
	     hm.put("TO_DATE", toDt);//set report parameter
	     byte[] content = ReportGenerator.newReportGenerator(inputStream,hm);//call new report generator method
	    
		response.setContentType("application/pdf");
		response.setHeader("Content-Disposition", "attachment;filename=" + "RevenueFiguresReport"+fromDate+"-to-"+toDate+".pdf");//setting report PDF name
		response.setContentLength(content.length);
	    FileCopyUtils.copy(content, response.getOutputStream());
	}
	}
	/** *Method to fetch inventory movement details
	    * @param  fromDate,toDate,party,itemCode,cablesStd,productType,mainColour,stripeColour,noOfCuStrand,
	             layType,layLength,od,cuDiameter,salesorder,workOrder,pageNumbers,rowsPerPage,sortColName,sortOrder
	    * @return response
	   */
	@RequestMapping(value="/inventoryDetails", produces="application/json", method=RequestMethod.POST)
	public @ResponseBody
	JqgridResponse<StockInDTO> inventoryMovementRecords(
			@RequestParam(value ="fromDate", required = false) String fromDate,
			@RequestParam(value ="toDate", required = false) String toDate,
			@RequestParam(value ="party", required = false) String party,
			@RequestParam(value ="itemCode", required = false) String itemCode,
			@RequestParam(value ="cablesStd", required = false) String cablesStd,
			@RequestParam(value ="productType", required = false) String productType,
			@RequestParam(value ="mainColour", required = false) String mainColour,
			@RequestParam(value ="stripeColour", required = false) String stripeColour,
			@RequestParam(value ="noOfCuStrand", required = false) Long noOfCuStrand,	
			@RequestParam(value ="layType", required = false) String layType,
			@RequestParam(value ="layLength", required = false) Integer layLength,
			@RequestParam(value ="od", required = false) String od,
			@RequestParam(value ="cuDiameter", required = false) String cuDiameter,	
			@RequestParam(value ="salesOrder", required = false) String salesorder,	
			@RequestParam(value ="salesOrder", required = false) String workOrder,				
			@RequestParam(value = "page", required = false) Integer pageNumbers,
			@RequestParam(value = "rows", required = false) Integer rowsPerPage,
			@RequestParam(value = "sidx", required = false) String sortColName,
			@RequestParam(value = "sord", required = false, defaultValue = "asc") String sortOrder) throws ParseException {
		/*Fetch logged in username*/ 
		CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();;
		String userName = user.getFirstName()+" "+user.getLastName();
	
		DateTime dt=new DateTime();
		 if(party==null || party=="" )
			 party="All";
		 if(itemCode==null || itemCode=="")
			 itemCode="All";
		 if(salesorder==null || salesorder=="")
			 salesorder="All";
		 if(workOrder==null || workOrder=="")
			 workOrder="All";
		 if(mainColour==null || mainColour=="")
			 mainColour="All";
		 if(stripeColour==null || stripeColour=="")
			 stripeColour="All";
		 if(od==null || od=="")
			 od="All";
		 if(cablesStd==null || cablesStd=="")
			 cablesStd="All";
		 if(productType==null || productType=="")
			 productType="All";
		 if(layLength==null)
			 layLength=0;
		 if(layType==null || layType=="")
			 layType="All";
		 if(cuDiameter==null || cuDiameter=="")
			 cuDiameter="All";
		 if(noOfCuStrand==null)
			 noOfCuStrand=(long) 0;
		 
		 if(fromDate=="" || fromDate==null){
			 if(dt.getMonthOfYear()<10)
			 fromDate="01"+"-"+"0"+dt.getMonthOfYear()+"-"+dt.getYear();
			 else
			 fromDate="01"+"/"+dt.getMonthOfYear()+"-"+dt.getYear();	 
		 }//end of if(fromDate=="" || fromDate==null) condition
		 
         if(toDate=="" || toDate==null){
        	if(dt.getMonthOfYear()<10 && dt.getDayOfMonth()<10 )
        	 toDate="0"+dt.getDayOfMonth() +"-0"+dt.getMonthOfYear()+"-"+dt.getYear();
        	else if(dt.getMonthOfYear()<10)
        	toDate=dt.getDayOfMonth() +"-0"+dt.getMonthOfYear()+"-"+dt.getYear();	
        	else if(dt.getDayOfMonth()<10)
        	toDate="0"+dt.getDayOfMonth() +dt.getMonthOfYear()+"-"+dt.getYear();		
        	else 
        	 toDate= dt.getDayOfMonth()+"-"+dt.getMonthOfYear()+"-"+dt.getYear();
		 }//end of  if(toDate=="" || toDate==null) condition
         
		 if((fromDate!=null && fromDate!="")&&(toDate!=null && toDate!="")){
			 fromDate=fromDate.substring(6,10)+"-"+fromDate.substring(3,5)+"-"+fromDate.substring(0,2);
			 toDate=toDate.substring(6,10)+"-"+toDate.substring(3,5)+"-"+toDate.substring(0,2);
	      }
         /*Initialization of empty List of type StockInDTO*/
		  List<StockInDTO> stockInDTOs = new ArrayList<>();
		  /*Method to fetch inventory movement details*/
			 List<Object[]> stockQueryList=stockInService.getStockDetails(fromDate, toDate, party,
					 itemCode, salesorder, workOrder, mainColour, stripeColour, od, cablesStd,
					 productType, layLength, layType, cuDiameter, noOfCuStrand);
			 
			 
			 Integer pagenumber=0;
			 if(pageNumbers!=null)
		     pagenumber= pageNumbers-1;
		 
		  int fromIndex = Math.min(stockQueryList.size(), pagenumber * rowsPerPage);
	      int toIndex = Math.min(stockQueryList.size(), fromIndex + rowsPerPage);
	      List<Object[]> pagedList;
		   if (fromIndex == 0 && toIndex == (stockQueryList.size() - 1))
	          pagedList = stockQueryList;
	       else
	          pagedList = stockQueryList.subList(fromIndex, toIndex);
		   for(Object[] element : pagedList) {
				 DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
				  String stockDate=df.format(element[0]); 
				  
				  String stockParty=(String) element[1];
				  String stockItemCode=(String) element[2];
				  String stockAssortedType=(String) element[3];
				  String storeAdd=(String) element[6];
				  String description=(String) element[7];
				  String unit=(String) element[8];
				  String soNo=(String) element[9];
				  String woNo=(String) element[10];
				  Double stockInQty=0.0;
				  Double stockOutQty=0.0;
				
					  stockInQty=(Double) element[4];
					  stockOutQty=(Double) element[5];
						  
			         StockInDTO stockInDTO=new StockInDTO();
				     stockInDTO.setCustomerCode(stockParty);
				     stockInDTO.setItemCode(stockItemCode);
				     stockInDTO.setStockQty(stockInQty);
				     stockInDTO.setWeight(stockOutQty);
				     stockInDTO.setAssortedType(stockAssortedType);
				     stockInDTO.setDcStatus(stockDate);
				     stockInDTO.setConfirmStatus(stockDate);
				     stockInDTO.setStoreAddress(storeAdd);
				     stockInDTO.setItemDescription(description);
				     stockInDTO.setUnits(unit);
				     stockInDTO.setOrderId(soNo);
				     stockInDTO.setWorkOrderNo(woNo);
				     stockInDTOs.add(stockInDTO);
				     stockInDTO.setSupervisor(userName);
		   	}
			/*Intialize JQ grid response of type StockInDTO*/	
		   JqgridResponse<StockInDTO> response = new JqgridResponse<StockInDTO>();
	       response.setRows(stockInDTOs);
	       response.setRecords(Long.valueOf(stockQueryList.size()).toString());
	       if(stockQueryList.size()>0)
	        response.setTotal(Integer.valueOf((int)Math.ceil(Double.valueOf(stockQueryList.size())/Double.valueOf(rowsPerPage.toString()))).toString());
	       else
	       response.setTotal("0");
	       response.setPage(Integer.valueOf(pagenumber+1).toString());
	       return response;
	}
	/**  * Method to fetch inventory movement ItemCode
	     * @return itemCodesList
	   */
	@RequestMapping(value="/fetchInventoryItemCode", produces="application/json", method=RequestMethod.GET)
	public @ResponseBody List<String> fetchItemCode(){
		List<String>itemCodesList=itemService.fetchInventoryItemCodes();
		return itemCodesList;
		
	}
}