package org.balajicables.salesmanager.controller;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Resource;
import org.balajicables.salesmanager.common.ItemMapper;
import org.balajicables.salesmanager.common.JqgridFilter;
import org.balajicables.salesmanager.common.JqgridObjectMapper;
import org.balajicables.salesmanager.common.JqgridResponse;
import org.balajicables.salesmanager.common.StatusResponse;
import org.balajicables.salesmanager.dto.ItemDTO;
import org.balajicables.salesmanager.model.Area;
import org.balajicables.salesmanager.model.AssortedRate;
import org.balajicables.salesmanager.model.CableStdPvc;
import org.balajicables.salesmanager.model.Colour;
import org.balajicables.salesmanager.model.CopperDiameter;
import org.balajicables.salesmanager.model.CustomerPartNo;
import org.balajicables.salesmanager.model.Item;
import org.balajicables.salesmanager.model.ProductType;
import org.balajicables.salesmanager.model.PurchaseOrderItem;
import org.balajicables.salesmanager.model.PvcStockOut;
import org.balajicables.salesmanager.model.SalesOrder;
import org.balajicables.salesmanager.model.SalesOrderItem;
import org.balajicables.salesmanager.model.ScrapDetails;
import org.balajicables.salesmanager.model.ScrapStoreReg;
import org.balajicables.salesmanager.service.AssortedRateService;
import org.balajicables.salesmanager.service.CustomerPartNoService;
import org.balajicables.salesmanager.service.ItemService;
import org.balajicables.salesmanager.service.OrderDetailsService;
import org.balajicables.salesmanager.service.OrderService;
import org.balajicables.salesmanager.service.PurchaseOrderItemService;
import org.balajicables.salesmanager.service.PvcStockOutService;
import org.balajicables.salesmanager.service.ScrapDetailsService;
import org.balajicables.salesmanager.service.ScrapStoreRegService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
/**
* This class demonstrates Extrusion WorkOrder Process.
* @author Abin Sam
*/
@Controller
@RequestMapping("/items")
public class ItemController {

	@Autowired
	private ItemService itemService;
	@Resource
	private OrderService orderService;
	@Resource
	private AssortedRateService assortedRateService;
	@Resource
	private CustomerPartNoService customerPartNoService;
	@Resource
	private PurchaseOrderItemService purchaseOrderItemService;
	@Resource
	private PvcStockOutService pvcStockOutService;
	@Resource
	private OrderDetailsService orderDetailsService;
	@Resource
	private ScrapStoreRegService scrapStoreRegService;
	@Resource
	private ScrapDetailsService scrapDetailsService;
	/**
	   * This method returns itemConfiguration.jsp
	   * Fetch all cableStdPvcs,colours,copperDiameters,productTypes,units
	   * @param Model to set the attribute.
	   * @return extrusionWorkOrder.jsp.
	   */
	@RequestMapping
	public String getItemsPage(Model model) {

		model.addAttribute("cableStdPvcs", itemService.getAllCableStdPvcs());
		model.addAttribute("colours", itemService.getAllColours());
		model.addAttribute("copperDiameters",itemService.getAllCopperDiameters());
		model.addAttribute("productTypes", itemService.getAllProductTypes());
		model.addAttribute("units", itemService.getAllUnits());
		
		return "itemConfiguration";
	}
	/**
	   * Method to fetch ItemMaster records and set to grid
	   * @param searchObject,search,filters,pageNumber,rowsPerPage,sortColName,sortOrder
	   * @return response
	   */
	@RequestMapping(value = "/records", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	JqgridResponse<ItemDTO> records(
			@RequestParam(value = "searchObject", required = false) String searchObject,
			@RequestParam("_search") Boolean search,
			@RequestParam(value = "filters", required = false) String filters,
			@RequestParam(value = "page", required = false) Integer pageNumber,
			@RequestParam(value = "rows", required = false) Integer rowsPerPage,
			@RequestParam(value = "sidx", required = false) String sortColName,
			@RequestParam(value = "sord", required = false, defaultValue = "asc") String sortOrder) {
		   /*JQGrid column sorting*/
		 
		  if(sortColName.equalsIgnoreCase("numberOfCopperStrand")){
				sortColName="numberOfCopperStrands";
			}
		  if(sortColName.equalsIgnoreCase("mainColourItem")){
				sortColName="mainColour.colorKey";
			}
		  if(sortColName.equalsIgnoreCase("innerColourItem")){
				sortColName="innerColour.color";
			}
	     if(sortColName.equalsIgnoreCase("productTypeKey")){
				sortColName="productType.productKey";
			}
		 if(sortColName.equalsIgnoreCase("cableStdKey")){
				sortColName="cableStdPvc.cableStdKey";
			}
		if(sortColName.equalsIgnoreCase("copperkey")){
				sortColName="copperStrandDiameter.copperkey";
			}
	   if(sortColName.equalsIgnoreCase("area")){
				sortColName="area.area";
			}
	  if(sortColName.equalsIgnoreCase("areaValue")){
				sortColName="area.areaValue";
			}
	  if(sortColName.equalsIgnoreCase("weight")){
			sortColName="copperWeight";
		}  
		if (searchObject == null || searchObject.equalsIgnoreCase("allSearch")) {
			/*Method to fetch JQGRID paged records of Item Master*/
			Page<Item> item = itemService.getItemPagedStore(pageNumber - 1,	rowsPerPage, sortColName, sortOrder);
			/*Intialize JQ grid response of type ItemDTO*/	
			JqgridResponse<ItemDTO> response = new JqgridResponse<ItemDTO>();
			/*Method to set Bunching Workorder Output items list to BunchingWOInputDTO*/
			List<ItemDTO> storeDTOs = convertToItemsDTO(item.getContent());
			response.setRows(storeDTOs);
			response.setRecords(Long.valueOf(item.getTotalElements()).toString());
			response.setTotal(Long.valueOf(item.getTotalPages()).toString());
			response.setPage(Integer.valueOf(item.getNumber() + 1).toString());
			return response;

		}//end of if (searchObject == null || searchObject.equalsIgnoreCase("allSearch")) condition
		else {
			
			return getFilteredRecords(searchObject, pageNumber - 1,rowsPerPage, sortColName, sortOrder);
		}
	}
	/**
	   * This method to fetch Item master item based on search parameter and set response to JQGRID
	   * Fetch Item master item details for grid
	   * @param filters,pageNumber,rowsPerPage,sortColName,sortOrder
	   * @return JqgridResponse<ItemDTO> response
	   */
	private JqgridResponse<ItemDTO> getFilteredRecords(String filters,
			int pagenumber, Integer rows, String sortColName, String sortOrder) {
		String qItemCode = null;
		Integer qNumberOfCopperStrands = 0;
		String qCopperKey = null;
		String qOuterDiameter = null;
		String qOdLabel = null;
		String qMainColour = null;
		String qInnerColor = null;
		String qMainColourKey = null;
		String qInnerColorKey = null;
		String qCableStdKey = null;
		String qLayLength = null;
		String qLayType = null;
		String qProductKey = null;
		//JQ Grid filtering parameters
		JqgridFilter jqgridFilter = JqgridObjectMapper.map(filters);
		for (JqgridFilter.Rule rule : jqgridFilter.getRules()) {
			if (rule.getField().equals("itemCode"))
				qItemCode = rule.getData();
			else if (rule.getField().equals("numberOfCopperStrands")) {
				if (rule.getData() == "" || rule.getData() == null)
					qNumberOfCopperStrands = 0;
				else
					qNumberOfCopperStrands = Integer.parseInt(rule.getData());
			} else if (rule.getField().equals("copperkey"))
				qCopperKey = rule.getData();
			else if (rule.getField().equals("outerDiameter"))
				qOuterDiameter = rule.getData();
			else if (rule.getField().equals("odLabel"))
				qOdLabel = rule.getData();
			else if (rule.getField().equals("mainColour"))
				qMainColour = rule.getData();
			else if (rule.getField().equals("innerColour"))
				qInnerColor = rule.getData();
			else if (rule.getField().equals("mainColourKey"))
				qMainColourKey = rule.getData();
			else if (rule.getField().equals("innerColourKey"))
				qInnerColorKey = rule.getData();
			else if (rule.getField().equals("cableStdKey"))
				qCableStdKey = rule.getData();
			else if (rule.getField().equals("layLength"))
				qLayLength = rule.getData();
			else if (rule.getField().equals("layType"))
				qLayType = rule.getData();

			else if (rule.getField().equals("productKey"))
				qProductKey = rule.getData();
		}
		/*Method to fetch Item Master items based on filtering params*/
		List<Item> item = itemService.fetchBySearch(qItemCode,
				qNumberOfCopperStrands, qCopperKey, qOuterDiameter, qOdLabel,
				qMainColour, qInnerColor, qMainColourKey, qInnerColorKey,
				qCableStdKey, qLayLength, qLayType, qProductKey, pagenumber,
				rows, sortColName, sortOrder);

		List<Item> pagedList;
		int fromIndex = Math.min(item.size(), pagenumber * rows);
		int toIndex = Math.min(item.size(), fromIndex + rows);

		if (fromIndex == 0 && toIndex == (item.size() - 1)) {
			pagedList = item;
		} else {
			pagedList = item.subList(fromIndex, toIndex);
		}
		 /*Set paged store regsiter response to ItemDTO*/
		List<ItemDTO> itemDto = ItemMapper.map(pagedList);
		/*Intialize JQ grid response of type StoreRegisterDTO*/
		JqgridResponse<ItemDTO> response = new JqgridResponse<ItemDTO>();
		response.setRows(itemDto);
		response.setRecords(Long.valueOf(item.size()).toString());
		if (item.size() > 0)
			response.setTotal(Integer.valueOf((int) Math.ceil(Double.valueOf(item.size())/ Double.valueOf(rows.toString()))).toString());
		else
			response.setTotal("0");
		response.setPage(Integer.valueOf(pagenumber + 1).toString());
		return response;

	}
	 /**
	   * This method to set Item Master items to ItemDTO
	   * @param Item
	   * @return List<ItemDTO>
	   */
	private List<ItemDTO> convertToItemsDTO(List<Item> itemRegs) {

		List<ItemDTO> itemDTOs = new ArrayList<>();
		for (Item itemReg : itemRegs) {
			ItemDTO itemRegDTO = new ItemDTO();
			itemRegDTO.setAreaValue(itemReg.getArea().getAreaValue());
			itemRegDTO.setAssortedType(itemReg.getAssortedType());
			itemRegDTO.setCableStdKey(itemReg.getCableStdPvc().getCableStd());
			itemRegDTO.setCopperKey(itemReg.getCopperStrandDiameter().getCopperkey());
			itemRegDTO.setInnerColorKey(itemReg.getInnerColour().getColorKey());
			itemRegDTO.setInputSize(itemReg.getInputSize());
			itemRegDTO.setItemCode(itemReg.getItemCode());
			itemRegDTO.setItemDescription(itemReg.getItemDescription());
			itemRegDTO.setItemId(itemReg.getItemId());
			itemRegDTO.setItemLabel(itemReg.getItemLabel());
			itemRegDTO.setItemType(itemReg.getItemType());
			itemRegDTO.setLayLength(itemReg.getLayLength());
			itemRegDTO.setLayType(itemReg.getLayType());
			itemRegDTO.setMainColorKey(itemReg.getMainColour().getColorKey());
			itemRegDTO.setNumberOfCopperStrand(itemReg.getNumberOfCopperStrands());
			itemRegDTO.setOdLabel(itemReg.getOdLabel());
			itemRegDTO.setOuterDiameter(itemReg.getOuterDiameter());
			itemRegDTO.setProductTypeKey(itemReg.getProductType().getProductType());
			itemRegDTO.setPvcWeight(itemReg.getPvcWeight());
			itemRegDTO.setSpecificDetails(itemReg.getSpecificDetails());
			itemRegDTO.setUnitId(itemReg.getUnit().getUnitId());
			itemRegDTO.setWeight(itemReg.getCopperWeight());
			itemRegDTO.setMainColourItem(itemReg.getMainColour().getColor());
			itemRegDTO.setInnerColourItem(itemReg.getInnerColour().getColor());
			itemRegDTO.setMainOrderSequence(itemReg.getMainColour().getOrderSequence());
			itemRegDTO.setStripeOrderSequence(itemReg.getInnerColour().getOrderSequence());
			itemDTOs.add(itemRegDTO);
		}
		return itemDTOs;

	}
	 /**
	   * Crud functionality of Item master
	   * @param id,oper,itemCode,itemName,itemDescription,itemLabel,mainColour,innerColour,productType,cableStdPvc,
	            copperDiameter,numberOfCopperStrands,laylength,layType,outerDiameter,specificDetails,area,itemType,
	            assortedType,inputSize,odLabel,copperWeight,pvcWeight
	   * @return List<StoreRegisterDTO>
	   */
	@RequestMapping(value = "/crud", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	StatusResponse create(@RequestParam String id, @RequestParam String oper,
			@RequestParam(required = false) String itemCode,
			@RequestParam(required = false) String itemName,
			@RequestParam(required = false) String itemDescription,
			@RequestParam(required = false) String itemLabel,
			@RequestParam(required = false) String mainColour,
			@RequestParam(required = false) String innerColour,
			@RequestParam(required = false) String productType,
			@RequestParam(required = false) String cableStdPvc,
			@RequestParam(required = false) String copperDiameter,
			@RequestParam(required = false) String numberOfCopperStrands,
			@RequestParam(required = false) String laylength,
			@RequestParam(required = false) String layType,
			@RequestParam(required = false) String outerDiameter,
			@RequestParam(required = false) String specificDetails,
			@RequestParam(required = false) String area,
			@RequestParam(required = false) String itemType,
			@RequestParam(required = false) String assortedType,
			@RequestParam(required = false) String inputSize,
			@RequestParam(required = false) String odLabel,
			@RequestParam(required = false) String copperWeight,
			@RequestParam(required = false) String pvcWeight) {
		Boolean result = false;
		switch (oper) {
	
		case "del":
			Long itemIdToDelete = Long.parseLong(id);
			List<CustomerPartNo> customerPartNoList = customerPartNoService
					.findByItemsItemId(itemIdToDelete);
			List<PurchaseOrderItem> purchaseOrderItemList = purchaseOrderItemService
					.findByItemItemId(itemIdToDelete);
			List<PvcStockOut> pvcStockOutList = pvcStockOutService
					.findByItemItemId(itemIdToDelete);
			List<SalesOrderItem> salesOrderItemList = orderDetailsService
					.findByItemsItemId(itemIdToDelete);
			List<ScrapStoreReg> scrapStoreRegList = scrapStoreRegService
					.findByItemsItemId(itemIdToDelete);
			List<ScrapDetails> scrapDetailsList = scrapDetailsService
					.findByItemItemId(itemIdToDelete);
			if (customerPartNoList.size() > 0
					|| purchaseOrderItemList.size() > 0
					|| pvcStockOutList.size() > 0
					|| salesOrderItemList.size() > 0
					|| scrapStoreRegList.size() > 0
					|| scrapDetailsList.size() > 0) {

			} else {
				result = itemService.delete(itemIdToDelete);
			}

			break;
		}//end of switch case
		return new StatusResponse(result);
	}
	 /**
	   * This method to set Item Master items to ItemDTO
	   * @param itemCode
	   * @return keyList
	   */
	@RequestMapping(value = "/fetchItem", method = RequestMethod.GET)
	public @ResponseBody
	List<String> createOrderDetails(Model model,
			@RequestParam("itemCode") String itemCode) {
		/*Method to fetch item code list*/
		List<Item> itemDetailList = itemService.findByItemCode(itemCode);
		/*Initialisation of empty list of type String*/
		List<String> keyList = new ArrayList<String>();
		keyList.add(itemDetailList.get(0).getProductType().getProductKey());
		keyList.add(itemDetailList.get(0).getCableStdPvc().getCableStdKey());
		keyList.add(itemDetailList.get(0).getCopperStrandDiameter().getCopperkey());
		keyList.add(itemDetailList.get(0).getMainColour().getColorKey());
		keyList.add(itemDetailList.get(0).getInnerColour().getColorKey());
		keyList.add(itemDetailList.get(0).getNumberOfCopperStrands().toString());
		keyList.add(itemDetailList.get(0).getLayLength().toString());
		keyList.add(itemDetailList.get(0).getLayType());
		String od = String.valueOf(itemDetailList.get(0).getOuterDiameter());	
		keyList.add(od);
		keyList.add(itemDetailList.get(0).getArea().getAreaValue());
		keyList.add(itemDetailList.get(0).getMainColour().getColor());
		keyList.add(itemDetailList.get(0).getInnerColour().getColor());
		keyList.add(itemDetailList.get(0).getUnit().getUnitId().toString());
		keyList.add(itemDetailList.get(0).getCopperWeight().toString());

		return keyList;
	}
	 /**
	   * Method to create new item
	   * @param orderId,productType,cableStdKey,copperkey,mainColour,innerColor,numberOfCopperStrands,
	            laylength,layType,outerDiameter
	   * @return responseList
	   */
	@RequestMapping(value = "/newItemId", method = RequestMethod.POST)
	public @ResponseBody
	List<String> checkItemExistence(
			@RequestParam("orderId") String orderId,
			@RequestParam("productType") String productType,
			@RequestParam("cableStdPvc") String cableStdKey,
			@RequestParam("copperDiameter") String copperkey,
			@RequestParam("colour") String mainColour,
			@RequestParam("innerColour") String innerColor,
			@RequestParam("numberOfCopperStrands") Integer numberOfCopperStrands,
			@RequestParam("laylength") Integer laylength,
			@RequestParam("layType") String layType,
			@RequestParam("outerDiameter") String outerDiameter)
	{
		String modifiedDiameter = "";
		String cuStrand = "";
		modifiedDiameter=outerDiameter;
		if (numberOfCopperStrands == 0)
			cuStrand = "0000";

		else if (numberOfCopperStrands < 10)
			cuStrand = "000" + numberOfCopperStrands;

		else if (numberOfCopperStrands < 100)
			cuStrand = "00" + numberOfCopperStrands;

		else if (numberOfCopperStrands < 1000)
			cuStrand = "0" + numberOfCopperStrands;

		else if (numberOfCopperStrands < 10000)
			cuStrand = numberOfCopperStrands.toString();

		StringBuilder sb = new StringBuilder(24);
		sb.append(productType);
		sb.append(cableStdKey);
		sb.append(cuStrand);
		sb.append(copperkey);
		if (laylength < 10) {
			sb.append("0");
			sb.append(laylength);
		} else {
			sb.append(laylength);
		}
		sb.append(layType);
		sb.append(modifiedDiameter);
		sb.append(mainColour);
		sb.append(innerColor);
		String itemCode = sb.toString();
		/*Method to fetch Item Id of the item code passed*/
		List<Item> itemList = itemService.fetchItemId(itemCode);

		List<String> responseList = new ArrayList<String>();
		if (itemList.size() > 0) {
			responseList.add(String.valueOf(itemList.get(0).getItemId()));
			responseList.add(itemList.get(0).getItemCode());
			responseList.add(itemList.get(0).getUnit().getUnitId().toString());
			responseList.add(itemList.get(0).getUnit().getUnits());
			responseList.add(itemList.get(0).getArea().getAreaValue());
			String assortedType = itemList.get(0).getAssortedType();

			List<SalesOrder> orderDetailsList = orderService.findBySalesOrderNoId(orderId);
			String customerCode = "";
			if (orderDetailsList.size() != 0) {
				customerCode = orderDetailsList.get(0).getCustomer().getCustomerCode();
			}//end of if (orderDetailsList.size() != 0) 
			List<AssortedRate> assortedRateList = assortedRateService.findByCustomerCodeAndAssortedType(customerCode,
							assortedType);
			if (assortedRateList.size() > 0) {
				if (assortedRateList.get(0).getRate() != null)
					responseList.add(assortedRateList.get(0).getRate().toString());
				else
					responseList.add("");
				if (assortedRateList.get(0).getBundleSize() != null)
					responseList.add(assortedRateList.get(0).getBundleSize().toString());
				else
					responseList.add("");
			}//end of if (assortedRateList.size() > 0)

		}//end of if (itemList.size() > 0)
		return responseList;
	}
	/**
	   * Method to confirm new item
	   * @param orderId,productType,cableStdKey,copperkey,mainColour,innerColor,numberOfCopperStrands,
	            laylength,layType,outerDiameter,unitId,area
	   * @return newItemCode
	   */
	@RequestMapping(value = "/confirmNewItemId", method = RequestMethod.POST)
	public @ResponseBody
	List<String> confirmNewItemCreate(
			@RequestParam("orderId") String orderId,
			@RequestParam("productType") String productType,
			@RequestParam("cableStdPvc") String cableStdKey,
			@RequestParam("copperDiameter") String copperkey,
			@RequestParam("colour") String mainColour,
			@RequestParam("innerColour") String innerColor,
			@RequestParam("numberOfCopperStrands") Integer numberOfCopperStrands,
			@RequestParam("laylength") Integer laylength,
			@RequestParam("layType") String layType,
			@RequestParam("outerDiameter") String outerDiameter,
			@RequestParam("units") Integer unitId,
			@RequestParam(value = "area", required = false) String area)
	{
		String cuStrand = "";

		String modifiedDiameter = "";

		if (Double.valueOf(outerDiameter) == 0) {
			modifiedDiameter = "0000";
		} else if (Double.valueOf(outerDiameter) < 10) {
			modifiedDiameter = "0"
					+ String.valueOf((long) (Double.valueOf(outerDiameter) * 100));
		} else if (Double.valueOf(outerDiameter) < 100)
			modifiedDiameter = String.valueOf((long) (Double
					.valueOf(outerDiameter) * 100));
		else if (Double.valueOf(outerDiameter) < 1000)
			modifiedDiameter = String.valueOf((long) (Double
					.valueOf(outerDiameter) * 10));
		else if (Double.valueOf(outerDiameter) < 10000)
			modifiedDiameter = String.valueOf((long) (Double
					.valueOf(outerDiameter) * 1));

		if (numberOfCopperStrands < 10)
			cuStrand = "000" + numberOfCopperStrands;

		else if (numberOfCopperStrands < 100)
			cuStrand = "00" + numberOfCopperStrands;

		else if (numberOfCopperStrands < 1000)
			cuStrand = "0" + numberOfCopperStrands;

		else if (numberOfCopperStrands < 10000)
			cuStrand = numberOfCopperStrands.toString();

		ItemDTO itemDTO = new ItemDTO();
		List<String> newItemCode = new ArrayList<>();
		StringBuilder sb = new StringBuilder(24);
		sb.append(productType);
		sb.append(cableStdKey);
		sb.append(cuStrand);
		sb.append(copperkey);
		if (laylength < 10) {
			sb.append("0");
			sb.append(laylength);
		} else {
			sb.append(laylength);
		}
		sb.append(layType);
		sb.append(modifiedDiameter);
		sb.append(mainColour);
		sb.append(innerColor);
		String itemCode = sb.toString();

		itemDTO.setItemCode(itemCode);
		itemDTO.setNumberOfCopperStrand(numberOfCopperStrands);
		itemDTO.setCopperKey(copperkey);
		itemDTO.setOuterDiameter(modifiedDiameter);
		itemDTO.setMainColorKey(mainColour);
		itemDTO.setInnerColorKey(innerColor);
		itemDTO.setProductTypeKey(productType);
		itemDTO.setCableStdKey(cableStdKey);
		itemDTO.setLayLength(laylength);
		itemDTO.setLayType(layType);
		itemDTO.setUnitId(unitId);

		List<CopperDiameter> copperKey = itemService.getCopperDiameter(copperkey);
		List<CableStdPvc> cableStd = itemService.getCableStd(cableStdKey);
		List<Colour> mainColorKey = itemService.getColor(mainColour);
		List<Colour> innerColorKey = itemService.getColor(innerColor);
		List<ProductType> productKey = itemService.getProductType(productType);

		String copperLabel = copperKey.get(0).getCopperlabel();
		String cableType = cableStd.get(0).getCableStd();
		String mainColor = mainColorKey.get(0).getColor();
		String stripeColor = innerColorKey.get(0).getColor();
		String productKeyVal = productKey.get(0).getProductKey();
		String processType = productKey.get(0).getProcessType();
		DecimalFormat oneDForm = new DecimalFormat("0.0");
		DecimalFormat threeDForm = new DecimalFormat("0.000");

		String modifiedOuterDiam = String.valueOf(oneDForm.format(Double.valueOf(outerDiameter)));

		String colorCode = "";
		String description = "";
		String label = "";
		String assortedType = "";
		String itemType = "";
		String odLabel="";
		area=numberOfCopperStrands+copperLabel;
		List<Area>areaList=itemService.getAreaValue(area);
        String areaValue="";
		if(areaList.size()>0)
        	areaValue=areaList.get(0).getAreaValue();
		Double outerDiameterDouble=Double.valueOf(outerDiameter);
		if(outerDiameterDouble!=0.0)
			odLabel=String .valueOf(outerDiameterDouble/100);

		if (stripeColor != null && stripeColor != "" && !(stripeColor.equalsIgnoreCase("XX")))
			colorCode = mainColor + "(" + stripeColor + ")";
		else
			colorCode = mainColor;
		if(odLabel!="" && odLabel!=null){
		description = productKeyVal + " " + cableType + " "
				+ numberOfCopperStrands + copperLabel + " " + colorCode
				+ " -" + odLabel;
		}else{
			description = productKeyVal + " " + cableType + " "
					+ numberOfCopperStrands + copperLabel + " " + colorCode;
		}			
		label = productKeyVal + " " + cableType + " "
				+ numberOfCopperStrands + copperLabel + " " + colorCode;
		assortedType = productKeyVal + "-" + areaValue + "-"
				+ numberOfCopperStrands + copperLabel + " ("
				+ odLabel + ")-" + cableType;
		if (processType != null && !(processType.equalsIgnoreCase("")))
			itemType = processType;
		else
			itemType = "ITEM";

		String cuStrandDiam = String.valueOf(threeDForm.format(Double
				.valueOf(copperkey) / 1000));
		String inputSize = numberOfCopperStrands + "/" + cuStrandDiam + " ("
				+ laylength + layType+")" ;
    	itemDTO.setItemDescription(description);
		itemDTO.setAssortedType(assortedType);
		itemDTO.setInputSize(inputSize);
		itemDTO.setItemType(itemType);
		itemDTO.setItemLabel(label);
		itemDTO.setArea(area);
		itemDTO.setOdLabel(modifiedOuterDiam);

		if (productKeyVal.equalsIgnoreCase("BA")
				|| productKeyVal.equalsIgnoreCase("BC")
				|| productKeyVal.equalsIgnoreCase("CS")
				|| productKeyVal.equalsIgnoreCase("MS")
				|| productKeyVal.equalsIgnoreCase("PA")
				|| productKeyVal.equalsIgnoreCase("PL")
				|| productKeyVal.equalsIgnoreCase("PS")
				|| productKeyVal.equalsIgnoreCase("PV")
				|| productKeyVal.equalsIgnoreCase("RA")
				|| productKeyVal.equalsIgnoreCase("RB")
				|| productKeyVal.equalsIgnoreCase("RI")) {
			itemDTO.setWeight(1.0);
			itemDTO.setPvcWeight(1.0);

		} else {
			Double copperWeight = (numberOfCopperStrands)
					* (Double.valueOf(cuStrandDiam))
					* (Double.valueOf(cuStrandDiam)) * 0.6985 * 1.015;
			String cuWeightRoundUp = String.valueOf(threeDForm
					.format(copperWeight));
			itemDTO.setWeight(Double.valueOf(cuWeightRoundUp));
			itemDTO.setPvcWeight(Double.valueOf(cuWeightRoundUp));

		}

		Item itemObj = itemDTO.getItem();
		Item createdItem = itemService.create(itemObj);
		String assortedRate = "";
		String bundleSize = "";

		newItemCode.add(createdItem.getItemCode());
		newItemCode.add(area);
		List<SalesOrder> orderDetailsList = orderService
				.findBySalesOrderNoId(orderId);
		String customerCode = "";
		if (orderDetailsList.size() != 0) {
			customerCode = orderDetailsList.get(0).getCustomer()
					.getCustomerCode();
		}
		List<AssortedRate> assortedRateList = assortedRateService
				.findByCustomerCodeAndAssortedType(customerCode, assortedType);
		if (assortedRateList.size() > 0) {
			if (assortedRateList.get(0).getRate() != null)
				assortedRate = assortedRateList.get(0).getRate().toString();
			if (assortedRateList.get(0).getBundleSize() != null)
				bundleSize = assortedRateList.get(0).getBundleSize().toString();
		}
		newItemCode.add(assortedRate);
		newItemCode.add(bundleSize);

		return newItemCode;
	}
	/**
	   * Method to check if the Item Exists
	   * @param maincolorKeySelect,stripecolorKeySelect,productTypeSelect,cableStdPvcSelect,copperDiameterSelect,
	            colourMainSelect,colorStripeSelect,numberOfCopperStrands,layLength,layType,outerDiameter,unitTypeSelect
	   * @return statusMssgList
	   */
	@RequestMapping(value = "/checkItemExist", produces = "application/json", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	public @ResponseBody
	List<String> checkItemExist(
			@RequestParam("maincolorKeySelect") String maincolorKeySelect,
			@RequestParam("stripecolorKeySelect") String stripecolorKeySelect,
			@RequestParam("productTypeSelect") String productTypeSelect,
			@RequestParam("cableStdPvcSelect") String cableStdPvcSelect,
			@RequestParam("copperDiameterSelect") String copperDiameterSelect,
			@RequestParam("colourMainSelect") String colourMainSelect,
			@RequestParam("colorStripeSelect") String colorStripeSelect,
			@RequestParam("numberOfCopperStrands") Integer numberOfCopperStrands,
			@RequestParam("layLength") Integer layLength,
			@RequestParam("layType") String layType,
			@RequestParam("outerDiameter") String outerDiameter,
			@RequestParam("unitTypeSelect") Integer unitTypeSelect) {
		String cuStrand = "";
		List<String> statusMssgList = new ArrayList<String>();

		String modifiedDiameter = "";

		if (Double.valueOf(outerDiameter) == 0) {
			modifiedDiameter = "0000";
		} else if (Double.valueOf(outerDiameter) < 10) {
			modifiedDiameter = "0"
					+ String.valueOf((long) (Double.valueOf(outerDiameter) * 100));
		} else if (Double.valueOf(outerDiameter) < 100)
			modifiedDiameter = String.valueOf((long) (Double
					.valueOf(outerDiameter) * 100));
		else if (Double.valueOf(outerDiameter) < 1000)
			modifiedDiameter = String.valueOf((long) (Double
					.valueOf(outerDiameter) * 10));
		else if (Double.valueOf(outerDiameter) < 10000)
			modifiedDiameter = String.valueOf((long) (Double
					.valueOf(outerDiameter) * 1));

		if (numberOfCopperStrands < 10)
			cuStrand = "000" + numberOfCopperStrands;

		else if (numberOfCopperStrands < 100)
			cuStrand = "00" + numberOfCopperStrands;

		else if (numberOfCopperStrands < 1000)
			cuStrand = "0" + numberOfCopperStrands;

		else if (numberOfCopperStrands < 10000)
			cuStrand = numberOfCopperStrands.toString();

		StringBuilder sb = new StringBuilder(24);
		sb.append(productTypeSelect);
		sb.append(cableStdPvcSelect);
		sb.append(cuStrand);
		sb.append(copperDiameterSelect);
		if (layLength < 10) {
			sb.append("0");
			sb.append(layLength);
		} else {
			sb.append(layLength);
		}
		sb.append(layType);
		sb.append(modifiedDiameter);
		sb.append(maincolorKeySelect);
		sb.append(stripecolorKeySelect);
		String itemCode = sb.toString();
		List<Item> itemList = itemService.findByItemCode(itemCode);
		if (itemList.size() > 0) {
			statusMssgList.add(itemCode);
		} else {
			statusMssgList.add("New");
		}

		return statusMssgList;

	}

	@RequestMapping(value = "/createNewItem", produces = "application/json", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	public @ResponseBody
	List<String> createNewItem(
			@RequestParam("maincolorKeySelect") String maincolorKeySelect,
			@RequestParam("stripecolorKeySelect") String stripecolorKeySelect,
			@RequestParam("productTypeSelect") String productTypeSelect,
			@RequestParam("cableStdPvcSelect") String cableStdPvcSelect,
			@RequestParam("copperDiameterSelect") String copperDiameterSelect,
			@RequestParam("colourMainSelect") String colourMainSelect,
			@RequestParam("colorStripeSelect") String colorStripeSelect,
			@RequestParam("numberOfCopperStrands") Integer numberOfCopperStrands,
			@RequestParam("layLength") Integer layLength,
			@RequestParam("layType") String layType,
			@RequestParam("outerDiameter") String outerDiameter,
			@RequestParam("unitTypeSelect") Integer unitTypeSelect
	) {
		String cuStrand = "";
		List<String> statusMssgList = new ArrayList<String>();

		if (numberOfCopperStrands < 10)
			cuStrand = "000" + numberOfCopperStrands;

		else if (numberOfCopperStrands < 100)
			cuStrand = "00" + numberOfCopperStrands;

		else if (numberOfCopperStrands < 1000)
			cuStrand = "0" + numberOfCopperStrands;

		else if (numberOfCopperStrands < 10000)
			cuStrand = numberOfCopperStrands.toString();
		
		String modifiedDiameter = "";

/*		if (Double.valueOf(outerDiameter) == 0) {
			modifiedDiameter = "0000";
		} else if (Double.valueOf(outerDiameter) < 10) {
			modifiedDiameter = "000"+Double.valueOf(outerDiameter);
		} else if (Double.valueOf(outerDiameter) < 100)
			modifiedDiameter ="00"+Double.valueOf(outerDiameter);
		else if (Double.valueOf(outerDiameter) < 1000)
			modifiedDiameter = "0"+Double.valueOf(outerDiameter);
		else if (Double.valueOf(outerDiameter) < 10000)
			modifiedDiameter = outerDiameter;*/
		if (Double.valueOf(outerDiameter) == 0) {
			modifiedDiameter = "0000";
		} else {
			modifiedDiameter = outerDiameter;
		} 
		ItemDTO itemDTO = new ItemDTO();

		StringBuilder sb = new StringBuilder(24);
		sb.append(productTypeSelect);
		sb.append(cableStdPvcSelect);
		sb.append(cuStrand);
		sb.append(copperDiameterSelect);
		if (layLength < 10) {
			sb.append("0");
			sb.append(layLength);
		} else {
			sb.append(layLength);
		}
		sb.append(layType);
		//sb.append(outerDiameter);
		sb.append(modifiedDiameter);
		sb.append(maincolorKeySelect);
		sb.append(stripecolorKeySelect);
		String itemCode = sb.toString();
		List<Item> itemList = itemService.findByItemCode(itemCode);
		if (itemList.size() == 0) {

			itemDTO.setProductTypeKey(productTypeSelect);
			itemDTO.setCableStdKey(cableStdPvcSelect);
			itemDTO.setNumberOfCopperStrand(numberOfCopperStrands);
			itemDTO.setCopperKey(copperDiameterSelect);
			itemDTO.setLayLength(layLength);
			itemDTO.setLayType(layType);
			itemDTO.setOuterDiameter(outerDiameter);
			itemDTO.setMainColorKey(maincolorKeySelect);
			itemDTO.setInnerColorKey(stripecolorKeySelect);
			itemDTO.setItemCode(itemCode);
			
			List<CopperDiameter> copperKey = itemService.getCopperDiameter(copperDiameterSelect);
			List<CableStdPvc> cableStd = itemService.getCableStd(cableStdPvcSelect);
			List<Colour> mainColorKey = itemService.getColor(maincolorKeySelect);
			List<Colour> innerColorKey = itemService.getColor(stripecolorKeySelect);
			List<ProductType> productKey = itemService.getProductType(productTypeSelect);
		
			String copperLabel = copperKey.get(0).getCopperlabel();
			String cableType=cableStd.get(0).getCableStd();
			String mainColor = mainColorKey.get(0).getColor();
			String stripeColor = innerColorKey.get(0).getColor();
			String productKeyVal = productKey.get(0).getProductKey();
			String processType = productKey.get(0).getProcessType();
     		DecimalFormat threeDForm = new DecimalFormat("0.000");
     		String colorCode = "";
			String description = "";
			String label = "";
			String assortedType = "";
			String itemType = "";
			String area=numberOfCopperStrands+copperLabel;
			List<Area>areaList=itemService.getAreaValue(area);
            String areaValue="";
			if(areaList.size()>0)
            	areaValue=areaList.get(0).getAreaValue();
			else
				area="0";
			String odLabel="";
		
            double odLabelDouble=0.0;
			Double outerDiameterDouble=Double.valueOf(outerDiameter)/100;
			if(outerDiameterDouble!=0.0)
			odLabelDouble=((double)Math.round(outerDiameterDouble*10))/10;
			
			odLabel=String.valueOf(odLabelDouble);
			
			if (stripeColor != null && stripeColor != "" && !(stripeColor.equalsIgnoreCase("XX")))
				colorCode = mainColor + "(" + stripeColor + ")";
			else
				colorCode = mainColor;
			if(odLabel!="" && odLabel!=null){
			description = productKeyVal + " " + cableType + " "
					+ numberOfCopperStrands + copperLabel + " " + colorCode
					+ " -" + odLabel;
			}else{
				description = productKeyVal + " " + cableType + " "
						+ numberOfCopperStrands + copperLabel + " " + colorCode;
			}			
			label = productKeyVal + " " + cableType + " "
					+ numberOfCopperStrands + copperLabel + " " + colorCode;
			assortedType = productKeyVal + "-" + areaValue + "-"
					+ numberOfCopperStrands + copperLabel + " ("
					+ odLabel + ")-" + cableType;
			if (processType != null && !(processType.equalsIgnoreCase("")))
				itemType = processType;
			else
				itemType = "ITEM";

			String cuStrandDiam = String.valueOf(threeDForm.format(Double
					.valueOf(copperDiameterSelect) / 1000));
			String inputSize = numberOfCopperStrands + "/" + cuStrandDiam + " ("
					+ layLength + layType+")" ;

			itemDTO.setItemDescription(description);
			itemDTO.setItemLabel(label);
			itemDTO.setAssortedType(assortedType);
			itemDTO.setOdLabel(odLabel);
			itemDTO.setUnitId(unitTypeSelect);
			itemDTO.setArea(area);
			itemDTO.setItemType(itemType);
			itemDTO.setInputSize(inputSize);

			if (productKeyVal.equalsIgnoreCase("BA")
					|| productKeyVal.equalsIgnoreCase("BC")
					|| productKeyVal.equalsIgnoreCase("CS")
					|| productKeyVal.equalsIgnoreCase("MS")
					|| productKeyVal.equalsIgnoreCase("PA")
					|| productKeyVal.equalsIgnoreCase("PL")
					|| productKeyVal.equalsIgnoreCase("PS")
					|| productKeyVal.equalsIgnoreCase("PV")
					|| productKeyVal.equalsIgnoreCase("RA")
					|| productKeyVal.equalsIgnoreCase("RB")
					|| productKeyVal.equalsIgnoreCase("RI")) {
				itemDTO.setWeight(1.0);
				itemDTO.setPvcWeight(1.0);

			} else {
				Double copperWeight = (numberOfCopperStrands)
						* (Double.valueOf(cuStrandDiam))
						* (Double.valueOf(cuStrandDiam)) * 0.6985 * 1.015;
				String cuWeightRoundUp = String.valueOf(threeDForm
						.format(copperWeight));
				itemDTO.setWeight(Double.valueOf(cuWeightRoundUp));
				itemDTO.setPvcWeight(Double.valueOf(cuWeightRoundUp));

			}

			Item itemObj = itemDTO.getItem();
			itemService.create(itemObj);
			statusMssgList.add("Created");
			statusMssgList.add(itemCode);

		} else {
			statusMssgList.add("Exist");
			statusMssgList.add(itemCode);
		}

		return statusMssgList;

	}

}
