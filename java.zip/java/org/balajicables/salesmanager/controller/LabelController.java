package org.balajicables.salesmanager.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;

import org.balajicables.salesmanager.dto.LabelReportDTO;
import org.balajicables.salesmanager.model.CustomerPartNo;
import org.balajicables.salesmanager.model.Item;
import org.balajicables.salesmanager.model.LabelReport;
import org.balajicables.salesmanager.model.WorkOrderItems;
import org.balajicables.salesmanager.service.CustomerPartNoService;
import org.balajicables.salesmanager.service.ItemService;
import org.balajicables.salesmanager.service.LabelReportService;
import org.balajicables.salesmanager.service.WorkOrderItemService;

@Controller
@RequestMapping("/labeltest")
public class LabelController {

	@Resource
	private CustomerPartNoService customerPartNoService;
	
	@Resource
	private ItemService itemService;
	
	@Resource
	private LabelReportService labelReportService;
	
	@Resource
	private WorkOrderItemService workOrderItemService;
	
	@RequestMapping(method = RequestMethod.GET)
	public String getWorkOrdersPage(Model model,
			@RequestParam(value = "woNo") String woNo,
			@RequestParam(value = "itemCode") String itemCode,
			@RequestParam(value = "quantity") Integer quantity,
			@RequestParam(value = "orderId") String orderId,
			@RequestParam(value = "customerId") Long customerId,
			@RequestParam(value = "itemDescription") String itemDescription,
			@RequestParam(value = "noOfCoils") String noOfCoils,
			@RequestParam(value = "area") String area,
			@RequestParam(value = "cableStd") String cableStd,
			@RequestParam(value = "customerName") String customerName,
			@RequestParam(value = "poDetails") String poDetails,
			@RequestParam(value = "workOrderItemId") Integer workOrderItemId

	) {
		Long itemId = null;
		String custPartNo="";
		List<Item> itemList =itemService.findByItemCode(itemCode);
		if(itemList.size()>0){
			itemId=itemList.get(0).getItemId();
		}
    	List<CustomerPartNo>  custPartList = null;
    	if(itemId!=null){
    		custPartList=customerPartNoService.findByCustomerIdAndItemId(customerId,itemId);
    	
    		
    	}
    	if(custPartList.size()>0){
    		custPartNo=custPartList.get(0).getPartNo();
    		
    	}
   
		model.addAttribute("quantity", quantity);
		model.addAttribute("itemCode", itemCode);
		model.addAttribute("woNo", woNo);
		model.addAttribute("orderId", orderId);
		model.addAttribute("customerId", customerId);
		model.addAttribute("itemDescription", itemDescription);
		model.addAttribute("noOfCoils", noOfCoils);
		model.addAttribute("area", area);
		model.addAttribute("cableStd", cableStd);
		model.addAttribute("customerName", customerName);
		model.addAttribute("partNo", custPartNo);
		model.addAttribute("poDetails", poDetails);
		model.addAttribute("workOrderItemId", workOrderItemId);
	

		return "label";

	}

	@RequestMapping(value="/individualLabelReport", produces="application/pdf", method=RequestMethod.GET)
	public @ResponseBody void labelReport(
			@RequestParam(value="workOrderItemId" , required = true) Long woItemId ,javax.servlet.http.HttpServletResponse response) throws IOException, InterruptedException{
		Boolean result=true;
	
		List<LabelReport> labelReportDetailsList = labelReportService.findByWorkOrderItemsWorkOrderItemId(woItemId);
		
	
		if(labelReportDetailsList.size()>0){
			for(int j=0;j<labelReportDetailsList.size();j++){
				if(labelReportDetailsList.get(j).getLabelReportId()!=null)
				labelReportService.delete(labelReportDetailsList.get(j).getLabelReportId());
			}
		}
			
	List<WorkOrderItems>woItemsList=workOrderItemService.findById(woItemId);
	if(woItemsList.size()>0){
		for(int k=0;k<woItemsList.size();k++){
			List<CustomerPartNo> customerPartList=customerPartNoService.findByCustomerIdAndItemId(woItemsList.get(k).getSalesOrderItem().getOrder().getCustomer().getCustomerId(), woItemsList.get(k).getSalesOrderItem().getItem().getItemId());
     		int noOfLabels=woItemsList.get(k).getNoOfCoils()+3;
     	  
			for(int i=1;i<=noOfLabels;i++){
				String bundleId=null;
				if(i<10)
		    		bundleId="00" +  i;
		    	else if(i<100)
		    		bundleId="0" +  i;
		    	else bundleId=String.valueOf(i);
				LabelReportDTO labelReportDTO=new LabelReportDTO();
				labelReportDTO.setArea(woItemsList.get(k).getSalesOrderItem().getItem().getArea().getAreaValue());
				labelReportDTO.setBatchNo(woItemsList.get(k).getProductionWorkOrder().getWorkOrderNo()+"/"+bundleId);
				labelReportDTO.setBundleId(bundleId);
				labelReportDTO.setCableStd(woItemsList.get(k).getSalesOrderItem().getItem().getCableStdPvc().getCableStd());
				labelReportDTO.setCustomerId(woItemsList.get(k).getSalesOrderItem().getOrder().getCustomer().getCustomerId());
				if(customerPartList.size()>0){
				   labelReportDTO.setPartNo(customerPartList.get(0).getPartNo());
				}
				else
					labelReportDTO.setPartNo(null);
				
				
				labelReportDTO.setItemDescription(woItemsList.get(k).getSalesOrderItem().getItem().getItemDescription());
				labelReportDTO.setPoNo(woItemsList.get(k).getSalesOrderItem().getOrder().getPoDetails());
				labelReportDTO.setQtyPerCoil(woItemsList.get(k).getQtyPerCoil());
				labelReportDTO.setSalesOrderNo(woItemsList.get(k).getSalesOrderItem().getOrder().getOrderId());
				labelReportDTO.setTotalQuantity(woItemsList.get(k).getTotalQuantity());
				labelReportDTO.setWorkOrderItemId(woItemsList.get(k).getWorkOrderItemId());
				labelReportDTO.setWorkOrderNo(woItemsList.get(k).getProductionWorkOrder().getWorkOrderNo());
				
				LabelReport labelReport=labelReportDTO.getLabelReport();
				LabelReport createdLabelReport=labelReportService.create(labelReport);
				if(createdLabelReport!=null)
					result=true;
	   		}
		}
		
     }
	
	if(result==true){
	if(woItemId!=null){
	InputStream inputStream = getClass().getClassLoader().getResourceAsStream("/org/balajicables/salesmanager/report/ExtrusionIndividualLabelReport.jrxml");
	 Map<String, Object> hm= new HashMap<String, Object>();
	
     hm.put("WO_ITEM_ID",Integer.parseInt(woItemId.toString()));
     byte[] content = ReportGenerator.newReportGenerator(inputStream,hm);
			
    response.setContentType("application/pdf");
	response.setHeader("Content-Disposition", "attachment;filename=" + "ExtrusionLabel"+woItemId+".pdf");
	response.setContentLength(content.length);
    FileCopyUtils.copy(content, response.getOutputStream());
	}
	}

	}
	
	
	
	@RequestMapping(value="/storeRegLabelReport", produces="application/pdf", method=RequestMethod.GET)
	public @ResponseBody void storeRegLabelReport(
			@RequestParam(value="storeRegisterId" , required = true) Long storeRegisterId ,javax.servlet.http.HttpServletResponse response) throws IOException, InterruptedException{
		if(storeRegisterId!=null ){
			InputStream inputStream = getClass().getClassLoader().getResourceAsStream("/org/balajicables/salesmanager/report/StoreRegisterLabelReport.jrxml");
			 Map<String, Object> hm= new HashMap<String, Object>();
			
		     hm.put("STORE_REGISTER_ID",Integer.parseInt(storeRegisterId.toString()));
		     byte[] content = ReportGenerator.newReportGenerator(inputStream,hm);
					
		    response.setContentType("application/pdf");
			response.setHeader("Content-Disposition", "attachment;filename=" + "ExtrusionLabel"+storeRegisterId+".pdf");
			response.setContentLength(content.length);
		    FileCopyUtils.copy(content, response.getOutputStream());

		}

	}
	
}
