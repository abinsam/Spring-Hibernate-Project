package org.balajicables.salesmanager.controller;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
import javax.annotation.Resource;
import org.balajicables.salesmanager.CustomUser;
import org.balajicables.salesmanager.common.JqgridResponse;
import org.balajicables.salesmanager.common.StatusResponse;
import org.balajicables.salesmanager.dto.MwdWorkOrderDTO;
import org.balajicables.salesmanager.dto.SalesOrderItemsDTO;
import org.balajicables.salesmanager.dto.StockInDTO;
import org.balajicables.salesmanager.dto.StoreRegisterDTO;
import org.balajicables.salesmanager.dto.WorkOrderOutputDTO;
import org.balajicables.salesmanager.model.MwdWorkOrder;
import org.balajicables.salesmanager.model.ProductionWorkOrder;
import org.balajicables.salesmanager.model.SalesOrderItem;
import org.balajicables.salesmanager.model.StockIn;
import org.balajicables.salesmanager.model.StoreRegister;
import org.balajicables.salesmanager.model.WorkOrderOutput;
import org.balajicables.salesmanager.repository.ItemRepository;
import org.balajicables.salesmanager.repository.MwdWorkOrderRepository;
import org.balajicables.salesmanager.repository.ProductionWorkOrderRepository;
import org.balajicables.salesmanager.repository.WorkOrderItemRepository;
import org.balajicables.salesmanager.repository.WorkOrderOutputRepository;
import org.balajicables.salesmanager.service.MwdWorkOrderInputService;
import org.balajicables.salesmanager.service.OrderDetailsService;
import org.balajicables.salesmanager.service.ProductionWorkOrderService;
import org.balajicables.salesmanager.service.StockInService;
import org.balajicables.salesmanager.service.StoreRegisterService;
import org.balajicables.salesmanager.service.WorkOrderOutputService;
import org.balajicables.salesmanager.utils.Utility;
import org.joda.time.DateTime;
import org.springframework.data.domain.Page;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/viewMWDWorkOrder")
public class MWDJobCardController {

	@Resource
	private ProductionWorkOrderService productionWorkOrderService;

	@Resource
	private MwdWorkOrderInputService mwdWorkOrderInputService;

	@Resource
	MwdWorkOrderRepository mwdWorkOrderRepository;

	@Resource
	WorkOrderOutputRepository workOrderOutputRepository;

	@Resource
	WorkOrderOutputService workOrderOutputService;

	@Resource
	StoreRegisterService storeRegisterService;

	@Resource
	WorkOrderItemRepository workOrderItemRepository;


	@Resource
	OrderDetailsService orderDetailsService;

	@Resource
	ItemRepository itemRepository;

	@Resource
	private StockInService stockInService;

	@Resource
	private ProductionWorkOrderRepository productionWorkOrderRepository;

	@RequestMapping(method = RequestMethod.GET)
	public String viewMWDWorkOrder(Model model) {
		ArrayList<String> woNosList = new ArrayList<>();
		DateTime dt = new DateTime();  // current time
		int month =dt.getMonthOfYear();
		int year=dt.getYear();
		String mwd = "MWD";
        String status="Pending";
		List<ProductionWorkOrder> productionWorkOrders = productionWorkOrderService.findByProcessTypeAndStatusAndMonthYear(mwd, status, month, year);
		for (int iterator = 0; iterator < productionWorkOrders.size(); iterator++) {
			if (productionWorkOrders.get(iterator).getWorkOrderNo() != null
					&& productionWorkOrders.get(iterator).getWorkOrderNo() != "") {
				String woNo = productionWorkOrders.get(iterator).getWorkOrderNo();
				if (!woNosList.contains(woNo)) {
					woNosList.add(woNo);
				}
			}
		}
		Collections.sort(woNosList,Collections.reverseOrder());
		model.addAttribute("workOrderNo", woNosList);// set Multiwire work order nos to model attribute
		return "mwdJobCard";
	}

	@RequestMapping(value = "/getWODetails/{woNo}", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	List<String> getWODetails(@PathVariable("woNo") String woNo, Model model) {

		List<ProductionWorkOrder> pdnWorkOrder = productionWorkOrderRepository
				.findByWorkOrderNo(woNo);
		List<String> pdnWoValuesList = new ArrayList<String>();
		if (pdnWorkOrder.get(0).getStartDate() != null)
			pdnWoValuesList.add(Utility.formDateFormatter.print(pdnWorkOrder
					.get(0).getStartDate().getTime()));
		if (pdnWorkOrder.get(0).getEndDate() != null)
			pdnWoValuesList.add(Utility.formDateFormatter.print(pdnWorkOrder
					.get(0).getEndDate().getTime()));
		pdnWoValuesList.add(pdnWorkOrder.get(0).getMachine().getDescription());
		pdnWoValuesList.add(pdnWorkOrder.get(0).getStatus());
		return pdnWoValuesList;
	}

	@RequestMapping(value = "/populateWODetailsGrid/{woNo}", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	JqgridResponse<MwdWorkOrderDTO> populateWODetailsGrid(
			@PathVariable("woNo") String woNo,
			@RequestParam(value = "filters", required = false) String filters,
			@RequestParam(value = "page", required = false) Integer pageNumber,
			@RequestParam(value = "rows", required = false) Integer rowsPerPage,
			@RequestParam(value = "sidx", required = false) String sortColName,
			@RequestParam(value = "sord", required = false, defaultValue = "asc") String sortOrder) {
		
		if(sortColName.equalsIgnoreCase("customerCode")){
			sortColName="salesOrderItem.orders.customer.customerCode";
		}

		
		if(sortColName.equalsIgnoreCase("customerName")){
			sortColName="salesOrderItem.orders.customer.customerName";
		}
		if(sortColName.equalsIgnoreCase("customerCode")){
			sortColName="salesOrderItem.orders.customer.customerCode";
		}

		
		Page<MwdWorkOrder> mwdWorkOrderOutput = mwdWorkOrderInputService
				.getPagedOrders(woNo, pageNumber - 1, rowsPerPage, sortColName,
						sortOrder);

		JqgridResponse<MwdWorkOrderDTO> response = new JqgridResponse<MwdWorkOrderDTO>();
		List<MwdWorkOrderDTO> mwdWorkOrderDTOs = convertToMwdWoDTO(
				mwdWorkOrderOutput.getContent(), woNo);
		response.setRows(mwdWorkOrderDTOs);
		response.setRecords(Long.valueOf(mwdWorkOrderOutput.getTotalElements())
				.toString());
		response.setTotal(Long.valueOf(mwdWorkOrderOutput.getTotalPages())
				.toString());
		response.setPage(Integer.valueOf(mwdWorkOrderOutput.getNumber() + 1)
				.toString());
		return response;
	}

	private List<MwdWorkOrderDTO> convertToMwdWoDTO(
			List<MwdWorkOrder> mwdWorkOrders, String woNo) {
		List<MwdWorkOrderDTO> mwdWoDTOs = new ArrayList<>();
		for (MwdWorkOrder mwdWo : mwdWorkOrders) {
			MwdWorkOrderDTO mwdWoDTO = new MwdWorkOrderDTO();
			mwdWoDTO.setMwdWoInputId(mwdWo.getMwdWoInputId());
			mwdWoDTO.setWorkOrderNo(mwdWo.getProductionWorkOrder()
					.getWorkOrderNo());
			mwdWoDTO.setSize(mwdWo.getSize());
			mwdWoDTO.setNetLength(mwdWo.getNetLength());
			mwdWoDTO.setStatus(mwdWo.getStatus());
			mwdWoDTO.setAnealingPercent(mwdWo.getAnealingPercent());
			mwdWoDTO.setCustomerName(mwdWo.getCustomerName());
			mwdWoDTO.setCustomerCode(mwdWo.getSalesOrderItem().getOrder().getCustomer().getCustomerCode());
			mwdWoDTO.setTotalQty(mwdWo.getTotalQty());
			mwdWoDTO.setSelectStatus(mwdWo.getSelectStatus());
			mwdWoDTOs.add(mwdWoDTO);
		}
		return mwdWoDTOs;
	}

	@RequestMapping(value = "/crudForFirstGrid", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	StatusResponse crudForFirstGrid(@RequestParam Long id,
			@RequestParam String oper,
			@RequestParam(required = false) String workOrderNo,
			@RequestParam(required = false) String anealingPercent) {
		Boolean result = false;
		CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();;
	    
		String userName = user.getFirstName()+" "+user.getLastName();

		if (anealingPercent != null && anealingPercent != "") {
			List<MwdWorkOrder> mwdInputList = mwdWorkOrderInputService
					.findById(id);
			MwdWorkOrder mwdWorkOrder = null;
			boolean match = false;
			if (oper.equalsIgnoreCase("edit")) {
				String decimalPattern = "((-|\\+)?[0-9]+(\\.[0-9]+)?)+";
				match = Pattern.matches(decimalPattern, anealingPercent);
				if (match == true) {
					if (mwdInputList.size() > 0) {
						MwdWorkOrderDTO mwdWorkOrderDTO = new MwdWorkOrderDTO();
						mwdWorkOrderDTO.setMwdWoInputId(mwdInputList.get(0)
								.getMwdWoInputId());
						mwdWorkOrderDTO.setOrderDetailId(mwdInputList.get(0)
								.getSalesOrderItem().getOrderDetailId());
						mwdWorkOrderDTO.setWorkOrderNo(mwdInputList.get(0)
								.getProductionWorkOrder().getWorkOrderNo());
						mwdWorkOrderDTO.setSize(mwdInputList.get(0).getSize());
						mwdWorkOrderDTO.setNetLength(mwdInputList.get(0)
								.getNetLength());
						mwdWorkOrderDTO.setAnealingPercent(anealingPercent);
						mwdWorkOrderDTO.setCustomerName(mwdInputList.get(0)
								.getSalesOrderItem().getOrder().getCustomer()
								.getCustomerName());
						mwdWorkOrderDTO.setUpdatedBy(userName);
						mwdWorkOrderDTO.setCreatedBy(mwdInputList.get(0)
								.getCreatedBy());
						mwdWorkOrderDTO.setStatus(mwdInputList.get(0)
								.getStatus());
						mwdWorkOrderDTO.setTotalQty(mwdInputList.get(0)
								.getTotalQty());
						mwdWorkOrderDTO.setSelectStatus(mwdInputList.get(0)
								.getSelectStatus());
						mwdWorkOrder = mwdWorkOrderDTO.getMwdWorkerOrder();
					}
				}
			}

			switch (oper) {
			case "edit":
				if (match == true) {
					result = mwdWorkOrderInputService.update(mwdWorkOrder);
				}
				break;
			case "del":
				Long salesOrderItemId = mwdInputList.get(0).getSalesOrderItem()
						.getOrderDetailId();
				String orderId = mwdInputList.get(0).getSalesOrderItem()
						.getOrder().getOrderId();
				Double balQty = mwdInputList.get(0).getSalesOrderItem()
						.getBalanceQty();
				Double pdnQty = mwdInputList.get(0).getSalesOrderItem()
						.getProductionQty();
				Double woQty = mwdInputList.get(0).getTotalQty();
				Double totalQty = mwdInputList.get(0).getSalesOrderItem()
						.getQuantity();
				Double newBalQty = 0.0;
				Double newPdnQty = 0.0;
				Double newTotalQty = 0.0;
				if (orderId.equalsIgnoreCase("BS000001")) {
					newBalQty = 0.0;
					if (woQty < totalQty) {
						newTotalQty = totalQty - woQty;
						newPdnQty = pdnQty - woQty;
					}
				} else {
					newTotalQty = totalQty;
					newBalQty = balQty + woQty;
					if (pdnQty > woQty)
						newPdnQty = pdnQty - woQty;
				}
				mwdWorkOrderRepository.delete(id);
				result = orderDetailsService.updateBalPdnQty(salesOrderItemId,
						newTotalQty, newBalQty, newPdnQty);
				break;

			}
		}
		return new StatusResponse(result);
	}

	@RequestMapping(value = "/createMWDWoOutput", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	StatusResponse createMWDWoOutput(
			@RequestParam(value = "idsOfSelectedRows[]", required = false) Long[] idsOfSelectedRows) {
		CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();;
	    
		String userName = user.getFirstName()+" "+user.getLastName();
		Boolean pdnWorkOrderOutputResult = false;
		Boolean result=false;
		String newBatchNo;

		for (int i = 0; i < idsOfSelectedRows.length; i++) {
			List<MwdWorkOrder> mwdWorkOrder = mwdWorkOrderRepository
					.findByMwdWoInputId(idsOfSelectedRows[i]);
			List<WorkOrderOutput> existBatchNoList = workOrderOutputService
					.fetchLatestBatchNo(mwdWorkOrder.get(0)
							.getProductionWorkOrder().getWorkOrderNo());
			String existBatchNo = "";
			if (existBatchNoList.size() > 0)
				existBatchNo = existBatchNoList.get(0).getBatchNo();

			if (!existBatchNo.isEmpty()) {
				String existBatchNoWo = existBatchNo.substring(0, 8);
				String existBatchNoId = existBatchNo.substring(9, 11);
				int serialNoInt = 0;
				serialNoInt = Integer.parseInt(existBatchNoId) + 1;

				if (serialNoInt < 10) {
					newBatchNo = existBatchNoWo + "/0"
							+ String.valueOf(serialNoInt);
				} else {
					newBatchNo = existBatchNoWo + "/"
							+ String.valueOf(serialNoInt);
				}
			}// end of if loop of checking existing sales no
			else {
				newBatchNo = mwdWorkOrder.get(0).getProductionWorkOrder()
						.getWorkOrderNo()
						+ "/" + "01";
			}
			if (mwdWorkOrder.size() > 0) {
				WorkOrderOutputDTO workOrderOutputDTO = new WorkOrderOutputDTO();
				workOrderOutputDTO.setWorkOrderNo(mwdWorkOrder.get(0)
						.getProductionWorkOrder().getWorkOrderNo());
				workOrderOutputDTO.setBatchNo(newBatchNo);
				workOrderOutputDTO.setNetLength(mwdWorkOrder.get(0)
						.getNetLength());
				workOrderOutputDTO.setNetWeight(0.0);
				// workOrderOutputDTO.setGrossWeight(weightPerMeterRound*mwdWorkOrder.get(0).getNetLength());
				workOrderOutputDTO.setGrossWeight(0.0);
				workOrderOutputDTO.setTareWeight(0.0);
				workOrderOutputDTO.setOrderDetailId(mwdWorkOrder.get(0)
						.getSalesOrderItem().getOrderDetailId());
				workOrderOutputDTO.setAnnealingPercent(mwdWorkOrder.get(0)
						.getAnealingPercent());
				workOrderOutputDTO.setSize(mwdWorkOrder.get(0).getSize());
				workOrderOutputDTO.setSpeed("0");
				workOrderOutputDTO.setUpdatedBy(userName);
				workOrderOutputDTO.setStockIn("No");

				WorkOrderOutput workOrderOutput = workOrderOutputDTO
						.getWorkOrderOutput();
				WorkOrderOutput createdWoOutput = workOrderOutputService
						.create(workOrderOutput);
				if (createdWoOutput != null) {
					pdnWorkOrderOutputResult = true;
				}
                if(pdnWorkOrderOutputResult==true){
                	MwdWorkOrderDTO mwdWoInputDTO = new MwdWorkOrderDTO();
                	mwdWoInputDTO.setMwdWoInputId(mwdWorkOrder.get(0).getMwdWoInputId());
    				mwdWoInputDTO.setWorkOrderNo(mwdWorkOrder.get(0).getProductionWorkOrder().getWorkOrderNo());
    				mwdWoInputDTO.setOrderDetailId(mwdWorkOrder.get(0).getSalesOrderItem().getOrderDetailId());
    				mwdWoInputDTO.setSize(mwdWorkOrder.get(0).getSalesOrderItem().getItem().getInputSize());
    				mwdWoInputDTO.setNetLength(mwdWorkOrder.get(0).getNetLength());
    				mwdWoInputDTO.setAnealingPercent(mwdWorkOrder.get(0).getAnealingPercent());
    				mwdWoInputDTO.setCustomerName(mwdWorkOrder.get(0).getSalesOrderItem().getOrder().getCustomer().getCustomerName());
    				mwdWoInputDTO.setUpdatedBy(mwdWorkOrder.get(0).getUpdatedBy());
    				mwdWoInputDTO.setCreatedBy(mwdWorkOrder.get(0).getCreatedBy());
    				mwdWoInputDTO.setStatus(mwdWorkOrder.get(0).getStatus());
    				mwdWoInputDTO.setTotalQty(mwdWorkOrder.get(0).getTotalQty());
    				mwdWoInputDTO.setSelectStatus("Yes");
    				MwdWorkOrder mwdWorkOrderInput=mwdWoInputDTO.getMwdWorkerOrder();
    				result=mwdWorkOrderInputService.update(mwdWorkOrderInput);
                }
			}
		}

		return new StatusResponse(result);
	}

	@RequestMapping(value = "/records/{woNo}", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	JqgridResponse<WorkOrderOutputDTO> records(
			@PathVariable("woNo") String workOrderNo,
			@RequestParam("_search") Boolean search,
			@RequestParam(value = "filters", required = false) String filters,
			@RequestParam(value = "page", required = false) Integer pageNumber,
			@RequestParam(value = "rows", required = false) Integer rowsPerPage,
			@RequestParam(value = "sidx", required = false) String sortColName,
			@RequestParam(value = "sord", required = false, defaultValue = "asc") String sortOrder) {

		
		
		
		
		Page<WorkOrderOutput> workOrderOutputs = workOrderOutputService
				.getWoOutputPagedList(workOrderNo, pageNumber - 1, rowsPerPage,
						sortColName, sortOrder);

		JqgridResponse<WorkOrderOutputDTO> response = new JqgridResponse<WorkOrderOutputDTO>();
		List<WorkOrderOutputDTO> workOrderOutputDTOs = convertToDTO(workOrderOutputs
				.getContent());
		response.setRows(workOrderOutputDTOs);
		response.setRecords(Long.valueOf(workOrderOutputs.getTotalElements())
				.toString());
		response.setTotal(Long.valueOf(workOrderOutputs.getTotalPages())
				.toString());
		response.setPage(Integer.valueOf(workOrderOutputs.getNumber() + 1)
				.toString());
		return response;
	}

	private List<WorkOrderOutputDTO> convertToDTO(
			List<WorkOrderOutput> workOrderOutputs) {
		List<WorkOrderOutputDTO> mwdWOOutputDTOs = new ArrayList<>();
		for (WorkOrderOutput workOrderOutput : workOrderOutputs) {
			WorkOrderOutputDTO workOrderDTO = new WorkOrderOutputDTO();
			workOrderDTO.setWoOutPutId(workOrderOutput.getWoOutPutId());
			workOrderDTO.setWorkOrderNo(workOrderOutput
					.getProductionWorkOrder().getWorkOrderNo());
			workOrderDTO.setBatchNo(workOrderOutput.getBatchNo());
			workOrderDTO.setAnnealingPercent(workOrderOutput
					.getAnnealingPercent());
			workOrderDTO.setSize(workOrderOutput.getSize());
			workOrderDTO.setSpeed(workOrderOutput.getSpeed());
			workOrderDTO.setNetLength(workOrderOutput.getNetLength());
			workOrderDTO.setNetWeight(workOrderOutput.getNetWeight());
			workOrderDTO.setTareWeight(workOrderOutput.getTareWeight());
			workOrderDTO.setGrossWeight(workOrderOutput.getGrossWeight());
			workOrderDTO.setStockIn(workOrderOutput.getStockIn());

			mwdWOOutputDTOs.add(workOrderDTO);
		}
		return mwdWOOutputDTOs;

	}

	@RequestMapping(value = "/crud", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	StatusResponse crud(@RequestParam Long id, @RequestParam String oper,
			@RequestParam(required = false) String netLength,
			@RequestParam(required = false) String grossWeight,
			@RequestParam(required = false) String tareWeight,
			@RequestParam(required = false) String annealingPercent,
			@RequestParam(required = false) String speed,
			@RequestParam(required = false) String stockIn) {
		Boolean result = false;
		Double newGrossWeight = 0.0;
		Double newNetLength = 0.0;
		Double newTareWeight = 0.0;
		CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();;
	    
		String userName = user.getFirstName()+" "+user.getLastName();
		boolean netLengthMatch = false;
		boolean grossWeightMatch = false;
		boolean tareWeightMatch = false;
		boolean annealingMatch = false;
		boolean speedMatch = false;
		if (oper.equalsIgnoreCase("edit")) {
			String decimalPattern = "((-|\\+)?[0-9]+(\\.[0-9]+)?)+";
			netLengthMatch = Pattern.matches(decimalPattern, netLength);
			grossWeightMatch = Pattern.matches(decimalPattern, grossWeight);
			tareWeightMatch = Pattern.matches(decimalPattern, tareWeight);
			annealingMatch = Pattern.matches(decimalPattern, annealingPercent);
			speedMatch = Pattern.matches(decimalPattern, speed);
			if (netLengthMatch == true && grossWeightMatch == true
					&& tareWeightMatch == true && annealingMatch == true
					&& speedMatch == true) {
				newNetLength = Double.valueOf(netLength);
				newGrossWeight = Double.valueOf(grossWeight);
				newTareWeight = Double.valueOf(tareWeight);

			}
		}
		switch (oper) {
		case "edit":
			if (netLengthMatch == true && grossWeightMatch == true
					&& tareWeightMatch == true && annealingMatch == true
					&& speedMatch == true) {
				if (newGrossWeight > newTareWeight
						|| newGrossWeight == newTareWeight
						|| (newGrossWeight == 0.0 && newTareWeight == 0.0)) {
					List<WorkOrderOutput> woOutputList = workOrderOutputService
							.findByWoOutputId(id);
					if (woOutputList.size() > 0) {
						
						WorkOrderOutputDTO workOrderOutputDTO = new WorkOrderOutputDTO();
						workOrderOutputDTO.setWoOutPutId(id);
						workOrderOutputDTO.setWorkOrderNo(woOutputList.get(0)
								.getProductionWorkOrder().getWorkOrderNo());
						workOrderOutputDTO.setBatchNo(woOutputList.get(0)
								.getBatchNo());
						workOrderOutputDTO.setSize(woOutputList.get(0)
								.getSize());
						workOrderOutputDTO.setNetLength(newNetLength);
						workOrderOutputDTO.setGrossWeight(Math.round(newGrossWeight*100.0)/100.0);
						workOrderOutputDTO.setTareWeight(Math.round(newTareWeight*100.0)/100.0);
						Double netWeight = newGrossWeight - newTareWeight;
						if (netWeight > 0.0) {
							workOrderOutputDTO.setNetWeight( Math.round(netWeight*100.0)/100.0);
						} else {
							workOrderOutputDTO.setNetWeight(0.0);
						}

						workOrderOutputDTO
								.setAnnealingPercent(annealingPercent);
						workOrderOutputDTO.setStockIn(stockIn);
						workOrderOutputDTO.setOrderDetailId(woOutputList.get(0)
								.getSalesOrderItem().getOrderDetailId());
						workOrderOutputDTO.setSpeed(speed);
						workOrderOutputDTO.setUpdatedBy(userName);
						workOrderOutputDTO.setCreatedTime(woOutputList.get(0)
								.getCreatedTime().toString());
						WorkOrderOutput workOrderOutput = workOrderOutputDTO
								.getWorkOrderOutput();
						result = workOrderOutputService.update(workOrderOutput);
					}
				}
			}
			break;
		case "del":
			result = workOrderOutputService.delete(id);
			break;
		}
		return new StatusResponse(result);
	}

	@RequestMapping(value = "/submitMWDWorkOrder/{woNo}", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	void submitMWDWorkOrder(@PathVariable("woNo") String woNo) {
		String updateStatus = "Submitted";
		productionWorkOrderService.updateWorkOrderStatus(woNo, updateStatus);

	}

	@RequestMapping(value = "/stockIn/{id}", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	StatusResponse stockIn(@PathVariable("id") Long id) {
		Long orderDetailId = null;
		Double stockInWeight = 0.0;
		Boolean updateWorkOrderOutput = false;
		Boolean updateSoItemResult = false;
		Boolean updateStockInResult = false;
		Boolean updateStoreReg = false;
		StockIn createdStockIn = null;
		StoreRegister createdStoreReg = null;
		CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();;
	    
		String supervisor = user.getFirstName()+" "+user.getLastName();
		String bundleNo = null;
		List<WorkOrderOutput> workOrderOutput = workOrderOutputRepository
				.findByWoOutPutId(id);
		if (workOrderOutput.size() > 0) {
			if (workOrderOutput.get(0).getGrossWeight() > workOrderOutput
					.get(0).getTareWeight()) {
				orderDetailId = workOrderOutput.get(0).getSalesOrderItem()
						.getOrderDetailId();
				String units=workOrderOutput.get(0).getSalesOrderItem().getItem().getUnit().getUnits();
				if(units.equalsIgnoreCase("Kgs")|| units.equalsIgnoreCase("Kg")){
				  stockInWeight = workOrderOutput.get(0).getNetWeight();
				}else
				  stockInWeight = workOrderOutput.get(0).getNetLength();
				
				
				WorkOrderOutputDTO workOrderOutputDTO = new WorkOrderOutputDTO();
				workOrderOutputDTO.setWoOutPutId(workOrderOutput.get(0)
						.getWoOutPutId());
				workOrderOutputDTO.setWorkOrderNo(workOrderOutput.get(0)
						.getProductionWorkOrder().getWorkOrderNo());
				workOrderOutputDTO.setNetLength(workOrderOutput.get(0)
						.getNetLength());
				workOrderOutputDTO.setGrossWeight(workOrderOutput.get(0)
						.getGrossWeight());
				workOrderOutputDTO.setTareWeight(workOrderOutput.get(0)
						.getTareWeight());
				workOrderOutputDTO.setNetWeight(workOrderOutput.get(0)
						.getNetWeight());
				workOrderOutputDTO.setNoOfStrands(workOrderOutput.get(0)
						.getNoOfStrands());
				workOrderOutputDTO.setSize(workOrderOutput.get(0).getSize());
				workOrderOutputDTO.setSpeed(workOrderOutput.get(0).getSpeed());
				workOrderOutputDTO.setAnnealingPercent(workOrderOutput.get(0)
						.getAnnealingPercent());
				workOrderOutputDTO.setOuterDiameter(workOrderOutput.get(0)
						.getOuterDiameter());
				workOrderOutputDTO.setCreatedTime(workOrderOutput.get(0)
						.getCreatedTime().toString());
				workOrderOutputDTO.setUpdatedBy(workOrderOutput.get(0)
						.getUpdatedBy());
				workOrderOutputDTO.setBatchNo(workOrderOutput.get(0)
						.getBatchNo());
				workOrderOutputDTO.setStockIn("Yes");
				if(workOrderOutput.get(0).getBatchNo()!=null)
				bundleNo = "0"+workOrderOutput.get(0).getBatchNo().substring(9);
				workOrderOutputDTO.setOrderDetailId(workOrderOutput.get(0)
						.getSalesOrderItem().getOrderDetailId());
				WorkOrderOutput woOutput = workOrderOutputDTO
						.getWorkOrderOutput();
				updateWorkOrderOutput = workOrderOutputService.update(woOutput);

				if (orderDetailId != null && updateWorkOrderOutput == true) {
					List<SalesOrderItem> soItemList = orderDetailsService.findById(orderDetailId);
					if (soItemList.size() > 0) {
						Double totalQtyOrdered=soItemList.get(0).getQuantity();
						Double newStockedInQty=soItemList.get(0).getCompletedQty() + stockInWeight;
                     	Double stockedOutQty=soItemList.get(0).getDispatchedQty();
						Double oldPdnQty=soItemList.get(0).getProductionQty();
						Double newBalQty=0.0;
						Double newPdnQty=0.0;
			            if(oldPdnQty<(newStockedInQty+stockedOutQty)){
			            	newPdnQty=0.0;
			            }else{
			            	newPdnQty=oldPdnQty-(newStockedInQty+stockedOutQty);
			            }
						if(totalQtyOrdered<(newPdnQty+newStockedInQty+stockedOutQty)){
							newBalQty=0.0;
						}else{
							newBalQty=totalQtyOrdered-(newPdnQty+newStockedInQty+stockedOutQty);
						}
						
						
						SalesOrderItemsDTO soitemsDTO = new SalesOrderItemsDTO();
						soitemsDTO.setOrderDetailId(soItemList.get(0).getOrderDetailId());
						soitemsDTO.setOrderId(soItemList.get(0).getOrder().getOrderId());
						soitemsDTO.setItemId(soItemList.get(0).getItem().getItemId());
						soitemsDTO.setQuantity(totalQtyOrdered);
						soitemsDTO.setBalanceQty(newBalQty);
						soitemsDTO.setProductionQty(newPdnQty);
						soitemsDTO.setCompletedQty(newStockedInQty);
						soitemsDTO.setDispatchedQty(stockedOutQty);
						soitemsDTO.setWoQty(soItemList.get(0).getWoQty());
						soitemsDTO.setWeight(soItemList.get(0).getWeight());
						soitemsDTO.setBundleSize(soItemList.get(0).getBundleSize());
						soitemsDTO.setRate(soItemList.get(0).getRate());
						soitemsDTO.setItemCode(soItemList.get(0).getItemCode());
						soitemsDTO.setUpdatedBy(soItemList.get(0).getUpdatedBy());
						soitemsDTO.setUpdatedTime(soItemList.get(0).getUpdatedTime().toString());
						soitemsDTO.setPvcWeight(soItemList.get(0).getPvcWeight());
						SalesOrderItem soitem = soitemsDTO.getOrderDetail();
						updateSoItemResult = orderDetailsService.update(soitem);

					}
					if (updateSoItemResult == true) {
						String salesOrder=workOrderOutput.get(0).getSalesOrderItem().getOrder().getOrderId();
						String itemCode=workOrderOutput.get(0).getSalesOrderItem().getItem().getItemCode();
                        String workOrderNo=workOrderOutput.get(0).getProductionWorkOrder().getWorkOrderNo();
						String confirmStatus="No";
						//List<StockIn> stockInList = stockInService.findByOrderDetailIdBundleIdWorkOrderNo(orderDetailId, bundleNo,workOrderOutput.get(0).getProductionWorkOrder().getWorkOrderNo());
						List<StockIn> stockInList = stockInService.findByOrderIdAndItemCodeAndWoNoAndBundleIdAndConfirmStatus(salesOrder, itemCode, workOrderNo, bundleNo, confirmStatus);
						List<StoreRegister> storeRegExistList = storeRegisterService.findByOrderDetailIdAndBundleIdAndWorkOrderNo(orderDetailId, bundleNo,workOrderOutput.get(0).getProductionWorkOrder().getWorkOrderNo());
						StockInDTO stockInDTO = new StockInDTO();
						stockInDTO.setStoreId(1);
						stockInDTO.setOrderDetailId(orderDetailId);
						stockInDTO.setOrderId(soItemList.get(0).getOrder()
								.getOrderId());
						stockInDTO.setItemId(soItemList.get(0).getItem()
								.getItemId());
						stockInDTO.setItemCode(soItemList.get(0).getItem()
								.getItemCode());
						stockInDTO
								.setSoItemQty(soItemList.get(0).getQuantity());
						stockInDTO.setWorkOrderNo(workOrderOutput.get(0)
								.getProductionWorkOrder().getWorkOrderNo());
						stockInDTO.setQcStatus("Approved");
						stockInDTO.setCustomerName(soItemList.get(0).getOrder()
								.getCustomer().getCustomerName());
						stockInDTO.setBundleId(bundleNo);
						stockInDTO.setBatchNo(workOrderOutput.get(0)
								.getBatchNo());
						stockInDTO.setConfirmStatus("Yes");
						stockInDTO.setStockQty(workOrderOutput.get(0)
								.getNetLength());
						stockInDTO.setWeight(workOrderOutput.get(0)
								.getNetWeight());
						stockInDTO.setSupervisor(supervisor);
						StockIn stockInObj = null;
						if (stockInList.size()==0 && storeRegExistList.size()==0) {
							stockInObj = stockInDTO.getStockIn();
							createdStockIn = stockInService.create(stockInObj);
							if (createdStockIn != null)
								updateStockInResult = true;
							else
								updateStockInResult = false;
						}
						if (updateStockInResult == true	&& storeRegExistList.size() == 0) {
							StoreRegisterDTO storeRegDTO = new StoreRegisterDTO();
							storeRegDTO.setItemCode(soItemList.get(0).getItem().getItemCode());
							storeRegDTO.setStoreId(1);
							storeRegDTO.setWorkOrderNo(workOrderOutput.get(0).getProductionWorkOrder().getWorkOrderNo());
							storeRegDTO.setCustomerName(soItemList.get(0).getOrder().getCustomer().getCustomerName());
							storeRegDTO.setBundleId(bundleNo);
    						storeRegDTO.setOrderId(soItemList.get(0).getOrder().getOrderId());
							storeRegDTO.setOrderDetailId(orderDetailId);
							storeRegDTO.setItemId(soItemList.get(0).getItem().getItemId());
                    		storeRegDTO.setSupervisor(supervisor);
							if (soItemList.get(0).getOrder().getOrderId()
									.equalsIgnoreCase("BS000001")) {
								storeRegDTO.setPackingSlipNo((long) 1);
								storeRegDTO.setBagWeight(1.0);
							}
							storeRegDTO.setStockQty(workOrderOutput.get(0).getNetLength());
							storeRegDTO.setWeight(workOrderOutput.get(0).getNetWeight());
							storeRegDTO.setQcStatus("Pending");
							storeRegDTO.setQcSupervisor("");
							storeRegDTO.setRejectStatus("");
							StoreRegister storeReg = storeRegDTO.getStoreRegister();
							createdStoreReg = storeRegisterService
									.create(storeReg);
							if (createdStoreReg != null)
								updateStoreReg = true;
						}
					}
				}
			}
		}
		return new StatusResponse(updateStoreReg);

	}

	@RequestMapping(value = "/getWorkOrderNos/{status}", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	ArrayList<String> getWorkOrderNos(
			@PathVariable("status") String status,
			@RequestParam("processType") String processType,
			@RequestParam("month") int month,
			@RequestParam("year") int year) {
		ArrayList<String> woNosList = new ArrayList<>();
		List<ProductionWorkOrder> pdnWos = productionWorkOrderService.findByProcessTypeAndStatusAndMonthYear(processType, status,month+1,year);

		for (int iterator = 0; iterator < pdnWos.size(); iterator++) {
			if (pdnWos.get(iterator).getWorkOrderNo() != null
					&& pdnWos.get(iterator).getWorkOrderNo() != "") {
				String woNo = pdnWos.get(iterator).getWorkOrderNo();
				if (!woNosList.contains(woNo)) {
					woNosList.add(woNo);
				}
			}
		}
		Collections.sort(woNosList,Collections.reverseOrder());

		return woNosList;
	}

	@RequestMapping(value = "/mwdJobCardReport", produces = "application/pdf", method = RequestMethod.GET)
	public void MultiWireJobCardReport(@RequestParam(value = "workOrderNo", required = true) String workOrderNo,javax.servlet.http.HttpServletResponse response) throws IOException, InterruptedException {
		if(workOrderNo!=null && workOrderNo!=""){
		InputStream inputStream = getClass().getClassLoader().getResourceAsStream("/org/balajicables/salesmanager/report/MWDJobCard.jrxml");
		
		Map<String, Object> hm = new HashMap<String, Object>();
		hm.put("WORK ORDER NO", workOrderNo);
		byte[] content = ReportGenerator.newReportGenerator(inputStream, hm);
		
		response.setContentType("application/pdf");
		response.setHeader("Content-Disposition", "attachment;filename="+ "MultiwireDrawingJobCard" + workOrderNo + ".pdf");
		response.setContentLength(content.length);
		
		FileCopyUtils.copy(content, response.getOutputStream());
		}
	}

	@RequestMapping(value = "/semiFinishedLabelReport", produces = "application/pdf", method = RequestMethod.GET)
	public void SemiFinishedLabelReport(@RequestParam(value = "woId", required = true) String woOutPutId,javax.servlet.http.HttpServletResponse response)	throws IOException, InterruptedException {
		
		
		if(woOutPutId!=null){
		InputStream inputStream = getClass().getClassLoader().getResourceAsStream("/org/balajicables/salesmanager/report/SemiFinishedLabelReport.jrxml");
		
		Map<String, Object> hm = new HashMap<String, Object>();
		hm.put("WO_OUTPUT_ID", Integer.parseInt(woOutPutId));
		byte[] content = ReportGenerator.newReportGenerator(inputStream, hm);
		
	
		
		response.setContentType("application/pdf");
		response.setHeader("Content-Disposition", "attachment;filename="+ "SemiFinishedLabel" + woOutPutId + ".pdf");
		response.setContentLength(content.length);
		
		FileCopyUtils.copy(content, response.getOutputStream());
		}
	}

}
