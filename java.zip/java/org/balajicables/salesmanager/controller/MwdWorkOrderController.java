package org.balajicables.salesmanager.controller;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
import javax.annotation.Resource;
import org.balajicables.salesmanager.CustomUser;
import org.balajicables.salesmanager.common.JqgridResponse;
import org.balajicables.salesmanager.common.SaveProductionWorkOrder;
import org.balajicables.salesmanager.common.StatusResponse;
import org.balajicables.salesmanager.dto.MwdWorkOrderDTO;
import org.balajicables.salesmanager.dto.OrderDTO;
import org.balajicables.salesmanager.dto.SalesOrderItemsDTO;
import org.balajicables.salesmanager.model.Customer;
import org.balajicables.salesmanager.model.Item;
import org.balajicables.salesmanager.model.MwdWorkOrder;
import org.balajicables.salesmanager.model.OrderStatus;
import org.balajicables.salesmanager.model.ProductionProcess;
import org.balajicables.salesmanager.model.ProductionWorkOrder;
import org.balajicables.salesmanager.model.SalesOrder;
import org.balajicables.salesmanager.model.SalesOrderItem;
import org.balajicables.salesmanager.repository.ItemRepository;
import org.balajicables.salesmanager.repository.MwdWorkOrderRepository;
import org.balajicables.salesmanager.service.CustomerService;
import org.balajicables.salesmanager.service.ItemService;
import org.balajicables.salesmanager.service.MachineService;
import org.balajicables.salesmanager.service.MwdWorkOrderInputService;
import org.balajicables.salesmanager.service.OrderDetailsService;
import org.balajicables.salesmanager.service.OrderService;
import org.balajicables.salesmanager.service.OrderStatusService;
import org.balajicables.salesmanager.service.ProductTypeService;
import org.balajicables.salesmanager.service.ProductionProcessService;
import org.balajicables.salesmanager.service.ProductionWorkOrderService;
import org.joda.time.DateTime;
import org.springframework.data.domain.Page;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
/**
* This class demonstrates MMH WorkOrder Process
* @author Abin Sam
*/
@Controller
@RequestMapping("/createMWDWorkOrder")
public class MwdWorkOrderController {

	@Resource
	private OrderStatusService orderStatusService;

	@Resource
	private ProductionWorkOrderService productionWorkOrderService;
	
	@Resource
	private MachineService machineService;

	@Resource
	private ProductionWorkOrderService prodWorkOrderService;
	
	@Resource
	private MwdWorkOrderInputService mwdWorkOrderInputService;

	@Resource
	private CustomerService customerService;

	@Resource
	private MwdWorkOrderRepository mwdWorkOrderRepository;

	@Resource
	private ItemRepository itemRepository;
	
	@Resource
	private ProductionProcessService productionProcessService;

	@Resource
	private OrderService orderService;

	@Resource
	private OrderDetailsService orderDetailsService;

	@Resource
	private ItemService itemService;
	
	@Resource
	private ProductTypeService productTypeService;
	/**
	   * This method returns mwdWorkOrder.jsp.
	   * Fetch all customers and workorder number based on process type
	   * @param Model to set the attribute.
	   * @return mwdWorkOrder.jsp.
	   */
	@RequestMapping
	public String getCreateWoPage(Model model) {
        /*Method to fetch customer list*/
		List<Customer> customers = customerService.findAll();
		/*Method to fetch PL items list*/
		List<Item> items = itemRepository.findByProductTypeProductKey("PL");
		items.addAll(itemRepository.findByProductTypeProductKey("PA"));
		
		String processType = "MWD";
		String status="Created";
		/*Initializing empty array list of type String*/
		ArrayList<String> woNosList = new ArrayList<>();
		List<ProductionWorkOrder> productionWorkOrders = productionWorkOrderService.findByProcessTypeAndStatus(processType, status);
		for (int iterator = 0; iterator < productionWorkOrders.size(); iterator++) {
			if (productionWorkOrders.get(iterator).getWorkOrderNo() != null
					&& productionWorkOrders.get(iterator).getWorkOrderNo() != "") {
				String woNo = productionWorkOrders.get(iterator).getWorkOrderNo();
				if (!woNosList.contains(woNo)) {
					woNosList.add(woNo);
				}//end of inner if loop
			}//end of outer if loop
		}//end of for loop
		Collections.sort(woNosList,Collections.reverseOrder());//sorts the list of MMH Work Order numbers into descending order

		ArrayList<Integer> numberOfCopperStrandsList = new ArrayList<>();
		List<Item> itemList = itemService.findByItemType("Multiwire");
		for (int iterator = 0; iterator < itemList.size(); iterator++) {
			if (itemList.get(iterator).getNumberOfCopperStrands() != null) {
				Integer numberOfCopperStrands = itemList.get(iterator).getNumberOfCopperStrands();
				if (!numberOfCopperStrandsList.contains(numberOfCopperStrands)) {
					numberOfCopperStrandsList.add(numberOfCopperStrands);
				}//end of inner if loop
			}//end of outer if loop
		}//end of for loop
		model.addAttribute("items", items);
		model.addAttribute("customers", customers);
		model.addAttribute("workOrderNo",woNosList);
		model.addAttribute("machine",machineService.findProcessMachineNo(processType));
		model.addAttribute("copperDiameters", itemService.getAllCopperDiameters());
    	model.addAttribute("productTypes", productTypeService.findByProcessType("MWD"));
		model.addAttribute("numberOfCopperStrands", numberOfCopperStrandsList);

		return "mwdWorkOrder";
	}
	/**
	   * Fetch copper diameter based on the product type and number of copper strands
	   * @PathVariable numberOfCopperStrand
	   * @return cuDiamtereList
	   */	
	@RequestMapping(value = "/getCuDiamter/{numberOfCopperStrand}", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	ArrayList<String> getDeliveryChallanNos(
			@PathVariable("numberOfCopperStrand") Integer numberOfCopperStrand, Model model) {
        /*Initializing empty ArrayList of type String*/
		ArrayList<String> cuDiamtereList = new ArrayList<>();
		/*Method to fetch item list based on process type and number of copper strands*/
		List<Item>itemList=itemService.findByItemTypeAndNumberOfCuStrands("Multiwire",numberOfCopperStrand);

		for (int iterator = 0; iterator < itemList.size(); iterator++) {
			if(itemList.get(iterator).getCopperStrandDiameter().getCopperkey()!=null && itemList.get(iterator).getCopperStrandDiameter().getCopperkey()!=""){
			String cuDiameter = itemList.get(iterator).getCopperStrandDiameter().getCopperkey();
			if (!cuDiamtereList.contains(cuDiameter)) {
				cuDiamtereList.add(cuDiameter);
			}//end of inner if condition
			}//end of outer if condition
		}//end of for loop
  		return cuDiamtereList;
	}
	/**
	   * Fetch MMH work order numbers list based on process type and status
	   * @return mwdWoNo
	   */		
	@RequestMapping(value = "/getMwdWoNos", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	List<String> getMwdWoNos() {
		String processType = "MWD";
		String status="Created";
		/*Initialisation of empty ArrayList of type String*/
		ArrayList<String>mwdWoNo=new ArrayList<String>();
		/*Method to fetch workorder list based on process type and status*/
		List<ProductionWorkOrder>mwdWoNoList=productionWorkOrderService.findByProcessTypeAndStatus(processType, status);
		for (int iterator = 0; iterator < mwdWoNoList.size(); iterator++) {
			if(mwdWoNoList.get(iterator).getWorkOrderNo()!=null && mwdWoNoList.get(iterator).getWorkOrderNo()!="")
				mwdWoNo.add(mwdWoNoList.get(iterator).getWorkOrderNo());
		}//end of for loop
		Collections.sort(mwdWoNo,Collections.reverseOrder());//sorts the list of MMH Work Order numbers into descending order

		return mwdWoNo;
	}
	/**
	   * Method to create MWD work order
	   * @RequestParam mwdStartDate,mwdCompletionDate,mwdWoMachineNoSelect,mwdWorkOrderNoTag
	   * @return newCreatedList
	   */
	@RequestMapping(value = "/createProdWO", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	List<String> createProdWO(@RequestParam String mwdStartDate,
			@RequestParam String mwdCompletionDate,
			@RequestParam Long mwdWoMachineNoSelect,
			@RequestParam(required = false) String mwdWorkOrderNoTag) {
		/*fetch user name based on login user*/
		CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();;
		String userName = user.getFirstName()+" "+user.getLastName();
		/*Initializing empty list of type string*/
		List<String> newCreatedList = new ArrayList<String>();
		if (mwdWorkOrderNoTag.isEmpty() || mwdWorkOrderNoTag == "") {

			String newWorkOrderNo;
			String yearNo = String.valueOf(new DateTime().getYear() % 1000);
			String monthNo = "";
			if (new DateTime().getMonthOfYear() > 9)
				monthNo = String.valueOf(new DateTime().getMonthOfYear());
			else
				monthNo = "0" + String.valueOf(new DateTime().getMonthOfYear());

			String processType = "MWD";
			/*Method to fetch existing MWD work order numbers based on process type*/
			List<ProductionWorkOrder> existWorkOrderList = prodWorkOrderService.fetchLatestWorkOrder(processType);

			String existWorkOrderNo = "";
			if (existWorkOrderList.size() > 0)
				existWorkOrderNo = existWorkOrderList.get(0).getWorkOrderNo();

			if (!existWorkOrderNo.isEmpty()) {
				String existWOYear = existWorkOrderNo.substring(1, 3);
				String existWOMonth = existWorkOrderNo.substring(3, 5);
				String existWONoParse = existWorkOrderNo.substring(1, 8);
				if ((yearNo.equalsIgnoreCase(existWOYear))&& (monthNo.equalsIgnoreCase(existWOMonth))) {
					int workOrderInt = Integer.parseInt(existWONoParse) + 1;
					newWorkOrderNo = "M" + String.valueOf(workOrderInt);
				} else {
					newWorkOrderNo = "M" + yearNo + monthNo + "001";
				}
			}// end of if loop of checking existing sales no
			else {
				newWorkOrderNo = "M" + yearNo + monthNo + "001";
			}
			/*Method to fetch process Id based on process type*/
			List<ProductionProcess>pdnProcess=productionProcessService.findByProcessType("MWD");
			Integer processId = pdnProcess.get(0).getProcessId();
		
			List<ProductionWorkOrder>pdnWoList=productionWorkOrderService.findByProductionWorkOrderNo(newWorkOrderNo);
			if(pdnWoList.size()==0){
		    /*Creating a new instance of class SaveProductionWorkOrder*/
			SaveProductionWorkOrder saveProductionWorkOrder = new SaveProductionWorkOrder();
            /*Method to save bunching work order number in ProductionWorkOrder */
			ProductionWorkOrder prdnWorkOrder = saveProductionWorkOrder.saveProductionWorkOrder(newWorkOrderNo,mwdWoMachineNoSelect, userName, mwdStartDate,mwdCompletionDate, processId);
			/*Method to create Bunching work order*/
			ProductionWorkOrder createdPdnWorkOrder = prodWorkOrderService.create(prdnWorkOrder);
			if (createdPdnWorkOrder != null) {
				newCreatedList.add(prdnWorkOrder.getWorkOrderNo());
				mwdWorkOrderNoTag = createdPdnWorkOrder.getWorkOrderNo();
			}//if (createdPdnWorkOrder != null)
			}//end of if(pdnWoList.size()==0)
		}//end of if (mwdWorkOrderNoTag.isEmpty() || mwdWorkOrderNoTag == "")
		return newCreatedList;
	}
	/**
	   * Method to save MMH work order input
	   * @param idsSelected,workOrderNo
	   * @return workOrderList
	   */
	@RequestMapping(value="/saveMWdWorkOrderInput", produces="application/json" ,method = RequestMethod.POST)
	public @ResponseBody
	List<String> saveWoItems(
   	 @RequestParam(value = "idsOfSelectedRows[]", required = false) Long[] idsSelected,
   	 @RequestParam(value="workOrderNo",required=true) String workOrderNo) {
		/*Initializing empty list of type string*/
		List<String> workOrderList=new ArrayList<String>();
        Boolean soItemQtyUpdate=false;
        Boolean result=false;
        /*fetch user name based on login user*/  
		CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();;
	 	String supervisor = user.getFirstName()+" "+user.getLastName();
	
		for(int i=0;i<idsSelected.length;i++){
			List<SalesOrderItem> salesOrderItem=orderDetailsService.findById(idsSelected[i]);
		 
			if(salesOrderItem.size()>0){
	
				Double newNetLength=0.0;
				Double newQty=0.0;
				newQty=salesOrderItem.get(0).getWoQty();
				Double noOfCuStrand=(double)salesOrderItem.get(0).getItem().getNumberOfCopperStrands();
				Double stranddDiameter=Double.valueOf(salesOrderItem.get(0).getItem().getCopperStrandDiameter().getCopperkey())/1000;
				Double roundUpWeight=noOfCuStrand*stranddDiameter*stranddDiameter*0.6985*1.015;
				Long netL=(long) ((newQty*100)/Double.valueOf(roundUpWeight));
				newNetLength=Double.valueOf(netL);
					
				MwdWorkOrderDTO mwdWoInputDTO = new MwdWorkOrderDTO();
				mwdWoInputDTO.setWorkOrderNo(workOrderNo);
				mwdWoInputDTO.setOrderDetailId(salesOrderItem.get(0).getOrderDetailId());
				mwdWoInputDTO.setSize(salesOrderItem.get(0).getItem().getInputSize());
				mwdWoInputDTO.setNetLength(newNetLength);
				mwdWoInputDTO.setAnealingPercent(null);
				mwdWoInputDTO.setCustomerName(salesOrderItem.get(0).getOrder().getCustomer().getCustomerName());
				mwdWoInputDTO.setUpdatedBy(supervisor);
				mwdWoInputDTO.setCreatedBy(supervisor);
				mwdWoInputDTO.setStatus("Pending");
				mwdWoInputDTO.setTotalQty(newQty);
				mwdWoInputDTO.setSelectStatus("No");
				MwdWorkOrder mwdWorkOrder=mwdWoInputDTO.getMwdWorkerOrder();
				MwdWorkOrder createdMwdWoInput=mwdWorkOrderInputService.create(mwdWorkOrder);
				if(createdMwdWoInput!=null)
					result=true;

				if(result==true ){
			   Boolean balQtyresult = false;
		       Boolean pdnQtyResult=false;
		       Double workOrderQty=salesOrderItem.get(0).getWoQty();
		       Double balanceQuantity=salesOrderItem.get(0).getBalanceQty();
		       Double pdnQuantity=salesOrderItem.get(0).getProductionQty();
		       Long salesOrderItemId=salesOrderItem.get(0).getOrderDetailId();
		       if(workOrderQty<=balanceQuantity && workOrderQty!=null ){
    				Double newPdnQty=pdnQuantity+workOrderQty;
			       Double totalQty=salesOrderItem.get(0).getQuantity();
			       Double dispatchedQty=salesOrderItem.get(0).getDispatchedQty();
			       Double storeQty=salesOrderItem.get(0).getCompletedQty();
			   	Double newBalanceQty=totalQty-(newPdnQty+storeQty+dispatchedQty);
			   	if(newBalanceQty<0)
			   	newBalanceQty=0.0;
				balQtyresult=orderDetailsService.updateBalQty(salesOrderItemId,newBalanceQty,workOrderQty);
				pdnQtyResult=orderDetailsService.updatePdnQty(salesOrderItemId,newPdnQty,workOrderQty);
				if(balQtyresult==true && pdnQtyResult==true)
					soItemQtyUpdate=true;
			}//end of if(workOrderQty<=balanceQuantity && workOrderQty!=null)
		    if(soItemQtyUpdate==true)
		    	workOrderList.add(workOrderNo);
			}//created if loop
			}//end of if(salesOrderItem.size()>0)
		}//end of for loop
	
		return workOrderList;
	}
	 /**
	   * Crud functionality of MMH work order 
	   * @param id,oper,anealingPercent,netLength
	   * @return StatusResponse
	   */
	@RequestMapping(value = "/crud", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	StatusResponse crud(@RequestParam Long id,
			@RequestParam String oper,
			@RequestParam(required = false) String anealingPercent,
			@RequestParam(required = false) String netLength) {
		
		Boolean updateMwdWoInput=false;
		/*fetch user name based on login user*/ 
		CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();;
		String userName = user.getFirstName()+" "+user.getLastName();
		
		MwdWorkOrder mwdWorkOrder=null;
		List<MwdWorkOrder> mwdList=mwdWorkOrderInputService.findById(id);
		boolean match = false;
		boolean lengthMatch=false;
		Long netLengthVal=null;
		
		 Double roundUpNetLength=null;
		 Double newWoQtyKg=null;
		if(oper.equalsIgnoreCase("edit")){
		    netLengthVal=(Double.valueOf(netLength)).longValue();
		    roundUpNetLength=(double)netLengthVal;
		    Double noOfCuStrand=(double)mwdList.get(0).getSalesOrderItem().getItem().getNumberOfCopperStrands();
			Double stranddDiameter=Double.valueOf(mwdList.get(0).getSalesOrderItem().getItem().getCopperStrandDiameter().getCopperkey())/1000;
			Double roundUpWeight=(noOfCuStrand*stranddDiameter*stranddDiameter*0.6985*1.015)/100;
			Double qty=Double.valueOf(netLengthVal)*roundUpWeight;
			Long woQtyKg= Math.round(qty);
		    newWoQtyKg=Double.valueOf(woQtyKg);
		
			
			String decimalPattern = "((-|\\+)?[0-9]+(\\.[0-9]+)?)+";  
			match = Pattern.matches(decimalPattern, anealingPercent);
			lengthMatch=Pattern.matches(decimalPattern,netLength);
			
			if(match==true && lengthMatch==true){
		
		    MwdWorkOrderDTO mwdWoInputDTO = null;
			if(mwdList.size()>0){
				mwdWoInputDTO=new MwdWorkOrderDTO();
				mwdWoInputDTO.setMwdWoInputId(mwdList.get(0).getMwdWoInputId());
				mwdWoInputDTO.setWorkOrderNo(mwdList.get(0).getProductionWorkOrder().getWorkOrderNo());
				mwdWoInputDTO.setOrderDetailId(mwdList.get(0).getSalesOrderItem().getOrderDetailId());
				mwdWoInputDTO.setSize(mwdList.get(0).getSize());
				mwdWoInputDTO.setNetLength(roundUpNetLength);
				mwdWoInputDTO.setAnealingPercent(anealingPercent);
				mwdWoInputDTO.setCustomerName(mwdList.get(0).getCustomerName());
				mwdWoInputDTO.setUpdatedBy(userName);
				mwdWoInputDTO.setCreatedBy(mwdList.get(0).getCreatedBy());
				mwdWoInputDTO.setStatus(mwdList.get(0).getStatus());
				mwdWoInputDTO.setTotalQty(newWoQtyKg);
				mwdWoInputDTO.setSelectStatus(mwdList.get(0).getSelectStatus());
			}//end of if(mwdList.size()>0)
			mwdWorkOrder=mwdWoInputDTO.getMwdWorkerOrder();	
		}//end of if(match==true && lengthMatch==true)
		
		}//end of if(oper.equalsIgnoreCase("edit"))

		switch (oper) {
		case "edit":
			if(match==true && lengthMatch==true){
			updateMwdWoInput = mwdWorkOrderInputService.update(mwdWorkOrder);
			    Long salesOrderItemId=mwdList.get(0).getSalesOrderItem().getOrderDetailId();
			    String orderId=mwdList.get(0).getSalesOrderItem().getOrder().getOrderId();
			    Double pdnQty=mwdList.get(0).getSalesOrderItem().getProductionQty();
			    Double oldWoQtyLength=mwdList.get(0).getNetLength();
			    Double newWoQtyLength=roundUpNetLength;
			    Double newWoQty=newWoQtyKg;
			    Double oldWoQty=mwdList.get(0).getTotalQty();
			    Double totalQty=mwdList.get(0).getSalesOrderItem().getQuantity();
			    Double newBalQty=0.0;
			    Double newPdnQty=0.0;
			    Double newTotalQty=0.0;
			    if(orderId.equalsIgnoreCase("BS000001")){
			    	newTotalQty=totalQty-oldWoQtyLength+newWoQtyLength;
			    	newPdnQty=pdnQty-oldWoQtyLength+newWoQtyLength;
			    }else{
			       	newTotalQty=totalQty;
			    	newPdnQty=pdnQty-oldWoQty+newWoQty;
			    	newBalQty=newTotalQty-(newPdnQty+mwdList.get(0).getSalesOrderItem().getCompletedQty()+mwdList.get(0).getSalesOrderItem().getDispatchedQty());
			    }//end of  if(orderId.equalsIgnoreCase("BS000001")) else ladder
			    updateMwdWoInput=orderDetailsService.updateBalPdnQty(salesOrderItemId,newTotalQty,newBalQty,newPdnQty);
    		}//end of if(match==true && lengthMatch==true)
			break;
		case "del":
			    Long salesOrderItemId=mwdList.get(0).getSalesOrderItem().getOrderDetailId();
			    String orderId=mwdList.get(0).getSalesOrderItem().getOrder().getOrderId();
			    Double balQty=mwdList.get(0).getSalesOrderItem().getBalanceQty();
			    Double pdnQty=mwdList.get(0).getSalesOrderItem().getProductionQty();
			    Double woQtyLength=mwdList.get(0).getNetLength();
			    Double totalQty=mwdList.get(0).getSalesOrderItem().getQuantity();
			    Double woQty=mwdList.get(0).getTotalQty();
			    Double newBalQty=0.0;
			    Double newPdnQty=0.0;
			    Double newTotalQty=0.0;
			    if(orderId.equalsIgnoreCase("BS000001")){
			    	newBalQty=0.0;
			    	if(woQtyLength<totalQty){
			    		newTotalQty=totalQty-woQtyLength;
					  	newPdnQty=pdnQty-woQtyLength;
				     }
			    }else{
			    	newTotalQty=totalQty;;
			    	newBalQty=balQty+woQty;
			    	if(pdnQty>woQty)
			    		newPdnQty=pdnQty-woQty;
			    }//end of if(orderId.equalsIgnoreCase("BS000001")) else loop
			    mwdWorkOrderRepository.delete(id);
			    updateMwdWoInput=orderDetailsService.updateBalPdnQty(salesOrderItemId,newTotalQty,newBalQty,newPdnQty);
		break;
		}//end of switch cases
		return new StatusResponse(updateMwdWoInput);
	}
	/** Method to fetch MMH work order input records and set to grid
	   * @param workOrderNo,search,filters,pageNumber,rowsPerPage,sortColName,sortOrder
	   * @return JqgridResponse<WorkOrderOutputDTO>   .
	   */
	@RequestMapping(value = "/records/{woNo}", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	JqgridResponse<MwdWorkOrderDTO> records(
			@PathVariable("woNo") String workOrderNo,
			@RequestParam("_search") Boolean search,
			@RequestParam(value = "filters", required = false) String filters,
			@RequestParam(value = "page", required = false) Integer pageNumber,
			@RequestParam(value = "rows", required = false) Integer rowsPerPage,
			@RequestParam(value = "sidx", required = false) String sortColName,
			@RequestParam(value = "sord", required = false, defaultValue = "asc") String sortOrder) {
		 /*JQGrid column sorting*/
		if(sortColName.equalsIgnoreCase("customerCode")){
			sortColName="salesOrderItem.orders.customer.customerCode";
		}

		if(sortColName.equalsIgnoreCase("customerName")){
			sortColName="salesOrderItem.orders.customer.customerName";
		}
		if(sortColName.equalsIgnoreCase("customerCode")){
			sortColName="salesOrderItem.orders.customer.customerCode";
		}
		/*Method to fetch JQGRID paged records of MMH work order input based on work order no*/
		Page<MwdWorkOrder> mwdWoInput = mwdWorkOrderInputService.getPagedOrders(workOrderNo, pageNumber - 1, rowsPerPage,sortColName, sortOrder);
		/*Intialize JQ grid response of type MwdWorkOrderDTO*/
		JqgridResponse<MwdWorkOrderDTO> response = new JqgridResponse<MwdWorkOrderDTO>();
		/*Method to set Bunching work order number list to MwdWorkOrderDTO*/
		List<MwdWorkOrderDTO> mwdWoInputDTOs = convertToDTO(mwdWoInput.getContent());
		response.setRows(mwdWoInputDTOs);
		response.setRecords(Long.valueOf(mwdWoInput.getTotalElements()).toString());
		response.setTotal(Long.valueOf(mwdWoInput.getTotalPages()).toString());
		response.setPage(Integer.valueOf(mwdWoInput.getNumber() + 1).toString());
		return response;
	}
	 /**
	   * This Method to set Invoice item list to MwdWorkOrderDTO
	   * @param List<MwdWorkOrder> MwdWorkOrder
	   * @return List<MwdWorkOrderDTO> response
	   */
	private List<MwdWorkOrderDTO> convertToDTO(List<MwdWorkOrder> mwdWoInputs) {
		List<MwdWorkOrderDTO> mwdWOInputDTOs = new ArrayList<>();
		for (MwdWorkOrder mwdWoInput : mwdWoInputs) {
			MwdWorkOrderDTO mwdWOInputDTO = new MwdWorkOrderDTO();
			mwdWOInputDTO.setMwdWoInputId(mwdWoInput.getMwdWoInputId());
			mwdWOInputDTO.setWorkOrderNo(mwdWoInput.getProductionWorkOrder().getWorkOrderNo());
			mwdWOInputDTO.setOrderDetailId(mwdWoInput.getSalesOrderItem().getOrderDetailId());
			mwdWOInputDTO.setSize(mwdWoInput.getSize());
			mwdWoInput.setNetLength(mwdWoInput.getNetLength());
			mwdWOInputDTO.setNetLength((mwdWoInput.getNetLength()));
			mwdWOInputDTO.setAnealingPercent(mwdWoInput.getAnealingPercent());
			mwdWOInputDTO.setCustomerCode(mwdWoInput.getSalesOrderItem().getOrders().getCustomer().getCustomerCode());
			mwdWOInputDTO.setTotalQty(mwdWoInput.getTotalQty());
			mwdWOInputDTO.setSelectStatus(mwdWoInput.getSelectStatus());
			
			mwdWOInputDTOs.add(mwdWOInputDTO);
		}//end of for loop
		return mwdWOInputDTOs;

	}
	 /**
	   * This Method to create MMH work order number
	   * @param mwdStartDate,mwdCompletionDate,mwdWoMachineNoSelect,numberOfCopperStrandsSelect,copperDiameterSelect,
	   * layLengthSelect,productType,noOfDrums,lengthPerDrum,bunchingWorkOrderNoTag
	   * @return newCreatedList
	   */	
	@RequestMapping(value = "/createMWDWo", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	List<String> createMWDWo(@RequestParam String mwdStartDate,
			@RequestParam String mwdCompletionDate,
			@RequestParam Long mwdWoMachineNoSelect,
		    @RequestParam(required = false) Integer numberOfCopperStrandsSelect,
			@RequestParam(required = false) String copperDiameterSelect,
			@RequestParam(required = false) String productType,
			@RequestParam(required = false) Double netLength,
			@RequestParam(required = false) String anealingPercent,
			@RequestParam(required = false) String mwdWorkOrderNoTag) {
		DecimalFormat oneDForm=new DecimalFormat("0.0");
		/*fetch user name based on login user*/ 
		CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();;
		String userName = user.getFirstName()+" "+user.getLastName();
		/*Initialization of empty list of type String*/
		List<String> newCreatedList = new ArrayList<String>();
		/*Method to get Item list*/
		List<Item> itemIdList=itemService.findByCuDiameterAndCuStrandAndProductType(copperDiameterSelect,numberOfCopperStrandsSelect,productType);
		if(itemIdList.size()>0){
		Double newNetLength=Double.valueOf(netLength.longValue());
        String inputSizeSelect=itemIdList.get(0).getInputSize();
        String itemCode=itemIdList.get(0).getItemCode();
		Long itemId=itemIdList.get(0).getItemId();
		Double noOfCuStrand=(double)itemIdList.get(0).getNumberOfCopperStrands();
		Double stranddDiameter=Double.valueOf(itemIdList.get(0).getCopperStrandDiameter().getCopperkey())/1000;

		Double roundUpWeight=noOfCuStrand*stranddDiameter*stranddDiameter*0.6985*1.015;
		String weightVal=oneDForm.format((Double.valueOf(roundUpWeight)/100)*newNetLength);
	    Double netQuantity=Double.valueOf(weightVal);
	 
		
		if (mwdWorkOrderNoTag.isEmpty() || mwdWorkOrderNoTag == "") {
			String newWorkOrderNo;
			String yearNo = String.valueOf(new DateTime().getYear() % 1000);
			String monthNo = "";
			if (new DateTime().getMonthOfYear() > 9)
				monthNo = String.valueOf(new DateTime().getMonthOfYear());
			else
				monthNo = "0" + String.valueOf(new DateTime().getMonthOfYear());

			String processType = "MWD";
			List<ProductionWorkOrder> existWorkOrderList = prodWorkOrderService
					.fetchLatestWorkOrder(processType);
            List<ProductionProcess>pdnProcessList=productionProcessService.findByProcessType(processType);
			String existWorkOrderNo = "";
			if (existWorkOrderList.size() > 0)
				existWorkOrderNo = existWorkOrderList.get(0).getWorkOrderNo();

			if (!existWorkOrderNo.isEmpty()) {
				String existWOYear = existWorkOrderNo.substring(1, 3);
				String existWOMonth = existWorkOrderNo.substring(3, 5);
				String existWONoParse = existWorkOrderNo.substring(1, 8);
				if ((yearNo.equalsIgnoreCase(existWOYear))
						&& (monthNo.equalsIgnoreCase(existWOMonth))) {
					int workOrderInt = Integer.parseInt(existWONoParse) + 1;
					newWorkOrderNo = "M" + String.valueOf(workOrderInt);
				} else {
					newWorkOrderNo = "M" + yearNo + monthNo + "001";
				}//end of inner if else ladder
			}// end of if loop of checking existing sales no
			else {
				newWorkOrderNo = "M" + yearNo + monthNo + "001";
			}//end of if (!existWorkOrderNo.isEmpty()) else ladder
			
			Integer processId = pdnProcessList.get(0).getProcessId();
			List<ProductionWorkOrder> pdnWoList=productionWorkOrderService.findByProductionWorkOrderNo(newWorkOrderNo);
			if(pdnWoList.size()==0){
			SaveProductionWorkOrder saveProductionWorkOrder = new SaveProductionWorkOrder();
			ProductionWorkOrder prdnWorkOrder = saveProductionWorkOrder.saveProductionWorkOrder(newWorkOrderNo,	mwdWoMachineNoSelect, userName, mwdStartDate,mwdCompletionDate, processId);
			ProductionWorkOrder createdPdnWorkOrder = prodWorkOrderService.create(prdnWorkOrder);
			if (createdPdnWorkOrder != null) {
			 mwdWorkOrderNoTag = createdPdnWorkOrder.getWorkOrderNo();
			}

		}
	}
		List<SalesOrderItem>soItemsList=orderDetailsService.findByOrdersOrderIdItemsItemCode("BS000001", itemCode);
		Boolean soItemResult=false;
		Long soItemsId=null;
		        List<OrderStatus> orderStatusList=orderStatusService.findByStatus("Approved");
			    Integer orderStatusId=null;
			    if(orderStatusList.size()>0)
			    	orderStatusId=orderStatusList.get(0).getOrderStatusId();
			    
		    	Long customerId=(long) 1;	
		 		Boolean soResult = false;
		 	    OrderDTO orderDTO = new OrderDTO();
				orderDTO.setOrderId("BS000001");
				orderDTO.setCreatedTime("1980-01-01 00:00:00.0");
				orderDTO.setCustomerId(customerId);
				orderDTO.setOrderStatusId(orderStatusId);
				orderDTO.setCreatedBy(userName);
				orderDTO.setUpdatedBy(userName);
				orderDTO.setInputQuantity(newNetLength);
				orderDTO.setMailStatus("No");
				java.util.Date date= new java.util.Date();
				orderDTO.setUpdatedTime(new Timestamp(date.getTime()).toString());
			  
				SalesOrder order = orderDTO.getOrder();
				
				List<SalesOrder> salesOrders = orderService.findBySalesOrderNoId("BS000001");
				
				if(salesOrders.size()== 0){
					SalesOrder createdOrder = orderService.create(order);
					if (createdOrder != null) {
						soResult = true;
					}
				}
				else{
					soResult=orderService.update(order);
				}
						
			SalesOrderItem createdSoItem =null;	
			if(soResult==true){
			if(soItemsList.size()==0){
				SalesOrderItemsDTO soitemsDTO = new SalesOrderItemsDTO();
				
					soitemsDTO.setOrderId("BS000001");
					soitemsDTO.setItemId(itemId);
					soitemsDTO.setItemCode(itemCode);
					soitemsDTO.setQuantity(newNetLength);
					soitemsDTO.setBalanceQty(0.0);
					soitemsDTO.setCompletedQty(0.0);
					soitemsDTO.setProductionQty(newNetLength);
					soitemsDTO.setWoQty(newNetLength);
					soitemsDTO.setDispatchedQty(0.0);
					soitemsDTO.setBundleSize(1);
					soitemsDTO.setWeight(netQuantity);
					soitemsDTO.setPvcWeight(netQuantity);
					soitemsDTO.setUpdatedBy(userName);
					soitemsDTO.setUpdatedTime(new Timestamp(date.getTime()).toString());
					SalesOrderItem soitem = soitemsDTO.getOrderDetail();
					createdSoItem = orderDetailsService.create(soitem);
					if (createdSoItem != null) {
						soItemsId=createdSoItem.getOrderDetailId();
						soItemResult = true;
					}
			}		
		else{
			SalesOrderItemsDTO soItemsDTO=new SalesOrderItemsDTO();
			Double newTotalQty=soItemsList.get(0).getQuantity()+newNetLength;
			Double newPdnQty=soItemsList.get(0).getProductionQty()+newNetLength;
			soItemsDTO.setOrderDetailId(soItemsList.get(0).getOrderDetailId());
			soItemsDTO.setOrderId(soItemsList.get(0).getOrder().getOrderId());
			soItemsDTO.setItemId(soItemsList.get(0).getItem().getItemId());
			soItemsDTO.setItemCode(soItemsList.get(0).getItem().getItemCode());
			soItemsDTO.setQuantity(newTotalQty);
			soItemsDTO.setBalanceQty(0.0);
			soItemsDTO.setCompletedQty(soItemsList.get(0).getCompletedQty());
			soItemsDTO.setProductionQty(newPdnQty);
			soItemsDTO.setWoQty(newNetLength);
			soItemsDTO.setDispatchedQty(soItemsList.get(0).getDispatchedQty());
			soItemsDTO.setBundleSize(soItemsList.get(0).getBundleSize());
			soItemsDTO.setWeight(soItemsList.get(0).getWeight());
			soItemsDTO.setPvcWeight(soItemsList.get(0).getPvcWeight());
			soItemsDTO.setUpdatedBy(userName);
			SalesOrderItem soItemObj=soItemsDTO.getOrderDetail();
			Boolean updateSoItemObj=orderDetailsService.update(soItemObj);
			if(updateSoItemObj==true){
				soItemsId=soItemsList.get(0).getOrderDetailId();
				soItemResult=true;
			}
				
		}
	}//end of if(soResult==true)
		if(soItemResult==true){
		MwdWorkOrderDTO mwdWoInputDTO = new MwdWorkOrderDTO();
		mwdWoInputDTO.setWorkOrderNo(mwdWorkOrderNoTag);
		mwdWoInputDTO.setOrderDetailId(soItemsId);
		mwdWoInputDTO.setSize(inputSizeSelect);
		mwdWoInputDTO.setNetLength(newNetLength);
		mwdWoInputDTO.setAnealingPercent(anealingPercent);
		mwdWoInputDTO.setCustomerName("Balaji");
		mwdWoInputDTO.setCreatedBy(userName);
		mwdWoInputDTO.setStatus("Pending");
		mwdWoInputDTO.setUpdatedBy(userName);
		mwdWoInputDTO.setTotalQty(netQuantity);
		mwdWoInputDTO.setSelectStatus("No");
		MwdWorkOrder mwdWorkOrder = mwdWoInputDTO.getMwdWorkerOrder();
		
       MwdWorkOrder createdMwdWo = mwdWorkOrderInputService.create(mwdWorkOrder);
       if(createdMwdWo!=null)
		newCreatedList.add(mwdWorkOrder.getProductionWorkOrder().getWorkOrderNo());
	 }//end of if(soItemResult==true)
	}
		return newCreatedList;

}
	/**
	   * This Method to update WorkOrder status
	   * @PathVariable woNo
	   * @return StatusResponse
	   */
	@RequestMapping(value="/pendingWorkOrder/{woNo}", produces="application/json", method=RequestMethod.POST)
	public @ResponseBody
	StatusResponse submitExtrusionWorkOrder(
			@PathVariable("woNo") String woNo) {
		Boolean result=false;
		String submitStatus="Pending";
		result=productionWorkOrderService.updateWorkOrderStatus(woNo,submitStatus);
		 return new StatusResponse(result);
	}
	/**
	   * This Method to generate MMH work order report
	   * @param workOrderNo,response
	   * @return void
	   */
@RequestMapping(value = "/mwdWorkOrderReport", produces = "application/pdf", method = RequestMethod.GET)
	
	public void mwdWorkOrderReport(@RequestParam(value = "workOrderNo", required = true) String workOrderNo,javax.servlet.http.HttpServletResponse response) throws IOException, InterruptedException{
		if(workOrderNo!=null && workOrderNo!=""){
	InputStream inputStream = getClass().getClassLoader().getResourceAsStream("/org/balajicables/salesmanager/report/MWDWorkOrderReport.jrxml");
    	
    	 Map<String, Object> hm= new HashMap<String, Object>();
         hm.put("WorkOrderNo", workOrderNo);//set report parameter
         byte[] content = ReportGenerator.newReportGenerator(inputStream,hm);//call report generator method
	      
			response.setContentType("application/pdf");
			response.setHeader("Content-Disposition", "attachment;filename=" + "MWDWorkOrderReport"+workOrderNo+".pdf");//MMH WorkOrder Report file name
		    response.setContentLength(content.length);
	    FileCopyUtils.copy(content, response.getOutputStream());
		}
   }
/**
 * This Method to fetch copper weight
 * @param numberOfCuStrand,cuDiameter,layLength,productType
 * @return cuWeightList
 */
@RequestMapping(value = "/fetchCuWeight", produces = "application/json", method = RequestMethod.POST)
public @ResponseBody
List<String>  fetchCuWeight(
		@RequestParam(required = false) Integer numberOfCuStrand,
		@RequestParam(required = false) String cuDiameter,
		@RequestParam(required = false) String productType){
	 
	   List<Item> itemIdList=itemService.findByCuDiameterAndCuStrandAndProductType(cuDiameter,numberOfCuStrand,productType);
       List<String> cuWeightList = new ArrayList<String>();
       double cuWeight=0.0;
	if(itemIdList.size()>0){
		if(itemIdList.get(0).getCopperWeight()!=null)
		cuWeight=itemIdList.get(0).getCopperWeight();
	}
	cuWeightList.add(String.valueOf(cuWeight));
	return cuWeightList;
	
}
	
}
