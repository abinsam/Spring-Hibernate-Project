package org.balajicables.salesmanager.controller;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Pattern;
import javassist.expr.NewArray;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import org.balajicables.salesmanager.CustomUser;
import org.balajicables.salesmanager.common.JqgridResponse;
import org.balajicables.salesmanager.common.SalesOrderUpdate;
import org.balajicables.salesmanager.common.StatusResponse;
import org.balajicables.salesmanager.dto.AssortedRateDTO;
import org.balajicables.salesmanager.dto.ItemDTO;
import org.balajicables.salesmanager.dto.OrderDTO;
import org.balajicables.salesmanager.dto.SalesOrderItemsDTO;
import org.balajicables.salesmanager.dto.WorkOrderItemsDTO;
import org.balajicables.salesmanager.repository.ItemRepository;
import org.balajicables.salesmanager.repository.ProductTypeRepository;
import org.balajicables.salesmanager.service.ItemService;
import org.balajicables.salesmanager.model.AssortedRate;
import org.balajicables.salesmanager.model.CableStdPvc;
import org.balajicables.salesmanager.model.Colour;
import org.balajicables.salesmanager.model.CopperDiameter;
import org.balajicables.salesmanager.model.Customer;
import org.balajicables.salesmanager.model.Item;
import org.balajicables.salesmanager.model.OrderStatus;
import org.balajicables.salesmanager.model.ProductType;
import org.balajicables.salesmanager.model.ProductionWorkOrder;
import org.balajicables.salesmanager.model.SalesOrder;
import org.balajicables.salesmanager.model.SalesOrderItem;
import org.balajicables.salesmanager.model.User;
import org.balajicables.salesmanager.model.WorkOrderItems;
import org.balajicables.salesmanager.service.AssortedRateService;
import org.balajicables.salesmanager.service.CableStdPvcService;
import org.balajicables.salesmanager.service.CustomerService;
import org.balajicables.salesmanager.service.OrderDetailsService;
import org.balajicables.salesmanager.service.OrderService;
import org.balajicables.salesmanager.service.OrderStatusService;
import org.balajicables.salesmanager.service.ProductTypeService;
import org.balajicables.salesmanager.utils.JSONExcelUtility;
import org.balajicables.salesmanager.utils.Utility;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.servlet.ModelAndView;
/**
* This class demonstrates Customer fetch/Update/Create Process.
* @author Abin Sam
*/
@SuppressWarnings("unused")
@Controller
@RequestMapping("/orderdetails")
public class OrderDetailsController {
	
	@Resource
	private OrderDetailsService orderDetailsService;
	
	@Resource
	private OrderService orderService;

	@Resource
	private ItemService itemService;

	@Resource
	private CustomerService customerService;
	
	@Resource
	private AssortedRateService assortedRateService;

	@Resource
	private OrderStatusService orderStatusService;

	@Resource 
	private ProductTypeService productTypeService;
	
	@Resource 
	private CableStdPvcService cableStdPvcService;
	
	@Resource 
	private ProductTypeRepository productTypeRepository;
	
	@Resource 
	private ItemRepository itemRepository;
	
	@RequestMapping(method = RequestMethod.GET)
	public String getItemsPage(Model model, @RequestParam(value="orderId") String orderId) {
		SalesOrder order = orderService.findByIdWithCustomer(orderId);
		model.addAttribute("orderId", orderId);
		model.addAttribute("order", order);	
		List<ProductType> productTypesList = productTypeService.findAll();// fetch all bunching work order have status pending and are in current month and year to a list
		model.addAttribute("productTypes", productTypesList);
		List<CableStdPvc> cableStdPvcsList = cableStdPvcService.findAll();// fetch all bunching work order have status pending and are in current month and year to a list

		model.addAttribute("cableStdPvcs", itemService.getAllCableStdPvcs());
		model.addAttribute("colours", itemService.getAllColours());
		model.addAttribute("copperDiameters", itemService.getAllCopperDiameters());
 		
		model.addAttribute("units", itemService.getAllUnits());	
		return "orderDetails";
	}	

	@RequestMapping(value="/fetchItemCode", produces="application/json", method=RequestMethod.GET)
	public @ResponseBody List<String> fetchItemCode(){
		List<String>itemCodesList=itemService.selectAllItemCodes();
		return itemCodesList;
		
	}
	
	@RequestMapping(value="/create" , method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	public @ResponseBody List<String> createOrderDetails(
			@RequestParam("orderId") String orderId,
			@RequestParam("item") String itemCode,
			@RequestParam("productType") String productType,
			@RequestParam("cableStdPvc") String cableStdKey,
			@RequestParam("copperDiameter") String copperkey,
			@RequestParam("colour") String mainColour,
			@RequestParam("innerColour") String innerColor,
			@RequestParam("rate") Float rate,
			@RequestParam("quantity") Double quantity,
			@RequestParam("bundleSize") String bundleSize,
			@RequestParam("numberOfCopperStrands") Integer numberOfCopperStrands
			)
		
	{
		CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();;

	 	String firstName=user.getFirstName();
	 	String lastname=user.getLastName();
	 	String name=firstName+" "+lastname;	 	
	 	
	    List<SalesOrder> soOrderDetailsList=null;
	    List<SalesOrderItem> soItemList=null;
	    Double inputQty=0.0;
	 	Double weight=0.0;	 	
	 	
		List<String> statusMssgList=new ArrayList<String>();
		Boolean result = false;
		List <Item> itemIdList=itemService.findByItemCode(itemCode);
		
		Long itemId=itemIdList.get(0).getItemId();
		if(itemIdList.size()>0){
			String productKey=itemIdList.get(0).getProductType().getProductKey();
			Double noOfCuStrand=(double)itemIdList.get(0).getNumberOfCopperStrands();
			Double stranddDiameter=Double.valueOf(itemIdList.get(0).getCopperStrandDiameter().getCopperkey())/1000;
			DecimalFormat threeDForm=new DecimalFormat("0.000");
	    	if(productKey.equalsIgnoreCase("BA") || productKey.equalsIgnoreCase("BC") || productKey.equalsIgnoreCase("CS") ||
					   productKey.equalsIgnoreCase("MS")|| productKey.equalsIgnoreCase("PA") || productKey.equalsIgnoreCase("PL") || productKey.equalsIgnoreCase("PS") ||
					   productKey.equalsIgnoreCase("PV") || productKey.equalsIgnoreCase("RA") || productKey.equalsIgnoreCase("RB") ||  productKey.equalsIgnoreCase("RI")){
						weight=quantity;
							}
			else{
				Double roundUpWeight=noOfCuStrand*stranddDiameter*stranddDiameter*0.6985*1.015;
				   String weightVal=threeDForm.format((Double.valueOf(roundUpWeight)/100)*quantity);
				   weight=Double.valueOf(weightVal);
		   }		
		}
		
		SalesOrderItemsDTO soitemsDTO = new SalesOrderItemsDTO();
		if(orderId!= null && itemCode!=null && itemId!=null) {
			soitemsDTO.setOrderId(orderId);
			soitemsDTO.setItemId(itemId);
			soitemsDTO.setItemCode(itemCode);
		}
		
		soitemsDTO.setRate(rate);
		if(quantity!=null){
		soitemsDTO.setQuantity(quantity);
		soitemsDTO.setWeight(weight);
		soitemsDTO.setPvcWeight(weight);
		}
		else{
			soitemsDTO.setQuantity(0.0);
			soitemsDTO.setWeight(weight);
			soitemsDTO.setPvcWeight(weight);
		}
		soitemsDTO.setBundleSize(Integer.parseInt(bundleSize));
		if(quantity!=null)
		soitemsDTO.setBalanceQty(quantity);
		else
		soitemsDTO.setBalanceQty(0.0);					
		soitemsDTO.setCompletedQty(0.0);
		soitemsDTO.setWoQty(0.0);
		soitemsDTO.setProductionQty(0.0);
		soitemsDTO.setDispatchedQty(0.0);
		soitemsDTO.setUpdatedBy(name);
		SalesOrderItem soitem = soitemsDTO.getOrderDetail();
		List<SalesOrderItem> soitemList=orderDetailsService.findByOrderIdItemId(orderId,itemCode);
		if(soitemList.size()==0){
		SalesOrderItem createdSoItem = orderDetailsService.create(soitem);
		if (createdSoItem != null) {
			result = true;
		}
		if(result==true){
			  soOrderDetailsList=orderService.findBySalesOrderNoId(orderId);
			    soItemList=orderDetailsService.findByOrderId(orderId);
			    if(soItemList.size()>0){
			    	for(int i=0;i<soItemList.size();i++){
			    		inputQty=inputQty+soItemList.get(i).getQuantity();
			    	}
			    }
				if(soOrderDetailsList.size()>0){
			  SalesOrderUpdate soQtyUpdate=new SalesOrderUpdate();
			  SalesOrder soOrder=soQtyUpdate.updateSoOrder(orderId,soOrderDetailsList,inputQty);
			  Boolean updateSalesOrder=orderService.update(soOrder);
				}
				
		}
		statusMssgList.add("added");
	}	
		else statusMssgList.add("exist");
			
		return statusMssgList;	

	}

	@RequestMapping(value = "/{id}", method=RequestMethod.PUT)
	@ResponseStatus(HttpStatus.NO_CONTENT)
	public void updateOrder(@PathVariable("id") String id,
			@Valid OrderDTO orderDTO) {
		
	}

	@RequestMapping(value="/{id}", method=RequestMethod.DELETE)
	@ResponseStatus(HttpStatus.NO_CONTENT)
	public void deleteOrder(@PathVariable("id") String id) {
		
	}
	
	@RequestMapping(method=RequestMethod.POST)
	@ResponseStatus(HttpStatus.CREATED)
	public @ResponseBody OrderDTO createOrder(@Valid OrderDTO orderDTO, BindingResult result,
					HttpServletResponse response) throws BindException {
		if(result.hasErrors()) {
			throw new BindException(result);
		}
		return null;
	}
	
	@RequestMapping(value="/addedItems/{orderId}", produces="application/json", method=RequestMethod.GET)
	public @ResponseBody
	JqgridResponse<SalesOrderItemsDTO> records(
			@PathVariable("orderId") String salesOrderId,
    		@RequestParam("_search") Boolean search,
    		@RequestParam(value="filters", required=false) String filters,
			@RequestParam(value = "page", required = false) Integer pageNumber,
			@RequestParam(value = "rows", required = false) Integer rowsPerPage,
			@RequestParam(value = "sidx", required = false) String sortColName,
			@RequestParam(value = "sord", required = false, defaultValue = "asc") String sortOrder) {
		//JQ grid sorting column name  
		if(sortColName.equalsIgnoreCase("itemCode")){
			sortColName="items.itemCode";
		}
	
		if(sortColName.equalsIgnoreCase("itemDescription")){
			sortColName="items.itemDescription";
		}
	
		if(sortColName.equalsIgnoreCase("unit")){
			sortColName="items.unit";
		}
		
		Page<SalesOrderItem> orderOutput = orderDetailsService.getPagedSalesOrderItems(salesOrderId,pageNumber - 1,
				rowsPerPage, sortColName, sortOrder);
				JqgridResponse<SalesOrderItemsDTO> response = new JqgridResponse<SalesOrderItemsDTO>();
				List<SalesOrderItemsDTO> salesOrderItemDTOs = convertToItemDTO(orderOutput.getContent(),salesOrderId);
				response.setRows(salesOrderItemDTOs);
				response.setRecords(Long.valueOf(orderOutput.getTotalElements()).toString());
				response.setTotal(Long.valueOf(orderOutput.getTotalPages()).toString());
				response.setPage(Integer.valueOf(orderOutput.getNumber()+1).toString());
				return response;
	}

	private List<SalesOrderItemsDTO> convertToItemDTO(List<SalesOrderItem> salesOrderItem,String salesOrderId) {
		List<SalesOrderItemsDTO> salesOrderItemrDTOs = new ArrayList<>();
		for(SalesOrderItem orderItem : salesOrderItem) {
			SalesOrderItemsDTO salesOrderItemsDTO = new SalesOrderItemsDTO();
			salesOrderItemsDTO.setOrderDetailId(orderItem.getOrderDetailId());
			salesOrderItemsDTO.setItemCode(orderItem.getItem().getItemCode());
			salesOrderItemsDTO.setItemId(orderItem.getItem().getItemId());
			salesOrderItemsDTO.setQuantity(orderItem.getQuantity());
			salesOrderItemsDTO.setRate(orderItem.getRate());
			salesOrderItemsDTO.setOrderId(salesOrderId);
		    salesOrderItemsDTO.setCopperlabel(orderItem.getItem().getCopperStrandDiameter().getCopperlabel());
		    salesOrderItemsDTO.setNumberOfCopperStrands(orderItem.getItem().getNumberOfCopperStrands());
		    
		    String od=String.valueOf(Double.valueOf(orderItem.getItem().getOuterDiameter())/100) ;
		   
		   
		    salesOrderItemsDTO.setOuterDiameter(od);
		    
		    salesOrderItemsDTO.setMainColour(orderItem.getItem().getMainColour().getColor());
		    salesOrderItemsDTO.setInnerColour(orderItem.getItem().getInnerColour().getColor());
		    salesOrderItemsDTO.setItemDescription(orderItem.getItem().getItemDescription());
		    salesOrderItemsDTO.setBundleSize(orderItem.getBundleSize());
		    salesOrderItemsDTO.setArea(orderItem.getItem().getArea().getAreaValue());
		   
		    salesOrderItemsDTO.setCompletedQty(orderItem.getCompletedQty());
		    salesOrderItemsDTO.setBalanceQty(orderItem.getBalanceQty());
		    salesOrderItemsDTO.setWoQty(orderItem.getWoQty());
		    salesOrderItemsDTO.setProductionQty(orderItem.getProductionQty());
		    salesOrderItemsDTO.setDispatchedQty(orderItem.getDispatchedQty());
		    salesOrderItemsDTO.setUnit(orderItem.getItem().getUnit().getUnits());
		    salesOrderItemsDTO.setWeight(orderItem.getWeight());
		    salesOrderItemsDTO.setPvcWeight(orderItem.getPvcWeight());
			salesOrderItemrDTOs.add(salesOrderItemsDTO);
			}
		return salesOrderItemrDTOs;
	}

	@RequestMapping(value = "/editFunc", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	StatusResponse crud(@RequestParam Long id,
			@RequestParam String oper,
			@RequestParam(required = false) String orderId,
			@RequestParam(required = false) Long itemId,
			@RequestParam(required = false) String itemCode,
			@RequestParam(required = false) Float rate,
			@RequestParam(required = false) String quantity,
			@RequestParam(required = false) Integer bundleSize,
			@RequestParam(required = false) Double balanceQty,
			@RequestParam(required = false) Double completedQty,
			@RequestParam(required = false) Double productionQty,
			@RequestParam(required = false) Double woQty,
			@RequestParam(required = false) Double dispatchedQty,
			@RequestParam(required = false) String units,
			@RequestParam(required = false) Double pvcWeight			
			) {
		Boolean result = false;
	  	boolean match = false;
	  	String decimalPattern = "((-|\\+)?[0-9]+(\\.[0-9]+)?)+";  
		match = Pattern.matches(decimalPattern, quantity);
		if(match==true){
		Double validQuantity=Double.valueOf(quantity);
		CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();;

	 	String userName = user.getFirstName()+" "+user.getLastName();
	 	    List<SalesOrder> soOrderDetailsList=null;
		    List<SalesOrderItem> soItemList=null;
		    Double inputQty=0.0;
		 	Double weight=0.0;
		SalesOrderItemsDTO soItemDTO = new SalesOrderItemsDTO();
		if(id != null)  {
			soItemDTO.setOrderDetailId(id);
		}
		
		List <Item> itemIdList=itemService.findByItemCode(itemCode);
		if(itemIdList.size()>0){
		
		Long newItemId=itemIdList.get(0).getItemId();
		Integer unitId=itemIdList.get(0).getUnit().getUnitId();
		List <SalesOrderItem> soItemsList=orderDetailsService.findById(id);
		Double totQty=0.0;
		Float existRate=(float) 0.0;
		Integer existBundle=0;
		
		if(soItemsList.size()>0){
		   totQty=soItemsList.get(0).getQuantity();
		   existRate=soItemsList.get(0).getRate();
		   existBundle=soItemsList.get(0).getBundleSize();
		   
		}

       balanceQty=validQuantity-(completedQty+productionQty+dispatchedQty);
       if(balanceQty<0)
    	   balanceQty=0.0;
		String productKey=itemIdList.get(0).getProductType().getProductKey();
		String unitsVal=itemIdList.get(0).getUnit().getUnits();
		Double noOfCuStrand=(double)itemIdList.get(0).getNumberOfCopperStrands();
		Double stranddDiameter=Double.valueOf(itemIdList.get(0).getCopperStrandDiameter().getCopperkey())/1000;
		DecimalFormat threeDForm=new DecimalFormat("0.000");
	/*	if(productKey.equalsIgnoreCase("BA") || productKey.equalsIgnoreCase("BC") || productKey.equalsIgnoreCase("CS") ||
		   productKey.equalsIgnoreCase("MS")|| productKey.equalsIgnoreCase("PA") || productKey.equalsIgnoreCase("PL") || productKey.equalsIgnoreCase("PS") ||
		   productKey.equalsIgnoreCase("PV") || productKey.equalsIgnoreCase("RA") || productKey.equalsIgnoreCase("RB") ||  productKey.equalsIgnoreCase("RI")){
	*/
		if(unitsVal.equalsIgnoreCase("Kgs") || unitsVal.equalsIgnoreCase("Kg") ){
		   weight=validQuantity;
		}
		else{
			   Double roundUpWeight=noOfCuStrand*stranddDiameter*stranddDiameter*0.6985*1.015;
			   String weightVal=threeDForm.format((Double.valueOf(roundUpWeight)/100)*validQuantity);
			   weight=Double.valueOf(weightVal);

		}
	
        
        
        
		soItemDTO.setOrderId(orderId);
		soItemDTO.setItemId(newItemId);
		soItemDTO.setItemCode(itemCode);
		soItemDTO.setRate(rate);
		soItemDTO.setBundleSize(bundleSize);
		soItemDTO.setQuantity(validQuantity);
		soItemDTO.setBalanceQty(balanceQty);
		soItemDTO.setCompletedQty(completedQty);
		soItemDTO.setProductionQty(productionQty);
		soItemDTO.setWoQty(woQty);
		soItemDTO.setDispatchedQty(dispatchedQty);
		soItemDTO.setUpdatedBy(userName);
		soItemDTO.setUnit(units);
		soItemDTO.setWeight(weight);
		soItemDTO.setPvcWeight(weight);
		SalesOrderItem itemObj = soItemDTO.getOrderDetail();
		switch (oper) {
		case "add":
			SalesOrderItem createdOrderItem = orderDetailsService.create(itemObj);
			if (createdOrderItem != null) {
				result = true;
			}
			break;
		case "edit":
			result = orderDetailsService.update(itemObj);
			break;
		case "del":
			
			break;
		}
		}
		if(result==true){
			   soOrderDetailsList=orderService.findBySalesOrderNoId(orderId);
			    soItemList=orderDetailsService.findByOrderId(orderId);
			    if(soItemList.size()>0){
			    	for(int i=0;i<soItemList.size();i++){
			    		inputQty=inputQty+soItemList.get(i).getQuantity();
			    		
			    	}
			    }
				if(soOrderDetailsList.size()>0){
			  SalesOrderUpdate soQtyUpdate=new SalesOrderUpdate();
			  SalesOrder soOrder=soQtyUpdate.updateSoOrder(orderId,soOrderDetailsList,inputQty);
			  Boolean updateSalesOrder=orderService.update(soOrder);
				}
		}}
		return new StatusResponse(result);
	}
	
	private List<OrderDTO> convertToDTO(List<SalesOrder> orders) {
		List<OrderDTO> orderDTOs = new ArrayList<>();
		for(SalesOrder order : orders) {
			OrderDTO orderDTO = new OrderDTO();
			orderDTO.setOrderId(order.getOrderId());
			if(order.getOrderRecDate()!=null)
			orderDTO.setOrderRecDate(Utility.formDateFormatter.print(order.getOrderRecDate().getTime()));
			if(order.getOrderDeliveryDate()!=null)
			orderDTO.setOrderDeliveryDate(Utility.formDateFormatter.print(order.getOrderDeliveryDate().getTime()));
			if(order.getOrderAcceptanceDate()!=null)
			orderDTO.setOrderAcceptanceDate(Utility.formDateFormatter.print(order.getOrderAcceptanceDate().getTime()));
			orderDTO.setPoDetails(order.getPoDetails());
			orderDTO.setModeOfReceipt(order.getModeOfReceipt());
			orderDTO.setMailStatus(order.getMailStatus());
			orderDTO.setLmeDetails(order.getLmeDetails());
			orderDTOs.add(orderDTO);
		}
		return orderDTOs;
	}
	
	
	
	@RequestMapping(value = "/delete/{soItemId}", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	StatusResponse deleteId(@PathVariable("soItemId") Long soItemId) {
		    List<SalesOrder> soOrderDetailsList=null;
		    List<SalesOrderItem> soItemList=null;
		    Double inputQty=0.0;
		   
		String orderId="";
		Boolean result=false;
		List<SalesOrderItem> deletedSoItem=orderDetailsService.findById(soItemId);
		if(deletedSoItem.size()>0){
			orderId=deletedSoItem.get(0).getOrder().getOrderId();
		}
		
		   result = orderDetailsService.delete(soItemId);
		   if(result==true){
			   soOrderDetailsList=orderService.findBySalesOrderNoId(orderId);
			    soItemList=orderDetailsService.findByOrderId(orderId);
			    if(soItemList.size()>0){
			    	for(int i=0;i<soItemList.size();i++){
			    		inputQty=inputQty+soItemList.get(i).getQuantity();
			    		
			    	}
			    }
				if(soOrderDetailsList.size()>0){
			  SalesOrderUpdate soQtyUpdate=new SalesOrderUpdate();
			  SalesOrder soOrder=soQtyUpdate.updateSoOrder(orderId,soOrderDetailsList,inputQty);
			  Boolean updateSalesOrder=orderService.update(soOrder);
				}

		   }
			return new StatusResponse(result);
	}	
	
	@RequestMapping(value = "/fetchRate", produces = "application/json", method = RequestMethod.GET)
	public @ResponseBody
	List<String> fetchRate(@RequestParam  String itemCode,
			               @RequestParam  String custName) {
		
		List<Customer>customerList=customerService.findByCustomerName(custName);
		List<Item>itemList=itemService.findByItemCode(itemCode);
		
		String customerCode="";
		String assortedType="";
		if(customerList.size()>0){
			customerCode=customerList.get(0).getCustomerCode();
		}
		if(itemList.size()>0){
			assortedType=itemList.get(0).getAssortedType();
		}
		List<AssortedRate> assortedRateList=assortedRateService.findByCustomerCodeAndAssortedType(customerCode,assortedType);
		List<String> rateList=new ArrayList<>();
		if(assortedRateList.size()>0){
			if(assortedRateList.get(0).getRate()!=null)
			rateList.add(assortedRateList.get(0).getRate().toString());
			else
			rateList.add("");
			if(assortedRateList.get(0).getBundleSize()!=null)
			rateList.add(assortedRateList.get(0).getBundleSize().toString());
			else
			rateList.add("");
		}

	    return rateList;
	   }	

	@RequestMapping(value = "/updateAssortedRate", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	List<String> updateAssortedRate(@RequestParam String customerName,
			               @RequestParam  String itemCode, @RequestParam(required=false)  Float rate) {
	   
		List<Customer>customerList=customerService.findByCustomerName(customerName);
		List<Item>itemList=itemService.findByItemCode(itemCode);
		List<String> rateList=new ArrayList<>();
		String customerCode="";
		String assortedType="";
		if(customerList.size()>0){
			customerCode=customerList.get(0).getCustomerCode();
		}
		if(itemList.size()>0){
			assortedType=itemList.get(0).getAssortedType();
		}
		List<AssortedRate> assortedRateList=assortedRateService.findByCustomerCodeAndAssortedType(customerCode, assortedType);
		AssortedRateDTO assorteRateDTO=new AssortedRateDTO();
		assorteRateDTO.setCustomerCode(customerCode);
		assorteRateDTO.setAssortedType(assortedType);
		assorteRateDTO.setRate(rate);
		AssortedRate assortedRate=assorteRateDTO.getAssortedRate();
		AssortedRate createdAssortedRate=null;
		Boolean updateAssortedRate=false;
			if(assortedRateList.size()>0)	{
				assortedRate.setAssortedRateId(assortedRateList.get(0).getAssortedRateId());
				assortedRate.setBundleSize(assortedRateList.get(0).getBundleSize());
				updateAssortedRate=assortedRateService.update(assortedRate);
			}
			else{
				createdAssortedRate=assortedRateService.create(assortedRate);	
			}
			if(createdAssortedRate!=null || updateAssortedRate==true ){
			List<OrderStatus> orderStatusList=orderStatusService.findAll();
			String []orderStatus={"Approved For Prodn","Pending","Created"};
			List<SalesOrderItem> salesOrderItemList=orderDetailsService.findByCustomerAssortedTypeStatusIn(customerName,assortedType,orderStatus);
		
			if(salesOrderItemList.size()>0){
				for(int i=0;i<salesOrderItemList.size();i++){
					SalesOrderItemsDTO soItemDTO=new SalesOrderItemsDTO();
					soItemDTO.setOrderDetailId(salesOrderItemList.get(i).getOrderDetailId());
					soItemDTO.setOrderId(salesOrderItemList.get(i).getOrder().getOrderId());
					soItemDTO.setItemId(salesOrderItemList.get(i).getItem().getItemId());
					soItemDTO.setQuantity(salesOrderItemList.get(i).getQuantity());
					soItemDTO.setBalanceQty(salesOrderItemList.get(i).getBalanceQty());
					soItemDTO.setBundleSize(salesOrderItemList.get(i).getBundleSize());
					soItemDTO.setRate(rate);
					soItemDTO.setWoQty(salesOrderItemList.get(i).getWoQty());
					soItemDTO.setCompletedQty(salesOrderItemList.get(i).getCompletedQty());
					soItemDTO.setItemCode(salesOrderItemList.get(i).getItemCode());
					soItemDTO.setProductionQty(salesOrderItemList.get(i).getProductionQty());
					soItemDTO.setDispatchedQty(salesOrderItemList.get(i).getDispatchedQty());
					soItemDTO.setUpdatedBy(salesOrderItemList.get(i).getUpdatedBy());
					soItemDTO.setUpdatedTime(salesOrderItemList.get(i).getUpdatedTime().toString());
					 soItemDTO.setWeight(salesOrderItemList.get(i).getWeight());
					 soItemDTO.setPvcWeight(salesOrderItemList.get(i).getPvcWeight());
					SalesOrderItem soItem=soItemDTO.getOrderDetail();
					Boolean updateSoItemRate=orderDetailsService.update(soItem);
				}
			}
			rateList.add(rate.toString());
		}
	    return rateList;
	   }	
	
	@RequestMapping(value = "/updateBundleSize", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	List<String> updateBundleSize(@RequestParam String customerName,
			               @RequestParam  String itemCode, @RequestParam(required=false)  Integer bundleSize) {
	   
		List<Customer>customerList=customerService.findByCustomerName(customerName);
		List<Item>itemList=itemService.findByItemCode(itemCode);
		List<String> rateList=new ArrayList<>();
		String customerCode="";
		String assortedType="";
		if(customerList.size()>0){
			customerCode=customerList.get(0).getCustomerCode();
		}
		if(itemList.size()>0){
			assortedType=itemList.get(0).getAssortedType();
		}
		List<AssortedRate> assortedRateList=assortedRateService.findByCustomerCodeAndAssortedType(customerCode, assortedType);
		AssortedRateDTO assorteRateDTO=new AssortedRateDTO();
		assorteRateDTO.setCustomerCode(customerCode);
		assorteRateDTO.setAssortedType(assortedType);
		assorteRateDTO.setBundleSize(bundleSize.longValue());
		
		AssortedRate assortedRate=assorteRateDTO.getAssortedRate();
		AssortedRate createdAssortedRate=null;
		Boolean updateBundleSize=false;
		if(assortedRateList.size()>0)	{
			assortedRate.setAssortedRateId(assortedRateList.get(0).getAssortedRateId());
			assortedRate.setRate(assortedRateList.get(0).getRate());
			updateBundleSize=assortedRateService.update(assortedRate);
		}
		else{
			createdAssortedRate=assortedRateService.create(assortedRate);	
		}
		String []orderStatus={"Approved For Prodn","Pending","Created"};

		if(createdAssortedRate!=null || updateBundleSize==true){
			List<SalesOrderItem> salesOrderItemList=orderDetailsService.findByCustomerAssortedTypeStatusIn(customerName,assortedType,orderStatus);
			if(salesOrderItemList.size()>0){
				for(int i=0;i<salesOrderItemList.size();i++){
					SalesOrderItemsDTO soItemDTO=new SalesOrderItemsDTO();
					soItemDTO.setOrderDetailId(salesOrderItemList.get(i).getOrderDetailId());
					soItemDTO.setOrderId(salesOrderItemList.get(i).getOrder().getOrderId());
					soItemDTO.setItemId(salesOrderItemList.get(i).getItem().getItemId());
					soItemDTO.setQuantity(salesOrderItemList.get(i).getQuantity());
					soItemDTO.setBalanceQty(salesOrderItemList.get(i).getBalanceQty());
					soItemDTO.setBundleSize(bundleSize);
					soItemDTO.setRate(salesOrderItemList.get(i).getRate());
					soItemDTO.setWoQty(salesOrderItemList.get(i).getWoQty());
					soItemDTO.setCompletedQty(salesOrderItemList.get(i).getCompletedQty());
					soItemDTO.setItemCode(salesOrderItemList.get(i).getItemCode());
					soItemDTO.setProductionQty(salesOrderItemList.get(i).getProductionQty());
					soItemDTO.setDispatchedQty(salesOrderItemList.get(i).getDispatchedQty());
					soItemDTO.setUpdatedBy(salesOrderItemList.get(i).getUpdatedBy());
					soItemDTO.setUpdatedTime(salesOrderItemList.get(i).getUpdatedTime().toString());
				    soItemDTO.setWeight(salesOrderItemList.get(i).getWeight());
				    soItemDTO.setPvcWeight(salesOrderItemList.get(i).getPvcWeight());
					SalesOrderItem soItem=soItemDTO.getOrderDetail();
					Boolean updateSoItemBundleId=orderDetailsService.update(soItem);
				}
			}
			rateList.add(bundleSize.toString());
		}
	    return rateList;
	   }	
	
}
