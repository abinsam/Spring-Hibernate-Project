package org.balajicables.salesmanager.controller;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import org.balajicables.salesmanager.common.JqgridResponse;
import org.balajicables.salesmanager.dto.PackingSlipDTO;
import org.balajicables.salesmanager.model.Customer;
import org.balajicables.salesmanager.model.DeliveryChallan;
import org.balajicables.salesmanager.model.PackingSlip;
import org.balajicables.salesmanager.model.StockOut;
import org.balajicables.salesmanager.service.CustomerService;
import org.balajicables.salesmanager.service.DeliveryChallanService;
import org.balajicables.salesmanager.service.PackingSlipService;
import org.balajicables.salesmanager.service.StockOutService;
import org.joda.time.DateTime;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

/**
*  View Delivery Challan Module.
* @author Abin Sam
*/

@Controller
@RequestMapping("/packingSlip")
public class PackingSlipController {



	@Resource
	private CustomerService customerService;
	@Resource
	private StockOutService stockOutService;
	@Resource
	private DeliveryChallanService deliveryChallanService;

	@Resource
	private PackingSlipService packingSlipService;

	 /**
	   * This method returns packlingSlip.jsp.
	   * Fetch all customers and Delivery ChallanNos based on month and year selected
	   * @param Model to set the attribute.
	   * @return packlingSlip.jsp.
	   */
	
	@RequestMapping(method = RequestMethod.GET)
	public String getItemsPage(Model model) {
		List<Customer> customers = customerService.findAll();
		DateTime dt = new DateTime();  // current DateTime
		int month =dt.getMonthOfYear(); //current month
		int year=dt.getYear();          //current year
	
		List<DeliveryChallan> deliveryChallanNos =deliveryChallanService.finddByStockOutsAndMonthYear(month,year); //method returns list of all deliverychallan numbers in the current month and year

		model.addAttribute("deliveryChallans", deliveryChallanNos);	//set delivery challan nos to model attribute
		model.addAttribute("customers", customers); //set customers to model attribute

		return "packlingSlip";

	}
	 /**
	   * This method to populate delivery challan nos based on month year selected
	   * Fetch  Delivery Challan Nos to populate on select box
	   * @param month,year
	   * @return ArrayList<String> dcNosList
	   */

	@RequestMapping(value = "/fetchDeliveryChallan", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	ArrayList<String> getWorkOrderNos(
			@RequestParam(value = "month", required = true) String month,
			@RequestParam(value = "year", required = true) String year) {
		ArrayList<String> dcNosList = new ArrayList<>();
		
        int monthValue=0;
        int yearValue=0;
        if(month!=null && month!=""){
        	monthValue=Integer.parseInt(month); //parse String month to integer
        }
       if(year!=null && year!=""){
    	   yearValue=Integer.parseInt(year); //parse String year to integer
        }
    
		List<StockOut> stockOuts =stockOutService.finddByStockOutsAndMonthYear((monthValue+1),yearValue); //method returns list of delivery challan numbers of that particular month and year
		
		for (int iterator = 0; iterator < stockOuts.size(); iterator++) {
			if(stockOuts.get(iterator).getDeliveryChallanNo()!=null && stockOuts.get(iterator).getDeliveryChallanNo()!=""){
			String dcNo = stockOuts.get(iterator).getDeliveryChallanNo();
			if (!dcNosList.contains(dcNo)) {
				dcNosList.add(dcNo);
			} // end of inner if loop
			}// end of outer if loop
		}// end of for loop

		return dcNosList;
	}
	
	 /**
	   * This method to populate delivery challan nos based on month year selected
	   * Fetch  Delivery Challan Nos to populate on select box
	   * @param month,year
	   * @return ArrayList<String> dcNosList
	   */

	@RequestMapping(value = "/getDeliveryChallanNos", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	ArrayList<String> getDeliveryChallanNos(
			@RequestParam(value = "customer", required = true) Long customerId,
			@RequestParam(value = "month", required = false) String month,
			@RequestParam(value = "year", required = false) String year) {
		    
		DateTime dt = new DateTime();  // current time
		ArrayList<String> dcNosList = new ArrayList<>();
		    int monthValue=0;
	        int yearValue=0;
	        if(month!=null && month!="")
	        	monthValue=Integer.parseInt(month)+1; //parse String month to integer
	        else
	        	monthValue =dt.getMonthOfYear();
	        
	       if(year!=null && year!="")
	    	   yearValue=Integer.parseInt(year); //parse String year to integer
	       else
	    	   yearValue =dt.getYear();
			List<DeliveryChallan> deliveryChallanNos =deliveryChallanService.finddByCustomerAndMonthYear(customerId,monthValue,yearValue); //method returns list of delivery challan numbers of that particular customer, month and year
	       for (int iterator = 0; iterator < deliveryChallanNos.size(); iterator++) {
			if(deliveryChallanNos.get(iterator).getDeliveryChallanNo()!=null && deliveryChallanNos.get(iterator).getDeliveryChallanNo()!="")
			dcNosList.add(deliveryChallanNos.get(iterator).getDeliveryChallanNo());
		    
		}// end of for loop
	  				return dcNosList;
	}
	 /**
	   * This method to populate delivery challan details 
	   * Fetch customer and populate on customer select box
	   * @param deliveryChallanNo
	   * @return ArrayList<String> dcDetails
	   */
	@RequestMapping(value = "/getDcDetails", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	ArrayList<String> getDcDetailsnNos(
			@RequestParam("deliveryChallanNo") String deliveryChallanNo, Model model) {
		ArrayList<String> dcDetails = new ArrayList<>();
		ArrayList<String> bagNoList = new ArrayList<>();
		
		List<StockOut> stockOutList=stockOutService.findByDeliveryChallanNo(deliveryChallanNo); // method returns list of delivery challan numbers from stock out table
	    List<PackingSlip> packingSlipList=packingSlipService.findByDeliveryChallanNo(deliveryChallanNo); //  method returns list of packing slip list numbers from packing slip table
	    if(packingSlipList.size()>0){
			for (int iterator = 0; iterator < packingSlipList.size(); iterator++) {
				String bagNo = packingSlipList.get(iterator).getPackingSlipNo();
				if (!bagNoList.contains(bagNo)) {
					bagNoList.add(bagNo);  //adding bag numbers to the array list called bagNoList
				} //end of if loop
			}//end of for loop
	    }//end of if loop

	    	if(stockOutList.size()>0){
		
			dcDetails.add(stockOutList.get(0).getSalesOrderItem().getOrder().getCustomer().getCustomerName()); //adding customer name to the array list called dcDetails
			dcDetails.add(stockOutList.get(0).getSalesOrderItem().getOrder().getCustomer().getCustomerId().toString()); //adding customer id to the array list called dcDetails
			
		}//end of if loop
		return dcDetails;
	}
	
	 /**
	   * This method to fetch packing slip details of selected delivery challan no
	   * Fetch  packing slip details for a particluar delivery challan number inside the grid
	   * @param deliveryChallanNo,filters,pageNumber,rowsPerPage,sortColName,sortOrder
	   * @return JqgridResponse<PackingSlipDTO> response
	   */
	
	@RequestMapping(value = "/getPackingSlipDetails", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	JqgridResponse<PackingSlipDTO> getPackingSlipDetails(
			@RequestParam("deliveryChallanNo") String deliveryChallanNo,
			@RequestParam(value = "filters", required = false) String filters,
			@RequestParam(value = "page", required = false) Integer pageNumber,
			@RequestParam(value = "rows", required = false) Integer rowsPerPage,
			@RequestParam(value = "sidx", required = false) String sortColName,
			@RequestParam(value = "sord", required = false, defaultValue = "asc") String sortOrder) {
		
		 Page<PackingSlip> packingSlips = packingSlipService.getPagedPackingSlipDetails(deliveryChallanNo, pageNumber-1, rowsPerPage,
					sortColName, sortOrder); /*method to fetch JQGRID paged records of packing slips for a particular delivery challan number*/
		JqgridResponse<PackingSlipDTO> response = new JqgridResponse<PackingSlipDTO>(); /*Intialize JQ grid response of type PackingSlipDTO*/
		/*Method to set packing slip list to PackingSlipDTO*/
		List<PackingSlipDTO> packingSlipDTOs = convertToPackingSlipDTO(packingSlips.getContent());
        response.setRows(packingSlipDTOs);
		response.setRecords(Long.valueOf(packingSlips.getTotalElements()).toString());
		response.setTotal(Long.valueOf(packingSlips.getTotalPages()).toString());
		response.setPage(Integer.valueOf(packingSlips.getNumber() + 1).toString());

		return response;
	}
	 /**
	   * This Method to set delivery challan item list to PackingSlipDTO
	   * @param List<PackingSlip> PackingSlip
	   * @return List<PackingSlipDTO> response
	   */
	List<PackingSlipDTO> convertToPackingSlipDTO(List<PackingSlip> packingSlips) {
		List<PackingSlipDTO> packingSlipDTOs = new ArrayList<>();

		for (PackingSlip packingSlip : packingSlips) {

			PackingSlipDTO packingSlipDTO = new PackingSlipDTO();

			packingSlipDTO.setPackingSlipId(packingSlip.getPackingSlipId());
			packingSlipDTO.setPackingSlipNo(packingSlip.getPackingSlipNo());	
			packingSlipDTO.setInputSize(packingSlip.getInputSize());
			packingSlipDTO.setNoOfRolls(packingSlip.getNoOfRolls());
			packingSlipDTO.setQuanityPerRoll(packingSlip.getQuanityPerRoll());
			packingSlipDTO.setTotalQuantity(packingSlip.getTotalQuantity());
			packingSlipDTO.setWeight(packingSlip.getWeight());
			packingSlipDTO.setUnitType(packingSlip.getUnitType());
			packingSlipDTO.setUnits(packingSlip.getUnits());
			packingSlipDTOs.add(packingSlipDTO);
			
			
		}
		
		return packingSlipDTOs;
	}
	
	 /**
	   * This Method to generate packingSlip report
	   * @param deliveryChallanNo
	   * @return 
	   */
	@RequestMapping(value = "/packingSlipReport", produces = "application/pdf", method = RequestMethod.GET)
	
	public void DeliveryChallanReport(@RequestParam(value = "deliveryChallanNo", required = true) String deliveryChallanNo,javax.servlet.http.HttpServletResponse response) throws IOException, InterruptedException{
	if(deliveryChallanNo!=null && deliveryChallanNo!=""){
		InputStream inputStream = getClass().getClassLoader().getResourceAsStream("/org/balajicables/salesmanager/report/PackingSlipReport.jrxml");
    	
    	 Map<String, Object> hm= new HashMap<String, Object>();
         hm.put("DC_NO", deliveryChallanNo);
         byte[] content = ReportGenerator.newReportGenerator(inputStream,hm);
	       
		response.setContentType("application/pdf");
		response.setHeader("Content-Disposition", "attachment;filename=" + "PackingSlip"+deliveryChallanNo+".pdf");
		response.setContentLength(content.length);
	    FileCopyUtils.copy(content, response.getOutputStream());
	}  
   }
	
	
}
