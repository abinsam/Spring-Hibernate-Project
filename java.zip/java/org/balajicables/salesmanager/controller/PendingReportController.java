package org.balajicables.salesmanager.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import org.balajicables.salesmanager.model.SalesOrder;
import org.balajicables.salesmanager.model.SalesOrderItem;
import org.balajicables.salesmanager.service.ItemService;
import org.balajicables.salesmanager.service.OrderDetailsService;
import org.balajicables.salesmanager.service.OrderService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
/**
* View Pending items Module.
* @author Abin Sam
*/

@Controller
@RequestMapping("/pendingSoItemReport")
public class PendingReportController {

	
	@Resource 
	private OrderService orderService;

	@Resource
	private ItemService itemService;
	

	@Resource
	private OrderDetailsService orderDetailsService;
	 /**
	   * This method returns pendingSoItemsReport.jsp.
	   * Fetch all sales order numbers,item id,customers,colors,copper diameters,product types,cable standards
	   * @param Model to set the attribute.
	   * @return pendingSoItemsReport.jsp.
	   */
	
	@RequestMapping(method = RequestMethod.GET)
	public String getSalesOrdersPage(Model model,String workOrderNo) {
		
		String[] orderStatus= {"Approved", "Approved For Prodn"};
		ArrayList<String> salesOrders = new ArrayList<>();
		Map<Long, String> unsortedMap = new HashMap<Long, String>();
		List<SalesOrderItem>soItemList=orderDetailsService.findByOrderStatusInAndBalanceQtyGreaterThan(orderStatus);
		for (int iterator = 0; iterator < soItemList.size(); iterator++) {
			String soNo = soItemList.get(iterator).getOrder().getOrderId();
			String customerName= soItemList.get(iterator).getOrder().getCustomer().getCustomerName();
         	Long customerId=soItemList.get(iterator).getOrder().getCustomer().getCustomerId();
			if (!salesOrders.contains(soNo)) {
				salesOrders.add(soNo);
			}//end of if loop
		  	if (!unsortedMap.containsValue(customerName)) {
		  		unsortedMap.put(customerId, customerName);
        		//custList.add(storeRegList.get(iterator).getSalesOrderItem().getOrder().getCustomer());
    		}//end of if loop
		}//end of for loop
		Collections.sort(salesOrders,Collections.reverseOrder());//sort sales orders in descending order
		Map<Long, String> sortedMap = sortByComparator(unsortedMap);
	
		model.addAttribute("orderIds",salesOrders);
		model.addAttribute("itemIds",itemService.getAllItems());
		model.addAttribute("customers", sortedMap);
		model.addAttribute("colours", itemService.getAllColours());
		model.addAttribute("copperDiameters", itemService.getAllCopperDiameters());
		model.addAttribute("productTypes", itemService.getAllProductTypes());
		model.addAttribute("cableStdPvcs", itemService.getAllCableStdPvcs());
			
		
		return "pendingSoItemsReport";
	}
	
	
	private Map<Long, String> sortByComparator(Map<Long, String> unsortedMap) {
		List list = new LinkedList(unsortedMap.entrySet());
	// sort list based on comparator
		Collections.sort(list, new Comparator() {
			public int compare(Object o1, Object o2) {
				return ((Comparable) ((Map.Entry) (o1)).getValue())
                                       .compareTo(((Map.Entry) (o2)).getValue());
			}
		});
 
		// put sorted list into map again
                //LinkedHashMap make sure order in which keys were inserted
		Map sortedMap = new LinkedHashMap();
		for (Iterator it = list.iterator(); it.hasNext();) {
			Map.Entry entry = (Map.Entry) it.next();
			sortedMap.put(entry.getKey(), entry.getValue());
		}
		return sortedMap;
	}
	
	
	
	
	
	 /**
	   * This method to populate sales order numbers based on customer selected
	   * Fetch sales order numbers to populate sales order number select box
	   * @param customerId
	   * @return ArrayList<String> salesOrders
	   */
	@RequestMapping(value = "/getSalesOrders", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	ArrayList<String> getSalesOrders(
			@RequestParam("customerId") Long customerId) {
		
		List<SalesOrder> salesOrdersList = orderService.findByCustomerId(customerId);//method to return list of sales order numbers based on a customer
		ArrayList<String> salesOrders = new ArrayList<>(); //new array list initialized
	

		for (int iterator = 0; iterator < salesOrdersList.size(); iterator++) {
			String soNo = salesOrdersList.get(iterator).getOrderId();

			if (!salesOrders.contains(soNo)) {
				salesOrders.add(soNo);
			}//end of if loop
			Collections.sort(salesOrders,Collections.reverseOrder());//sorts the sales order numbers in descending order
		}//end of for loop

		return salesOrders;
	}	
	
	 /**
	   * This method to populate sales order numbers based on customer and work order type selected
	   * Fetch sales order numbers to populate sales order number select box
	   * @param customerId,reportType
	   * @return ArrayList<String> salesOrders
	   */
	@RequestMapping(value = "/getPendingSalesOrders", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	ArrayList<String> getPendingSalesOrders(
			@RequestParam("customerId") Long customerId,@RequestParam("reportType") String reportType) {
		List<SalesOrderItem>soItemList=null;//Initialize salesorder item type list
		String itemType=null;//initialize itemtype variable
		//Set value of item type absed on work order process
		if(reportType.equalsIgnoreCase("Extrusion")){
			itemType="ITEM";
		}
		else if(reportType.equalsIgnoreCase("MWD")){
			 itemType="Multiwire";
		}
		else if(reportType.equalsIgnoreCase("Bunching")){
			itemType="Bunching";
		}
		else if(reportType.equalsIgnoreCase("All")){
			itemType="All";
		}
		ArrayList<String> salesOrders = new ArrayList<>(); //new array list initialized
		String[] orderStatus= {"Approved", "Approved For Prodn"};//initialize order status used as fetch parammeter of sales orders
		if(itemType!=null && customerId!=null){
			if(customerId>0){
					if(itemType.equalsIgnoreCase("All"))
					//Method to fetch pending sales order items of approved and production approved orders  irrespective of item type and based on customer
					  soItemList=orderDetailsService.findByCustomerIdAndOrderStatusInAndBalanceQtyGreaterThan(customerId,orderStatus);
					else	
					//Method to fetch pending sales order items of approved and production approved orders  based on work order process and based on customer
					soItemList=orderDetailsService.findByCustomerIdAndItemsItemTypeAndOrderStatusInAndBalanceQtyGreaterThan(customerId,itemType,orderStatus);
			}//end of if(customerId>0) loop
			else{
					if(itemType.equalsIgnoreCase("All"))
						//Method to fetch all pending sales order items of approved and production approved orders 
						soItemList=orderDetailsService.findByOrderStatusInAndBalanceQtyGreaterThan(orderStatus);
					else
						//Method to fetch all pending sales order items of approved and production approved orders  based on item type
						soItemList=orderDetailsService.findByItemsItemTypeAndOrderStatusInAndBalanceQtyGreaterThan(itemType,orderStatus);
				
			}//end of else loop
			
			for (int iterator = 0; iterator < soItemList.size(); iterator++) {
			String soNo = soItemList.get(iterator).getOrder().getOrderId();
				if (!salesOrders.contains(soNo)) {
				salesOrders.add(soNo);
			}//end of if loop
		
		}
			Collections.sort(salesOrders,Collections.reverseOrder());//sorts the sales order numbers in descending order
		}//end of for loop

		return salesOrders;
	}	
	
	
	 /**
	   * This method to fetch sales order details based on sales order no
	   * Fetch customer to populate customer select box
	   * @return ArrayList<String> customer
	   */
	@RequestMapping(value = "/getSalesOrderDetails", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	ArrayList<String> getSalesOrderDetails(@RequestParam("salesOrder") String  salesOrder) {
		ArrayList<String> salesOrderDetails = new ArrayList<>();
		List<SalesOrder> salesOrdersList = orderService.findBySalesOrderNoId(salesOrder);
		if(salesOrdersList.size()>0){
			salesOrderDetails.add(salesOrdersList.get(0).getCustomer().getCustomerId().toString());
			salesOrderDetails.add(salesOrdersList.get(0).getCustomer().getCustomerName());
		}//end of  if loop
		return salesOrderDetails;
	}


	
	 /**
	   * This method to populate sales order numbers 
	   * Fetch sales order numbers to populate sales order number select box
	   * @return ArrayList<String> salesOrders
	   */
	@RequestMapping(value = "/fetchSalesOrder", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	ArrayList<String> getWorkOrderNos() {
		ArrayList<String> salesOrders = new ArrayList<>();
		
		List<SalesOrder> salesOrdersList = orderService.findAll();//method to return a list of all sales order numbers
		
		for (int iterator = 0; iterator < salesOrdersList.size(); iterator++) {
			if(salesOrdersList.get(iterator).getOrderId()!=null && salesOrdersList.get(iterator).getOrderId()!=""){
			String salesOrderNo = salesOrdersList.get(iterator).getOrderId();
			if (!salesOrders.contains(salesOrderNo)) {
				salesOrders.add(salesOrderNo);
			}//end of inner if loop
		  }//end of outer if loop
			Collections.sort(salesOrders,Collections.reverseOrder());	//sorts the sales order numbers in descending order
		}//end of for loop

		return salesOrders;
	}

}
