package org.balajicables.salesmanager.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.balajicables.salesmanager.common.JqgridFilter;
import org.balajicables.salesmanager.common.JqgridObjectMapper;
import org.balajicables.salesmanager.common.JqgridResponse;
import org.balajicables.salesmanager.common.SalesOrderItemMapper;
import org.balajicables.salesmanager.dto.SalesOrderItemsDTO;
import org.balajicables.salesmanager.model.SalesOrderItem;
import org.balajicables.salesmanager.service.ItemService;
import org.balajicables.salesmanager.service.OrderDetailsService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
/**
* View Pending items Module.
* @author Abin Sam
*/

@Controller
@RequestMapping("/pendingStockOutReport")
public class PendingStockOutReportController {

	


	@Resource
	private ItemService itemService;
	

	@Resource
	private OrderDetailsService orderDetailsService;
	 /**
	   * This method returns pendingSoItemsReport.jsp.
	   * Fetch all sales order numbers,item id,customers,colors,copper diameters,product types,cable standards
	   * @param Model to set the attribute.
	   * @return pendingSoItemsReport.jsp.
	   */
	
	@RequestMapping(method = RequestMethod.GET)
	public String getSalesOrdersPage(Model model,String workOrderNo) {
		
		String orderStatus= "('Approved', 'Approved For Prodn')";
		ArrayList<String> salesOrders = new ArrayList<>();
		Map<Long, String> unsortedMap = new HashMap<Long, String>();
		//List<SalesOrderItem>soItemList=orderDetailsService.findByOrderStatusInAndBalanceQtyGreaterThan(orderStatus);
		String sortColName="o.orders.customer.customerName";
		String sortOrder="asc";
		List<SalesOrderItem>soItemList=orderDetailsService.findByOrderStatusInAndStockOutQtyPending(orderStatus,sortColName,sortOrder);

		
		for (int iterator = 0; iterator < soItemList.size(); iterator++) {
			String soNo = soItemList.get(iterator).getOrder().getOrderId();
			String customerName= soItemList.get(iterator).getOrder().getCustomer().getCustomerName();
         	Long customerId=soItemList.get(iterator).getOrder().getCustomer().getCustomerId();
			if(customerId!=1){
         	if (!salesOrders.contains(soNo)) {
				salesOrders.add(soNo);
			}//end of if loop
		  	if (!unsortedMap.containsValue(customerName)) {
		  		unsortedMap.put(customerId, customerName);
        		//custList.add(storeRegList.get(iterator).getSalesOrderItem().getOrder().getCustomer());
    		}//end of if loop
			}
		}//end of for loop
		Collections.sort(salesOrders,Collections.reverseOrder());//sort sales orders in descending order
		Map<Long, String> sortedMap = sortByComparator(unsortedMap);
	
		model.addAttribute("orderIds",salesOrders);
		model.addAttribute("itemIds",itemService.getAllItems());
		model.addAttribute("customers", sortedMap);
		model.addAttribute("colours", itemService.getAllColours());
		model.addAttribute("copperDiameters", itemService.getAllCopperDiameters());
		model.addAttribute("productTypes", itemService.getAllProductTypes());
		model.addAttribute("cableStdPvcs", itemService.getAllCableStdPvcs());
			
		
		return "pendingStockOutReport";
	}
	
	
	private Map<Long, String> sortByComparator(Map<Long, String> unsortedMap) {
		List list = new LinkedList(unsortedMap.entrySet());
	// sort list based on comparator
		Collections.sort(list, new Comparator() {
			public int compare(Object o1, Object o2) {
				return ((Comparable) ((Map.Entry) (o1)).getValue())
                                       .compareTo(((Map.Entry) (o2)).getValue());
			}
		});
 
		// put sorted list into map again
                //LinkedHashMap make sure order in which keys were inserted
		Map sortedMap = new LinkedHashMap();
		for (Iterator it = list.iterator(); it.hasNext();) {
			Map.Entry entry = (Map.Entry) it.next();
			sortedMap.put(entry.getKey(), entry.getValue());
		}
		return sortedMap;
	}
	
	
	/**
	   * 
	   * 
	   * 
	   * @param searchObject,search,filters,pageNumber,rowsPerPage,sortColName,sortOrder
	   * @return JqgridResponse<StockInDTO>response
	   */
	@RequestMapping(value="/records", produces="application/json" , method = RequestMethod.POST)
	public @ResponseBody
	JqgridResponse<SalesOrderItemsDTO> records(
			@RequestParam(value="searchObject", required=false) String searchObject,
		    @RequestParam("_search") Boolean search,
  		@RequestParam(value="filters", required=false) String filters,
	    	@RequestParam(value = "page", required = false) Integer pageNumber,
			@RequestParam(value = "rows", required = false) Integer rowsPerPage,
			@RequestParam(value = "sidx", required = false) String sortColName,
			@RequestParam(value = "sord", required = false, defaultValue = "asc") String sortOrder) {
		/*JQGrid column sorting*/
		if(sortColName.equalsIgnoreCase("customerName")){
			sortColName="o.orders.customer.customerName";
		}
		if(sortColName.equalsIgnoreCase("customerCode")){
			sortColName="o.orders.customer.customerCode";
		}
		if(sortColName.equalsIgnoreCase("orderAcceptanceDate")){
			sortColName="o.orders.orderAcceptanceDate";
		}
		if(sortColName.equalsIgnoreCase("orderId")){
			sortColName="o.orders.orderId";
		}
		if(sortColName.equalsIgnoreCase("itemCode")){
			sortColName="o.items.itemCode";
		}
		if(sortColName.equalsIgnoreCase("mainColour")){
			sortColName="o.items.mainColour.color";
		}
		if(sortColName.equalsIgnoreCase("innerColor")){
			sortColName="o.items.innerColour.color";
		}
		if(sortColName.equalsIgnoreCase("numberOfCopperStrands")){
			sortColName="o.items.numberOfCopperStrands";
		}
		if(sortColName.equalsIgnoreCase("unit")){
			sortColName="items.unit.units";
		}
		if(sortColName.equalsIgnoreCase("cableStdKey")){
			sortColName="o.items.cableStdPvc.cableStdKey";
		}
		if(sortColName.equalsIgnoreCase("copperkey")){
			sortColName="o.items.copperStrandDiameter.copperkey";
		}
		if(sortColName.equalsIgnoreCase("odLabel")){
			sortColName="o.items.odLabel";
		}
		if(sortColName.equalsIgnoreCase("status")){
			sortColName="o.orders.orderStatus.status";
		}
		String orderStatus= "('Approved', 'Approved For Prodn')";

		if (searchObject != null) {
	           return getFilteredRecords(searchObject, pageNumber-1,rowsPerPage,sortColName,sortOrder);
	    }//end of if (searchObject != null)  condition
		
		if(search==true){
		   return getFilteredRecords(filters, pageNumber-1, rowsPerPage,sortColName,sortOrder);
		}//end of if(search==true) condition
       else{
    	int pagenumber=pageNumber-1;
    	Integer rows=rowsPerPage;
	    List<SalesOrderItem> salesOrderItem = orderDetailsService.findByOrderStatusInAndStockOutQtyPending(orderStatus,sortColName,sortOrder);
	    List<SalesOrderItem> pagedList;
        int fromIndex = Math.min(salesOrderItem.size(), pagenumber * rows);//start index of response set to JQ Grid
        int toIndex = Math.min(salesOrderItem.size(), fromIndex + rows);//end index of response set to JQ Grid
        
        if (fromIndex == 0 && toIndex == (salesOrderItem.size() - 1)){
            pagedList = salesOrderItem;
        }//end of if loop
        else{
           pagedList = salesOrderItem.subList(fromIndex, toIndex);
        }//end of else loop
    	List<SalesOrderItemsDTO> salesOrderItemDto = SalesOrderItemMapper.map(pagedList);
        JqgridResponse<SalesOrderItemsDTO> response = new JqgridResponse<SalesOrderItemsDTO>();
        response.setRows(salesOrderItemDto);
        response.setRecords(Long.valueOf(salesOrderItem.size()).toString());
        if(salesOrderItem.size()>0)
        response.setTotal(Integer.valueOf((int)Math.ceil(Double.valueOf(salesOrderItem.size())/Double.valueOf(rows.toString()))).toString());
        else
        response.setTotal("0");
        response.setPage(Integer.valueOf(pagenumber+1).toString());
        return response;
       
	}
		
}


	private JqgridResponse<SalesOrderItemsDTO> getFilteredRecords(
			String filters, int pagenumber,Integer rows,
			String sortColName, String sortOrder) {
		 String qOrderId = null;
         Long qCustomerId = null;
        Integer qNumberOfCopperStrands=0;
        String qCopperKey = null;
        String qOdLabel = null;
        String qMainColour = null;
        String qInnerColor = null;
        String qCableStdKey = null;
        String qLayLength = null;
        String qLayType = null;
        String qProductKey = null;
        String qItemCode = null;
        String qOrderAcceptanceDate = null;
        String qOrderAcceptanceDateTo = null;
        //JQ Grid filtering parameters 
        JqgridFilter jqgridFilter = JqgridObjectMapper.map(filters);
        for (JqgridFilter.Rule rule: jqgridFilter.getRules()) {
                if (rule.getField().equals("orderId"))
                	   qOrderId = rule.getData();
                else if (rule.getField().equals("itemCode"))
             	   qItemCode = rule.getData();
                else if (rule.getField().equals("customerId")){
              	  if(rule.getData()=="" || rule.getData()==null)
              		qCustomerId =(long) 0;
              		  else
              			qCustomerId =Long.valueOf(rule.getData()) ;
                }
                
                else if (rule.getField().equals("numberOfCopperStrands")){
            	  if(rule.getData()=="" || rule.getData()==null)
            		  qNumberOfCopperStrands =0;
            		  else
            	   qNumberOfCopperStrands =Integer.parseInt(rule.getData()) ;
              }
               else if (rule.getField().equals("copperkey"))
                	qCopperKey =rule.getData() ; 
               else if (rule.getField().equals("odLabel"))
            	   qOdLabel =rule.getData() ; 
               else if (rule.getField().equals("mainColour"))
            	   qMainColour =rule.getData() ; 
               else if (rule.getField().equals("innerColor"))
             	   qInnerColor =rule.getData() ; 
               else if (rule.getField().equals("cableStdKey"))
             	   qCableStdKey =rule.getData() ; 
               else if (rule.getField().equals("layLength"))
             	   qLayLength =rule.getData() ; 
               else if (rule.getField().equals("layType"))
             	   qLayType =rule.getData() ; 
               else if (rule.getField().equals("productKey"))
             	   qProductKey =rule.getData() ;
               else if (rule.getField().equals("orderAcceptanceDate"))
            	   qOrderAcceptanceDate =rule.getData() ;
               else if (rule.getField().equals("orderAcceptanceDateTo"))
            	   qOrderAcceptanceDateTo =rule.getData() ;
                
         }//end of for loop
        String orderAccDate=null;
        if(qOrderAcceptanceDate!=null && qOrderAcceptanceDate!="")
        orderAccDate=qOrderAcceptanceDate.substring(6,10)+"-"+qOrderAcceptanceDate.substring(3,5)+"-"+qOrderAcceptanceDate.substring(0,2);
        
        String orderAccDateTo=null;
        if(qOrderAcceptanceDateTo!=null && qOrderAcceptanceDateTo!="")
        orderAccDateTo=qOrderAcceptanceDateTo.substring(6,10)+"-"+qOrderAcceptanceDateTo.substring(3,5)+"-"+qOrderAcceptanceDateTo.substring(0,2);
        List<SalesOrderItem> soItem = null;
        soItem=orderDetailsService.fetchByPendingStockOutSearch(qOrderId, qCustomerId,qNumberOfCopperStrands,
                qCopperKey,qOdLabel,qMainColour,qInnerColor,
                qCableStdKey,qLayLength,qLayType,qProductKey,qItemCode,orderAccDate,orderAccDateTo,pagenumber,rows,sortColName,sortOrder);
       
        
        List<SalesOrderItem> pagedList;
        int fromIndex = Math.min(soItem.size(), pagenumber * rows);
        int toIndex = Math.min(soItem.size(), fromIndex + rows);
        
        if (fromIndex == 0 && toIndex == (soItem.size() - 1))
        {
            pagedList = soItem;
        }
        else
        {
           pagedList = soItem.subList(fromIndex, toIndex);
        }
        /*Set paged salesorder items response to SalesOrderItemsDTO*/
        List<SalesOrderItemsDTO> soitemsDto = SalesOrderItemMapper.map(pagedList);
        /*Intialize JQ grid response of type SalesOrderItemsDTO*/
        JqgridResponse<SalesOrderItemsDTO> response = new JqgridResponse<SalesOrderItemsDTO>();
        response.setRows(soitemsDto);
        response.setRecords(Long.valueOf(soItem.size()).toString());
        if(soItem.size()>0)
        response.setTotal(Integer.valueOf((int)Math.ceil(Double.valueOf(soItem.size())/Double.valueOf(rows.toString()))).toString());
        else
        response.setTotal("0");
        response.setPage(Integer.valueOf(pagenumber+1).toString());
      return response;
   }

	
	 /**
	   * This method to populate sales order numbers based on customer and work order type selected
	   * Fetch sales order numbers to populate sales order number select box
	   * @param customerId,reportType
	   * @return ArrayList<String> salesOrders
	   */
	@RequestMapping(value = "/getStockOutPendingSalesOrders", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	ArrayList<String> getPendingSalesOrders(
			@RequestParam("customerId") Long customerId) {
		List<SalesOrderItem>soItemList=null;//Initialize salesorder item type list
		//Set value of item type absed on work order process
				ArrayList<String> salesOrders = new ArrayList<>(); //new array list initialized
		String orderStatus= "('Approved', 'Approved For Prodn')";//initialize order status used as fetch parammeter of sales orders
		if(customerId!=null && customerId>0){
				  soItemList=orderDetailsService.findByCustomerIdAndOrderStatusInAndQuantityGreaterThanDispatchedQty(customerId,orderStatus);
			for (int iterator = 0; iterator < soItemList.size(); iterator++) {
			String soNo = soItemList.get(iterator).getOrder().getOrderId();
				if (!salesOrders.contains(soNo)) {
				salesOrders.add(soNo);
			}//end of if loop
		
		}
			Collections.sort(salesOrders,Collections.reverseOrder());//sorts the sales order numbers in descending order
		}//end of for loop

		return salesOrders;
	}	
	

}
	
	
	


