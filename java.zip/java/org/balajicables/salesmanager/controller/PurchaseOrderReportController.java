package org.balajicables.salesmanager.controller;

import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;


import org.balajicables.salesmanager.common.JqgridResponse;
import org.balajicables.salesmanager.dto.PurchaseOrderDTO;
import org.balajicables.salesmanager.model.PurchaseOrder;
import org.balajicables.salesmanager.service.PurchaseOrderService;
import org.balajicables.salesmanager.utils.Utility;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
/**
*  View Delivery Challan Module.
* @author 10603708
*/
@Controller
@RequestMapping("/purchaseOrderReport")

public class PurchaseOrderReportController {
	
	@Resource
	private PurchaseOrderService purchaseOrderService;

	 /**
	   * This method returns purchaseOrderReport.jsp.
	   * @return purchaseOrderReport.jsp.
	   */
	@RequestMapping
	public String salesOrderReport(Model model) {
		return "purchaseOrderReport";
	}


	 /**
	   * This method to fetch details of selected purchase order number
	   * Fetch Purchase Order details for grid
	   * @param fromDateString,toDateString,orderStatus,filters,pageNumber,rowsPerPage,sortColName,sortOrder
	   * @return JqgridResponse<DeliveryChallanItemsDTO> response
	   */
	@RequestMapping(value="/records", produces="application/json", method=RequestMethod.POST)
	public @ResponseBody
	JqgridResponse<PurchaseOrderDTO> records(
	   		@RequestParam("_search") Boolean search,
	   		@RequestParam(value="fromDate", required=false) String fromDateString,
	   		@RequestParam(value="toDate", required=false) String toDateString,
	   		@RequestParam(value="orderStatus", required=false) String orderStatus,
    		@RequestParam(value="filters", required=false) String filters,
			@RequestParam(value = "page", required = false) Integer pageNumber,
			@RequestParam(value = "rows", required = false) Integer rowsPerPage,
			@RequestParam(value = "sidx", required = false) String sortColName,
			@RequestParam(value = "sord", required = false, defaultValue = "asc") String sortOrder) throws ParseException {
		
		if(sortColName.equalsIgnoreCase("customerCode")){
			sortColName="customer.customerCode";
		}
	  if(sortColName.equalsIgnoreCase("customerName")){
			sortColName="customer.customerName";
		}
	  if(sortColName.equalsIgnoreCase("itemDescription")){
			sortColName="salesOrderItem.items.itemDescription";
		}
	 
	  if(sortColName.equalsIgnoreCase("status")){
			sortColName="orderStatus.status";
		}
		Page<PurchaseOrder> orders = null;//initialize Page orders of type PurchaseOrder to null
		  DateFormat df = new SimpleDateFormat("dd-MM-yyyy");
	     	java.util.Date fromDate = df.parse(fromDateString);//parses string to produce fromDate in Date format
	     	java.util.Date toDate = df.parse(toDateString);//parses string to produce toDate in Date format
		
		
	    if(orderStatus==null || orderStatus==""){
	    	/*Method to return all purchase orders that are in between fromDate and toDate */
		  orders = purchaseOrderService.getPurchaseOrderReport(fromDate,toDate,pageNumber - 1,
						rowsPerPage, sortColName, sortOrder);
	    }else{
	    	 orders = purchaseOrderService.getPurchaseOrderReportWithStatus(fromDate,toDate,orderStatus,pageNumber - 1,
						rowsPerPage, sortColName, sortOrder);	
	    }//end of if else loop

	    /*Intialize JQ grid response of type PurchaseOrderDTO*/
		JqgridResponse<PurchaseOrderDTO> response = new JqgridResponse<PurchaseOrderDTO>();
		/*Method to set dpurchase orders list to PurchaseOrderDTO*/
		List<PurchaseOrderDTO> orderDTOs = convertToPurchaseOrderReportDTO(orders.getContent());
		response.setRows(orderDTOs);
		response.setRecords(Long.valueOf(orders.getTotalElements()).toString());
		response.setTotal(Long.valueOf(orders.getTotalPages()).toString());
		response.setPage(Integer.valueOf(orders.getNumber()+1).toString());

		return response;
	}

	 /**
	   * This Method to set delivery challan item list to PurchaseOrderDTO
	   * @param List<PurchaseOrder> poOrder
	   * @return List<PurchaseOrderDTO> response
	   */
	private List<PurchaseOrderDTO> convertToPurchaseOrderReportDTO(List<PurchaseOrder> orders) {
		List<PurchaseOrderDTO> purchaseOrderDTOs = new ArrayList<>();
		for(PurchaseOrder poOrder : orders) {
			PurchaseOrderDTO purchaseOrderDTO = new PurchaseOrderDTO();
			purchaseOrderDTO.setPoNo(poOrder.getPoNo());
			if (poOrder.getPoDate() != null)
				purchaseOrderDTO.setPoDate(Utility.formDateFormatter.print(poOrder.getPoDate().getTime()));
			purchaseOrderDTO.setCustomerId(poOrder.getCustomer().getCustomerId());
			purchaseOrderDTO.setCustomerName(poOrder.getCustomer().getCustomerName());
			purchaseOrderDTO.setPoStatus(poOrder.getPoStatus());
			purchaseOrderDTO.setQuantity(poOrder.getQuantity());
		    purchaseOrderDTO.setBalanceQuantity(poOrder.getBalanceQuantity());
		    purchaseOrderDTO.setCreatedBy(poOrder.getCreatedBy());
		    purchaseOrderDTO.setUpdatedBy(poOrder.getUpdatedBy());
		    if(poOrder.getCreatedTime()!=null)
		    	purchaseOrderDTO.setCreatedTime(poOrder.getCreatedTime().toString());
		    purchaseOrderDTO.setTotalPrice(poOrder.getTotalPrice());
		    purchaseOrderDTO.setExciseDuty(poOrder.getExciseDuty());
		    purchaseOrderDTO.setCstValue(poOrder.getCstValue());
		    purchaseOrderDTO.setAmount(poOrder.getAmount());
		    purchaseOrderDTO.setMailSent(poOrder.getMailSent());
			purchaseOrderDTOs.add(purchaseOrderDTO);
		}
			return purchaseOrderDTOs;
 }
	
	 /**
	   * This Method to generate Purchase Order report
	   * @param fromDate,toDate
	   * @return 
	   */
	
	@RequestMapping(value = "/purchaseOrderHistoryReport", produces = "application/pdf", method = RequestMethod.GET)

	public void SalesOrderReport(@RequestParam(value = "fromDate", required = true) String fromDate,
			                     @RequestParam(value = "toDate", required = true) String toDate,  javax.servlet.http.HttpServletResponse response) throws IOException, InterruptedException, ParseException{
		if(fromDate!=null && fromDate!="" && toDate!="" && toDate!=null){
		InputStream inputStream = getClass().getClassLoader().getResourceAsStream("/org/balajicables/salesmanager/report/PurchaseOrderHistoryReport.jrxml");
	
		 DateFormat df = new SimpleDateFormat("dd-MM-yyyy");
	     	java.util.Date fromDt = df.parse(fromDate);
	     	java.util.Date toDt = df.parse(toDate);
		
		 Map<String, Object> hm= new HashMap<String, Object>();
	     hm.put("FROM_DATE", fromDt);//add report parameter to hash map
	     hm.put("TO_DATE", toDt);//add report parameter to hash map
	     byte[] content = ReportGenerator.newReportGenerator(inputStream,hm);
	  
			response.setContentType("application/pdf");
			response.setHeader("Content-Disposition", "attachment;filename=" + "PurchaseOrderHistory"+fromDate+"-to-"+toDate+".pdf");//setting header of a PDF file
		    response.setContentLength(content.length);
	        FileCopyUtils.copy(content, response.getOutputStream());
		}//end of if loop
	}

}


