package org.balajicables.salesmanager.controller;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
import javax.annotation.Resource;
import org.balajicables.salesmanager.CustomUser;
import org.balajicables.salesmanager.common.JqgridResponse;
import org.balajicables.salesmanager.common.StatusResponse;
import org.balajicables.salesmanager.dto.PurchaseOrderDTO;
import org.balajicables.salesmanager.dto.PurchaseOrderItemDTO;
import org.balajicables.salesmanager.dto.RawMaterialStoreRegDTO;
import org.balajicables.salesmanager.model.Customer;
import org.balajicables.salesmanager.model.PurchaseOrder;
import org.balajicables.salesmanager.model.PurchaseOrderItem;
import org.balajicables.salesmanager.model.RawMaterialStoreReg;
import org.balajicables.salesmanager.service.CustomerService;
import org.balajicables.salesmanager.service.PurchaseOrderItemService;
import org.balajicables.salesmanager.service.PurchaseOrderService;
import org.balajicables.salesmanager.service.RawMaterialStoreRegService;
import org.balajicables.salesmanager.utils.Utility;
import org.joda.time.DateTime;
import org.springframework.data.domain.Page;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
/**
* Purchase Order Stock In Module.
* @author Abin Sam
*/
@Controller
@RequestMapping("/poStockIn")

public class PurchaseOrderStockInController {
	
	@Resource
	private PurchaseOrderItemService purchaseOrderItemService;
	
	@Resource
	private PurchaseOrderService purchaseOrderService;
	
	@Resource
	private CustomerService customerService;
	
	@Resource
	private RawMaterialStoreRegService rawMaterialStoreRegService;
	
	
	 /**
	   * This method returns purchaseOrderStockIn.jsp.
	   * Fetch all customers and Purchase Order Numbers of current month and year 
	   * @param Model to set the attribute.
	   * @return purchaseOrderStockIn.jsp.
	   */
	
	@RequestMapping(method = RequestMethod.GET)
    public String rawMaterialStoreRegister(Model model) {
		
		DateTime dt = new DateTime();  // current time
		int month =dt.getMonthOfYear();
		int year=dt.getYear(); 
		String poStatus="Approved";
	    /*Method to fetch list of purchase order numbers of current month year and status Approved*/
		List<PurchaseOrder> poNos =purchaseOrderService.finddByStatusMonthYear(poStatus,month,year);
		/*Method to fetch all customers and populate them in the customer select box*/
		List<Customer> customers = customerService.findAll();
		//Collections.sort(poNos,Collections.reverseOrder());
		model.addAttribute("poNos", poNos);	
		model.addAttribute("customers", customers);
		return "purchaseOrderStockIn";

    }

	 /**
	   * This Method to fetch purchase orders
	   * ArrayList<String> poNosList
	   * @param month,year
	   * @return poNosList
	   */
	@RequestMapping(value = "/fetchPurchaceOrder", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	ArrayList<String> getPurchaseOrderNos(
			@RequestParam(value = "month", required = true) String month,
			@RequestParam(value = "year", required = true) String year) {
		ArrayList<String> poNosList = new ArrayList<>();//empty array list initialized
		
        int monthValue=0;
        int yearValue=0;
        if(month!=null && month!=""){
        	monthValue=Integer.parseInt(month);//parsing string month to integer 
        }
       if(year!=null && year!=""){
    	   yearValue=Integer.parseInt(year);//parsing string year to integer
        }   
       String poStatus="Approved";
		List<PurchaseOrder> poNos =purchaseOrderService.finddByStatusMonthYear(poStatus,(monthValue+1),yearValue);//Method to get list of purchase order numbers of a particular month,year
		for (int iterator = 0; iterator < poNos.size(); iterator++) {
			if(poNos.get(iterator).getPoNo()!=null && poNos.get(iterator).getPoNo()!=""){
			String poNo = poNos.get(iterator).getPoNo();
			if (!poNosList.contains(poNo)) {
				poNosList.add(poNo);
			  }//end of inner if loop
			}//end of outer if loop
		Collections.sort(poNosList,Collections.reverseOrder());//sorts the purchase order numbers into descending order
		}//end of for loop
	
		return poNosList;
	}
	 /**
	   * This Method to fetch purchase orders
	   * ArrayList<String> poNosList
	   * @param customer,month,year
	   * @return poNosList
	   */
	@RequestMapping(value = "/getPoNos", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	ArrayList<String> getWorkOrderNos(@RequestParam(value = "customer", required = true) String customer,
			@RequestParam(value = "month", required = true) String month,
			@RequestParam(value = "year", required = true) String year) {
		   ArrayList<String> poNosList = new ArrayList<>();
		
        int monthValue=0;
        int yearValue=0;
        if(month!=null && month!=""){
        	monthValue=Integer.parseInt(month);//parsing string month to integer
        }
        if(year!=null && year!=""){
    	   yearValue=Integer.parseInt(year);//parsing string year to integer
        }
    
		String poStatus="Approved";
		/*Method to get list of purchase order numbers of a particular month,year and customer*/
		List<PurchaseOrder> purchaseOrders = purchaseOrderService.findByCustIdAndPurchaseOrderStatusAndMonthYear(customer,poStatus,(monthValue+1),yearValue);
		
		for(int iterator=0;iterator < purchaseOrders.size();iterator++ ){
			String poNo = purchaseOrders.get(iterator).getPoNo();
			poNosList.add(poNo);
			Collections.sort(poNosList,Collections.reverseOrder());//sorts the purchase order numbers into descending order
		}//end of for loop
		
		return poNosList;
	 }    
	 /**
	   * This Method is to fetch details of purchase orders
	   * ArrayList<String> poNosList
	   * @PathVariable poNo
	   * @return poItemList
	   */
	@RequestMapping(value="/getPoCustomerDetails", produces="application/json", method=RequestMethod.POST)
	public @ResponseBody
	ArrayList<String> getPoCustomerDetails(
			@RequestParam("poNo") String poNo, Model model) {
		ArrayList<String> poItemList = new ArrayList<>();//empty array list initialized 
       /*Method to get list of purchase order details*/
		List<PurchaseOrderItem> purchaseOrderItems = purchaseOrderItemService.findByPoNo(poNo);//Method to fetch list of items of a particular purchase order number 
		if(purchaseOrderItems.size()>0){
			poItemList.add(purchaseOrderItems.get(0).getPurchaseOrder().getCustomer().getCustomerName());
			poItemList.add(purchaseOrderItems.get(0).getPurchaseOrder().getCustomer().getCustomerId().toString());//customer name is fetched
		}
		
		return poItemList;
	}
	 /**
	   * This Method is to fetch details of purchase orders
	   * ArrayList<String> poNosList
	   * @PathVariable poNo
	   * @return poItemList
	   */
	@RequestMapping(value="/getPoItemDetails", produces="application/json", method=RequestMethod.POST)
	public @ResponseBody
	ArrayList<String> getPoItemDetails(
			@RequestParam("poNo") String poNo, Model model) {
		ArrayList<String> poItemList = new ArrayList<>();//empty array list initialized 
	
		List<PurchaseOrderItem> purchaseOrderItems = purchaseOrderItemService.findByPoNo(poNo);//Method to fetch list of items of a particular purchase order number 
		for(int iterator=0;iterator < purchaseOrderItems.size();iterator++ ){
			String poNoItems = purchaseOrderItems.get(iterator).getItem().getItemCode();//item code is fetched
			poItemList.add(poNoItems);
		}
				return poItemList;
	}
	 /**
	   * This Method is to fetch details of purchase order items
	   * List<PurchaseOrderItem> poItemList
	   * @RequestParam poNo,item code
	   * @return itemQtyDetailsList
	   */
	
	
	@RequestMapping(value = "/fetchItemDetails", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	List<String> fetchWoDetails(@RequestParam String poNo,@RequestParam String itemCode) {
		System.out.println("list of po items---------------------------------------");
		List<String> itemQtyDetailsList = new ArrayList<>();//empty list inilialized
		/*Method to fetch list of items of a particular Purchase order number*/
		List<PurchaseOrderItem> poItemList = purchaseOrderItemService.findByPoNoItemId(poNo, itemCode);
    	System.out.println("list of po items---------------------------------------"+poItemList);
    	itemQtyDetailsList.add(poItemList.get(0).getQuantity().toString());//fetch quantity of particular PO item
    	itemQtyDetailsList.add(poItemList.get(0).getBalanceQty().toString());//fetch balance quantity of particular PO item
    	itemQtyDetailsList.add(poItemList.get(0).getPurchaseOrder().getCustomer().getCustomerId().toString());//fetch customer of particular PO item
    		
		return itemQtyDetailsList;
	}
	
	 /**
	   * This Method is to add purchase order item to stock
	   * List<PurchaseOrderItem> poItemList
	   * @RequestParam itemIdSelect,grossWeight,tareWeight,batchNo,noOfBundles
	   * returns StatusResponse
	   */
	@RequestMapping(value = "/addToStock", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	StatusResponse getRawMaterialForStock(@RequestParam String pOrderNoSelect,
			          @RequestParam String itemIdSelect,
			          @RequestParam Double grossWeight,
			          @RequestParam Double tareWeight,
		              @RequestParam String batchNo, 
		              @RequestParam int noOfBundles) {
		
	Boolean result=false;
	DecimalFormat twoDForm=new DecimalFormat("0.00");
	if(grossWeight>=tareWeight){
		/*Method to fetch list of purchase order item list based on Purchase order number selected*/
		List<PurchaseOrderItem> poItemList = purchaseOrderItemService.findByPoNoItemId(pOrderNoSelect, itemIdSelect);
		Long poItemId = null;
		if(poItemList.size()>0)
		
		poItemId=poItemList.get(0).getPurchaseOrderItemId();
		Double netWeight =Double.valueOf(twoDForm.format(grossWeight-tareWeight));//calculating net weight which is grossWeight-tareWeight
		Double totalQuantity = Double.valueOf(twoDForm.format(noOfBundles * netWeight));//calculating total quantity which is noOfBundles * netWeight
		/*supervisor name which is first name and last name of user that has been logged in*/
		CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		String supervisor = user.getFirstName()+" "+user.getLastName();
		
		     RawMaterialStoreRegDTO rawMaterialStoreRegDTO = new RawMaterialStoreRegDTO(); 
		     rawMaterialStoreRegDTO.setStoreId(1);
		     rawMaterialStoreRegDTO.setPurchaseOrderItemId(poItemId);
		     rawMaterialStoreRegDTO.setQcStatus("Pending");
		     rawMaterialStoreRegDTO.setGrossWeight(grossWeight);
		     rawMaterialStoreRegDTO.setTareWeight(tareWeight);
		     rawMaterialStoreRegDTO.setNetWeight(netWeight);
		     rawMaterialStoreRegDTO.setSupervisorName(supervisor);
		     rawMaterialStoreRegDTO.setSendToRbd("No");
		     rawMaterialStoreRegDTO.setBatchNo(batchNo);
		     rawMaterialStoreRegDTO.setNoOfBags(noOfBundles);
		     rawMaterialStoreRegDTO.setItemCode(itemIdSelect);
		     rawMaterialStoreRegDTO.setItemDescription(poItemList.get(0).getItem().getItemDescription());
		     rawMaterialStoreRegDTO.setTotalQty(totalQuantity);
		     rawMaterialStoreRegDTO.setStockInStatus("No");
		     rawMaterialStoreRegDTO.setQcSupervisor("");
		 
		     RawMaterialStoreReg rawMaterialStoreReg=rawMaterialStoreRegDTO.getRawMaterialStoreReg();
		     RawMaterialStoreReg createdRawMaterialStoreReg=rawMaterialStoreRegService.create(rawMaterialStoreReg);
		     if(createdRawMaterialStoreReg!=null)
		    	 result=true;
		    
	}
  return new StatusResponse(result);
}	
	
	 /**
	   * This POST method is to fetch Purchase Order Item ready for stock in for JQ grid.
	   * @param purchaseOrderNo.
	   * @return JqgridResponse<RawMaterialStoreRegDTO>response  .
	   */
	
	@RequestMapping(value = "/readyForStock", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	JqgridResponse<RawMaterialStoreRegDTO> rawMaterialStockItem(
			@RequestParam(value = "searchObject", required = false) String searchObject,
			@RequestParam("_search") Boolean search,
			@RequestParam(value = "purchaseOrderNo", required = true) String purchaseOrderNo,
			@RequestParam(value = "filters", required = false) String filters,
			@RequestParam(value = "page", required = false) Integer pageNumber,
			@RequestParam(value = "rows", required = false) Integer rowsPerPage,
			@RequestParam(value = "sidx", required = false) String sortColName,
			@RequestParam(value = "sord", required = false, defaultValue = "asc") String sortOrder) {

		//JQ grid sorting column name  
		if(sortColName.equalsIgnoreCase("purchaseOrderItemId")){
			sortColName="purchaseOrderItem.purchaseOrderItemId";
		}
	
		if(sortColName.equalsIgnoreCase("customerName")){
			sortColName="purchaseOrderItem.purchaseOrder.customer.customerName";
		}
		if(sortColName.equalsIgnoreCase("customerCode")){
			sortColName="purchaseOrderItem.purchaseOrder.customer.customerCode";
		}
		if(sortColName.equalsIgnoreCase("itemId")){
			sortColName="purchaseOrderItem.item.itemId";
		}
		if(sortColName.equalsIgnoreCase("itemCode")){
			sortColName="purchaseOrderItem.item.itemCode";
		}
		if(sortColName.equalsIgnoreCase("itemDescription")){
			sortColName="purchaseOrderItem.item.itemDescription";
		}
		if(sortColName.equalsIgnoreCase("quantity")){
			sortColName="purchaseOrderItem.quantity";
		}
		if(sortColName.equalsIgnoreCase("balanceQty")){
			sortColName="purchaseOrderItem.balanceQty";
		}
				
		String sendToRbd="No";
		String stockInStatus="No";
		Page<RawMaterialStoreReg> rawMaterialForStockIn = rawMaterialStoreRegService.getRawMaterialToStock(pageNumber - 1,rowsPerPage, sortColName, sortOrder,sendToRbd,stockInStatus,purchaseOrderNo);
		JqgridResponse<RawMaterialStoreRegDTO> response = new JqgridResponse<RawMaterialStoreRegDTO>();
		List<RawMaterialStoreRegDTO> rawmatRegDTOs = convertToRawMaterialStoreRegDTO(rawMaterialForStockIn.getContent());
		response.setRows(rawmatRegDTOs);
		response.setRecords(Long.valueOf(rawMaterialForStockIn.getTotalElements()).toString());
		response.setTotal(Long.valueOf(rawMaterialForStockIn.getTotalPages()).toString());
		response.setPage(Integer.valueOf(rawMaterialForStockIn.getNumber() + 1).toString());
		return response;
		}
	 /**
	   * This  method is to set the Page result to RawMaterialStoreRegDTO object.
	   * @param List<RawMaterialStoreReg>,Purchase Order Number .
	   * @return List<RawMaterialStoreRegDTO>  .
	   */
	private List<RawMaterialStoreRegDTO> convertToRawMaterialStoreRegDTO(List<RawMaterialStoreReg> rawMaterialStoreRegisterItems) {
		List<RawMaterialStoreRegDTO> rawMatStoreRegDTOs = new ArrayList<>();
		for(RawMaterialStoreReg rawMaterialItems : rawMaterialStoreRegisterItems) {
			
			RawMaterialStoreRegDTO rawMaterialStoreRegDTO=new RawMaterialStoreRegDTO();
			rawMaterialStoreRegDTO.setRwStoreRegId(rawMaterialItems.getRwStoreRegId());
			rawMaterialStoreRegDTO.setPoNo(rawMaterialItems.getPurchaseOrderItem().getPurchaseOrder().getPoNo());
			rawMaterialStoreRegDTO.setPurchaseOrderItemId(rawMaterialItems.getPurchaseOrderItem().getPurchaseOrderItemId());
			rawMaterialStoreRegDTO.setItemCode(rawMaterialItems.getPurchaseOrderItem().getItem().getItemCode());
			rawMaterialStoreRegDTO.setItemDescription(rawMaterialItems.getPurchaseOrderItem().getItem().getItemDescription());
			rawMaterialStoreRegDTO.setBatchNo(rawMaterialItems.getBatchNo());
			rawMaterialStoreRegDTO.setQuantity(rawMaterialItems.getPurchaseOrderItem().getQuantity());
			rawMaterialStoreRegDTO.setBalanceQty(rawMaterialItems.getPurchaseOrderItem().getBalanceQty());
			rawMaterialStoreRegDTO.setGrossWeight(rawMaterialItems.getGrossWeight());
			rawMaterialStoreRegDTO.setTareWeight(rawMaterialItems.getTareWeight());
			rawMaterialStoreRegDTO.setNetWeight(rawMaterialItems.getNetWeight());
			rawMaterialStoreRegDTO.setNoOfBags(rawMaterialItems.getNoOfBags());
			rawMaterialStoreRegDTO.setTotalQty(rawMaterialItems.getTotalQty());
			rawMaterialStoreRegDTO.setQcStatus(rawMaterialItems.getQcStatus());
			rawMaterialStoreRegDTO.setSendToRbd(rawMaterialItems.getSendToRbd());
			rawMaterialStoreRegDTO.setStockOutQty(rawMaterialItems.getStockOutQty()!=null?rawMaterialItems.getStockOutQty():0.0);
			rawMaterialStoreRegDTO.setStockInStatus(rawMaterialItems.getStockInStatus());
			rawMaterialStoreRegDTO.setRemarks(rawMaterialItems.getRemarks()!=null?rawMaterialItems.getRemarks():"");
			rawMaterialStoreRegDTO.setQcSupervisor(rawMaterialItems.getQcSupervisor()!=null?rawMaterialItems.getQcSupervisor():"");
			rawMaterialStoreRegDTO.setRejectStatus(rawMaterialItems.getRejectStatus()!=null?rawMaterialItems.getRejectStatus():"");
			rawMatStoreRegDTOs.add(rawMaterialStoreRegDTO);
		}
		return rawMatStoreRegDTOs;
	}
	
	 /**
	   * Crud Functionality of Purchase Order Stock In Grid.
	   * @param Purchase Order Stock In Grid Data .
	   * @return StatusResponse  .
	   */
	
	@RequestMapping(value = "/crud", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	StatusResponse crud(
			@RequestParam Long id,
			@RequestParam String oper,
			@RequestParam(required = false) Long purchaseOrderItemId,
			@RequestParam(required = false) Double quantity,
			@RequestParam(required = false) String grossWeight,
			@RequestParam (required=false)  String tareWeight,
			@RequestParam (required=false)  String batchNo,
			@RequestParam (required=false)  String noOfBags,
			@RequestParam (required=false)  String stockInStatus
						
			) {

		Boolean result = false;
	
		String decimalPattern = "((-|\\+)?[0-9]+(\\.[0-9]+)?)+"; 
	    boolean noOfBagMatch=false;
		boolean grossWeightMatch =false;
		boolean tareWeightMatch =false;
	    Double totalQty=null;
	    Double netWeight=0.0;
	    Double newGrossWeight=0.0;
	    Double newTareWeight=0.0;
	    RawMaterialStoreReg rawMaterialStoreReg = null;
		if(oper.equalsIgnoreCase("edit")){
			grossWeightMatch = Pattern.matches(decimalPattern, grossWeight);
			tareWeightMatch = Pattern.matches(decimalPattern, tareWeight);
		
			
			
	    if (noOfBags.matches("[0-9]+")){
	    	noOfBagMatch=true;
	    }
	    
	    if(grossWeightMatch==true && tareWeightMatch==true && noOfBagMatch==true ){
		Integer newNoOfBag=Integer.parseInt(noOfBags);
	 newGrossWeight=Double.valueOf(grossWeight);
	 newTareWeight=Double.valueOf(tareWeight);
	    	
		
		if(newNoOfBag!=null && newNoOfBag>0 && newGrossWeight!=null && newTareWeight!=null && (newGrossWeight>newTareWeight)){
			CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();;

 	   String userName = user.getFirstName()+" "+user.getLastName();
  	  
 	   netWeight =newGrossWeight-newTareWeight;
 	   totalQty =newNoOfBag*netWeight;
	    	  
 		RawMaterialStoreRegDTO rawMaterialStoreRegDTO = new RawMaterialStoreRegDTO();
 		rawMaterialStoreRegDTO.setRwStoreRegId(id);
 		rawMaterialStoreRegDTO.setStoreId(1);
 		rawMaterialStoreRegDTO.setPurchaseOrderItemId(purchaseOrderItemId);
 		rawMaterialStoreRegDTO.setQcStatus("Pending");
 		rawMaterialStoreRegDTO.setQcSupervisor("");
 		rawMaterialStoreRegDTO.setGrossWeight(newGrossWeight);
 		rawMaterialStoreRegDTO.setNetWeight(netWeight);
 		rawMaterialStoreRegDTO.setTareWeight(newTareWeight);
 		rawMaterialStoreRegDTO.setSupervisorName(userName);
 		rawMaterialStoreRegDTO.setBatchNo(batchNo);
 		rawMaterialStoreRegDTO.setNoOfBags(newNoOfBag);
 		rawMaterialStoreRegDTO.setTotalQty(totalQty);
 		rawMaterialStoreRegDTO.setSendToRbd("No");
 		rawMaterialStoreRegDTO.setStockInStatus(stockInStatus);
 		rawMaterialStoreReg = rawMaterialStoreRegDTO.getRawMaterialStoreReg();

		}}}
 	     switch (oper) {
		case "edit":
			 if(grossWeightMatch==true && tareWeightMatch==true && noOfBagMatch==true && (newGrossWeight>newTareWeight)){
			result = rawMaterialStoreRegService.update(rawMaterialStoreReg);}
			break;
		
		case "del":
			Long rawMaterialIdTodelete =id;
			result = rawMaterialStoreRegService.delete(rawMaterialIdTodelete);
			break;
			
 	     }//end of switch
		    return new StatusResponse(result);
	
	    }
	 /**
	   * This POST method is to fetch Purchase Order Items to confirm stock in for JQ grid.
	   * @param purchaseOrderNo.
	   * @return JqgridResponse<RawMaterialStoreRegDTO>response  .
	   */	
@RequestMapping(value="/confirmStockIn", produces="application/json" ,method = RequestMethod.POST)
public @ResponseBody
StatusResponse confirmStockIn(
	 @RequestParam(value = "idsOfSelectedRows[]", required = false) Long[] idsSelected){
	
	/*supervisor name which is first name and last name of user that has been logged in*/
	   CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();;
	   String userName = user.getFirstName()+" "+user.getLastName();

	   Boolean updateRawMaterialStoreReg=false;
	   Boolean result=false;
	   for(int i=0;i<idsSelected.length;i++){
		   /*Method to fetch list of items selected in the grid for confirmed stock in*/
		List<RawMaterialStoreReg> rawMaterialStoreRegList=rawMaterialStoreRegService.findById(idsSelected[i]);
		if(rawMaterialStoreRegList.size()>0){
			RawMaterialStoreRegDTO rawMaterialStoreRegDTO = new RawMaterialStoreRegDTO();
	 		rawMaterialStoreRegDTO.setRwStoreRegId(rawMaterialStoreRegList.get(0).getRwStoreRegId());
	 		rawMaterialStoreRegDTO.setStoreId(rawMaterialStoreRegList.get(0).getStore().getStoreId());
	 		rawMaterialStoreRegDTO.setPurchaseOrderItemId(rawMaterialStoreRegList.get(0).getPurchaseOrderItem().getPurchaseOrderItemId());
	 		rawMaterialStoreRegDTO.setQcStatus(rawMaterialStoreRegList.get(0).getQcStatus());
	 		rawMaterialStoreRegDTO.setGrossWeight(rawMaterialStoreRegList.get(0).getGrossWeight());
	 		rawMaterialStoreRegDTO.setNetWeight(rawMaterialStoreRegList.get(0).getNetWeight());
	 		rawMaterialStoreRegDTO.setTareWeight(rawMaterialStoreRegList.get(0).getTareWeight());
	 		rawMaterialStoreRegDTO.setSupervisorName(userName);
	 		rawMaterialStoreRegDTO.setBatchNo(rawMaterialStoreRegList.get(0).getBatchNo());
	 		rawMaterialStoreRegDTO.setNoOfBags(rawMaterialStoreRegList.get(0).getNoOfBags());
	 		rawMaterialStoreRegDTO.setTotalQty(rawMaterialStoreRegList.get(0).getTotalQty());
	 		rawMaterialStoreRegDTO.setSendToRbd(rawMaterialStoreRegList.get(0).getSendToRbd());
	 		rawMaterialStoreRegDTO.setQcSupervisor(rawMaterialStoreRegList.get(0).getQcSupervisor()!=null?rawMaterialStoreRegList.get(0).getQcSupervisor():"");
			rawMaterialStoreRegDTO.setRejectStatus(rawMaterialStoreRegList.get(0).getRejectStatus()!=null?rawMaterialStoreRegList.get(0).getRejectStatus():"");
		
	 		rawMaterialStoreRegDTO.setStockInStatus("Yes");
	 		 RawMaterialStoreReg rawMaterialStoreReg = rawMaterialStoreRegDTO.getRawMaterialStoreReg();
	        updateRawMaterialStoreReg=rawMaterialStoreRegService.update(rawMaterialStoreReg);
	 	}//end of if loop
	}//end of for loop
		if(updateRawMaterialStoreReg==true){
			String stockedInStatus="Yes";
			List<RawMaterialStoreReg> rawMaterialStoreList=rawMaterialStoreRegService.findByStockedInStatus(stockedInStatus);
			Map<String, List<RawMaterialStoreReg>> map = new HashMap<String, List<RawMaterialStoreReg>>();
			for (RawMaterialStoreReg rawMaterialStoresList : rawMaterialStoreList) {
				  String key = rawMaterialStoresList.getPurchaseOrderItem().getPurchaseOrderItemId().toString();
				   if (map.get(key) == null) {
	        		     map.put(key, new ArrayList<RawMaterialStoreReg>());
	        		     
	        		    }
	        	   map.get(key).add(rawMaterialStoresList);
				
			}
			Boolean updatePoItemQty=false;
			Boolean updatePoQty =false;
			for (List<RawMaterialStoreReg> value : map.values()) {
        			Double poItemStockedInQty=0.0;
        			Double poItemOrderedQty=0.0;
        			Double poItemNewBalanceQty=0.0;
 				    Long poItemId=value.get(0).getPurchaseOrderItem().getPurchaseOrderItemId();
				   for(int m=0;m<value.size();m++){
					   poItemStockedInQty=poItemStockedInQty+value.get(m).getTotalQty();
	       		   }
				   List<PurchaseOrderItem>poItemList=purchaseOrderItemService.findByPoItemId(poItemId);
                   if(poItemList.size()>0){
                	   poItemOrderedQty=poItemList.get(0).getQuantity();
                   }
				   if(poItemOrderedQty<poItemStockedInQty){
					   poItemNewBalanceQty=0.0;  
				   }else{
					   poItemNewBalanceQty=poItemOrderedQty-poItemStockedInQty;
				   }
					PurchaseOrderItemDTO purchaseOrderItemDTO=new PurchaseOrderItemDTO();
					purchaseOrderItemDTO.setPurchaseOrderItemId(poItemList.get(0).getPurchaseOrderItemId());
					purchaseOrderItemDTO.setPoNo(poItemList.get(0).getPurchaseOrder().getPoNo());
					purchaseOrderItemDTO.setItemId(poItemList.get(0).getItem().getItemId());
					purchaseOrderItemDTO.setItemCode(poItemList.get(0).getItem().getItemCode());
					purchaseOrderItemDTO.setDescription(poItemList.get(0).getItem().getItemDescription());
					purchaseOrderItemDTO.setQuantity(poItemList.get(0).getQuantity());
					purchaseOrderItemDTO.setRate(poItemList.get(0).getRate());
					purchaseOrderItemDTO.setPrice(poItemList.get(0).getPrice());
					purchaseOrderItemDTO.setBalanceQty(Math.round(poItemNewBalanceQty*100.0)/100.0);
					if(poItemNewBalanceQty==0)
				    purchaseOrderItemDTO.setStatus(1);
				    else
				    purchaseOrderItemDTO.setStatus(poItemList.get(0).getStatus());	
				    PurchaseOrderItem poItems=purchaseOrderItemDTO.getPoItem();
					updatePoItemQty=purchaseOrderItemService.update(poItems);
			}//end of for loop
			
		if(updatePoItemQty==true){
			List<PurchaseOrder>purchaseOrders=purchaseOrderService.findAll();
			if(purchaseOrders.size()>0){
				for(int m=0;m<purchaseOrders.size();m++){
					String poNumber=purchaseOrders.get(m).getPoNo();
					List<PurchaseOrderItem>poItemsList=purchaseOrderItemService.findByPoNo(poNumber);
					Double totalPoItemOrderedQty=0.0;
					Double totalPoItemBalanceQty=0.0;
			    	if(poItemsList.size()>0){
							for(int k=0;k<poItemsList.size();k++){
							totalPoItemOrderedQty=totalPoItemOrderedQty+poItemsList.get(k).getQuantity();
							totalPoItemBalanceQty=totalPoItemBalanceQty+poItemsList.get(k).getBalanceQty();
						}
					}
					
					PurchaseOrderDTO purchaseOrderDTO=new PurchaseOrderDTO();
					purchaseOrderDTO.setPoNo(purchaseOrders.get(m).getPoNo());
					purchaseOrderDTO.setCustomerId(purchaseOrders.get(m).getCustomer().getCustomerId());
					if(purchaseOrders.get(m).getPoDate() != null)
					purchaseOrderDTO.setPoDate(Utility.formDateFormatter.print(purchaseOrders.get(m).getPoDate().getTime()));
					if(totalPoItemBalanceQty==0.0)
					  purchaseOrderDTO.setPoStatus("Closed");	
					else 
					  purchaseOrderDTO.setPoStatus(purchaseOrders.get(m).getPoStatus());
					purchaseOrderDTO.setCreatedTime(purchaseOrders.get(m).getCreatedTime().toString());
					purchaseOrderDTO.setQuantity(purchaseOrders.get(m).getQuantity());
					purchaseOrderDTO.setBalanceQuantity(Math.round(totalPoItemBalanceQty*100.0)/100.0);
					purchaseOrderDTO.setUpdatedTime(purchaseOrders.get(m).getUpdatedTime().toString());
					purchaseOrderDTO.setCreatedBy(purchaseOrders.get(m).getCreatedBy());
					purchaseOrderDTO.setUpdatedBy(purchaseOrders.get(m).getUpdatedBy());
					purchaseOrderDTO.setTotalPrice(purchaseOrders.get(m).getTotalPrice());
					purchaseOrderDTO.setExciseDuty(purchaseOrders.get(m).getExciseDuty());
					purchaseOrderDTO.setCstValue(purchaseOrders.get(m).getCstValue());
					purchaseOrderDTO.setAmount(purchaseOrders.get(m).getAmount());
					purchaseOrderDTO.setMailSent(purchaseOrders.get(m).getMailSent());
				    PurchaseOrder purchaseOrder=purchaseOrderDTO.getPurchaseOrder();
					updatePoQty = purchaseOrderService.update(purchaseOrder);
			   
				}
			}
			
			  if(updatePoQty==true)
	        	result=true;
		}		
	}
	return new StatusResponse(result);
	 }
}	 