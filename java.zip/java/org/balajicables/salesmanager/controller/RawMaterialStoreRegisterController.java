package org.balajicables.salesmanager.controller;

import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import org.balajicables.salesmanager.common.JqgridResponse;
import org.balajicables.salesmanager.dto.RawMaterialStoreRegDTO;
import org.balajicables.salesmanager.model.RawMaterialStoreReg;
import org.balajicables.salesmanager.service.RawMaterialStoreRegService;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
/**
* Raw Material Store Register Module.
* @author Abin Sam
*/
@Controller
@RequestMapping("/rawMaterailStoreRegister")
public class RawMaterialStoreRegisterController {

	@Resource
	private RawMaterialStoreRegService rawMaterialStoreRegService;
	
	 /**
	   * This method returns rawMaterialStoreRegister.jsp
	   * @return rawMaterialStoreRegister.jsp.
	   * @param Model to set the attribute.
	   */
	
	@RequestMapping(method = RequestMethod.GET)
	public String getRawMaterials(Model model) {
		
		return "rawMaterialStoreRegister";
	}
	 
	/**
	   * This method is to fetch items present in RawMaterialStoreReg
	   * returns list itemCodeList
	   */

	@RequestMapping(value = "/fetchStoreItems", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	List<String> fetchStoreItems(Model model) {
		/*Method to fetch list of items present in raw material store register*/
		List<RawMaterialStoreReg>storeRegList=rawMaterialStoreRegService.findAll();
		List<String>itemCodeList=new ArrayList<>();
		if(storeRegList.size()>0){
			for (int iterator = 0; iterator < storeRegList.size(); iterator++) {
				String itemCode= storeRegList.get(iterator).getPurchaseOrderItem().getItem().getItemCode();//fetch item code of the item
				if (!itemCodeList.contains(itemCode)) {
					itemCodeList.add(itemCode);
				}
		   }
	   }

		return itemCodeList;
	}	
	 /**
	   * This method to fetch item of raw material store register
	   * Fetch raw material store register items for grid
	   * @param search,filters,pageNumber,rowsPerPage,sortColName,sortOrder
	   * @return JqgridResponse<RawMaterialStoreRegDTO> response
	   */
	@RequestMapping(value="/records", produces="application/json",method=RequestMethod.POST)
	public @ResponseBody
	JqgridResponse<RawMaterialStoreRegDTO> records(
    		@RequestParam("_search") Boolean search,
    		@RequestParam(value="filters", required=false) String filters,
			@RequestParam(value = "page", required = false) Integer pageNumber,
			@RequestParam(value = "rows", required = false) Integer rowsPerPage,
			@RequestParam(value = "sidx", required = false) String sortColName,
			@RequestParam(value = "sord", required = false, defaultValue = "asc") String sortOrder) {
		
		//JQ grid sorting column name  
		if(sortColName.equalsIgnoreCase("purchaseOrderItemId")){
			sortColName="purchaseOrderItem.purchaseOrderItemId";
		}
	
		if(sortColName.equalsIgnoreCase("customerName")){
			sortColName="purchaseOrderItem.purchaseOrder.customer.customerName";
		}
		if(sortColName.equalsIgnoreCase("customerCode")){
			sortColName="purchaseOrderItem.purchaseOrder.customer.customerCode";
		}
		if(sortColName.equalsIgnoreCase("itemId")){
			sortColName="purchaseOrderItem.item.itemId";
		}
		if(sortColName.equalsIgnoreCase("itemCode")){
			sortColName="purchaseOrderItem.item.itemCode";
		}
		if(sortColName.equalsIgnoreCase("itemDescription")){
			sortColName="purchaseOrderItem.item.itemDescription";
		}
		
		
		
		
		
		
		
		String qcStatus[]={"Approved","Pending"};
		/*Method to fetch Method to fetch JQGRID paged records items from raw material store register whose QC status is either Approved or Pending*/
		Page<RawMaterialStoreReg> rawMaterialStoreRegs = rawMaterialStoreRegService.getPagedRawMaterialStore(pageNumber - 1,
				rowsPerPage, sortColName, sortOrder,qcStatus);
		/*Intialize JQ grid response of type RawMaterialStoreRegDTO*/
		JqgridResponse<RawMaterialStoreRegDTO> response = new JqgridResponse<RawMaterialStoreRegDTO>();
		/*Method to set raw material store register item list to RawMaterialStoreRegDTO*/
		List<RawMaterialStoreRegDTO> rawMaterialStoreRegDTOs = convertToDTO(rawMaterialStoreRegs.getContent());
		response.setRows(rawMaterialStoreRegDTOs);
		response.setRecords(Long.valueOf(rawMaterialStoreRegs.getTotalElements()).toString());
		response.setTotal(Long.valueOf(rawMaterialStoreRegs.getTotalPages()).toString());
		response.setPage(Integer.valueOf(rawMaterialStoreRegs.getNumber()+1).toString());
		return response;
	}
	 /**
	   * This Method to set raw material store register item list to RawMaterialStoreRegDTO
	   * @param List<RawMaterialStoreReg> RawMaterialStoreReg
	   * @return List<RawMaterialStoreRegDTO> response
	   */	
	private List<RawMaterialStoreRegDTO> convertToDTO(List<RawMaterialStoreReg> rawMaterialStoreRegs) {
		List<RawMaterialStoreRegDTO> rawMaterialStoreRegDTOs = new ArrayList<>();
		for(RawMaterialStoreReg rawMaterialStoreReg : rawMaterialStoreRegs) {
			
			RawMaterialStoreRegDTO rawMaterialStoreRegDTO = new RawMaterialStoreRegDTO();
			
			
			rawMaterialStoreRegDTO.setRwStoreRegId(rawMaterialStoreReg.getRwStoreRegId());
			rawMaterialStoreRegDTO.setStoreId(rawMaterialStoreReg.getStore().getStoreId());
			rawMaterialStoreRegDTO.setCustomerName(rawMaterialStoreReg.getPurchaseOrderItem().getPurchaseOrder().getCustomer().getCustomerName());
			rawMaterialStoreRegDTO.setCustomerCode(rawMaterialStoreReg.getPurchaseOrderItem().getPurchaseOrder().getCustomer().getCustomerCode());
			rawMaterialStoreRegDTO.setBalanceQty(rawMaterialStoreReg.getPurchaseOrderItem().getBalanceQty());
			rawMaterialStoreRegDTO.setBatchNo(rawMaterialStoreReg.getBatchNo());
			rawMaterialStoreRegDTO.setQcStatus(rawMaterialStoreReg.getQcStatus());
			rawMaterialStoreRegDTO.setGrossWeight(rawMaterialStoreReg.getGrossWeight());
			rawMaterialStoreRegDTO.setItemCode(rawMaterialStoreReg.getPurchaseOrderItem().getItem().getItemCode());
			rawMaterialStoreRegDTO.setItemDescription(rawMaterialStoreReg.getPurchaseOrderItem().getItem().getItemDescription());
			rawMaterialStoreRegDTO.setSendToRbd(rawMaterialStoreReg.getSendToRbd());
			rawMaterialStoreRegDTO.setTareWeight(rawMaterialStoreReg.getTareWeight());
			rawMaterialStoreRegDTO.setNetWeight(rawMaterialStoreReg.getNetWeight());
			rawMaterialStoreRegDTO.setNoOfBags(rawMaterialStoreReg.getNoOfBags());
			rawMaterialStoreRegDTO.setPoNo(rawMaterialStoreReg.getPurchaseOrderItem().getPurchaseOrder().getPoNo());
			rawMaterialStoreRegDTO.setPurchaseOrderItemId(rawMaterialStoreReg.getPurchaseOrderItem().getPurchaseOrderItemId());
			rawMaterialStoreRegDTO.setSupervisorName(rawMaterialStoreReg.getSupervisor());
			rawMaterialStoreRegDTO.setTotalQty(rawMaterialStoreReg.getTotalQty());
			rawMaterialStoreRegDTO.setStockInStatus(rawMaterialStoreReg.getStockInStatus());
			rawMaterialStoreRegDTO.setQcSupervisor(rawMaterialStoreReg.getQcSupervisor()!=null?rawMaterialStoreReg.getQcSupervisor():"");
			rawMaterialStoreRegDTO.setRejectStatus(rawMaterialStoreReg.getRejectStatus()!=null?rawMaterialStoreReg.getRejectStatus():"");
			rawMaterialStoreRegDTO.setQcStatus(rawMaterialStoreReg.getQcStatus());
			rawMaterialStoreRegDTO.setDateTime(rawMaterialStoreReg.getDateTime().toString());
			
			rawMaterialStoreRegDTOs.add(rawMaterialStoreRegDTO);
		}//end of for loop
		return rawMaterialStoreRegDTOs;
	}
	 /**
	   * This Method to fetch raw material store register item based o item selected
	   * @param itemIdSelect,search,filters,pageNumber,rowsPerPage,sortColName,sortOrder
	   * @return List<RawMaterialStoreRegDTO> response
	   */
	@RequestMapping(value = "/searchItem", produces = "application/json",method=RequestMethod.POST)
	public @ResponseBody
	JqgridResponse<RawMaterialStoreRegDTO> records(
			@RequestParam(value="itemIdSelect" ,required = true) String itemIdSelect,
			@RequestParam("_search") Boolean search,
			@RequestParam(value = "filters", required = false) String filters,
			@RequestParam(value = "page", required = false) Integer pageNumber,
			@RequestParam(value = "rows", required = false) Integer rowsPerPage,
			@RequestParam(value = "sidx", required = false) String sortColName,
			@RequestParam(value = "sord", required = false, defaultValue = "asc") String sortOrder) {
		/*Method to fetch Method to fetch JQGRID paged records items from raw material store register based on item selected*/
		Page<RawMaterialStoreReg> rawMaterialStoreRegs = rawMaterialStoreRegService.getPagedItemEntry(itemIdSelect, pageNumber - 1, rowsPerPage, sortColName, sortOrder);
		/*Intialize JQ grid response of type RawMaterialStoreRegDTO*/
		JqgridResponse<RawMaterialStoreRegDTO> response = new JqgridResponse<RawMaterialStoreRegDTO>();
		/*Method to set raw material store register item list to RawMaterialStoreRegDTO*/
		List<RawMaterialStoreRegDTO> rawMaterialStoreRegDTOs = convertToDTO(rawMaterialStoreRegs.getContent());
		response.setRows(rawMaterialStoreRegDTOs);
		response.setRecords(Long.valueOf(rawMaterialStoreRegs.getTotalElements()).toString());
		response.setTotal(Long.valueOf(rawMaterialStoreRegs.getTotalPages()).toString());
		response.setPage(Integer.valueOf(rawMaterialStoreRegs.getNumber()+1).toString());
		return response;


	}	
	 /**
	   * This Method to fetch raw material store register item 
	   * @param searchObject,search,stockDateString,itemCode,filters,pageNumber,rowsPerPage,sortColName,sortOrder
	   * @return List<RawMaterialStoreRegDTO> response
	   */
	@RequestMapping(value="/searchByDate", produces="application/json", method=RequestMethod.POST)
	public @ResponseBody
	JqgridResponse<RawMaterialStoreRegDTO> records(
			@RequestParam(value="searchObject", required=false) String searchObject,
			@RequestParam("_search") Boolean search,
			@RequestParam(value="stockDate", required=false) String stockDateString,
			@RequestParam(value="itemCode", required=false) String itemCode,
    		@RequestParam(value="filters", required=false) String filters,
			@RequestParam(value = "page", required = false) Integer pageNumber,
			@RequestParam(value = "rows", required = false) Integer rowsPerPage,
			@RequestParam(value = "sidx", required = false) String sortColName,
			@RequestParam(value = "sord", required = false, defaultValue = "asc") String sortOrder) throws ParseException {
		 Page<RawMaterialStoreReg> storeReg=null;//Initializing Paged storeReg to null
		 java.util.Date stockFromDate= null;
		 java.util.Date stockToDate= null;
		 String qcStatus[]={"Approved","Pending"};
		if(stockDateString!=null && stockDateString!=""){
			  DateFormat df = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
			  stockFromDate = df.parse(stockDateString+" 00:00:00");
			  stockToDate = df.parse(stockDateString+" 23:59:59");
		 }//end of if loop
		if(stockDateString!=null && stockDateString!="" && itemCode!=null && itemCode!=""){
			/*Method to fetch Paged records items from raw material store register based on stockFromDate,stockToDate,itemCode,qcStatus, */
     		storeReg = rawMaterialStoreRegService.getOnDatePagedRawMaterialStore(stockFromDate,stockToDate,itemCode,qcStatus,pageNumber - 1, rowsPerPage, sortColName, sortOrder);

		}else{
		  	if(stockDateString!=null && stockDateString!="")
		  		/*Method to fetch Paged records items from raw material store register based on stockFromDate,stockToDate,qcStatus, */
	     		storeReg = rawMaterialStoreRegService.getStockDatePagedQcStatusStore(stockFromDate,stockToDate,qcStatus,pageNumber - 1, rowsPerPage, sortColName, sortOrder);
		 
	     	else if(itemCode!=null && itemCode!="")
	     		/*Method to fetch Paged records items from raw material store register based on itemCode,qcStatus, */
		    	storeReg = rawMaterialStoreRegService.getItemPagedStore(qcStatus,itemCode,pageNumber - 1, rowsPerPage, sortColName, sortOrder);
		    
	     	else
	     		/*Method to fetch Paged records items from raw material store register based on qcStatus, */
		    	storeReg = rawMaterialStoreRegService.getPagedStore(qcStatus,pageNumber - 1, rowsPerPage, sortColName, sortOrder);

		}//end of outer if else loop	   
			
		JqgridResponse<RawMaterialStoreRegDTO> response = new JqgridResponse<RawMaterialStoreRegDTO>();
		List<RawMaterialStoreRegDTO> storeDTOs = convertToDTO(storeReg.getContent());
		response.setRows(storeDTOs);
		response.setRecords(Long.valueOf(storeReg.getTotalElements()).toString());
		response.setTotal(Long.valueOf(storeReg.getTotalPages()).toString());
		response.setPage(Integer.valueOf(storeReg.getNumber()+1).toString());
		
	 	return response;

	}
	
	 /**
	   * This Method to generate Raw Material Store Report 
	   * @param stockAsOnDate
	   * @return 
	   */
	@RequestMapping(value = "/stockReport", produces = "application/pdf", method = RequestMethod.GET)

	public void SalesOrderReport(@RequestParam(value = "stockDate", required = true) String stockDate,
			                      javax.servlet.http.HttpServletResponse response) throws IOException, InterruptedException, ParseException{
		if(stockDate!=null){
		InputStream inputStream = getClass().getClassLoader().getResourceAsStream("/org/balajicables/salesmanager/report/RawMaterialStoreReport.jrxml");
		
		 
		 DateFormat df = new SimpleDateFormat("dd-MM-yyyy");
	     java.util.Date stockAsOnDate = df.parse(stockDate);
	
	 
		 Map<String, Object> hm= new HashMap<String, Object>();
	     hm.put("STOCK_AS_ON_DATE", stockAsOnDate);//add report parameter to hash map
	    
	     byte[] content = ReportGenerator.newReportGenerator(inputStream,hm);
	    
		response.setContentType("application/pdf");
		response.setHeader("Content-Disposition", "attachment;filename=" + "RM Stock Report "+stockAsOnDate+".pdf");
		response.setContentLength(content.length);
	    FileCopyUtils.copy(content, response.getOutputStream());
	}
	}
}
