package org.balajicables.salesmanager.controller;

import java.util.ArrayList;
import java.util.List;
import javax.annotation.Resource;
import org.balajicables.salesmanager.CustomUser;
import org.balajicables.salesmanager.common.JqgridResponse;
import org.balajicables.salesmanager.dto.RawMaterialStoreRegDTO;
import org.balajicables.salesmanager.model.RawMaterialStoreReg;
import org.balajicables.salesmanager.service.RawMaterialStoreRegService;
import org.springframework.data.domain.Page;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
/**
* Raw Material Store Register Module.
* @author 10603708
*/
@Controller
@RequestMapping("/rawMaterialStoreRegisterForQc")
public class RawMaterialStoreRegisterForQcController {

	@Resource
	private RawMaterialStoreRegService rawMaterialStoreRegService;
	 /**
	   * This method returns rawMaterialStoreRegisterForQc.jsp
	   * @return rawMaterialStoreRegisterForQc.jsp.
	   * @param Model to set the attribute.
	   */
	
	@RequestMapping(method = RequestMethod.GET)
	public String getRawMaterials(Model model) {
	
		return "rawMaterialStoreRegisterForQc";
	}
	/**
	   * This method is to fetch items present in RawMaterialStoreReg
	   * returns list itemCodeList
	   */
	@RequestMapping(value = "/fetchStoreRawMaterialItems", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	List<String> fetchStoreRawMaterialItems(Model model) {
		String status="Pending";
		/*Method to fetch list of items present in raw material store register which are pending status*/
		List<RawMaterialStoreReg>storeRegList=rawMaterialStoreRegService.findByQcStatus(status);
		List<String>itemCodeList=new ArrayList<>();
		if(storeRegList.size()>0){
			for (int iterator = 0; iterator < storeRegList.size(); iterator++) {
				String itemCode= storeRegList.get(iterator).getPurchaseOrderItem().getItem().getItemCode();
				if (!itemCodeList.contains(itemCode)) {
					itemCodeList.add(itemCode);
				}//end of inner if loop
		   }//end of for loop
	   }//end of outer if loop

		return itemCodeList;
	}
	 /**
	   * This method to fetch item of raw material store register
	   * Fetch raw material store register items for grid
	   * @param search,filters,pageNumber,rowsPerPage,sortColName,sortOrder
	   * @return JqgridResponse<RawMaterialStoreRegDTO> response
	   */
	@RequestMapping(value="/records", produces="application/json",method=RequestMethod.POST)
	public @ResponseBody
	JqgridResponse<RawMaterialStoreRegDTO> records(
    		@RequestParam("_search") Boolean search,
    		@RequestParam(value="filters", required=false) String filters,
			@RequestParam(value = "page", required = false) Integer pageNumber,
			@RequestParam(value = "rows", required = false) Integer rowsPerPage,
			@RequestParam(value = "sidx", required = false) String sortColName,
			@RequestParam(value = "sord", required = false, defaultValue = "asc") String sortOrder) {
		/*grid column sorting*/
		  if(sortColName.equalsIgnoreCase("itemDescription")){
				sortColName="purchaseOrderItem.item.itemDescription";
			}
		  if(sortColName.equalsIgnoreCase("itemCode")){
				sortColName="purchaseOrderItem.item.itemCode";
			}
		  if(sortColName.equalsIgnoreCase("customerCode")){
				sortColName="purchaseOrderItem.purchaseOrder.customer.customerCode";
			}
		  if(sortColName.equalsIgnoreCase("customerName")){
				sortColName="purchaseOrderItem.purchaseOrder.customer.customerName";
			}
		/*Method to fetch JQGRID paged records items from raw material store register*/
		Page<RawMaterialStoreReg> rawMaterialStoreRegs = rawMaterialStoreRegService.getQCPagedStore(pageNumber - 1,
				rowsPerPage, sortColName, sortOrder);
		/*Intialize JQ grid response of type RawMaterialStoreRegDTO*/	
		JqgridResponse<RawMaterialStoreRegDTO> response = new JqgridResponse<RawMaterialStoreRegDTO>();
		/*Method to set raw material store register item list to RawMaterialStoreRegDTO*/
		List<RawMaterialStoreRegDTO> rawMaterialStoreRegDTOs = convertToDTO(rawMaterialStoreRegs.getContent());
		response.setRows(rawMaterialStoreRegDTOs);
		response.setRecords(Long.valueOf(rawMaterialStoreRegs.getTotalElements()).toString());
		response.setTotal(Long.valueOf(rawMaterialStoreRegs.getTotalPages()).toString());
		response.setPage(Integer.valueOf(rawMaterialStoreRegs.getNumber()+1).toString());
		return response;
	}
	 /**
	   * This Method to set raw material store register item list to RawMaterialStoreRegDTO
	   * @param List<RawMaterialStoreReg> RawMaterialStoreReg
	   * @return List<RawMaterialStoreRegDTO> response
	   */	
	private List<RawMaterialStoreRegDTO> convertToDTO(List<RawMaterialStoreReg> rawMaterialStoreRegs) {
		List<RawMaterialStoreRegDTO> rawMaterialStoreRegDTOs = new ArrayList<>();
		for(RawMaterialStoreReg rawMaterialStoreReg : rawMaterialStoreRegs) {
			
			RawMaterialStoreRegDTO rawMaterialStoreRegDTO = new RawMaterialStoreRegDTO();		
			
			rawMaterialStoreRegDTO.setRwStoreRegId(rawMaterialStoreReg.getRwStoreRegId());
			rawMaterialStoreRegDTO.setStoreId(rawMaterialStoreReg.getStore().getStoreId());
			rawMaterialStoreRegDTO.setCustomerName(rawMaterialStoreReg.getPurchaseOrderItem().getPurchaseOrder().getCustomer().getCustomerName());
			rawMaterialStoreRegDTO.setCustomerCode(rawMaterialStoreReg.getPurchaseOrderItem().getPurchaseOrder().getCustomer().getCustomerCode());
			rawMaterialStoreRegDTO.setBalanceQty(rawMaterialStoreReg.getPurchaseOrderItem().getBalanceQty());
			rawMaterialStoreRegDTO.setBatchNo(rawMaterialStoreReg.getBatchNo());
			rawMaterialStoreRegDTO.setQcStatus(rawMaterialStoreReg.getQcStatus());
			rawMaterialStoreRegDTO.setGrossWeight(rawMaterialStoreReg.getGrossWeight());
			rawMaterialStoreRegDTO.setItemCode(rawMaterialStoreReg.getPurchaseOrderItem().getItem().getItemCode());
			rawMaterialStoreRegDTO.setItemDescription(rawMaterialStoreReg.getPurchaseOrderItem().getItem().getItemDescription());
			rawMaterialStoreRegDTO.setSendToRbd(rawMaterialStoreReg.getSendToRbd());
			rawMaterialStoreRegDTO.setTareWeight(rawMaterialStoreReg.getTareWeight());
			rawMaterialStoreRegDTO.setNetWeight(rawMaterialStoreReg.getNetWeight());
			rawMaterialStoreRegDTO.setNoOfBags(rawMaterialStoreReg.getNoOfBags());
			rawMaterialStoreRegDTO.setPoNo(rawMaterialStoreReg.getPurchaseOrderItem().getPurchaseOrder().getPoNo());
			rawMaterialStoreRegDTO.setPurchaseOrderItemId(rawMaterialStoreReg.getPurchaseOrderItem().getPurchaseOrderItemId());
			rawMaterialStoreRegDTO.setSupervisorName(rawMaterialStoreReg.getSupervisor());
			rawMaterialStoreRegDTO.setTotalQty(rawMaterialStoreReg.getTotalQty());
			rawMaterialStoreRegDTO.setStockInStatus(rawMaterialStoreReg.getStockInStatus());
			rawMaterialStoreRegDTO.setQcSupervisor(rawMaterialStoreReg.getQcSupervisor()!=null?rawMaterialStoreReg.getQcSupervisor():"");
			rawMaterialStoreRegDTO.setRejectStatus(rawMaterialStoreReg.getRejectStatus()!=null?rawMaterialStoreReg.getRejectStatus():"");
		
			
		
			
			rawMaterialStoreRegDTOs.add(rawMaterialStoreRegDTO);
		}
		return rawMaterialStoreRegDTOs;
	}
	/**
	   * This Method to fetch raw material store register item based o item selected
	   * @param itemIdSelect,search,filters,pageNumber,rowsPerPage,sortColName,sortOrder
	   * @return List<RawMaterialStoreRegDTO> response
	   */
	@RequestMapping(value = "/searchItem", produces = "application/json",method=RequestMethod.POST)
	public @ResponseBody
	JqgridResponse<RawMaterialStoreRegDTO> records(
			@RequestParam(value="itemIdSelect" ,required = true) String itemIdSelect,
			@RequestParam("_search") Boolean search,
			@RequestParam(value = "filters", required = false) String filters,
			@RequestParam(value = "page", required = false) Integer pageNumber,
			@RequestParam(value = "rows", required = false) Integer rowsPerPage,
			@RequestParam(value = "sidx", required = false) String sortColName,
			@RequestParam(value = "sord", required = false, defaultValue = "asc") String sortOrder) {
		/*Method to fetch Method to fetch JQGRID paged records items from raw material store register based on item selected*/
		Page<RawMaterialStoreReg> rawMaterialStoreRegs = rawMaterialStoreRegService.getPagedItemEntry(itemIdSelect, pageNumber - 1, rowsPerPage, sortColName, sortOrder);
		/*Intialize JQ grid response of type RawMaterialStoreRegDTO*/
		JqgridResponse<RawMaterialStoreRegDTO> response = new JqgridResponse<RawMaterialStoreRegDTO>();
		/*Method to set raw material store register item list to RawMaterialStoreRegDTO*/
		List<RawMaterialStoreRegDTO> rawMaterialStoreRegDTOs = convertToDTO(rawMaterialStoreRegs.getContent());
		response.setRows(rawMaterialStoreRegDTOs);
		response.setRecords(Long.valueOf(rawMaterialStoreRegs.getTotalElements()).toString());
		response.setTotal(Long.valueOf(rawMaterialStoreRegs.getTotalPages()).toString());
		response.setPage(Integer.valueOf(rawMaterialStoreRegs.getNumber()+1).toString());
		return response;


	}	
	 /**
	   * This Method to fetch raw material store register item 
	   * @param remarks,status,
	   * @return List<RawMaterialStoreRegDTO> response
	   */
	@RequestMapping(value = "/approveOrRejectQC", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	List<String> approveQC(
			@RequestParam(value = "remarks", required = true) String remarks,
			@RequestParam(value = "status", required = true) String status,
			@RequestParam(value = "idsOfSelectedRows[]", required = false) Long[] idsOfSelectedRows)
		 {
		List<String> retstatus=new ArrayList<>();
		/*supervisor name which is first name and last name of user that has been logged in*/
		CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();;
	 	String supervisor = user.getFirstName()+" "+user.getLastName();
		/*Initializing list rawstoreRegList of type RawMaterialStoreReg to null*/
	 	List<RawMaterialStoreReg> rawstoreRegList = null;
		
		for (int i = 0; i < idsOfSelectedRows.length; i++) {
		
			rawstoreRegList = rawMaterialStoreRegService.findById(idsOfSelectedRows[i]);
			if(rawstoreRegList.size()>0){
				rawstoreRegList.get(0).setRemarks(remarks);
				if(status.equalsIgnoreCase("Approved")){
					rawstoreRegList.get(0).setQcStatus("Approved");
					rawstoreRegList.get(0).setRejectStatus("");
				}else if(status.equalsIgnoreCase("Scrap")){
					rawstoreRegList.get(0).setQcStatus("Rejected");
					rawstoreRegList.get(0).setRejectStatus(status);
				}else if(status.equalsIgnoreCase("Rework")){
					rawstoreRegList.get(0).setQcStatus("Rejected");
					rawstoreRegList.get(0).setRejectStatus(status);
				}//end of inner else if ladder
				
				rawstoreRegList.get(0).setQcSupervisor(supervisor);
				rawMaterialStoreRegService.update(rawstoreRegList.get(0));
				retstatus.add("updated");
			}//end of outer if loop
			
		}//end of for loop
		
	return retstatus;
		
}
}
