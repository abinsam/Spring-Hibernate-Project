package org.balajicables.salesmanager.controller;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
import javax.annotation.Resource;
import org.balajicables.salesmanager.CustomUser;
import org.balajicables.salesmanager.common.JqgridResponse;
import org.balajicables.salesmanager.common.StatusResponse;
import org.balajicables.salesmanager.dto.OrderDTO;
import org.balajicables.salesmanager.dto.RbdWorkOrderInputDTO;
import org.balajicables.salesmanager.dto.SalesOrderItemsDTO;
import org.balajicables.salesmanager.dto.StockInDTO;
import org.balajicables.salesmanager.dto.StoreRegisterDTO;
import org.balajicables.salesmanager.dto.WorkOrderOutputDTO;
import org.balajicables.salesmanager.model.Item;
import org.balajicables.salesmanager.model.OrderStatus;
import org.balajicables.salesmanager.model.ProductionWorkOrder;
import org.balajicables.salesmanager.model.RbdWorkOrderInput;
import org.balajicables.salesmanager.model.SalesOrder;
import org.balajicables.salesmanager.model.SalesOrderItem;
import org.balajicables.salesmanager.model.StockIn;
import org.balajicables.salesmanager.model.StoreRegister;
import org.balajicables.salesmanager.model.WorkOrderOutput;
import org.balajicables.salesmanager.repository.ItemRepository;
import org.balajicables.salesmanager.repository.WorkOrderItemRepository;
import org.balajicables.salesmanager.repository.WorkOrderOutputRepository;
import org.balajicables.salesmanager.service.ItemService;
import org.balajicables.salesmanager.service.OrderDetailsService;
import org.balajicables.salesmanager.service.OrderService;
import org.balajicables.salesmanager.service.OrderStatusService;
import org.balajicables.salesmanager.service.ProductionWorkOrderService;
import org.balajicables.salesmanager.service.RbdWorkOrderInputService;
import org.balajicables.salesmanager.service.StockInService;
import org.balajicables.salesmanager.service.StoreRegisterService;
import org.balajicables.salesmanager.service.WorkOrderOutputService;
import org.balajicables.salesmanager.utils.Utility;
import org.joda.time.DateTime;
import org.springframework.data.domain.Page;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
/**
* This class demonstrates RBD Work Order Process.
* @author Abin Sam
*/
@Controller
@RequestMapping("/storeRegisterForRBD")
public class RbdWorkOrderController {

	@Resource
	private ProductionWorkOrderService productionWorkOrderService;
	
	@Resource
	private OrderStatusService orderStatusService;
	
	@Resource
	private RbdWorkOrderInputService rbdWorkOrderInputService;
	
	@Resource
	private StoreRegisterService storeRegisterService;
	
	@Resource
	private WorkOrderOutputService workOrderOutputService;

	@Resource
	private ItemRepository itemRepository;

	@Resource
	private OrderService orderService;
	
	@Resource
	WorkOrderOutputRepository workOrderOutputRepository;
	
	@Resource
	private ItemService itemService;
	
	@Resource
	WorkOrderItemRepository workOrderItemRepository;
	
	@Resource
	private OrderDetailsService orderDetailsService;
	
	@Resource
	private StockInService stockInService;
	 /**
	   * This method returns rbdWorkOrder.jsp.
	   * Fetches all RBD work order numbers in current month and year
	   * @param Model to set the attribute.
	   * @return rbdWorkOrder.jsp.
	   */
	@RequestMapping(method = RequestMethod.GET)
	public String getSalesOrdersPage(Model model) {

		DateTime dt = new DateTime();  // current time
		int month =dt.getMonthOfYear(); //current month
		int year=dt.getYear(); //current year
		String rbd = "RBD";
		ArrayList<String> woNosList = new ArrayList<>();//new array list initialized
		/*Method to fetch RBD work order numbers in current month and year*/
		List<ProductionWorkOrder> productionWorkOrders = productionWorkOrderService.findByProcessType(rbd,month,year);
		/*Iterating the List to get distinct values of Work Order No*/
		for (int iterator = 0; iterator < productionWorkOrders.size(); iterator++) {
			if (productionWorkOrders.get(iterator).getWorkOrderNo() != null
					&& productionWorkOrders.get(iterator).getWorkOrderNo() != "") {
				String woNo = productionWorkOrders.get(iterator).getWorkOrderNo();
				if (!woNosList.contains(woNo)) {
					woNosList.add(woNo);
				}
			}
			Collections.sort(woNosList,Collections.reverseOrder());//sorts the list of RBD Work Order numbers into descending order
		}
		model.addAttribute("workOrderNo",woNosList);//set bunching work order nos to model attribute
	
		return "rbdWorkOrder";
	}
	 /**
	   * This POST method is to fetch details of a Work order No.
	   * @PathVariable Work Order No  .
	   * @return Work Order details List.
	   */
	@RequestMapping(value = "/fetchWoDetails/{woNo}", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	List<String> fetchWoDetails(@PathVariable("woNo") String workOrderNo) {
		/*Method to fetch list of work order numbers*/
		List<ProductionWorkOrder> workOrderList = productionWorkOrderService.findByProductionWorkOrderNo(workOrderNo);
    	List<String> workOrderDetailsList = new ArrayList<>();
		if (workOrderList.get(0).getStartDate() != null)
			workOrderDetailsList.add(Utility.formDateFormatter.print(workOrderList.get(0).getStartDate().getTime()));
		else
			workOrderDetailsList.add("");
		if (workOrderList.get(0).getEndDate() != null)
			workOrderDetailsList.add(Utility.formDateFormatter.print(workOrderList.get(0).getEndDate().getTime()));
		else
			workOrderDetailsList.add("");
		workOrderDetailsList.add(workOrderList.get(0).getMachine().getDescription());
		workOrderDetailsList.add(workOrderList.get(0).getInputWeight().toString());
		workOrderDetailsList.add(workOrderList.get(0).getBalanceWeight().toString());
		workOrderDetailsList.add(workOrderList.get(0).getOutputWeight().toString());
		workOrderDetailsList.add(workOrderList.get(0).getStatus());
		return workOrderDetailsList;
	}
	/**
	   * This POST method is to fetch item code list
	   * @PathVariable woNo .
	   * @return Item Code List.
	   */
	@RequestMapping(value = "/itemCodeList/{woNo}", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	List<String> itemCodeList(@PathVariable("woNo") String workOrderNo) {
        List<String> codeList = new ArrayList<String>();//new list initialized
		List<Item> item = itemRepository.findByProductTypeProductKey("RA");//method to fetch list of items whose product type is RA
		item.addAll( itemRepository.findByProductTypeProductKey("RB"));//method to fetch list of items whose product type is RB
		/*Iterating the List to get distinct values of Work Order No*/
	   for (int i = 0; i < item.size(); i++) {
			if (codeList.contains(item.get(i).getItemCode())) {
				
			} else {
				codeList.add(item.get(i).getInputSize());
			}
		}//end of for loop
		
		return codeList;
	}
	/**
	   * This POST method is to fetch RBD Work Order Details for JQ grid.
	   * @PathVariable workOrderNo .
	   * @param search,filters,pageNumber,rowsPerPage,sortColName,sortOrder
	   * @return JqgridResponse<RbdWorkOrderInputDTO> response  
	   */
	@RequestMapping(value = "/rbdRecords/{woNo}", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	JqgridResponse<RbdWorkOrderInputDTO> rbdRecords(
			@PathVariable("woNo") String workOrderNo,
			@RequestParam(value = "searchObject", required = false) String searchObject,
			@RequestParam("_search") Boolean search,
			@RequestParam(value = "filters", required = false) String filters,
			@RequestParam(value = "page", required = false) Integer pageNumber,
			@RequestParam(value = "rows", required = false) Integer rowsPerPage,
			@RequestParam(value = "sidx", required = false) String sortColName,
			@RequestParam(value = "sord", required = false, defaultValue = "asc") String sortOrder) {
		
		
		if(sortColName.equalsIgnoreCase("customerCode")){
			sortColName="rawMaterialStoreReg.purchaseOrderItem.purchaseOrder.customer.customerCode";
		}
		if(sortColName.equalsIgnoreCase("customerName")){
			sortColName="rawMaterialStoreReg.purchaseOrderItem.purchaseOrder.customer.customerName";
		}
		if(sortColName.equalsIgnoreCase("itemDescription")){
			sortColName="rawMaterialStoreReg.purchaseOrderItem.item.itemDescription";
		}
		if(sortColName.equalsIgnoreCase("batchNo")){
			sortColName="batchNo";
		}
		if(sortColName.equalsIgnoreCase("noOfBags")){
			sortColName="noOfBags";
		}
		if(sortColName.equalsIgnoreCase("qtyPerBag")){
			sortColName="qtyPerBag";
		}
		if(sortColName.equalsIgnoreCase("totalQty")){
			sortColName="totalQty";
		}
		if(sortColName.equalsIgnoreCase("units")){
			sortColName="rawMaterialStoreReg.purchaseOrderItem.item.unit.units";
		}
		
		/*Method to fetch Method to fetch JQGRID paged records items from RBD work order input based on the work order number*/
		Page<RbdWorkOrderInput> storeReg = rbdWorkOrderInputService
				.getRbdPagedList(workOrderNo, pageNumber - 1, rowsPerPage,
						sortColName, sortOrder);
		/*Intialize JQ grid response of type RbdWorkOrderInputDTO*/
		JqgridResponse<RbdWorkOrderInputDTO> response = new JqgridResponse<RbdWorkOrderInputDTO>();
		/*Method to set RBD work order input item list to RbdWorkOrderInputDTO*/
		List<RbdWorkOrderInputDTO> storeDTOs = convertToRbdDTO(storeReg.getContent());
		response.setRows(storeDTOs);
		response.setRecords(Long.valueOf(storeReg.getTotalElements()).toString());
		response.setTotal(Long.valueOf(storeReg.getTotalPages()).toString());
		response.setPage(Integer.valueOf(storeReg.getNumber() + 1).toString());
		return response;
	}
	 /**
	   * This Method to set RBD work order input item list to RbdWorkOrderInputDTO
	   * @param List<RbdWorkOrderInput> RbdWorkOrderInput
	   * @return List<RbdWorkOrderInputDTO> response
	   */
	private List<RbdWorkOrderInputDTO> convertToRbdDTO(
			List<RbdWorkOrderInput> rbdContents) {
		List<RbdWorkOrderInputDTO> rbdInputDTOs = new ArrayList<>();
		for (RbdWorkOrderInput rbdContent : rbdContents) {
			RbdWorkOrderInputDTO rbdDTO = new RbdWorkOrderInputDTO();
			rbdDTO.setRwStoreRegId(rbdContent.getRawMaterialStoreReg().getRwStoreRegId());
			rbdDTO.setCustomerCode(rbdContent.getRawMaterialStoreReg().getPurchaseOrderItem().getPurchaseOrder().getCustomer().getCustomerCode());
			rbdDTO.setCustomerName((rbdContent.getRawMaterialStoreReg().getPurchaseOrderItem().getPurchaseOrder().getCustomer().getCustomerName()));
			rbdDTO.setItemCode(rbdContent.getRawMaterialStoreReg().getPurchaseOrderItem().getItem().getItemCode());
			rbdDTO.setItemDescription((rbdContent.getRawMaterialStoreReg().getPurchaseOrderItem().getItem().getItemDescription()));
			rbdDTO.setGrossWeight(rbdContent.getGrossWeight());
			rbdDTO.setTareWeight(rbdContent.getTareWeight());
			rbdDTO.setNetWeight(rbdContent.getNetWeight());
			rbdDTO.setBatchNo(rbdContent.getRawMaterialStoreReg().getBatchNo());
			rbdDTO.setNoOfBags(rbdContent.getRawMaterialStoreReg().getNoOfBags());
			
			rbdDTO.setTotalQty(rbdContent.getRawMaterialStoreReg().getTotalQty());
			rbdDTO.setUnits(rbdContent.getRawMaterialStoreReg().getPurchaseOrderItem().getItem().getUnit().getUnits());
			rbdInputDTOs.add(rbdDTO);
		}
		return rbdInputDTOs;

	}
	 /**
	   * This Method to save the work order ouptput for the RBD input
	   * @param workOrderNo,itemIdSelect,tareWeight,grossWeight,netLength
	   * @return outputWeightList
	   */
	@RequestMapping(value = "/saveWorkOrderOutput", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	List<Double> crud(@RequestParam String workOrderNo,
			          @RequestParam String itemIdSelect,
			          @RequestParam Double tareWeight,
		              @RequestParam Double grossWeight, 
		              @RequestParam Double netLength) {
		/*Method to fetch latest batch number for a particular work order number*/
		List<WorkOrderOutput> existBatchNoList = workOrderOutputService.fetchLatestBatchNo(workOrderNo);
		String existBatchNo = "";
		String newBatchNo;
		if (existBatchNoList.size() > 0)//checking if the existBatchNoList size is more 0
			existBatchNo = existBatchNoList.get(0).getBatchNo();
		if (!existBatchNo.isEmpty()) {
			String existBatchNoWo = existBatchNo.substring(0, 8);
			String existBatchNoId = existBatchNo.substring(9, 11);
			int serialNoInt = 0;
			serialNoInt = Integer.parseInt(existBatchNoId) + 1;
			if (serialNoInt < 10) {
				newBatchNo = existBatchNoWo + "/0"+ String.valueOf(serialNoInt);
			} else {
				newBatchNo = existBatchNoWo + "/" + String.valueOf(serialNoInt);
			}
		}// end of if loop of checking existing sales no
		else {
			newBatchNo = workOrderNo + "/" + "01";
		}
		/*supervisor name which is first name and last name of user that has been logged in*/
		CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		String supervisor = user.getFirstName()+" "+user.getLastName();
		
		Boolean pdnWorkOrderOutputResult = false;
		
		Double inputWeight = Double.valueOf(0);
		Double outputWeight = Double.valueOf(0);
		Double balanceWeight = Double.valueOf(0);
		List<Double> outputWeightList = new ArrayList<Double>();
		String itemCode =null;

		List<Item> itemList=itemService.findByItemInputSize(itemIdSelect);
		if(itemList.size()>0){
			itemCode=itemList.get(0).getItemCode();
		}
		Long orderDetailIds=null;
		if(itemCode!=null){
		Double netWeight = grossWeight - tareWeight;
		if(!itemCode.equalsIgnoreCase("")){
 			orderDetailIds= createSalesOrderForRbd(supervisor,workOrderNo, itemCode, netWeight, 0);
 		}
		Double newNetLength=0.0;
		Long netL=netLength.longValue();
		newNetLength=Double.valueOf(netL);
		if(orderDetailIds!=null){
		List<WorkOrderOutput>workOrderOutputList=workOrderOutputService.findByBatchNo(newBatchNo);
		if(workOrderOutputList.size()==0){
		WorkOrderOutputDTO workOrderOutputDTO = new WorkOrderOutputDTO();
		workOrderOutputDTO.setWorkOrderNo(workOrderNo);
		workOrderOutputDTO.setBatchNo(newBatchNo);
		workOrderOutputDTO.setSize(itemIdSelect);
		workOrderOutputDTO.setNetLength(Math.round(newNetLength*100.0)/100.0);
		workOrderOutputDTO.setNetWeight(Math.round(netWeight*100.0)/100.0);
		workOrderOutputDTO.setGrossWeight(Math.round(grossWeight*100.0)/100.0);
		workOrderOutputDTO.setTareWeight(Math.round(tareWeight*100.0)/100.0);
		workOrderOutputDTO.setUpdatedBy(supervisor);
		workOrderOutputDTO.setStockIn("No");
		workOrderOutputDTO.setOrderDetailId(orderDetailIds);
		WorkOrderOutput workOrderOutput = workOrderOutputDTO.getWorkOrderOutput();
		WorkOrderOutput createdWoOutput = workOrderOutputService.create(workOrderOutput);
		
		List<ProductionWorkOrder> pdnWoList = productionWorkOrderService.findByProductionWorkOrderNo(workOrderNo);
		if (pdnWoList.size() > 0) {
			inputWeight = inputWeight + pdnWoList.get(0).getInputWeight();
			outputWeight = outputWeight + pdnWoList.get(0).getOutputWeight();
		}

		if (createdWoOutput != null) {
			outputWeight = outputWeight + netWeight;
			balanceWeight = inputWeight - outputWeight;
			pdnWorkOrderOutputResult = productionWorkOrderService.updateWorkOrderWeight(workOrderNo, inputWeight,outputWeight, balanceWeight);
			if(pdnWorkOrderOutputResult==true)
			outputWeightList.add(outputWeight);
		}//end of if (createdWoOutput != null)
	  }//end of if(orderDetailIds!=null)
	}//end of if(itemCode!=null)
		}
		return outputWeightList;
	}
	
	 /**
	   * This Method to create sales order for RBD
	   */
   private Long createSalesOrderForRbd(String userName, String woNo, String itemCode, Double quantity,Integer bundleSize) {
	
	Boolean updateSoItem=false;
	/*Method to fetch list of orders whose order status is Approved*/
	  List<OrderStatus>statusList=orderStatusService.findByStatus("Approved");
	  /*Method to fetch list of items*/ 
	  List<Item>itemList=itemService.findByItemCode(itemCode);
	   Long itemId=null;
	   if(itemList.size()>0)
		   itemId=itemList.get(0).getItemId();
	   SalesOrderItem soitem=new SalesOrderItem();
	    Long customerId=(long) 1;	
 		Boolean soResult = false;
 		
 		OrderDTO orderDTO = new OrderDTO();
		orderDTO.setOrderId("BS000001");
		orderDTO.setCreatedTime("1980-01-01 00:00:00.0");
		orderDTO.setCustomerId(customerId);
		orderDTO.setOrderStatusId(statusList.get(0).getOrderStatusId());
		orderDTO.setCreatedBy(userName);
		orderDTO.setUpdatedBy(userName);
		orderDTO.setInputQuantity(0.0);
		orderDTO.setMailStatus("No");
		orderDTO.setLmeDetails("");
		java.util.Date date= new java.util.Date();
		orderDTO.setUpdatedTime(new Timestamp(date.getTime()).toString());
  
		SalesOrder order = orderDTO.getOrder();
		try{
			SalesOrder createdOrder = orderService.create(order);
			if(createdOrder!=null)
			soResult = true;
		}catch(Exception e){
			orderService.update(order);
			soResult = true;
		}// end of try catch block
		Long soItemId=null;
	if(soResult==true){
	List<SalesOrderItem> soItemList=orderDetailsService.findByOrderIdItemId("BS000001", itemCode);
	if(soItemList.size()>0){
		Double totalQty=soItemList.get(0).getQuantity()+quantity;
		
		SalesOrderItemsDTO soitemsDTO = new SalesOrderItemsDTO();
		soitemsDTO.setOrderDetailId(soItemList.get(0).getOrderDetailId());
		soitemsDTO.setOrderId(soItemList.get(0).getOrder().getOrderId());
		soitemsDTO.setItemId(soItemList.get(0).getItem().getItemId());
		soitemsDTO.setQuantity(totalQty);
		soitemsDTO.setBalanceQty(0.0);
		soitemsDTO.setProductionQty(soItemList.get(0).getProductionQty());
		soitemsDTO.setCompletedQty(soItemList.get(0).getCompletedQty());
		soitemsDTO.setDispatchedQty(soItemList.get(0).getDispatchedQty());
		soitemsDTO.setWoQty(quantity);
		soitemsDTO.setWeight(totalQty);
		soitemsDTO.setBundleSize(soItemList.get(0).getBundleSize());
		soitemsDTO.setRate(soItemList.get(0).getRate());
		soitemsDTO.setItemCode(soItemList.get(0).getItemCode());
		soitemsDTO.setUpdatedBy(soItemList.get(0).getUpdatedBy());
		soitemsDTO.setUpdatedTime(soItemList.get(0).getUpdatedTime().toString());
		soitemsDTO.setPvcWeight(totalQty);
		soitem=soitemsDTO.getOrderDetail();
		updateSoItem=orderDetailsService.update(soitem);
		if(updateSoItem==true)
			soItemId=soItemList.get(0).getOrderDetailId();
	}//end of if(soItemList.size()>0)
	else if (itemId!=null){
		SalesOrderItemsDTO soitemDTO = new SalesOrderItemsDTO();
		soitemDTO.setOrderId("BS000001");
		soitemDTO.setItemId(itemId);
		soitemDTO.setQuantity(quantity);
		soitemDTO.setBalanceQty(0.0);
		soitemDTO.setProductionQty(0.0);
		soitemDTO.setCompletedQty(0.0);
		soitemDTO.setDispatchedQty(0.0);
		soitemDTO.setWoQty(quantity);
		soitemDTO.setWeight(quantity);
		soitemDTO.setBundleSize(1);
		soitemDTO.setRate((float)0);
		soitemDTO.setItemCode(itemCode);
		soitemDTO.setUpdatedBy(userName);
		soitemDTO.setPvcWeight(quantity);
		SalesOrderItem soItemObj=soitemDTO.getOrderDetail();
		soitem=orderDetailsService.create(soItemObj);
		if(soitem!=null)
			soItemId=soitem.getOrderDetailId();

	}//end of else if
}//end of if(soResult==true)
	
     return soItemId;
	}
   
      /**
	   * This Method to fetch RBD output records based on a work order number
	   * @PathVariable workOrderNo
	   * @RequestParam searchObject,search,filters,pageNumber,rowsPerPage,sortColName,sortOrder
	   */
	
	@RequestMapping(value = "/rbdOutputRecords/{woNo}", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	JqgridResponse<WorkOrderOutputDTO> rbdOutputRecords(
			@PathVariable("woNo") String workOrderNo,
			@RequestParam(value = "searchObject", required = false) String searchObject,
			@RequestParam("_search") Boolean search,
			@RequestParam(value = "filters", required = false) String filters,
			@RequestParam(value = "page", required = false) Integer pageNumber,
			@RequestParam(value = "rows", required = false) Integer rowsPerPage,
			@RequestParam(value = "sidx", required = false) String sortColName,
			@RequestParam(value = "sord", required = false, defaultValue = "asc") String sortOrder) {
		/*Method to fetch Method to fetch JQGRID paged records items from RBD work order output based on the work order number*/
		Page<WorkOrderOutput> woOutput = workOrderOutputService.getWoOutputPagedList(workOrderNo, pageNumber - 1, rowsPerPage,
						sortColName, sortOrder);
		/*Intialize JQ grid response of type WorkOrderOutputDTO*/
		JqgridResponse<WorkOrderOutputDTO> response = new JqgridResponse<WorkOrderOutputDTO>();
		/*Method to set RBD work order output item list to WorkOrderOutputDTO*/
		List<WorkOrderOutputDTO> woOutputDTOs = convertToWoOutputDTO(woOutput.getContent());
		response.setRows(woOutputDTOs);
		response.setRecords(Long.valueOf(woOutput.getTotalElements()).toString());
		response.setTotal(Long.valueOf(woOutput.getTotalPages()).toString());
		response.setPage(Integer.valueOf(woOutput.getNumber() + 1).toString());
		return response;

	}
	 /**
	   * This Method to set RBD work order input item list to WorkOrderOutputDTO
	   * @param List<WorkOrderOutput> WorkOrderOutput
	   * @return List<WorkOrderOutputDTO> response
	   */
	private List<WorkOrderOutputDTO> convertToWoOutputDTO(
			List<WorkOrderOutput> woOutputs) {
		List<WorkOrderOutputDTO> woOuputDTOs = new ArrayList<>();
		for (WorkOrderOutput woOutput : woOutputs) {
			WorkOrderOutputDTO woOuputDTO = new WorkOrderOutputDTO();
			woOuputDTO.setWoOutPutId(woOutput.getWoOutPutId());
			woOuputDTO.setWorkOrderNo(woOutput.getProductionWorkOrder().getWorkOrderNo());
			woOuputDTO.setSize(woOutput.getSize());
			woOuputDTO.setBatchNo(woOutput.getBatchNo());
			woOuputDTO.setGrossWeight(woOutput.getGrossWeight());
			woOuputDTO.setNetLength(woOutput.getNetLength());
			woOuputDTO.setNetWeight(woOutput.getNetWeight());
			woOuputDTO.setTareWeight(woOutput.getTareWeight());
			woOuputDTO.setStockIn(woOutput.getStockIn());
			woOuputDTO.setOrderDetailId(woOutput.getSalesOrderItem().getOrderDetailId());
			woOuputDTOs.add(woOuputDTO);
		}
		return woOuputDTOs;
	}
	/**
	   * Crud Functionality of RBD work order output Grid.
	   * @param RBD work order output Grid Data .
	   * @return StatusResponse  .
	   */
	@RequestMapping(value = "/crud", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	StatusResponse crud(@RequestParam Long id, @RequestParam String oper,
			@RequestParam(required = false) Long orderDetailId,
			@RequestParam(required = true) String workOrderNo,
			@RequestParam(required = true) String batchNo,
			@RequestParam(required = false) String netLength,
			@RequestParam(required = false) String tareWeight,
			@RequestParam(required = false) String grossWeight,
			@RequestParam(required = false) String size,
			@RequestParam(required = false) String stockIn) {
		
		String decimalPattern = "((-|\\+)?[0-9]+(\\.[0-9]+)?)+";  
		boolean netLengthMatch = Pattern.matches(decimalPattern, netLength);
		boolean grossWeightMatch = Pattern.matches(decimalPattern, grossWeight);
		boolean tareWeightMatch = Pattern.matches(decimalPattern, tareWeight);
		
		Boolean workOrderWeightUpdate = false;
		if(netLengthMatch==true && grossWeightMatch==true && tareWeightMatch==true){
		  Double newNetLength=Double.valueOf(netLength);
		  Double newGrossWeight=Double.valueOf(grossWeight);
		  Double newTareWeight=Double.valueOf(tareWeight);
			
		Double netWeight=newGrossWeight-newTareWeight;
		Boolean result = false;
		Double inputWeight = Double.valueOf(0);
		Double outputWeight = Double.valueOf(0);
		Double balanceWeight = Double.valueOf(0);
		if(newGrossWeight>=newTareWeight){
		WorkOrderOutputDTO workOrderOutputDTO = new WorkOrderOutputDTO();
		workOrderOutputDTO.setWoOutPutId(id);
		workOrderOutputDTO.setWorkOrderNo(workOrderNo);
		workOrderOutputDTO.setNetLength(Math.round(newNetLength*100.0)/100.0);
		workOrderOutputDTO.setNetWeight(Math.round(netWeight*100.0)/100.0);
		workOrderOutputDTO.setGrossWeight(Math.round(newGrossWeight*100.0)/100.0);
		workOrderOutputDTO.setTareWeight(Math.round(newTareWeight*100.0)/100.0);
		workOrderOutputDTO.setBatchNo(batchNo);
		workOrderOutputDTO.setSize(size);
		workOrderOutputDTO.setStockIn(stockIn);
		workOrderOutputDTO.setOrderDetailId(orderDetailId);
		/*supervisor name which is first name and last name of user that has been logged in*/
		CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();;
		String supervisor = user.getFirstName()+" "+user.getLastName();

		workOrderOutputDTO.setUpdatedBy(supervisor);
		/*Method to fetch work order output list based on batch number*/
		List<WorkOrderOutput> woOutputList = workOrderOutputService.findByBatchNo(batchNo);
		if (woOutputList.size() > 0) {
			List<ProductionWorkOrder> pdnWoList = productionWorkOrderService.findByProductionWorkOrderNo(workOrderNo);
			if (pdnWoList.size() > 0) {
				inputWeight = pdnWoList.get(0).getInputWeight();
				outputWeight = outputWeight	+ (pdnWoList.get(0).getOutputWeight())-(woOutputList.get(0).getNetWeight()) + netWeight;
				balanceWeight = inputWeight - outputWeight;
			}
		}
		WorkOrderOutput woOutput = workOrderOutputDTO.getWorkOrderOutput();
		switch (oper) {
		case "add":
			WorkOrderOutput createdWoOutput = workOrderOutputService
					.create(woOutput);
			if (createdWoOutput != null) {
				result = true;
			}
			break;
		case "edit":
			result = workOrderOutputService.update(woOutput);
			break;
		case "del":
			
			break;

		}//end of switch cases
		if (result == true) {
			workOrderWeightUpdate = productionWorkOrderService.updateWorkOrderWeight(workOrderNo, inputWeight,outputWeight, balanceWeight);
		   }//end of if (result == true)
    	}
	}
		return new StatusResponse(workOrderWeightUpdate);
	
	}
	
	/**
	   * Method to delete a row from RBD work order output grid
	   * @PathVariable id
	   * @return outputWeightList  .
	   */
	@RequestMapping(value = "/delRow/{id}", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	List<Double> deleteRow(@PathVariable("id") Long id) {

		List<Double> outputWeightList = new ArrayList<>();
		Boolean workOrderWeightUpdate = false;
		Boolean deleteWoOutputResult = false;
		Double inputWeight = Double.valueOf(0);
		Double outputWeight = Double.valueOf(0);
		Double balanceWeight = Double.valueOf(0);
		Double newSoItemQty=0.0;
		Double woOutputQty=0.0;
		Double pdnWoOutputWeight = Double.valueOf(0);
		Double woOutputputWeight = Double.valueOf(0);
		String workOrderNo = "";
        Long soItemId=null;
        Boolean updateSoItemResult=false;
		List<ProductionWorkOrder> pdnWoList = null;
		/*Method to fetch workorder output list based on id*/
		List<WorkOrderOutput> workOrderoutputList = workOrderOutputService.findByWoOutputId(id);
		if (workOrderoutputList.size() > 0) {
			soItemId= workOrderoutputList.get(0).getSalesOrderItem().getOrderDetailId();
			workOrderNo = workOrderoutputList.get(0).getProductionWorkOrder().getWorkOrderNo();
			pdnWoList = productionWorkOrderService.findByProductionWorkOrderNo(workOrderNo);
			String units= workOrderoutputList.get(0).getSalesOrderItem().getItem().getUnit().getUnits();
			if(units.equalsIgnoreCase("Kgs") || units.equalsIgnoreCase("Kg") ){
			   woOutputQty=workOrderoutputList.get(0).getNetWeight();
			}else{
				woOutputQty=workOrderoutputList.get(0).getNetLength();
			}
		}//end of if (workOrderoutputList.size() > 0)
		
		if(soItemId!=null){
			List<SalesOrderItem>soItemList=orderDetailsService.findById(soItemId);
			if(soItemList.size()>0){
				if(soItemList.get(0).getQuantity()>woOutputQty){
					newSoItemQty=soItemList.get(0).getQuantity()-woOutputQty;
				}//end of if(soItemList.get(0).getQuantity()>woOutputQty)
				SalesOrderItemsDTO soitemsDTO = new SalesOrderItemsDTO();
				soitemsDTO.setOrderDetailId(soItemList.get(0).getOrderDetailId());
				soitemsDTO.setOrderId(soItemList.get(0).getOrder().getOrderId());
				soitemsDTO.setItemId(soItemList.get(0).getItem().getItemId());
				soitemsDTO.setQuantity(newSoItemQty);
				soitemsDTO.setBalanceQty(0.0);
				soitemsDTO.setProductionQty(newSoItemQty);
				soitemsDTO.setCompletedQty(soItemList.get(0).getCompletedQty());
				soitemsDTO.setDispatchedQty(soItemList.get(0).getDispatchedQty());
				soitemsDTO.setWoQty(soItemList.get(0).getWoQty());
				soitemsDTO.setWeight(newSoItemQty);
				soitemsDTO.setBundleSize(soItemList.get(0).getBundleSize());
				soitemsDTO.setRate(soItemList.get(0).getRate());
				soitemsDTO.setItemCode(soItemList.get(0).getItemCode());
				soitemsDTO.setUpdatedBy(soItemList.get(0).getUpdatedBy());
				soitemsDTO.setUpdatedTime(soItemList.get(0).getUpdatedTime().toString());
				soitemsDTO.setPvcWeight(newSoItemQty);
				SalesOrderItem soitem=soitemsDTO.getOrderDetail();
				updateSoItemResult=orderDetailsService.update(soitem);
			}//end of if(soItemList.size()>0)
		}//end of if(soItemId!=null)
		pdnWoOutputWeight = pdnWoList.get(0).getOutputWeight();
		woOutputputWeight = workOrderoutputList.get(0).getNetWeight();
		inputWeight = inputWeight + pdnWoList.get(0).getInputWeight();

		deleteWoOutputResult = workOrderOutputService.delete(id);
		if (deleteWoOutputResult == true && updateSoItemResult==true) {
			outputWeight = outputWeight + pdnWoOutputWeight - woOutputputWeight;
			balanceWeight = inputWeight - outputWeight;
			workOrderWeightUpdate = productionWorkOrderService.updateWorkOrderWeight(workOrderNo, inputWeight,outputWeight, balanceWeight);
			if(workOrderWeightUpdate==true)
			outputWeightList.add(outputWeight);
		}//end of if (deleteWoOutputResult == true && updateSoItemResult==true)
		return outputWeightList;
	}

	/**
	   * Method to submit RBD work order output
	   * @PathVariable workOrderNo
	   * @return woStatus
	   */
	@RequestMapping(value = "/submitWorkOrder/{workOrderNo}", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	List<String> submitWorkOrder(
			@PathVariable("workOrderNo") String workOrderNo) {
		Boolean workOrderStatusUpdate = false;
		List<String> woStatus=new ArrayList<String>();
		String workOrderStatus="Submitted";
		workOrderStatusUpdate = productionWorkOrderService.updateWorkOrderStatus(workOrderNo,workOrderStatus);
		List<ProductionWorkOrder> woOrderList=productionWorkOrderService.findByProductionWorkOrderNo(workOrderNo);
		if(woOrderList.size()>0 && workOrderStatusUpdate==true ){
			woStatus.add(woOrderList.get(0).getStatus());
		}//end of if(woOrderList.size()>0 && workOrderStatusUpdate==true )
		return woStatus;
	}

	/**
	   * Method to stock in RBD work order
	   * @PathVariable id
	   * @return StatusResponse
	   */
	@RequestMapping(value = "/stockIn/{id}", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	StatusResponse stockIn(@PathVariable("id") Long id) {
		Long orderDetailId=null;
		Double stockQty=0.0;
		Boolean updateWorkOrderOutput=false;
		Boolean updateSoItemResult=false;
		Boolean updateStockInResult=false;
		Boolean updateStoreReg=false;
		StockIn createdStockIn=null;
		StoreRegister createdStoreReg=null;
		/*supervisor name which is first name and last name of user that has been logged in*/
		CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();;
		String supervisor = user.getFirstName()+" "+user.getLastName();
		
		String bundleNo=null;
		List<WorkOrderOutput> workOrderOutput = workOrderOutputRepository.findByWoOutPutId(id);
		if(workOrderOutput.size()>0){
		if(workOrderOutput.get(0).getGrossWeight()>workOrderOutput.get(0).getTareWeight()){
			orderDetailId=workOrderOutput.get(0).getSalesOrderItem().getOrderDetailId();
			String units=workOrderOutput.get(0).getSalesOrderItem().getItem().getUnit().getUnits();
			if(units.equalsIgnoreCase("Kgs") || units.equalsIgnoreCase("Kg") ){
			    stockQty=workOrderOutput.get(0).getNetWeight();
			}else{
				stockQty=workOrderOutput.get(0).getNetLength();
			}
			
			WorkOrderOutputDTO workOrderOutputDTO= new WorkOrderOutputDTO();
			workOrderOutputDTO.setWoOutPutId(workOrderOutput.get(0).getWoOutPutId());
			workOrderOutputDTO.setWorkOrderNo(workOrderOutput.get(0).getProductionWorkOrder().getWorkOrderNo());
			workOrderOutputDTO.setNetLength(workOrderOutput.get(0).getNetLength());
			workOrderOutputDTO.setGrossWeight(workOrderOutput.get(0).getGrossWeight());
			workOrderOutputDTO.setTareWeight(workOrderOutput.get(0).getTareWeight());
			workOrderOutputDTO.setNetWeight(workOrderOutput.get(0).getNetWeight());
			workOrderOutputDTO.setNoOfStrands(workOrderOutput.get(0).getNoOfStrands());
			workOrderOutputDTO.setSize(workOrderOutput.get(0).getSize());
			workOrderOutputDTO.setSpeed(workOrderOutput.get(0).getSpeed());
			workOrderOutputDTO.setAnnealingPercent(workOrderOutput.get(0).getAnnealingPercent());
			workOrderOutputDTO.setOuterDiameter(workOrderOutput.get(0).getOuterDiameter());
			workOrderOutputDTO.setCreatedTime(workOrderOutput.get(0).getCreatedTime().toString());
			workOrderOutputDTO.setUpdatedBy(workOrderOutput.get(0).getUpdatedBy());
			workOrderOutputDTO.setBatchNo(workOrderOutput.get(0).getBatchNo());
			workOrderOutputDTO.setStockIn("Yes");
			if(workOrderOutput.get(0).getBatchNo()!=null)
				bundleNo = "0"+workOrderOutput.get(0).getBatchNo().substring(9);
			
			
			workOrderOutputDTO.setOrderDetailId(workOrderOutput.get(0).getSalesOrderItem().getOrderDetailId());
			WorkOrderOutput woOutput=workOrderOutputDTO.getWorkOrderOutput();
			updateWorkOrderOutput=workOrderOutputService.update(woOutput);
		 
		if(orderDetailId!=null && updateWorkOrderOutput==true){
			List<SalesOrderItem>soItemList=orderDetailsService.findById(orderDetailId);
			if(soItemList.size()>0){
				SalesOrderItemsDTO soitemsDTO = new SalesOrderItemsDTO();
				soitemsDTO.setOrderDetailId(soItemList.get(0).getOrderDetailId());
				soitemsDTO.setOrderId(soItemList.get(0).getOrder().getOrderId());
				soitemsDTO.setItemId(soItemList.get(0).getItem().getItemId());
				soitemsDTO.setQuantity(soItemList.get(0).getQuantity());
				soitemsDTO.setBalanceQty(0.0);
				soitemsDTO.setProductionQty(soItemList.get(0).getProductionQty());
				soitemsDTO.setCompletedQty(soItemList.get(0).getCompletedQty()+stockQty);
				soitemsDTO.setDispatchedQty(soItemList.get(0).getDispatchedQty());
				soitemsDTO.setWoQty(soItemList.get(0).getWoQty());
				soitemsDTO.setWeight(soItemList.get(0).getWeight());
				soitemsDTO.setBundleSize(soItemList.get(0).getBundleSize());
				soitemsDTO.setRate(soItemList.get(0).getRate());
				soitemsDTO.setItemCode(soItemList.get(0).getItemCode());
				soitemsDTO.setUpdatedBy(soItemList.get(0).getUpdatedBy());
				soitemsDTO.setUpdatedTime(soItemList.get(0).getUpdatedTime().toString());
				soitemsDTO.setPvcWeight(soItemList.get(0).getPvcWeight());
				SalesOrderItem soitem=soitemsDTO.getOrderDetail();
				updateSoItemResult=orderDetailsService.update(soitem);
			}
			
			if(updateSoItemResult==true){
				String salesOrder=workOrderOutput.get(0).getSalesOrderItem().getOrder().getOrderId();
				String itemCode=workOrderOutput.get(0).getSalesOrderItem().getItem().getItemCode();
				String workOrderNo=workOrderOutput.get(0).getProductionWorkOrder().getWorkOrderNo();
				//String bundles=soItemList.get(0).getBundleSize().toString();
				String confirmStatus="No";
			//List<StockIn>stockInList=stockInService.findByOrderDetailIdBundleIdWorkOrderNo(orderDetailId, soItemList.get(0).getBundleSize().toString(), workOrderOutput.get(0).getProductionWorkOrder().getWorkOrderNo());
				List<StockIn>stockInList=stockInService.findByOrderIdAndItemCodeAndWoNoAndBundleIdAndConfirmStatus(salesOrder, itemCode, workOrderNo, bundleNo, confirmStatus);

			   List<StoreRegister>storeRegExistList=storeRegisterService.findByOrderDetailIdAndBundleIdAndWorkOrderNo(orderDetailId, bundleNo, workOrderOutput.get(0).getProductionWorkOrder().getWorkOrderNo());
     		
			
			    StockInDTO stockInDTO = new StockInDTO();
				stockInDTO.setStoreId(1);
				stockInDTO.setOrderDetailId(orderDetailId);
				stockInDTO.setOrderId(soItemList.get(0).getOrder().getOrderId());
				stockInDTO.setItemId(soItemList.get(0).getItem().getItemId());
				stockInDTO.setItemCode(soItemList.get(0).getItem().getItemCode());
				stockInDTO.setSoItemQty(soItemList.get(0).getQuantity());
				stockInDTO.setWorkOrderNo(workOrderOutput.get(0).getProductionWorkOrder().getWorkOrderNo());
				stockInDTO.setQcStatus("Approved");
				stockInDTO.setCustomerName(soItemList.get(0).getOrder().getCustomer().getCustomerName());
				stockInDTO.setBundleId(bundleNo);
				stockInDTO.setWeight(workOrderOutput.get(0).getNetWeight());
				stockInDTO.setBatchNo(workOrderOutput.get(0).getBatchNo());
				stockInDTO.setConfirmStatus("Yes");
				stockInDTO.setStockQty(workOrderOutput.get(0).getNetLength());
				stockInDTO.setWeight(workOrderOutput.get(0).getNetWeight());
				stockInDTO.setSupervisor(supervisor);
				StockIn stockInObj=null;
				if(stockInList.size()==0 && storeRegExistList.size()==0){
				  stockInObj=stockInDTO.getStockIn();
				 createdStockIn=stockInService.create(stockInObj);
				 if(createdStockIn!=null)
				 updateStockInResult=true;
				 else
					 updateStockInResult=false;	 
				}//end of if(stockInList.size()==0)
				if(updateStockInResult==true && storeRegExistList.size()==0){
					StoreRegisterDTO storeRegDTO=new StoreRegisterDTO();
					storeRegDTO.setItemCode(soItemList.get(0).getItem().getItemCode());
					storeRegDTO.setStoreId(1);
					storeRegDTO.setWorkOrderNo(workOrderOutput.get(0).getProductionWorkOrder().getWorkOrderNo());
					storeRegDTO.setCustomerName(soItemList.get(0).getOrder().getCustomer().getCustomerName());
					storeRegDTO.setBundleId(bundleNo);
					
					storeRegDTO.setOrderId(soItemList.get(0).getOrder().getOrderId());
					storeRegDTO.setOrderDetailId(orderDetailId);
					storeRegDTO.setItemId(soItemList.get(0).getItem().getItemId());
					storeRegDTO.setPackingSlipNo((long)1);
					storeRegDTO.setSupervisor(supervisor);
					
					storeRegDTO.setBagWeight(1.0);
					storeRegDTO.setStockQty(workOrderOutput.get(0).getNetLength());
					storeRegDTO.setWeight(workOrderOutput.get(0).getNetWeight());
					storeRegDTO.setQcStatus("Pending");
					storeRegDTO.setQcSupervisor("");
					storeRegDTO.setRejectStatus("");
					
					StoreRegister storeReg=storeRegDTO.getStoreRegister();
					createdStoreReg=storeRegisterService.create(storeReg);
					if(createdStoreReg!=null)
						updateStoreReg=true;
			 }//end of if(updateStockInResult==true && storeRegExistList.size()==0)
		}//end of if(updateSoItemResult==true)
      }//end of if(orderDetailId!=null && updateWorkOrderOutput==true)
	}//end of if(workOrderOutput.get(0).getGrossWeight()>workOrderOutput.get(0).getTareWeight())	
}//end of (workOrderOutput.size()>0)
   return new StatusResponse(updateStoreReg);

}
	 /**generate rbdJobCardReport
	   * @param  workOrderNo
	   * @return void .
	   */	
@RequestMapping(value = "/rbdJobCardReport", produces = "application/pdf", method = RequestMethod.GET)
	
	public void rbdJobCardReport(@RequestParam(value = "workOrderNo", required = true) String workOrderNo,javax.servlet.http.HttpServletResponse response) throws IOException, InterruptedException{
	
	if(workOrderNo!=null && workOrderNo!=""){
	InputStream inputStream = getClass().getClassLoader().getResourceAsStream("/org/balajicables/salesmanager/report/RBDJobCardReport.jrxml");
    	
    	 Map<String, Object> hm= new HashMap<String, Object>();
         hm.put("WORK ORDER NO", workOrderNo);//set report param
         byte[] content = ReportGenerator.newReportGenerator(inputStream,hm);
	       
	    response.setContentType("application/pdf");
		response.setHeader("Content-Disposition", "attachment;filename=" + "RbdJobCardReport"+workOrderNo+".pdf");//set PDF file header
		response.setContentLength(content.length);
	    FileCopyUtils.copy(content, response.getOutputStream());
       
   }
 }

@RequestMapping(value = "/getWorkOrderNo", produces = "application/json", method = RequestMethod.POST)
public @ResponseBody
ArrayList<String> getWorkOrderNos(
		@RequestParam("processType") String processType,
		@RequestParam("month") int month,
		@RequestParam("year") int year) {
	ArrayList<String> woNosList = new ArrayList<>();
	List<ProductionWorkOrder> pdnWos = productionWorkOrderService.findByProcessTypeAndMonthYear(processType,month+1,year);

	for (int iterator = 0; iterator < pdnWos.size(); iterator++) {
		if (pdnWos.get(iterator).getWorkOrderNo() != null
				&& pdnWos.get(iterator).getWorkOrderNo() != "") {
			String woNo = pdnWos.get(iterator).getWorkOrderNo();
			if (!woNosList.contains(woNo)) {
				woNosList.add(woNo);
			}
		}
	}
	Collections.sort(woNosList,Collections.reverseOrder());

	return woNosList;
}
}	
		
		
