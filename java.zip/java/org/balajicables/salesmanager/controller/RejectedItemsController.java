
package org.balajicables.salesmanager.controller;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Resource;

import org.balajicables.salesmanager.CustomUser;
import org.balajicables.salesmanager.common.JqgridResponse;
import org.balajicables.salesmanager.common.StatusResponse;
import org.balajicables.salesmanager.dto.RawMaterialStoreRegDTO;
import org.balajicables.salesmanager.dto.ScrapStoreRegDTO;
import org.balajicables.salesmanager.dto.StoreRegisterDTO;
import org.balajicables.salesmanager.model.RawMaterialStoreReg;
import org.balajicables.salesmanager.model.ScrapStoreReg;
import org.balajicables.salesmanager.model.StoreRegister;
import org.balajicables.salesmanager.model.Item;
import org.balajicables.salesmanager.service.ItemService;
import org.balajicables.salesmanager.service.RawMaterialStoreRegService;
import org.balajicables.salesmanager.service.ScrapStoreRegService;
import org.balajicables.salesmanager.service.StoreRegisterService;
import org.springframework.data.domain.Page;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
/**
* This class demonstrates Rejected Items By QC.
* @author Abin Sam
*/
@Controller
@RequestMapping("/rejectedItems")
public class RejectedItemsController {

	@Resource
	private StoreRegisterService storeRegisterService;
	@Resource
	private ItemService itemService;
	@Resource
	private RawMaterialStoreRegService rawMaterialStoreRegService;
	@Resource
	private ScrapStoreRegService  scrapStoreRegService;
	 /**
	   * This method returns rejectedItems.jsp
	   * @param Model to set the attribute.
	   * @return rejectedItems.jsp.
	   */
	@RequestMapping(method = RequestMethod.GET)
	public String getRejectedItemsPage(Model model) {

	
		return "rejectedItems";
	}
	/**
	   * This POST method is to fetch store register rejected items for rejectedItems JQ grid.
	   * @param searchObject,rejectStatus,toDateString,fromDateString,search,filters,pageNumber,rowsPerPage,sortColName,sortOrder
	   * @return JqgridResponse<StoreRegisterDTO> response  
	   */
	@RequestMapping(value="/records", produces="application/json", method=RequestMethod.POST)
	public @ResponseBody
	JqgridResponse<StoreRegisterDTO> records(
			@RequestParam(value="searchObject", required=false) String searchObject,
			@RequestParam("_search") Boolean search,
			@RequestParam(value="fromDate", required=false) String fromDateString,
	   		@RequestParam(value="toDate", required=false) String toDateString,
	   		@RequestParam(value="orderStatus", required=false) String rejectStatus,
    		@RequestParam(value="filters", required=false) String filters,
			@RequestParam(value = "page", required = false) Integer pageNumber,
			@RequestParam(value = "rows", required = false) Integer rowsPerPage,
			@RequestParam(value = "sidx", required = false) String sortColName,
			@RequestParam(value = "sord", required = false, defaultValue = "asc") String sortOrder) throws ParseException {
		 /*grid column sorting*/
		 if(sortColName.equalsIgnoreCase("customerCode")){
				sortColName="salesOrderItem.orders.customer.customerCode";
			}
		  if(sortColName.equalsIgnoreCase("customerName")){
				sortColName="salesOrderItem.orders.customer.customerName";
			}
		  if(sortColName.equalsIgnoreCase("itemDescription")){
				sortColName="salesOrderItem.items.itemDescription";
			}
		  if(sortColName.equalsIgnoreCase("workOrderNo")){
				sortColName="productionWorkOrder.workOrderNo";
			}
		  if(sortColName.equalsIgnoreCase("status")){
				sortColName="salesOrderItem.orders.orderStatus.status";
			}
		
		 /*storeReg Page of type StoreRegister initialized to null*/
		 Page<StoreRegister> storeReg=null;
		 java.util.Date fromDate = null;
		 java.util.Date toDate = null;
		 if((fromDateString!=null && fromDateString!="")&&(toDateString!=null && toDateString!="")){
			  DateFormat df = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
		     	 fromDate = df.parse(fromDateString+" 00:00:00");
		     	 toDate = df.parse(toDateString+" 23:59:59");
		 }
		
	     	if((fromDateString!=null && fromDateString!="")&&(toDateString!=null && toDateString!="")&&(rejectStatus==null || rejectStatus=="")){
	     		/*Method to fetch Method to fetch JQGRID rejected paged records items from store register based on fromDate,toDate*/
	     		storeReg = storeRegisterService.getRejectOrderWithDate(fromDate,toDate,pageNumber - 1,
							rowsPerPage, sortColName, sortOrder);
		    }else if((rejectStatus!=null && rejectStatus!="")&&(fromDateString==null || fromDateString=="")&&(toDateString==null || toDateString=="")){
		    	/*Method to fetch Method to fetch JQGRID rejected paged records items from store register based on rejectStatus*/
               storeReg = storeRegisterService.getRejectOrderWithStatus(rejectStatus,pageNumber - 1,
							rowsPerPage, sortColName, sortOrder);	
		    }
		    else if((rejectStatus!=null && rejectStatus!="")&&(fromDateString!=null && fromDateString!="")&&(toDateString!=null && toDateString!="")){
		    	/*Method to fetch Method to fetch JQGRID rejected paged records items from store register based on fromDate,toDate,rejectStatus*/
               storeReg = storeRegisterService.getRejectOrderWithStatusAndDate(fromDate,toDate,rejectStatus,pageNumber - 1,
							rowsPerPage, sortColName, sortOrder);	
		    }else{
		    	/*Method to fetch Method to fetch JQGRID rejected paged records items from store register*/
               storeReg = storeRegisterService.getQCRejectedPagedStore(pageNumber - 1,
						rowsPerPage, sortColName, sortOrder);
		    }
	    /*Intialize JQ grid response of type StoreRegisterDTO*/
		JqgridResponse<StoreRegisterDTO> response = new JqgridResponse<StoreRegisterDTO>();
		/*Method to set rejected store register item list to StoreRegisterDTO*/
		List<StoreRegisterDTO> storeDTOs = convertToStoreDTO(storeReg.getContent());
		response.setRows(storeDTOs);
		response.setRecords(Long.valueOf(storeReg.getTotalElements()).toString());
		response.setTotal(Long.valueOf(storeReg.getTotalPages()).toString());
		response.setPage(Integer.valueOf(storeReg.getNumber()+1).toString());
	 	return response;
	
	}
	 /**
	   * This Method to set rejected store register item list to StoreRegisterDTO
	   * @param List<StoreRegister> StoreRegister
	   * @return List<StoreRegisterDTO> response
	   */
	private List<StoreRegisterDTO> convertToStoreDTO(List<StoreRegister> storeRegs) {
		List<StoreRegisterDTO> storeRegDTOs = new ArrayList<>();
		for(StoreRegister storeReg : storeRegs) {
			StoreRegisterDTO storeRegDTO=new StoreRegisterDTO();
			storeRegDTO.setStoreRegisterId(storeReg.getStoreRegisterId());
			storeRegDTO.setStoreId(storeReg.getStore().getStoreId());
			storeRegDTO.setStoreAddress(storeReg.getStore().getStoreAddress());
			storeRegDTO.setItemId(storeReg.getSalesOrderItem().getItem().getItemId());
			storeRegDTO.setItemCode(storeReg.getSalesOrderItem().getItem().getItemCode());
			storeRegDTO.setOrderId(storeReg.getSalesOrderItem().getOrder().getOrderId());
			storeRegDTO.setCustomerId(storeReg.getSalesOrderItem().getOrder().getCustomer().getCustomerId());
			storeRegDTO.setCustomerName(storeReg.getSalesOrderItem().getOrder().getCustomer().getCustomerName());
			storeRegDTO.setCustomerCode(storeReg.getSalesOrderItem().getOrder().getCustomer().getCustomerCode());
			storeRegDTO.setWorkOrderNo(storeReg.getProductionWorkOrder().getWorkOrderNo());
			storeRegDTO.setStockQty(storeReg.getStockQty());
			storeRegDTO.setBundleId(storeReg.getBundleId());
			storeRegDTO.setOrderDetailId(storeReg.getSalesOrderItem().getOrderDetailId());
			storeRegDTO.setItemDescription(storeReg.getSalesOrderItem().getItem().getItemDescription());
			storeRegDTO.setPackingSlipNo(storeReg.getPackingSlipNo());
			storeRegDTO.setSupervisor(storeReg.getSupervisor());
			storeRegDTO.setWeight(storeReg.getWeight());
			storeRegDTO.setUnits(storeReg.getSalesOrderItem().getItem().getUnit().getUnits());
			storeRegDTO.setBagWeight(storeReg.getBagWeight());
			storeRegDTO.setStatus(storeReg.getSalesOrderItem().getOrder().getOrderStatus().getStatus());
			storeRegDTO.setRejectStatus(storeReg.getRejectStatus());
			storeRegDTO.setQcSupervisor(storeReg.getQcSupervisor());
			storeRegDTO.setRemarks(storeReg.getRemarks());
			storeRegDTOs.add(storeRegDTO)	;
		}
		return storeRegDTOs;
	}
	/**
	   * This POST method is to fetch raw material store register rejected items for rejectedItems JQ grid.
	   * @param searchObject,rejectStatus,toDateString,fromDateString,search,filters,pageNumber,rowsPerPage,sortColName,sortOrder
	   * @return JqgridResponse<RawMaterialStoreRegDTO> response  
	   */
	@RequestMapping(value="/poRecords", produces="application/json", method=RequestMethod.POST)
	public @ResponseBody
	JqgridResponse<RawMaterialStoreRegDTO> poRecords(
			@RequestParam(value="searchObject", required=false) String searchObject,
			@RequestParam("_search") Boolean search,
			@RequestParam(value="fromDate", required=false) String fromDateString,
	   		@RequestParam(value="toDate", required=false) String toDateString,
	   		@RequestParam(value="orderStatus", required=false) String rejectStatus,
    		@RequestParam(value="filters", required=false) String filters,
			@RequestParam(value = "page", required = false) Integer pageNumber,
			@RequestParam(value = "rows", required = false) Integer rowsPerPage,
			@RequestParam(value = "sidx", required = false) String sortColName,
			@RequestParam(value = "sord", required = false, defaultValue = "asc") String sortOrder) throws ParseException {
		 /*storeReg Page of type RawMaterialStoreReg initialized to null*/ 
		Page<RawMaterialStoreReg> storeReg=null;
		 java.util.Date fromDate = null;
		 java.util.Date toDate = null;
		 if((fromDateString!=null && fromDateString!="")&&(toDateString!=null && toDateString!="")){
			  DateFormat df = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
		     	 fromDate = df.parse(fromDateString+" 00:00:00");
		     	 toDate = df.parse(toDateString+" 23:59:59");
		 }//end of if((fromDateString!=null && fromDateString!="")&&(toDateString!=null && toDateString!="")) loop
		
	     	if((fromDateString!=null && fromDateString!="")&&(toDateString!=null && toDateString!="")&&(rejectStatus==null || rejectStatus=="")){
	     		/*Method to fetch Method to fetch JQGRID rejected paged records items from raw material store register based on fromDate,toDate and "Rejected" status*/
                storeReg = rawMaterialStoreRegService.getRejectOrderWithDateAndStatus("Rejected",fromDate,toDate,pageNumber - 1,
							rowsPerPage, sortColName, sortOrder);
		    }else if((rejectStatus!=null && rejectStatus!="")&&(fromDateString==null || fromDateString=="")&&(toDateString==null || toDateString=="")){
		    	/*Method to fetch Method to fetch JQGRID rejected paged records items from raw material store register based on "Rejected" status and rejectStatus */
                storeReg = rawMaterialStoreRegService.getRejectOrderWithRejectStatus("Rejected",rejectStatus,pageNumber - 1,
							rowsPerPage, sortColName, sortOrder);	
		    }
		    else if((rejectStatus!=null && rejectStatus!="")&&(fromDateString!=null && fromDateString!="")&&(toDateString!=null && toDateString!="")){
		    	/*Method to fetch Method to fetch JQGRID rejected paged records items from raw material store register based on fromDate,toDate and "Rejected" status*/
                storeReg = rawMaterialStoreRegService.getRejectOrderWithStatusAndDate("Rejected",fromDate,toDate,rejectStatus,pageNumber - 1,
							rowsPerPage, sortColName, sortOrder);	
		    }else{
		    	/*Method to fetch Method to fetch JQGRID rejected paged records items from raw material store register*/
                storeReg = rawMaterialStoreRegService.getQCRejectedPagedStore(pageNumber - 1,
						rowsPerPage, sortColName, sortOrder);
		    }//end of else if ladder
	     	  /*Intialize JQ grid response of type RawMaterialStoreRegDTO*/	
		JqgridResponse<RawMaterialStoreRegDTO> response = new JqgridResponse<RawMaterialStoreRegDTO>();
		/*Method to set rejected raw material store register item list to RawMaterialStoreRegDTO*/
		List<RawMaterialStoreRegDTO> storeDTOs = convertToRawMaterialStoreDTO(storeReg.getContent());
		response.setRows(storeDTOs);
		response.setRecords(Long.valueOf(storeReg.getTotalElements()).toString());
		response.setTotal(Long.valueOf(storeReg.getTotalPages()).toString());
		response.setPage(Integer.valueOf(storeReg.getNumber()+1).toString());
	 	return response;
	
	}
	 /**
	   * This Method to set rejected store register item list to RawMaterialStoreRegDTO
	   * @param List<RawMaterialStoreReg> RawMaterialStoreReg
	   * @return List<RawMaterialStoreRegDTO> response
	   */
	private List<RawMaterialStoreRegDTO> convertToRawMaterialStoreDTO(List<RawMaterialStoreReg> storeRegs) {
		List<RawMaterialStoreRegDTO> storeRegDTOs = new ArrayList<>();
		for(RawMaterialStoreReg storeReg : storeRegs) {
			/*Initializing RawMaterialStoreRegDTO*/
			RawMaterialStoreRegDTO storeRegDTO=new RawMaterialStoreRegDTO();

			storeRegDTO.setRwStoreRegId(storeReg.getRwStoreRegId());
			storeRegDTO.setStoreId(storeReg.getStore().getStoreId());
			storeRegDTO.setItemCode(storeReg.getPurchaseOrderItem().getItem().getItemCode());
			storeRegDTO.setPoNo(storeReg.getPurchaseOrderItem().getPurchaseOrder().getPoNo());
			storeRegDTO.setPoStatus(storeReg.getPurchaseOrderItem().getPurchaseOrder().getPoStatus());
			storeRegDTO.setCustomerName(storeReg.getPurchaseOrderItem().getPurchaseOrder().getCustomer().getCustomerName());
			storeRegDTO.setCustomerCode(storeReg.getPurchaseOrderItem().getPurchaseOrder().getCustomer().getCustomerCode());
			storeRegDTO.setStockOutQty(storeReg.getStockOutQty());
			storeRegDTO.setItemDescription(storeReg.getPurchaseOrderItem().getItem().getItemDescription());
			storeRegDTO.setNetWeight(storeReg.getNetWeight());
			storeRegDTO.setTotalQty(storeReg.getTotalQty());
			storeRegDTO.setBatchNo(storeReg.getBatchNo());
			storeRegDTO.setNoOfBags(storeReg.getNoOfBags());
			storeRegDTO.setTotalQty(storeReg.getTotalQty());
			storeRegDTO.setUnits(storeReg.getPurchaseOrderItem().getItem().getUnit().getUnits());
			storeRegDTO.setRejectStatus(storeReg.getRejectStatus());
			storeRegDTO.setQcSupervisor(storeReg.getQcSupervisor());
			storeRegDTO.setRemarks(storeReg.getRemarks());
			storeRegDTOs.add(storeRegDTO)	;
		}//end of for loop
		return storeRegDTOs;
	}

	
	
	 /**
	   * Scrapping rejected items
	   * @param selected store register id
	   * @return List<String>
	   */
	@RequestMapping(value = "/scrapItems", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	StatusResponse scrapItems(
				@RequestParam(value = "idsOfSelectedRows[]", required = false) Long[] idsOfSelectedRows){
		/*Method to get name of the person who has logged in*/
		CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();;
		/*Method to get username of the person who has logged in*/
		String userName = user.getFirstName()+" "+user.getLastName(); 
		Long itemId=null;
		Boolean result=false;
		List<Item>itemList=itemService.findByProductKey("CS");
		if(itemList.size()>0){
			itemId=itemList.get(0).getItemId();
		}
		
		
		for (int i = 0; i < idsOfSelectedRows.length; i++) {
			   List<StoreRegister> storeRegList = storeRegisterService.findById(idsOfSelectedRows[i]);
		       if(storeRegList.size()>0){
		    	   Double stockQuantity=0.0;
		    	   String units=storeRegList.get(0).getSalesOrderItem().getItem().getUnit().getUnits();
		    	   if(units.equalsIgnoreCase("Kgs") && units.equalsIgnoreCase("Kg")){
		    		   stockQuantity=storeRegList.get(0).getWeight();
		    	   }else{
		    		   stockQuantity=storeRegList.get(0).getStockQty();
		    	   }
		    	   List<ScrapStoreReg>scrapList=scrapStoreRegService.findByItemsItemId(itemId);
		    		ScrapStoreRegDTO scrapStoreRegDTO=new ScrapStoreRegDTO();
		    		if(scrapList.size()>0){
		    			scrapStoreRegDTO.setScrapStoreRegId(scrapList.get(0).getScrapStoreRegId());
		    			scrapStoreRegDTO.setStockOutQty(scrapList.get(0).getStockOutQty());
			    		scrapStoreRegDTO.setUpdatedBy(userName);
			    		scrapStoreRegDTO.setItemId(itemId);
			    		scrapStoreRegDTO.setStockQuantity(scrapList.get(0).getStockQuantity()+stockQuantity);
			    		scrapStoreRegDTO.setStoreId(scrapList.get(0).getStore().getStoreId());
		    			ScrapStoreReg scrapStoreReg=scrapStoreRegDTO.getScrapStoreReg();
		    			result=scrapStoreRegService.update(scrapStoreReg);
		    		}
		    		else{
		       			scrapStoreRegDTO.setStockOutQty(0.0);
			    		scrapStoreRegDTO.setUpdatedBy(userName);
			    		scrapStoreRegDTO.setItemId(itemId);
			    		scrapStoreRegDTO.setStockQuantity(stockQuantity);
			    		scrapStoreRegDTO.setStoreId(1);
			    		ScrapStoreReg scrapStoreRegs=scrapStoreRegDTO.getScrapStoreReg();
			    		ScrapStoreReg createdScrapStoreReg=scrapStoreRegService.create(scrapStoreRegs);
		        		if(createdScrapStoreReg!=null)
		        		result=true;
		    		}
		       }
		       if(result==true){
		    	   Long storeRegId=storeRegList.get(0).getStoreRegisterId();
		    	   storeRegisterService.delete(storeRegId);
		       }
		  }//end of for loop
		return new StatusResponse(result);
		
		 }

}
