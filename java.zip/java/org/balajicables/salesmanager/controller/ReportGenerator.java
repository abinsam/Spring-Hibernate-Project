package org.balajicables.salesmanager.controller;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Map;
import java.util.ResourceBundle;
import javax.servlet.http.HttpServletResponse;
import net.sf.jasperreports.engine.JRAbstractExporter;
import net.sf.jasperreports.engine.JRExporterParameter;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.export.JRPdfExporter;
/**
 * Generates Jasper Reports in PDF format by taking the input from the jrxml files 
 */
public class ReportGenerator {
	public static Boolean reportGenerator(InputStream inputStream,
			String pdfFileName, Map<String, Object> hm,HttpServletResponse response) {		
	      Boolean result=false;
		  try {
			    JasperReport jasperReport;
				JasperPrint jasperPrint;

			
				   ResourceBundle bundle = ResourceBundle.getBundle("db");
				   String dbUrl = bundle.getString("db.url");
				   String dbDriver = bundle.getString("db.driver");
				   String dbUname = bundle.getString("db.username");
				   String dbPwd = bundle.getString("db.password");
			   
				   Class.forName(dbDriver);
				   Connection conn = DriverManager.getConnection(dbUrl, dbUname, dbPwd);

				   ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
				   jasperReport = JasperCompileManager.compileReport(inputStream);//compiles the .jrxml files into .jasper files
				  
				   jasperPrint = JasperFillManager.fillReport(jasperReport, hm,conn);
				 
				   JRAbstractExporter exporter =  new JRPdfExporter();
				
						exporter.setParameter(JRExporterParameter.JASPER_PRINT, jasperPrint);
						exporter.setParameter(JRExporterParameter.OUTPUT_STREAM, outputStream);
						exporter.exportReport();
				
						byte[] content = outputStream.toByteArray();
						result=true;
						File f = new File(pdfFileName);
						FileOutputStream fos = new FileOutputStream(f);
						fos.write(content, 0, content.length);
				
						
					fos.flush();
					fos.close();
			   
			  } catch (Exception e) {
			   System.out.print("Exceptiion" + e);
			  }
		  return result;
	 }

	public static byte[] newReportGenerator(InputStream inputStream,Map<String, Object> hm) {
		 
	      byte[] content = null;
		  try {
			    JasperReport jasperReport;
				JasperPrint jasperPrint;

			
				   ResourceBundle bundle = ResourceBundle.getBundle("db");
				   String dbUrl = bundle.getString("db.url");
				   String dbDriver = bundle.getString("db.driver");
				   String dbUname = bundle.getString("db.username");
				   String dbPwd = bundle.getString("db.password");
			   
				   Class.forName(dbDriver);
				   Connection conn = DriverManager.getConnection(dbUrl, dbUname, dbPwd);

				   ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
				   jasperReport = JasperCompileManager.compileReport(inputStream);
				   jasperPrint = JasperFillManager.fillReport(jasperReport, hm,conn);
				 
				   JRAbstractExporter exporter =  new JRPdfExporter();
				
						exporter.setParameter(JRExporterParameter.JASPER_PRINT, jasperPrint);
						exporter.setParameter(JRExporterParameter.OUTPUT_STREAM, outputStream);
						exporter.exportReport();
						
						content = outputStream.toByteArray();
								   
			  } catch (Exception e) {
				  e.printStackTrace();
			
			  }
		 
		  return content;	
	 }
	
	public static void deleteDir(File dir) {
		File[] files = dir.listFiles();

		for (File myFile : files) {
			if (myFile.isDirectory()) {
				deleteDir(myFile);
			}
			myFile.delete();

		}

	}

}
	 