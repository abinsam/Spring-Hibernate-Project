package org.balajicables.salesmanager.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import javax.annotation.Resource;
import org.balajicables.salesmanager.common.JqgridFilter;
import org.balajicables.salesmanager.common.JqgridObjectMapper;
import org.balajicables.salesmanager.common.JqgridResponse;
import org.balajicables.salesmanager.common.StatusResponse;
import org.balajicables.salesmanager.dto.SalesOrderItemsDTO;
import org.balajicables.salesmanager.model.Item;
import org.balajicables.salesmanager.model.SalesOrderItem;
import org.balajicables.salesmanager.model.StoreRegister;
import org.balajicables.salesmanager.service.ItemService;
import org.balajicables.salesmanager.service.OrderDetailsService;
import org.balajicables.salesmanager.service.StoreRegisterService;
import org.balajicables.salesmanager.utils.Utility;

import org.springframework.data.domain.Page;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
/**
* This class demonstrates MMH WorkOrder Process
* @author Abin Sam
*/
@Controller
@RequestMapping("/viewSOForWO")
public class SOForWOController {

	@Resource
	private OrderDetailsService orderDetailsService;

	@Resource 
	private StoreRegisterService storeRegisterService;
	
	@Resource
	private ItemService itemService;
	/**
	   * This method returns soForWorkOrder.jsp.
	   * Fetch all customers and workorder number based on process type
	   * @param Model to set the attribute.
	   * @return soForWorkOrder.jsp.
	   */
	@RequestMapping(method = RequestMethod.GET)
	public String getSalesOrdersPage(Model model,@RequestParam(value="workOrderNo") String workOrderNo,
			@RequestParam(value="reportType") String reportType) {
		String itemType=null;
		if(reportType.equalsIgnoreCase("Extrusion")){
			itemType="ITEM";
		}
		else if(reportType.equalsIgnoreCase("MWD")){
			 itemType="Multiwire";
		}
		else if(reportType.equalsIgnoreCase("Bunching")){
			itemType="Bunching";
		}
		if(itemType!=null){
		String[] orderStatus= {"Approved", "Approved For Prodn"};
		ArrayList<String> salesOrders = new ArrayList<>();
		Map<Long, String> unsortedMap = new HashMap<Long, String>();
		List<SalesOrderItem>soItemList=orderDetailsService.findByItemsItemTypeAndOrderStatusInAndBalanceQtyGreaterThan(itemType,orderStatus);
		for (int iterator = 0; iterator < soItemList.size(); iterator++) {
			String soNo = soItemList.get(iterator).getOrder().getOrderId();
			String customerName= soItemList.get(iterator).getOrder().getCustomer().getCustomerName();
         	Long customerId=soItemList.get(iterator).getOrder().getCustomer().getCustomerId();
			if (!salesOrders.contains(soNo)) {
				salesOrders.add(soNo);
			}//end of if loop
		  	if (!unsortedMap.containsValue(customerName)) {
		  		unsortedMap.put(customerId, customerName);
        		//custList.add(storeRegList.get(iterator).getSalesOrderItem().getOrder().getCustomer());
    		}//end of if loop
		}//end of for loop
		Collections.sort(salesOrders,Collections.reverseOrder());//sort sales orders in descending order
		Map<Long, String> sortedMap = sortByComparator(unsortedMap);
		
		model.addAttribute("workOrderNo", workOrderNo);
		model.addAttribute("reportType", reportType);
		model.addAttribute("orderIds",salesOrders);
		model.addAttribute("itemIds",itemService.getAllItems());
		model.addAttribute("customers", sortedMap);
		model.addAttribute("colours", itemService.getAllColours());
		model.addAttribute("copperDiameters", itemService.getAllCopperDiameters());
		model.addAttribute("productTypes", itemService.getAllProductTypes());
		model.addAttribute("cableStdPvcs", itemService.getAllCableStdPvcs());
		}//end of if loop
		return "soForWorkOrder";
	}
	
	private Map<Long, String> sortByComparator(Map<Long, String> unsortedMap) {
		List list = new LinkedList(unsortedMap.entrySet());
	// sort list based on comparator
		Collections.sort(list, new Comparator() {
			public int compare(Object o1, Object o2) {
				return ((Comparable) ((Map.Entry) (o1)).getValue())
                                       .compareTo(((Map.Entry) (o2)).getValue());
			}
		});
 
		// put sorted list into map again
                //LinkedHashMap make sure order in which keys were inserted
		Map sortedMap = new LinkedHashMap();
		for (Iterator it = list.iterator(); it.hasNext();) {
			Map.Entry entry = (Map.Entry) it.next();
			sortedMap.put(entry.getKey(), entry.getValue());
		}
		return sortedMap;
	}
	/**
	   * This method fetch stock in item records for workorder
	   * Fetch  stock in records for grid
	   * @PathVariable reportType
	   * @param searchObject,search,filters,pageNumber,rowsPerPage,sortColName,sortOrder
	   * @return JqgridResponse<StockInDTO>response
	   */
	@RequestMapping(value="/records/{reportType}", produces="application/json" , method = RequestMethod.POST)
	public @ResponseBody
	JqgridResponse<SalesOrderItemsDTO> records(
			@PathVariable("reportType") String reportType,
			@RequestParam(value="searchObject", required=false) String searchObject,
		    @RequestParam("_search") Boolean search,
    		@RequestParam(value="filters", required=false) String filters,
	    	@RequestParam(value = "page", required = false) Integer pageNumber,
			@RequestParam(value = "rows", required = false) Integer rowsPerPage,
			@RequestParam(value = "sidx", required = false) String sortColName,
			@RequestParam(value = "sord", required = false, defaultValue = "asc") String sortOrder) {
		/*JQGrid column sorting*/
		if(sortColName.equalsIgnoreCase("customerName")){
			sortColName="orders.customer.customerName";
		}
		if(sortColName.equalsIgnoreCase("customerCode")){
			sortColName="orders.customer.customerCode";
		}
		if(sortColName.equalsIgnoreCase("orderAcceptanceDate")){
			sortColName="orders.orderAcceptanceDate";
		}
		if(sortColName.equalsIgnoreCase("cableStdKey")){
			sortColName="items.cableStdPvc.cableStdKey";
		}
		if(sortColName.equalsIgnoreCase("orderId")){
			sortColName="orders.orderId";
		}
		if(sortColName.equalsIgnoreCase("itemCode")){
			sortColName="items.itemCode";
		}
		if(sortColName.equalsIgnoreCase("mainColour")){
			sortColName="items.mainColour.color";
		}
		if(sortColName.equalsIgnoreCase("innerColor")){
			sortColName="items.innerColour.color";
		}
		if(sortColName.equalsIgnoreCase("numberOfCopperStrands")){
			sortColName="items.numberOfCopperStrands";
		}
		
		if(sortColName.equalsIgnoreCase("copperkey")){
			sortColName="items.copperStrandDiameter.copperkey";
		}
		if(sortColName.equalsIgnoreCase("unit")){
			sortColName="items.unit.units";
		}
		if(sortColName.equalsIgnoreCase("odLabel")){
			sortColName="items.odLabel";
		}
		if(sortColName.equalsIgnoreCase("status")){
			sortColName="orders.orderStatus.status";
		}
		String[] orderStatus= {"Approved", "Approved For Prodn"};
 
		if (searchObject != null) {
	           return getFilteredRecords(searchObject, pageNumber-1,rowsPerPage,sortColName,sortOrder,reportType);
	    }//end of if (searchObject != null)  condition
		
		if(search==true){
		   return getFilteredRecords(filters, pageNumber-1, rowsPerPage,sortColName,sortOrder,reportType);
		}//end of if(search==true) condition
         else{
        	 /*Page orderOutput of type SalesOrderItem initialized to null*/
	          Page<SalesOrderItem> orderOutput = null;
	           if(reportType.equalsIgnoreCase("PendingReport"))	{
	        	   /*Fetch jqgrid paged salesorder item records based on orderstatus*/
		           orderOutput=orderDetailsService.getSoItemPendingReport(pageNumber - 1,rowsPerPage, sortColName, sortOrder,orderStatus);	
	      }//end of if(reportType.equalsIgnoreCase("PendingReport")) condition	
	        else{
	        	   /*Fetch jqgrid paged salesorder item records based on orderStatus,reportType*/
		           orderOutput=orderDetailsService.getPendingSoItems(pageNumber - 1,rowsPerPage, sortColName, sortOrder,orderStatus,reportType);
	    }
	    /*Intialize JQ grid response of type SalesOrderItemsDTO */
        JqgridResponse<SalesOrderItemsDTO> response = new JqgridResponse<SalesOrderItemsDTO>();
        /*Method to set salesorder item list to SalesOrderItemsDTO*/
        List<SalesOrderItemsDTO> soItemDTOs = convertToDTO(orderOutput.getContent());
		response.setRows(soItemDTOs);
	    response.setRecords(Long.valueOf(orderOutput.getTotalElements()).toString());
	    response.setTotal(Long.valueOf(orderOutput.getTotalPages()).toString());
	    response.setPage(Integer.valueOf(orderOutput.getNumber()+1).toString());
  	    
	    return response;
	}
		
}
	 /**
	   * This method to fetch salesorder item based on search parameter and set response to JQGRID
	   * Fetch salesorder item details for grid
	   * @param filters,pageNumber,rowsPerPage,sortColName,sortOrder
	   * @return JqgridResponse<SalesOrderItemsDTO> response
	   */
		private JqgridResponse<SalesOrderItemsDTO> getFilteredRecords(
			String filters,int pagenumber,Integer rows,String sortColName,String sortOrder,String reportType) {
        String qOrderId = null;
         Long qCustomerId = null;
        Integer qNumberOfCopperStrands=0;
        String qCopperKey = null;
        String qOdLabel = null;
        String qMainColour = null;
        String qInnerColor = null;
        String qCableStdKey = null;
        String qLayLength = null;
        String qLayType = null;
        String qProductKey = null;
        String qItemCode = null;
        String qOrderAcceptanceDate = null;
        String qOrderAcceptanceDateTo = null;
        //JQ Grid filtering parameters 
        JqgridFilter jqgridFilter = JqgridObjectMapper.map(filters);
        for (JqgridFilter.Rule rule: jqgridFilter.getRules()) {
                if (rule.getField().equals("orderId"))
                	   qOrderId = rule.getData();
                else if (rule.getField().equals("itemCode"))
             	   qItemCode = rule.getData();
                else if (rule.getField().equals("customerId")){
              	  if(rule.getData()=="" || rule.getData()==null)
              		qCustomerId =(long) 0;
              		  else
              			qCustomerId =Long.valueOf(rule.getData()) ;
                }
                
                else if (rule.getField().equals("numberOfCopperStrands")){
            	  if(rule.getData()=="" || rule.getData()==null)
            		  qNumberOfCopperStrands =0;
            		  else
            	   qNumberOfCopperStrands =Integer.parseInt(rule.getData()) ;
              }
               else if (rule.getField().equals("copperkey"))
                	qCopperKey =rule.getData() ; 
               else if (rule.getField().equals("odLabel"))
            	   qOdLabel =rule.getData() ; 
               else if (rule.getField().equals("mainColour"))
            	   qMainColour =rule.getData() ; 
               else if (rule.getField().equals("innerColor"))
             	   qInnerColor =rule.getData() ; 
               else if (rule.getField().equals("cableStdKey"))
             	   qCableStdKey =rule.getData() ; 
               else if (rule.getField().equals("layLength"))
             	   qLayLength =rule.getData() ; 
               else if (rule.getField().equals("layType"))
             	   qLayType =rule.getData() ; 
               else if (rule.getField().equals("productKey"))
             	   qProductKey =rule.getData() ;
               else if (rule.getField().equals("orderAcceptanceDate"))
            	   qOrderAcceptanceDate =rule.getData() ;
               else if (rule.getField().equals("orderAcceptanceDateTo"))
            	   qOrderAcceptanceDateTo =rule.getData() ;
                
         }//end of for loop
        String orderAccDate=null;
        if(qOrderAcceptanceDate!=null && qOrderAcceptanceDate!="")
        orderAccDate=qOrderAcceptanceDate.substring(6,10)+"-"+qOrderAcceptanceDate.substring(3,5)+"-"+qOrderAcceptanceDate.substring(0,2);
        
        String orderAccDateTo=null;
        if(qOrderAcceptanceDateTo!=null && qOrderAcceptanceDateTo!="")
        orderAccDateTo=qOrderAcceptanceDateTo.substring(6,10)+"-"+qOrderAcceptanceDateTo.substring(3,5)+"-"+qOrderAcceptanceDateTo.substring(0,2);
        /*List soItem of type SalesOrderItem initialized to null*/
        List<SalesOrderItem> soItem = null;
        /*Method to fetch StoreRegister items based on filtering params*/
        soItem=orderDetailsService.fetchBySearch(qOrderId, qCustomerId,qNumberOfCopperStrands,
                qCopperKey,qOdLabel,qMainColour,qInnerColor,
                qCableStdKey,qLayLength,qLayType,qProductKey,qItemCode,orderAccDate,orderAccDateTo,pagenumber,rows,sortColName,sortOrder,reportType);
        List<SalesOrderItem> pagedList;
        int fromIndex = Math.min(soItem.size(), pagenumber * rows);
        int toIndex = Math.min(soItem.size(), fromIndex + rows);
        
        if (fromIndex == 0 && toIndex == (soItem.size() - 1))
        {
            pagedList = soItem;
        }
        else
        {
           pagedList = soItem.subList(fromIndex, toIndex);
        }
        /*Set paged salesorder items response to SalesOrderItemsDTO*/
       // List<SalesOrderItemsDTO> soitemsDto = SalesOrderItemMapper.map(pagedList);
        
        List<SalesOrderItemsDTO> soitemsDto = convertToDTO(pagedList);
        
        
        
        /*Intialize JQ grid response of type SalesOrderItemsDTO*/
        JqgridResponse<SalesOrderItemsDTO> response = new JqgridResponse<SalesOrderItemsDTO>();
        response.setRows(soitemsDto);
        response.setRecords(Long.valueOf(soItem.size()).toString());
        if(soItem.size()>0)
        response.setTotal(Integer.valueOf((int)Math.ceil(Double.valueOf(soItem.size())/Double.valueOf(rows.toString()))).toString());
        else
        response.setTotal("0");
        response.setPage(Integer.valueOf(pagenumber+1).toString());
      return response;
   }
		/**
		   * This method to set sales order item list to SalesOrderItemsDTO
		   * @param List<SalesOrderItem> soItems
		   * @return List<SalesOrderItemsDTO>
		   */
		private List<SalesOrderItemsDTO> convertToDTO(List<SalesOrderItem> soItems) {
		List<SalesOrderItemsDTO> soItemDTOs = new ArrayList<>();
		for(SalesOrderItem salesOrderItem : soItems) {
			/*Creating new instance of SalesOrderItemsDTO*/
			SalesOrderItemsDTO soItemDTO = new SalesOrderItemsDTO();
		    soItemDTO.setOrderDetailId(salesOrderItem.getOrderDetailId());
			
			if(salesOrderItem.getOrder().getOrderAcceptanceDate()!=null)
				soItemDTO.setOrderAcceptanceDate(Utility.formDateFormatter.print(salesOrderItem.getOrder().getOrderAcceptanceDate().getTime()));
			
			soItemDTO.setOrderId(salesOrderItem.getOrder().getOrderId());
			soItemDTO.setCustomerId(salesOrderItem.getOrder().getCustomer().getCustomerId());
			soItemDTO.setCustomerName(salesOrderItem.getOrder().getCustomer().getCustomerName());	
			soItemDTO.setCustomerCode(salesOrderItem.getOrder().getCustomer().getCustomerCode());
			soItemDTO.setStatus(salesOrderItem.getOrder().getOrderStatus().getStatus());
			
			soItemDTO.setItemId(salesOrderItem.getItem().getItemId());
			soItemDTO.setItemCode(salesOrderItem.getItem().getItemCode());
			soItemDTO.setNumberOfCopperStrands(salesOrderItem.getItem().getNumberOfCopperStrands());
			
			String cuKey=String.valueOf((Double.valueOf(salesOrderItem.getItem().getCopperStrandDiameter().getCopperkey()))/1000);
			soItemDTO.setCopperkey(cuKey);
			
			String od=String.valueOf(Double.valueOf(salesOrderItem.getItem().getOuterDiameter())/100) ;
			soItemDTO.setOuterDiameter(od);
			soItemDTO.setOdLabel(salesOrderItem.getItem().getOdLabel());
			soItemDTO.setMainColour(salesOrderItem.getItem().getMainColour().getColor());
			soItemDTO.setInnerColour(salesOrderItem.getItem().getInnerColour().getColor());
			soItemDTO.setCableStdKey(salesOrderItem.getItem().getCableStdPvc().getCableStdKey());
			soItemDTO.setProductKey(salesOrderItem.getItem().getProductType().getProductKey());
			soItemDTO.setLayType(salesOrderItem.getItem().getLayType());
			soItemDTO.setLayLength(salesOrderItem.getItem().getLayLength());
		    soItemDTO.setItemDescription(salesOrderItem.getItem().getItemDescription());
			soItemDTO.setQuantity(salesOrderItem.getQuantity());
			soItemDTO.setBalanceQty(salesOrderItem.getBalanceQty());
			soItemDTO.setBundleSize(salesOrderItem.getBundleSize());
			soItemDTO.setCompletedQty(salesOrderItem.getCompletedQty());
			soItemDTO.setProductionQty(salesOrderItem.getProductionQty());
			soItemDTO.setDispatchedQty(salesOrderItem.getDispatchedQty());
			soItemDTO.setWoQty((double)0);
			soItemDTO.setUnit(salesOrderItem.getItem().getUnit().getUnits());
			soItemDTO.setStatus(salesOrderItem.getOrder().getOrderStatus().getStatus());
			soItemDTO.setPvcWeight(salesOrderItem.getPvcWeight());
			soItemDTO.setWeight(salesOrderItem.getWeight());
			/*String unitType=null;
			  String units=salesOrderItem.getItem().getUnit().getUnits();
			  if(units.equalsIgnoreCase("Kgs")||units.equalsIgnoreCase("Kg"))
					  unitType="o.weight";
				  else  if(units.equalsIgnoreCase("mts"))
					  unitType="o.stockQty";
				  else
					  unitType="o.stockQty"; 
	
		    String itemCode=salesOrderItem.getItem().getItemCode();
			Long customerId=salesOrderItem.getOrder().getCustomer().getCustomerId();
			Double sameCustomerStockQty=0.0;
			Double sameItemStockQty=0.0;
			if(unitType!=null && unitType!=""){
			sameCustomerStockQty=storeRegisterService.fetchStockQty(customerId, itemCode,unitType);
			sameItemStockQty=storeRegisterService.fetchItemStockQty(customerId, itemCode,unitType);
			}
			Double finalQtyLevel=0.0;
			if(sameCustomerStockQty!=null && sameItemStockQty!=null )
				finalQtyLevel=sameCustomerStockQty+sameItemStockQty;
			soItemDTO.setDelivered(String.valueOf(finalQtyLevel));
			
*/			Long itemIds=salesOrderItem.getItem().getItemId();
			List<StoreRegister>storeRegList=storeRegisterService.findBySalesorderItemItemItemId(itemIds);
		    if(storeRegList.size()>0)
			   soItemDTO.setDelivered("Yes");
		    else
		       soItemDTO.setDelivered("No");	
			soItemDTOs.add(soItemDTO);
			}//end of for loop
		
		return soItemDTOs;
	}
		/**
		   * edit functionality of sales order items for workorder
		   * @param id,oper,quantity,balanceQty,productionQty,woQty
		   * @return StatusResponse
		   */
	@RequestMapping(value = "/editFunc", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	StatusResponse crud(@RequestParam Long id, @RequestParam String oper,
			@RequestParam(required = false) Double quantity,
			@RequestParam(required = false) Double balanceQty,
			@RequestParam(required = false) Double productionQty,
			@RequestParam(required = false) String woQty) {

		Boolean result = false;
		Boolean patternMatch = false;
		if (oper.equalsIgnoreCase("edit")) {
			String decimalPattern = "((-|\\+)?[0-9]+(\\.[0-9]+)?)+";
			patternMatch = Pattern.matches(decimalPattern, woQty);
		}// end of if(oper.equalsIgnoreCase("edit")) condition

		if (patternMatch == true) {
			if (woQty != null) {

				Double validWoQty = Double.valueOf(woQty);
				if (validWoQty == 0) {
					validWoQty = balanceQty;
				}//end of if (validWoQty == 0) condition

				if (validWoQty > balanceQty) {
					validWoQty = balanceQty;
				}//end of if (validWoQty > balanceQty) condition
				/*Method to fetch sales order items based ids*/
				List<SalesOrderItem> soItemList = orderDetailsService
						.findById(id);
				if (soItemList.size() > 0) {
					/*Creating new instance of SalesOrderItemsDTO*/
					SalesOrderItemsDTO soItemDTO = new SalesOrderItemsDTO();
					soItemDTO.setOrderDetailId(soItemList.get(0)
							.getOrderDetailId());

					if (soItemList.get(0).getOrder().getOrderAcceptanceDate() != null)
						soItemDTO
								.setOrderAcceptanceDate(Utility.formDateFormatter
										.print(soItemList.get(0).getOrder()
												.getOrderAcceptanceDate()
												.getTime()));
					soItemDTO.setOrderId(soItemList.get(0).getOrder()
							.getOrderId());
					soItemDTO
							.setItemId(soItemList.get(0).getItem().getItemId());
					soItemDTO.setItemCode(soItemList.get(0).getItem()
							.getItemCode());
					soItemDTO.setQuantity(soItemList.get(0).getQuantity());
					soItemDTO.setBalanceQty(soItemList.get(0).getBalanceQty());
					soItemDTO.setWeight(soItemList.get(0).getWeight());
					soItemDTO.setBundleSize(soItemList.get(0).getBundleSize());
					soItemDTO.setRate(soItemList.get(0).getRate());
					soItemDTO.setProductionQty(soItemList.get(0)
							.getProductionQty());
					soItemDTO.setWoQty(validWoQty);
					soItemDTO.setCompletedQty(soItemList.get(0)
							.getCompletedQty());
					soItemDTO.setDispatchedQty(soItemList.get(0)
							.getDispatchedQty());
					soItemDTO.setUnit(soItemList.get(0).getItem().getUnit()
							.getUnits());
					soItemDTO.setUpdatedBy(soItemList.get(0).getUpdatedBy());
					soItemDTO.setUpdatedTime(soItemList.get(0).getUpdatedTime()
							.toString());
					soItemDTO.setPvcWeight(soItemList.get(0).getPvcWeight());
					SalesOrderItem soItem = soItemDTO.getOrderDetail();
					result = orderDetailsService.update(soItem);
				}//end of if (soItemList.size() > 0) condition
			}//end of if (woQty != null) condition
		}//end of if (patternMatch == true) condition
		return new StatusResponse(result);

	}
	/**
	   * method to check if the item quantity has been sent to work order or not
	   * @param model,customerName,customerId,itemCode,itemId
	   * @return List<Double> stockQtyList
	   */
	@RequestMapping(value="/fetchQtyLevels" , method = RequestMethod.POST)
	public @ResponseBody
	List<Double> fetchStockQuantity(Model model,
			@RequestParam String customerName,
			@RequestParam Long customerId,
			@RequestParam String itemCode,
			@RequestParam Long itemId){
		
		  List<Item>itemList=itemService.findByItemId(itemId);
		  String unitType=null;
		  if(itemList.size()>0){
			  if(itemList.get(0).getUnit().getUnits().equalsIgnoreCase("Kgs")||itemList.get(0).getUnit().getUnits().equalsIgnoreCase("Kg"))
				  unitType="o.weight";
			  else  if(itemList.get(0).getUnit().getUnits().equalsIgnoreCase("mts"))
				  unitType="o.stockQty";
			  else
				  unitType="o.stockQty"; 
		  }
			/*Initialization of empty List of type double*/
			List<Double> stockQtyList=new ArrayList<Double>();
		  if(unitType!=null){
			Double sameCustomerStockQty=storeRegisterService.fetchStockQty(customerId, itemCode,unitType);
			Double sameItemStockQty=storeRegisterService.fetchItemStockQty(customerId, itemCode,unitType);
			Double sameCustomerPdnQty=orderDetailsService.fetchPdnQty(customerId, itemCode);
			Double sameItemPdnQty=orderDetailsService.fetchItemPdnQty(customerId, itemCode);
	  if(sameCustomerStockQty!=null){
			stockQtyList.add(sameCustomerStockQty);
		}
		else stockQtyList.add(Double.valueOf(0)); 
		stockQtyList.add(sameItemStockQty);
		
		if(sameCustomerPdnQty!=null)
			stockQtyList.add(sameCustomerPdnQty);
		else
			stockQtyList.add(Double.valueOf(0));
		
		if(sameItemPdnQty!=null)
			stockQtyList.add(sameItemPdnQty);
		else
			stockQtyList.add(Double.valueOf(0));
			
	}	
		  return stockQtyList;	}
}
