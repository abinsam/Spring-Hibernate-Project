package org.balajicables.salesmanager.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.DecimalFormat;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
import javax.annotation.Resource;
import org.balajicables.salesmanager.CustomUser;
import org.balajicables.salesmanager.common.JqgridResponse;
import org.balajicables.salesmanager.common.MailMail;
import org.balajicables.salesmanager.common.SalesOrderUpdate;
import org.balajicables.salesmanager.common.StatusResponse;
import org.balajicables.salesmanager.dto.AssortedRateDTO;
import org.balajicables.salesmanager.dto.OrderDTO;
import org.balajicables.salesmanager.dto.SalesOrderItemsDTO;
import org.balajicables.salesmanager.repository.UserRepository;
import org.balajicables.salesmanager.model.AssortedRate;
import org.balajicables.salesmanager.model.Customer;
import org.balajicables.salesmanager.model.DeliveryChallanItems;
import org.balajicables.salesmanager.model.Item;
import org.balajicables.salesmanager.model.OrderStatus;
import org.balajicables.salesmanager.model.Role;
import org.balajicables.salesmanager.model.SalesOrder;
import org.balajicables.salesmanager.model.SalesOrderItem;
import org.balajicables.salesmanager.model.User;
import org.balajicables.salesmanager.model.WorkOrderItems;
import org.balajicables.salesmanager.model.WorkOrderOutput;
import org.balajicables.salesmanager.service.AssortedRateService;
import org.balajicables.salesmanager.service.CustomerService;
import org.balajicables.salesmanager.service.DeliveryChallanItemsService;
import org.balajicables.salesmanager.service.ItemService;
import org.balajicables.salesmanager.service.OrderDetailsService;
import org.balajicables.salesmanager.service.OrderService;
import org.balajicables.salesmanager.service.OrderStatusService;
import org.balajicables.salesmanager.service.WorkOrderItemService;
import org.balajicables.salesmanager.service.WorkOrderOutputService;
import org.balajicables.salesmanager.utils.Utility;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.data.domain.Page;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
/**
  * This class demonstrates Sales order Items module.
  * @author Abin Sam
*/
@Controller
@RequestMapping("/salesItemsDetails")
public class SalesItemController {
	@Resource 
	private OrderService orderService;
	@Resource 
	private ItemService itemService;
	@Resource
	private OrderDetailsService orderDetailsService;
	@Resource
	private OrderStatusService orderStatusService;
	@Resource 
	private UserRepository userRepository;
	@Resource
	private AssortedRateService assortedRateService;
	@Resource
	private WorkOrderItemService workOrderItemService;
	@Resource
	private WorkOrderOutputService workOrderOutputService;
	@Resource
	private CustomerService customerService;
	@Resource
	private DeliveryChallanItemsService deliveryChallanItemsService;
	
	 /**
	   * This method returns salesOrdersItems.jsp.
	   * @RequestParam orderId
	   * @param Model to set the attribute.
	   * @return salesOrdersItems.jsp.
	   */
	@RequestMapping(method = RequestMethod.GET)
	public String getSalesItemPage(Model model,
	         @RequestParam(value="orderId") String orderId) {
		/*Method to get name of the person who has logged in*/
		CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		/*Method to get username of the person who has logged in*/
	 	User users = userRepository.findByUserName(user.getUsername());
		/*Method to get role of the person who has logged in*/
	 	List<Role> roles = users.getRoles();
	 	/*Method to fetch list of sales orders */
	    List<SalesOrder>soOrderList=orderService.findBySalesOrderNoId(orderId);
	    String mailSent="";
	    String statusValue="";
        String customerName="";
        String poNo="";
        String orderRecDate="";
        String orderAcceptanceDate="";
        String orderDeliveryDate="";
        String modeOfReceipt="";

	    if(soOrderList.size()>0){
	       	statusValue=soOrderList.get(0).getOrderStatus().getStatus();
	    	customerName=soOrderList.get(0).getCustomer().getCustomerName();
	    	poNo=soOrderList.get(0).getPoDetails();
	    	if(soOrderList.get(0).getOrderRecDate()!=null)
	    	   orderRecDate=Utility.formDateFormatter.print(soOrderList.get(0).getOrderRecDate().getTime());
	      	if(soOrderList.get(0).getOrderAcceptanceDate()!=null)
	      		orderAcceptanceDate=Utility.formDateFormatter.print(soOrderList.get(0).getOrderAcceptanceDate().getTime());
	     	if(soOrderList.get(0).getOrderDeliveryDate()!=null)
	     		orderDeliveryDate=Utility.formDateFormatter.print(soOrderList.get(0).getOrderDeliveryDate().getTime());
	     	modeOfReceipt=soOrderList.get(0).getModeOfReceipt();
	     	mailSent=soOrderList.get(0).getMailStatus();
	    	
	    }//end of if(soOrderList.size()>0)
		model.addAttribute("role",roles.get(0).getAuthority());
    	model.addAttribute("orderId", orderId);
		model.addAttribute("statusValue", statusValue);
		model.addAttribute("customerName",customerName);
		model.addAttribute("poNo",poNo);
		model.addAttribute("orderRecDate",orderRecDate);
		model.addAttribute("orderAcceptanceDate",orderAcceptanceDate);
		model.addAttribute("orderDeliveryDate",orderDeliveryDate);
		model.addAttribute("modeOfReceipt",modeOfReceipt);
		model.addAttribute("mailSent",mailSent);
		
       List<SalesOrder>soList=orderService.findBySalesOrderNoId(orderId);
		ArrayList<String> assortedItemList = new ArrayList<>();
		List<SalesOrderItem> soItemList=orderDetailsService.findByOrderId(orderId);
		if(soItemList.size()>0){
		for (int iterator = 0; iterator < soItemList.size(); iterator++) {
			String assortedItem = soItemList.get(iterator).getItem().getAssortedType();

			if (!assortedItemList.contains(assortedItem)) {
				assortedItemList.add(assortedItem);
			}

		}}
		model.addAttribute("assortedItemList",assortedItemList);
		
		List<OrderStatus> orderStatusList=orderStatusService.findAll();
		if(orderStatusList.size()>0){
			for(int i=0;i<orderStatusList.size();i++){
				if(orderStatusList.get(i).getStatus().equalsIgnoreCase("Created"))
					orderStatusList.remove(i);
			}
		}
		
		List<OrderStatus> officeList = new ArrayList<OrderStatus>();

	 	for(int i=0; i<roles.size();i++){
	 		if(roles.get(i).getAuthority().equalsIgnoreCase("ROLE_ADMIN")){
	 			for(int j=0;j<orderStatusList.size();j++){
	 				if(orderStatusList.get(j).getStatus().equalsIgnoreCase(statusValue)){
	 					orderStatusList.remove(orderStatusList.get(j));
	 				}
	 			}
	 			model.addAttribute("status",orderStatusList);
	 			
			}else if(roles.get(i).getAuthority().equalsIgnoreCase("ROLE_OFFICE")){
				for(int j=0;j<orderStatusList.size();j++){
	 				if(orderStatusList.get(j).getStatus().equalsIgnoreCase("Pending") || orderStatusList.get(j).getStatus().equalsIgnoreCase("Approved For Prodn")
	 						 || orderStatusList.get(j).getStatus().equalsIgnoreCase("Dispatched") || orderStatusList.get(j).getStatus().equalsIgnoreCase("Cancelled")){
	 					officeList.add(orderStatusList.get(j));
	 				}
	 			}
				for(int k=0;k<officeList.size();k++){
					if(officeList.get(k).getStatus().equalsIgnoreCase(statusValue)){
						officeList.remove(officeList.get(k));
					}
				}
				for(int k=0;k<officeList.size();k++){
					if(statusValue.equalsIgnoreCase("Approved")){
						officeList.removeAll(officeList);
					}
				}
				
				model.addAttribute("status",officeList);
			}
	 	}//end of for(int i=0; i<roles.size();i++)
		if(soList.size()>0){
		model.addAttribute("mailSent",soList.get(0).getMailStatus());
		model.addAttribute("lmeDetails",soList.get(0).getLmeDetails());
		}
	
		return "salesOrdersItems";
	}
	 /**
	   * This Method to fetch sales order items record based on sales order number
	   * @RequestParam orderId,itemType,search,filters,pageNumber,rowsPerPage,sortColName,sortOrder
	   * @return response
	   */
	@RequestMapping(value="/items/{orderId}", produces="application/json", method=RequestMethod.POST)
	public @ResponseBody
	JqgridResponse<SalesOrderItemsDTO> items(
			@PathVariable("orderId") String orderId,
		    @RequestParam(required=false) String itemType,
   	        @RequestParam("_search") Boolean search,
    		@RequestParam(value="filters", required=false) String filters,
	    	@RequestParam(value = "page", required = false) Integer pageNumber,
			@RequestParam(value = "rows", required = false) Integer rowsPerPage,
			@RequestParam(value = "sidx", required = false) String sortColName,
			@RequestParam(value = "sord", required = false, defaultValue = "asc") String sortOrder) {
		
			if(sortColName.equalsIgnoreCase("itemCode")){
				sortColName="items.itemCode";
			}
		
			if(sortColName.equalsIgnoreCase("itemDescription")){
				sortColName="items.itemDescription";
			}
			if(sortColName.equalsIgnoreCase("unit")){
				sortColName="items.unit.units";
			}
			/*orderOutput Page of type SalesOrderItem initialized to null*/
			Page<SalesOrderItem> orderOutput =null;
		    if(itemType!=null && itemType!=""){
			orderOutput = orderDetailsService.getSoItemAssortedType(orderId,pageNumber - 1,
					rowsPerPage, sortColName, sortOrder,itemType);
		    }
		    else{

			orderOutput = orderDetailsService.getPagedSalesOrderItems(orderId,pageNumber - 1,
			rowsPerPage, sortColName, sortOrder);

		}
		/*Intialize JQ grid response of type SalesOrderItemsDTO*/
		JqgridResponse<SalesOrderItemsDTO> response = new JqgridResponse<SalesOrderItemsDTO>();
		/*Method to set sales order item list to SalesOrderItemsDTO*/
		List<SalesOrderItemsDTO> salesOrderItemDTOs = convertToItemDTO(orderOutput.getContent(),orderId);
		response.setRows(salesOrderItemDTOs);
		response.setRecords(Long.valueOf(orderOutput.getTotalElements()).toString());
		response.setTotal(Long.valueOf(orderOutput.getTotalPages()).toString());
		response.setPage(Integer.valueOf(orderOutput.getNumber()+1).toString());
		return response;	
	}
	 /**
	   * This Method to set sales order item list to SalesOrderItemsDTO
	   * @param List<SalesOrderItem> SalesOrderItem
	   * @return List<SalesOrderItemsDTO> response
	   */
    private List<SalesOrderItemsDTO> convertToItemDTO(List<SalesOrderItem> salesOrderItem,String salesOrderId) {
	List<SalesOrderItemsDTO> salesOrderItemrDTOs = new ArrayList<>();
	for(SalesOrderItem orderItem : salesOrderItem) {
		SalesOrderItemsDTO salesOrderItemsDTO = new SalesOrderItemsDTO();
		salesOrderItemsDTO.setOrderDetailId(orderItem.getOrderDetailId());
		salesOrderItemsDTO.setItemId(orderItem.getItem().getItemId());
		salesOrderItemsDTO.setItemCode(orderItem.getItem().getItemCode());
		salesOrderItemsDTO.setItemDescription(orderItem.getItem().getItemDescription());
		salesOrderItemsDTO.setBalanceQty(orderItem.getBalanceQty());
		salesOrderItemsDTO.setQuantity(orderItem.getQuantity());
		salesOrderItemsDTO.setRate(orderItem.getRate());
		salesOrderItemsDTO.setUnitId(orderItem.getUnitId());
	    salesOrderItemsDTO.setOrderId(salesOrderId);
	    salesOrderItemsDTO.setWoQty(orderItem.getWoQty());
	    salesOrderItemsDTO.setCompletedQty(orderItem.getCompletedQty());
	    salesOrderItemsDTO.setProductionQty(orderItem.getProductionQty());
	    salesOrderItemsDTO.setDispatchedQty(orderItem.getDispatchedQty());
	    salesOrderItemsDTO.setUnit(orderItem.getItem().getUnit().getUnits());
	    salesOrderItemsDTO.setBundleSize(orderItem.getBundleSize());
	    salesOrderItemsDTO.setWeight(orderItem.getWeight());
	    salesOrderItemsDTO.setPvcWeight(orderItem.getPvcWeight());
		salesOrderItemrDTOs.add(salesOrderItemsDTO);
		}
	return salesOrderItemrDTOs;
}

@RequestMapping(value = "/modifyitems", produces = "application/json", method = RequestMethod.POST)
public @ResponseBody
StatusResponse modifyItems(@RequestParam Long id,
		@RequestParam String oper,
		@RequestParam(required = false) String orderId,
		@RequestParam(required = false) Long itemId,
    	@RequestParam(required = false) String itemCode,
		@RequestParam(required = false) String rate,
		@RequestParam(required = false) String quantity,
		@RequestParam(required = false) Double balanceQty,
		@RequestParam(required = false) Double woQty,
		@RequestParam(required = false) Double completedQty,
		@RequestParam(required = false) Double productionQty,
		@RequestParam(required = false) Double dispatchedQty,
		@RequestParam(required = false) String units,
		@RequestParam(required = false) String bundleSize,
		@RequestParam(required = false) Double pvcWeight
		) {

	Boolean updateSalesOrder=false;
	boolean quantityMatch = false;
	boolean bundleSizeMatch=false;
	boolean rateMatch=false;
  if(rate==null || rate==""){
	  rate="0";
  }
	String decimalPattern = "((-|\\+)?[0-9]+(\\.[0-9]+)?)+";  
	 quantityMatch = Pattern.matches(decimalPattern, quantity);
	 rateMatch=Pattern.matches(decimalPattern, rate);
	  if (bundleSize.matches("[0-9]+")){
		  bundleSizeMatch=true;
	    }
	if(quantityMatch==true && bundleSizeMatch==true && rateMatch==true){
		Integer newBundleSize=Integer.parseInt(bundleSize);
		Double newQuantity=Double.valueOf(quantity);
		Float newRate=Float.valueOf(rate);
		  
	if(newRate==null){
		newRate=(float) 0;
	}
	if(newBundleSize==null){
		newBundleSize=0;
	}
	Double soQty=0.0;
	  List<WorkOrderItems> woItemsList=workOrderItemService.findBySalesOrderItem(id);
	 if(woItemsList.size()>0){
		 soQty=woItemsList.get(0).getSalesOrderItem().getQuantity();
		 newQuantity=soQty;
	 }
		CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();;

 	String userName = user.getFirstName()+" "+user.getLastName();
	Boolean updateSoItemRateBundle=false;
 	   List<SalesOrder> soOrderDetailsList=null;
	   List<SalesOrderItem> soItemList=null;
	    Double inputQty=0.0;
		Boolean result = false;
		Boolean updateAssortedMaster=false;
		AssortedRate createdAssortedRate=null;
	     String assortedType="";
         Double weight=0.0;

    SalesOrderItemsDTO soItemDto = new SalesOrderItemsDTO();
	if(id != null) {
		soItemDto.setOrderDetailId(id);
		
	}
	List <SalesOrderItem> soItemsList=orderDetailsService.findById(id);
	//Double totQty=0.0;
	if(soItemsList.size()>0){
		 //  totQty=soItemsList.get(0).getQuantity();
		   assortedType=soItemsList.get(0).getItem().getAssortedType();
	}

    balanceQty=newQuantity-(completedQty+productionQty+dispatchedQty);
    if(balanceQty<0)
    	balanceQty=0.0;
    
    
	List <Item> itemIdList=itemService.findByItemCode(itemCode);
    if(itemIdList.size()>0){
		//String productKey=itemIdList.get(0).getProductType().getProductKey();
		String unitVal=itemIdList.get(0).getUnit().getUnits();
		Double noOfCuStrand=(double)itemIdList.get(0).getNumberOfCopperStrands();
		Double stranddDiameter=Double.valueOf(itemIdList.get(0).getCopperStrandDiameter().getCopperkey())/1000;
		DecimalFormat threeDForm=new DecimalFormat("0.000");
    	/*if(productKey.equalsIgnoreCase("BA") || productKey.equalsIgnoreCase("BC") || productKey.equalsIgnoreCase("CS") ||
				   productKey.equalsIgnoreCase("MS")|| productKey.equalsIgnoreCase("PA") || productKey.equalsIgnoreCase("PL") || productKey.equalsIgnoreCase("PS") ||
				   productKey.equalsIgnoreCase("PV") || productKey.equalsIgnoreCase("RA") || productKey.equalsIgnoreCase("RB") ||  productKey.equalsIgnoreCase("RI")){
	*/	if(unitVal.equalsIgnoreCase("Kgs") || unitVal.equalsIgnoreCase("Kg") ){
		   weight=newQuantity;
		}else{
			String roundUpWeight=threeDForm.format(noOfCuStrand*stranddDiameter*stranddDiameter*0.6985*1.015);
			   String weightVal=threeDForm.format((Double.valueOf(roundUpWeight)/100)*newQuantity);
			   weight=Double.valueOf(weightVal);
	   }		
	}  
    
	 soItemDto.setItemId(itemId);
	 soItemDto.setItemCode(itemCode);
	 soItemDto.setOrderId(orderId);
  	 soItemDto.setRate(newRate);
	 soItemDto.setBalanceQty(balanceQty);
	 soItemDto.setQuantity(newQuantity);
     soItemDto.setWoQty(woQty);
     soItemDto.setCompletedQty(completedQty);
     soItemDto.setProductionQty(productionQty);
     soItemDto.setDispatchedQty(dispatchedQty);
     soItemDto.setUpdatedBy(userName);
     soItemDto.setUnit(units);
     soItemDto.setBundleSize(newBundleSize);
     soItemDto.setWeight(weight);
     soItemDto.setPvcWeight(weight);
     if(pvcWeight!=null)
    	 soItemDto.setPvcWeight(pvcWeight);
     else
    	 soItemDto.setPvcWeight(weight);
     SalesOrderItem itemOrder = soItemDto.getOrderDetail();
 	switch (oper) {
 	case "edit":
 		result = orderDetailsService.update(itemOrder);
 		break;
 	case "del":
 	
 	}//end of switch case
    /*Method to fetch sales order list */
     List<SalesOrder>soOrderList=orderService.findBySalesOrderNoId(orderId);
     
      String customerCode="";
      String customerName="";
      String []orderStatus={"Approved For Prodn","Pending"};
      if(soOrderList.size()>0){
    	
    	 customerCode=soOrderList.get(0).getCustomer().getCustomerCode();
    	 customerName=soOrderList.get(0).getCustomer().getCustomerName();
     }//end of if(soOrderList.size()>0) condition

     List<AssortedRate>assortedRateList=assortedRateService.findByCustomerCodeAndAssortedType(customerCode, assortedType);
     List<SalesOrderItem> soItemToUpdate=orderDetailsService.findByCustomerAssortedTypeStatusIn(customerName, assortedType, orderStatus);

     if(assortedRateList.size()>0){
    	 AssortedRateDTO assortedRateDTO=new AssortedRateDTO();
    	assortedRateDTO.setAssortedRateId(assortedRateList.get(0).getAssortedRateId());
 		assortedRateDTO.setCustomerCode(customerCode);
 		assortedRateDTO.setAssortedType(assortedType);
 		assortedRateDTO.setBundleSize(newBundleSize.longValue());
 		assortedRateDTO.setRate(newRate);
 		AssortedRate assortedRate=assortedRateDTO.getAssortedRate();
 		updateAssortedMaster=assortedRateService.update(assortedRate);
 		
     }//end of if(assortedRateList.size()>0) condition
     else{
    	    AssortedRateDTO assortedRateDTO=new AssortedRateDTO();
    		assortedRateDTO.setCustomerCode(customerCode);
    		assortedRateDTO.setAssortedType(assortedType);
    		assortedRateDTO.setBundleSize(newBundleSize.longValue());
    		assortedRateDTO.setRate(newRate);
    		AssortedRate assortedRate=assortedRateDTO.getAssortedRate();
    	    createdAssortedRate=assortedRateService.create(assortedRate);
    		
     }
		if((updateAssortedMaster==true || createdAssortedRate!=null) && soItemToUpdate.size()>0 && result==true){
		
	    for(int j=0;j<soItemToUpdate.size();j++){
			SalesOrderItemsDTO soItemToUpdateDTO=new SalesOrderItemsDTO();
			soItemToUpdateDTO.setOrderDetailId(soItemToUpdate.get(j).getOrderDetailId());
			soItemToUpdateDTO.setOrderId(soItemToUpdate.get(j).getOrder().getOrderId());
			soItemToUpdateDTO.setItemId(soItemToUpdate.get(j).getItem().getItemId());
			soItemToUpdateDTO.setQuantity(soItemToUpdate.get(j).getQuantity());
			soItemToUpdateDTO.setBalanceQty(soItemToUpdate.get(j).getBalanceQty());
			soItemToUpdateDTO.setUnitId(soItemToUpdate.get(j).getUnitId());
			soItemToUpdateDTO.setBundleSize(newBundleSize);
			soItemToUpdateDTO.setRate(newRate);
			soItemToUpdateDTO.setWoQty(soItemToUpdate.get(j).getWoQty());
			soItemToUpdateDTO.setCompletedQty(soItemToUpdate.get(j).getCompletedQty());
			soItemToUpdateDTO.setItemCode(soItemToUpdate.get(j).getItemCode());
			soItemToUpdateDTO.setProductionQty(soItemToUpdate.get(j).getProductionQty());
			soItemToUpdateDTO.setDispatchedQty(soItemToUpdate.get(j).getDispatchedQty());
			soItemToUpdateDTO.setUpdatedBy(soItemToUpdate.get(j).getUpdatedBy());
			soItemToUpdateDTO.setUpdatedTime(soItemToUpdate.get(j).getUpdatedTime().toString());
			soItemToUpdateDTO.setWeight(soItemToUpdate.get(j).getWeight());
			soItemToUpdateDTO.setPvcWeight(soItemToUpdate.get(j).getPvcWeight());
			SalesOrderItem soItemUpdate=soItemToUpdateDTO.getOrderDetail();
			updateSoItemRateBundle=orderDetailsService.update(soItemUpdate);
	     }//end of for loop
	}//end of if((updateAssortedMaster==true || createdAssortedRate!=null) && soItemToUpdate.size()>0 && result==true) condition 
		
	  if(result==true && updateSoItemRateBundle==true){
		  soOrderDetailsList=orderService.findBySalesOrderNoId(orderId);
		    soItemList=orderDetailsService.findByOrderId(orderId);
		    if(soItemList.size()>0){
		    	for(int i=0;i<soItemList.size();i++){
		    		
		    		inputQty=inputQty+soItemList.get(i).getQuantity();
		    		
		    	}//end of for loop
		    }
			if(soOrderDetailsList.size()>0){
		         SalesOrderUpdate soQtyUpdate=new SalesOrderUpdate();
		         SalesOrder soOrder=soQtyUpdate.updateSoOrder(orderId,soOrderDetailsList,inputQty);
		         updateSalesOrder=orderService.update(soOrder);
			}//end of if(soOrderDetailsList.size()>0) condition
			
	  }//end of  if(result==true && updateSoItemRateBundle==true) condition
  }
	return new StatusResponse(updateSalesOrder);
}
/**
 * method to check if rates are present for the salesorder items
 * @param orderId
 * @return List<String> rateStatusMssg
 */
@RequestMapping(value = "/checkRates", produces = "application/json", method = RequestMethod.POST)
public @ResponseBody
List<String> checkRates(@RequestParam String orderId) {
   /*Initialization of empty List of type String*/
   List<String> rateStatusMssg=new ArrayList<>();
   /*Initialization of empty List of type SalesOrderItem*/
   List<SalesOrderItem> soItemRateList=new ArrayList<>();
   /*Method to fetch rate list based on orderId*/
   soItemRateList=orderDetailsService.checkSoItemRates(orderId);
   if(soItemRateList.size()>0){
	   rateStatusMssg.add("rateNotPresent") ;
   }//end of  if(soItemRateList.size()>0) condition
   else 
	   rateStatusMssg.add("rateValid") ;
	return rateStatusMssg;
}
/**
 * Method to generate sales order report
 * @param salesOrderNo
 * @return List<String> rateStatusMssg
 */
@RequestMapping(value = "/salesOrderReport", produces = "application/pdf", method = RequestMethod.GET)

public void SalesOrderReport(@RequestParam(value = "salesOrderNo", required = true) String salesOrderNo,javax.servlet.http.HttpServletResponse response) throws IOException, InterruptedException{
	if(salesOrderNo!=null && salesOrderNo!=""){
	 InputStream inputStream = getClass().getClassLoader().getResourceAsStream("/org/balajicables/salesmanager/report/SalesOrderReport.jrxml");
	 Map<String, Object> hm= new HashMap<String, Object>();
     hm.put("ORDER_ID", salesOrderNo);//setting report parameter
     byte[] content = ReportGenerator.newReportGenerator(inputStream,hm);//calling report parameter
    
	 response.setContentType("application/pdf");
	 response.setHeader("Content-Disposition", "attachment;filename=" + "SalesOrder"+salesOrderNo+".pdf");
	 response.setContentLength(content.length);
     FileCopyUtils.copy(content, response.getOutputStream());
	}//end of if(salesOrderNo!=null && salesOrderNo!="") condition
}
/**
 * send submitted sales order mail
 * @param orderId
 * @return StatusResponse
 */
@RequestMapping(value = "/sendSalesOrderMail", produces = "application/json", method = RequestMethod.POST)
public @ResponseBody
StatusResponse submitInvoice(
		@RequestParam(value = "orderId", required = true) String orderId) throws IOException {

	 List<SalesOrder> soDetails = orderService.findBySalesOrderNoId(orderId);
     Boolean updateSalesOrder=false;
     String pathC = "C:\\ReportPDFs";//temporary  folder for reports
	 File fileC = new File(pathC);//create temp folder
	 
	 if (soDetails.size() > 0) {
		 Long custId=soDetails.get(0).getCustomer().getCustomerId();
		 List<Customer> custDetail=customerService.findById(custId);
		 String emailAddress="";
		 String[] toEmailIds=null;
		 String customer="";
		 String orderRecDate="";
		 String orderAcceptanceDate="";
		 String poDetails="";
		 String modeOfReceipt="";
		 String orderDeliveryDate="";
		 String createdTime="";
		 String targetDate="";
		 String createdBy="";
		 String updatedBy="";
		 String customerCode="";
		 String contactPerson="";
		 String contactNo="";
		 String altContactNo="";
		 String email="";
		 String address="";
		 String city="";
		 String state="";
		 String country="";
		 Integer pincode=0;
		 String vatRegNo="";
		 String cstRegNo="";
		 String eccNo="";
		 String tinNo="";
		 String panNo="";
		 String paymentTerms="";
		 String freight="";
		 String customerName=""; 
		 if(soDetails.get(0).getOrderRecDate()!=null)
			 orderRecDate=Utility.formDateFormatter.print(soDetails.get(0).getOrderRecDate().getTime());
		 if(soDetails.get(0).getOrderDeliveryDate()!=null)
			 orderDeliveryDate=Utility.formDateFormatter.print(soDetails.get(0).getOrderDeliveryDate().getTime());
		 if(soDetails.get(0).getOrderAcceptanceDate()!=null)
			 orderAcceptanceDate=Utility.formDateFormatter.print(soDetails.get(0).getOrderAcceptanceDate().getTime());
		 if(soDetails.get(0).getPoDetails()!=null)
			 poDetails=soDetails.get(0).getPoDetails();
		 if(soDetails.get(0).getModeOfReceipt()!=null)
			 modeOfReceipt=soDetails.get(0).getModeOfReceipt();
		 if(soDetails.get(0).getCreatedTime()!=null)
			 createdTime=soDetails.get(0).getCreatedTime().toString();
		 if(soDetails.get(0).getTargetDate()!=null)
			 orderAcceptanceDate=Utility.formDateFormatter.print(soDetails.get(0).getTargetDate().getTime());		
		 if(soDetails.get(0).getCreatedBy()!=null)
			 createdBy=soDetails.get(0).getCreatedBy();
		 if(soDetails.get(0).getUpdatedBy()!=null)
			 updatedBy=soDetails.get(0).getUpdatedBy();
		 if(soDetails.get(0).getCustomer().getCustomerName()!=null)
			 customerName=soDetails.get(0).getCustomer().getCustomerName();
		 if(soDetails.get(0).getCustomer().getCustomerCode()!=null)
			 customerCode=soDetails.get(0).getCustomer().getCustomerCode();
		 if(soDetails.get(0).getCustomer().getContactPerson()!=null)
			 contactPerson=soDetails.get(0).getCustomer().getContactPerson();
		 if(soDetails.get(0).getCustomer().getContactNo()!=null)
			 contactNo=soDetails.get(0).getCustomer().getContactNo();
		 if(soDetails.get(0).getCustomer().getAltContactNo()!=null)
			 altContactNo=soDetails.get(0).getCustomer().getAltContactNo();
		 if(soDetails.get(0).getCustomer().getEmail()!=null)
			 email=soDetails.get(0).getCustomer().getEmail();
		 if(soDetails.get(0).getCustomer().getAddress()!=null)
			 address=soDetails.get(0).getCustomer().getAddress();
		 if(soDetails.get(0).getCustomer().getCity()!=null)
			 city=soDetails.get(0).getCustomer().getCity();
		 if(soDetails.get(0).getCustomer().getState()!=null)
			 state=soDetails.get(0).getCustomer().getState();
		 if(soDetails.get(0).getCustomer().getCountry()!=null)
			 country=soDetails.get(0).getCustomer().getCountry();
		 if(soDetails.get(0).getCustomer().getPincode()!=null)
			 pincode=soDetails.get(0).getCustomer().getPincode();
		 if(soDetails.get(0).getCustomer().getVatRegNo()!=null)
			 vatRegNo=soDetails.get(0).getCustomer().getVatRegNo();
		 if(soDetails.get(0).getCustomer().getCstRegNo()!=null)
			 cstRegNo=soDetails.get(0).getCustomer().getCstRegNo();
		 if(soDetails.get(0).getCustomer().getEccNo()!=null)
			 eccNo=soDetails.get(0).getCustomer().getEccNo();
		 if(soDetails.get(0).getCustomer().getTinNo()!=null)
			 tinNo=soDetails.get(0).getCustomer().getTinNo();
		 if(soDetails.get(0).getCustomer().getPanNo()!=null)
			 panNo=soDetails.get(0).getCustomer().getPanNo();
		 if(custDetail.size()>0){
			  if(custDetail.get(0).getEmail()!=null)
			  emailAddress= custDetail.get(0).getEmail();
			  if(custDetail.get(0).getCustomerName()!=null)
			  customer=custDetail.get(0).getCustomerName();
		 }//end of if(custDetail.size()>0) condition
		 
			 InputStream inputStreamInvoicePrint = getClass().getClassLoader().getResourceAsStream("/org/balajicables/salesmanager/report/SalesOrderReport.jrxml");
			 Map<String, Object> hm= new HashMap<String, Object>();
		     hm.put("ORDER_ID", orderId);
			 byte[] content = ReportGenerator.newReportGenerator(inputStreamInvoicePrint,hm);
   
			 if(fileC.exists()){
				 System.out.println("folder exists");
                 ReportGenerator.deleteDir(fileC);
                 fileC.mkdir();//create temp folder for report
	          }else{
	             fileC.mkdir();//create temp folder for report
              }
			    String[] fileName={pathC+"\\SalesOrder"+orderId+".pdf"};
				File f = new File(fileName[0]);
				FileOutputStream fos = new FileOutputStream(f);
				fos.write(content, 0, content.length);
                fos.close();  
   
	         if(emailAddress!=null){
	           	toEmailIds = emailAddress.split(";", -1);
	         }//end of  if(emailAddress!=null) condition
	 
        ApplicationContext context =new ClassPathXmlApplicationContext("Spring-Mail.xml");
    
	    if(toEmailIds!=null && orderId!=null && orderId!="" && customer!=null){
	    	
	    	 MailMail mailsender = (MailMail) context.getBean("mailMail");
    	     String templateName="salesOrderTemplate.vm";
    	     HashMap<String, String> model=new HashMap<>();
       	     model.put("ORDER_ID", orderId);  
    	     model.put("ORDER_RECEIVED_DATE", orderRecDate);
    	     model.put("ORDER_ACCEPTANCE_DATE", orderAcceptanceDate);
    	     model.put("PO_DETAILS", poDetails);
    	     model.put("MODE_OF_RECEIPT", modeOfReceipt);
    	     model.put("ORDER_DELIVERY_DATE", orderDeliveryDate);
    	     model.put("CREATED_TIME", createdTime);
    	     model.put("TARGET_DATE", targetDate);
    	     model.put("CREATED_BY", createdBy);
    	     model.put("UPDATED_BY", updatedBy);
    	     model.put("CUSTOMER_NAME", customerName);
       	     model.put("CUSTOMER_CODE", customerCode);
    	     model.put("CUSTOMER_ID", String.valueOf(custId)); 
    	     model.put("CONTACT_PERSON", contactPerson);
    	     model.put("CONTACT_NO", contactNo);
    	     model.put("ALT_CONTACT_NO", altContactNo);
    	     model.put("EMAIL", email);
    	     model.put("ADDRESS", address);
             model.put("CITY", city);
             model.put("STATE", state);
    	     model.put("COUNTRY", country);
    	     model.put("PINCODE",String.valueOf(pincode));
    	     model.put("VAT_REG_NO", vatRegNo);
             model.put("CST_REG_NO", cstRegNo);
             model.put("ECC_NO", eccNo);
    	     model.put("TIN_NO", tinNo);
    	     model.put("PAN_NO", panNo);
    	     model.put("PAYMENT_TERMS", paymentTerms);
             model.put("FRIEGHT", freight);
   	     
             String subject="Sales Order Acceptance :"+orderId+" for Purchase Order No "+poDetails+" dated "+orderRecDate;
			 mailsender.sendEmailsWithAttachment(toEmailIds, subject, fileName, templateName, model);
			 
			 /*Creating a new instance of OrderDTO*/
			 OrderDTO orderDTO= new OrderDTO();
				orderDTO.setOrderId(soDetails.get(0).getOrderId());
				if(soDetails.get(0).getOrderRecDate()!=null)
				orderDTO.setOrderRecDate(Utility.formDateFormatter.print(soDetails.get(0).getOrderRecDate().getTime()));
				if(soDetails.get(0).getOrderDeliveryDate()!=null)
				orderDTO.setOrderDeliveryDate(Utility.formDateFormatter.print(soDetails.get(0).getOrderDeliveryDate().getTime()));
				if(soDetails.get(0).getOrderAcceptanceDate()!=null)
				orderDTO.setOrderAcceptanceDate(Utility.formDateFormatter.print(soDetails.get(0).getOrderAcceptanceDate().getTime()));
				if(soDetails.get(0).getTargetDate()!=null)
				orderDTO.setTargetDate(Utility.formDateFormatter.print(soDetails.get(0).getTargetDate().getTime()));
				orderDTO.setPoDetails(soDetails.get(0).getPoDetails());
				orderDTO.setModeOfReceipt(soDetails.get(0).getModeOfReceipt());
				orderDTO.setOrderStatusId(soDetails.get(0).getOrderStatus().getOrderStatusId());
				orderDTO.setStatus(soDetails.get(0).getOrderStatus().getStatus());
				orderDTO.setCustomerId(soDetails.get(0).getCustomer().getCustomerId());
				if(soDetails.get(0).getCreatedTime()!=null)
				orderDTO.setCreatedTime(soDetails.get(0).getCreatedTime().toString());
				if(soDetails.get(0).getUpdatedTime()!=null)
				orderDTO.setUpdatedTime(soDetails.get(0).getUpdatedTime().toString());
				orderDTO.setUpdatedBy(soDetails.get(0).getUpdatedBy());
				orderDTO.setCreatedBy(soDetails.get(0).getCreatedBy());
				orderDTO.setMailStatus("Yes");
				orderDTO.setLmeDetails(soDetails.get(0).getLmeDetails());
				orderDTO.setInputQuantity(soDetails.get(0).getInputQuantity());
				SalesOrder salesOrder = orderDTO.getOrder();
				updateSalesOrder = orderService.update(salesOrder);

  	}//end of  if(toEmailIds!=null && orderId!=null && orderId!="" && customer!=null) condition

    if(updateSalesOrder==true){
    	 ReportGenerator.deleteDir(fileC);
    }
}//end of if (soDetails.size() > 0) condition
	 return new StatusResponse(updateSalesOrder);

}

/**
 * This Method to fetch work order items record based on sales order item id
 * @RequestParam orderId,itemType,search,filters,pageNumber,rowsPerPage,sortColName,sortOrder
 * @return response
 */
@RequestMapping(value = "/workOrderRecords", produces = "application/json", method = RequestMethod.POST)
public @ResponseBody
List<String> workOrderRecords(@RequestParam(required=false) Long salesOrderItemId) {
	 List<String> workOrderList=new ArrayList<>();
	if(salesOrderItemId!=null){
	List<SalesOrderItem>soItemList=orderDetailsService.findById(salesOrderItemId);
	if(soItemList.size()>0){
	if(soItemList.get(0).getItem().getItemType().equalsIgnoreCase("ITEM")){
		List<WorkOrderItems>woItemList=workOrderItemService.findBySalesOrderItem(salesOrderItemId);
		if(woItemList.size()>0){
			for(int iterator=0;iterator<woItemList.size();iterator++){
				String woNo = woItemList.get(iterator).getProductionWorkOrder().getWorkOrderNo();
		    	if (!workOrderList.contains(woNo)) {
		    		workOrderList.add(woNo);
				}//end of if (!salesOrders.contains(soNo)) loop
			}
		}

	}else{
		List<WorkOrderOutput>woOutputPagedList=workOrderOutputService.findBySalesOrderItem(salesOrderItemId);
		if(woOutputPagedList.size()>0){
			for(int iterator=0;iterator<woOutputPagedList.size();iterator++){
				String woNo = woOutputPagedList.get(iterator).getProductionWorkOrder().getWorkOrderNo();
		    	if (!workOrderList.contains(woNo)) {
		    		workOrderList.add(woNo);
				}//end of if (!salesOrders.contains(soNo)) loop
			}
		}
	}
	}//	end of if(soItemList.size()>0) loop
	/*Method to set work order item list to WorkOrderItemsDTO*/
	
	}
	return workOrderList;	
}

/**
 * This Method to fetch list of delivery challan numbers based on sales order item id
 * @RequestParam orderId,itemType,search,filters,pageNumber,rowsPerPage,sortColName,sortOrder
 * @return response
 */
@RequestMapping(value = "/deliverychallanRecords", produces = "application/json", method = RequestMethod.POST)
public @ResponseBody
List<String> deliveryChallanRecords(@RequestParam(required=false) Long salesOrderItemId) {
	 List<String> dcList=new ArrayList<>();
	 List<String> responseList=new ArrayList<>();
	 List<SalesOrderItem>soItemList=orderDetailsService.findById(salesOrderItemId);
	 if(soItemList.size()>0){
	    Long itemId =  soItemList.get(0).getItem().getItemId();
	    String orderId =  soItemList.get(0).getOrder().getOrderId();
	 
		List<DeliveryChallanItems>deliverychallanList=deliveryChallanItemsService.findByItemItemIdAndDeliveryChallanOrdersOrderId(itemId,orderId);

		if(deliverychallanList.size()>0){
			for(int iterator=0;iterator<deliverychallanList.size();iterator++){
				String dcNo = deliverychallanList.get(iterator).getDeliveryChallan().getDeliveryChallanNo();
		    	if (!dcList.contains(dcNo)) {
		   		    Format formatter = new SimpleDateFormat("dd-MM-yyyy");//date formatter
					Date dcDate = deliverychallanList.get(iterator).getDeliveryChallan().getChallanDate();
					String stringDcDate = formatter.format(dcDate);
		    		dcList.add(dcNo);
		    		responseList.add("DC NO:"+dcNo+" "+"DATE:"+stringDcDate);
				}//end of if (!dcList.contains(dcNo)&&!dcList.contains(stringDcDate)) loop
			}
		}
	 }
	return responseList;	
}
}