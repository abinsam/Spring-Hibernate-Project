package org.balajicables.salesmanager.controller;

import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.balajicables.salesmanager.common.JqgridResponse;
import org.balajicables.salesmanager.dto.OrderDTO;
import org.balajicables.salesmanager.model.OrderStatus;
import org.balajicables.salesmanager.model.SalesOrder;
import org.balajicables.salesmanager.service.OrderService;
import org.balajicables.salesmanager.service.OrderStatusService;
import org.balajicables.salesmanager.utils.Utility;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
/**
 * This class demonstrates SalesOrder Report Module
 * @author 10603708
*/
@Controller
@RequestMapping("/salesOrderReport")

public class SalesOrderReportController {
	
	@Resource
	private OrderService orderService;
	
	@Resource
	private OrderStatusService orderStatusService;
	/**
	   * This method returns salesOrderReport.jsp.
	   * @param Model to set the attribute.
	   * @return salesOrderReport.jsp.
	   */	
	@RequestMapping
	public String salesOrderReport(Model model) {
		List<OrderStatus> orderStatusList=orderStatusService.findAll();
		if(orderStatusList.size()>0){
			for(int k=0;k<orderStatusList.size();k++){
				if(orderStatusList.get(k).getStatus().equalsIgnoreCase("Created"))
					orderStatusList.remove(orderStatusList.get(k));
			}//end of for loop
			
		}//end of if(orderStatusList.size()>0) condition
		model.addAttribute("status",orderStatusList);//set order status to model attribute
		return "salesOrderReport";
	}
	/**
	   * This method to fetch SalesOrder records
	   * Fetch SalesOrder details for grid
	   * @param fromDateString,toDateString,orderStatus,search,filters,pageNumber,rowsPerPage,sortColName,sortOrder
	   * @return JqgridResponse<ScrapDetailsDTO> response
	   */
	@RequestMapping(value="/records", produces="application/json", method=RequestMethod.POST)
	public @ResponseBody
	JqgridResponse<OrderDTO> records(
	   		@RequestParam("_search") Boolean search,
	   		@RequestParam(value="fromDate", required=false) String fromDateString,
	   		@RequestParam(value="toDate", required=false) String toDateString,
	   		@RequestParam(value="orderStatus", required=false) String orderStatus,
    		@RequestParam(value="filters", required=false) String filters,
			@RequestParam(value = "page", required = false) Integer pageNumber,
			@RequestParam(value = "rows", required = false) Integer rowsPerPage,
			@RequestParam(value = "sidx", required = false) String sortColName,
			@RequestParam(value = "sord", required = false, defaultValue = "asc") String sortOrder) throws ParseException {
		 /*JQGrid column sorting*/
		 if(sortColName.equalsIgnoreCase("customerCode")){
				sortColName="customer.customerCode";
			}
		  if(sortColName.equalsIgnoreCase("customerName")){
				sortColName="customer.customerName";
			}
		  if(sortColName.equalsIgnoreCase("itemDescription")){
				sortColName="salesOrderItem.items.itemDescription";
			}
		 
		  if(sortColName.equalsIgnoreCase("status")){
				sortColName="orderStatus.status";
			}
		  
		  Page<SalesOrder> orders = null;
		  DateFormat df = new SimpleDateFormat("dd-MM-yyyy");
	     	java.util.Date fromDate = df.parse(fromDateString);
	     	java.util.Date toDate = df.parse(toDateString);
		
		
	    if(orderStatus==null || orderStatus==""){
	    	String status="Created";
	    	/*Method to fetch JQGRID paged records of sales order records based on fromDate,toDate,status */
			  orders = orderService.getSalesOrderReport(fromDate,toDate,status,pageNumber - 1,
						rowsPerPage, sortColName, sortOrder);
	    }else{
	    	/*Method to fetch JQGRID paged records of sales order records based on fromDate,toDate,orderStatus */
	    	 orders = orderService.getSalesOrderReportWithStatus(fromDate,toDate,orderStatus,pageNumber - 1,
						rowsPerPage, sortColName, sortOrder);	
	    }
	    /*Intialize JQgrid response of type OrderDTO*/
		JqgridResponse<OrderDTO> response = new JqgridResponse<OrderDTO>();
		/*Method to set salesorders list to OrderDTO*/
		List<OrderDTO> orderDTOs = convertToSalesOrderReportDTO(orders.getContent());
		response.setRows(orderDTOs);
		response.setRecords(Long.valueOf(orders.getTotalElements()).toString());
		response.setTotal(Long.valueOf(orders.getTotalPages()).toString());
		response.setPage(Integer.valueOf(orders.getNumber()+1).toString());

		return response;
	}
	 /**
	   * This Method to set salesorder records to OrderDTO
	   * @param List<SalesOrder> SalesOrder
	   * @return List<OrderDTO> response
	   */
	private List<OrderDTO> convertToSalesOrderReportDTO(List<SalesOrder> orders) {
		List<OrderDTO> orderDTOs = new ArrayList<>();
		for(SalesOrder order : orders) {
			
			if((!(order.getOrderId().equalsIgnoreCase("BS000001")))){
			OrderDTO orderDTO = new OrderDTO();
			orderDTO.setOrderId(order.getOrderId());
			if(order.getOrderRecDate()!=null)
			orderDTO.setOrderRecDate(Utility.formDateFormatter.print(order.getOrderRecDate().getTime()));
			if(order.getOrderDeliveryDate()!=null)
			orderDTO.setOrderDeliveryDate(Utility.formDateFormatter.print(order.getOrderDeliveryDate().getTime()));
			if(order.getOrderAcceptanceDate()!=null)
			orderDTO.setOrderAcceptanceDate(Utility.formDateFormatter.print(order.getOrderAcceptanceDate().getTime()));
			if(order.getTargetDate()!=null)
			orderDTO.setTargetDate(Utility.formDateFormatter.print(order.getTargetDate().getTime()));
			orderDTO.setPoDetails(order.getPoDetails());
			orderDTO.setModeOfReceipt(order.getModeOfReceipt());
			orderDTO.setOrderStatusId(order.getOrderStatus().getOrderStatusId());
			orderDTO.setStatus(order.getOrderStatus().getStatus());
			if(order.getCreatedTime()!=null)
			orderDTO.setCreatedTime(order.getCreatedTime().toString());
			if(order.getUpdatedTime()!=null)
			orderDTO.setUpdatedTime(order.getUpdatedTime().toString());
			orderDTO.setUpdatedBy(order.getUpdatedBy());
			orderDTO.setCreatedBy(order.getCreatedBy());
			orderDTO.setCustomerName(order.getCustomer().getCustomerName());
			orderDTO.setCustomerCode(order.getCustomer().getCustomerCode());
			orderDTO.setInputQuantity(order.getInputQuantity());
			orderDTO.setMailStatus(order.getMailStatus());
			orderDTO.setLmeDetails(order.getLmeDetails());
	
		    orderDTOs.add(orderDTO);
			}//end of if((!(order.getOrderId().equalsIgnoreCase("BS000001")))) condition
		}//end of for loop
			return orderDTOs;
 }
	/**
	   * This Method to generate salesorder history report
	   * @param fromDate,toDate
	   * @return void
	   */
	@RequestMapping(value = "/salesOrderHistoryReport", produces = "application/pdf", method = RequestMethod.GET)

	public void SalesOrderReport(@RequestParam(value = "fromDate", required = true) String fromDate,
			                     @RequestParam(value = "toDate", required = true) String toDate,  
			                     javax.servlet.http.HttpServletResponse response) throws IOException, InterruptedException, ParseException{
		if(fromDate!="" && fromDate!=null && toDate!=null && toDate!="" ){
		 InputStream inputStream = getClass().getClassLoader().getResourceAsStream("/org/balajicables/salesmanager/report/SOHistoryReport.jrxml");	 
		 DateFormat df = new SimpleDateFormat("dd-MM-yyyy");
	     java.util.Date fromDt = df.parse(fromDate);
	     java.util.Date toDt = df.parse(toDate);
	 
		 Map<String, Object> hm= new HashMap<String, Object>();
	     hm.put("FROM_DATE", fromDt);//set report parameters
	     hm.put("TO_DATE", toDt);//set report parameters
	     byte[] content = ReportGenerator.newReportGenerator(inputStream,hm);//call reportgenerator
	    
		response.setContentType("application/pdf");
		response.setHeader("Content-Disposition", "attachment;filename=" + "SalesOrderHistory"+fromDate+"-to-"+toDate+".pdf");//set PDF report name
		response.setContentLength(content.length);
	    FileCopyUtils.copy(content, response.getOutputStream());
	}//end of if(fromDate!="" && fromDate!=null && toDate!=null && toDate!="") condition
	}
}

