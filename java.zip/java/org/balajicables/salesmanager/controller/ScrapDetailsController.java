package org.balajicables.salesmanager.controller;

import java.util.ArrayList;
import java.util.List;
import javax.annotation.Resource;
import org.balajicables.salesmanager.CustomUser;
import org.balajicables.salesmanager.common.JqgridResponse;
import org.balajicables.salesmanager.common.StatusResponse;
import org.balajicables.salesmanager.dto.ScrapDetailsDTO;
import org.balajicables.salesmanager.dto.ScrapStoreRegDTO;
import org.balajicables.salesmanager.model.Item;
import org.balajicables.salesmanager.model.MachineDetails;
import org.balajicables.salesmanager.model.ProductionWorkOrder;
import org.balajicables.salesmanager.model.ScrapDetails;
import org.balajicables.salesmanager.model.ScrapStoreReg;
import org.balajicables.salesmanager.model.Shift;
import org.balajicables.salesmanager.repository.ItemRepository;
import org.balajicables.salesmanager.repository.MachineRepository;
import org.balajicables.salesmanager.repository.ProductionProcessRepository;
import org.balajicables.salesmanager.repository.ProductionWorkOrderRepository;
import org.balajicables.salesmanager.repository.ShiftRepository;
import org.balajicables.salesmanager.service.ItemService;
import org.balajicables.salesmanager.service.ProductionWorkOrderService;
import org.balajicables.salesmanager.service.ScrapDetailsService;
import org.balajicables.salesmanager.service.ScrapStoreRegService;
import org.joda.time.DateTime;
import org.springframework.data.domain.Page;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
/**
 * This class demonstrates Scrap module
 * @author Abin Sam
*/
@Controller
@RequestMapping("/scrap")
public class ScrapDetailsController {
	
	@Resource
	private ProductionProcessRepository productionProcessRepository;
	
	@Resource 
	private ProductionWorkOrderRepository productionWorkOrderRepository;
	
	@Resource 
	private ItemRepository itemRepository;
	
	@Resource 
	private MachineRepository machineRepository;
	
	@Resource 
	private ShiftRepository shiftRepository;
	
	@Resource
	private ProductionWorkOrderService productionWorkOrderService;
	
	@Resource
	private ScrapDetailsService scrapDetailsService;
	
	@Resource
	private ScrapStoreRegService scrapStoreRegService;
	
	@Resource
	private ItemService itemService;
	

	/**
	   * This method returns scrap.jsp.
	   * @param Model to set the attribute.
	   * @return scrap.jsp.
	   */	
	@RequestMapping
	public String getCreateWoPage(Model model) {
		/*Method to fetch list of items from item master of item type SRCP*/
		List<Item> items =  itemRepository.findByItemType("SCRAP");
		model.addAttribute("processes",productionProcessRepository.findAll());//set processes to model attribute
		model.addAttribute("machine", machineRepository.findAll());//set machine numbers to model attribute
		model.addAttribute("items",items);//set items to model attribute
		model.addAttribute("shifts", shiftRepository.findAll());//set shifts to model attribute
		model.addAttribute("scrap", items);//set scrap to model attribute
		return "scrap";
	}
	/**
	   * Method to fetch Work Orders
	   * @param processType,month,year
	   * @return List<String> pdnWoValuesList
	   */
	@RequestMapping(value="/getWorkOrders", produces="application/json", method=RequestMethod.POST)
	public @ResponseBody
	List<String> getWODetails(
			@RequestParam(value = "processType", required = true) String processType,
			@RequestParam(value = "month", required = false) String month,
			@RequestParam(value = "year", required = false) String year) {
		/*By default to set the current month and year*/
		DateTime dt = new DateTime();  
		    int monthValue=0;
	        int yearValue=0;
	        if(month!=null && month!="")
	        	monthValue=Integer.parseInt(month)+1;
	        else
	        	monthValue =dt.getMonthOfYear();
	        
	       if(year!=null && year!="")
	    	   yearValue=Integer.parseInt(year);
	       else
	    	   yearValue =dt.getYear();
		/*Method to fetch workorders based on the processType,monthValue,yearValue*/
		List<ProductionWorkOrder> pdnWorkOrders = productionWorkOrderService.findByProcessTypeAndMonthYear(processType, monthValue, yearValue);
		/*Initialising an empty list of type String and add the fetched workorder nos to empty list pdnWoValuesList*/
		List<String> pdnWoValuesList = new ArrayList<String>();
		for(int iterator=0; iterator < pdnWorkOrders.size();iterator++){
			ProductionWorkOrder productionWorkOrder = pdnWorkOrders.get(iterator);
			pdnWoValuesList.add(productionWorkOrder.getWorkOrderNo());
		}//end of for loop
		return pdnWoValuesList;
	}
	/**
	   * Method to fetch machine description based on the workorder number 
	   * @PathVariable workOrderNo
	   * @return List<String> pdnWoValuesList
	   */	
	@RequestMapping(value="/getMachineDesc/{workOrderNo}", produces="application/json", method=RequestMethod.POST)
	public @ResponseBody
	List<String> getMachineDetails(
			@PathVariable("workOrderNo") String workOrderNo,
			Model model) {
		/*Method to fetch workorder*/
		List<ProductionWorkOrder> pdnWorkOrders = productionWorkOrderRepository.findByWorkOrderNo(workOrderNo);
		/*Initialising an empty list of type String and inserting the fetched machine descriptions*/
		List<String> pdnWoValuesList = new ArrayList<String>();
		for(int iterator=0; iterator < pdnWorkOrders.size();iterator++){
			ProductionWorkOrder productionWorkOrder = pdnWorkOrders.get(iterator);
			pdnWoValuesList.add(productionWorkOrder.getMachine().getDescription());
		}//end of for loop
		return pdnWoValuesList;
	}
	/**
	   * Method to fetch item description based on the itemcode 
	   * @PathVariable itemCode
	   * @return List<String> itemDescList
	   */	
	@RequestMapping(value="/getItemDescription/{itemCode}", produces="application/json", method=RequestMethod.POST)
	public @ResponseBody
	List<String> getItemDescription(
			@PathVariable("itemCode") String itemCode,
			Model model) {
		/*Method to fetch items from Item master*/
		List<Item> items = itemRepository.findByItemCode(itemCode);
		/*Initialising an empty list of type String and inserting the fetched item descriptions*/
		List<String> itemDescList = new ArrayList<String>();
		for(int iterator=0; iterator < items.size();iterator++){
			Item item = items.get(iterator);
			itemDescList.add(item.getItemDescription());
		}
		return itemDescList;
	}
	/**
	   * Method to create scrap entries
	   * @RequestParam workOrderNoSelect,machine,scrapDate,shiftSelect,quantity,itemSelect
	   * @return StatusResponse
	   */	
	@RequestMapping(value="/createScrapEntry", produces="application/json", method=RequestMethod.POST)
	public @ResponseBody
	StatusResponse createScrapEntry(
			@RequestParam(required = false) String workOrderNoSelect,
			@RequestParam(required = false) String machine,
			@RequestParam(required = false) String scrapDate,
			@RequestParam(required = false) Integer shiftSelect,
			@RequestParam(required = false) Double quantity,
			@RequestParam(required = false) String itemSelect
			) {
		
		Boolean result=false;
		/*Method to get name of the person who has logged in*/
		CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();;
		/*Method to get username of the person who has logged in*/
		String userName = user.getFirstName()+" "+user.getLastName();
	 	/*Creating a new instance of ScrapDetailsDTO*/
	 	ScrapDetailsDTO scrapDetailsDTO = new ScrapDetailsDTO();
	 	scrapDetailsDTO.setWorkOrderNo(workOrderNoSelect);
	 	/*Method to fetch machine list*/
	 	List<MachineDetails> machineDetails = machineRepository.findByDescription(machine);
	 	
	 	scrapDetailsDTO.setMachineDesciption(machineDetails.get(0).getDescription());
	 	scrapDetailsDTO.setScrapDate(scrapDate);
	 	scrapDetailsDTO.setSupervisor(userName);
	 	/*Method to fetch shift list*/
	 	Shift shift = shiftRepository.findByShiftId(shiftSelect);
	 	
	 	scrapDetailsDTO.setShiftPattern(shift.getShiftPattern());
	 	scrapDetailsDTO.setShiftId(shift.getShiftId());
	 	scrapDetailsDTO.setMachineNo(machineDetails.get(0).getMachineNo());
	 	scrapDetailsDTO.setQuantity(quantity);
	 	/*Method to fetch item list*/
	 	List<Item> item = itemRepository.findByItemCode(itemSelect);
		scrapDetailsDTO.setItemId(item.get(0).getItemId());
	 	scrapDetailsDTO.setItemCode(item.get(0).getItemCode());
	 	scrapDetailsDTO.setItemDesc(item.get(0).getItemDescription());
	 	
	 	scrapDetailsDTO.setStockedInStatus("No");
	 	ScrapDetails scrapDetails = scrapDetailsDTO.getScrapDetails();
	 	/*Method to create scrap details*/
	 	ScrapDetails createdScrapDetails = scrapDetailsService.create(scrapDetails);
	 	
         if(createdScrapDetails!=null)
    	 		result=true;
	 	return new StatusResponse(result);
	}
	 /**
	   * This method to fetch scrap records
	   * Fetch  Scrap details for grid
	   * @param search,filters,pageNumber,rowsPerPage,sortColName,sortOrder
	   * @return JqgridResponse<ScrapDetailsDTO> response
	   */
	@RequestMapping(value="/records", produces="application/json", method=RequestMethod.POST)
	public @ResponseBody
	JqgridResponse<ScrapDetailsDTO> records(
			@RequestParam("_search") Boolean search,
    		@RequestParam(value="filters", required=false) String filters,
			@RequestParam(value = "page", required = false) Integer pageNumber,
			@RequestParam(value = "rows", required = false) Integer rowsPerPage,
			@RequestParam(value = "sidx", required = false) String sortColName,
			@RequestParam(value = "sord", required = false, defaultValue = "asc") String sortOrder) {
		/*JQGrid column sorting*/
		if(sortColName.equalsIgnoreCase("workOrderNo")){
            sortColName="productionWorkOrder.workOrderNo";
		}
		if(sortColName.equalsIgnoreCase("itemCode")){
            sortColName="item.itemCode";
		}
		if(sortColName.equalsIgnoreCase("itemDescription")){
            sortColName="item.itemDescription";
		}
		if(sortColName.equalsIgnoreCase("shiftPattern")){
            sortColName="Shift.shiftId";
		}
		if(sortColName.equalsIgnoreCase("shiftId")){
            sortColName="Shift.shiftId";
		}
		if(sortColName.equalsIgnoreCase("shiftDesc")){
            sortColName="Shift.shiftDesc";
		}
		if(sortColName.equalsIgnoreCase("machineDesciption")){
            sortColName="machineDetails.description";
		}
		if(sortColName.equalsIgnoreCase("productType")){
            sortColName="item.productType.productType";
		}
		if(sortColName.equalsIgnoreCase("productKey")){
            sortColName="item.productType.productKey";
		}
		if(sortColName.equalsIgnoreCase("rawMaterial")){
            sortColName="item.productType.rawMaterial";
		}
		/*Method to fetch JQGRID paged records of Scrap items*/
		Page<ScrapDetails> scrapDetails= scrapDetailsService.getScrapDetailsPagedList(pageNumber -1, rowsPerPage, sortColName, sortOrder);
		/*Intialize JQ grid response of type ScrapDetailsDTO*/
		JqgridResponse<ScrapDetailsDTO> response = new JqgridResponse<ScrapDetailsDTO>();
		/*Method to set scrap item list to ScrapDetailsDTO*/
		List<ScrapDetailsDTO> scrapDetailsDTOs = convertToScrapDetailsDTO(scrapDetails.getContent());
		
		response.setRows(scrapDetailsDTOs);
		response.setRecords(Long.valueOf(scrapDetails.getTotalElements()).toString());
		response.setTotal(Long.valueOf(scrapDetails.getTotalPages()).toString());
		response.setPage(Integer.valueOf(scrapDetails.getNumber()+1).toString());
		return response;
		
	}
	 /**
	   * This Method to set scrap list to ScrapDetailsDTO
	   * @param List<ScrapDetails> scrapDetails
	   * @return List<ScrapDetailsDTO> response
	   */
	private List<ScrapDetailsDTO> convertToScrapDetailsDTO(List<ScrapDetails> scrapDetails) {
		List<ScrapDetailsDTO> scrapDetailsDTOs = new ArrayList<>();
		for(ScrapDetails scrapDetailObj : scrapDetails) {
			ScrapDetailsDTO scrapDetailsDTO = new ScrapDetailsDTO();
			
			scrapDetailsDTO.setWorkOrderNo(scrapDetailObj.getProductionWorkOrder().getWorkOrderNo());
			scrapDetailsDTO.setItemCode(scrapDetailObj.getItem().getItemCode());
			scrapDetailsDTO.setItemId(scrapDetailObj.getItem().getItemId());
			scrapDetailsDTO.setItemDesc(scrapDetailObj.getItem().getItemDescription());
			scrapDetailsDTO.setMachineNo(scrapDetailObj.getMachineDetails().getMachineNo());
			scrapDetailsDTO.setMachineDesciption(scrapDetailObj.getMachineDetails().getDescription());
			scrapDetailsDTO.setQuantity(scrapDetailObj.getQuantity());
			scrapDetailsDTO.setStockedInStatus(scrapDetailObj.getStockedInStatus());
			scrapDetailsDTO.setScrapDate(scrapDetailObj.getScrapDate());
			scrapDetailsDTO.setShiftId(scrapDetailObj.getShift().getShiftId());
			scrapDetailsDTO.setShiftPattern(scrapDetailObj.getShift().getShiftPattern());
			scrapDetailsDTO.setSupervisor(scrapDetailObj.getSupervisor());
			scrapDetailsDTO.setScrapId(scrapDetailObj.getScrapId());
			scrapDetailsDTO.setProductKey(scrapDetailObj.getItem().getProductType().getProductKey());
			scrapDetailsDTOs.add(scrapDetailsDTO);
		}//end of for loop
		return scrapDetailsDTOs;
	}
	 /**
	   * Method to Create/Edit scrap details
	   * @param operation(edit/create),id,workOrderNo,itemId,machineNo,supervisor,scrapDate,shiftPattern,quantity,
	     stockedInStatus
	   * @return StatusResponse
	   */	
	@RequestMapping(value = "/crud", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	StatusResponse crud(@RequestParam Long id,
			@RequestParam String oper,
			@RequestParam(required = false) String workOrderNo,
			@RequestParam(required = false) Long itemId,
			@RequestParam(required = false) Long machineNo,
			@RequestParam (required=false)  String supervisor,
			@RequestParam (required=false)  String scrapDate,
			@RequestParam (required=false)  String shiftPattern,
			@RequestParam (required=false)  Double quantity,
			@RequestParam (required=false)  String stockedInStatus
		) {
	
		Boolean result = false;
		/*Creating a new instance of ScrapDetailsDTO*/
		ScrapDetailsDTO scrapDetailsDTO =new ScrapDetailsDTO();
		/*Method to get name of the person who has logged in*/
		CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();;
		/*Method to get username of the person who has logged in*/
		String userName = user.getFirstName()+" "+user.getLastName();
	 	
		switch (oper) {
		case "edit":
			scrapDetailsDTO.setScrapId(id);
			scrapDetailsDTO.setWorkOrderNo(workOrderNo);
			scrapDetailsDTO.setItemId(itemId);
			scrapDetailsDTO.setScrapDate(scrapDate);
			List<Shift> shift = shiftRepository.findByShiftPattern(shiftPattern);
			scrapDetailsDTO.setShiftId(shift.get(0).getShiftId());
			scrapDetailsDTO.setShiftPattern(shiftPattern);
			scrapDetailsDTO.setSupervisor(supervisor);
			scrapDetailsDTO.setMachineNo(machineNo);
    		scrapDetailsDTO.setQuantity(quantity);
			scrapDetailsDTO.setSupervisor(userName);
			scrapDetailsDTO.setStockedInStatus(stockedInStatus);
			ScrapDetails scrapDetails = scrapDetailsDTO.getScrapDetails();
			result = scrapDetailsService.update(scrapDetails);
		break;
		case "del":
			result = scrapDetailsService.delete(id);
			
     	 	break;
		}//end of switch cases
		return new StatusResponse(result);
	}
	/**
	   * Method to fetch scrap quantity
	   * @param itemCode
	   * @return StatusResponse
	   */	
	@RequestMapping(value="/fetchScrapQuantity", produces="application/json", method=RequestMethod.POST)
	public @ResponseBody
	List<String> fetchScrapQuantity(@RequestParam(value="itemCode",required = false) String itemCode){
		/*Creating a new instance of ScrapDetailsDTO*/
		List<String> scrapQtyList = new ArrayList<String>();
		/*Method to fetch item list*/
		List<Item>itemList=itemService.findByItemCode(itemCode);
		if(itemList.size()>0){
			Long itemId=itemList.get(0).getItemId();
			List<ScrapStoreReg>scrapStore=scrapStoreRegService.findByItemsItemId(itemId);
		if(scrapStore.size()>0)
		scrapQtyList.add(scrapStore.get(0).getStockQuantity().toString());
		else
		scrapQtyList.add("0.0");
	   }
		return scrapQtyList;
	}
	/**
	   * Method to stock in scrap items
	   * @PathVariable id
	   * @RequestParam quantity
	   * @return StatusResponse
	   */	
	@RequestMapping(value="/stockInScrap/{id}", produces="application/json", method=RequestMethod.POST)
	public @ResponseBody
	StatusResponse stockInScrap(
			@PathVariable("id") Long id,
			@RequestParam (required=false)  Double quantity)	{
		/*Method to get name of the person who has logged in*/
		CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();;
		/*Method to get username of the person who has logged in*/
		String userName = user.getFirstName()+" "+user.getLastName();
	 	Long itemId=null;
        List<ScrapDetails>scrapDetailsList=scrapDetailsService.findById(id);
        if(scrapDetailsList.size()>0){
        itemId=scrapDetailsList.get(0).getItem().getItemId();
        }
        Double totalStockQty=0.0;
        Boolean result=false;
        Boolean finalResult=false;
        if(itemId!=null){
        	/*Method to fetch scrap items based on itemId*/
        	List<ScrapStoreReg>scrapStoreRegList=scrapStoreRegService.findByItemsItemId(itemId);
        	/*Creating a new instance of ScrapStoreRegDTO*/
        	ScrapStoreRegDTO scrapStoreRegDTO=new ScrapStoreRegDTO();
        	if(scrapStoreRegList.size()>0){
        		for(int k=0;k<scrapStoreRegList.size();k++){
        			totalStockQty=totalStockQty+scrapStoreRegList.get(k).getStockQuantity()+quantity;
        		}
        		scrapStoreRegDTO.setScrapStoreRegId(scrapStoreRegList.get(0).getScrapStoreRegId());
        	}//end of if(scrapStoreRegList.size()>0) condition
        	else{
        		totalStockQty=quantity;
        	}
        	scrapStoreRegDTO.setStockQuantity(totalStockQty);
        	scrapStoreRegDTO.setUpdatedBy(userName);
        	scrapStoreRegDTO.setItemId(itemId);
    		scrapStoreRegDTO.setStoreId(1);
        	
        	if(scrapStoreRegList.size()>0){
           		ScrapStoreReg scrapStoreReg=scrapStoreRegDTO.getScrapStoreReg();
        		result=scrapStoreRegService.update(scrapStoreReg);
        	}//end of if(scrapStoreRegList.size()>0) condition
        	else{
        		ScrapStoreReg scrapStoreReg=scrapStoreRegDTO.getScrapStoreReg();
        		ScrapStoreReg createdScrapStoreReg=scrapStoreRegService.create(scrapStoreReg);
        		if(createdScrapStoreReg!=null)
        		result=true;
            }
        	
        }//end of if(itemId!=null) condition
        
        if(result==true){
       	if(scrapDetailsList.size()>0){
	 			ScrapDetailsDTO scrapDetailsDTO=new ScrapDetailsDTO();
	 			scrapDetailsDTO.setScrapId(scrapDetailsList.get(0).getScrapId());
	 			scrapDetailsDTO.setWorkOrderNo(scrapDetailsList.get(0).getProductionWorkOrder().getWorkOrderNo());
	 			scrapDetailsDTO.setItemId(scrapDetailsList.get(0).getItem().getItemId());
	 			scrapDetailsDTO.setMachineNo(scrapDetailsList.get(0).getMachineDetails().getMachineNo());
	 			scrapDetailsDTO.setSupervisor(scrapDetailsList.get(0).getSupervisor());
	 			scrapDetailsDTO.setScrapDate(scrapDetailsList.get(0).getScrapDate());
	 			scrapDetailsDTO.setCreatedDate(scrapDetailsList.get(0).getCreatedDate());
	 			scrapDetailsDTO.setQuantity(scrapDetailsList.get(0).getQuantity());
	 			scrapDetailsDTO.setShiftId(scrapDetailsList.get(0).getShift().getShiftId());
	 			scrapDetailsDTO.setStockedInStatus("Yes");
	 			ScrapDetails scrapDetails=scrapDetailsDTO.getScrapDetails();
	 			finalResult=scrapDetailsService.update(scrapDetails);
	 
        }//end of if(scrapDetailsList.size()>0)
       }//end of if(result==true) condition
	 	 	return new StatusResponse(finalResult);	 		
        }
}