package org.balajicables.salesmanager.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.annotation.Resource;
import org.balajicables.salesmanager.CustomUser;
import org.balajicables.salesmanager.common.JqgridResponse;
import org.balajicables.salesmanager.common.StatusResponse;
import org.balajicables.salesmanager.dto.DeliveryChallanDTO;
import org.balajicables.salesmanager.dto.DeliveryChallanItemsDTO;
import org.balajicables.salesmanager.dto.OrderDTO;
import org.balajicables.salesmanager.dto.PackingSlipDTO;
import org.balajicables.salesmanager.dto.SalesOrderItemsDTO;
import org.balajicables.salesmanager.dto.ScrapStoreRegDTO;
import org.balajicables.salesmanager.dto.StockOutDTO;
import org.balajicables.salesmanager.model.Customer;
import org.balajicables.salesmanager.model.DeliveryChallan;
import org.balajicables.salesmanager.model.DeliveryChallanItems;
import org.balajicables.salesmanager.model.OrderStatus;
import org.balajicables.salesmanager.model.PackingSlip;
import org.balajicables.salesmanager.model.SalesOrder;
import org.balajicables.salesmanager.model.SalesOrderItem;
import org.balajicables.salesmanager.model.ScrapDetails;
import org.balajicables.salesmanager.model.ScrapStoreReg;
import org.balajicables.salesmanager.model.StockOut;
import org.balajicables.salesmanager.service.CustomerService;
import org.balajicables.salesmanager.service.DeliveryChallanItemsService;
import org.balajicables.salesmanager.service.DeliveryChallanService;
import org.balajicables.salesmanager.service.OrderDetailsService;
import org.balajicables.salesmanager.service.OrderService;
import org.balajicables.salesmanager.service.OrderStatusService;
import org.balajicables.salesmanager.service.PackingSlipService;
import org.balajicables.salesmanager.service.ScrapDetailsService;
import org.balajicables.salesmanager.service.ScrapStoreRegService;
import org.balajicables.salesmanager.service.StockOutService;
import org.balajicables.salesmanager.utils.Utility;
import org.joda.time.DateTime;
import org.springframework.data.domain.Page;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
/**
 * This class demonstrates StockOut of Scrap module
 * @author Abin Sam
*/
@Controller
@RequestMapping("/scrapStockOut")
public class ScrapStockOutController {

	@Resource
	private CustomerService customerService;

	@Resource
	private OrderDetailsService orderDetailsService;

	@Resource
	ScrapStoreRegService scrapStoreRegService;
	
	@Resource
	OrderStatusService orderStatusService;
	@Resource
	PackingSlipService packingSlipService;

	@Resource
	DeliveryChallanService deliveryChallanService;
	
	@Resource
	ScrapDetailsService scrapDetailsService;
	
	@Resource
	StockOutService stockOutService;
	
	@Resource
	OrderService orderService;	

	@Resource
	DeliveryChallanItemsService deliveryChallanItemsService;
	/**
	   * This method returns scrapStockOut.jsp.
	   * @param Model to set the attribute.
	   * @return scrapStockOut.jsp.
	   */	
	@RequestMapping
	public String getCreateWoPage(Model model) {
		/*Method to fetch customer list */
		ArrayList<String> soNosList = new ArrayList<>();
	    String itemType="SCRAP";
	    String status="Approved";
	    /*Method to fetch salesorder item list based on customerId,itemType,status*/
		List<SalesOrderItem> salesOrderItems =orderDetailsService.findByScrapItem(itemType,status);
    	for (int iterator = 0; iterator < salesOrderItems.size(); iterator++) {
			if(salesOrderItems.get(iterator).getOrder().getOrderId()!=null && salesOrderItems.get(iterator).getOrder().getOrderId()!=""){
			String salesOrderNo = salesOrderItems.get(iterator).getOrder().getOrderId();
			if (!soNosList.contains(salesOrderNo)) {
				soNosList.add(salesOrderNo);
			}//end of inner if condition
			}//end of outer if condition
			Collections.sort(soNosList,Collections.reverseOrder());
		} //end of for loop  	
    	model.addAttribute("orders", soNosList);
		List<Customer> customers = customerService.findAll();
		model.addAttribute("customers", customers);//set customer list to model attribute
		return "scrapStockOut";
	}
	 /**
	   * This method to fetch scrap stockout records
	   * Fetch  Scrap stockout details for grid
	   * @param search,salesOrderNo,filters,pageNumber,rowsPerPage,sortColName,sortOrder
	   * @return JqgridResponse<ScrapStoreRegDTO> response
	   */
	@RequestMapping(value="/records", produces="application/json", method=RequestMethod.POST)
	public @ResponseBody
	JqgridResponse<ScrapStoreRegDTO> records(
			@RequestParam("_search") Boolean search,
			@RequestParam(value="salesOrderNo", required=false) String salesOrderNo,
    		@RequestParam(value="filters", required=false) String filters,
			@RequestParam(value = "page", required = false) Integer pageNumber,
			@RequestParam(value = "rows", required = false) Integer rowsPerPage,
			@RequestParam(value = "sidx", required = false) String sortColName,
			@RequestParam(value = "sord", required = false, defaultValue = "asc") String sortOrder) {
		/*JQGrid column sorting*/
		if(sortColName.equalsIgnoreCase("itemDescription")){
            sortColName="items.itemDescription";
		}
		if(sortColName.equalsIgnoreCase("itemCode")){
            sortColName="items.itemCode";
		}
		/*scrapStoreRegDetails page of type ScrapStoreReg initialized to null*/
		Page<ScrapStoreReg> scrapStoreRegDetails= null;
		
		if(salesOrderNo!=null && salesOrderNo!=""){
			List<SalesOrderItem>soItemList=orderDetailsService.findByOrderId(salesOrderNo);
			ArrayList<String>itemCode=new ArrayList<>();
			if(soItemList.size()>0){
				for(int k=0;k<soItemList.size();k++){
					itemCode.add(soItemList.get(k).getItem().getItemCode());
				}
			}
			/*Method to fetch JQGRID paged records of Scrap Stockout items based on itemcode*/	
			scrapStoreRegDetails= scrapStoreRegService.findByItemsItemCodeIn(pageNumber -1, rowsPerPage, sortColName, sortOrder,itemCode);
		}//end of if(salesOrderNo!=null && salesOrderNo!="") condition
		else
			/*Method to fetch JQGRID paged records of Scrap Stockout items*/	
		scrapStoreRegDetails= scrapStoreRegService.getScrapStoreRegDetailsPagedList(pageNumber -1, rowsPerPage, sortColName, sortOrder);
		/*Intialize JQ grid response of type ScrapStoreRegDTO*/		
		JqgridResponse<ScrapStoreRegDTO> response = new JqgridResponse<ScrapStoreRegDTO>();
		/*Method to set scrap item list to ScrapStoreRegDTO*/	
		List<ScrapStoreRegDTO> scrapStoreRegDTOs = convertToScrapStoreRegDTO(scrapStoreRegDetails.getContent());

     	response.setRows(scrapStoreRegDTOs);
		response.setRecords(Long.valueOf(scrapStoreRegDetails.getTotalElements()).toString());
		response.setTotal(Long.valueOf(scrapStoreRegDetails.getTotalPages()).toString());
		response.setPage(Integer.valueOf(scrapStoreRegDetails.getNumber()+1).toString());
		return response;
		
	}
	 /**
	   * This Method to set scrap list to ScrapStoreRegDTO
	   * @param List<ScrapStoreReg> ScrapStoreReg
	   * @return List<ScrapStoreRegDTO> response
	   */
	private List<ScrapStoreRegDTO> convertToScrapStoreRegDTO(List<ScrapStoreReg> scrapStoreRegDetails) {
		List<ScrapStoreRegDTO> scrapStoreRegDTOs = new ArrayList<>();
		for(ScrapStoreReg scrapStoreRegDetail : scrapStoreRegDetails) {
			ScrapStoreRegDTO scrapStoreRegDTO = new ScrapStoreRegDTO();
			scrapStoreRegDTO.setScrapStoreRegId(scrapStoreRegDetail.getScrapStoreRegId());
			scrapStoreRegDTO.setItemId(scrapStoreRegDetail.getItems().getItemId());
			scrapStoreRegDTO.setStockQuantity(scrapStoreRegDetail.getStockQuantity());
			scrapStoreRegDTO.setUpdatedBy(scrapStoreRegDetail.getUpdatedBy());
			scrapStoreRegDTO.setItemCode(scrapStoreRegDetail.getItems().getItemCode());
			scrapStoreRegDTO.setItemDescription(scrapStoreRegDetail.getItems().getItemDescription());
			scrapStoreRegDTOs.add(scrapStoreRegDTO);
		}//end of for loop
		return scrapStoreRegDTOs;
	}	
	 /**
	   * This Method to fetch salesorder
	   * @param 
	   * @return ArrayList<String> soNosList
	   */
	@RequestMapping(value = "/fetchAllSalesOrder", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	ArrayList<String> getAllSalesorderNos() {
		/*Initialization of an empty ArrayList of type String*/
		ArrayList<String> soNosList = new ArrayList<>();
	    String itemType="SCRAP";
	    String status="Approved";
	    /*Method to fetch salesorder item list based on customerId,itemType,status*/
		List<SalesOrderItem> salesOrderItems =orderDetailsService.findByScrapItem(itemType,status);
  	for (int iterator = 0; iterator < salesOrderItems.size(); iterator++) {
			if(salesOrderItems.get(iterator).getOrder().getOrderId()!=null && salesOrderItems.get(iterator).getOrder().getOrderId()!=""){
			String salesOrderNo = salesOrderItems.get(iterator).getOrder().getOrderId();
			if (!soNosList.contains(salesOrderNo)) {
				soNosList.add(salesOrderNo);
			}//end of inner if condition
			}//end of outer if condition
			Collections.sort(soNosList,Collections.reverseOrder());
		} //end of for loop  	
	return soNosList;
	}
	 /**
	   * This Method to fetch salesorder
	   * @param customerId
	   * @return ArrayList<String> soNosList
	   */
	@RequestMapping(value = "/fetchSalesOrder", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	ArrayList<String> getSalesorderNos(
			@RequestParam(value="customerId",required=true) Long customerId) {
		/*Initialization of an empty ArrayList of type String*/
		ArrayList<String> soNosList = new ArrayList<>();
	    String itemType="SCRAP";
	    String status="Approved";
	    /*Method to fetch salesorder item list based on customerId,itemType,status*/
		List<SalesOrderItem> salesOrderItems =orderDetailsService.finddByCustomerIdAndScrapItem(customerId,itemType,status);
    	for (int iterator = 0; iterator < salesOrderItems.size(); iterator++) {
			if(salesOrderItems.get(iterator).getOrder().getOrderId()!=null && salesOrderItems.get(iterator).getOrder().getOrderId()!=""){
			String salesOrderNo = salesOrderItems.get(iterator).getOrder().getOrderId();
			if (!soNosList.contains(salesOrderNo)) {
				soNosList.add(salesOrderNo);
			}//end of inner if condition
			}//end of outer if condition
			Collections.sort(soNosList,Collections.reverseOrder());
		} //end of for loop  	
	return soNosList;
	}
	 /**
	   * Method to Create/Edit scrap stockout details
	   * @param operation(edit/create),id,stockOutQuantity
	   * @return StatusResponse
	   */	
	@RequestMapping(value = "/crud", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	StatusResponse crud(@RequestParam Long id,
			@RequestParam String oper,
			@RequestParam(required = false) Double stockOutQuantity
		) {
		Boolean updateScrapStoreReg=false;
	    /*Method to fetch items from scrap store register based on the id*/
		List<ScrapStoreReg>scrapstoreRegList=scrapStoreRegService.findByScrapStoreRegId(id);
		if(scrapstoreRegList.size()>0){
/*			if(stockOutQuantity!=null && stockOutQuantity!=0 && !(stockOutQuantity>scrapstoreRegList.get(0).getStockQuantity()) ) 
				stockOutQuantity=stockOutQuantity;
			}else
				stockOutQuantity=scrapstoreRegList.get(0).getStockQuantity();
		*/
		if(stockOutQuantity==null)
			stockOutQuantity=scrapstoreRegList.get(0).getStockQuantity();
		else if(stockOutQuantity==0)
			stockOutQuantity=scrapstoreRegList.get(0).getStockQuantity();
		else if(stockOutQuantity>scrapstoreRegList.get(0).getStockQuantity())
			stockOutQuantity=scrapstoreRegList.get(0).getStockQuantity();
		
		  /*Creating a new instance of ScrapStoreRegDTO*/	
		  ScrapStoreRegDTO scrapStoreRegDTO=new ScrapStoreRegDTO();
		  scrapStoreRegDTO.setItemCode(scrapstoreRegList.get(0).getItems().getItemCode());
		  scrapStoreRegDTO.setItemDescription(scrapstoreRegList.get(0).getItems().getItemDescription());
		  scrapStoreRegDTO.setItemId(scrapstoreRegList.get(0).getItems().getItemId());
		  scrapStoreRegDTO.setScrapStoreRegId(id);
		  if(stockOutQuantity>scrapstoreRegList.get(0).getStockQuantity())
		  scrapStoreRegDTO.setStockOutQty(scrapstoreRegList.get(0).getStockQuantity());
		  else
		  scrapStoreRegDTO.setStockOutQty(stockOutQuantity);	  
		  scrapStoreRegDTO.setStockQuantity(scrapstoreRegList.get(0).getStockQuantity());
		  scrapStoreRegDTO.setUpdatedBy(scrapstoreRegList.get(0).getUpdatedBy());
		  scrapStoreRegDTO.setUpdatedTime(scrapstoreRegList.get(0).getUpdatedTime().toString());
		  scrapStoreRegDTO.setStoreId(1);
		  ScrapStoreReg scrapStoreReg=scrapStoreRegDTO.getScrapStoreReg();
		  updateScrapStoreReg=scrapStoreRegService.update(scrapStoreReg);
	 }//end of if(scrapstoreRegList.size()>0) condition
		
  return new StatusResponse(updateScrapStoreReg);
	
}		
	 /**
	   * Method to stockout scrap items
	   * @param idsSelected,salesOrderNo,challanDate
	   * @return List<String> dcNoList
	   */		
	@RequestMapping(value="/stockOut", produces="application/json" ,method = RequestMethod.POST)
	public @ResponseBody
	List<String> crud(
   	 @RequestParam(value = "idsOfSelectedRows[]", required = false) Long[] idsSelected,
     @RequestParam(value = "salesOrderNo", required = false) String salesOrderNo,
     @RequestParam(value = "challanDate", required = false) String challanDate) {
		/*Method to get name of the person who has logged in*/
		CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		/*Method to get username of the person who has logged in*/
		String userName = user.getFirstName()+" "+user.getLastName();
	 	StockOut createStockOut=null;
	 	/*Initialization of an empty List of type String*/
		List<String> dcNoList=new ArrayList<>();
		String newdeliveryChallanNo = null;
		/*Method to fetch latest delivery challan*/
		List<DeliveryChallan> existdeliveryChallanList=deliveryChallanService.fetchLatestDeliveryChallan();
		
		String existDcNo="";
		
		if(existdeliveryChallanList.size()>0)
			existDcNo=existdeliveryChallanList.get(0).getDeliveryChallanNo();
		
		if(!existDcNo.isEmpty()){
			String existDcNumber = existDcNo.substring(0,existDcNo.indexOf("("));
			String existDcFinancialYear=existDcNo.substring(existDcNo.indexOf("(")+1,existDcNo.indexOf(")"));
			String currentYear=String.valueOf(new DateTime().getYear()%1000);
			String previousYear=String.valueOf((new DateTime().getYear()-1)%1000);
			String nextYear=String.valueOf((new DateTime().getYear()+1)%1000);
			String cuurentFinacialYear=null;
			if(new DateTime().getMonthOfYear()>2)
				cuurentFinacialYear=currentYear+"-"+nextYear;
			else
				cuurentFinacialYear=previousYear+"-"+currentYear;
			if(cuurentFinacialYear.equalsIgnoreCase(existDcFinancialYear)){
				Long newDcNumber=Long.valueOf(existDcNumber)+1;
				String newDcNo="0000";
				if(newDcNumber<10)
				  newDcNo="000"+newDcNumber;
				else if(newDcNumber<100)
			      newDcNo="00"+newDcNumber;
				else if(newDcNumber<1000)
				  newDcNo="0"+newDcNumber;
				else
				  newDcNo=String.valueOf(newDcNumber);
				newdeliveryChallanNo=newDcNo+"("+cuurentFinacialYear+")";	
		 	}//end of if(cuurentFinacialYear.equalsIgnoreCase(existDcFinancialYear)) condition
			else{
				String currentYears=String.valueOf(new DateTime().getYear()%1000);
				String previousYears=String.valueOf((new DateTime().getYear()-1)%1000);
				String nextYears=String.valueOf((new DateTime().getYear()+1)%1000);
				String finacialYears=null;
				if(new DateTime().getMonthOfYear()>3)
					finacialYears=currentYears+"-"+nextYears;
				else
					finacialYears=previousYears+"-"+currentYears;
				newdeliveryChallanNo="0001("+finacialYears+")";	
			}
		}//end of if loop of checking existing sales no
		else{
			String currentYear=String.valueOf(new DateTime().getYear()%1000);
			String previousYear=String.valueOf((new DateTime().getYear()-1)%1000);
			String nextYear=String.valueOf((new DateTime().getYear()+1)%1000);
			String finacialYear=null;
			if(new DateTime().getMonthOfYear()>3)
				finacialYear=currentYear+"-"+nextYear;
			else
				finacialYear=previousYear+"-"+currentYear;
			newdeliveryChallanNo="0001("+finacialYear+")";
		} 
		 DeliveryChallan createddc=null;
		 DeliveryChallanItems createdDcItem=null;
		 Boolean updateSalesOrderItem=false;
		 Boolean updateScrapStoreReg=false;
		 
		if(newdeliveryChallanNo!=null){
			
			for(int i=0;i<idsSelected.length;i++){
			 /*Method to fetch scrap items based on the id selected*/
		     List<ScrapStoreReg>scrapStoreReg=scrapStoreRegService.findByScrapStoreRegId(idsSelected[i]);
		     String itemCode=scrapStoreReg.get(0).getItems().getItemCode();
		     Long itemId=scrapStoreReg.get(0).getItems().getItemId();
		     String stockedInstatus="Yes";
		     /*Method to fetch salesorder items based on salesOrderNo,itemCode*/
		     List<SalesOrderItem>soItemList=orderDetailsService.findByOrderIdItemId(salesOrderNo, itemCode);
		     
		     if(soItemList.size()>0){
		     /*Method to fetch scrap item details based on itemId,stockedInstatus*/ 
		     List<ScrapDetails>scrapDetails=scrapDetailsService.findByItemIdAndStockedInStatus(itemId,stockedInstatus);
		     Long orderDetailId=soItemList.get(0).getOrderDetailId();
		     /*Creating a new instance of StockOutDTO*/
		     StockOutDTO stockOutDTO=new StockOutDTO();
			 stockOutDTO.setStoreId(scrapStoreReg.get(0).getStore().getStoreId());
			 stockOutDTO.setOrderDetailId(orderDetailId);
			 stockOutDTO.setOrderId(salesOrderNo);
			 stockOutDTO.setItemId(scrapStoreReg.get(0).getItems().getItemId());
			 stockOutDTO.setItemCode(scrapStoreReg.get(0).getItems().getItemCode());
			 stockOutDTO.setSoItemQty(soItemList.get(0).getQuantity());
			 stockOutDTO.setWorkOrderNo(scrapDetails.get(0).getProductionWorkOrder().getWorkOrderNo());
			 stockOutDTO.setStockOutQty(scrapStoreReg.get(0).getStockOutQty());
			 stockOutDTO.setQcStatus("Approved");
			 stockOutDTO.setQcSupervisor(scrapStoreReg.get(0).getUpdatedBy());
			 stockOutDTO.setCustomerName(soItemList.get(0).getOrder().getCustomer().getCustomerName());
			 stockOutDTO.setBundleId("01");
			 stockOutDTO.setConfirmStatus("Yes");
			 stockOutDTO.setPackingSlipNo(null);
			 stockOutDTO.setRemarks("Approved");
			 stockOutDTO.setSupervisor(userName);
			 stockOutDTO.setWeight(scrapStoreReg.get(0).getStockOutQty());
			 stockOutDTO.setBagWeight(null);
			 stockOutDTO.setDeliveryChallanNo(newdeliveryChallanNo);
			 StockOut stockOut=stockOutDTO.getStockOut();
			 createStockOut=stockOutService.create(stockOut);
			 
			 if(createStockOut!=null){
				  ScrapStoreRegDTO scrapStoreRegDTO=new ScrapStoreRegDTO();
				  scrapStoreRegDTO.setItemCode(scrapStoreReg.get(0).getItems().getItemCode());
				  scrapStoreRegDTO.setItemDescription(scrapStoreReg.get(0).getItems().getItemDescription());
				  scrapStoreRegDTO.setItemId(scrapStoreReg.get(0).getItems().getItemId());
				  scrapStoreRegDTO.setScrapStoreRegId(scrapStoreReg.get(0).getScrapStoreRegId());
				  scrapStoreRegDTO.setStockOutQty(scrapStoreReg.get(0).getStockOutQty());
		          if(scrapStoreReg.get(0).getStockQuantity()>scrapStoreReg.get(0).getStockOutQty())
				  scrapStoreRegDTO.setStockQuantity(scrapStoreReg.get(0).getStockQuantity()-scrapStoreReg.get(0).getStockOutQty());
		          else
		          scrapStoreRegDTO.setStockQuantity(0.0);
				  scrapStoreRegDTO.setUpdatedBy(scrapStoreReg.get(0).getUpdatedBy());
				  scrapStoreRegDTO.setUpdatedTime(scrapStoreReg.get(0).getUpdatedTime().toString());
				  scrapStoreRegDTO.setStoreId(scrapStoreReg.get(0).getStore().getStoreId());
				  ScrapStoreReg scrapStoreRegs=scrapStoreRegDTO.getScrapStoreReg();
				  updateScrapStoreReg=scrapStoreRegService.update(scrapStoreRegs);

			 }//end of  if(createStockOut!=null) condition
		   }//end of  if(soItemList.size()>0) condition
		 }//end of for loop
			int itemExist=0;
			for(int m=0;m<idsSelected.length;m++){
				 /*Method to fetch scrap items based on the id selected*/
			     List<ScrapStoreReg>scrapStoreReg=scrapStoreRegService.findByScrapStoreRegId(idsSelected[m]);
			     String itemCode=scrapStoreReg.get(0).getItems().getItemCode();
			     /*Method to fetch salesorder items based on salesOrderNo,itemCode*/
			     List<SalesOrderItem>soItemList=orderDetailsService.findByOrderIdItemId(salesOrderNo, itemCode);
                 if(soItemList.size()>0)
                	 itemExist++;
			}//end of for loop
			if(updateScrapStoreReg==true && itemExist>0){
				/*Creating a new instance of DeliveryChallanDTO*/
				DeliveryChallanDTO deliveryChallanDTO=new DeliveryChallanDTO();
    			deliveryChallanDTO.setDeliveryChallanNo(newdeliveryChallanNo);
    			deliveryChallanDTO.setChallanDate(challanDate);
    			deliveryChallanDTO.setInvoiceStatus("No");
    			deliveryChallanDTO.setOrderId(salesOrderNo);
    			deliveryChallanDTO.setStatus("Created");
    			deliveryChallanDTO.setRemarks("");
    		
    			DeliveryChallan deliveryChallan=deliveryChallanDTO.getDeliveryChallan();
    			
    			createddc=deliveryChallanService.create(deliveryChallan);
			}//end of if(updateScrapStoreReg==true && itemExist>0) condition
			
			if(createddc!=null){
				for(int i=0;i<idsSelected.length;i++){
				     List<ScrapStoreReg>scrapStoreReg=scrapStoreRegService.findByScrapStoreRegId(idsSelected[i]);
				     String itemCode=scrapStoreReg.get(0).getItems().getItemCode();
				     String itemDesc=scrapStoreReg.get(0).getItems().getItemDescription();
				     String unitType=scrapStoreReg.get(0).getItems().getUnit().getUnitType();
				     String units=scrapStoreReg.get(0).getItems().getUnit().getUnits();
				     List<SalesOrderItem>soItemList=orderDetailsService.findByOrderIdItemId(salesOrderNo, itemCode);
                     
				    if(soItemList.size()>0){
					DeliveryChallanItemsDTO deliveryChallanItemsDTO=new DeliveryChallanItemsDTO();
   					deliveryChallanItemsDTO.setDeliveryChallanNo(newdeliveryChallanNo);
   					deliveryChallanItemsDTO.setItemId(scrapStoreReg.get(0).getItems().getItemId());
   					deliveryChallanItemsDTO.setItemDescription(scrapStoreReg.get(0).getItems().getItemDescription());
   					deliveryChallanItemsDTO.setNoOfRolls((long)1);
   					deliveryChallanItemsDTO.setQtyPerRoll(scrapStoreReg.get(0).getStockOutQty());
   					deliveryChallanItemsDTO.setTotalQty(scrapStoreReg.get(0).getStockOutQty());
   					deliveryChallanItemsDTO.setUnits(scrapStoreReg.get(0).getItems().getUnit().getUnits());
   					deliveryChallanItemsDTO.setRate(soItemList.get(0).getRate());
   					deliveryChallanItemsDTO.setAssortedType(scrapStoreReg.get(0).getItems().getAssortedType());
   					deliveryChallanItemsDTO.setProductTypeKey(scrapStoreReg.get(0).getItems().getProductType().getProductKey());
   				    DeliveryChallanItems dcItemList=deliveryChallanItemsDTO.getDeliveryChallanItems();
   				    createdDcItem=deliveryChallanItemsService.create(dcItemList);
   				    /*Creating a new instance of PackingSlipDTO */
   				    PackingSlipDTO packingSlipDTO=new PackingSlipDTO();
   				    
   				    if(newdeliveryChallanNo!=null){
			        packingSlipDTO.setPackingSlipNo(newdeliveryChallanNo+"/01");
			        packingSlipDTO.setDeliveryChallanNo(newdeliveryChallanNo);
   				    }//end of  if(newdeliveryChallanNo!=null) condition
   				    
   				    if(itemDesc!=null)
			        packingSlipDTO.setInputSize(itemDesc);
			        packingSlipDTO.setNoOfRolls(1);
			        
			        if(scrapStoreReg.get(0).getStockOutQty()!=null){
			        packingSlipDTO.setQuanityPerRoll(scrapStoreReg.get(0).getStockOutQty());
			        packingSlipDTO.setTotalQuantity(scrapStoreReg.get(0).getStockOutQty());
			        packingSlipDTO.setWeight(scrapStoreReg.get(0).getStockOutQty());
			        }//end of  if(scrapStoreReg.get(0).getStockOutQty()!=null) condition
			        
			        if(units!=null)
			        packingSlipDTO.setUnits(units);
			        
			        if(unitType!=null)
			        packingSlipDTO.setUnitType(unitType);
			        PackingSlip packingSlip=packingSlipDTO.getPackingSlip();
			        packingSlipService.create(packingSlip);
		   				    
   				    if(createdDcItem!=null){
   				    	Double dispatchedQty=scrapStoreReg.get(0).getStockOutQty();
   				    	Double orderedQty=soItemList.get(0).getQuantity();
   				    	Double balanceQty=0.0;
   				    	
   				    	if(orderedQty>dispatchedQty)
   				    	balanceQty=orderedQty-dispatchedQty;
   				    	
   				 	SalesOrderItemsDTO soItemDTO=new SalesOrderItemsDTO();
   			  		soItemDTO.setOrderDetailId(soItemList.get(0).getOrderDetailId());
   			  		soItemDTO.setOrderId(soItemList.get(0).getOrder().getOrderId());
   			  		soItemDTO.setItemId(soItemList.get(0).getItem().getItemId());
   			  		soItemDTO.setQuantity(soItemList.get(0).getQuantity());
   			  		soItemDTO.setBalanceQty(balanceQty);
   			  		soItemDTO.setWeight(soItemList.get(0).getWeight());
   			  		soItemDTO.setBundleSize(soItemList.get(0).getBundleSize());
   			  		soItemDTO.setRate(soItemList.get(0).getRate());
   			  		soItemDTO.setWoQty(dispatchedQty);
   			  		soItemDTO.setCompletedQty(0.0);
   			  		soItemDTO.setItemCode(soItemList.get(0).getItemCode());
   			  		soItemDTO.setProductionQty(0.0);
   			  		soItemDTO.setDispatchedQty(dispatchedQty);
   			  		soItemDTO.setUpdatedBy(soItemList.get(0).getUpdatedBy());
   			  		soItemDTO.setUpdatedTime(soItemList.get(0).getUpdatedTime().toString());
   			  	    soItemDTO.setPvcWeight(soItemList.get(0).getPvcWeight());
   			  		SalesOrderItem soItem=soItemDTO.getOrderDetail();
   			  		updateSalesOrderItem=orderDetailsService.update(soItem);
   		
   				    }//end of if(createdDcItem!=null) condition
				}//end of if(soItemList.size()>0) condition
			}//end of for loop
			if(updateSalesOrderItem==true){
					List<SalesOrderItem> salesOrderItemList=orderDetailsService.findByOrderId(salesOrderNo);
					if(salesOrderItemList.size()>0){
					int soStatus=0;
						for(int j=0;j<salesOrderItemList.size();j++){
							Double totalOrderedQty=salesOrderItemList.get(j).getQuantity();
							Double totalStockedOutQty=salesOrderItemList.get(j).getDispatchedQty();
							if(!(totalStockedOutQty>=(96*totalOrderedQty)/100)){
								soStatus++;
							}
						}
						if(soStatus==0){
							List<SalesOrder>soDetails=orderService.findBySalesOrderNoId(salesOrderNo);
							
							if(soDetails.size()>0){
							List<OrderStatus>orderStatus=orderStatusService.findByStatus("Dispatched");
							
							if(orderStatus.size()>0 && soDetails.size()>0 ){
								
							OrderDTO orderDTO=new OrderDTO();
							orderDTO.setOrderId(soDetails.get(0).getOrderId());
							if(soDetails.get(0).getOrderRecDate()!=null)
							orderDTO.setOrderRecDate(Utility.formDateFormatter.print(soDetails.get(0).getOrderRecDate().getTime()));
							if(soDetails.get(0).getOrderAcceptanceDate()!=null)
							orderDTO.setOrderAcceptanceDate(Utility.formDateFormatter.print(soDetails.get(0).getOrderAcceptanceDate().getTime()));
							if(soDetails.get(0).getOrderDeliveryDate()!=null)
							orderDTO.setOrderDeliveryDate(Utility.formDateFormatter.print(soDetails.get(0).getOrderDeliveryDate().getTime()));
							orderDTO.setCustomerId(soDetails.get(0).getCustomer().getCustomerId());
							orderDTO.setPoDetails(soDetails.get(0).getPoDetails());
							orderDTO.setModeOfReceipt(soDetails.get(0).getModeOfReceipt());
							orderDTO.setOrderStatusId(orderStatus.get(0).getOrderStatusId());
							orderDTO.setCreatedTime(soDetails.get(0).getCreatedTime().toString());
							if(soDetails.get(0).getTargetDate()!=null)
							orderDTO.setTargetDate(Utility.formDateFormatter.print(soDetails.get(0).getTargetDate().getTime()));
							orderDTO.setCreatedBy(soDetails.get(0).getCreatedBy());
							orderDTO.setUpdatedBy(soDetails.get(0).getUpdatedBy());
							orderDTO.setUpdatedTime(soDetails.get(0).getUpdatedTime().toString());
							orderDTO.setInputQuantity(soDetails.get(0).getInputQuantity());
							orderDTO.setMailStatus(soDetails.get(0).getMailStatus());
							orderDTO.setLmeDetails(soDetails.get(0).getLmeDetails());
							SalesOrder salesOrder=orderDTO.getOrder();
							orderService.update(salesOrder);
							
							}//end of if(orderStatus.size()>0 && soDetails.size()>0 ) condition
						}//end of if(soDetails.size()>0) condition
					}//end of if(soStatus==0) condition
				}
			       dcNoList.add(newdeliveryChallanNo);
				}//end of if(updateSalesOrderItem==true) condition
			}//end of if(createddc!=null) condition
		}//end of if(newdeliveryChallanNo!=null) condition	
		 return dcNoList;
   }
}