package org.balajicables.salesmanager.controller;

import javax.validation.Valid;

import org.balajicables.salesmanager.dao.UserDao;
import org.balajicables.salesmanager.model.User;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class SignupController {

	@Autowired
	UserDao userDao;

	Logger logger = LoggerFactory.getLogger(SignupController.class);

	@RequestMapping(value = "/signup", method = RequestMethod.GET)
	public String signup() {
		return "signup";
	}

	@RequestMapping(value = "/signup", method = RequestMethod.POST)
	public void signup(@Valid User user) {
		userDao.save(user);
		logger.info("User " + user);
	
	}
}
