package org.balajicables.salesmanager.controller;

import java.util.ArrayList;
import java.util.List;
import javax.annotation.Resource;

import org.apache.commons.lang.WordUtils;
import org.balajicables.salesmanager.CustomUser;
import org.balajicables.salesmanager.common.JqgridResponse;
import org.balajicables.salesmanager.common.StatusResponse;
import org.balajicables.salesmanager.dto.ProductionWorkOrderDTO;
import org.balajicables.salesmanager.dto.SalesOrderItemsDTO;
import org.balajicables.salesmanager.dto.StockInDTO;
import org.balajicables.salesmanager.dto.StoreRegisterDTO;
import org.balajicables.salesmanager.dto.WorkOrderItemsDTO;
import org.balajicables.salesmanager.dto.WorkOrderOutputDTO;
import org.balajicables.salesmanager.model.Customer;
import org.balajicables.salesmanager.model.ProductionWorkOrder;
import org.balajicables.salesmanager.model.SalesOrder;
import org.balajicables.salesmanager.model.SalesOrderItem;
import org.balajicables.salesmanager.model.StockIn;
import org.balajicables.salesmanager.model.StoreRegister;
import org.balajicables.salesmanager.model.WorkOrderItems;
import org.balajicables.salesmanager.model.WorkOrderOutput;
import org.balajicables.salesmanager.service.CustomerService;
import org.balajicables.salesmanager.service.OrderDetailsService;
import org.balajicables.salesmanager.service.OrderService;
import org.balajicables.salesmanager.service.ProductionWorkOrderService;
import org.balajicables.salesmanager.service.StockInService;
import org.balajicables.salesmanager.service.StoreRegisterService;
import org.balajicables.salesmanager.service.WorkOrderItemService;
import org.balajicables.salesmanager.service.WorkOrderOutputService;
import org.balajicables.salesmanager.utils.Utility;
import org.springframework.data.domain.Page;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
/**
* This class demonstrates Stock In Module
* @author Abin Sam
*/
@Controller
@RequestMapping("/stockin")

public class StockInController {

	@Resource
	private StockInService stockInService;
	
	@Resource
	private CustomerService customerService;
	
	@Resource
	private OrderService orderService;
	
	@Resource
	private ProductionWorkOrderService productionWorkOrderService;
	
	@Resource
	private OrderDetailsService orderDetailsService;
	
	@Resource
	private WorkOrderOutputService workOrderOutputService;
	
	@Resource
	private StoreRegisterService storeRegisterService;

	@Resource
	private WorkOrderItemService workOrderItemService;
	/**
	   * This method returns stockIn.jsp.
	   * @param Model to set the attribute.
	   * @return stockIn.jsp.
	   */
	@RequestMapping(method = RequestMethod.GET)
	public String getStockIn(Model model) 
	{
		/*Method to fetch list of customers*/
		List<Customer> customers = customerService.findAll();
		model.addAttribute("customers", customers);//set customers to model attribute
		/*Method to fetch list of salesorders*/
		List<SalesOrder> order = orderService.findAll();
		model.addAttribute("order", order);//set salesorder numbers to model attribute
	
		return "stockIn";
	}
     /**
	   * Method to save selected items for stock in
	   * @param sales order,item code,work order, bundle id,customer,item description,quantity,weight,bag no and bag weight
	   * @return List<String> statusMssgList
	   */	
	@RequestMapping(value = "/saveStock", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	List<String> crudStockIn(
			@RequestParam  String ItemCode,
			@RequestParam  String SalesOrderId,
			@RequestParam  String WorkOrderNo,
			@RequestParam  String BundleId,
			@RequestParam  String CustomerName,
			@RequestParam  String ItemDesc,
			@RequestParam  Double Quantity,
			@RequestParam  Double Weight
			)
			{
		if(ItemCode!=null)
		   WordUtils.capitalize(ItemCode);
		if(SalesOrderId!=null)
			WordUtils.capitalize(SalesOrderId);
		if(WorkOrderNo!=null)
			WordUtils.capitalize(WorkOrderNo);
		Integer woItemTotalBundle=0;
		/*Initialization of empty list of type String*/
		List<String> statusMssgList=new ArrayList<>();
		/*Method to fetch storeregister itemlist based on SalesOrderId, ItemCode, BundleId, WorkOrderNo*/
        List<StoreRegister>storeRegisterList=storeRegisterService.findByOrderIdAndItemCodeAndBundleIdAndWorkOrderNo(SalesOrderId, ItemCode, BundleId, WorkOrderNo);
        /*Method to fetch workorder item list itemlist based on SalesOrderId,ItemCode,WorkOrderNo*/
        List<WorkOrderItems> woItemIdList=workOrderItemService.findByOrderIdAndItemCodeAndWorkOrderNo(SalesOrderId,ItemCode,WorkOrderNo);
        
  		    if(woItemIdList.size()>0){
  	        	woItemTotalBundle=woItemIdList.get(0).getNoOfCoils();
  	        }
             String bundleId="";
        	 bundleId=BundleId;
      	     Integer bundleInt=Integer.parseInt(bundleId);
  		     bundleInt= bundleInt+1;
  		     String newBundleId="";
  		     if(bundleInt<10){
  		      newBundleId="00"+String.valueOf(bundleInt);
  		     }
  		     else{
  		      newBundleId="0"+String.valueOf(bundleInt); 
  		     }
  		 
  		     if(bundleInt>woItemTotalBundle){
  		    	 newBundleId="001"; 
  		     }
        
        if(storeRegisterList.size()>0){
        	 statusMssgList.add("exist");
	    	 statusMssgList.add(newBundleId);
	    }else{
		   String confirmStatus="No";
			List<StockIn> stockInList=stockInService.findByOrderIdAndItemCodeAndWoNoAndBundleIdAndConfirmStatus(SalesOrderId,ItemCode,WorkOrderNo,BundleId,confirmStatus);
	        if(stockInList.size()>0){
	       	 statusMssgList.add("added");
	    	 statusMssgList.add(newBundleId);
	 
	        }else{
				statusMssgList=updateStockInProcess(SalesOrderId,ItemCode,WorkOrderNo,BundleId,Quantity,Weight,newBundleId);

	        }
        }
	return statusMssgList;
   }
	 /**
	   * Method to update the stocked in items
	   * @param sales order,item code,work order, bundle id,customer,item description,quantity,weight,bag no and bag weight
	   * @return List<String> statusMssgList
	   */	
  private List<String> updateStockInProcess(String salesOrderId, String itemCode,String workOrderNo, String bundleId, Double quantity,
			Double weight, String newBundleId) {
	    /*Fetch logged in user*/
	    CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();;
		String userName = user.getFirstName()+" "+user.getLastName();
	    /*Method to fetch Production work order item list */
	    List<ProductionWorkOrder>pdnList=productionWorkOrderService.findByProductionWorkOrderNo(workOrderNo);
	    List<SalesOrderItem> soItemDetailsList=null;
	
		Long itemId=(long) 0;
		long orderdetailId=0;
		 List<String> statusMssgList=new ArrayList<>();
	    if(pdnList.get(0).getProcess().getProcessType().equalsIgnoreCase("Extrusion")){
		List<WorkOrderItems> woItemList=workOrderItemService.findByOrderIdAndItemCodeAndWorkOrderNo(salesOrderId, itemCode, workOrderNo);
		if(woItemList.size()>0){
			soItemDetailsList=orderDetailsService.findById(woItemList.get(0).getSalesOrderItem().getOrderDetailId());  
			itemId=woItemList.get(0).getSalesOrderItem().getItem().getItemId();
			orderdetailId=woItemList.get(0).getSalesOrderItem().getOrderDetailId();
		 }//end of if(woItemList.size()>0) condition
		}//end of if(pdnList.get(0).getProcess().getProcessType().equalsIgnoreCase("Extrusion")) condition
	    if(pdnList.get(0).getProcess().getProcessType().equalsIgnoreCase("Bunching") || pdnList.get(0).getProcess().getProcessType().equalsIgnoreCase("MWD")){
		List <WorkOrderOutput> woOutputList=workOrderOutputService.findByOrderIdAndItemCodeAndWorkOrderNo(salesOrderId, itemCode, workOrderNo);
		if(woOutputList.size()>0){
			soItemDetailsList=orderDetailsService.findById(woOutputList.get(0).getSalesOrderItem().getOrderDetailId());      
			itemId=woOutputList.get(0).getSalesOrderItem().getItem().getItemId();
			orderdetailId=woOutputList.get(0).getSalesOrderItem().getOrderDetailId();
		}
	    }
		StockIn createdStore =null;
		String confirmStatus="No";
        List<StockIn>stockInList=stockInService.findByOrderIdAndItemCodeAndWoNoAndBundleIdAndConfirmStatus(salesOrderId, itemCode, workOrderNo, bundleId, confirmStatus);
	    if(stockInList.size()==0){
        StockInDTO stockInDTO=new StockInDTO();
		stockInDTO.setStoreId(1);
		stockInDTO.setOrderDetailId(orderdetailId);
		stockInDTO.setOrderId(salesOrderId);
		stockInDTO.setItemId(itemId);
		stockInDTO.setItemCode(itemCode);
		stockInDTO.setSoItemQty(soItemDetailsList.get(0).getQuantity());
		stockInDTO.setWorkOrderNo(workOrderNo);
		stockInDTO.setStockQty(quantity);
		stockInDTO.setCustomerName(soItemDetailsList.get(0).getOrder().getCustomer().getCustomerName());
	    stockInDTO.setWeight(weight);
		stockInDTO.setBundleId(bundleId);
		stockInDTO.setQcStatus("Pending");
		stockInDTO.setConfirmStatus("No");
		stockInDTO.setSupervisor(userName);
		StockIn stockInItem=stockInDTO.getStockIn();
       
		    createdStore = stockInService.create(stockInItem);//save in stock in table
		   	if(createdStore!=null)
					{
			        List<WorkOrderItems> woItemsList=workOrderItemService.findBySoItemIdAndWorkOrder(orderdetailId,workOrderNo);
			        if(woItemsList.size()>0){
			        	for(int k=0;k<woItemsList.size();k++){
			        		Double stockedQty=woItemsList.get(k).getStockInQty();
			        		Double woQty=woItemsList.get(k).getTotalQuantity();
			        	    if(stockedQty>=(0.96*woQty)){
			        			WorkOrderItemsDTO woDTO=new WorkOrderItemsDTO();
			        			woDTO.setWorkOrderItemId(woItemsList.get(k).getWorkOrderItemId());
			        			woDTO.setWorkOrderNo(woItemsList.get(k).getProductionWorkOrder().getWorkOrderNo());
			        			woDTO.setOrderDetailId(woItemsList.get(k).getSalesOrderItem().getOrderDetailId());
			        			woDTO.setNoOfCoils(woItemsList.get(k).getNoOfCoils());
			        			woDTO.setQtyPerCoil(woItemsList.get(k).getQtyPerCoil());
			        			woDTO.setTotalQuantity(woItemsList.get(k).getTotalQuantity());
			        			woDTO.setPackingType(woItemsList.get(k).getPackingType());
			        			woDTO.setPvcGrade(woItemsList.get(k).getPvcGrade());
			        			woDTO.setMasterBatch(woItemsList.get(k).getMasterBatch());
			        			woDTO.setToBeLabelled(woItemsList.get(k).getToBeLabelled());
			        			woDTO.setStockInQty(woItemsList.get(k).getStockInQty());
			        			woDTO.setUpdatedBy(woItemsList.get(k).getUpdatedBY());
			        			woDTO.setUpdatedTime(woItemsList.get(k).getUpdatedTime().toString());
			        			woDTO.setStockInStatus("Completed");
			        			WorkOrderItems woItem=woDTO.getWorkOrderItem();
			        		    workOrderItemService.update(woItem);
			        			
			        		}
			        	}
			        }
			        int completedStatus= 0;
			        List<WorkOrderItems>woItemsListOfWo=workOrderItemService.findByProductionWorkOrderWorkOrderNo(workOrderNo);
			        for(int l=0;l<woItemsListOfWo.size();l++){
			        	if(woItemsListOfWo.get(l).getStockInStatus().equalsIgnoreCase("Completed"))
			        		completedStatus++;
			        }
			        if(completedStatus==woItemsListOfWo.size()){
			      	List<ProductionWorkOrder>pdnWo=productionWorkOrderService.findByProductionWorkOrderNo(workOrderNo);
			        	ProductionWorkOrderDTO pdnWoDTO=new ProductionWorkOrderDTO();
			        	pdnWoDTO.setWorkOrderNo(pdnWo.get(0).getWorkOrderNo());
			        	pdnWoDTO.setProcessId(pdnWo.get(0).getProcess().getProcessId());
			        	pdnWoDTO.setMachineNo(pdnWo.get(0).getMachine().getMachineNo());
			        	if(pdnWo.get(0).getStartDate()!=null)
			        	pdnWoDTO.setStartDate(Utility.formDateFormatter.print(pdnWo.get(0).getStartDate().getTime()));
			        	if(pdnWo.get(0).getStartTime()!=null)
			        	pdnWoDTO.setStartTime(pdnWo.get(0).getStartTime().toString());
			        	if(pdnWo.get(0).getEndDate()!=null)
			        	pdnWoDTO.setEndDate(Utility.formDateFormatter.print(pdnWo.get(0).getEndDate().getTime()));
			        	if(pdnWo.get(0).getEndTime()!=null)
			        	pdnWoDTO.setEndTime(pdnWo.get(0).getEndTime().toString());
			        	pdnWoDTO.setStatus("Completed");
			        	pdnWoDTO.setCreatedTime(pdnWo.get(0).getCreatedTime().toString());
			        	pdnWoDTO.setCreatedBy(pdnWo.get(0).getCreatedBy());
			        	pdnWoDTO.setInputWeight(pdnWo.get(0).getInputWeight());
			        	pdnWoDTO.setOutputWeight(pdnWo.get(0).getOutputWeight());
			        	pdnWoDTO.setBalanceWeight(pdnWo.get(0).getBalanceWeight());
			        	ProductionWorkOrder pdnWorkOrder=pdnWoDTO.getPdnWorkOrder();
			        	productionWorkOrderService.update(pdnWorkOrder);
			        	
				        }
	               	 statusMssgList.add("created");
			  	     statusMssgList.add(newBundleId);// automatically increment bundle id after save
			 	}// end of if stockInOutList
	    }//end of if(stockInList.size()==0)
		return statusMssgList;
	}
   
  /**
   * Method to fetch the stock in item details based on salesOrderId,itemCode,workOrderNo
   * @param salesOrderId,itemCode,workOrderNo
   * @return List<String> stockInDetaislList
   */
	@RequestMapping(value = "/populateItemDetails", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	List<String> fetchItemDetails(@RequestParam  String salesOrderId,@RequestParam  String itemCode,@RequestParam  String workOrderNo)
		{
		/*Initialisation of empty list of type String*/
		List<String> stockInDetaislList=new ArrayList<>();
		/*Method to fetch work order item list*/
		List<WorkOrderItems> woItemList=workOrderItemService.findByOrderIdAndItemCodeAndWorkOrderNo(salesOrderId,itemCode,workOrderNo);
		String itemDesc="";
		String customerName="";
		String quantity="";
		String units="";
		if(woItemList.size()>0){
			if(woItemList.get(0).getSalesOrderItem().getItem().getItemDescription()!=null)
			itemDesc=woItemList.get(0).getSalesOrderItem().getItem().getItemDescription();
			
			if(woItemList.get(0).getSalesOrderItem().getOrder().getCustomer().getCustomerName()!=null)
			customerName=woItemList.get(0).getSalesOrderItem().getOrder().getCustomer().getCustomerName();
			
			if(woItemList.get(0).getSalesOrderItem().getBundleSize()!=null)
			quantity=woItemList.get(0).getSalesOrderItem().getBundleSize().toString();
			
			if(woItemList.get(0).getSalesOrderItem().getItem().getUnit().getUnits()!=null)
				units=woItemList.get(0).getSalesOrderItem().getItem().getUnit().getUnits();	
		}//end of if(woItemList.size()>0)
		
		stockInDetaislList.add(itemDesc);
		stockInDetaislList.add(customerName);
		stockInDetaislList.add(quantity);
		stockInDetaislList.add(units);
				
		return stockInDetaislList;
	}
	/**
	   * This method fetch stock in records based on search parameters for grid
	   * Fetch  stock in records for grid
	   * @param searchObject,search,filters,pageNumber,rowsPerPage,sortColName,sortOrder
	   * @return JqgridResponse<StockInDTO>response
	   */
	@RequestMapping(value="/records", produces="application/json", method=RequestMethod.POST)
	public @ResponseBody
	JqgridResponse<StockInDTO> records(
			@RequestParam(value="searchObject", required=false) String searchObject,
			@RequestParam("_search") Boolean search,
    		@RequestParam(value="filters", required=false) String filters,
			@RequestParam(value = "page", required = false) Integer pageNumber,
			@RequestParam(value = "rows", required = false) Integer rowsPerPage,
			@RequestParam(value = "sidx", required = false) String sortColName,
			@RequestParam(value = "sord", required = false, defaultValue = "asc") String sortOrder) {
		/*JQGrid column sorting*/
		if(sortColName.equalsIgnoreCase("workOrderNo")){
			sortColName="productionWorkOrder.workOrderNo";
		}
		
		if(sortColName.equalsIgnoreCase("itemDescription")){
			sortColName="salesOrderItem.items.itemDescription";
		}
		
		if(sortColName.equalsIgnoreCase("units")){
			sortColName="salesOrderItem.items.unit.units";
		}
		
		if(sortColName.equalsIgnoreCase("customerName")){
			sortColName="salesOrderItem.orders.customer.customerName";
		}
		if(sortColName.equalsIgnoreCase("customerCode")){
			sortColName="salesOrderItem.orders.customer.customerCode";
		}
		if(sortColName.equalsIgnoreCase("workOrderNo")){
			sortColName="productionWorkOrder.workOrderNo";
		}
		if(sortColName.equalsIgnoreCase("itemDescription")){
			sortColName="salesOrderItem.items.itemDescription";
		}
		if(sortColName.equalsIgnoreCase("units")){
			sortColName="salesOrderItem.items.unit.units";
		}
		/*Fetch logged in user*/
		CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();;
        String userName=user.getFirstName()+" "+user.getLastName();
	
		String confirmStatus="No";
		/*Fetch jqgrid paged stock in records when search parameter is null*/
		Page<StockIn>stockIn = stockInService.getPagedStockInBySupervisor(pageNumber - 1,rowsPerPage, sortColName, sortOrder,confirmStatus,userName);
		/*Intialize JQ grid response of type StockInDTO */
		JqgridResponse<StockInDTO> response = new JqgridResponse<StockInDTO>();
		/*Method to set StockIn item list to StockInDTO*/
		List<StockInDTO> stockInDTOs = convertToStoreDTO(stockIn.getContent());
		response.setRows(stockInDTOs);
		response.setRecords(Long.valueOf(stockIn.getTotalElements()).toString());
		response.setTotal(Long.valueOf(stockIn.getTotalPages()).toString());
		response.setPage(Integer.valueOf(stockIn.getNumber()+1).toString());
		return response;
		}
	 /**
	   * This method to set StockIn item to StockInDTO
	   * @param StockIn
	   * @return List<StockInDTO>
	   */	
	private List<StockInDTO> convertToStoreDTO(List<StockIn> stockedIn) {
		List<StockInDTO> stockInDTOs = new ArrayList<>();
		for(StockIn stockIn : stockedIn) {   
			StockInDTO stockInDTO=new StockInDTO();
			stockInDTO.setStockInId(stockIn.getStockInId());
			stockInDTO.setStoreId(stockIn.getStore().getStoreId());
			stockInDTO.setOrderDetailId(stockIn.getSalesOrderItem().getOrderDetailId());
			stockInDTO.setOrderId(stockIn.getSalesOrderItem().getOrder().getOrderId());
			stockInDTO.setItemId(stockIn.getSalesOrderItem().getItem().getItemId());
			stockInDTO.setItemCode(stockIn.getSalesOrderItem().getItem().getItemCode());
			stockInDTO.setItemDescription(stockIn.getSalesOrderItem().getItem().getItemDescription());
			stockInDTO.setSoItemQty(stockIn.getSalesOrderItem().getQuantity());
			stockInDTO.setWorkOrderNo(stockIn.getProductionWorkOrder().getWorkOrderNo());
			stockInDTO.setStockInDateTime(stockIn.getStockInDateTime().toString());
			stockInDTO.setStockQty(stockIn.getStockQty());
			stockInDTO.setQcStatus(stockIn.getQcStatus());
			stockInDTO.setCustomerName(stockIn.getSalesOrderItem().getOrder().getCustomer().getCustomerName());
			stockInDTO.setCustomerCode(stockIn.getSalesOrderItem().getOrder().getCustomer().getCustomerCode());
			stockInDTO.setBundleId(stockIn.getBundleId());
			stockInDTO.setWeight(stockIn.getWeight());
			stockInDTO.setBatchNo(stockIn.getBatchNo());
			stockInDTO.setConfirmStatus(stockIn.getConfirmStatus());
			stockInDTO.setSupervisor(stockIn.getSupervisor());
			stockInDTO.setUnits(stockIn.getSalesOrderItem().getItem().getUnit().getUnits());
			stockInDTOs.add(stockInDTO)	;
			}
		return stockInDTOs;
	}	
	 /**
	   * Crud functionality for stock in items and create delivery challan 
	   * @param idsSelected
	   * @return List<String>status message
	   */
	@RequestMapping(value="/crud", produces="application/json" ,method = RequestMethod.POST)
	public @ResponseBody
	StatusResponse confirmStockIn(
   	 @RequestParam(value = "idsOfSelectedRows[]", required = false) Long[] idsSelected) {
		    
		    Boolean updateStockIn=false;
		    /*Fetch logged in user*/
			CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();;
		 	String supervisor = user.getFirstName()+" "+user.getLastName();
		 	
		    Boolean result=false;
		  
		    String workOrderNo=null;
		    String processType=null;
		    String bundleId=null;
		    String batchNo=null;
		    Boolean updatedWoItems=false;
		    Boolean updatedWoOutput=false;
		    Boolean updateSalesOrderItem=false;
	        /*Initialisation of an empty ArrayList of type Long*/
		    ArrayList<Long>soItemNosList = new ArrayList<>();
		    
	 	    for(int i=0;i<idsSelected.length;i++){
	 		 Long orderDetailsId=null;
	 		 StoreRegister createdStoreReg=null;   
	 		 List<StockIn> stockInRecords=stockInService.findByStockInId(idsSelected[i]);
			 if(stockInRecords.size()>0){
						
			 StockInDTO stockInDTO=new StockInDTO();
			 stockInDTO.setStockInId(idsSelected[i]);
			 stockInDTO.setStoreId(stockInRecords.get(0).getStore().getStoreId());
			 stockInDTO.setOrderDetailId(stockInRecords.get(0).getSalesOrderItem().getOrderDetailId());
			 stockInDTO.setOrderId(stockInRecords.get(0).getSalesOrderItem().getOrder().getOrderId());
			 stockInDTO.setItemId(stockInRecords.get(0).getSalesOrderItem().getItem().getItemId());
			 stockInDTO.setItemCode(stockInRecords.get(0).getSalesOrderItem().getItem().getItemCode());
			 stockInDTO.setSoItemQty(stockInRecords.get(0).getSalesOrderItem().getQuantity());
			 stockInDTO.setWorkOrderNo(stockInRecords.get(0).getProductionWorkOrder().getWorkOrderNo());
		     stockInDTO.setStockQty(stockInRecords.get(0).getStockQty());
			 stockInDTO.setQcStatus(stockInRecords.get(0).getQcStatus());
			 stockInDTO.setCustomerName(stockInRecords.get(0).getSalesOrderItem().getOrder().getCustomer().getCustomerName());
			 stockInDTO.setBundleId(stockInRecords.get(0).getBundleId());
			 stockInDTO.setBatchNo(stockInRecords.get(0).getBatchNo());
			 stockInDTO.setConfirmStatus("Yes");
			 stockInDTO.setWeight(stockInRecords.get(0).getWeight());
			 stockInDTO.setSupervisor(supervisor);
			 StockIn stockIn=stockInDTO.getStockIn();
			 updateStockIn=stockInService.update(stockIn);
			 String bundleIdValue=stockInRecords.get(0).getBundleId();
			 List<StoreRegister> storeRegLists=storeRegisterService.findByOrderDetailIdAndBundleIdAndWorkOrderNo(stockInRecords.get(0).getSalesOrderItem().getOrderDetailId(), bundleIdValue, stockInRecords.get(0).getProductionWorkOrder().getWorkOrderNo());
			 if(updateStockIn==true && storeRegLists.size()==0){
				 StoreRegisterDTO storeRegDTO=new StoreRegisterDTO();
				 storeRegDTO.setItemCode(stockInRecords.get(0).getItemCode());
				 storeRegDTO.setStoreId(stockInRecords.get(0).getStore().getStoreId());
				 storeRegDTO.setWorkOrderNo(stockInRecords.get(0).getProductionWorkOrder().getWorkOrderNo());
				 storeRegDTO.setCustomerName(stockInRecords.get(0).getCustomerName());
				 storeRegDTO.setStockQty(stockInRecords.get(0).getStockQty());
				 storeRegDTO.setBundleId(stockInRecords.get(0).getBundleId());
				 storeRegDTO.setOrderId(stockInRecords.get(0).getOrderId());
				 storeRegDTO.setOrderDetailId(stockInRecords.get(0).getSalesOrderItem().getOrderDetailId());
				 storeRegDTO.setItemId(stockInRecords.get(0).getItemId());
				 storeRegDTO.setWeight(stockInRecords.get(0).getWeight());
				 storeRegDTO.setSupervisor(supervisor);
				 storeRegDTO.setQcStatus("Pending");
				 storeRegDTO.setQcSupervisor("");
				 storeRegDTO.setRejectStatus("");
				 StoreRegister storeReg=storeRegDTO.getStoreRegister();
				 createdStoreReg=storeRegisterService.create(storeReg);
			 }			
			}
		   if (createdStoreReg!=null){
			   orderDetailsId=stockInRecords.get(0).getSalesOrderItem().getOrderDetailId();
				if (!soItemNosList.contains(orderDetailsId)) {
					soItemNosList.add(orderDetailsId);
				}
		       workOrderNo=stockInRecords.get(0).getProductionWorkOrder().getWorkOrderNo();
		       processType=stockInRecords.get(0).getProductionWorkOrder().getProcess().getProcessType();
		       bundleId=stockInRecords.get(0).getBundleId();
			   Long bundleNo=Long.valueOf(bundleId);
			   if(bundleNo<10)
				   batchNo=workOrderNo+"/0"+bundleNo;
			   else
				   batchNo=workOrderNo+"/"+bundleNo;
			   
			result=true;
		   }//end of  if (createdStoreReg!=null) condition
			
		if(result==true && soItemNosList.size()>0 && workOrderNo!=null && processType.equalsIgnoreCase("Extrusion")){
			List<WorkOrderItems> workOrderItemList=workOrderItemService.findBySoItemIdAndWorkOrder(orderDetailsId,workOrderNo);
			WorkOrderItemsDTO woItemsDTO=new WorkOrderItemsDTO();
			if(workOrderItemList.size()>0){
			Double updatedStockInQty=0.0;
				String confirmStatus="Yes";
				List<StockIn> stockInMaxBundleIdList=stockInService.findByOrderDetailIdAndWorkOrderNoAndConfirmStatusAndMaxBundleId(orderDetailsId,workOrderNo,confirmStatus);
                if(stockInMaxBundleIdList.size()>0){
                	for(int m=0;m<stockInMaxBundleIdList.size();m++){
                    String units=stockInMaxBundleIdList.get(m).getSalesOrderItem().getItem().getUnit().getUnits();
                	if(units.equalsIgnoreCase("Kgs") || units.equalsIgnoreCase("Kg"))
                        updatedStockInQty=updatedStockInQty+stockInMaxBundleIdList.get(m).getWeight();
	             	else
                    	updatedStockInQty=updatedStockInQty+stockInMaxBundleIdList.get(m).getStockQty();
                	}
                }
				Double woItemQty=workOrderItemList.get(0).getTotalQuantity();
				Double toleranceWoQty=((96*woItemQty)/100);
				if(updatedStockInQty>=toleranceWoQty){
					woItemsDTO.setStockInStatus("Completed");
				}
				else{
					woItemsDTO.setStockInStatus(workOrderItemList.get(0).getStockInStatus());
				}
				woItemsDTO.setWorkOrderItemId(workOrderItemList.get(0).getWorkOrderItemId());
				woItemsDTO.setWorkOrderNo(workOrderItemList.get(0).getProductionWorkOrder().getWorkOrderNo());
				woItemsDTO.setOrderDetailId(workOrderItemList.get(0).getSalesOrderItem().getOrderDetailId());
				woItemsDTO.setNoOfCoils(workOrderItemList.get(0).getNoOfCoils());
				woItemsDTO.setQtyPerCoil(workOrderItemList.get(0).getQtyPerCoil());
				woItemsDTO.setTotalQuantity(workOrderItemList.get(0).getTotalQuantity());
				woItemsDTO.setPackingType(workOrderItemList.get(0).getPackingType());
				woItemsDTO.setPvcGrade(workOrderItemList.get(0).getPvcGrade());
				woItemsDTO.setMasterBatch(workOrderItemList.get(0).getMasterBatch());
				woItemsDTO.setToBeLabelled(workOrderItemList.get(0).getToBeLabelled());
				woItemsDTO.setStockInQty(updatedStockInQty);
				woItemsDTO.setUpdatedBy(workOrderItemList.get(0).getUpdatedBY());
				woItemsDTO.setUpdatedTime(workOrderItemList.get(0).getUpdatedTime().toString());
			   WorkOrderItems woItem=woItemsDTO.getWorkOrderItem();
			   updatedWoItems=workOrderItemService.update(woItem);
		      }
			
		     int completedStatus= 0;
		        List<WorkOrderItems>woItemsListOfWo=workOrderItemService.findByProductionWorkOrderWorkOrderNo(workOrderNo);
		        for(int l=0;l<woItemsListOfWo.size();l++){
		        	if(woItemsListOfWo.get(l).getStockInStatus().equalsIgnoreCase("Completed"))
		        		completedStatus++;
		        }
		        if(completedStatus==woItemsListOfWo.size()){
		             productionWorkOrderService.updateWorkOrderStatus(workOrderNo, "Completed");

		 	        }
     	}
		if(result==true && soItemNosList.size()>0 && workOrderNo!=null && (processType.equalsIgnoreCase("Bunching") || processType.equalsIgnoreCase("MWD"))){
			List<WorkOrderOutput> workOrderOutputList=workOrderOutputService.findBySoItemIdAndWorkOrderNoAndBatchNo(orderDetailsId, workOrderNo,batchNo);
			WorkOrderOutputDTO woOutputDTO=new WorkOrderOutputDTO();
			if(workOrderOutputList.size()>0){
	    		woOutputDTO.setWoOutPutId(workOrderOutputList.get(0).getWoOutPutId());
	    		woOutputDTO.setWorkOrderNo(workOrderOutputList.get(0).getProductionWorkOrder().getWorkOrderNo());
	    		woOutputDTO.setNetLength(workOrderOutputList.get(0).getNetLength());
	    		woOutputDTO.setGrossWeight(workOrderOutputList.get(0).getGrossWeight());
	    		woOutputDTO.setNetWeight(stockInRecords.get(0).getWeight());
	    		woOutputDTO.setTareWeight(workOrderOutputList.get(0).getTareWeight());
	    		woOutputDTO.setNoOfStrands(workOrderOutputList.get(0).getNoOfStrands());
	    		woOutputDTO.setSize(workOrderOutputList.get(0).getSize());
	    		woOutputDTO.setSpeed(workOrderOutputList.get(0).getSpeed());
	    		woOutputDTO.setAnnealingPercent(workOrderOutputList.get(0).getAnnealingPercent());
	    		woOutputDTO.setOuterDiameter(workOrderOutputList.get(0).getOuterDiameter());
	    		woOutputDTO.setCreatedTime(workOrderOutputList.get(0).getCreatedTime().toString());
	    		woOutputDTO.setUpdatedBy(workOrderOutputList.get(0).getUpdatedBy());
	    		woOutputDTO.setBatchNo(workOrderOutputList.get(0).getBatchNo());
	    		woOutputDTO.setStockIn("Yes");
	    		woOutputDTO.setOrderDetailId(workOrderOutputList.get(0).getSalesOrderItem().getOrderDetailId());
	    		   WorkOrderOutput woOutput=woOutputDTO.getWorkOrderOutput();
				   updatedWoOutput=workOrderOutputService.update(woOutput);
			   
				
			}
		
		}
		  }
// update sales order item
	 	if(soItemNosList.size()>0){
	 		for(int m=0;m<soItemNosList.size();m++){
	 			Double totalStockedInQty=0.0;
				Double pdnQty=0.0;
				Double totalQty=0.0;
				Double dispatchedQty=0.0;
				Double storeQty=0.0;
				
				
				Double newPdnQty=0.0;
				Double newCompletedQty=0.0;
				Double newBalanceQty=0.0;
				Double newDispatchedQty=0.0;	
				List<StoreRegister> stockedInList=storeRegisterService.findBySalesOrderItemOrderDetailId(soItemNosList.get(m));
				if(stockedInList.size()>0){
		  			for(int k=0;k<stockedInList.size();k++){
		  				String unitsVal=stockedInList.get(k).getSalesOrderItem().getItem().getUnit().getUnits();
		  			 if(unitsVal.equalsIgnoreCase("Kgs")|| unitsVal.equalsIgnoreCase("Kg"))
			  				totalStockedInQty=totalStockedInQty+stockedInList.get(k).getWeight();
                 	 else
                 	        totalStockedInQty=totalStockedInQty+stockedInList.get(k).getStockQty();
		  				  		
		  			}
		  			List<SalesOrderItem>salesOrderItemList=orderDetailsService.findById(soItemNosList.get(m));
					
			  		if(salesOrderItemList.size()>0){
			  			pdnQty=salesOrderItemList.get(0).getProductionQty();
			  		    totalQty=salesOrderItemList.get(0).getQuantity();
			  			dispatchedQty=salesOrderItemList.get(0).getDispatchedQty();
			  			storeQty=salesOrderItemList.get(0).getCompletedQty();
			  			if(totalStockedInQty>=totalQty){
			  				newPdnQty=(double) 0;
			  				newCompletedQty=totalStockedInQty;
			 			   //newBalanceQty=0.0;
			  				newDispatchedQty=dispatchedQty;
			  				
			  			}// end of if loop
			  			else{
			  			 if(pdnQty<=(totalStockedInQty-storeQty)){
			  				 newPdnQty=(double) 0;
			  				 newCompletedQty=totalStockedInQty;
			  				// newBalanceQty=totalQty-totalStockedInQty;
			  				 newDispatchedQty=dispatchedQty;
			  			 }
			  			 else{
			  				 newPdnQty=pdnQty-(totalStockedInQty-storeQty);
			  				 if(newPdnQty<0)
			  				 newPdnQty=0.0;
			  				 newCompletedQty=totalStockedInQty;
			  				// newBalanceQty=totalQty-(newPdnQty+totalStockedInQty);
			  				 newDispatchedQty=dispatchedQty;
			  			 }
			  			}// end of else loop			  				newBalanceQty=0.0;
			  			
			  			newBalanceQty=totalQty-(newPdnQty+newCompletedQty+newDispatchedQty);
			  			if(newBalanceQty<0)
			  				newBalanceQty=0.0;		
			  		SalesOrderItemsDTO soItemDTO=new SalesOrderItemsDTO();
			  		soItemDTO.setOrderDetailId(salesOrderItemList.get(0).getOrderDetailId());
			  		soItemDTO.setOrderId(salesOrderItemList.get(0).getOrder().getOrderId());
			  		soItemDTO.setItemId(salesOrderItemList.get(0).getItem().getItemId());
			  		soItemDTO.setQuantity(totalQty);
			  		soItemDTO.setBalanceQty(newBalanceQty);
			  		soItemDTO.setWeight(salesOrderItemList.get(0).getWeight());
			  		soItemDTO.setPvcWeight(salesOrderItemList.get(0).getPvcWeight());
			  		soItemDTO.setBundleSize(salesOrderItemList.get(0).getBundleSize());
			  		soItemDTO.setRate(salesOrderItemList.get(0).getRate());
			  		soItemDTO.setWoQty(salesOrderItemList.get(0).getWoQty());
			  		soItemDTO.setCompletedQty(newCompletedQty);
			  		soItemDTO.setItemCode(salesOrderItemList.get(0).getItemCode());
			  		soItemDTO.setProductionQty(newPdnQty);
			  		soItemDTO.setDispatchedQty(newDispatchedQty);
			  		soItemDTO.setUpdatedBy(salesOrderItemList.get(0).getUpdatedBy());
			  		soItemDTO.setUpdatedTime(salesOrderItemList.get(0).getUpdatedTime().toString());
			  		
			  		SalesOrderItem soItem=soItemDTO.getOrderDetail();
			  		updateSalesOrderItem=orderDetailsService.update(soItem);
			 	}
				}
		  		if(updateSalesOrderItem==true && (updatedWoItems==true || updatedWoOutput==true))
		  			result=true;
		  		else
		  			result=false;
	 		}
	 	}
		return new StatusResponse(result);
	
	}
	 /**
	   * Method to delete item slected for stock in
	   * @param stockInId
	   * @return StatusResponse
	   */
	@RequestMapping(value = "/delete", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	StatusResponse deleteId(@RequestParam(value = "id", required = true) Long stockInId) {
		Boolean result=false;
		   result = stockInService.delete(stockInId);
			return new StatusResponse(result);
   
	}
	/**
	   * Method to fetch salesorder
	   * @param itemCode,customerId
	   * @return StatusResponse
	   */
	@RequestMapping(value = "/fetchSalesOrder", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	List<String> fetchSalesOrder(
			 @RequestParam(value = "itemCode", required = true) String itemCode,
	       	 @RequestParam(value = "customerId", required = true) Long customerId) {
		 /*Initialisation of empty ArrayList of type String*/
		 ArrayList<String> soNoList = new ArrayList<>();
		 /*Method to fetch list of salesorder items based on itemCode,customerId*/
		 List<SalesOrderItem> soItemList=orderDetailsService.findByItemCodeAndCustomerId(itemCode,customerId);
		
			for (int iterator = 0; iterator < soItemList.size(); iterator++) {
				String soNo = soItemList.get(iterator).getOrder().getOrderId();
                Double stockInQuantity=soItemList.get(iterator).getCompletedQty();
                Double orderedQty=soItemList.get(iterator).getQuantity();
                String orderStatus=soItemList.get(iterator).getOrder().getOrderStatus().getStatus();
                if(orderStatus.equalsIgnoreCase("Approved") || orderStatus.equalsIgnoreCase("Approved For Prodn")){
                	if(!(stockInQuantity>= (96*orderedQty)/100)){
                	if (!soNoList.contains(soNo)) {
    					soNoList.add(soNo);
    				}//end of if (!soNoList.contains(soNo)) condition
                }//end of if(!(stockInQuantity>= (96*orderedQty)/100)) condition
              }//end of outer most if condition
			}//end of for loop
		
		 return soNoList;
	}
	/**
	   * Method to change label of bundles
	   * @RequestParam itemCode,oldSoNo,newSoNo,oldWoNo
	   * @return changeLabelDetails
	   */
	@RequestMapping(value = "/changeLabel", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	List<String> changeLabel(
			 @RequestParam(value = "itemCode", required = true) String itemCode,
	       	 @RequestParam(value = "oldSoNo", required = true) String oldSoNo,
	    	 @RequestParam(value = "newSoNo", required = true) String newSoNo,
	    	 @RequestParam(value = "oldWoNo", required = true) String oldWoNo) {
		/*Fetch logged in username*/ 
		CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();;
	 	String userName = user.getFirstName()+" "+user.getLastName();
	 	/*Initialization of an empty list of type String*/
	 	List<String> changeLabelDetails=new ArrayList<>();
	    String customerName=null;	
		Boolean updateOldSoDetailsList=false;
		Boolean updateNewSoDetailsList=false;
		/*Method to fetch old salesorder items*/
		List<SalesOrderItem> oldSoItemList=orderDetailsService.findByOrdersOrderIdItemsItemCode(oldSoNo, itemCode);
		/*Method to fetch new salesorder items*/
		List<SalesOrderItem> newSoItemList=orderDetailsService.findByOrdersOrderIdItemsItemCode(newSoNo, itemCode);
		
		List<WorkOrderItems> woItemList=null;
		Long oldSalesOrderItemId=null;
		Long newSalesOrderItemId=null;
		if(oldSoItemList.size()>0){
			oldSalesOrderItemId=oldSoItemList.get(0).getOrderDetailId();
		}
		if(newSoItemList.size()>0){
			newSalesOrderItemId=newSoItemList.get(0).getOrderDetailId();
		}
		if(oldSalesOrderItemId!=null && oldWoNo!=null){
			woItemList=workOrderItemService.findBySoItemIdAndWorkOrderNo(oldSalesOrderItemId, oldWoNo);
			WorkOrderItemsDTO workOrderItemsDTO=new WorkOrderItemsDTO();
			workOrderItemsDTO.setWorkOrderItemId(woItemList.get(0).getWorkOrderItemId());
			workOrderItemsDTO.setWorkOrderNo(woItemList.get(0).getProductionWorkOrder().getWorkOrderNo());
			workOrderItemsDTO.setOrderDetailId(newSalesOrderItemId);
			workOrderItemsDTO.setNoOfCoils(woItemList.get(0).getNoOfCoils());
			workOrderItemsDTO.setQtyPerCoil(woItemList.get(0).getQtyPerCoil());
			workOrderItemsDTO.setTotalQuantity(woItemList.get(0).getTotalQuantity());
			workOrderItemsDTO.setPackingType(woItemList.get(0).getPackingType());
			workOrderItemsDTO.setPvcGrade(woItemList.get(0).getPvcGrade());
			workOrderItemsDTO.setMasterBatch(woItemList.get(0).getMasterBatch());
			workOrderItemsDTO.setToBeLabelled(woItemList.get(0).getToBeLabelled());
			workOrderItemsDTO.setStockInQty(woItemList.get(0).getStockInQty());
			workOrderItemsDTO.setStockInStatus(woItemList.get(0).getStockInStatus());
			workOrderItemsDTO.setUpdatedBy(userName);
			
			WorkOrderItems workOrderItems=workOrderItemsDTO.getWorkOrderItem();
			Boolean updateWoItems=workOrderItemService.update(workOrderItems);
			if(updateWoItems==true){
				if(oldSoItemList.size()>0){
					Double balanceQty=0.0;
					Double pdnQty = 0.0;
					pdnQty=oldSoItemList.get(0).getProductionQty()-woItemList.get(0).getTotalQuantity();		
					balanceQty=oldSoItemList.get(0).getQuantity()-(pdnQty+oldSoItemList.get(0).getCompletedQty()+oldSoItemList.get(0).getDispatchedQty());
					if(balanceQty<0.0)	
						balanceQty=0.0;
					SalesOrderItemsDTO salesOrderItemDTO=new SalesOrderItemsDTO();
					salesOrderItemDTO.setOrderDetailId(oldSoItemList.get(0).getOrderDetailId());
					salesOrderItemDTO.setOrderId(oldSoItemList.get(0).getOrder().getOrderId());
					salesOrderItemDTO.setItemId(oldSoItemList.get(0).getItem().getItemId());
					salesOrderItemDTO.setQuantity(oldSoItemList.get(0).getQuantity());
					salesOrderItemDTO.setBalanceQty(balanceQty);
					salesOrderItemDTO.setProductionQty(pdnQty);
					salesOrderItemDTO.setCompletedQty(oldSoItemList.get(0).getCompletedQty());
					salesOrderItemDTO.setDispatchedQty(oldSoItemList.get(0).getDispatchedQty());
					salesOrderItemDTO.setWoQty(oldSoItemList.get(0).getWoQty());
					salesOrderItemDTO.setWeight(oldSoItemList.get(0).getWeight());
					salesOrderItemDTO.setBundleSize(oldSoItemList.get(0).getBundleSize());
					salesOrderItemDTO.setRate(oldSoItemList.get(0).getRate());
					salesOrderItemDTO.setItemCode(oldSoItemList.get(0).getItemCode());
					salesOrderItemDTO.setUpdatedBy(oldSoItemList.get(0).getUpdatedBy());
					salesOrderItemDTO.setUpdatedTime(oldSoItemList.get(0).getUpdatedTime().toString());
					salesOrderItemDTO.setPvcWeight(oldSoItemList.get(0).getPvcWeight());
					
					SalesOrderItem soItem=salesOrderItemDTO.getOrderDetail();
					updateOldSoDetailsList=orderDetailsService.update(soItem);
				}
				if(newSoItemList.size()>0){
					Double newSoBalanceQty=0.0;
					Double newSoPdnQty = 0.0;
					newSoPdnQty=newSoItemList.get(0).getProductionQty()+woItemList.get(0).getTotalQuantity();		
					newSoBalanceQty=newSoItemList.get(0).getQuantity()-(newSoPdnQty+newSoItemList.get(0).getCompletedQty()+newSoItemList.get(0).getDispatchedQty());
					if(newSoBalanceQty<0.0)
						newSoBalanceQty=0.0;
					customerName=newSoItemList.get(0).getOrder().getCustomer().getCustomerName();
					SalesOrderItemsDTO salesOrderItemDTO=new SalesOrderItemsDTO();
					salesOrderItemDTO.setOrderDetailId(newSoItemList.get(0).getOrderDetailId());
					salesOrderItemDTO.setOrderId(newSoItemList.get(0).getOrder().getOrderId());
					salesOrderItemDTO.setItemId(newSoItemList.get(0).getItem().getItemId());
					salesOrderItemDTO.setQuantity(newSoItemList.get(0).getQuantity());
					salesOrderItemDTO.setBalanceQty(newSoBalanceQty);
					salesOrderItemDTO.setProductionQty(newSoPdnQty);
					salesOrderItemDTO.setCompletedQty(newSoItemList.get(0).getCompletedQty());
					salesOrderItemDTO.setDispatchedQty(newSoItemList.get(0).getDispatchedQty());
					salesOrderItemDTO.setWoQty(newSoItemList.get(0).getWoQty());
					salesOrderItemDTO.setWeight(newSoItemList.get(0).getWeight());
					salesOrderItemDTO.setBundleSize(newSoItemList.get(0).getBundleSize());
					salesOrderItemDTO.setRate(newSoItemList.get(0).getRate());
					salesOrderItemDTO.setItemCode(newSoItemList.get(0).getItemCode());
					salesOrderItemDTO.setUpdatedBy(newSoItemList.get(0).getUpdatedBy());
					salesOrderItemDTO.setUpdatedTime(newSoItemList.get(0).getUpdatedTime().toString());
					salesOrderItemDTO.setPvcWeight(newSoItemList.get(0).getPvcWeight());
					
					SalesOrderItem soItems=salesOrderItemDTO.getOrderDetail();
					updateNewSoDetailsList=orderDetailsService.update(soItems);
				}//end of if(newSoItemList.size()>0) condition
			}//end of if(updateWoItems==true) condition
		}//end of if(oldSalesOrderItemId!=null && oldWoNo!=null) condition
	if(updateNewSoDetailsList==true && updateOldSoDetailsList==true){
		changeLabelDetails.add(newSoNo);
		changeLabelDetails.add(customerName);

	}
	    return changeLabelDetails;
	}
	/**
	   * Method to Bar code scanning functionality of stock out
	   * @param item code,sales order no,work order no and bundle id
	   * @return List<String> stockInAttributes
	   */
	@RequestMapping(value = "/barCode", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	List<String> barCode(
			 @RequestParam(value = "itemCode", required = true) String itemCode,
			 @RequestParam(value = "soNo", required = true) String soNo,
			 @RequestParam(value = "woNo", required = true) String woNo,
			 @RequestParam(value = "bundleId", required = false) String bundleId){
		/*Initialization of an empty list of type String*/
		List<String> stockInAttributes=new ArrayList<>();
		if(itemCode!=null && itemCode!="" && soNo!=null && soNo!="" && woNo!=null && woNo!="" 	&& bundleId!=null && bundleId!=""){
		 WordUtils.capitalize(itemCode);
		 WordUtils.capitalize(soNo);
		 WordUtils.capitalize(woNo);
		
		String itemDesc="";
		String customerName="";
		String quantity="";
		String units="";
		String weight="";
		String processType=null;
		/*Method to fetch list of workorder from production work order*/
	    List<ProductionWorkOrder>pdnWoList=productionWorkOrderService.findByProductionWorkOrderNo(woNo);
	    if(pdnWoList.size()>0){
	    	processType=pdnWoList.get(0).getProcess().getProcessType();
	    if(processType.equalsIgnoreCase("Extrusion")){
			List<WorkOrderItems> woItemList=workOrderItemService.findByOrderIdAndItemCodeAndWorkOrderNo(soNo,itemCode,woNo);
		
			if(woItemList.size()>0){
				if(woItemList.get(0).getSalesOrderItem().getItem().getItemDescription()!=null)
				itemDesc=woItemList.get(0).getSalesOrderItem().getItem().getItemDescription();
				
				if(woItemList.get(0).getSalesOrderItem().getOrder().getCustomer().getCustomerName()!=null)
				customerName=woItemList.get(0).getSalesOrderItem().getOrder().getCustomer().getCustomerName();
				
				if(woItemList.get(0).getSalesOrderItem().getBundleSize()!=null)
				quantity=woItemList.get(0).getSalesOrderItem().getBundleSize().toString();
				
				if(woItemList.get(0).getSalesOrderItem().getItem().getUnit().getUnits()!=null)
					units=woItemList.get(0).getSalesOrderItem().getItem().getUnit().getUnits();	
			}
	    }

	    else if(processType.equalsIgnoreCase("Bunching") || processType.equalsIgnoreCase("MWD")){
			   Long bundleNo=Long.valueOf(bundleId);
			   String batchNo="";
			   if(bundleNo<10)
				   batchNo=woNo+"/0"+bundleNo;
			   else
				   batchNo=woNo+"/"+bundleNo;
             /*Method to fetch workorder batch number list*/	
			 List<WorkOrderOutput> woOutputBatchNoList=workOrderOutputService.findByOrderIdAndItemCodeAndWorkOrderNoAndBatchNo(soNo,itemCode,woNo,batchNo);
		
			if(woOutputBatchNoList.size()>0){
				if(woOutputBatchNoList.get(0).getSalesOrderItem().getItem().getItemDescription()!=null)
				itemDesc=woOutputBatchNoList.get(0).getSalesOrderItem().getItem().getItemDescription();
				
				if(woOutputBatchNoList.get(0).getSalesOrderItem().getOrder().getCustomer().getCustomerName()!=null)
				customerName=woOutputBatchNoList.get(0).getSalesOrderItem().getOrder().getCustomer().getCustomerName();
				
				if(woOutputBatchNoList.get(0).getNetLength()!=null)
				quantity=woOutputBatchNoList.get(0).getNetLength().toString();
				
				if(woOutputBatchNoList.get(0).getSalesOrderItem().getItem().getUnit().getUnits()!=null)
					units=woOutputBatchNoList.get(0).getSalesOrderItem().getItem().getUnit().getUnits();	
				if(woOutputBatchNoList.get(0).getNetWeight()!=null)
					weight=woOutputBatchNoList.get(0).getNetWeight().toString();
			}//end of if(woOutputBatchNoList.size()>0) condition
		}
	    
	    }//end of  if(pdnWoList.size()>0) condition
		stockInAttributes.add(itemDesc);
		stockInAttributes.add(customerName);
		stockInAttributes.add(quantity);
		stockInAttributes.add(units);
		stockInAttributes.add(weight);
		}
		return stockInAttributes;
		
	}
	
}