package org.balajicables.salesmanager.controller;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.balajicables.salesmanager.CustomUser;
import org.balajicables.salesmanager.dto.SalesOrderItemsDTO;
import org.balajicables.salesmanager.dto.WorkOrderItemsDTO;
import org.balajicables.salesmanager.model.Customer;
import org.balajicables.salesmanager.model.SalesOrderItem;
import org.balajicables.salesmanager.model.WorkOrderItems;

import org.balajicables.salesmanager.service.CustomerService;
import org.balajicables.salesmanager.service.OrderDetailsService;
import org.balajicables.salesmanager.service.WorkOrderItemService;

import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
/**
* This class demonstrates Stock In For WorkOrder Module
* @author Abin Sam
*/
@Controller
@RequestMapping("/stockinFromWo")
public class StockInWoController {

	@Resource
	private WorkOrderItemService workOrderItemService;
	
	@Resource
	private CustomerService customerService;

	@Resource
	private OrderDetailsService orderDetailsService;
	 /**
	   * This method returns stockInForWo.jsp.
	   * @param Model to set the attribute.
	   * @return stockInForWo.jsp.
	   */
	@RequestMapping(method = RequestMethod.GET)
	public String getStockIn(Model model, @RequestParam(value = "id") Long id) {
        /*Method to fetch list of customers*/
		List<Customer> customers = customerService.findAll();
		model.addAttribute("customers", customers);//set customers to model attribute
		/*Method to fetch work order item list*/
		List<WorkOrderItems> woItemList = workOrderItemService.findById(id);
		if (woItemList.size() > 0) {
		
			model.addAttribute("quantity", woItemList.get(0).getTotalQuantity());//set customers to model attribute
			model.addAttribute("itemCode", woItemList.get(0).getSalesOrderItem().getItem().getItemCode());//set customers to model attribute
			model.addAttribute("woNo", woItemList.get(0).getProductionWorkOrder().getWorkOrderNo());//set customers to model attribute
			model.addAttribute("orderId", woItemList.get(0).getSalesOrderItem().getOrder().getOrderId());//set customers to model attribute
			model.addAttribute("customerName", woItemList.get(0).getSalesOrderItem().getOrder().getCustomer().getCustomerName());//set customers to model attribute
			model.addAttribute("itemDescription", woItemList.get(0).getSalesOrderItem().getItem().getItemDescription());//set customers to model attribute
			model.addAttribute("noOfCoils", woItemList.get(0).getNoOfCoils());//set customers to model attribute
			model.addAttribute("qtyPerCoil", woItemList.get(0).getQtyPerCoil());//set customers to model attribute
			model.addAttribute("units", woItemList.get(0).getSalesOrderItem().getItem().getUnit().getUnits());//set customers to model attribute

		}//end of if(woItemList.size() > 0) condition 
		return "stockInForWo";
	}
	/**
	   * Method to change label of bundles
	   * @RequestParam itemCode,oldSoNo,newSoNo,oldWoNo
	   * @return changeLabelDetails
	   */
	@RequestMapping(value = "/changeLabel", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	List<String> changeLabel(
			 @RequestParam(value = "itemCode", required = true) String itemCode,
	       	 @RequestParam(value = "oldSoNo", required = true) String oldSoNo,
	    	 @RequestParam(value = "newSoNo", required = true) String newSoNo,
	    	 @RequestParam(value = "oldWoNo", required = true) String oldWoNo) {
		/*Fetch logged in username*/ 
		CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();;
	 	String userName = user.getFirstName()+" "+user.getLastName();
	 	/*Initialization of an empty list of type String*/
	    List<String> changeLabelDetails=new ArrayList<>();
	    String customerName=null;	
		Boolean updateOldSoDetailsList=false;
		Boolean updateNewSoDetailsList=false;
	    /*Method to fetch old salesorder items*/
		List<SalesOrderItem> oldSoItemList=orderDetailsService.findByOrdersOrderIdItemsItemCode(oldSoNo, itemCode);
		/*Method to fetch new salesorder items*/
		List<SalesOrderItem> newSoItemList=orderDetailsService.findByOrdersOrderIdItemsItemCode(newSoNo, itemCode);
		List<WorkOrderItems> woItemList=null;
		Long oldSalesOrderItemId=null;
		Long newSalesOrderItemId=null;
		if(oldSoItemList.size()>0){
			oldSalesOrderItemId=oldSoItemList.get(0).getOrderDetailId();
		}
		if(newSoItemList.size()>0){
			newSalesOrderItemId=newSoItemList.get(0).getOrderDetailId();
		}
		if(oldSalesOrderItemId!=null && oldWoNo!=null){
			woItemList=workOrderItemService.findBySoItemIdAndWorkOrderNo(oldSalesOrderItemId, oldWoNo);
			WorkOrderItemsDTO workOrderItemsDTO=new WorkOrderItemsDTO();
			workOrderItemsDTO.setWorkOrderItemId(woItemList.get(0).getWorkOrderItemId());
			workOrderItemsDTO.setWorkOrderNo(woItemList.get(0).getProductionWorkOrder().getWorkOrderNo());
			workOrderItemsDTO.setOrderDetailId(newSalesOrderItemId);
			workOrderItemsDTO.setNoOfCoils(woItemList.get(0).getNoOfCoils());
			workOrderItemsDTO.setQtyPerCoil(woItemList.get(0).getQtyPerCoil());
			workOrderItemsDTO.setTotalQuantity(woItemList.get(0).getTotalQuantity());
			workOrderItemsDTO.setPackingType(woItemList.get(0).getPackingType());
			workOrderItemsDTO.setPvcGrade(woItemList.get(0).getPvcGrade());
			workOrderItemsDTO.setMasterBatch(woItemList.get(0).getMasterBatch());
			workOrderItemsDTO.setToBeLabelled(woItemList.get(0).getToBeLabelled());
			workOrderItemsDTO.setStockInQty(woItemList.get(0).getStockInQty());
			workOrderItemsDTO.setStockInStatus(woItemList.get(0).getStockInStatus());
			workOrderItemsDTO.setUpdatedBy(userName);
			
			WorkOrderItems workOrderItems=workOrderItemsDTO.getWorkOrderItem();
			Boolean updateWoItems=workOrderItemService.update(workOrderItems);
			if(updateWoItems==true){
				if(oldSoItemList.size()>0){
					Double balanceQty=0.0;
					Double pdnQty = 0.0;
					pdnQty=oldSoItemList.get(0).getProductionQty()-woItemList.get(0).getTotalQuantity();		
					balanceQty=oldSoItemList.get(0).getQuantity()-(pdnQty+oldSoItemList.get(0).getCompletedQty()+oldSoItemList.get(0).getDispatchedQty());
					if(balanceQty<0.0)	
							balanceQty=0.0;
					SalesOrderItemsDTO salesOrderItemDTO=new SalesOrderItemsDTO();
					salesOrderItemDTO.setOrderDetailId(oldSoItemList.get(0).getOrderDetailId());
					salesOrderItemDTO.setOrderId(oldSoItemList.get(0).getOrder().getOrderId());
					salesOrderItemDTO.setItemId(oldSoItemList.get(0).getItem().getItemId());
					salesOrderItemDTO.setQuantity(oldSoItemList.get(0).getQuantity());
					salesOrderItemDTO.setBalanceQty(balanceQty);
					salesOrderItemDTO.setProductionQty(pdnQty);
					salesOrderItemDTO.setCompletedQty(oldSoItemList.get(0).getCompletedQty());
					salesOrderItemDTO.setDispatchedQty(oldSoItemList.get(0).getDispatchedQty());
					salesOrderItemDTO.setWoQty(oldSoItemList.get(0).getWoQty());
					salesOrderItemDTO.setWeight(oldSoItemList.get(0).getWeight());
					salesOrderItemDTO.setBundleSize(oldSoItemList.get(0).getBundleSize());
					salesOrderItemDTO.setRate(oldSoItemList.get(0).getRate());
					salesOrderItemDTO.setItemCode(oldSoItemList.get(0).getItemCode());
					salesOrderItemDTO.setUpdatedBy(oldSoItemList.get(0).getUpdatedBy());
					salesOrderItemDTO.setUpdatedTime(oldSoItemList.get(0).getUpdatedTime().toString());
					salesOrderItemDTO.setPvcWeight(oldSoItemList.get(0).getPvcWeight());
					
					SalesOrderItem soItem=salesOrderItemDTO.getOrderDetail();
					updateOldSoDetailsList=orderDetailsService.update(soItem);
				}
				if(newSoItemList.size()>0){
					Double newSoBalanceQty=0.0;
					Double newSoPdnQty = 0.0;
					newSoPdnQty=newSoItemList.get(0).getProductionQty()+woItemList.get(0).getTotalQuantity();		
					newSoBalanceQty=newSoItemList.get(0).getQuantity()-(newSoPdnQty+newSoItemList.get(0).getCompletedQty()+newSoItemList.get(0).getDispatchedQty());
					if(newSoBalanceQty<0.0)
						newSoBalanceQty=0.0;
					customerName=newSoItemList.get(0).getOrder().getCustomer().getCustomerName();
					SalesOrderItemsDTO salesOrderItemDTO=new SalesOrderItemsDTO();
					salesOrderItemDTO.setOrderDetailId(newSoItemList.get(0).getOrderDetailId());
					salesOrderItemDTO.setOrderId(newSoItemList.get(0).getOrder().getOrderId());
					salesOrderItemDTO.setItemId(newSoItemList.get(0).getItem().getItemId());
					salesOrderItemDTO.setQuantity(newSoItemList.get(0).getQuantity());
					salesOrderItemDTO.setBalanceQty(newSoBalanceQty);
					salesOrderItemDTO.setProductionQty(newSoPdnQty);
					salesOrderItemDTO.setCompletedQty(newSoItemList.get(0).getCompletedQty());
					salesOrderItemDTO.setDispatchedQty(newSoItemList.get(0).getDispatchedQty());
					salesOrderItemDTO.setWoQty(newSoItemList.get(0).getWoQty());
					salesOrderItemDTO.setWeight(newSoItemList.get(0).getWeight());
					salesOrderItemDTO.setBundleSize(newSoItemList.get(0).getBundleSize());
					salesOrderItemDTO.setRate(newSoItemList.get(0).getRate());
					salesOrderItemDTO.setItemCode(newSoItemList.get(0).getItemCode());
					salesOrderItemDTO.setUpdatedBy(newSoItemList.get(0).getUpdatedBy());
					salesOrderItemDTO.setUpdatedTime(newSoItemList.get(0).getUpdatedTime().toString());
					salesOrderItemDTO.setPvcWeight(newSoItemList.get(0).getPvcWeight());
					
					SalesOrderItem soItems=salesOrderItemDTO.getOrderDetail();
					updateNewSoDetailsList=orderDetailsService.update(soItems);
				}//end of if(newSoItemList.size()>0) condition
			}//end of if(updateWoItems==true) condition
		}//end of if(oldSalesOrderItemId!=null && oldWoNo!=null) condition
	    if(updateNewSoDetailsList==true && updateOldSoDetailsList==true){
	    	
		                                        changeLabelDetails.add(newSoNo);
		                                        changeLabelDetails.add(customerName);
	   }
	    return changeLabelDetails;
	}
	/**
	   * Method to fetch salesorder
	   * @RequestParam itemCode,customerId
	   * @return soNoList
	   */
	@RequestMapping(value = "/fetchSalesOrder", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	List<String> fetchSalesOrder(
			 @RequestParam(value = "itemCode", required = true) String itemCode,
	       	 @RequestParam(value = "customerId", required = true) Long customerId) {
	     /*Initialization of empty ArrayList of type String*/
		 ArrayList<String> soNoList = new ArrayList<>();
		 /*Method to salesorder item list based on itemCode,customerId*/
		 List<SalesOrderItem> soItemList=orderDetailsService.findByItemCodeAndCustomerId(itemCode,customerId);
		
			for (int iterator = 0; iterator < soItemList.size(); iterator++) {
				String soNo = soItemList.get(iterator).getOrder().getOrderId();
                Double stockInQuantity=soItemList.get(iterator).getCompletedQty();
                Double orderedQty=soItemList.get(iterator).getQuantity();
                String orderStatus=soItemList.get(iterator).getOrder().getOrderStatus().getStatus();
                if(orderStatus.equalsIgnoreCase("Approved") || orderStatus.equalsIgnoreCase("Approved For Prodn")){
                	if(!(stockInQuantity>= (96*orderedQty)/100)){
                	if (!soNoList.contains(soNo)) {
    					soNoList.add(soNo);
    				}
                }
                }
			}
		 return soNoList;
	}
	
}
