package org.balajicables.salesmanager.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import javax.annotation.Resource;

import org.apache.commons.lang.WordUtils;
import org.balajicables.salesmanager.CustomUser;
import org.balajicables.salesmanager.common.JqgridFilter;
import org.balajicables.salesmanager.common.JqgridObjectMapper;
import org.balajicables.salesmanager.common.JqgridResponse;
import org.balajicables.salesmanager.common.StatusResponse;
import org.balajicables.salesmanager.common.StockOutMapper;
import org.balajicables.salesmanager.dto.DeliveryChallanDTO;
import org.balajicables.salesmanager.dto.DeliveryChallanItemsDTO;
import org.balajicables.salesmanager.dto.OrderDTO;
import org.balajicables.salesmanager.dto.PackingSlipDTO;
import org.balajicables.salesmanager.dto.SalesOrderItemsDTO;
import org.balajicables.salesmanager.dto.StockOutDTO;
import org.balajicables.salesmanager.dto.StoreRegisterDTO;
import org.balajicables.salesmanager.model.DeliveryChallan;
import org.balajicables.salesmanager.model.DeliveryChallanItems;
import org.balajicables.salesmanager.model.OrderStatus;
import org.balajicables.salesmanager.model.PackingSlip;
import org.balajicables.salesmanager.model.SalesOrder;
import org.balajicables.salesmanager.model.SalesOrderItem;
import org.balajicables.salesmanager.model.StockOut;
import org.balajicables.salesmanager.model.StoreRegister;
import org.balajicables.salesmanager.service.DeliveryChallanItemsService;
import org.balajicables.salesmanager.service.DeliveryChallanService;
import org.balajicables.salesmanager.service.OrderDetailsService;
import org.balajicables.salesmanager.service.OrderService;
import org.balajicables.salesmanager.service.OrderStatusService;
import org.balajicables.salesmanager.service.PackingSlipService;
import org.balajicables.salesmanager.service.StockOutService;
import org.balajicables.salesmanager.service.StoreRegisterService;
import org.balajicables.salesmanager.utils.Utility;
import org.joda.time.DateTime;
import org.springframework.data.domain.Page;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
/**
* This class demonstrates Stock Out Module
* @author Abin Sam
*/
@Controller
@RequestMapping("/stockout")

public class StockOutController {

	@Resource
	private StockOutService stockOutService;
	@Resource
	private OrderStatusService orderStatusService;

	@Resource
	private OrderService orderService;
	
	@Resource
	private PackingSlipService packingSlipService;

	@Resource
	private OrderDetailsService orderDetailsService;
	@Resource
	private StoreRegisterService storeRegisterService;
	

	@Resource
	private DeliveryChallanService deliveryChallanService;
	
	@Resource
	private DeliveryChallanItemsService deliveryChallanItemsService;

	 /**
	   * This method returns stockOut.jsp.
	   * @return stockOut.jsp.
	   */
	@SuppressWarnings("deprecation")
	@RequestMapping(method = RequestMethod.GET)
	public String getStockIn(Model model) 
	{
		Date date= new java.util.Date();
		String month1= String.valueOf(date.getMonth()+1);
		String day = String.valueOf(date.getDate());
		String year1= String.valueOf(date.getYear()+1900);

		String sysDate = day + '-' + month1 + '-' + year1;
		
		model.addAttribute("date", sysDate);
		return "stockOut"; 
	}
   /**
	   * select item for stock out
	   * @param storeregsiter id,bag no,bag weight
	   * @return StatusResponse
	   */
	@RequestMapping(value = "/storeStockOut", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	StatusResponse storeStockOut(
			@RequestParam(value = "idsOfSelectedRows[]", required = false) Long[] idsSelected,
			@RequestParam(value = "bagNo", required = false) Long bagNo,
			@RequestParam(value = "bagWeight", required = false) Double bagWeight,
			Model model)
			{
		/*fetch logged in username*/
		CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();;
	 	String supervisor = user.getFirstName()+" "+user.getLastName();
	 	/*Initialization of empty list of type StoreRegister*/
	  	List<StoreRegister>storeRegList=new ArrayList<>();
		StockOut createdStockOut=null;
		Boolean updateStockOut=false;
	    Boolean finalResult=false;
	    Boolean updateStoreReg=false;
	
		if(idsSelected!=null){
			for(int k=0;k<idsSelected.length;k++){
				if(idsSelected[k]!=null){
					storeRegList=storeRegisterService.findById(idsSelected[k]);//fetch store register records based on id
				}//end of  if loop
				if(storeRegList.size()>0 && storeRegList!=null){
					String soNo=storeRegList.get(0).getSalesOrderItem().getOrder().getOrderId();
					String confirmStatus="No";
					Long orderDetailsId=storeRegList.get(0).getSalesOrderItem().getOrderDetailId();
					String workOrderNo=storeRegList.get(0).getProductionWorkOrder().getWorkOrderNo();
					String bundleId=storeRegList.get(0).getBundleId();
					String itemCodes=storeRegList.get(0).getSalesOrderItem().getItem().getItemCode();
				    //fetch store reg list for work order no ,sales order item id and bundle id
					List<StoreRegister>storeList=storeRegisterService.findByOrderDetailIdAndBundleIdAndWorkOrderNo(orderDetailsId, bundleId, workOrderNo);
					if(storeList.size()>0){
					//if exist in store then we can stock out	
			        	 //fetch stock out by sales order,item code,work order, bundle id
			        	 List<StockOut>stockOutlist=stockOutService.findByOrderIdAndItemCodeAndBundleIdAndWorkOrderNoAndConfirmStatus(soNo, itemCodes, bundleId, workOrderNo,confirmStatus);
			        	 if(!(stockOutlist.size()>0)){
			        			StockOutDTO stockOutDTO=new StockOutDTO();
								stockOutDTO.setStoreId(storeRegList.get(0).getStore().getStoreId());
								stockOutDTO.setOrderDetailId(storeRegList.get(0).getSalesOrderItem().getOrderDetailId());
								stockOutDTO.setOrderId(storeRegList.get(0).getSalesOrderItem().getOrder().getOrderId());
								stockOutDTO.setItemId(storeRegList.get(0).getSalesOrderItem().getItem().getItemId());
								stockOutDTO.setItemCode(storeRegList.get(0).getSalesOrderItem().getItem().getItemCode());
								stockOutDTO.setSoItemQty(storeRegList.get(0).getSalesOrderItem().getQuantity());
								stockOutDTO.setWorkOrderNo(storeRegList.get(0).getProductionWorkOrder().getWorkOrderNo());
								stockOutDTO.setStockOutQty(storeRegList.get(0).getStockQty());
								stockOutDTO.setQcStatus(storeRegList.get(0).getQcStatus());
								stockOutDTO.setQcSupervisor(storeRegList.get(0).getQcSupervisor());
								stockOutDTO.setCustomerName(storeRegList.get(0).getSalesOrderItem().getOrder().getCustomer().getCustomerName());
								stockOutDTO.setBundleId(storeRegList.get(0).getBundleId());
								stockOutDTO.setPackingSlipNo(bagNo);
								stockOutDTO.setRemarks(storeRegList.get(0).getRemarks());
								stockOutDTO.setSupervisor(supervisor);
								stockOutDTO.setWeight(storeRegList.get(0).getWeight());
								stockOutDTO.setConfirmStatus("No");
								stockOutDTO.setDeliveryChallanNo(null);
								if(bagWeight!=null)
								stockOutDTO.setBagWeight(bagWeight);
								StockOut stockOut=stockOutDTO.getStockOut();
								createdStockOut=stockOutService.create(stockOut);//create stock out with bag weight and bag no
								if(createdStockOut!=null)
									finalResult=true;//statusMssg.add("Created");
								 StoreRegisterDTO storeRegDTO=new StoreRegisterDTO();
								 storeRegDTO.setStoreRegisterId(storeRegList.get(0).getStoreRegisterId());
								 storeRegDTO.setItemCode(storeRegList.get(0).getItemCode());
								 storeRegDTO.setStoreId(storeRegList.get(0).getStore().getStoreId());
								 storeRegDTO.setWorkOrderNo(storeRegList.get(0).getProductionWorkOrder().getWorkOrderNo());
								 storeRegDTO.setCustomerName(storeRegList.get(0).getCustomerName());
								 storeRegDTO.setStockQty(storeRegList.get(0).getStockQty());
								 storeRegDTO.setBundleId(storeRegList.get(0).getBundleId());
								 storeRegDTO.setOrderId(storeRegList.get(0).getOrderId());
								 storeRegDTO.setOrderDetailId(storeRegList.get(0).getSalesOrderItem().getOrderDetailId());
								 storeRegDTO.setItemId(storeRegList.get(0).getItemId());
								 storeRegDTO.setPackingSlipNo(bagNo);
								 storeRegDTO.setSupervisor(storeRegList.get(0).getSupervisor());
								 storeRegDTO.setWeight(storeRegList.get(0).getWeight());
								 storeRegDTO.setQcStatus(storeRegList.get(0).getQcStatus());
								 storeRegDTO.setQcSupervisor(storeRegList.get(0).getQcSupervisor());
								 storeRegDTO.setRejectStatus(storeRegList.get(0).getRejectStatus());
								 storeRegDTO.setBagWeight(bagWeight);
								 StoreRegister storeRegister=storeRegDTO.getStoreRegister();
								 updateStoreReg=storeRegisterService.update(storeRegister);//update store register
					     	     if(updateStoreReg==true){
					     	     finalResult=true; 
					     	
			        	 }//end of if loop
					}//end of id loop
				 	      if(finalResult=true && bagWeight!=null){
				 	    	  //fetch stock out based on sales order,bag no and confirm status
				 	    		List<StockOut> stockOutBagList=stockOutService.findByOrderIdoPackingSlipNoConfirmStatus(soNo,bagNo,confirmStatus);
				 	    		//fetch StoreRegister based on sales order,bag no 
				 	    		List<StoreRegister> storeRegBagList=storeRegisterService.findByOrderIdoPackingSlipNo(soNo,bagNo);
								if(stockOutBagList.size()>0){
							    	for(int l=0;l<stockOutBagList.size();l++){
							    		if(stockOutBagList.get(l).getBagWeight()!=bagWeight){
							    		StockOutDTO stockOutBagWtDTO=new StockOutDTO();
							    		stockOutBagWtDTO.setStockOutId(stockOutBagList.get(l).getStockOutId());
							    		stockOutBagWtDTO.setStoreId(stockOutBagList.get(l).getStore().getStoreId());
							    		stockOutBagWtDTO.setOrderDetailId(stockOutBagList.get(l).getSalesOrderItem().getOrderDetailId());
							    		stockOutBagWtDTO.setOrderId(stockOutBagList.get(l).getSalesOrderItem().getOrder().getOrderId());
							    		stockOutBagWtDTO.setItemId(stockOutBagList.get(l).getSalesOrderItem().getItem().getItemId());
							    		stockOutBagWtDTO.setItemCode(stockOutBagList.get(l).getSalesOrderItem().getItem().getItemCode());
							    		stockOutBagWtDTO.setSoItemQty(stockOutBagList.get(l).getSalesOrderItem().getQuantity());
							    		stockOutBagWtDTO.setWorkOrderNo(stockOutBagList.get(l).getProductionWorkOrder().getWorkOrderNo());
							    		stockOutBagWtDTO.setStockOutQty(stockOutBagList.get(l).getStockOutQty());
							    		stockOutBagWtDTO.setQcStatus(stockOutBagList.get(l).getQcStatus());
							    		stockOutBagWtDTO.setQcSupervisor(stockOutBagList.get(l).getQcSupervisor());
							    		stockOutBagWtDTO.setCustomerName(stockOutBagList.get(l).getCustomerName());
							    		stockOutBagWtDTO.setBundleId(stockOutBagList.get(l).getBundleId());
							    		stockOutBagWtDTO.setPackingSlipNo(stockOutBagList.get(l).getPackingSlipNo());
							    		stockOutBagWtDTO.setSupervisor(stockOutBagList.get(l).getSupervisor());
							    		stockOutBagWtDTO.setWeight(stockOutBagList.get(l).getWeight());
							    		stockOutBagWtDTO.setConfirmStatus(stockOutBagList.get(l).getConfirmStatus());
							    		stockOutBagWtDTO.setRemarks(stockOutBagList.get(l).getRemarks());
							    		stockOutBagWtDTO.setBagWeight(bagWeight);
							    		stockOutBagWtDTO.setDeliveryChallanNo(stockOutBagList.get(l).getDeliveryChallanNo());
							    		StockOut stockOutDetails=stockOutBagWtDTO.getStockOut();
							    		updateStockOut=stockOutService.update(stockOutDetails);	//update stock out with bag weight and bag no
							    		}
							    	}//end of for loop
							    }// stock out if loop  
							    if(storeRegBagList.size()>0){
							    	for(int l=0;l<storeRegBagList.size();l++){
							    		if(storeRegBagList.get(l).getBagWeight()!=bagWeight){
							    	    StoreRegisterDTO storeRegBagWtDTO=new StoreRegisterDTO();
							    	    storeRegBagWtDTO.setStoreRegisterId(storeRegBagList.get(l).getStoreRegisterId());
							    	    storeRegBagWtDTO.setItemCode(storeRegBagList.get(l).getSalesOrderItem().getItem().getItemCode());
							    	    storeRegBagWtDTO.setStoreId(storeRegBagList.get(l).getStore().getStoreId());
							    	    storeRegBagWtDTO.setWorkOrderNo(storeRegBagList.get(l).getProductionWorkOrder().getWorkOrderNo());
							    		storeRegBagWtDTO.setCustomerName(storeRegBagList.get(l).getCustomerName());
							    	    storeRegBagWtDTO.setStockQty(storeRegBagList.get(l).getStockQty());
							    		storeRegBagWtDTO.setBundleId(storeRegBagList.get(l).getBundleId());
							    	    storeRegBagWtDTO.setOrderId(storeRegBagList.get(l).getSalesOrderItem().getOrder().getOrderId());
							    	    storeRegBagWtDTO.setOrderDetailId(storeRegBagList.get(l).getSalesOrderItem().getOrderDetailId());
							    	    storeRegBagWtDTO.setItemId(storeRegBagList.get(l).getSalesOrderItem().getItem().getItemId());
							    		storeRegBagWtDTO.setPackingSlipNo(storeRegBagList.get(l).getPackingSlipNo());
							    		storeRegBagWtDTO.setSupervisor(storeRegBagList.get(l).getSupervisor());
							    		storeRegBagWtDTO.setWeight(storeRegBagList.get(l).getWeight());
							    		storeRegBagWtDTO.setQcStatus(storeRegBagList.get(l).getQcStatus());
							    		storeRegBagWtDTO.setQcSupervisor(storeRegBagList.get(l).getQcSupervisor());
							    		storeRegBagWtDTO.setRejectStatus(storeRegBagList.get(l).getRejectStatus());
				                     	storeRegBagWtDTO.setBagWeight(bagWeight);
							    		StoreRegister storeRegDetails=storeRegBagWtDTO.getStoreRegister();
							    		updateStoreReg=storeRegisterService.update(storeRegDetails);//update store regsiter with bag no and bag weight 		    		
							    	}//end of if(storeRegBagList.get(l).getBagWeight()!=bagWeight) loop
							      }//end of for loop
							    }// store reg if loop
				 	       }//end of if(finalResult=true && bagWeight!=null) loop
				 	      if(updateStockOut==true && updateStoreReg==true)
				  	       finalResult=true;
					
						//Commented for restock out process
					//fetch stock out list based on sales order item id,work order no and bundle id
				//	List<StockOut> stockOutList=stockOutService.findByOrderDetailIdWorkOrderNoBundleId(orderDetailsId,workOrderNo,bundleId);
/*					if(stockOutList.size()>0 ){
						StockOutDTO stockOutDTO=new StockOutDTO();
						stockOutDTO.setStockOutId(stockOutList.get(0).getStockOutId());
						stockOutDTO.setStoreId(stockOutList.get(0).getStore().getStoreId());
						stockOutDTO.setOrderDetailId(stockOutList.get(0).getSalesOrderItem().getOrderDetailId());
						stockOutDTO.setOrderId(stockOutList.get(0).getSalesOrderItem().getOrder().getOrderId());
						stockOutDTO.setItemId(stockOutList.get(0).getSalesOrderItem().getItem().getItemId());
						stockOutDTO.setItemCode(stockOutList.get(0).getSalesOrderItem().getItem().getItemCode());
						stockOutDTO.setSoItemQty(stockOutList.get(0).getSalesOrderItem().getQuantity());
						stockOutDTO.setWorkOrderNo(stockOutList.get(0).getProductionWorkOrder().getWorkOrderNo());
						stockOutDTO.setStockOutQty(stockOutList.get(0).getStockOutQty());
						stockOutDTO.setQcStatus(stockOutList.get(0).getQcStatus());
						stockOutDTO.setQcSupervisor(stockOutList.get(0).getQcSupervisor());
						stockOutDTO.setCustomerName(stockOutList.get(0).getSalesOrderItem().getOrder().getCustomer().getCustomerName());
						stockOutDTO.setBundleId(stockOutList.get(0).getBundleId());
						stockOutDTO.setPackingSlipNo(bagNo);
						stockOutDTO.setRemarks(stockOutList.get(0).getRemarks());
						stockOutDTO.setSupervisor(stockOutList.get(0).getSupervisor());
						stockOutDTO.setWeight(stockOutList.get(0).getWeight());
						stockOutDTO.setConfirmStatus(stockOutList.get(0).getConfirmStatus());
						stockOutDTO.setDeliveryChallanNo(stockOutList.get(0).getDeliveryChallanNo());
						if(bagWeight!=null)
						stockOutDTO.setBagWeight(bagWeight);
						StockOut updatetockOut=stockOutDTO.getStockOut();
						updateStockOut=stockOutService.update(updatetockOut);//update stock out with bag weight and bag no
						if(updateStockOut==true)
							finalResult=true;
						//statusMssg.add("Exist");
					
			
					}//end of if(stockOutList.size()>0 )loop
					else{
						StockOutDTO stockOutDTO=new StockOutDTO();
						stockOutDTO.setStoreId(storeRegList.get(0).getStore().getStoreId());
						stockOutDTO.setOrderDetailId(storeRegList.get(0).getSalesOrderItem().getOrderDetailId());
						stockOutDTO.setOrderId(storeRegList.get(0).getSalesOrderItem().getOrder().getOrderId());
						stockOutDTO.setItemId(storeRegList.get(0).getSalesOrderItem().getItem().getItemId());
						stockOutDTO.setItemCode(storeRegList.get(0).getSalesOrderItem().getItem().getItemCode());
						stockOutDTO.setSoItemQty(storeRegList.get(0).getSalesOrderItem().getQuantity());
						stockOutDTO.setWorkOrderNo(storeRegList.get(0).getProductionWorkOrder().getWorkOrderNo());
						stockOutDTO.setStockOutQty(storeRegList.get(0).getStockQty());
						stockOutDTO.setQcStatus(storeRegList.get(0).getQcStatus());
						stockOutDTO.setQcSupervisor(storeRegList.get(0).getQcSupervisor());
						stockOutDTO.setCustomerName(storeRegList.get(0).getSalesOrderItem().getOrder().getCustomer().getCustomerName());
						stockOutDTO.setBundleId(storeRegList.get(0).getBundleId());
						stockOutDTO.setPackingSlipNo(bagNo);
						stockOutDTO.setRemarks(storeRegList.get(0).getRemarks());
						stockOutDTO.setSupervisor(supervisor);
						stockOutDTO.setWeight(storeRegList.get(0).getWeight());
						stockOutDTO.setConfirmStatus("No");
						stockOutDTO.setDeliveryChallanNo(null);
						if(bagWeight!=null)
						stockOutDTO.setBagWeight(bagWeight);
						StockOut stockOut=stockOutDTO.getStockOut();
						createdStockOut=stockOutService.create(stockOut);//create stock out with bag weight and bag no
						if(createdStockOut!=null)
							finalResult=true;//statusMssg.add("Created");
						
				      }//end of else loop
*/					//Commented for restock out process
							   

					} 
			    }//end of if(storeRegList.size()>0 && storeRegList!=null) loop
			}//end of for loop
		}//end of if(idsSelected!=null) loop
		
		return new StatusResponse(finalResult);
		    }
		
	 /**
	   * Fetch stock out details based on sales order,item,work order and bundle id
	   * @param sales order,item code,work order and bundle id
	   * @return List<String>
	   */
	
	@RequestMapping(value = "/populateStockOutDetails", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	List<String> fetchItemDetails(
			@RequestParam  String salesOrderId,
			@RequestParam  String itemCode,
			@RequestParam  String workOrderNo,
			@RequestParam  String bundleId
				)
			{
		String itemDescription="";
		String customerName="";
		String quantity="";
		String weight="";
		//fetch store register by  sales order,item code,work order and bundle id
		List<StoreRegister> storeRegList=storeRegisterService.findByOrderIdAndItemCodeAndBundleIdAndWorkOrderNo(salesOrderId,itemCode,bundleId,workOrderNo);
		if(storeRegList.size()>0){
			if(storeRegList.get(0).getSalesOrderItem().getItem().getItemDescription()!=null)
			itemDescription=storeRegList.get(0).getSalesOrderItem().getItem().getItemDescription();
			if(storeRegList.get(0).getSalesOrderItem().getOrder().getCustomer().getCustomerName()!=null)
			customerName=storeRegList.get(0).getSalesOrderItem().getOrder().getCustomer().getCustomerName();
			if(storeRegList.get(0).getStockQty()!=null)
			quantity=storeRegList.get(0).getStockQty().toString();
			if(storeRegList.get(0).getWeight()!=null)
			weight=storeRegList.get(0).getWeight().toString();
		}//end of if(storeRegList.size()>0) loop
		List<String> storeList=new ArrayList<>();
				storeList.add(itemDescription);//add itemDescription  to list 
			    storeList.add(customerName);//add customerName to list 
                storeList.add(quantity);//add quantity to list 
               storeList.add(weight);//add weight to list 
	  	return storeList;
		}
	 /**
	   * Select item  for stock out
	   * @param sales order,item code,work order, bundle id,customer,item description,quantity,weight,bag no and bag weight
	   * @return List<String>
	   */
	@RequestMapping(value = "/saveStockOut", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	List<String> saveStockItems(
			@RequestParam  String ItemCode,
			@RequestParam  String SalesOrderId,
			@RequestParam  String WorkOrderNo,
			@RequestParam  String BundleId,
			@RequestParam  String CustomerName,
			@RequestParam  String ItemDesc,
			@RequestParam  Double Quantity,
			@RequestParam  Double Weight,
			@RequestParam  Long bagNo,
			@RequestParam(value = "bagWeight", required = false) Double bagWeight
			
			)
			{
		 List<String> statusMssgList=new ArrayList<>();
		 //fetch store register record based on  sales order,item code,work order, bundle id
	     List<StoreRegister>storeRegistersList=storeRegisterService.findByOrderIdAndItemCodeAndBundleIdAndWorkOrderNo(SalesOrderId, ItemCode, BundleId, WorkOrderNo);
         if(storeRegistersList.size()>0){
        	 String confirmStatus="No";
        	 //fetch stock out by sales order,item code,work order, bundle id
        	 List<StockOut>stockOutlist=stockOutService.findByOrderIdAndItemCodeAndBundleIdAndWorkOrderNoAndConfirmStatus(SalesOrderId, ItemCode, BundleId, WorkOrderNo,confirmStatus);
        	 if(stockOutlist.size()>0){
        		 statusMssgList.add("added");//add status message to list
        	 }//end of if loop
        	 else{
        		 //method to update stcok out by sales order,item code,work order, bundle id,bag weight and bag no
 				statusMssgList=updateStockOutProcess(SalesOrderId,ItemCode,WorkOrderNo,BundleId,Quantity,Weight,storeRegistersList,bagWeight,bagNo);

        	 }//end of else loop
         }//end of  if(storeRegistersList.size()>0)loop
         else{
        	 statusMssgList.add("Dont exist");//add status message to list
         }//end of else loop
		 
		 
		 return statusMssgList;
		 
		 
		 
		   }
			
	 /**
	   * Update stock out
	   * @param sales order,item code,work order, bundle id,List<StoreRegister>,weight,bag no and bag weight
	   * @return List<String>
	   */
	private List<String> updateStockOutProcess(String salesOrderId,
			String itemCode, String workOrderNo, String bundleId,
			Double quantity, Double weight,List<StoreRegister>storeRegisterList, Double bagWeight,Long bagNo) {
		 
        Boolean updateStockOut=false;
        /*Fetch logged in user*/
		CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();;
	    String supervisor = user.getFirstName()+" "+user.getLastName();
		/*Initialization of empty List of type String*/
	    List<String> statusMssgList=new ArrayList<>();
		
	    String qcStatus="";
		String soStatus="";
		
		  	if(storeRegisterList.size()>0){
		  		qcStatus=storeRegisterList.get(0).getQcStatus();
		  		soStatus=storeRegisterList.get(0).getSalesOrderItem().getOrder().getOrderStatus().getStatus();
		  		if(qcStatus.equalsIgnoreCase("Approved") && soStatus.equalsIgnoreCase("Approved")){
		 		StockOutDTO stockOutDTO=new StockOutDTO();
				stockOutDTO.setStoreId(1);
				stockOutDTO.setOrderDetailId(storeRegisterList.get(0).getSalesOrderItem().getOrderDetailId());
				stockOutDTO.setOrderId(storeRegisterList.get(0).getSalesOrderItem().getOrder().getOrderId());
				stockOutDTO.setItemCode(storeRegisterList.get(0).getSalesOrderItem().getItem().getItemCode());
				stockOutDTO.setItemId(storeRegisterList.get(0).getSalesOrderItem().getItem().getItemId());
				stockOutDTO.setSoItemQty(storeRegisterList.get(0).getSalesOrderItem().getQuantity());
				stockOutDTO.setWorkOrderNo(storeRegisterList.get(0).getProductionWorkOrder().getWorkOrderNo());
				stockOutDTO.setStockOutQty(storeRegisterList.get(0).getStockQty());
				stockOutDTO.setQcStatus(storeRegisterList.get(0).getQcStatus());
				stockOutDTO.setQcSupervisor(storeRegisterList.get(0).getQcSupervisor());
				stockOutDTO.setBundleId(storeRegisterList.get(0).getBundleId());
				stockOutDTO.setCustomerName(storeRegisterList.get(0).getSalesOrderItem().getOrder().getCustomer().getCustomerName());
			    stockOutDTO.setSupervisor(supervisor);
			    stockOutDTO.setWeight(weight);
			    stockOutDTO.setRemarks(storeRegisterList.get(0).getRemarks());
			    stockOutDTO.setConfirmStatus("No");	
			    stockOutDTO.setDeliveryChallanNo(null);
			    stockOutDTO.setPackingSlipNo(bagNo);
			    if(bagWeight!=null)
			    stockOutDTO.setBagWeight(bagWeight);
			   	StockOut stockOutItem=stockOutDTO.getStockOut();
		       	StockOut createdStore = stockOutService.create(stockOutItem);//create stock out item
				if(createdStore!=null)
					statusMssgList.add("created");
				    updateStockOut=true;
				    
				    StoreRegisterDTO storeRegDTO=new StoreRegisterDTO();
				    storeRegDTO.setStoreRegisterId(storeRegisterList.get(0).getStoreRegisterId());
				    storeRegDTO.setItemCode(storeRegisterList.get(0).getSalesOrderItem().getItem().getItemCode());
				    storeRegDTO.setStoreId(storeRegisterList.get(0).getStore().getStoreId());
				    storeRegDTO.setWorkOrderNo(storeRegisterList.get(0).getProductionWorkOrder().getWorkOrderNo());
				    storeRegDTO.setCustomerName(storeRegisterList.get(0).getCustomerName());
				    storeRegDTO.setStockQty(storeRegisterList.get(0).getStockQty());
				    storeRegDTO.setBundleId(storeRegisterList.get(0).getBundleId());
				    storeRegDTO.setOrderId(storeRegisterList.get(0).getSalesOrderItem().getOrder().getOrderId());
				    storeRegDTO.setOrderDetailId(storeRegisterList.get(0).getSalesOrderItem().getOrderDetailId());
				    storeRegDTO.setItemId(storeRegisterList.get(0).getSalesOrderItem().getItem().getItemId());
				    storeRegDTO.setPackingSlipNo(bagNo);
				    storeRegDTO.setSupervisor(storeRegisterList.get(0).getSupervisor());
				    storeRegDTO.setWeight(storeRegisterList.get(0).getWeight());
				    storeRegDTO.setQcStatus(storeRegisterList.get(0).getQcStatus());
				    storeRegDTO.setQcSupervisor(storeRegisterList.get(0).getQcSupervisor());
				    storeRegDTO.setRejectStatus(storeRegisterList.get(0).getRejectStatus());
				    storeRegDTO.setBagWeight(bagWeight);
		    		StoreRegister storeRegs=storeRegDTO.getStoreRegister();
		    		storeRegisterService.update(storeRegs);//update store register	
		  	}else if(!(soStatus.equalsIgnoreCase("Approved"))){
		  		statusMssgList.add("SO Status Not Approved");//add statusMssg to list  
		  	}else if(!(qcStatus.equalsIgnoreCase("Approved"))){
		  		statusMssgList.add("QC Status Not Approved");//add statusMssg to list
	
		  	}
   
        }//end of if(storeRegisterList.size()>0) loop

		 	if(updateStockOut==true && bagWeight!=null){
		 		String confirmStatus="No";
		 		//fetch StockOut based on order id,packing slip and confirm status
		 		List<StockOut>stockOutBagList=stockOutService.findByOrderIdoPackingSlipNoConfirmStatus(salesOrderId, bagNo, confirmStatus);
		 		//fetch Store Register based on order id,packing slip 
		 		List<StoreRegister>storeRegBagList=storeRegisterService.findByOrderIdoPackingSlipNo(salesOrderId, bagNo);
		 		if(stockOutBagList.size()>0){
		 			for(int l=0;l<stockOutBagList.size();l++){
		 				StockOutDTO stockOutBagWtDTO=new StockOutDTO();
			    		stockOutBagWtDTO.setStockOutId(stockOutBagList.get(l).getStockOutId());
			    		stockOutBagWtDTO.setStoreId(stockOutBagList.get(l).getStore().getStoreId());
			    		stockOutBagWtDTO.setOrderDetailId(stockOutBagList.get(l).getSalesOrderItem().getOrderDetailId());
			    		stockOutBagWtDTO.setOrderId(stockOutBagList.get(l).getSalesOrderItem().getOrder().getOrderId());
			    		stockOutBagWtDTO.setItemId(stockOutBagList.get(l).getSalesOrderItem().getItem().getItemId());
			    		stockOutBagWtDTO.setItemCode(stockOutBagList.get(l).getSalesOrderItem().getItem().getItemCode());
			    		stockOutBagWtDTO.setSoItemQty(stockOutBagList.get(l).getSalesOrderItem().getQuantity());
			    		stockOutBagWtDTO.setWorkOrderNo(stockOutBagList.get(l).getProductionWorkOrder().getWorkOrderNo());
			    		stockOutBagWtDTO.setStockOutQty(stockOutBagList.get(l).getStockOutQty());
			    		stockOutBagWtDTO.setQcStatus(stockOutBagList.get(l).getQcStatus());
			    		stockOutBagWtDTO.setQcSupervisor(stockOutBagList.get(l).getQcSupervisor());
			    		stockOutBagWtDTO.setCustomerName(stockOutBagList.get(l).getCustomerName());
			    		stockOutBagWtDTO.setBundleId(stockOutBagList.get(l).getBundleId());
			    		stockOutBagWtDTO.setPackingSlipNo(stockOutBagList.get(l).getPackingSlipNo());
			    		stockOutBagWtDTO.setSupervisor(stockOutBagList.get(l).getSupervisor());
			    		stockOutBagWtDTO.setWeight(stockOutBagList.get(l).getWeight());
			    		stockOutBagWtDTO.setRemarks(stockOutBagList.get(l).getRemarks());
			    		stockOutBagWtDTO.setConfirmStatus(stockOutBagList.get(l).getConfirmStatus());
			    		stockOutBagWtDTO.setBagWeight(bagWeight);
			    		stockOutBagWtDTO.setDeliveryChallanNo(stockOutBagList.get(l).getDeliveryChallanNo());
			    		StockOut stockOutDetails=stockOutBagWtDTO.getStockOut();
			    		stockOutService.update(stockOutDetails);	//update stock out	    		
			    
		 			}//end of for loop
		 		} // end of if(stockOutBagList.size()>0)loop
		 		if(storeRegBagList.size()>0){
		 			for(int m=0;m>storeRegBagList.size();m++){
		 			   StoreRegisterDTO storeRegBagWtDTO=new StoreRegisterDTO();
			    	    storeRegBagWtDTO.setStoreRegisterId(storeRegBagList.get(m).getStoreRegisterId());
			    	    storeRegBagWtDTO.setItemCode(storeRegBagList.get(m).getSalesOrderItem().getItem().getItemCode());
			    	    storeRegBagWtDTO.setStoreId(storeRegBagList.get(m).getStore().getStoreId());
			    	    storeRegBagWtDTO.setWorkOrderNo(storeRegBagList.get(m).getProductionWorkOrder().getWorkOrderNo());
			    		storeRegBagWtDTO.setCustomerName(storeRegBagList.get(m).getCustomerName());
			    	    storeRegBagWtDTO.setStockQty(storeRegBagList.get(m).getStockQty());
			    		storeRegBagWtDTO.setBundleId(storeRegBagList.get(m).getBundleId());
			    	    storeRegBagWtDTO.setOrderId(storeRegBagList.get(m).getSalesOrderItem().getOrder().getOrderId());
			    	    storeRegBagWtDTO.setOrderDetailId(storeRegBagList.get(m).getSalesOrderItem().getOrderDetailId());
			    	    storeRegBagWtDTO.setItemId(storeRegBagList.get(m).getSalesOrderItem().getItem().getItemId());
			    		storeRegBagWtDTO.setPackingSlipNo(storeRegBagList.get(m).getPackingSlipNo());
			    		storeRegBagWtDTO.setSupervisor(storeRegBagList.get(m).getSupervisor());
			    		storeRegBagWtDTO.setWeight(storeRegBagList.get(m).getWeight());
			    		storeRegBagWtDTO.setQcStatus(storeRegBagList.get(m).getQcStatus());
			    		storeRegBagWtDTO.setQcSupervisor(storeRegBagList.get(m).getQcSupervisor());
			    		storeRegBagWtDTO.setRejectStatus(storeRegBagList.get(m).getRejectStatus());
                	    storeRegBagWtDTO.setBagWeight(bagWeight);
			    		StoreRegister storeRegDetails=storeRegBagWtDTO.getStoreRegister();
			    		storeRegisterService.update(storeRegDetails);//update store register		    		
	    	     	}//end of for loop
			    }// store reg if loop
		  	    }//end of if(updateStockOut==true && bagWeight!=null) loop
				return statusMssgList;
 }
	 /**
	   * This method fetch stock out records based on search parameters for grid
	   * Fetch  stock out records for grid
	   * @param search,filters,pageNumber,rowsPerPage,sortColName,sortOrder
	   * @return JqgridResponse<StockOutDTO>response
	   */
	@RequestMapping(value="/records", produces="application/json", method=RequestMethod.POST)
	public @ResponseBody
	JqgridResponse<StockOutDTO> records(
			@RequestParam(value="searchObject", required=false) String searchObject,
			@RequestParam("_search") Boolean search,
    		@RequestParam(value="filters", required=false) String filters,
			@RequestParam(value = "page", required = false) Integer pageNumber,
			@RequestParam(value = "rows", required = false) Integer rowsPerPage,
			@RequestParam(value = "sidx", required = false) String sortColName,
			@RequestParam(value = "sord", required = false, defaultValue = "asc") String sortOrder) {
	
		//JQ grid sorting column name  
		
		if(sortColName.equalsIgnoreCase("status")){
			sortColName="salesOrderItem.orders.orderStatus.status";
		}
		if(sortColName.equalsIgnoreCase("customerName")){
			sortColName="salesOrderItem.orders.customer.customerName";
		}
		if(sortColName.equalsIgnoreCase("customerCode")){
			sortColName="salesOrderItem.orders.customer.customerCode";
		}
		if(sortColName.equalsIgnoreCase("workOrderNo")){
			sortColName="productionWorkOrder.workOrderNo";
		}
		if(sortColName.equalsIgnoreCase("itemDescription")){
			sortColName="salesOrderItem.items.itemDescription";
		}
		if(sortColName.equalsIgnoreCase("units")){
			sortColName="salesOrderItem.items.unit.units";
		}
		/*Fetch logged in user*/	
		CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();;
        String userName=user.getFirstName()+" "+user.getLastName();
		String confirmStatus="No";
		if (searchObject != null && !(searchObject.equalsIgnoreCase("allSearch"))) {
			//fetch stock out based on default search and user
	           return getFilteredRecords(searchObject,confirmStatus, userName,pageNumber-1,rowsPerPage,sortColName,sortOrder);
	   } else{
		   /*Fetch jqgrid paged stock out records when search parameter is null*/
		 Page<StockOut>stockOut = stockOutService.getPagedStockOutUserName(pageNumber - 1,rowsPerPage, sortColName, sortOrder,confirmStatus,userName);
		 /*Intialize JQ grid response of type StockOutDTO */
		JqgridResponse<StockOutDTO> response = new JqgridResponse<StockOutDTO>();
		/*Method to set StockOut item list to StockOutDTO*/
		List<StockOutDTO> stockOutDTOs = convertToStoreDTO(stockOut.getContent());
		response.setRows(stockOutDTOs);
		response.setRecords(Long.valueOf(stockOut.getTotalElements()).toString());
		response.setTotal(Long.valueOf(stockOut.getTotalPages()).toString());
		response.setPage(Integer.valueOf(stockOut.getNumber()+1).toString());
		return response;
		}
	}
	 /**
	   * This method to fetch StockOut item based on search parameter and set response to JQGRID
	   * Fetch StockOut item details for grid
	   * @param filters,pageNumber,rowsPerPage,sortColName,sortOrder
	   * @return JqgridResponse<StoreRegisterDTO> response
	   */
	private JqgridResponse<StockOutDTO> getFilteredRecords(String filters,String confirmStatus,
			String userName,int pagenumber, Integer rows, String sortColName, String sortOrder) {
		 String qOrderId = null;
		 //JQ Grid filtering parameters
	      	JqgridFilter jqgridFilter = JqgridObjectMapper.map(filters);
	        for (JqgridFilter.Rule rule: jqgridFilter.getRules()) {
	                if (rule.getField().equals("orderId"))
	                	   qOrderId = rule.getData();
	        }
	          List<StockOut>stockOutItem = null;
	          //Method to fetch StockOut items based on filtering params
	          stockOutItem=stockOutService.fetchStockOutBySearchUserName
	        		(qOrderId,confirmStatus,userName,pagenumber,rows,sortColName,sortOrder);
	        //Set paged StockOut response to store register dto
	          List<StockOutDTO> stockOutDto = StockOutMapper.map(stockOutItem);
		        JqgridResponse<StockOutDTO> response = new JqgridResponse<StockOutDTO>();
		        response.setRows(stockOutDto);
		        return response;
     	}
	 /**
	   * This method to set StockOut item to StockOutDTO
	   * @param StockOut
	   * @return List<StockOutDTO>
	   */
	private List<StockOutDTO> convertToStoreDTO(List<StockOut> stockedOut) {
		List<StockOutDTO> stockOutDTOs = new ArrayList<>();
		for(StockOut stockOut : stockedOut) {   
			StockOutDTO stockOutDTO=new StockOutDTO();
			stockOutDTO.setStockOutId(stockOut.getStockOutId());
			stockOutDTO.setStoreId(stockOut.getStore().getStoreId());
			stockOutDTO.setOrderDetailId(stockOut.getSalesOrderItem().getOrderDetailId());
			stockOutDTO.setOrderId(stockOut.getSalesOrderItem().getOrder().getOrderId());
			stockOutDTO.setItemId(stockOut.getSalesOrderItem().getItem().getItemId());
			stockOutDTO.setItemCode(stockOut.getSalesOrderItem().getItem().getItemCode());
			stockOutDTO.setItemDescription(stockOut.getSalesOrderItem().getItem().getItemDescription());
			stockOutDTO.setSoItemQty(stockOut.getSalesOrderItem().getQuantity());
			stockOutDTO.setWorkOrderNo(stockOut.getProductionWorkOrder().getWorkOrderNo());
			stockOutDTO.setStockOutQty(stockOut.getStockOutQty());
			stockOutDTO.setQcStatus(stockOut.getQcStatus());
			stockOutDTO.setQcSupervisor(stockOut.getQcSupervisor());
			stockOutDTO.setCustomerName(stockOut.getSalesOrderItem().getOrder().getCustomer().getCustomerName());
			stockOutDTO.setCustomerCode(stockOut.getSalesOrderItem().getOrder().getCustomer().getCustomerCode());
			stockOutDTO.setBundleId(stockOut.getBundleId());
			stockOutDTO.setWeight(stockOut.getWeight());
			stockOutDTO.setConfirmStatus(stockOut.getConfirmStatus());
			stockOutDTO.setRemarks(stockOut.getRemarks());
			stockOutDTO.setUnits(stockOut.getSalesOrderItem().getItem().getUnit().getUnits());
			stockOutDTO.setPackingSlipNo(stockOut.getPackingSlipNo());
			stockOutDTO.setBagWeight(stockOut.getBagWeight());
			stockOutDTO.setQcStatus(stockOut.getQcStatus());
			stockOutDTO.setStatus(stockOut.getSalesOrderItem().getOrder().getOrderStatus().getStatus());
			stockOutDTOs.add(stockOutDTO);
			}//end of for loop
		return stockOutDTOs;
	}	
	 /**
	   * stock out items and craete delivery challan 
	   * @param StockOutid,challanDate,Salesorder Id
	   * @return List<String>status message
	   */
	@RequestMapping(value="/crud", produces="application/json" ,method = RequestMethod.POST)
	public @ResponseBody
	List<String> crud(
   	 @RequestParam(value = "idsOfSelectedRows[]", required = false) Long[] idsSelected,
     @RequestParam(value = "challanDate", required = false) String challanDate,
     @RequestParam(value = "salesOrderNo", required = false) String salesOrderNo ) {
		 String newdeliveryChallanNo = null;
		   Boolean updateStockOut=false;
		    Boolean storeRegDeleteResult=true;
		    Boolean updateStockOutDeliveryChallan=false;
		    Boolean finalresult=false;
			DeliveryChallan createddc=null;
			Boolean dcItemResult=false;
			List<String>dcNoList=new ArrayList<>();
		
			List<Long> stockedOutIdsList=new ArrayList<>();
			//fetch logged in user
			CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();;
			String userName = user.getFirstName()+" "+user.getLastName();
	 
		    if(idsSelected!=null && salesOrderNo!=null && idsSelected.length>0){
			 //fetch altest delivery challan details
				List<DeliveryChallan> existdeliveryChallanList=deliveryChallanService.fetchLatestDeliveryChallan();
				String existDcNo="";
				if(existdeliveryChallanList.size()>0)
					existDcNo=existdeliveryChallanList.get(0).getDeliveryChallanNo();//get latest delivery challan no
				
				if(!existDcNo.isEmpty()){
					//formatting delivery challan no to generate new deliverychallan no
					String existDcNumber = existDcNo.substring(0,existDcNo.indexOf("("));
					String existDcFinancialYear=existDcNo.substring(existDcNo.indexOf("(")+1,existDcNo.indexOf(")"));
					
					String currentYear=String.valueOf(new DateTime().getYear()%1000);
					String previousYear=String.valueOf((new DateTime().getYear()-1)%1000);
					String nextYear=String.valueOf((new DateTime().getYear()+1)%1000);
					String cuurentFinacialYear=null;
					if(new DateTime().getMonthOfYear()>3)
						cuurentFinacialYear=currentYear+"-"+nextYear;
					else
						cuurentFinacialYear=previousYear+"-"+currentYear;
					if(cuurentFinacialYear.equalsIgnoreCase(existDcFinancialYear)){
						Long newDcNumber=Long.valueOf(existDcNumber)+1;
						String newDcNo="0000";
						if(newDcNumber<10)
						  newDcNo="000"+newDcNumber;
						else if(newDcNumber<100)
					      newDcNo="00"+newDcNumber;
						else if(newDcNumber<1000)
						  newDcNo="0"+newDcNumber;
						else
						  newDcNo=String.valueOf(newDcNumber);
						newdeliveryChallanNo=newDcNo+"("+cuurentFinacialYear+")";	
				 	}else{
						String currentYears=String.valueOf(new DateTime().getYear()%1000);
						String previousYears=String.valueOf((new DateTime().getYear()-1)%1000);
						String nextYears=String.valueOf((new DateTime().getYear()+1)%1000);
						String finacialYears=null;
						if(new DateTime().getMonthOfYear()>3)
							finacialYears=currentYears+"-"+nextYears;
						else
							finacialYears=previousYears+"-"+currentYears;
						newdeliveryChallanNo="0001("+finacialYears+")";	
					}
				}//end of if loop of checking existing sales no
				else{
					String currentYear=String.valueOf(new DateTime().getYear()%1000);
					String previousYear=String.valueOf((new DateTime().getYear()-1)%1000);
					String nextYear=String.valueOf((new DateTime().getYear()+1)%1000);
					String finacialYear=null;
					if(new DateTime().getMonthOfYear()>3)
						finacialYear=currentYear+"-"+nextYear;
					else
						finacialYear=previousYear+"-"+currentYear;
					newdeliveryChallanNo="0001("+finacialYear+")";	
				}  //end of else loop
		
		//fetch delivery challan record by delivery challan no
		List<DeliveryChallan>dcList=deliveryChallanService.findByDeliveryChallanNo(newdeliveryChallanNo);
		  	if(dcList.size()==0){
		    for(int i=0;i<idsSelected.length;i++){
		 		List<StockOut> stockOutRecords=stockOutService.findByStockOutId(idsSelected[i]);
		 		if(stockOutRecords.size()>0 && stockOutRecords.get(0).getSalesOrderItem().getOrder().getOrderId().equalsIgnoreCase(salesOrderNo)){
		 		 StockOutDTO stockOutDTO=new StockOutDTO();
       			 stockOutDTO.setStockOutId(idsSelected[i]);
            	 stockOutDTO.setStoreId(stockOutRecords.get(0).getStore().getStoreId());
       			 stockOutDTO.setOrderDetailId(stockOutRecords.get(0).getSalesOrderItem().getOrderDetailId());
       			 stockOutDTO.setOrderId(stockOutRecords.get(0).getSalesOrderItem().getOrder().getOrderId());
       			 salesOrderNo=stockOutRecords.get(0).getSalesOrderItem().getOrder().getOrderId();
       			 stockOutDTO.setItemId(stockOutRecords.get(0).getSalesOrderItem().getItem().getItemId());
       			 stockOutDTO.setItemCode(stockOutRecords.get(0).getSalesOrderItem().getItem().getItemCode());
       			 stockOutDTO.setSoItemQty(stockOutRecords.get(0).getSalesOrderItem().getQuantity());
       			 stockOutDTO.setWorkOrderNo(stockOutRecords.get(0).getProductionWorkOrder().getWorkOrderNo());
       			 stockOutDTO.setStockOutQty(stockOutRecords.get(0).getStockOutQty());
       			 stockOutDTO.setQcStatus(stockOutRecords.get(0).getQcStatus());
       		     stockOutDTO.setQcSupervisor(stockOutRecords.get(0).getQcSupervisor());
       			 stockOutDTO.setCustomerName(stockOutRecords.get(0).getSalesOrderItem().getOrder().getCustomer().getCustomerName());
       			 stockOutDTO.setBundleId(stockOutRecords.get(0).getBundleId());
       			 stockOutDTO.setConfirmStatus("Yes");
       			 stockOutDTO.setPackingSlipNo(stockOutRecords.get(0).getPackingSlipNo());
       			 stockOutDTO.setRemarks(stockOutRecords.get(0).getRemarks());
       			 stockOutDTO.setSupervisor(stockOutRecords.get(0).getSupervisor());
       			 stockOutDTO.setWeight(stockOutRecords.get(0).getWeight());
       			 stockOutDTO.setBagWeight(stockOutRecords.get(0).getBagWeight());
       			 stockOutDTO.setDeliveryChallanNo(stockOutRecords.get(0).getDeliveryChallanNo());
       			 StockOut stockOut=stockOutDTO.getStockOut();
       			 updateStockOut=stockOutService.update(stockOut); //confrim stcok out and update

       			 if(updateStockOut==true){
    				 Long orderDetailId=stockOutRecords.get(0).getSalesOrderItem().getOrderDetailId();
    				 String workOrderNo=stockOutRecords.get(0).getProductionWorkOrder().getWorkOrderNo();
    				 String bundleId=stockOutRecords.get(0).getBundleId();
    				 //fetch store regsiter by sales order item id,bundle id and work order no
    				 List<StoreRegister>storeRegList=storeRegisterService.findByOrderDetailIdAndBundleIdAndWorkOrderNo(orderDetailId, bundleId, workOrderNo);
    				 if(storeRegList.size()>0)
    					 storeRegDeleteResult=storeRegisterService.delete(storeRegList.get(0).getStoreRegisterId());//delete store register record
    			 }//end of if(updateStockOut==true) loop 
       			 if(storeRegDeleteResult==true)
       				stockedOutIdsList.add(idsSelected[i]);//add stock out id to list
       			
		 		}//end of if loop
		    }// end of for loop 
		if(stockedOutIdsList.size()>0){
			DeliveryChallanDTO deliveryChallanDTO=new DeliveryChallanDTO();
			deliveryChallanDTO.setDeliveryChallanNo(newdeliveryChallanNo);
			deliveryChallanDTO.setDcSupervisor(userName);
			deliveryChallanDTO.setChallanDate(challanDate);
			deliveryChallanDTO.setInvoiceStatus("No");
			deliveryChallanDTO.setOrderId(salesOrderNo);
			deliveryChallanDTO.setStatus("Created");
			deliveryChallanDTO.setRemarks("");
			
			DeliveryChallan dcItem=deliveryChallanDTO.getDeliveryChallan();
		    createddc = deliveryChallanService.create(dcItem);//craete delivery challan record
		    if(createddc!=null){
	        for(int m=0;m<stockedOutIdsList.size();m++){
	        	//fetch stock out record by stock out id in the list
	         List<StockOut>selectedStockOutList=stockOutService.findByStockOutId(stockedOutIdsList.get(m));
	       	 StockOutDTO stockOutsDTO=new StockOutDTO();
	       	 stockOutsDTO.setStockOutId(selectedStockOutList.get(0).getStockOutId());
	         stockOutsDTO.setStoreId(selectedStockOutList.get(0).getStore().getStoreId());
	       	 stockOutsDTO.setOrderDetailId(selectedStockOutList.get(0).getSalesOrderItem().getOrderDetailId());
	       	 stockOutsDTO.setOrderId(selectedStockOutList.get(0).getSalesOrderItem().getOrder().getOrderId());
	       	 stockOutsDTO.setItemId(selectedStockOutList.get(0).getSalesOrderItem().getItem().getItemId());
	       	 stockOutsDTO.setItemCode(selectedStockOutList.get(0).getSalesOrderItem().getItem().getItemCode());
	       	 stockOutsDTO.setSoItemQty(selectedStockOutList.get(0).getSalesOrderItem().getQuantity());
	       	 stockOutsDTO.setWorkOrderNo(selectedStockOutList.get(0).getProductionWorkOrder().getWorkOrderNo());
	       	 stockOutsDTO.setStockOutQty(selectedStockOutList.get(0).getStockOutQty());
	       	 stockOutsDTO.setQcStatus(selectedStockOutList.get(0).getQcStatus());
	       	 stockOutsDTO.setQcSupervisor(selectedStockOutList.get(0).getQcSupervisor());
	       	 stockOutsDTO.setCustomerName(selectedStockOutList.get(0).getSalesOrderItem().getOrder().getCustomer().getCustomerName());
	       	 stockOutsDTO.setBundleId(selectedStockOutList.get(0).getBundleId());
	       	 stockOutsDTO.setConfirmStatus("Yes");
	         stockOutsDTO.setRemarks(selectedStockOutList.get(0).getRemarks());
	       	 stockOutsDTO.setPackingSlipNo(selectedStockOutList.get(0).getPackingSlipNo());
	       	 stockOutsDTO.setSupervisor(selectedStockOutList.get(0).getSupervisor());
	       	 stockOutsDTO.setWeight(selectedStockOutList.get(0).getWeight());
	       	 stockOutsDTO.setBagWeight(selectedStockOutList.get(0).getBagWeight());
	       	 stockOutsDTO.setDeliveryChallanNo(newdeliveryChallanNo);
   			 StockOut stockOut=stockOutsDTO.getStockOut();
   			 updateStockOutDeliveryChallan=stockOutService.update(stockOut);//confrim stock out and update with dc no

	        }// end of for loop
		  }//end of if(createddc!=null) loop
		}//end of if(stockedOutIdsList.size()>0)loop
		    
		 if(updateStockOutDeliveryChallan==true && createddc!=null){
			 //fetch stock out by dc no
			   List<StockOut> stockOutDetailsList=stockOutService.findByDeliveryChallanNo(newdeliveryChallanNo);
		 	  		Map<String, List<StockOut>> map = new HashMap<String, List<StockOut>>();//initialize hash map for iteration
		    		for (StockOut stockOutDetails :stockOutDetailsList) {
		    		   String key =String.valueOf(stockOutDetails.getPackingSlipNo())+stockOutDetails.getSalesOrderItem().getItem().getItemDescription()+stockOutDetails.getStockOutQty();
		    		  if (map.get(key) == null) {
		    		     map.put(key, new ArrayList<StockOut>());
		    	      }//end of if loop
		    		   map.get(key).add(stockOutDetails);
		    		}//end of for loop
		    		//iterating over values only
		    		for (List<StockOut> value : map.values()) {
		    			String packingNo=null;
		    			String stockOutBagNoString=null;
 		    			Long stockOutBagNo=value.get(0).getPackingSlipNo();//get bag no
 		    			if(stockOutBagNo<10){
 		    				stockOutBagNoString="0"+stockOutBagNo;
 		    			}else
 		    				stockOutBagNoString=String.valueOf(stockOutBagNo);
 		    	
		    			 packingNo=newdeliveryChallanNo+"/"+stockOutBagNoString;//create packing slip no
		    			 
		    			 String itemDesc=value.get(0).getSalesOrderItem().getItem().getItemDescription();
		    			 Integer noOfRolls=value.size();
		    			 String units=value.get(0).getSalesOrderItem().getItem().getUnit().getUnits();
		    			 String unitType=value.get(0).getSalesOrderItem().getItem().getUnit().getUnitType();
		    			 Double quantity=null;
		    			 if(units.equalsIgnoreCase("Kgs") || units.equalsIgnoreCase("Kg"))
		    		       quantity=value.get(0).getWeight();
		    		 	 else
		    			   quantity=value.get(0).getStockOutQty(); 
		    			 
		    				    Double totalQuantity=Double.valueOf(noOfRolls)*quantity;
		    				
		    					PackingSlipDTO packingSlipDTO=new PackingSlipDTO();
		    			        packingSlipDTO.setPackingSlipNo(packingNo);
		    			        packingSlipDTO.setDeliveryChallanNo(newdeliveryChallanNo);
		    			        packingSlipDTO.setInputSize(itemDesc);
		    			        packingSlipDTO.setNoOfRolls(noOfRolls);
		    			        packingSlipDTO.setQuanityPerRoll(quantity);
		    			        packingSlipDTO.setTotalQuantity(totalQuantity);
		    			        packingSlipDTO.setWeight(value.get(0).getBagWeight());
		    			        packingSlipDTO.setUnits(units);
		    			        packingSlipDTO.setUnitType(unitType);
		    			        PackingSlip packingSlip=packingSlipDTO.getPackingSlip();
		    			        PackingSlip createdPackingSlip=packingSlipService.create(packingSlip);//craete packing slip records
		    			        if(createdPackingSlip!=null)
		    			        	  finalresult=true;
		    		}// end of iterating for loop
			 }// end of  if(updateStockOutDeliveryChallan=true && createddc!=null)
			 if(updateStockOutDeliveryChallan=true && createddc!=null){
				 List<StockOut> stockOutList=stockOutService.findByDeliveryChallanNo(newdeliveryChallanNo);
				 if(stockOutList.size()>0){
					 Map<String, List<StockOut>> map = new HashMap<String, List<StockOut>>();
			    		for (StockOut stockOutsList :stockOutList) {
			    		  String dcNumber=stockOutsList.getDeliveryChallanNo();
			    		  String itemDescription=stockOutsList.getSalesOrderItem().getItem().getItemDescription();
			    		  Double qty=null;
			    		  String units=stockOutsList.getSalesOrderItem().getItem().getUnit().getUnits();
			    		  if(units.equalsIgnoreCase("Kgs") || units.equalsIgnoreCase("Kg"))
			    			  qty=stockOutsList.getWeight();
			    		  else
			    			  qty=stockOutsList.getStockOutQty(); 
	 		    		  
			    		  String key=null;
			    
			    		  key=dcNumber+itemDescription+qty;
			    		   if (map.get(key) == null) {
			    		     map.put(key, new ArrayList<StockOut>());
			    		     
			    		     }
			    		   map.get(key).add(stockOutsList);
			    		}//end of for loop
		    			    				 
			    		for (List<StockOut> value : map.values()) {
			    			String dcNo=value.get(0).getDeliveryChallanNo();
			    	        String units=value.get(0).getSalesOrderItem().getItem().getUnit().getUnits();
			    	        String unitType=value.get(0).getSalesOrderItem().getItem().getUnit().getUnitType();
				    		Float rate=value.get(0).getSalesOrderItem().getRate();
				    		String assortedType=value.get(0).getSalesOrderItem().getItem().getAssortedType();
				    		Long itemIds=value.get(0).getSalesOrderItem().getItem().getItemId();
				    		String productTypeKey=value.get(0).getSalesOrderItem().getItem().getProductType().getProductKey();
			                String itemLabel=value.get(0).getSalesOrderItem().getItem().getItemDescription();
			       			Long noOfRolls=(long) value.size();
			    			Double qtyPerRoll=null;
					    			
			    			if(units.equalsIgnoreCase("Kgs") || units.equalsIgnoreCase("Kg") )
			    				 qtyPerRoll=value.get(0).getWeight();
				    	    else
				    			 qtyPerRoll=value.get(0).getStockOutQty(); 
			    			
			    			Double totalQty=qtyPerRoll*noOfRolls;
			    	   					DeliveryChallanItemsDTO deliveryChallanItemsDTO=new DeliveryChallanItemsDTO();
			    	   					deliveryChallanItemsDTO.setDeliveryChallanNo(dcNo);
			    	   					deliveryChallanItemsDTO.setItemId(itemIds);
			    	   					deliveryChallanItemsDTO.setItemDescription(itemLabel);
			    	   					deliveryChallanItemsDTO.setNoOfRolls(noOfRolls);
			    	   					deliveryChallanItemsDTO.setQtyPerRoll(qtyPerRoll);
			    	   					deliveryChallanItemsDTO.setTotalQty(totalQty);
			    	   					deliveryChallanItemsDTO.setUnits(units);
			    	   					deliveryChallanItemsDTO.setRate(rate);
			    	   					deliveryChallanItemsDTO.setUnitType(unitType);
			    	   					deliveryChallanItemsDTO.setAssortedType(assortedType);
			    	   					deliveryChallanItemsDTO.setProductTypeKey(productTypeKey);
			    	   				    DeliveryChallanItems dcItemList=deliveryChallanItemsDTO.getDeliveryChallanItems();
			    	   				    DeliveryChallanItems createdDcItem=deliveryChallanItemsService.create(dcItemList);//create delivery challan item records
			    	 	                if(createdDcItem!=null)
			    	 	                	dcItemResult=true;
			    		   }// end of iterating for loop
		  				 }
			 }// end of  if(updateStockOutDeliveryChallan=true && createddc!=null){

List<Long> orderDetailsIdsList=new ArrayList<>();
for(int k=0;k<idsSelected.length;k++){
List<StockOut>stockOutsList=stockOutService.findByStockOutId(stockedOutIdsList.get(k));
if(stockOutsList.size()>0){
for (int iterator = 0; iterator < stockOutsList.size(); iterator++) {
		Long soItemId = stockOutsList.get(iterator).getSalesOrderItem().getOrderDetailId();

		if (!orderDetailsIdsList.contains(soItemId)) {
			orderDetailsIdsList.add(soItemId);//add sales order item to list
		}//end of inner fi loop
}//end of for loop

}//end of if(stockOutsList.size()>0) loop
}//en dof outer for loop

Boolean updateSalesOrderItem=false;
Boolean result =false;

if(finalresult==true && orderDetailsIdsList.size()>0 && dcItemResult==true){
//update sales order item
for(int s=0;s<orderDetailsIdsList.size();s++){
	Double totalStockedOutQty=0.0;
	Double newDispatchedQty=0.0;
	Double newCompletedQty=0.0;
	//fetch stock out bysales order item id
	List<StockOut> stockedOutList=stockOutService.findBySalesOrderItemOrderDetailId(orderDetailsIdsList.get(s));
	if(stockedOutList.size()>0){
		for(int k=0;k<stockedOutList.size();k++){
			String units=stockedOutList.get(k).getSalesOrderItem().getItem().getUnit().getUnits();
			//calculate stock out quantity based on unit of item
			if(units.equalsIgnoreCase("Kgs") || units.equalsIgnoreCase("Kg"))
				totalStockedOutQty=totalStockedOutQty+stockedOutList.get(k).getWeight();
			else
				totalStockedOutQty=totalStockedOutQty+stockedOutList.get(k).getStockOutQty();	
			}//end of for loop
	//fetch sales order item records based on id	
	List<SalesOrderItem>salesOrderItemList=orderDetailsService.findById(orderDetailsIdsList.get(s));
	if(salesOrderItemList.size()>0){
		//Calculating stocked out and balance qunatity of sales order item
		newDispatchedQty=totalStockedOutQty;
		if(salesOrderItemList.get(0).getCompletedQty()>(totalStockedOutQty-salesOrderItemList.get(0).getDispatchedQty())){
		 newCompletedQty=salesOrderItemList.get(0).getCompletedQty()-(totalStockedOutQty-salesOrderItemList.get(0).getDispatchedQty());
		}
		Double balQty=0.0;
		balQty=salesOrderItemList.get(0).getQuantity()-(salesOrderItemList.get(0).getProductionQty()+Math.round(newCompletedQty*100.0)/100.0+Math.round(newDispatchedQty*100.0)/100.0);
		if(balQty<0)
			balQty=0.0;
	SalesOrderItemsDTO soItemDTO=new SalesOrderItemsDTO();
	soItemDTO.setOrderDetailId(salesOrderItemList.get(0).getOrderDetailId());
	soItemDTO.setOrderId(salesOrderItemList.get(0).getOrder().getOrderId());
	soItemDTO.setItemId(salesOrderItemList.get(0).getItem().getItemId());
	soItemDTO.setQuantity(salesOrderItemList.get(0).getQuantity());
	soItemDTO.setBalanceQty(balQty);
	soItemDTO.setWeight(salesOrderItemList.get(0).getWeight());
	soItemDTO.setBundleSize(salesOrderItemList.get(0).getBundleSize());
	soItemDTO.setRate(salesOrderItemList.get(0).getRate());
	soItemDTO.setWoQty(salesOrderItemList.get(0).getWoQty());
	soItemDTO.setCompletedQty(Math.round(newCompletedQty*100.0)/100.0);
	soItemDTO.setItemCode(salesOrderItemList.get(0).getItemCode());
	soItemDTO.setProductionQty(salesOrderItemList.get(0).getProductionQty());
	soItemDTO.setDispatchedQty(Math.round(newDispatchedQty*100.0)/100.0);
	soItemDTO.setUpdatedBy(salesOrderItemList.get(0).getUpdatedBy());
	soItemDTO.setUpdatedTime(salesOrderItemList.get(0).getUpdatedTime().toString());
	soItemDTO.setPvcWeight(salesOrderItemList.get(0).getPvcWeight());
	SalesOrderItem soItem=soItemDTO.getOrderDetail();
	updateSalesOrderItem=orderDetailsService.update(soItem);//updates ales order item by stocked out quantity
}//end of if(salesOrderItemList.size()>0) loop
	if(updateSalesOrderItem==true)
		result=true;
	else
		result=false;
	}
}//end of for loop

}

if(result==true){
String soStatus="Approved";
//fetch sales order item record by id 
List<SalesOrderItem> salesOrderItemList=orderDetailsService.findByOrderId(salesOrderNo);
if(salesOrderItemList.size()>0){
int totalStockedInSoItems=0;
	for(int j=0;j<salesOrderItemList.size();j++){
		Double totalOrderedQty=salesOrderItemList.get(j).getQuantity();
		List<StockOut>stockOutSoItemList=stockOutService.findBySalesOrderItemOrderDetailIdAndConfirmStatus(salesOrderItemList.get(j).getOrderDetailId(), "Yes");
		if(stockOutSoItemList.size()>0){
			 Double totalStockedOutQty=0.0;
			for(int n=0;n<stockOutSoItemList.size();n++){
				String units=stockOutSoItemList.get(n).getSalesOrderItem().getItem().getUnit().getUnits();
				//calculate toatl stock out quantity of a sales order
				if(units.equalsIgnoreCase("Kgs")|| units.equalsIgnoreCase("Kg"))
					totalStockedOutQty=totalStockedOutQty+stockOutSoItemList.get(n).getWeight();
					else
						totalStockedOutQty=totalStockedOutQty+stockOutSoItemList.get(n).getStockOutQty();

			}//end of inner for loop
		
		if(totalStockedOutQty>=(96*totalOrderedQty)/100){
			totalStockedInSoItems++;
		}
	}//end of for loop
		}
	//set sales order staus based on stock out quantity
	if(totalStockedInSoItems==salesOrderItemList.size())
		soStatus="Dispatched";
	else
		soStatus="Approved";

		List<SalesOrder>soDetails=orderService.findBySalesOrderNoId(salesOrderNo);
		List<OrderStatus>orderStatus=orderStatusService.findByStatus(soStatus);
		if(orderStatus.size()>0 && soDetails.size()>0 ){
		OrderDTO orderDTO=new OrderDTO();
		orderDTO.setOrderId(soDetails.get(0).getOrderId());
		if(soDetails.get(0).getOrderRecDate()!=null)
		orderDTO.setOrderRecDate(Utility.formDateFormatter.print(soDetails.get(0).getOrderRecDate().getTime()));
		if(soDetails.get(0).getOrderAcceptanceDate()!=null)
		orderDTO.setOrderAcceptanceDate(Utility.formDateFormatter.print(soDetails.get(0).getOrderAcceptanceDate().getTime()));
		if(soDetails.get(0).getOrderDeliveryDate()!=null)
		orderDTO.setOrderDeliveryDate(Utility.formDateFormatter.print(soDetails.get(0).getOrderDeliveryDate().getTime()));
		orderDTO.setCustomerId(soDetails.get(0).getCustomer().getCustomerId());
		orderDTO.setPoDetails(soDetails.get(0).getPoDetails());
		orderDTO.setModeOfReceipt(soDetails.get(0).getModeOfReceipt());
		orderDTO.setOrderStatusId(orderStatus.get(0).getOrderStatusId());
		orderDTO.setCreatedTime(soDetails.get(0).getCreatedTime().toString());
		if(soDetails.get(0).getTargetDate()!=null)
		orderDTO.setTargetDate(Utility.formDateFormatter.print(soDetails.get(0).getTargetDate().getTime()));
		orderDTO.setCreatedBy(soDetails.get(0).getCreatedBy());
		orderDTO.setUpdatedBy(soDetails.get(0).getUpdatedBy());
		orderDTO.setUpdatedTime(soDetails.get(0).getUpdatedTime().toString());
		orderDTO.setInputQuantity(soDetails.get(0).getInputQuantity());
		orderDTO.setMailStatus(soDetails.get(0).getMailStatus());
		orderDTO.setLmeDetails(soDetails.get(0).getLmeDetails());
		SalesOrder salesOrder=orderDTO.getOrder();
		orderService.update(salesOrder);//upadte sales order based on stcok out quantity of its items

	}
}//end of if(salesOrderItemList.size()>0)loop
dcNoList.add(newdeliveryChallanNo);//add new create delivery challan no to return list
}  //end of if loop
}// end of if dc list size loop
		 }//end of if loop idsselected and sales order null
return dcNoList;
		

}
	 /**
	   * delete item slected for stock out and restock in item
	   * @param stockOutId
	   * @return StatusResponse
	   */
	@RequestMapping(value = "/delete", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	StatusResponse deleteId(@RequestParam(value = "id", required = true) Long stockOutId) {
		//fetch stock out records by stcok out id
		List<StockOut> stockOutList=stockOutService.findByStockOutId(stockOutId);
		String woNo=null;
	    Long orderDetailId=null;
	    String bundleId=null;
		if(stockOutList.size()>0){
			woNo=stockOutList.get(0).getProductionWorkOrder().getWorkOrderNo();
			bundleId=stockOutList.get(0).getBundleId();
			orderDetailId=stockOutList.get(0).getSalesOrderItem().getOrderDetailId();
		}//end of if if(stockOutList.size()>0) loop
		//fetch store register record by order detail id,bundle id and work order no
		List<StoreRegister> storeRegList=storeRegisterService.findByOrderDetailIdAndBundleIdAndWorkOrderNo(orderDetailId,bundleId,woNo);
		Boolean result=false;
		Boolean updateResult=false;
		   result = stockOutService.delete(stockOutId);//delete stock out
		   if(result==true && storeRegList.size()>0){
			   StoreRegisterDTO storeRegDTO=new StoreRegisterDTO();
			   storeRegDTO.setStoreRegisterId(storeRegList.get(0).getStoreRegisterId());
			   storeRegDTO.setItemCode(storeRegList.get(0).getSalesOrderItem().getItem().getItemCode());
			   storeRegDTO.setStoreId(storeRegList.get(0).getStore().getStoreId());
			   storeRegDTO.setWorkOrderNo(storeRegList.get(0).getProductionWorkOrder().getWorkOrderNo());
			   storeRegDTO.setCustomerName(storeRegList.get(0).getCustomerName());
			   storeRegDTO.setStockQty(storeRegList.get(0).getStockQty());
			   storeRegDTO.setBundleId(storeRegList.get(0).getBundleId());
			   storeRegDTO.setOrderId(storeRegList.get(0).getOrderId());
			   storeRegDTO.setOrderDetailId(storeRegList.get(0).getSalesOrderItem().getOrderDetailId());
			   storeRegDTO.setItemId(storeRegList.get(0).getSalesOrderItem().getItem().getItemId());
			   storeRegDTO.setPackingSlipNo(null);
			   storeRegDTO.setSupervisor(storeRegList.get(0).getSupervisor());
			   storeRegDTO.setWeight(storeRegList.get(0).getWeight());
			   storeRegDTO.setQcStatus(storeRegList.get(0).getQcStatus());
			   storeRegDTO.setQcSupervisor(storeRegList.get(0).getQcSupervisor());
				 storeRegDTO.setRejectStatus(storeRegList.get(0).getRejectStatus());
			   storeRegDTO.setBagWeight(null);
			   StoreRegister storeReg=storeRegDTO.getStoreRegister();
			   updateResult=storeRegisterService.update(storeReg);//update store register with restocked in item
	
		   }//end of  if(result==true && storeRegList.size()>0) loop
			return new StatusResponse(updateResult);
   
	}
	 /**
	   * bar code scanning functionality of stock out
	   * @param item code,sales order no,work order no and bundle id
	   * @return List<String> status message
	   */
	@RequestMapping(value = "/barCode", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	List<String> barCode(
			 @RequestParam(value = "itemCode", required = false) String itemCode,
			 @RequestParam(value = "soNo", required = false) String soNo,
			 @RequestParam(value = "woNo", required = false) String woNo,
			 @RequestParam(value = "bundleId", required = false) String bundleId){
		List<String>stockInAttributes=new ArrayList<>();
		if(itemCode!=null && itemCode!="" && soNo!=null && soNo!="" && 
				woNo!=null && woNo!="" 	&& bundleId!=null && bundleId!=""){
			 WordUtils.capitalize(itemCode);
			 WordUtils.capitalize(soNo);
    		 WordUtils.capitalize(woNo);
		String itemDesc="";
		String customerName="";
		String quantity="";
		String units="";
	    String weight="";
	    List<StoreRegister> storeRegList=storeRegisterService.findByOrderIdAndItemCodeAndBundleIdAndWorkOrderNo(soNo, itemCode, bundleId, woNo);
		if(storeRegList.size()>0){
			if(storeRegList.get(0).getSalesOrderItem().getItem().getItemDescription()!=null)
			itemDesc=storeRegList.get(0).getSalesOrderItem().getItem().getItemDescription();//get item description
			
			if(storeRegList.get(0).getSalesOrderItem().getOrder().getCustomer().getCustomerName()!=null)
			customerName=storeRegList.get(0).getSalesOrderItem().getOrder().getCustomer().getCustomerName();//get customer name
			
			if(storeRegList.get(0).getStockQty()!=null)
			quantity=storeRegList.get(0).getStockQty().toString();//get stock quantity
			
			if(storeRegList.get(0).getSalesOrderItem().getItem().getUnit().getUnits()!=null)
				units=storeRegList.get(0).getSalesOrderItem().getItem().getUnit().getUnits();	//get units
			if(storeRegList.get(0).getWeight()!=null)
				weight=storeRegList.get(0).getWeight().toString();	//get weight
		}//end of if(storeRegList.size()>0)loop
	//add attributes to return list
		stockInAttributes.add(itemDesc);
		stockInAttributes.add(customerName);
		stockInAttributes.add(quantity);
		stockInAttributes.add(units);
		stockInAttributes.add(weight);
		}  
		return stockInAttributes;
	}
	 /**
	   * functionality to edit bag no and weight in stock out grid
	   * @param stock out id,bag no,bag wight
	   * @return StatusResponse
	   */
	@RequestMapping(value = "/modify", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	StatusResponse modify(@RequestParam Long id,
			@RequestParam String oper,
			@RequestParam(required = false) Long packingSlipNo,
			@RequestParam(required = false) String bagWeight){
		Boolean result=false;
		if(packingSlipNo!=null && id!=null){
			boolean match = false;
			Double validBagWeight=0.0;
		  	String decimalPattern = "((-|\\+)?[0-9]+(\\.[0-9]+)?)+";//regex patter for valid entry matching 
		  	if(bagWeight!=null && bagWeight!="")
			match = Pattern.matches(decimalPattern, bagWeight);
			if(match==true){
				validBagWeight=Double.valueOf(bagWeight);
			}//end of if loop
			//fetch stcok out records by id
			List<StockOut>stockOutList=stockOutService.findByStockOutId(id);
			if(stockOutList.size()>0){
				String workOrderNo=stockOutList.get(0).getProductionWorkOrder().getWorkOrderNo();
				String salesorderNo=stockOutList.get(0).getSalesOrderItem().getOrder().getOrderId();
				String itemCode=stockOutList.get(0).getSalesOrderItem().getItem().getItemCode();
				String bundleId=stockOutList.get(0).getBundleId();
				//fetch store register record by sales order,item code,vbundle id and work order no
				List<StoreRegister>storeRegList=storeRegisterService.findByOrderIdAndItemCodeAndBundleIdAndWorkOrderNo(salesorderNo, itemCode, bundleId, workOrderNo);
				Boolean updateStoreReg=false;
				Boolean updateStockOut=false;
				if(storeRegList.size()>0){
					 StoreRegisterDTO storeRegDTO=new StoreRegisterDTO();
					 storeRegDTO.setStoreRegisterId(storeRegList.get(0).getStoreRegisterId());
					 storeRegDTO.setItemCode(storeRegList.get(0).getItemCode());
					 storeRegDTO.setStoreId(storeRegList.get(0).getStore().getStoreId());
					 storeRegDTO.setWorkOrderNo(storeRegList.get(0).getProductionWorkOrder().getWorkOrderNo());
					 storeRegDTO.setCustomerName(storeRegList.get(0).getCustomerName());
					 storeRegDTO.setStockQty(storeRegList.get(0).getStockQty());
					 storeRegDTO.setBundleId(storeRegList.get(0).getBundleId());
					 storeRegDTO.setOrderId(storeRegList.get(0).getOrderId());
					 storeRegDTO.setOrderDetailId(storeRegList.get(0).getSalesOrderItem().getOrderDetailId());
					 storeRegDTO.setItemId(storeRegList.get(0).getItemId());
					 storeRegDTO.setPackingSlipNo(packingSlipNo);
					 storeRegDTO.setSupervisor(storeRegList.get(0).getSupervisor());
					 storeRegDTO.setWeight(storeRegList.get(0).getWeight());
					 storeRegDTO.setQcStatus(storeRegList.get(0).getQcStatus());
					 storeRegDTO.setQcSupervisor(storeRegList.get(0).getQcSupervisor());
					 storeRegDTO.setRejectStatus(storeRegList.get(0).getRejectStatus());
					 storeRegDTO.setBagWeight(validBagWeight);
					 StoreRegister storeRegister=storeRegDTO.getStoreRegister();
					 updateStoreReg=storeRegisterService.update(storeRegister);//update store register by validf weight and bag no
					 if(updateStoreReg==true){
					    StockOutDTO stockOutDTO=new StockOutDTO();
						stockOutDTO.setStockOutId(stockOutList.get(0).getStockOutId());
						stockOutDTO.setStoreId(stockOutList.get(0).getStore().getStoreId());
						stockOutDTO.setOrderDetailId(stockOutList.get(0).getSalesOrderItem().getOrderDetailId());
						stockOutDTO.setOrderId(stockOutList.get(0).getSalesOrderItem().getOrder().getOrderId());
						stockOutDTO.setItemId(stockOutList.get(0).getSalesOrderItem().getItem().getItemId());
						stockOutDTO.setItemCode(stockOutList.get(0).getSalesOrderItem().getItem().getItemCode());
						stockOutDTO.setSoItemQty(stockOutList.get(0).getSalesOrderItem().getQuantity());
						stockOutDTO.setWorkOrderNo(stockOutList.get(0).getProductionWorkOrder().getWorkOrderNo());
						stockOutDTO.setStockOutQty(stockOutList.get(0).getStockOutQty());
						stockOutDTO.setQcStatus(stockOutList.get(0).getQcStatus());
						stockOutDTO.setQcSupervisor(stockOutList.get(0).getQcSupervisor());
						stockOutDTO.setCustomerName(stockOutList.get(0).getSalesOrderItem().getOrder().getCustomer().getCustomerName());
						stockOutDTO.setBundleId(stockOutList.get(0).getBundleId());
						stockOutDTO.setPackingSlipNo(packingSlipNo);
						stockOutDTO.setSupervisor(stockOutList.get(0).getSupervisor());
						stockOutDTO.setWeight(stockOutList.get(0).getWeight());
						stockOutDTO.setConfirmStatus(stockOutList.get(0).getConfirmStatus());
						stockOutDTO.setRemarks(stockOutList.get(0).getRemarks());
						stockOutDTO.setDeliveryChallanNo(stockOutList.get(0).getDeliveryChallanNo());
						stockOutDTO.setBagWeight(validBagWeight);
						StockOut updatetockOut=stockOutDTO.getStockOut();
						updateStockOut=stockOutService.update(updatetockOut);//update stock out by bag weight and bag no
					 }
					 if(updateStockOut==true && updateStoreReg==true){
						 String confirmStatus="No";
						//fetch StockOut record by sales order,item code,vbundle id and work order no
							List<StockOut> stockOutBagList=stockOutService.findByOrderIdoPackingSlipNoConfirmStatus(salesorderNo,packingSlipNo,confirmStatus);
							//fetch store register record by sales order,item code,vbundle id and work order no
							List<StoreRegister> storeRegBagList=storeRegisterService.findByOrderIdoPackingSlipNo(salesorderNo,packingSlipNo);
							if(stockOutBagList.size()>0){
						    	for(int l=0;l<stockOutBagList.size();l++){
						    		if(stockOutBagList.get(l).getBagWeight()!=validBagWeight){
						    		StockOutDTO stockOutBagWtDTO=new StockOutDTO();
						    		stockOutBagWtDTO.setStockOutId(stockOutBagList.get(l).getStockOutId());
						    		stockOutBagWtDTO.setStoreId(stockOutBagList.get(l).getStore().getStoreId());
						    		stockOutBagWtDTO.setOrderDetailId(stockOutBagList.get(l).getSalesOrderItem().getOrderDetailId());
						    		stockOutBagWtDTO.setOrderId(stockOutBagList.get(l).getSalesOrderItem().getOrder().getOrderId());
						    		stockOutBagWtDTO.setItemId(stockOutBagList.get(l).getSalesOrderItem().getItem().getItemId());
						    		stockOutBagWtDTO.setItemCode(stockOutBagList.get(l).getSalesOrderItem().getItem().getItemCode());
						    		stockOutBagWtDTO.setSoItemQty(stockOutBagList.get(l).getSalesOrderItem().getQuantity());
						    		stockOutBagWtDTO.setWorkOrderNo(stockOutBagList.get(l).getProductionWorkOrder().getWorkOrderNo());
						    		stockOutBagWtDTO.setStockOutQty(stockOutBagList.get(l).getStockOutQty());
						    		stockOutBagWtDTO.setQcStatus(stockOutBagList.get(l).getQcStatus());
						    		stockOutBagWtDTO.setQcSupervisor(stockOutBagList.get(l).getQcSupervisor());
						    		stockOutBagWtDTO.setCustomerName(stockOutBagList.get(l).getCustomerName());
						    		stockOutBagWtDTO.setBundleId(stockOutBagList.get(l).getBundleId());
						    		stockOutBagWtDTO.setPackingSlipNo(stockOutBagList.get(l).getPackingSlipNo());
						    		stockOutBagWtDTO.setSupervisor(stockOutBagList.get(l).getSupervisor());
						    		stockOutBagWtDTO.setWeight(stockOutBagList.get(l).getWeight());
						    		stockOutBagWtDTO.setConfirmStatus(stockOutBagList.get(l).getConfirmStatus());
						    		stockOutBagWtDTO.setBagWeight(validBagWeight);
						    		stockOutBagWtDTO.setRemarks(stockOutBagList.get(l).getRemarks());
						    		stockOutBagWtDTO.setDeliveryChallanNo(stockOutBagList.get(l).getDeliveryChallanNo());
						    		StockOut stockOutDetails=stockOutBagWtDTO.getStockOut();
						    		stockOutService.update(stockOutDetails);//upadte stock out with valid bag weight and bag no		
						    		}//end of if(stockOutBagList.get(l).getBagWeight()!=validBagWeight)loop
						    	}//end of for loop
						    }// stock out if loop  
						    if(storeRegBagList.size()>0){
						    	for(int l=0;l<storeRegBagList.size();l++){
						    		if(storeRegBagList.get(l).getBagWeight()!=validBagWeight){
						    	    StoreRegisterDTO storeRegBagWtDTO=new StoreRegisterDTO();
						    	    storeRegBagWtDTO.setStoreRegisterId(storeRegBagList.get(l).getStoreRegisterId());
						    	    storeRegBagWtDTO.setItemCode(storeRegBagList.get(l).getSalesOrderItem().getItem().getItemCode());
						    	    storeRegBagWtDTO.setStoreId(storeRegBagList.get(l).getStore().getStoreId());
						    	    storeRegBagWtDTO.setWorkOrderNo(storeRegBagList.get(l).getProductionWorkOrder().getWorkOrderNo());
						    		storeRegBagWtDTO.setCustomerName(storeRegBagList.get(l).getCustomerName());
						    	    storeRegBagWtDTO.setStockQty(storeRegBagList.get(l).getStockQty());
						    		storeRegBagWtDTO.setBundleId(storeRegBagList.get(l).getBundleId());
						    	    storeRegBagWtDTO.setOrderId(storeRegBagList.get(l).getSalesOrderItem().getOrder().getOrderId());
						    	    storeRegBagWtDTO.setOrderDetailId(storeRegBagList.get(l).getSalesOrderItem().getOrderDetailId());
						    	    storeRegBagWtDTO.setItemId(storeRegBagList.get(l).getSalesOrderItem().getItem().getItemId());
						    		storeRegBagWtDTO.setPackingSlipNo(storeRegBagList.get(l).getPackingSlipNo());
						    		storeRegBagWtDTO.setSupervisor(storeRegBagList.get(l).getSupervisor());
						    		storeRegBagWtDTO.setWeight(storeRegBagList.get(l).getWeight());
						    		storeRegBagWtDTO.setQcStatus(storeRegBagList.get(l).getQcStatus());
						    		storeRegBagWtDTO.setQcSupervisor(storeRegBagList.get(l).getQcSupervisor());
						    		storeRegBagWtDTO.setRejectStatus(storeRegBagList.get(l).getRejectStatus());
			                     	storeRegBagWtDTO.setBagWeight(validBagWeight);
						    		StoreRegister storeRegDetails=storeRegBagWtDTO.getStoreRegister();
						    		storeRegisterService.update(storeRegDetails);//update store reg with bag weight and bag no		    		
						    	}//end of for loop
						    		}//end of  if(storeRegBagList.size()>0)loop
						    }// store reg if loop

					 }
					 
				result=true;	 
				}//end of if(storeRegList.size()>0)loop
			}//end of if(stockOutList.size()>0)loop
		}//end of if(packingSlipNo!=null && id!=null)loop
		return new StatusResponse(result);
	}
}