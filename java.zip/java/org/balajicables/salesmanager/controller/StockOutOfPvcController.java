package org.balajicables.salesmanager.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.regex.Pattern;
import javax.annotation.Resource;
import org.balajicables.salesmanager.common.JqgridResponse;
import org.balajicables.salesmanager.common.StatusResponse;
import org.balajicables.salesmanager.dto.PvcStockOutDTO;
import org.balajicables.salesmanager.dto.RawMaterialStoreRegDTO;
import org.balajicables.salesmanager.model.ProductionWorkOrder;
import org.balajicables.salesmanager.model.PvcStockOut;
import org.balajicables.salesmanager.model.RawMaterialStoreReg;
import org.balajicables.salesmanager.service.PvcStockOutService;
import org.balajicables.salesmanager.service.RawMaterialStoreRegService;
import org.balajicables.salesmanager.service.WorkOrderItemService;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
/**
* This class demonstrates PVC Stock Out Module
* @author Abin Sam
*/
@Controller
@RequestMapping("/stockOutOfPVC")
public class StockOutOfPvcController {


	@Resource
	private WorkOrderItemService workOrderItemService;
	
	@Resource
	private RawMaterialStoreRegService rawMaterialStoreRegService;
	
	@Resource
	private PvcStockOutService pvcStockOutService;

	
	 /**
	   * This method returns stockOutOfPVC.jsp.
	   * @param Model to set the attribute.
	   * @return stockOutOfPVC.jsp.
	   */
	@RequestMapping(method = RequestMethod.GET)
	public String getRawMaterials(Model model) {

		return "stockOutOfPVC";
	}
	
	 /**
	   * This method returns work order nos list based on process type ,month and year selected
	   * Fetch all work order nos for select box
	   * @param processType,year,month,Model to set the attribute.
	   * @return List<String>WorkOrderNosList
	   */
	@RequestMapping(value = "/getWorkOrderNos", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	ArrayList<String> getWorkOrderNos(
			@RequestParam("processType") String processType,
			@RequestParam("month") int month,
			@RequestParam("year") int year) {
		
		ArrayList<String> woNosList = new ArrayList<>();
	    //fetch Production work order records based on created month,year and process type
		List<ProductionWorkOrder> woItemList = workOrderItemService.findByProcessTypeAndMonthYear(processType,month+1,year);
		for (int iterator = 0; iterator < woItemList.size(); iterator++) {
			String woNo = woItemList.get(iterator).getWorkOrderNo();
			if (!woNosList.contains(woNo)) {
				woNosList.add(woNo);
			}//end of if (!woNosList.contains(woNo))loop
			Collections.sort(woNosList,Collections.reverseOrder());//sort work order nos in reverse order	
		}//end of for loop
		
		return woNosList;
	}
	
	
	 /**
	   * This method fetch raw material stock (PVC)based on qc status
	   * Fetch raw material stock for grid
	   * @param search,filters,pageNumber,rowsPerPage,sortColName,sortOrder
	   * @return JqgridResponse<RawMaterialStoreRegDTO> response
	   */
	@RequestMapping(value="/records", produces="application/json",method=RequestMethod.POST)
	public @ResponseBody
	JqgridResponse<RawMaterialStoreRegDTO> records(
    		@RequestParam("_search") Boolean search,
    		@RequestParam(value="filters", required=false) String filters,
			@RequestParam(value = "page", required = false) Integer pageNumber,
			@RequestParam(value = "rows", required = false) Integer rowsPerPage,
			@RequestParam(value = "sidx", required = false) String sortColName,
			@RequestParam(value = "sord", required = false, defaultValue = "asc") String sortOrder) {

		//JQ grid sorting column name  
		if(sortColName.equalsIgnoreCase("purchaseOrderItemId")){
			sortColName="purchaseOrderItem.purchaseOrderItemId";
		}
	
		if(sortColName.equalsIgnoreCase("customerName")){
			sortColName="purchaseOrderItem.purchaseOrder.customer.customerName";
		}
		if(sortColName.equalsIgnoreCase("customerCode")){
			sortColName="purchaseOrderItem.purchaseOrder.customer.customerCode";
		}
		if(sortColName.equalsIgnoreCase("itemId")){
			sortColName="purchaseOrderItem.item.itemId";
		}
		if(sortColName.equalsIgnoreCase("itemCode")){
			sortColName="purchaseOrderItem.item.itemCode";
		}
		if(sortColName.equalsIgnoreCase("itemDescription")){
			sortColName="purchaseOrderItem.item.itemDescription";
		}
		
		
		
		String productType[]={"PV"};
		String qcStatus[]={"Approved","Pending"};
		//fetch qc pending and approved raw material stock (PVC) in stores
		Page<RawMaterialStoreReg> rawMaterialStoreRegs = rawMaterialStoreRegService.getPagedApprovedPvcStock(pageNumber - 1,
				rowsPerPage, sortColName, sortOrder,productType,qcStatus);
		/*Intialize JQ grid response of type RawMaterialStoreRegDTO */
		JqgridResponse<RawMaterialStoreRegDTO> response = new JqgridResponse<RawMaterialStoreRegDTO>();
		/*Method to set RawMaterialStock item list to RawMaterialStoreRegDTO*/
		List<RawMaterialStoreRegDTO> rawMaterialStoreRegDTOs = convertToDTO(rawMaterialStoreRegs.getContent());
		response.setRows(rawMaterialStoreRegDTOs);
		response.setRecords(Long.valueOf(rawMaterialStoreRegs.getTotalElements()).toString());
		response.setTotal(Long.valueOf(rawMaterialStoreRegs.getTotalPages()).toString());
		response.setPage(Integer.valueOf(rawMaterialStoreRegs.getNumber()+1).toString());
		return response;
	}
	
	
	 /**
	   * This method to set RawMaterial item to RawMaterialStoreRegDTO
	   * @param RawMaterialStoreReg
	   * @return List<RawMaterialStoreRegDTO>
	   */
	private List<RawMaterialStoreRegDTO> convertToDTO(List<RawMaterialStoreReg> rawMaterialStoreRegs) {
		List<RawMaterialStoreRegDTO> rawMaterialStoreRegDTOs = new ArrayList<>();
		for(RawMaterialStoreReg rawMaterialStoreReg : rawMaterialStoreRegs) {
			
			RawMaterialStoreRegDTO rawMaterialStoreRegDTO = new RawMaterialStoreRegDTO();
			
			
			rawMaterialStoreRegDTO.setRwStoreRegId(rawMaterialStoreReg.getRwStoreRegId());
			rawMaterialStoreRegDTO.setStoreId(rawMaterialStoreReg.getStore().getStoreId());
			rawMaterialStoreRegDTO.setCustomerName(rawMaterialStoreReg.getPurchaseOrderItem().getPurchaseOrder().getCustomer().getCustomerName());
			rawMaterialStoreRegDTO.setBalanceQty(rawMaterialStoreReg.getPurchaseOrderItem().getBalanceQty());
			rawMaterialStoreRegDTO.setBatchNo(rawMaterialStoreReg.getBatchNo());
			rawMaterialStoreRegDTO.setQcStatus(rawMaterialStoreReg.getQcStatus());
			rawMaterialStoreRegDTO.setGrossWeight(rawMaterialStoreReg.getGrossWeight());
			rawMaterialStoreRegDTO.setItemCode(rawMaterialStoreReg.getPurchaseOrderItem().getItem().getItemCode());
			rawMaterialStoreRegDTO.setItemDescription(rawMaterialStoreReg.getPurchaseOrderItem().getItem().getItemDescription());
			rawMaterialStoreRegDTO.setSendToRbd(rawMaterialStoreReg.getSendToRbd());
			rawMaterialStoreRegDTO.setTareWeight(rawMaterialStoreReg.getTareWeight());
			rawMaterialStoreRegDTO.setNetWeight(rawMaterialStoreReg.getNetWeight());
			rawMaterialStoreRegDTO.setNoOfBags(rawMaterialStoreReg.getNoOfBags());
			rawMaterialStoreRegDTO.setPoNo(rawMaterialStoreReg.getPurchaseOrderItem().getPurchaseOrder().getPoNo());
			rawMaterialStoreRegDTO.setPurchaseOrderItemId(rawMaterialStoreReg.getPurchaseOrderItem().getPurchaseOrderItemId());
			rawMaterialStoreRegDTO.setSupervisorName(rawMaterialStoreReg.getSupervisor());
			rawMaterialStoreRegDTO.setTotalQty(rawMaterialStoreReg.getTotalQty());
			rawMaterialStoreRegDTO.setStockInStatus(rawMaterialStoreReg.getStockInStatus());
			rawMaterialStoreRegDTO.setQcSupervisor(rawMaterialStoreReg.getQcSupervisor());	
			
			rawMaterialStoreRegDTOs.add(rawMaterialStoreRegDTO);
		}//end of for loop
		return rawMaterialStoreRegDTOs;
	}


	 /**
	   * crud functionality of raw material stock
	   * @param StoreRegister
	   * @return List<StoreRegisterDTO>
	   */
	@RequestMapping(value = "/crud", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	StatusResponse crud(
			@RequestParam Long id,
			@RequestParam String oper,
			@RequestParam (required=false)  String stockOutQty,
			@RequestParam (required=false)  Double totalQty
						
			) {

		Boolean updaterawMaterilaStoreReg=false;
		Boolean patternMatch=false;
		if(oper.equalsIgnoreCase("edit")){
			String decimalPattern = "((-|\\+)?[0-9]+(\\.[0-9]+)?)+"; //regex pattern for matching 
			patternMatch = Pattern.matches(decimalPattern, stockOutQty);//check pattern to confrim valid entries
		}//end of if(oper.equalsIgnoreCase("edit"))loop
		if(stockOutQty=="")
			patternMatch=true;
	
		if(patternMatch==true){
		if(stockOutQty!=null){
			Double validStockOutQty=0.0;
			if(stockOutQty=="")
			validStockOutQty=totalQty;	
			else
		    validStockOutQty=Double.valueOf(stockOutQty);	
			if(validStockOutQty==0){
				validStockOutQty=totalQty;
			}//end of if loop
		
			if(validStockOutQty>totalQty){
				validStockOutQty=totalQty;
			}//end of if loop
			//fetch raw material stock based on RawMaterialStoreReg id
			List<RawMaterialStoreReg> rawMaterialStoreRegLsit=rawMaterialStoreRegService.findById(id);
			if(rawMaterialStoreRegLsit.size()>0){
				RawMaterialStoreRegDTO rawMaterialStoreRegDTO = new RawMaterialStoreRegDTO();
				
				
				rawMaterialStoreRegDTO.setRwStoreRegId(rawMaterialStoreRegLsit.get(0).getRwStoreRegId());
				rawMaterialStoreRegDTO.setStoreId(rawMaterialStoreRegLsit.get(0).getStore().getStoreId());
				rawMaterialStoreRegDTO.setCustomerName(rawMaterialStoreRegLsit.get(0).getPurchaseOrderItem().getPurchaseOrder().getCustomer().getCustomerName());
				rawMaterialStoreRegDTO.setBalanceQty(rawMaterialStoreRegLsit.get(0).getPurchaseOrderItem().getBalanceQty());
				rawMaterialStoreRegDTO.setBatchNo(rawMaterialStoreRegLsit.get(0).getBatchNo());
				rawMaterialStoreRegDTO.setQcStatus(rawMaterialStoreRegLsit.get(0).getQcStatus());
				rawMaterialStoreRegDTO.setGrossWeight(rawMaterialStoreRegLsit.get(0).getGrossWeight());
				rawMaterialStoreRegDTO.setItemCode(rawMaterialStoreRegLsit.get(0).getPurchaseOrderItem().getItem().getItemCode());
				rawMaterialStoreRegDTO.setItemDescription(rawMaterialStoreRegLsit.get(0).getPurchaseOrderItem().getItem().getItemDescription());
				rawMaterialStoreRegDTO.setSendToRbd(rawMaterialStoreRegLsit.get(0).getSendToRbd());
				rawMaterialStoreRegDTO.setTareWeight(rawMaterialStoreRegLsit.get(0).getTareWeight());
				rawMaterialStoreRegDTO.setNetWeight(rawMaterialStoreRegLsit.get(0).getNetWeight());
				rawMaterialStoreRegDTO.setNoOfBags(rawMaterialStoreRegLsit.get(0).getNoOfBags());
				rawMaterialStoreRegDTO.setPoNo(rawMaterialStoreRegLsit.get(0).getPurchaseOrderItem().getPurchaseOrder().getPoNo());
				rawMaterialStoreRegDTO.setPurchaseOrderItemId(rawMaterialStoreRegLsit.get(0).getPurchaseOrderItem().getPurchaseOrderItemId());
				rawMaterialStoreRegDTO.setSupervisorName(rawMaterialStoreRegLsit.get(0).getSupervisor());
				rawMaterialStoreRegDTO.setTotalQty(rawMaterialStoreRegLsit.get(0).getTotalQty());
				rawMaterialStoreRegDTO.setStockInStatus(rawMaterialStoreRegLsit.get(0).getStockInStatus());
				rawMaterialStoreRegDTO.setQcSupervisor(rawMaterialStoreRegLsit.get(0).getQcSupervisor());
		        rawMaterialStoreRegDTO.setStockOutQty(validStockOutQty);
		        
		        RawMaterialStoreReg rawMaterialStoreReg=rawMaterialStoreRegDTO.getRawMaterialStoreReg();
		        
		        updaterawMaterilaStoreReg=rawMaterialStoreRegService.update(rawMaterialStoreReg);//update rawmaterial store reg 
			}//end of if(rawMaterialStoreRegLsit.size()>0) loop
				
 	     }//end of if(stockOutQty!=null) loop
		}  //end of if(patternMatch==true)loop
		return new StatusResponse(updaterawMaterilaStoreReg);
	
	    }


	 /**
	   * stock out pvc for selected extrusion work order
	   * @param rawmaterial store register id,work order no
	   * @return StatusResponse
	   */
	
	@RequestMapping(value="/pvcStockOut", produces="application/json" ,method = RequestMethod.POST)
	public @ResponseBody
	StatusResponse pvcStockOut(
   	 @RequestParam(value = "idsOfSelectedRows[]", required = false) Long[] idsSelected,
   	 @RequestParam(value="extrusionWoNo",required=true) String extrusionWoNo) {
		Boolean updatePvcStockOut=false;
		Boolean updaterawMaterilaStoreReg=false;
		if(idsSelected!=null){
			for(int k=0;k<idsSelected.length;k++){
				//fetch raw material stock by raw material store reg id
				List<RawMaterialStoreReg>rawMaterialStoreReg=rawMaterialStoreRegService.findById(idsSelected[k]);
				if(rawMaterialStoreReg.size()>0){
					String batch=rawMaterialStoreReg.get(0).getBatchNo();//get batch no
					List<PvcStockOut>pvcStockOutList=pvcStockOutService.findByBatchAndProductionWorkOrderNo(batch,extrusionWoNo);
					if(pvcStockOutList.size()>0){
						PvcStockOutDTO pvcStockOutDTO=new PvcStockOutDTO();
						pvcStockOutDTO.setPvcStockOutId(pvcStockOutList.get(0).getPvcStockOutID());
						pvcStockOutDTO.setBatch(pvcStockOutList.get(0).getBatch());
						pvcStockOutDTO.setQuantity(pvcStockOutList.get(0).getQuantity()+rawMaterialStoreReg.get(0).getStockOutQty());
						pvcStockOutDTO.setWorkOrderNo(pvcStockOutList.get(0).getProductionWorkOrder().getWorkOrderNo());
						pvcStockOutDTO.setItemId(pvcStockOutList.get(0).getItem().getItemId());
						PvcStockOut pvcStockOut=pvcStockOutDTO.getPvcStockOut();
						updatePvcStockOut=pvcStockOutService.update(pvcStockOut);//update pvc stock out
					}//end of 	if(pvcStockOutList.size()>0)loop
					else{
						PvcStockOutDTO pvcStockOutDTOs=new PvcStockOutDTO();
						pvcStockOutDTOs.setBatch(batch);
						pvcStockOutDTOs.setQuantity(rawMaterialStoreReg.get(0).getStockOutQty());
						pvcStockOutDTOs.setWorkOrderNo(extrusionWoNo);
						pvcStockOutDTOs.setItemId(rawMaterialStoreReg.get(0).getPurchaseOrderItem().getItem().getItemId());
						PvcStockOut pvcStockOuts=pvcStockOutDTOs.getPvcStockOut();
						PvcStockOut createdPvcStockOuts=pvcStockOutService.create(pvcStockOuts);//create PVC  stock 
						if(createdPvcStockOuts!=null)
							updatePvcStockOut=true;	
					}//end of else loop
					
					if(updatePvcStockOut==true){
						RawMaterialStoreRegDTO rawMaterialStoreRegDTO = new RawMaterialStoreRegDTO();
						rawMaterialStoreRegDTO.setRwStoreRegId(rawMaterialStoreReg.get(0).getRwStoreRegId());
						rawMaterialStoreRegDTO.setStoreId(rawMaterialStoreReg.get(0).getStore().getStoreId());
						rawMaterialStoreRegDTO.setCustomerName(rawMaterialStoreReg.get(0).getPurchaseOrderItem().getPurchaseOrder().getCustomer().getCustomerName());
						rawMaterialStoreRegDTO.setBalanceQty(rawMaterialStoreReg.get(0).getPurchaseOrderItem().getBalanceQty());
						rawMaterialStoreRegDTO.setBatchNo(rawMaterialStoreReg.get(0).getBatchNo());
						rawMaterialStoreRegDTO.setQcStatus(rawMaterialStoreReg.get(0).getQcStatus());
						rawMaterialStoreRegDTO.setGrossWeight(rawMaterialStoreReg.get(0).getGrossWeight());
						rawMaterialStoreRegDTO.setItemCode(rawMaterialStoreReg.get(0).getPurchaseOrderItem().getItem().getItemCode());
						rawMaterialStoreRegDTO.setItemDescription(rawMaterialStoreReg.get(0).getPurchaseOrderItem().getItem().getItemDescription());
						rawMaterialStoreRegDTO.setSendToRbd(rawMaterialStoreReg.get(0).getSendToRbd());
						rawMaterialStoreRegDTO.setTareWeight(rawMaterialStoreReg.get(0).getTareWeight());
						rawMaterialStoreRegDTO.setNetWeight(rawMaterialStoreReg.get(0).getNetWeight());
						rawMaterialStoreRegDTO.setNoOfBags(rawMaterialStoreReg.get(0).getNoOfBags());
						rawMaterialStoreRegDTO.setPoNo(rawMaterialStoreReg.get(0).getPurchaseOrderItem().getPurchaseOrder().getPoNo());
						rawMaterialStoreRegDTO.setPurchaseOrderItemId(rawMaterialStoreReg.get(0).getPurchaseOrderItem().getPurchaseOrderItemId());
						rawMaterialStoreRegDTO.setSupervisorName(rawMaterialStoreReg.get(0).getSupervisor());
						rawMaterialStoreRegDTO.setTotalQty(rawMaterialStoreReg.get(0).getTotalQty()-rawMaterialStoreReg.get(0).getStockOutQty());
						rawMaterialStoreRegDTO.setStockInStatus(rawMaterialStoreReg.get(0).getStockInStatus());
				        rawMaterialStoreRegDTO.setStockOutQty((double)0);
				        rawMaterialStoreRegDTO.setQcSupervisor(rawMaterialStoreReg.get(0).getQcSupervisor());
				        if(rawMaterialStoreReg.get(0).getTotalQty()-rawMaterialStoreReg.get(0).getStockOutQty()==0){
				        	rawMaterialStoreRegService.delete(rawMaterialStoreReg.get(0).getRwStoreRegId());//delete pvc stock from store register after stock out	
				        }
				        else{
				        RawMaterialStoreReg rawMaterialStoreRegs=rawMaterialStoreRegDTO.getRawMaterialStoreReg();
				        updaterawMaterilaStoreReg=rawMaterialStoreRegService.update(rawMaterialStoreRegs);
				        }
			  
					}//end of 	if(updatePvcStockOut==true) loop
			   }// end of if(rawMaterialStoreReg.size()>0) loop
			}// end of for loop
		}//end of if(idsSelected!=null) loop
			
		 return new StatusResponse(updaterawMaterilaStoreReg);
}
}