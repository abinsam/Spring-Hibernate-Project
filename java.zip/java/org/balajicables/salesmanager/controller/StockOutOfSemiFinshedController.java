package org.balajicables.salesmanager.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.annotation.Resource;
import org.balajicables.salesmanager.CustomUser;
import org.balajicables.salesmanager.common.JqgridResponse;
import org.balajicables.salesmanager.common.StatusResponse;
import org.balajicables.salesmanager.dto.SemifinishedStockOutDTO;
import org.balajicables.salesmanager.dto.StockOutDTO;
import org.balajicables.salesmanager.dto.StoreRegisterDTO;
import org.balajicables.salesmanager.model.Item;
import org.balajicables.salesmanager.model.ProductionWorkOrder;
import org.balajicables.salesmanager.model.SemifinishedStockOut;
import org.balajicables.salesmanager.model.StockOut;
import org.balajicables.salesmanager.model.StoreRegister;
import org.balajicables.salesmanager.service.ItemService;
import org.balajicables.salesmanager.service.ProductionWorkOrderService;
import org.balajicables.salesmanager.service.SemifinishedStockOutService;
import org.balajicables.salesmanager.service.StockOutService;
import org.balajicables.salesmanager.service.StoreRegisterService;
import org.springframework.data.domain.Page;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
/**
* This class demonstrates Semi finished stock out  Module
* @author Abin Sam
*/
@Controller
@RequestMapping("/stockOutSemiFinished")

public class StockOutOfSemiFinshedController {

	@Resource
	private ProductionWorkOrderService productionWorkOrderService;
	@Resource
	private StoreRegisterService storeRegisterService;
	@Resource
	private SemifinishedStockOutService semifinishedStockOutService;
	@Resource
	private StockOutService stockOutService;
	@Resource
	private ItemService itemService;
	
	 /**
	   * This method returns stockOutOfSemiFinishedGoods.jsp.
	   * @param Model to set the attribute.
	   * @return stockOutOfSemiFinishedGoods.jsp.
	   */
	@RequestMapping
	public String getProcessAndWorkOrderPage(Model model) {
	return "stockOutOfSemiFinishedGoods";
	}
	
	
	 /**
	   * This method returns workorderNos List
	   * Fetch all workorderNos based on selected year ,month and process type
	   * @param Model to set the attribute.
	   * @return List<String>workorderNos
	   */
	@RequestMapping(value = "/fetchWorkOrder", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	List<String> getWorkOrderNos(@RequestParam(value = "process", required = true) String process,
			@RequestParam(value = "month", required = true) String month,
			@RequestParam(value = "year", required = true) String year) {
		ArrayList<String> woNosList = new ArrayList<>();
		
		String processType=null;
		//if process is Bunching slect mwd items for stock out
          if(process.equalsIgnoreCase("MWD"))
        	  processType="Bunching";
        //if process is Extrusion slect Bunching items for stock out 
          if(process.equalsIgnoreCase("Bunching"))
        	  processType="Extrusion";
        int monthValue=0;
        int yearValue=0;
        if(month!=null && month!=""){
        	monthValue=Integer.parseInt(month);//parse month to integer
        }
       if(year!=null && year!=""){
    	   yearValue=Integer.parseInt(year);//parse year to integer
        }
          List<ProductionWorkOrder>poWoNoList=null;
          //Method to fetch Production work order List based on process type,month and year
          if(processType!=null)
          poWoNoList=productionWorkOrderService.findByProcessTypeAndMonthYear(processType,(monthValue+1),yearValue);
          for(int k=0;k<poWoNoList.size();k++)
        	  woNosList.add(poWoNoList.get(k).getWorkOrderNo());//add work order no to return list
          Collections.sort(woNosList,Collections.reverseOrder());//sort order of work order nos in descending order
          return woNosList; 
	 }    
	
	
	 /**
	   * This method fetch data for  semifinished stock out manual grid
	   * Fetch all semifinished stock in stores based on process type selected for stock out
	   * @param filters,search,process, pageNumber,rowsPerPage,sortColName,sortOrder
	   * @return JqgridResponse<StoreRegisterDTO>response
	   */
	@RequestMapping(value="/storeReg", produces="application/json", method=RequestMethod.POST)
	public @ResponseBody
	JqgridResponse<StoreRegisterDTO> semiFinishedStoreReg(
			@RequestParam(value="filters", required=false) String filters,
			@RequestParam("_search") Boolean search,
    		@RequestParam(value="process", required=false) String process,
			@RequestParam(value = "page", required = false) Integer pageNumber,
			@RequestParam(value = "rows", required = false) Integer rowsPerPage,
			@RequestParam(value = "sidx", required = false) String sortColName,
			@RequestParam(value = "sord", required = false, defaultValue = "asc") String sortOrder) {
	//sort column name of jqgrid records
		if(sortColName.equalsIgnoreCase("itemDescription")){
			sortColName="salesOrderItem.items.itemDescription";
		}
		if(sortColName.equalsIgnoreCase("workOrderNo")){
			sortColName="productionWorkOrder.workOrderNo";
		}
		if(sortColName.equalsIgnoreCase("customerName")){
			sortColName="customerName";
		}
		if(sortColName.equalsIgnoreCase("status")){
			sortColName="salesOrderItem.orders.orderStatus.status";
		}
		if(sortColName.equalsIgnoreCase("customerCode")){
			sortColName="salesOrderItem.orders.customer.customerCode";
		}
		if(sortColName.equalsIgnoreCase("customerName")){
			sortColName="salesOrderItem.orders.customer.customerName";
		}
		String []itemType;
		//Select item type for search parameter based on process type
		if(process==null || process=="")
		   itemType= new String[] {"Bunching","Multiwire"};
		else if(process.equalsIgnoreCase("Bunching"))
			itemType= new String[] {"Bunching"};
		else if(process.equalsIgnoreCase("MWD"))
			itemType= new String[] {"Multiwire"};
		else
			itemType= new String[] {"Bunching","Multiwire"};
		//fetch semifinished stock from store register based on item type
		Page<StoreRegister> storeReg =storeRegisterService.getPagedSemiFinishedStoreReg(pageNumber - 1,rowsPerPage, sortColName, sortOrder,itemType);
	
		/*Intialize JQ grid response of type StoreRegisterDTO */
		JqgridResponse<StoreRegisterDTO> response = new JqgridResponse<StoreRegisterDTO>();
		/*Method to set StoreRegister item list to StoreRegisterDTO*/
		List<StoreRegisterDTO> storeDTOs = convertToStoreDTO(storeReg.getContent());
		response.setRows(storeDTOs);
		response.setRecords(Long.valueOf(storeReg.getTotalElements()).toString());
		response.setTotal(Long.valueOf(storeReg.getTotalPages()).toString());
		response.setPage(Integer.valueOf(storeReg.getNumber()+1).toString());

		return response;
	}
	
	
	
	 /**
	   * This method to set store regsiter item to StoreRegisterDTO
	   * @param StoreRegister
	   * @return List<StoreRegisterDTO>
	   */
	private List<StoreRegisterDTO> convertToStoreDTO(List<StoreRegister> storeRegs) {
		List<StoreRegisterDTO> storeRegDTOs = new ArrayList<>();
		for(StoreRegister storeReg : storeRegs) {
			StoreRegisterDTO storeRegDTO=new StoreRegisterDTO();
			storeRegDTO.setStoreRegisterId(storeReg.getStoreRegisterId());
			storeRegDTO.setStoreId(storeReg.getStore().getStoreId());
			storeRegDTO.setStoreAddress(storeReg.getStore().getStoreAddress());
			storeRegDTO.setItemId(storeReg.getSalesOrderItem().getItem().getItemId());
			storeRegDTO.setItemCode(storeReg.getSalesOrderItem().getItem().getItemCode());
			storeRegDTO.setOrderId(storeReg.getSalesOrderItem().getOrder().getOrderId());
			storeRegDTO.setCustomerId(storeReg.getSalesOrderItem().getOrder().getCustomer().getCustomerId());
			storeRegDTO.setCustomerName(storeReg.getSalesOrderItem().getOrder().getCustomer().getCustomerName());
			storeRegDTO.setCustomerCode(storeReg.getSalesOrderItem().getOrder().getCustomer().getCustomerCode());
			storeRegDTO.setWorkOrderNo(storeReg.getProductionWorkOrder().getWorkOrderNo());
			storeRegDTO.setStockQty(storeReg.getStockQty());
			storeRegDTO.setBundleId(storeReg.getBundleId());
			storeRegDTO.setOrderDetailId(storeReg.getSalesOrderItem().getOrderDetailId());
			storeRegDTO.setItemDescription(storeReg.getSalesOrderItem().getItem().getItemDescription());
			storeRegDTO.setPackingSlipNo(storeReg.getPackingSlipNo());
			storeRegDTO.setSupervisor(storeReg.getSupervisor());
			storeRegDTO.setWeight(storeReg.getWeight());
			storeRegDTO.setUnits(storeReg.getSalesOrderItem().getItem().getUnit().getUnits());
			storeRegDTO.setBagWeight(storeReg.getBagWeight());
			storeRegDTO.setStatus(storeReg.getSalesOrderItem().getOrder().getOrderStatus().getStatus());
			storeRegDTO.setQcStatus(storeReg.getQcStatus());
			storeRegDTO.setQcSupervisor(storeReg.getQcSupervisor());
			storeRegDTOs.add(storeRegDTO)	;
		}//end of for loop
		return storeRegDTOs;
	}

	 /**
	   * This method fetch semi finished stock in  Store register based on search parameters for grid
	   * Fetch  semi finished stock for grid
	   * @param search,filters,pageNumber,rowsPerPage,sortColName,sortOrder
	   * @return JqgridResponse<SemifinishedStockOutDTO>response
	   */
	@RequestMapping(value="/semiFinishedStockOutRecords", produces="application/json", method=RequestMethod.POST)
	public @ResponseBody
	JqgridResponse<SemifinishedStockOutDTO> semiFinishedStockOutRecords(
			@RequestParam("_search") Boolean search,
    		@RequestParam(value="filters", required=false) String filters,
			@RequestParam(value = "page", required = false) Integer pageNumber,
			@RequestParam(value = "rows", required = false) Integer rowsPerPage,
			@RequestParam(value = "sidx", required = false) String sortColName,
			@RequestParam(value="itemType", required=false) String itemType,
			@RequestParam(value = "sord", required = false, defaultValue = "asc") String sortOrder) {
		//fetch logged in user
		CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();;
		String userName = user.getFirstName()+" "+user.getLastName();
	//sort column name based on grid sortcol parameter
		if(sortColName.equalsIgnoreCase("itemDescription")){
			sortColName="salesOrderItem.items.itemDescription";
		}
		if(sortColName.equalsIgnoreCase("workOrderNo")){
			sortColName="productionWorkOrder.workOrderNo";
		}
		if(sortColName.equalsIgnoreCase("status")){
			sortColName="salesOrderItem.orders.orderStatus.status";
		}
		Page<SemifinishedStockOut> semifinishedStockOutList=null;
		String[] itemTypeArray = new String[] {};//initialize itemType Array
		/*Intialize JQ grid response of type SemifinishedStockOutDTO */
		JqgridResponse<SemifinishedStockOutDTO> response = new JqgridResponse<SemifinishedStockOutDTO>();
	
if(itemType!=null && itemType!="")
{
	    itemTypeArray = new String[] {itemType};//initialize itemType Array
		String confirmStatus="No";//initialize confirmStatus
	    //method to fetch semifinished stock selected for stock out
		semifinishedStockOutList =semifinishedStockOutService.getPagedNotConfirmedUserBasedSemiFinishedSotck(pageNumber - 1,rowsPerPage, sortColName, sortOrder,confirmStatus,itemTypeArray,userName);

		/*Method to set SemifinishedStockOut item list to SemifinishedStockOutDTO*/
		List<SemifinishedStockOutDTO> semifinishedStockOutDTOs=null;
	    semifinishedStockOutDTOs = convertToSemifinishedStockOutDTO(semifinishedStockOutList.getContent());
		response.setRows(semifinishedStockOutDTOs);
		response.setRecords(Long.valueOf(semifinishedStockOutList.getTotalElements()).toString());
		response.setTotal(Long.valueOf(semifinishedStockOutList.getTotalPages()).toString());
		response.setPage(Integer.valueOf(semifinishedStockOutList.getNumber()+1).toString());
}
		return response;

}

	 /**
	   * This method to set SemifinishedStock item to SemifinishedStockOutDTO
	   * @param SemifinishedStockOut
	   * @return List<SemifinishedStockOutDTO>
	   */
	private List<SemifinishedStockOutDTO> convertToSemifinishedStockOutDTO(
			List<SemifinishedStockOut> semifinishedStockOuts) {
		List<SemifinishedStockOutDTO> semifinishedStockOutDTOs = new ArrayList<>();
		for(SemifinishedStockOut semifinishedStockOut : semifinishedStockOuts) {
			SemifinishedStockOutDTO semifinishedStockOutDTO=new SemifinishedStockOutDTO();
			semifinishedStockOutDTO.setSemifinishedStockOutId(semifinishedStockOut.getSemifinishedStockOutId());
			semifinishedStockOutDTO.setStoreId(semifinishedStockOut.getStore().getStoreId());
			semifinishedStockOutDTO.setItemId(semifinishedStockOut.getSalesOrderItem().getItem().getItemId());
			semifinishedStockOutDTO.setItemCode(semifinishedStockOut.getSalesOrderItem().getItem().getItemCode());
			semifinishedStockOutDTO.setOrderId(semifinishedStockOut.getSalesOrderItem().getOrder().getOrderId());
			semifinishedStockOutDTO.setStockedOutFor(semifinishedStockOut.getProductionWorkOrder().getWorkOrderNo());
			semifinishedStockOutDTO.setWorkOrderNo(semifinishedStockOut.getProductionWorkOrders().getWorkOrderNo());
			semifinishedStockOutDTO.setStockOutQty(semifinishedStockOut.getStockOutQty());
			semifinishedStockOutDTO.setBundleId(semifinishedStockOut.getBundleId());
			semifinishedStockOutDTO.setOrderDetailId(semifinishedStockOut.getSalesOrderItem().getOrderDetailId());
			semifinishedStockOutDTO.setItemDescription(semifinishedStockOut.getSalesOrderItem().getItem().getItemDescription());
			semifinishedStockOutDTO.setSupervisor(semifinishedStockOut.getSupervisor());
			semifinishedStockOutDTO.setWeight(semifinishedStockOut.getWeight());
			semifinishedStockOutDTO.setCustomerName(semifinishedStockOut.getSalesOrderItem().getOrder().getCustomer().getCustomerName());
			semifinishedStockOutDTO.setCustomerCode(semifinishedStockOut.getSalesOrderItem().getOrder().getCustomer().getCustomerCode());
			semifinishedStockOutDTO.setQcStatus(semifinishedStockOut.getQcStatus());
			semifinishedStockOutDTO.setStatus(semifinishedStockOut.getSalesOrderItem().getOrder().getOrderStatus().getStatus());
			
			semifinishedStockOutDTOs.add(semifinishedStockOutDTO)	;
		}//end of for loop
		return semifinishedStockOutDTOs;
	}
	
	

	 /**
	   * Manual stock Out of semifinished goods
	   * @param StoreRegisterId,workOrderNo
	   * @return StatusResponse
	   */
	@RequestMapping(value = "/stockOutManual", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	StatusResponse stockOutManual(
			@RequestParam(value = "idsOfSelectedRows[]", required = false) Long[] idsSelected,
			@RequestParam(value = "workOrderNo", required = false) String workOrderNo){
		//fetch logged in user
		CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();;
	 	String supervisor = user.getFirstName()+" "+user.getLastName();
	 	Boolean result=false;
	 	//method to fetch production work order list based on work order no
	 	List<ProductionWorkOrder>pdnWorkOrderList=productionWorkOrderService.findByProductionWorkOrderNo(workOrderNo);
	 	String processType=pdnWorkOrderList.get(0).getProcess().getProcessType();//get process type
	 	
	 	if(idsSelected!=null){
	 		for(int k=0;k<idsSelected.length;k++){
	 			Boolean stockValid=false;
	 			//fetch store register list based on id
	 			List<StoreRegister>storeRegList=storeRegisterService.findById(idsSelected[k]);
	 			String itemType=storeRegList.get(0).getSalesOrderItem().getItem().getItemType();
	 			//Check validity of stock out condition
	 			if(processType.equalsIgnoreCase("Bunching") && itemType.equalsIgnoreCase("Multiwire"))
	 				stockValid=true;
	 			else if(processType.equalsIgnoreCase("Extrusion") && itemType.equalsIgnoreCase("Bunching") )
	 				stockValid=true;
	 			else
	 				stockValid=false;
	 			
	 			if(storeRegList.size()>0 && stockValid==true){
	 				String confirmStatus="No";
	 				String salesOrder=storeRegList.get(0).getSalesOrderItem().getOrder().getOrderId();
	 				String workOrder=storeRegList.get(0).getProductionWorkOrder().getWorkOrderNo();
	 				String itemCode=storeRegList.get(0).getSalesOrderItem().getItem().getItemCode();
	 				String bundles=storeRegList.get(0).getBundleId();
	 				List<StockOut>stockOutList=stockOutService.findByOrderIdAndItemCodeAndBundleIdAndWorkOrderNoAndConfirmStatus(salesOrder, itemCode, bundles, workOrder, confirmStatus);
	 		 		if(stockOutList.size()==0){
	 				StockOutDTO stockOutDTO=new StockOutDTO();
					stockOutDTO.setStoreId(storeRegList.get(0).getStore().getStoreId());
					stockOutDTO.setOrderDetailId(storeRegList.get(0).getSalesOrderItem().getOrderDetailId());
					stockOutDTO.setOrderId(storeRegList.get(0).getSalesOrderItem().getOrder().getOrderId());
					stockOutDTO.setItemCode(storeRegList.get(0).getSalesOrderItem().getItem().getItemCode());
					stockOutDTO.setItemId(storeRegList.get(0).getSalesOrderItem().getItem().getItemId());
					stockOutDTO.setSoItemQty(storeRegList.get(0).getSalesOrderItem().getQuantity());
					stockOutDTO.setWorkOrderNo(storeRegList.get(0).getProductionWorkOrder().getWorkOrderNo());
					stockOutDTO.setStockOutQty(storeRegList.get(0).getStockQty());
					stockOutDTO.setQcStatus(storeRegList.get(0).getQcStatus());
					stockOutDTO.setQcSupervisor(storeRegList.get(0).getQcSupervisor());
					stockOutDTO.setBundleId(storeRegList.get(0).getBundleId());
					stockOutDTO.setCustomerName(storeRegList.get(0).getSalesOrderItem().getOrder().getCustomer().getCustomerName());
				    stockOutDTO.setSupervisor(supervisor);
				    stockOutDTO.setWeight(storeRegList.get(0).getWeight());
				    stockOutDTO.setConfirmStatus("Yes");	
				    stockOutDTO.setRemarks(storeRegList.get(0).getRemarks());
				    stockOutDTO.setDeliveryChallanNo("");
				    stockOutDTO.setPackingSlipNo((long) 0);
				    stockOutDTO.setBagWeight(storeRegList.get(0).getWeight());
				   	StockOut stockOutItem=stockOutDTO.getStockOut();
			        stockOutService.create(stockOutItem);//create stock out of semifinished item
	 		 		}//end of if(stockOutList.size()==0) loop
	 				SemifinishedStockOutDTO  semifinishedStockOutDTO=new SemifinishedStockOutDTO();
	 				semifinishedStockOutDTO.setStockedOutFor(workOrderNo);
	 				semifinishedStockOutDTO.setWorkOrderNo(storeRegList.get(0).getProductionWorkOrder().getWorkOrderNo());
	 				semifinishedStockOutDTO.setOrderDetailId(storeRegList.get(0).getSalesOrderItem().getOrderDetailId());
	 				semifinishedStockOutDTO.setOrderId(storeRegList.get(0).getSalesOrderItem().getOrder().getOrderId());
	 				semifinishedStockOutDTO.setItemCode(storeRegList.get(0).getSalesOrderItem().getItem().getItemCode());
	 				semifinishedStockOutDTO.setItemId(storeRegList.get(0).getSalesOrderItem().getItem().getItemId());
	 				semifinishedStockOutDTO.setStoreId(storeRegList.get(0).getStore().getStoreId());
	 				semifinishedStockOutDTO.setStockOutQty(storeRegList.get(0).getStockQty());
	 				semifinishedStockOutDTO.setWeight(storeRegList.get(0).getWeight());
	 				semifinishedStockOutDTO.setBundleId(storeRegList.get(0).getBundleId());
	 				semifinishedStockOutDTO.setSupervisor(supervisor);
	 				semifinishedStockOutDTO.setConfirmStatus("Yes");
	 				semifinishedStockOutDTO.setQcStatus(storeRegList.get(0).getQcStatus());
	 				semifinishedStockOutDTO.setQcSupervisor(storeRegList.get(0).getQcSupervisor());
	 				SemifinishedStockOut semifinishedStockOut=semifinishedStockOutDTO.getSemifinishedStockOut();
	 				SemifinishedStockOut createdSemiFinishedStockOut=semifinishedStockOutService.create(semifinishedStockOut);//create semifinished stock out entry
	 				if(createdSemiFinishedStockOut!=null)
	 	 					result = storeRegisterService.delete(idsSelected[k]);//delete store register entry after stock out
	
	 		}// end of if loop
	 	}//end of for loop
	 	}//end of if null check loop	
	 	return new StatusResponse(result);
	}

	 /**
	   * Barcode stock Out of semifinished goods
	   * @param StoreRegisterId,workOrderNo
	   * @return StatusResponse
	   */
	@RequestMapping(value = "/stockOutBarCode", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	List<String> stockOutBarCode(
			@RequestParam(value = "idsOfSelectedRows[]", required = false) Long[] idsSelected,
			@RequestParam(value = "workOrderNo", required = false) String workOrderNo){
		//fetch logged in user
		CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();;
	 	String supervisor = user.getFirstName()+" "+user.getLastName();
	 	Boolean result=false;
		//method to fetch production work order list based on work order no
	 	List<ProductionWorkOrder>pdnWorkOrderList=productionWorkOrderService.findByProductionWorkOrderNo(workOrderNo);
	 	String processType=pdnWorkOrderList.get(0).getProcess().getProcessType();
	 	List<String>statusMssgList=new ArrayList<>();
	 	if(idsSelected!=null){
	 		for(int k=0;k<idsSelected.length;k++){
	 			Boolean stockValid=false;
	 			//method to fetch semi finished stock record slected for stock out
	 			List<SemifinishedStockOut>semifinishedStockOutList=semifinishedStockOutService.findBySemifinishedStockOutId(idsSelected[k]);
	 			String itemType=null;
	 			String salesOrderId=null;
	 			String bundleId=null;
	 			String itemCode=null;
	 			String woNo=null;
	 			if(semifinishedStockOutList.size()>0){	
	 					itemType=semifinishedStockOutList.get(0).getSalesOrderItem().getItem().getItemType();
	 					salesOrderId=semifinishedStockOutList.get(0).getSalesOrderItem().getOrder().getOrderId();
	 					bundleId=semifinishedStockOutList.get(0).getBundleId();
	 					woNo=semifinishedStockOutList.get(0).getProductionWorkOrders().getWorkOrderNo();
	 					itemCode=semifinishedStockOutList.get(0).getSalesOrderItem().getItem().getItemCode();
	 			}//end of if(semifinishedStockOutList.size()>0) loop
	 			//check avlidity of stock out parameters selected
	 			if(processType.equalsIgnoreCase("Bunching") && itemType.equalsIgnoreCase("Multiwire"))
	 				stockValid=true;
	 			else if(processType.equalsIgnoreCase("Extrusion") && itemType.equalsIgnoreCase("Bunching") )
	 				stockValid=true;
	 			else
	 				stockValid=false;
	 			//fetch store register record based on sales order,item code,bundle id and work order no
	 			List<StoreRegister>storeRegList=storeRegisterService.findByOrderIdAndItemCodeAndBundleIdAndWorkOrderNo(salesOrderId, itemCode, bundleId, woNo);
	 			if(semifinishedStockOutList.size()>0 && stockValid==true && storeRegList.size()>0){
		 					
	 				SemifinishedStockOutDTO  semifinishedStockOutDTO=new SemifinishedStockOutDTO();
	 				semifinishedStockOutDTO.setSemifinishedStockOutId(semifinishedStockOutList.get(0).getSemifinishedStockOutId());
	 				semifinishedStockOutDTO.setStockedOutFor(workOrderNo);
	 				semifinishedStockOutDTO.setWorkOrderNo(semifinishedStockOutList.get(0).getProductionWorkOrders().getWorkOrderNo());
	 				semifinishedStockOutDTO.setOrderDetailId(semifinishedStockOutList.get(0).getSalesOrderItem().getOrderDetailId());
	 				semifinishedStockOutDTO.setOrderId(semifinishedStockOutList.get(0).getSalesOrderItem().getOrder().getOrderId());
	 				semifinishedStockOutDTO.setItemCode(semifinishedStockOutList.get(0).getSalesOrderItem().getItem().getItemCode());
	 				semifinishedStockOutDTO.setItemId(semifinishedStockOutList.get(0).getSalesOrderItem().getItem().getItemId());
	 				semifinishedStockOutDTO.setStoreId(semifinishedStockOutList.get(0).getStore().getStoreId());
	 				semifinishedStockOutDTO.setStockOutQty(semifinishedStockOutList.get(0).getStockOutQty());
	 				semifinishedStockOutDTO.setWeight(semifinishedStockOutList.get(0).getWeight());
	 				semifinishedStockOutDTO.setBundleId(semifinishedStockOutList.get(0).getBundleId());
	 				semifinishedStockOutDTO.setSupervisor(supervisor);
	 				semifinishedStockOutDTO.setConfirmStatus("Yes");
	 				semifinishedStockOutDTO.setQcStatus(semifinishedStockOutList.get(0).getQcStatus());
	 				semifinishedStockOutDTO.setQcSupervisor(semifinishedStockOutList.get(0).getQcSupervisor());
	 			
	 				SemifinishedStockOut semifinishedStockOut=semifinishedStockOutDTO.getSemifinishedStockOut();
	 				SemifinishedStockOut createdSemiFinishedStockOut=semifinishedStockOutService.create(semifinishedStockOut);//create semifinished stock out entry
	 				if(createdSemiFinishedStockOut!=null)
	 	 					result = storeRegisterService.delete(storeRegList.get(0).getStoreRegisterId());//delete store register entry after stock out
	 		        if(result==true)
	 				statusMssgList.add("Valid");//add status mssg to list
	 		        else
	 		         statusMssgList.add("Invalid");//add status mssg to list
	 		        
	 			}//end of 	if(semifinishedStockOutList.size()>0 && stockValid==true && storeRegList.size()>0)loop
	 			else{
	 				  statusMssgList.add("Invalid");//add status mssg to list
	 			}//en dof else loop
	 		}
	 	}//end of outer if loop
		return statusMssgList;
	}

	
	 /**
	   * Confirm Barcode stock Out of semifinished goods
	   * @param barCode,process,work order no
	   * @return List<String>  status message
	   */
	@RequestMapping(value = "/barCodeStockOutScan", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	List<String> barCodeStockOutScan(
			@RequestParam(value = "barCode", required = true)String barCode,
			@RequestParam(value = "process", required = false)String process,
			@RequestParam(value = "workOrderNo", required = false)String workOrderNo){
		Boolean result=false;
		List<String>statusMssgList=new ArrayList<>();

		if(barCode!=null){
			//fetch loged in user
		CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();;
	 	String supervisor = user.getFirstName()+" "+user.getLastName();
	 	Boolean stockValid=false;
	    String itemCode=barCode.substring(0, 23);//get item code from barcode value
	    String soNo = barCode.substring(23, 31);//get sales order from barcode value
	    String woNo = barCode.substring(31, 39);//get work order from barcode value
	    String bundleId = barCode.substring(39, 42);//get bundle id from barcode value
		List<ProductionWorkOrder>pdnWorkOrderList=null;
 	 if(workOrderNo!=null && workOrderNo!="")
 		pdnWorkOrderList=productionWorkOrderService.findByProductionWorkOrderNo(workOrderNo);//fetch production work order list by work order no
	 	String processType = null;
	 	if(pdnWorkOrderList.size()>0)
	 		processType=pdnWorkOrderList.get(0).getProcess().getProcessType();
	 
		List<Item>itemList=itemService.findByItemCode(itemCode);//fetch item amster record based on item code
	    //Assign processtype based on item type scanned
		if(itemList.size()>0){
			String itemType=itemList.get(0).getItemType();
			if(processType.equalsIgnoreCase("Bunching") && itemType.equalsIgnoreCase("Multiwire"))
 				stockValid=true;
 			else if(processType.equalsIgnoreCase("Extrusion") && itemType.equalsIgnoreCase("Bunching") )
 				stockValid=true;
 			else
 				stockValid=false;
 		String confirmStatus="No";
    			
 		        //fetch store register record based on ordr id,item code,bundle id and work order no
 		        List<StoreRegister>storeRegList=storeRegisterService.findByOrderIdAndItemCodeAndBundleIdAndWorkOrderNo(soNo, itemCode, bundleId, woNo);
 		        //fetch SemifinishedStockOut record based on ordr id,item code,bundle id ,confirm sattus("no")and work order no
 		        List<SemifinishedStockOut>semiFinishedStockList=semifinishedStockOutService.findByOrderIdAndItemCodeAndBundleIdAndWorkOrderAndConfirmStatus(soNo, itemCode, bundleId, woNo,confirmStatus);
    			if(storeRegList.size()>0 && stockValid==true && semiFinishedStockList.size()==0){
					SemifinishedStockOutDTO  semifinishedStockOutDTO=new SemifinishedStockOutDTO();
	 				semifinishedStockOutDTO.setStockedOutFor(workOrderNo);
	 				semifinishedStockOutDTO.setWorkOrderNo(storeRegList.get(0).getProductionWorkOrder().getWorkOrderNo());
	 				semifinishedStockOutDTO.setOrderDetailId(storeRegList.get(0).getSalesOrderItem().getOrderDetailId());
	 				semifinishedStockOutDTO.setOrderId(storeRegList.get(0).getSalesOrderItem().getOrder().getOrderId());
	 				semifinishedStockOutDTO.setItemCode(storeRegList.get(0).getSalesOrderItem().getItem().getItemCode());
	 				semifinishedStockOutDTO.setItemId(storeRegList.get(0).getSalesOrderItem().getItem().getItemId());
	 				semifinishedStockOutDTO.setStoreId(storeRegList.get(0).getStore().getStoreId());
	 				semifinishedStockOutDTO.setStockOutQty(storeRegList.get(0).getStockQty());
	 				semifinishedStockOutDTO.setWeight(storeRegList.get(0).getWeight());
	 				semifinishedStockOutDTO.setBundleId(storeRegList.get(0).getBundleId());
	 				semifinishedStockOutDTO.setSupervisor(supervisor);
	 				semifinishedStockOutDTO.setConfirmStatus("No");
	 				semifinishedStockOutDTO.setQcStatus(storeRegList.get(0).getQcStatus());
	 				semifinishedStockOutDTO.setQcSupervisor(storeRegList.get(0).getQcSupervisor());
	 		
	 				SemifinishedStockOut semifinishedStockOut=semifinishedStockOutDTO.getSemifinishedStockOut();
	 				SemifinishedStockOut createdSemiFinishedStockOut=semifinishedStockOutService.create(semifinishedStockOut);//create semifinished stock out entry
					if(createdSemiFinishedStockOut!=null)
						result=true;
					if(result==true)
						statusMssgList.add("Valid");//add status message to list
					else
						statusMssgList.add("Invalid");//add status message to list	
	 		   }//end of if(storeRegList.size()>0 && stockValid==true && semiFinishedStockList.size()==0)loop
    			else if(semiFinishedStockList.size()>0){
	 			  statusMssgList.add("Exist");//add status message to list
	 		   }//end of else if loop
	 		  else	statusMssgList.add("Invalid");//add status message to list
		

			}
		}//end of if loop
           return statusMssgList;
	}
	
	
	 /**
	   * delete semifinished stock selected for stock out
	   * @param SemifinishedStockOutId
	   * @return StatusResponse
	   */
	@RequestMapping(value = "/delete", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	StatusResponse delete(@RequestParam(value = "id", required = true) Long id){
		Boolean semifinishedStockOutResult=false;
		//fetch semifinished stock based on id
		List<SemifinishedStockOut>semifinishedStockOutList=semifinishedStockOutService.findBySemifinishedStockOutId(id);
         if(semifinishedStockOutList.size()>0){
        	 if(semifinishedStockOutList.get(0).getConfirmStatus()!=null){
        	 if(semifinishedStockOutList.get(0).getConfirmStatus().equalsIgnoreCase("No")){
        		 semifinishedStockOutResult=semifinishedStockOutService.delete(id);
        	 }//end of  if(semifinishedStockOutList.get(0).getConfirmStatus().equalsIgnoreCase("No"))
        	 if(semifinishedStockOutList.get(0).getConfirmStatus().equalsIgnoreCase("Yes")){
        		 Boolean storeCreate=false;
        		List<StoreRegister>storeRegList=storeRegisterService.
        				findByOrderDetailIdAndBundleIdAndWorkOrderNo(semifinishedStockOutList.get(0).getSalesOrderItem().getOrderDetailId(),
        						semifinishedStockOutList.get(0).getBundleId(), semifinishedStockOutList.get(0).getProductionWorkOrders().getWorkOrderNo());
        	   if(!(storeRegList.size()>0)){
        		StoreRegisterDTO storeRegDTO=new StoreRegisterDTO();
  			   storeRegDTO.setItemCode(semifinishedStockOutList.get(0).getSalesOrderItem().getItem().getItemCode());
  			   storeRegDTO.setStoreId(semifinishedStockOutList.get(0).getStore().getStoreId());
  			   storeRegDTO.setWorkOrderNo(semifinishedStockOutList.get(0).getProductionWorkOrders().getWorkOrderNo());
  			   storeRegDTO.setCustomerName(semifinishedStockOutList.get(0).getSalesOrderItem().getOrder().getCustomer().getCustomerName());
  			   storeRegDTO.setStockQty(semifinishedStockOutList.get(0).getStockOutQty());
  			   storeRegDTO.setBundleId(semifinishedStockOutList.get(0).getBundleId());
  			   storeRegDTO.setOrderId(semifinishedStockOutList.get(0).getOrderId());
  			   storeRegDTO.setOrderDetailId(semifinishedStockOutList.get(0).getSalesOrderItem().getOrderDetailId());
  			   storeRegDTO.setItemId(semifinishedStockOutList.get(0).getSalesOrderItem().getItem().getItemId());
  			   storeRegDTO.setPackingSlipNo(null);
  			   storeRegDTO.setSupervisor(semifinishedStockOutList.get(0).getSupervisor());
  			   storeRegDTO.setWeight(semifinishedStockOutList.get(0).getWeight());
  			   storeRegDTO.setQcStatus(semifinishedStockOutList.get(0).getQcStatus());
  			   storeRegDTO.setQcSupervisor(semifinishedStockOutList.get(0).getQcSupervisor());
  			   storeRegDTO.setRejectStatus(null);
  			   storeRegDTO.setBagWeight(null);
  			   StoreRegister storeReg=storeRegDTO.getStoreRegister();
  			   StoreRegister craetedStoreReg=storeRegisterService.create(storeReg);//create store register entry 
        	   if(craetedStoreReg!=null)
        		   storeCreate=true;
        	   }else
        		   storeCreate=true; 
  			   if(id!=null && storeCreate==true)
  				 semifinishedStockOutResult=semifinishedStockOutService.delete(id);//delete semifinished stock out entry
  	          }//end of  if(semifinishedStockOutList.get(0).getConfirmStatus().equalsIgnoreCase("Yes"))loop
        	 }//end of  if(semifinishedStockOutList.get(0).getConfirmStatus()!=null)loop
         }//end of   if(semifinishedStockOutList.size()>0)loop
         return new StatusResponse(semifinishedStockOutResult);
	
}	

}