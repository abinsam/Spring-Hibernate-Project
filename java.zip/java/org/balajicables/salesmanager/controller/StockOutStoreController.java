package org.balajicables.salesmanager.controller;

import java.util.List;

import javax.annotation.Resource;

import org.balajicables.salesmanager.model.StoreRegister;
import org.balajicables.salesmanager.service.StoreRegisterService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
/**
* This class demonstrates Stock Out Module
* @author Abin Sam
*/
@Controller
@RequestMapping("/stockOutFromStore")

public class StockOutStoreController {

	@Resource
	private StoreRegisterService storeRegisterService;
	
	 /**
	   * This method returns stockOutStore.jsp.
	   * Fetch Work order no,Item code,stockQty,Order Id,Customer Name,item description,bundle id and weight for store register 
	   *        item selected for stock out
	   * @param StoreRegister Id
	   * @return stockOutStore.jsp.
	   */
	@RequestMapping(method = RequestMethod.GET)
	public String getStockOut(Model model,
	   		 @RequestParam(value="id") Long id)
	{
		List<StoreRegister> storeRegList=storeRegisterService.findById(id);
		if(storeRegList.size()>0){
		model.addAttribute("woNo",storeRegList.get(0).getProductionWorkOrder().getWorkOrderNo());//set work order no to model attribute
		model.addAttribute("itemCode",storeRegList.get(0).getSalesOrderItem().getItem().getItemCode());//set item code to model attribute
		model.addAttribute("stockQty",storeRegList.get(0).getStockQty());//set stock qty to model attribute
		model.addAttribute("orderId",storeRegList.get(0).getSalesOrderItem().getOrder().getOrderId());//set order id to model attribute
		model.addAttribute("customerName",storeRegList.get(0).getSalesOrderItem().getOrder().getCustomer().getCustomerName());//set customer name to model attribute
		model.addAttribute("itemDescription",storeRegList.get(0).getSalesOrderItem().getItem().getItemDescription());//setitem description to model attribute
		model.addAttribute("bundleId",storeRegList.get(0).getBundleId());//set bundfle id to model attribute
		model.addAttribute("weight",storeRegList.get(0).getWeight());//set weight to model attribute
		}//end of if loop
		return "stockOutStore";
	}
	
}

	
	

