package org.balajicables.salesmanager.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.annotation.Resource;
import org.balajicables.salesmanager.CustomUser;
import org.balajicables.salesmanager.common.JqgridFilter;
import org.balajicables.salesmanager.common.JqgridObjectMapper;
import org.balajicables.salesmanager.common.JqgridResponse;
import org.balajicables.salesmanager.common.StatusResponse;
import org.balajicables.salesmanager.common.StoreRegisterMapper;
import org.balajicables.salesmanager.dto.SalesOrderItemsDTO;
import org.balajicables.salesmanager.dto.StockInDTO;
import org.balajicables.salesmanager.dto.StoreRegisterDTO;
import org.balajicables.salesmanager.dto.WorkOrderItemsDTO;
import org.balajicables.salesmanager.dto.WorkOrderOutputDTO;
import org.balajicables.salesmanager.model.Customer;
import org.balajicables.salesmanager.model.LabelReport;
import org.balajicables.salesmanager.model.ProductionProcess;
import org.balajicables.salesmanager.model.SalesOrder;
import org.balajicables.salesmanager.model.SalesOrderItem;
import org.balajicables.salesmanager.model.StockIn;
import org.balajicables.salesmanager.model.StoreRegister;
import org.balajicables.salesmanager.model.WorkOrderItems;
import org.balajicables.salesmanager.model.WorkOrderOutput;
import org.balajicables.salesmanager.repository.ProductionProcessRepository;
import org.balajicables.salesmanager.service.CustomerService;
import org.balajicables.salesmanager.service.ItemService;
import org.balajicables.salesmanager.service.LabelReportService;
import org.balajicables.salesmanager.service.OrderDetailsService;
import org.balajicables.salesmanager.service.OrderService;
import org.balajicables.salesmanager.service.StockInService;
import org.balajicables.salesmanager.service.StoreRegisterService;
import org.balajicables.salesmanager.service.WorkOrderItemService;
import org.balajicables.salesmanager.service.WorkOrderOutputService;
import org.springframework.data.domain.Page;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
/**
* This class demonstrates Store Register Module
* @author Abin Sam
*/
@Controller
@RequestMapping("/storeRegister")
public class StoreRegisterController {

	@Resource
	private OrderDetailsService orderDetailsService;

	@Resource
	private ProductionProcessRepository productionProcessRepository;
	
	@Resource
	private WorkOrderOutputService workOrderOutputService;
	
	@Resource
	private StockInService stockInService;
	
	@Resource
	private WorkOrderItemService workOrderItemService;
	
	@Resource
	private ItemService itemService;
	
	@Resource
	private OrderService orderService;
	
	@Resource
	private CustomerService customerService;
	
	@Resource
	private StoreRegisterService storeRegisterService;

	@Resource
	private LabelReportService labelReportService;

	
	 /**
	   * This method returns storeRegister.jsp.
	   * Fetch all salesOrders,work order process,customers,colors,copperDiameters,
	   *       productTypes,cableStdPvcs
	   * @param Model to set the attribute.
	   * @return storeRegister.jsp.
	   */
	@RequestMapping(method = RequestMethod.GET)
	public String getSalesOrdersPage(Model model) {
    	ArrayList<String> salesOrders = new ArrayList<>();
		ArrayList<String> custList = new ArrayList<>();

    	//Method to fetch store register List
		List<StoreRegister>storeRegList=storeRegisterService.findAll();
		for (int iterator = 0; iterator < storeRegList.size(); iterator++) {
			String soNo = storeRegList.get(iterator).getOrderId();
         	String customerName = storeRegList.get(iterator).getSalesOrderItem().getOrder().getCustomer().getCustomerName();
    	if (!salesOrders.contains(soNo)) {
				salesOrders.add(soNo);
			}//end of if (!salesOrders.contains(soNo)) loop
         	if (!custList.contains(customerName)) {
         		custList.add(customerName);
			}//end of if (!salesOrders.contains(soNo)) loop
	
		}//end of for loop
		Collections.sort(salesOrders,Collections.reverseOrder());//sort sales order in reverse order
		model.addAttribute("orderIds",salesOrders);//set sales order to model attribute
		Collections.sort(custList);//sort sales order in reverse order
		model.addAttribute("customers",custList);//set customers to model attribute
		model.addAttribute("colours", itemService.getAllColours());//set colours to model attribute
		model.addAttribute("copperDiameters", itemService.getAllCopperDiameters());//set copperDiameters to model attribute
		model.addAttribute("productTypes", itemService.getAllProductTypes());//set productTypes to model attribute
		model.addAttribute("cableStdPvcs", itemService.getAllCableStdPvcs());//set cableStdPvcs to model attribute
		model.addAttribute("customersList", customerService.findAll());//set customer to model attribute
	
		List<ProductionProcess> pdnProcessList = productionProcessRepository.findAll();//fetch production process list
		if (pdnProcessList.size() > 0) {
			for (int i = 0; i < pdnProcessList.size(); i++) {
				if (pdnProcessList.get(i).getProcessType().equalsIgnoreCase("RBD"))
					pdnProcessList.remove(pdnProcessList.get(i));//remove rbd work order nos from list
			}//end of for loop
		}//end of if (pdnProcessList.size() > 0) loop
		model.addAttribute("processes", pdnProcessList);
	
		return "storeRegister";
	}
	 /**
	   * This method returns work order nos list based on process type selected
	   * Fetch all work order nos for select box
	   * @param processType,Model to set the attribute.
	   * @return List<String>WorkOrderNosList
	   */
	@RequestMapping(value = "/getWorkOrders", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	List<String> getWODetails( @RequestParam(value = "processType", required = true) String processType,Model model) {
		List<StoreRegister> storeWorkOrders = storeRegisterService.findByProductionWorkOrderProcess(processType);
		ArrayList<String> pdnWoValuesList = new ArrayList<>();
		
		for(int iterator=0; iterator < storeWorkOrders.size();iterator++){
			String woNo= storeWorkOrders.get(iterator).getProductionWorkOrder().getWorkOrderNo();
			if (!pdnWoValuesList.contains(woNo)) {
			pdnWoValuesList.add(woNo);
			}
			Collections.sort(pdnWoValuesList,Collections.reverseOrder());//sort production work order list in descending order
		}//end of for loop
		return pdnWoValuesList;
	}
	 /**
	   * This method returns item code list from store register
	   * Fetch all item code nos for select box
	   * @param Model to set the attribute.
	   * @return List<String>itemCodeList
	   */
	@RequestMapping(value = "/fetchStoreItems", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	List<String> fetchStoreItems(Model model) {
		//Method to fetch store register list
		List<StoreRegister>storeRegList=storeRegisterService.findAll();
		List<String>itemCodeList=new ArrayList<>();
		if(storeRegList.size()>0){
			for (int iterator = 0; iterator < storeRegList.size(); iterator++) {
				String itemCode= storeRegList.get(iterator).getItemCode();//get item code
				if (!itemCodeList.contains(itemCode)) {
					itemCodeList.add(itemCode);
				}//end of if (!itemCodeList.contains(itemCode)) loop
		   }//end of for loop
	   }// end of if loop

		return itemCodeList;
	}
	 /**
	   * This method returns sales order list from store register
	   * Fetch all sales order nos for select box
	   * @param Model to set the attribute.
	   * @return List<String>salesOrderList
	   */
	@RequestMapping(value = "/fetchSalesOrders", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	ArrayList<String> getWorkOrderNos() {
		ArrayList<String> salesOrders = new ArrayList<>();
		//Method to fetch sales orders from store register
		List<SalesOrder> salesOrdersList = orderService.findAll();
		
		for (int iterator = 0; iterator < salesOrdersList.size(); iterator++) {
			if(salesOrdersList.get(iterator).getOrderId()!=null && salesOrdersList.get(iterator).getOrderId()!=""){
			String salesOrderNo = salesOrdersList.get(iterator).getOrderId();
			if (!salesOrders.contains(salesOrderNo)) {
				salesOrders.add(salesOrderNo);
			}//end of if (!salesOrders.contains(salesOrderNo))  loop
		  }//end of outer if loop
			Collections.sort(salesOrders,Collections.reverseOrder());//sort sales order in descending order
		}//end of for loop

		return salesOrders;
	}
	 /**
	   * This method returns sales order List  from store register based on customer selected
	   * Fetch  sales order no list for select box
	   * @param customerId, Model to set the attribute.
	   * @return List<String>salesOrderList
	   */
	@RequestMapping(value = "/getSalesOrders", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	ArrayList<String> getSalesOrders(
			 @RequestParam(value = "customerId", required = true) String customerId, Model model) {
		//fetch store register lsit based on customer name
		List<StoreRegister> salesOrdersList = storeRegisterService.findBySalesOrderItemOrdersCustomerCustomerName(customerId);
		ArrayList<String> salesOrders = new ArrayList<>();
		for (int iterator = 0; iterator < salesOrdersList.size(); iterator++) {
			String soNo = salesOrdersList.get(iterator).getOrderId();
    		if (!salesOrders.contains(soNo)) {
				salesOrders.add(soNo);
			}//end of if (!salesOrders.contains(soNo)) loop
			Collections.sort(salesOrders,Collections.reverseOrder());//sort sales order in descending order
		}//end of for loop

		return salesOrders;
	}
	 /**
	   * This method fetch Store register based on search parameters for grid
	   * Fetch  Store register for grid
	   * @param search,filters,pageNumber,rowsPerPage,sortColName,sortOrder
	   * @return JqgridResponse<StoreRegisterDTO>response
	   */
	@RequestMapping(value="/records", produces="application/json", method=RequestMethod.POST)
	public @ResponseBody
	JqgridResponse<StoreRegisterDTO> records(
			@RequestParam(value="searchObject", required=false) String searchObject,
			@RequestParam("_search") Boolean search,
    		@RequestParam(value="filters", required=false) String filters,
			@RequestParam(value = "page", required = false) Integer pageNumber,
			@RequestParam(value = "rows", required = false) Integer rowsPerPage,
			@RequestParam(value = "sidx", required = false) String sortColName,
			@RequestParam(value = "sord", required = false, defaultValue = "asc") String sortOrder) {
		//set sort column name based grid sortcolname parameter
		if(sortColName.equalsIgnoreCase("itemDescription")){
			sortColName="salesOrderItem.items.itemDescription";
		}
		if(sortColName.equalsIgnoreCase("status")){
			sortColName="salesOrderItem.orders.orderStatus.status";
		}
		
		if(sortColName.equalsIgnoreCase("customerCode")){
			sortColName="salesOrderItem.orders.customer.customerCode";
		}
		
		if(sortColName.equalsIgnoreCase("itemCode")){
			sortColName="salesOrderItem.items.itemCode";
		}
		if(sortColName.equalsIgnoreCase("workOrderNo")){
			sortColName="productionWorkOrder.workOrderNo";
		}
		
		if (searchObject != null && !(searchObject.equalsIgnoreCase("allSearch"))) {
			//method to fetch store register by default search parameters
	           return getFilteredRecords(searchObject, pageNumber-1,rowsPerPage,sortColName,sortOrder);
	   } //end of if loop
		else{
			//method to fetch store register based on QC status    	
			Page<StoreRegister>storeRegItem=  storeRegisterService.fetchByQcStatusNotIn("Rejected",pageNumber - 1,
						                                        rowsPerPage, sortColName, sortOrder);
			/*Intialize JQ grid response of type StoreRegisterDTO */
			JqgridResponse<StoreRegisterDTO> response = new JqgridResponse<StoreRegisterDTO>();
			/*Method to set StoreRegister item list to StoreRegisterDTO*/
			List<StoreRegisterDTO> storeRegsiterDTOs = convertToStoreRegItemDTO(storeRegItem.getContent());
			response.setRows(storeRegsiterDTOs);
			response.setRecords(Long.valueOf(storeRegItem.getTotalElements()).toString());
		    response.setTotal(Long.valueOf(storeRegItem.getTotalPages()).toString());
			response.setPage(Integer.valueOf(storeRegItem.getNumber()+1).toString());
			return response;
      }//end of else loop
	}
    /**
	   * This method to set store regsiter item to StoreRegisterDTO
	   * @param StoreRegister
	   * @return List<StoreRegisterDTO>
	   */
	private List<StoreRegisterDTO> convertToStoreRegItemDTO(
			List<StoreRegister> storeRegItems) {
		List<StoreRegisterDTO> storeRegisterDTOs = new ArrayList<>();
		for(StoreRegister storeRegister : storeRegItems) {
			StoreRegisterDTO dto = new StoreRegisterDTO();
			dto.setStoreRegisterId(storeRegister.getStoreRegisterId());
			dto.setStoreId(storeRegister.getStore().getStoreId());
			dto.setStoreAddress(storeRegister.getStore().getStoreAddress());
			dto.setItemId(storeRegister.getSalesOrderItem().getItem().getItemId());
			dto.setItemCode(storeRegister.getSalesOrderItem().getItem().getItemCode());
			dto.setOrderId(storeRegister.getSalesOrderItem().getOrder().getOrderId());
			dto.setWorkOrderNo(storeRegister.getProductionWorkOrder().getWorkOrderNo());
			dto.setStockQty(storeRegister.getStockQty());
			dto.setOrderDetailId(storeRegister.getSalesOrderItem().getOrderDetailId());
			dto.setCustomerName(storeRegister.getSalesOrderItem().getOrder().getCustomer().getCustomerName());
			dto.setCustomerCode(storeRegister.getSalesOrderItem().getOrder().getCustomer().getCustomerCode());
			dto.setCustomerId(storeRegister.getSalesOrderItem().getOrder().getCustomer().getCustomerId());
		    dto.setItemDescription(storeRegister.getSalesOrderItem().getItem().getItemDescription());
		    dto.setUnits(storeRegister.getSalesOrderItem().getItem().getUnit().getUnits());
		    dto.setBundleId(storeRegister.getBundleId());
		    dto.setWeight(storeRegister.getWeight());
		    dto.setPackingSlipNo(storeRegister.getPackingSlipNo());
		    dto.setBagWeight(storeRegister.getBagWeight());
		    dto.setStatus(storeRegister.getSalesOrderItem().getOrder().getOrderStatus().getStatus());
		    dto.setQcStatus(storeRegister.getQcStatus());
		    dto.setQcSupervisor(storeRegister.getQcSupervisor());
	        storeRegisterDTOs.add(dto);
			}//end of for loop
		return storeRegisterDTOs;
	
	}
	 /**
	   * This method to fetch store regsiter item based on search parameter and set response to JQGRID
	   * Fetch store Regsiter item details for grid
	   * @param filters,pageNumber,rowsPerPage,sortColName,sortOrder
	   * @return JqgridResponse<StoreRegisterDTO> response
	   */
	private JqgridResponse<StoreRegisterDTO> getFilteredRecords(
			String filters, int pagenumber, Integer rows,
			String sortColName, String sortOrder) {
		    
		    String qOrderId = null;
		    String qCustomerName=null;
	        String qItemCode=null; 
	        Integer qNumberOfCopperStrands=0;
	        String qCopperKey = null;
	        String qOuterDiameter = null;
	        String qMainColour = null;
	        String qInnerColor = null;
	        String qCableStdKey = null;
	        String qLayLength = null;
	        String qLayType = null;
	        String qProductKey = null;
	        String qWorkOrderNo=null;
	        //JQ Grid filtering parameters
	      	JqgridFilter jqgridFilter = JqgridObjectMapper.map(filters);
	        for (JqgridFilter.Rule rule: jqgridFilter.getRules()) {
	                if (rule.getField().equals("orderId"))
	                	   qOrderId = rule.getData();
	                else if (rule.getField().equals("itemCode"))
	             	   qItemCode = rule.getData();
	                else if (rule.getField().equals("workOrderNo"))
	                	qWorkOrderNo = rule.getData();
	                else if (rule.getField().equals("customerName"))
	                	qCustomerName =rule.getData() ; 
                    else if (rule.getField().equals("numberOfCopperStrands")){
	             	  if(rule.getData()=="" || rule.getData()==null)
	             		  qNumberOfCopperStrands =0;
	             		  else
	             	   qNumberOfCopperStrands =Integer.parseInt(rule.getData()) ;
	                }
	                else if (rule.getField().equals("copperkey"))
	                 	qCopperKey =rule.getData() ; 
	                else if (rule.getField().equals("outerDiameter"))
	          	      qOuterDiameter =rule.getData() ; 
	                else if (rule.getField().equals("mainColour"))
	             	   qMainColour =rule.getData() ; 
	                else if (rule.getField().equals("innerColor"))
	              	   qInnerColor =rule.getData() ; 
	                else if (rule.getField().equals("cableStdKey"))
	              	   qCableStdKey =rule.getData() ; 
	                else if (rule.getField().equals("layLength"))
	              	   qLayLength =rule.getData() ; 
	                else if (rule.getField().equals("layType"))
	              	   qLayType =rule.getData() ; 
	                else if (rule.getField().equals("productKey"))
	              	   qProductKey =rule.getData() ;
	         }//end of for loop
	        /*Method to fetch StoreRegister items based on filtering params*/
	        List<StoreRegister>storeRegItem=
	           storeRegisterService.fetchByRejectStatusSearch
	        		(qOrderId,qWorkOrderNo, qCustomerName,qItemCode,
	        		qNumberOfCopperStrands,qCopperKey,qOuterDiameter,qMainColour,qInnerColor,
	                qCableStdKey,qLayLength,qLayType,qProductKey,pagenumber,rows,sortColName,sortOrder);
	   
	        List<StoreRegister> pagedList;
	        int fromIndex = Math.min(storeRegItem.size(), pagenumber * rows);//start index of response set to JQ Grid
	        int toIndex = Math.min(storeRegItem.size(), fromIndex + rows);//end index of response set to JQ Grid
	        
	        if (fromIndex == 0 && toIndex == (storeRegItem.size() - 1)){
	            pagedList = storeRegItem;
	        }//end of if loop
	        else{
	           pagedList = storeRegItem.subList(fromIndex, toIndex);
	        }//end of else loop
	        /*Set paged store regsiter response to StoreRegisterDTO*/
	    	List<StoreRegisterDTO> storeRegisterDto = StoreRegisterMapper.map(pagedList);
	    	/*Intialize JQ grid response of type StoreRegisterDTO*/
	        JqgridResponse<StoreRegisterDTO> response = new JqgridResponse<StoreRegisterDTO>();
	        
	        response.setRows(storeRegisterDto);
	        response.setRecords(Long.valueOf(storeRegItem.size()).toString());
	        if(storeRegItem.size()>0)
	        response.setTotal(Integer.valueOf((int)Math.ceil(Double.valueOf(storeRegItem.size())/Double.valueOf(rows.toString()))).toString());
	       else
	       response.setTotal("0");
	       response.setPage(Integer.valueOf(pagenumber+1).toString());
	       return response;
	       
				
	}	
	 /**
	   * Crud functionality of StoreRegister
	   * @param StoreRegisterid,oper,itemCode,workOrderNo,customerName,stockQty,bundleId,orderId,orderDetailId,
			   itemId,supervisor,packingSlipNo,weight
	   * @return List<StoreRegisterDTO>
	   */
	@RequestMapping(value = "/crud", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	StatusResponse crud(@RequestParam Long id,
			@RequestParam String oper,
			@RequestParam(required = false) String itemCode,
			@RequestParam(required = false) String workOrderNo,
			@RequestParam(required = false) String customerName,
			@RequestParam(required = false) Double stockQty,
			@RequestParam(required = false) String bundleId,
			@RequestParam(required = false) String orderId,
			@RequestParam(required = false) Long orderDetailId,
			@RequestParam(required = false) Long itemId,
			@RequestParam(required = false) String supervisor,
			@RequestParam(required = false) Long packingSlipNo,
			@RequestParam(required = false) Double weight
		
			
			) {
	  Boolean result = false;
      StoreRegisterDTO storeRegDTO=new StoreRegisterDTO();
      storeRegDTO.setStoreRegisterId(id);
      storeRegDTO.setStoreId(1);
      storeRegDTO.setItemCode(itemCode);
      storeRegDTO.setWorkOrderNo(workOrderNo);
      storeRegDTO.setCustomerName(customerName);
      storeRegDTO.setStockQty(stockQty);
      storeRegDTO.setBundleId(bundleId);
      storeRegDTO.setOrderId(orderId);
      storeRegDTO.setOrderDetailId(orderDetailId);
      storeRegDTO.setItemId(itemId);
      storeRegDTO.setPackingSlipNo(packingSlipNo);
      storeRegDTO.setSupervisor(supervisor);
      storeRegDTO.setWeight(weight);
      
      StoreRegister storeReg=storeRegDTO.getStoreRegister();

      result = storeRegisterService.update(storeReg);//create store register entry
      return new StatusResponse(result);

	}	
	 /**
	   * fetch sales order from store register
	   * @param storeRegId,customerId
	   * @return List<String>SalesOrderList
	   */
	@RequestMapping(value = "/fetchSalesOrder", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	List<String> fetchSalesOrder(
			 @RequestParam(value = "storeRegId", required = true) Long storeRegId,
			 @RequestParam(value = "customerId", required = true) Long customerId) {
	    List<Customer>customerList=customerService.findById(customerId);
	    ArrayList<String> soNoList = new ArrayList<>();
	    if(customerList.size()>0){
	    	if(customerList.get(0).getCustomerId()==1){
	    		soNoList.add("BS000001");
	    	}//end of if loop
	    	else{
	    		//Method to fetch store register based on id
	    		List<StoreRegister>storeRegList=storeRegisterService.findById(storeRegId);
	    		if(storeRegList.size()>0){
	    			String itemCode=storeRegList.get(0).getSalesOrderItem().getItem().getItemCode();
	    			List<SalesOrderItem> soItemList=orderDetailsService.findByItemCodeAndCustomerId(itemCode,customerId);
	               if(soItemList.size()>0){
	       			for (int iterator = 0; iterator < soItemList.size(); iterator++) {
	    				String soNo = soItemList.get(iterator).getOrder().getOrderId();
	                    Double stockInQuantity=soItemList.get(iterator).getCompletedQty();
	                    Double orderedQty=soItemList.get(iterator).getQuantity();
	                    String orderStatus=soItemList.get(iterator).getOrder().getOrderStatus().getStatus();
	                    if(orderStatus.equalsIgnoreCase("Approved") || orderStatus.equalsIgnoreCase("Approved For Prodn")){
	    					//change so status to completed even if 96% of stock is done
	                    	if(!(stockInQuantity>= (96*orderedQty)/100)){
	                    	if (!soNoList.contains(soNo)) {
	        					soNoList.add(soNo);
	        				}//end of if (!soNoList.contains(soNo))  loop
	                    }//end of if(!(stockInQuantity>= (96*orderedQty)/100)) loop
	                    }//end of if loop
	    			} 
	               }//end of   if(soItemList.size()>0) loop
	    		}//end of if(storeRegList.size()>0) loop
	    	}//end of else loop
	    	
	    }
		 return soNoList;
	}	
	 /**
	   * Change label of store regsiter item to item of approved sales order which has same item and is not completed
	   * @param storeRegId,new sales order no
	   * @return StatusResponse
	   */
	@RequestMapping(value = "/changeLabel", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	StatusResponse changeLabel(
	       	 @RequestParam(value = "storeRegId", required = false) Long storeRegId,
	    	 @RequestParam(value = "newSoNo", required = false) String newSoNo) {
	
		 Boolean updateNewStoreReg=false;

    	if(storeRegId!=null && newSoNo!=null){
    		//fetch logged in user
    	CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();;
	 	String userName = user.getFirstName()+" "+user.getLastName();
	
	 	Long oldSalesOrderItemId=null;
		Long newSalesOrderItemId=null;
		String newCustomerName=null;
		 String oldWoNo=null;
		 String newSalesOrderNo=null;
	    Double newSalesOrderOrderedQty=0.0;
		Boolean updateWoItems=false;
		Boolean updateNewStockIn=false;
		//method to fetch store register by id
		List<StoreRegister>storeRegList=storeRegisterService.findById(storeRegId);
		if(storeRegList.size()>0){
			String itemType=storeRegList.get(0).getSalesOrderItem().getItem().getItemType();
			String itemCode=storeRegList.get(0).getSalesOrderItem().getItem().getItemCode();
			String oldSoNo=storeRegList.get(0).getSalesOrderItem().getOrder().getOrderId();
		     oldWoNo=storeRegList.get(0).getProductionWorkOrder().getWorkOrderNo();
		//method to fetch details of existing store item selected for label change
		List<SalesOrderItem> oldSoItemList=orderDetailsService.findByOrdersOrderIdItemsItemCode(oldSoNo, itemCode);
		//method to fetch details of new sales order
		List<SalesOrderItem> newSoItemList=orderDetailsService.findByOrdersOrderIdItemsItemCode(newSoNo, itemCode);
		List<WorkOrderItems> woNewCustomerListExist=null;
		List<WorkOrderItems> woItemList=null;
        List<WorkOrderOutput>woOutputList=null;
		if(oldSoItemList.size()>0){
			oldSalesOrderItemId=oldSoItemList.get(0).getOrderDetailId();
		
 		}//end of if(oldSoItemList.size()>0) loop
		List<SalesOrderItem>newSoItemDetailsList=null;

		if(newSoItemList.size()>0){
			//details of new sales order no
			newSalesOrderItemId=newSoItemList.get(0).getOrderDetailId();
			newSalesOrderNo=newSoItemList.get(0).getOrder().getOrderId();
			newSalesOrderOrderedQty=newSoItemList.get(0).getQuantity();
			newCustomerName=newSoItemList.get(0).getOrder().getCustomer().getCustomerName();
			newSoItemDetailsList=orderDetailsService.findById(newSalesOrderItemId);
		}//end of if(newSoItemList.size()>0) loop
	
		if(oldSalesOrderItemId!=null && oldWoNo!=null){
			//check item type to select work order output records
			if(itemType.equalsIgnoreCase("Bunching") || itemType.equalsIgnoreCase("Multiwire") || itemType.equalsIgnoreCase("Raw")){
				woOutputList=workOrderOutputService.findBySoItemIdAndWorkOrderNo(oldSalesOrderItemId, oldWoNo);
			if(woOutputList.size()>0){
			WorkOrderOutputDTO workOrderOutputDTO=new WorkOrderOutputDTO();
			workOrderOutputDTO.setWoOutPutId(woOutputList.get(0).getWoOutPutId());
			workOrderOutputDTO.setWorkOrderNo(woOutputList.get(0).getProductionWorkOrder().getWorkOrderNo());
			workOrderOutputDTO.setNetLength(woOutputList.get(0).getNetLength());
			workOrderOutputDTO.setGrossWeight(woOutputList.get(0).getGrossWeight());
			workOrderOutputDTO.setTareWeight(woOutputList.get(0).getTareWeight());
			workOrderOutputDTO.setNetWeight(woOutputList.get(0).getNetWeight());
			workOrderOutputDTO.setNoOfStrands(woOutputList.get(0).getNoOfStrands());
			workOrderOutputDTO.setSpeed(woOutputList.get(0).getSpeed());
			workOrderOutputDTO.setAnnealingPercent(woOutputList.get(0).getAnnealingPercent());
			workOrderOutputDTO.setOuterDiameter(woOutputList.get(0).getOuterDiameter());
			workOrderOutputDTO.setUpdatedBy(userName);
			workOrderOutputDTO.setBatchNo(woOutputList.get(0).getBatchNo());
			workOrderOutputDTO.setStockIn(woOutputList.get(0).getStockIn());
			workOrderOutputDTO.setSize(woOutputList.get(0).getSize());
			workOrderOutputDTO.setOrderDetailId(newSalesOrderItemId);
			WorkOrderOutput workOrderOutputs=workOrderOutputDTO.getWorkOrderOutput();
			updateWoItems=workOrderOutputService.update(workOrderOutputs);//update work order output
			}//end of if(woOutputList.size()>0)loop
		}
			else{
			//fectch work order item based on new sales order item id
			woNewCustomerListExist=workOrderItemService.findBySoItemIdAndWorkOrderNo(newSalesOrderItemId,oldWoNo);
			//fectch work order item based on old sales order item id
			woItemList=workOrderItemService.findBySoItemIdAndWorkOrderNo(oldSalesOrderItemId, oldWoNo);
    		if(woItemList.size()>0){
			if(woNewCustomerListExist.size()>0){
				WorkOrderItemsDTO workOrderItemsDTO=new WorkOrderItemsDTO();
				workOrderItemsDTO.setWorkOrderItemId(woNewCustomerListExist.get(0).getWorkOrderItemId());
				workOrderItemsDTO.setWorkOrderNo(woNewCustomerListExist.get(0).getProductionWorkOrder().getWorkOrderNo());
				workOrderItemsDTO.setOrderDetailId(woNewCustomerListExist.get(0).getSalesOrderItem().getOrderDetailId());
				workOrderItemsDTO.setNoOfCoils(woNewCustomerListExist.get(0).getNoOfCoils()+1);
				workOrderItemsDTO.setQtyPerCoil(woNewCustomerListExist.get(0).getQtyPerCoil());
				workOrderItemsDTO.setTotalQuantity(woNewCustomerListExist.get(0).getTotalQuantity()+storeRegList.get(0).getStockQty());
				workOrderItemsDTO.setPackingType(woNewCustomerListExist.get(0).getPackingType());
				workOrderItemsDTO.setPvcGrade(woNewCustomerListExist.get(0).getPvcGrade());
				workOrderItemsDTO.setMasterBatch(woNewCustomerListExist.get(0).getMasterBatch());
				workOrderItemsDTO.setToBeLabelled(woNewCustomerListExist.get(0).getToBeLabelled());
				workOrderItemsDTO.setStockInQty(woNewCustomerListExist.get(0).getStockInQty()+storeRegList.get(0).getStockQty());
				workOrderItemsDTO.setStockInStatus(woNewCustomerListExist.get(0).getStockInStatus());
				workOrderItemsDTO.setUpdatedBy(userName);
				WorkOrderItems workOrderItems=workOrderItemsDTO.getWorkOrderItem();
				updateWoItems=workOrderItemService.update(workOrderItems);//update work order items
			}//end of if(woNewCustomerListExist.size()>0) loop
			else{
				if(newSoItemDetailsList.size()>0){
				WorkOrderItemsDTO workOrderItemDTO=new WorkOrderItemsDTO();
				workOrderItemDTO.setWorkOrderNo(oldWoNo);
				workOrderItemDTO.setOrderDetailId(newSalesOrderItemId);
				workOrderItemDTO.setNoOfCoils(1);
				workOrderItemDTO.setQtyPerCoil(newSoItemDetailsList.get(0).getBundleSize());
				workOrderItemDTO.setTotalQuantity(storeRegList.get(0).getStockQty());
				workOrderItemDTO.setPackingType(woItemList.get(0).getPackingType());
				workOrderItemDTO.setPvcGrade(woItemList.get(0).getPvcGrade());
				workOrderItemDTO.setMasterBatch(woItemList.get(0).getMasterBatch());
				workOrderItemDTO.setToBeLabelled(woItemList.get(0).getToBeLabelled());
				workOrderItemDTO.setStockInQty(storeRegList.get(0).getStockQty());
				workOrderItemDTO.setStockInStatus("Completed");
				workOrderItemDTO.setUpdatedBy(woItemList.get(0).getUpdatedBY());
				WorkOrderItems workOrderItem=workOrderItemDTO.getWorkOrderItem();
				updateWoItems=workOrderItemService.update(workOrderItem);//update work order items
		       }//end of if(newSoItemDetailsList.size()>0)loop
			 }//end of els eloop
			if(woItemList.get(0).getNoOfCoils()>0){
			    WorkOrderItemsDTO woItemsDTO=new WorkOrderItemsDTO();
			    woItemsDTO.setWorkOrderItemId(woItemList.get(0).getWorkOrderItemId());
			    woItemsDTO.setWorkOrderNo(woItemList.get(0).getProductionWorkOrder().getWorkOrderNo());
			    woItemsDTO.setOrderDetailId(woItemList.get(0).getSalesOrderItem().getOrderDetailId());
			    woItemsDTO.setNoOfCoils(woItemList.get(0).getNoOfCoils()-1);
			    woItemsDTO.setQtyPerCoil(woItemList.get(0).getQtyPerCoil());
			    woItemsDTO.setTotalQuantity(woItemList.get(0).getTotalQuantity()-storeRegList.get(0).getStockQty());
			    woItemsDTO.setPackingType(woItemList.get(0).getPackingType());
			    woItemsDTO.setPvcGrade(woItemList.get(0).getPvcGrade());
			    woItemsDTO.setMasterBatch(woItemList.get(0).getMasterBatch());
			    woItemsDTO.setToBeLabelled(woItemList.get(0).getToBeLabelled());
			    woItemsDTO.setStockInQty(woItemList.get(0).getStockInQty()-storeRegList.get(0).getStockQty());
			    woItemsDTO.setStockInStatus(woItemList.get(0).getStockInStatus());
			    woItemsDTO.setUpdatedBy(woItemList.get(0).getUpdatedBY());
				WorkOrderItems woItems=woItemsDTO.getWorkOrderItem();
				updateWoItems=workOrderItemService.update(woItems);//update work order item after change label
			}//end of if(woItemList.get(0).getNoOfCoils()>0) loop
		        	Boolean deleteLabelReport=false;
		        	//fetch label report table entries for work order item id that has to be deleted
		        	List<WorkOrderItems>woItem=workOrderItemService.findById(woItemList.get(0).getWorkOrderItemId());
		        	if(woItem.size()>0){
		        		if(woItem.get(0).getNoOfCoils()<1){
		        			List<LabelReport>labeReportList=labelReportService.findByWorkOrderItemsWorkOrderItemId(woItem.get(0).getWorkOrderItemId());
		        			if(labeReportList.size()>0){
		        				for(int l=0;l<labeReportList.size();l++){
		        				labelReportService.delete(labeReportList.get(l).getLabelReportId());//delete label report table entries
		        				deleteLabelReport=true;
		        					
		        				}//end of for loop
		        			}//end of if(labeReportList.size()>0) loop
		        			if(deleteLabelReport==true)
		        			workOrderItemService.delete(woItem.get(0).getWorkOrderItemId());//delete work order item
		        		}//check no of coils end of if loop
		        }//end of if(woItem.size()>0) loop
		        	
		
			
    		}
		}//end of else loop
}//end of if(oldSalesOrderItemId!=null && oldWoNo!=null) loop
		}//end of if(storeRegList.size()>0) loop
		List<String> bundleIdsList=new ArrayList<>();
	if(updateWoItems==true){
		
		List<StockIn>oldStockInList=stockInService.findByOrderDetailIdBundleIdWorkOrderNo(oldSalesOrderItemId, storeRegList.get(0).getBundleId(), oldWoNo);
		
		
		/*Changes as of 11-July-2015*/
		//List<StockIn>changeStoreExistList=stockInService.findByOrderIdAndItemCodeAndWoNo(newSalesOrderNo, oldStockInList.get(0).getSalesOrderItem().getItem().getItemCode(), oldWoNo);
		List<StockIn>changeStoreExistList=stockInService.findByOrderIdAndItemCodeAndWoNoAndBundleId(newSalesOrderNo, oldStockInList.get(0).getSalesOrderItem().getItem().getItemCode(), oldWoNo,storeRegList.get(0).getBundleId());

		String greatestBundleId=null;
	    Integer bundleValue=null;
	    String newBundleIds=null;
		
		if(changeStoreExistList.size()>0){
			for(int y=0;y<changeStoreExistList.size();y++){
				String bundleIds = changeStoreExistList.get(y).getBundleId();

				if (!bundleIdsList.contains(bundleIds)) {
					bundleIdsList.add(bundleIds);
				}
			}
	
		Collections.sort(bundleIdsList,Collections.reverseOrder());
	    greatestBundleId=bundleIdsList.get(0);
	    if(greatestBundleId!=null)
	    bundleValue=Integer.parseInt(greatestBundleId)+1;

	    if(bundleValue!=null){
	    if(bundleValue<10)
	    	newBundleIds="00"+bundleValue;
	    else if (bundleValue<100)
	    	newBundleIds="0"+bundleValue;
	    else
	     	newBundleIds=String.valueOf(bundleValue);
	    }
		}
		if(oldStockInList.size()>0){
			StockInDTO stockInDTO=new StockInDTO();
			stockInDTO.setStockInId(oldStockInList.get(0).getStockInId());
			stockInDTO.setStoreId(oldStockInList.get(0).getStore().getStoreId());
			stockInDTO.setOrderDetailId(newSalesOrderItemId);
			stockInDTO.setOrderId(newSalesOrderNo);
			stockInDTO.setItemId(oldStockInList.get(0).getSalesOrderItem().getItem().getItemId());
			stockInDTO.setItemCode(oldStockInList.get(0).getSalesOrderItem().getItem().getItemCode());
			stockInDTO.setSoItemQty(newSalesOrderOrderedQty);
			stockInDTO.setWorkOrderNo(oldStockInList.get(0).getProductionWorkOrder().getWorkOrderNo());
			stockInDTO.setStockQty(oldStockInList.get(0).getStockQty());
			stockInDTO.setQcStatus(oldStockInList.get(0).getQcStatus());
			stockInDTO.setCustomerName(newCustomerName);
			
			/* START OF NEW CODE ADDED ABIN SAM @ 19 April 2015*/
	    	   if(oldStockInList.get(0).getStockInDateTime() !=null){
	    		   stockInDTO.setStockInDateTime(oldStockInList.get(0).getStockInDateTime().toString());
				}
	    	  /*END OF NEW CODE ADDED ABIN SAM @ 19 April 2015*/
	    	   
			if(newBundleIds!=null && newBundleIds!="")
			   stockInDTO.setBundleId(newBundleIds);
			else
				stockInDTO.setBundleId(oldStockInList.get(0).getBundleId());
			stockInDTO.setWeight(oldStockInList.get(0).getWeight());
			stockInDTO.setBatchNo(oldStockInList.get(0).getBatchNo());
			stockInDTO.setConfirmStatus(oldStockInList.get(0).getConfirmStatus());
			stockInDTO.setSupervisor(userName);
			StockIn stockIn=stockInDTO.getStockIn();
		    updateNewStockIn=stockInService.update(stockIn);
		}
		if(updateNewStockIn==true){
			List<StoreRegister>oldStoreRegList=storeRegisterService.findByOrderDetailIdAndBundleIdAndWorkOrderNo(oldSalesOrderItemId, storeRegList.get(0).getBundleId(), oldWoNo);
	       if(oldStoreRegList.size()>0){
	    	   StoreRegisterDTO storeRegisterDTO=new StoreRegisterDTO();
	    	   storeRegisterDTO.setStoreRegisterId(oldStoreRegList.get(0).getStoreRegisterId());
	    	   storeRegisterDTO.setStoreId(oldStoreRegList.get(0).getStore().getStoreId());
	    	   storeRegisterDTO.setItemCode(oldStoreRegList.get(0).getSalesOrderItem().getItem().getItemCode());
	    	   storeRegisterDTO.setWorkOrderNo(oldStoreRegList.get(0).getProductionWorkOrder().getWorkOrderNo());
	    	   storeRegisterDTO.setCustomerName(newCustomerName);
	    	   storeRegisterDTO.setStockQty(oldStoreRegList.get(0).getStockQty());
	    	 /* START OF NEW CODE ADDED ABIN SAM @ 13 April 2015*/
	    	   if(oldStoreRegList.get(0).getUpdatedDateTime()!=null){
	    		   storeRegisterDTO.setUpdatedDateTime(oldStoreRegList.get(0).getUpdatedDateTime().toString());
				}
	    	  /*END OF NEW CODE ADDED ABIN SAM @ 13 April 2015*/
	    	   if(newBundleIds!=null && newBundleIds!="")
	    	   storeRegisterDTO.setBundleId(newBundleIds);
	    	   else
	    		storeRegisterDTO.setBundleId(oldStoreRegList.get(0).getBundleId());
	    	   storeRegisterDTO.setOrderId(newSalesOrderNo);
	    	   storeRegisterDTO.setOrderDetailId(newSalesOrderItemId);
	    	   storeRegisterDTO.setItemId(oldStoreRegList.get(0).getSalesOrderItem().getItem().getItemId());
	    	   storeRegisterDTO.setPackingSlipNo(null);
	    	   storeRegisterDTO.setSupervisor(userName);
	    	   if(oldStoreRegList.get(0).getQcStatus()!=null)
	    	   storeRegisterDTO.setQcStatus(oldStoreRegList.get(0).getQcStatus());
	    	   if(oldStoreRegList.get(0).getQcSupervisor()!=null)
	    	   storeRegisterDTO.setQcSupervisor(oldStoreRegList.get(0).getQcSupervisor());
	    	   if(oldStoreRegList.get(0).getRejectStatus()!=null)
	    	   storeRegisterDTO.setRejectStatus(oldStoreRegList.get(0).getRejectStatus());
	    	   storeRegisterDTO.setWeight(oldStoreRegList.get(0).getWeight());
	    	   storeRegisterDTO.setBagWeight(null);
	    	   StoreRegister storeRegister=storeRegisterDTO.getStoreRegister();
			   updateNewStoreReg=storeRegisterService.update(storeRegister);
		 
	       }
		}
		
		if(updateNewStoreReg==true){
			List<StoreRegister>newStoreRegisterListDetails=storeRegisterService.findByOrderDetailId(newSalesOrderItemId);
		    if(newStoreRegisterListDetails.size()>0){
		    	Double newSoTotalStockQty=0.0;
		    	//String itemType=newStoreRegisterListDetails.get(0).getSalesOrderItem().getItem().getItemType();
	    		 String units=newStoreRegisterListDetails.get(0).getSalesOrderItem().getItem().getUnit().getUnits();

		    	for(int i=0;i<newStoreRegisterListDetails.size();i++){
		    		    if(units.equalsIgnoreCase("Kgs")|| units.equalsIgnoreCase("Kg") )
			    		    newSoTotalStockQty=newSoTotalStockQty+newStoreRegisterListDetails.get(i).getWeight();
		    		    else
		    	  		    newSoTotalStockQty=newSoTotalStockQty+newStoreRegisterListDetails.get(i).getStockQty();
		       	}
		    
		    	List<SalesOrderItem>salesOrderItemList=orderDetailsService.findById(newSalesOrderItemId);
		    	if(salesOrderItemList.size()>0){
		    		Double newSoBalQty=0.0;
		    		Double newSoTotalQty=salesOrderItemList.get(0).getQuantity();
		    		Double newSoPdnQty=salesOrderItemList.get(0).getProductionQty();
		    		Double newSoDispatchedQty=salesOrderItemList.get(0).getDispatchedQty();
		    		Double newSoCompletedQty=newSoTotalStockQty;
		    		if((newSoPdnQty+newSoDispatchedQty+newSoCompletedQty)<newSoTotalQty)
		    			newSoBalQty=newSoTotalQty-(newSoPdnQty+newSoDispatchedQty+newSoCompletedQty);
		    		if(newSoBalQty<0.0)
		    			newSoBalQty=0.0;
		    		SalesOrderItemsDTO soItemDTO=new SalesOrderItemsDTO();
					soItemDTO.setOrderDetailId(salesOrderItemList.get(0).getOrderDetailId());
					soItemDTO.setOrderId(salesOrderItemList.get(0).getOrder().getOrderId());
					soItemDTO.setItemId(salesOrderItemList.get(0).getItem().getItemId());
					soItemDTO.setQuantity(salesOrderItemList.get(0).getQuantity());
					soItemDTO.setBalanceQty(newSoBalQty);
					soItemDTO.setBundleSize(salesOrderItemList.get(0).getBundleSize());
					soItemDTO.setRate(salesOrderItemList.get(0).getRate());
					soItemDTO.setWoQty(salesOrderItemList.get(0).getWoQty());
					soItemDTO.setCompletedQty(newSoCompletedQty);
					soItemDTO.setItemCode(salesOrderItemList.get(0).getItemCode());
					soItemDTO.setProductionQty(salesOrderItemList.get(0).getProductionQty());
					soItemDTO.setDispatchedQty(salesOrderItemList.get(0).getDispatchedQty());
					soItemDTO.setUpdatedBy(salesOrderItemList.get(0).getUpdatedBy());
					soItemDTO.setUpdatedTime(salesOrderItemList.get(0).getUpdatedTime().toString());
					 soItemDTO.setWeight(salesOrderItemList.get(0).getWeight());
					 soItemDTO.setPvcWeight(salesOrderItemList.get(0).getPvcWeight());
					SalesOrderItem soItem=soItemDTO.getOrderDetail();
					orderDetailsService.update(soItem);
		            
		    	}}
			 List<StoreRegister>oldStoreRegisterListDetails=storeRegisterService.findByOrderDetailId(oldSalesOrderItemId);
		     if(oldStoreRegisterListDetails.size()>0){
			   	//String itemType=oldStoreRegisterListDetails.get(0).getSalesOrderItem().getItem().getItemType();
	    		 String units=newStoreRegisterListDetails.get(0).getSalesOrderItem().getItem().getUnit().getUnits();

			   	Double oldSoTotalStockQty=0.0;
		    	for(int i=0;i<oldStoreRegisterListDetails.size();i++){
		    	    if(units.equalsIgnoreCase("Kgs")|| units.equalsIgnoreCase("Kg"))
			    	   oldSoTotalStockQty=oldSoTotalStockQty+oldStoreRegisterListDetails.get(i).getWeight();
		    	    else
                        oldSoTotalStockQty=oldSoTotalStockQty+oldStoreRegisterListDetails.get(i).getStockQty();
		    	}

               	List<SalesOrderItem>oldSalesOrderItemList=orderDetailsService.findById(oldSalesOrderItemId);
		    	if(oldSalesOrderItemList.size()>0){
		    		Double oldSoBalQty=0.0;
		    		Double oldSoTotalQty=oldSalesOrderItemList.get(0).getQuantity();
		    		Double oldSoPdnQty=oldSalesOrderItemList.get(0).getProductionQty();
		    		Double oldSoDispatchedQty=oldSalesOrderItemList.get(0).getDispatchedQty();
		    		Double oldSoCompletedQty=oldSoTotalStockQty;
		    		if((oldSoPdnQty+oldSoDispatchedQty+oldSoCompletedQty)<oldSoTotalQty)
		    			oldSoBalQty=oldSoTotalQty-(oldSoPdnQty+oldSoDispatchedQty+oldSoCompletedQty);
		    		if(oldSoBalQty<0.0)
		    			oldSoBalQty=0.0;
		    		SalesOrderItemsDTO soItemDTO=new SalesOrderItemsDTO();
					soItemDTO.setOrderDetailId(oldSalesOrderItemList.get(0).getOrderDetailId());
					soItemDTO.setOrderId(oldSalesOrderItemList.get(0).getOrder().getOrderId());
					soItemDTO.setItemId(oldSalesOrderItemList.get(0).getItem().getItemId());
					soItemDTO.setQuantity(oldSalesOrderItemList.get(0).getQuantity());
					soItemDTO.setBalanceQty(oldSoBalQty);
					soItemDTO.setBundleSize(oldSalesOrderItemList.get(0).getBundleSize());
					soItemDTO.setRate(oldSalesOrderItemList.get(0).getRate());
					soItemDTO.setWoQty(oldSalesOrderItemList.get(0).getWoQty());
					soItemDTO.setCompletedQty(oldSoCompletedQty);
					soItemDTO.setItemCode(oldSalesOrderItemList.get(0).getItemCode());
					soItemDTO.setProductionQty(oldSalesOrderItemList.get(0).getProductionQty());
					soItemDTO.setDispatchedQty(oldSalesOrderItemList.get(0).getDispatchedQty());
					soItemDTO.setUpdatedBy(oldSalesOrderItemList.get(0).getUpdatedBy());
					soItemDTO.setUpdatedTime(oldSalesOrderItemList.get(0).getUpdatedTime().toString());
					soItemDTO.setWeight(oldSalesOrderItemList.get(0).getWeight());
					soItemDTO.setPvcWeight(oldSalesOrderItemList.get(0).getPvcWeight());
					SalesOrderItem soItem=soItemDTO.getOrderDetail();
					orderDetailsService.update(soItem);
		            
		    	}
		    }

		}
	}
	
   }//end of if loop

    	return new StatusResponse(updateNewStoreReg);
  }
}