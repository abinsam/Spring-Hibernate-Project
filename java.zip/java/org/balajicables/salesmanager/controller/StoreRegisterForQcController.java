package org.balajicables.salesmanager.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import javax.annotation.Resource;
import org.balajicables.salesmanager.CustomUser;
import org.balajicables.salesmanager.common.JqgridFilter;
import org.balajicables.salesmanager.common.JqgridObjectMapper;
import org.balajicables.salesmanager.common.JqgridResponse;
import org.balajicables.salesmanager.common.StatusResponse;
import org.balajicables.salesmanager.common.StoreRegisterMapper;
import org.balajicables.salesmanager.dto.SalesOrderItemsDTO;
import org.balajicables.salesmanager.dto.SemifinishedStockOutDTO;
import org.balajicables.salesmanager.dto.StockInDTO;
import org.balajicables.salesmanager.dto.StockOutDTO;
import org.balajicables.salesmanager.dto.StoreRegisterDTO;
import org.balajicables.salesmanager.model.SalesOrderItem;
import org.balajicables.salesmanager.model.SemifinishedStockOut;
import org.balajicables.salesmanager.model.StockIn;
import org.balajicables.salesmanager.model.StockOut;
import org.balajicables.salesmanager.model.StoreRegister;
import org.balajicables.salesmanager.repository.ProductionProcessRepository;
import org.balajicables.salesmanager.service.ItemService;
import org.balajicables.salesmanager.service.OrderDetailsService;
import org.balajicables.salesmanager.service.ProductionWorkOrderService;
import org.balajicables.salesmanager.service.SemifinishedStockOutService;
import org.balajicables.salesmanager.service.StockInService;
import org.balajicables.salesmanager.service.StockOutService;
import org.balajicables.salesmanager.service.StoreRegisterService;
import org.springframework.data.domain.Page;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
/**
* This class demonstrate QC Store Register Module
* @author Abin Sam
*/
@Controller
@RequestMapping("/storeRegisterForQc")
public class StoreRegisterForQcController {

	@Resource
	private OrderDetailsService orderDetailsService;

	@Resource
	private SemifinishedStockOutService semifinishedStockOutService;
	@Resource
	private ItemService itemService;


	@Resource
	private StockInService stockInService;

	@Resource
	private StoreRegisterService storeRegisterService;

	@Resource
	private ProductionWorkOrderService productionWorkOrderService;



	@Resource
	private ProductionProcessRepository productionProcessRepository;

	
	@Resource 
	private StockOutService stockOutService;
	
	 /**
	   * This method returns storeRegisterForQc.jsp.
	   * Fetch all salesOrders,work order process,work order nos, customers,colors,copperDiameters,
	   *       productTypes,cableStdPvcs
	   * @param Model to set the attribute.
	   * @return storeRegisterForQc.jsp.
	   */
	@RequestMapping(method = RequestMethod.GET)
	public String getSalesOrdersPage(Model model) {
		ArrayList<String> salesOrders = new ArrayList<>();
		Map<Long, String> map = new HashMap<Long, String>();
		String qcStatus="Pending";//Initialize qcStatus variable
		List<StoreRegister>storeRegList=storeRegisterService.findByQcStatus(qcStatus);//fetch all store register itmes with QC status pending
		
		for (int iterator = 0; iterator < storeRegList.size(); iterator++) {
			String soNo = storeRegList.get(iterator).getSalesOrderItem().getOrder().getOrderId();
			String customerName= storeRegList.get(iterator).getSalesOrderItem().getOrder().getCustomer().getCustomerName();
         	Long customerId=storeRegList.get(iterator).getSalesOrderItem().getOrder().getCustomer().getCustomerId();
			if (!salesOrders.contains(soNo)) {
				salesOrders.add(soNo);
			}//end of if loop
		  	if (!map.containsValue(customerName)) {
        		map.put(customerId, customerName);
        		//custList.add(storeRegList.get(iterator).getSalesOrderItem().getOrder().getCustomer());
    		}//end of if loop
		}//end of for loop
		
		Collections.sort(salesOrders,Collections.reverseOrder());//sort sales orders in descending order
		//Collections.sort(map);//sort sales orders in ascending order

		model.addAttribute("orderIds",salesOrders);//add sales order to model attribute
		model.addAttribute("customers", map);//add customers to model attribute
		
		model.addAttribute("processes",productionProcessRepository.findAll());//add productionProcess to model attribute
		model.addAttribute("workOrder", productionWorkOrderService.findAll());//add workOrder to model attribute
		//model.addAttribute("customers", customerService.findAll());//add customers to model attribute
		model.addAttribute("colours", itemService.getAllColours());//add colours to model attribute
		model.addAttribute("copperDiameters", itemService.getAllCopperDiameters());//add copperDiameters to model attribute
		model.addAttribute("productTypes", itemService.getAllProductTypes());//add productTypes to model attribute
		model.addAttribute("cableStdPvcs", itemService.getAllCableStdPvcs());//add cableStdPvcs to model attribute

		return "storeRegisterForQc";
	}

	 /**
	   * This method returns itemCode List
	   * Fetch all QC Pending Store register Items
	   * @param Model to set the attribute.
	   * @return storeRegisterForQc.jsp.
	   */
	@RequestMapping(value = "/fetchStoreItems", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	List<String> fetchStoreItems(Model model) {
		String status="Pending";//initialize qc status
		//Method to fetch store register items by qc status
		List<StoreRegister>storeRegList=storeRegisterService.findByQcStatus(status);
		List<String>itemCodeList=new ArrayList<>();
		if(storeRegList.size()>0){
			for (int iterator = 0; iterator < storeRegList.size(); iterator++) {
				String itemCode= storeRegList.get(iterator).getItemCode();
				if (!itemCodeList.contains(itemCode)) {
					itemCodeList.add(itemCode);
				}//end of inner if loop
		   }//end of for loop
	   }//end of if loop

		return itemCodeList;
	}
	
	 /**
	   * This method returns work orders List
	   * Fetch all Production work order Nos
	   * @param processType.
	   * @return List<String>workOrders
	   */
	@RequestMapping(value="/getWorkOrders/{processType}", produces="application/json", method=RequestMethod.POST)
	public @ResponseBody
	List<String> getWODetails(
			@PathVariable("processType") String processType,
			Model model) {
		String qcStatus="Pending";
		//Method to fetch production work orders by process type
		//List<ProductionWorkOrder> pdnWorkOrders = productionWorkOrderRepository.findByProcessProcessType(processType);
		List<StoreRegister> storeWorkOrders = storeRegisterService.findByQcStatusAndProductionWorkOrderProcess(qcStatus,processType);
		
		ArrayList<String> pdnWoValuesList = new ArrayList<>();
		
		for(int iterator=0; iterator < storeWorkOrders.size();iterator++){
			String woNo= storeWorkOrders.get(iterator).getProductionWorkOrder().getWorkOrderNo();
			if (!pdnWoValuesList.contains(woNo)) {
			pdnWoValuesList.add(woNo);
			}
			Collections.sort(pdnWoValuesList,Collections.reverseOrder());//sort production work order list in descending order
		}//end of for loop
				
		return pdnWoValuesList;
	}
	
	 /**
	   * This method returns sales order List  from store register based on customer selected nd QC Status
	   * Fetch  sales order no list for select box
	   * @param customerId, Model to set the attribute.
	   * @return List<String>salesOrderList
	   */
	@RequestMapping(value = "/getSalesOrders", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	ArrayList<String> getSalesOrders(
			@RequestParam("customerId") Long customerId, Model model) {
		String qcStatus="Pending";
		List<StoreRegister> salesOrdersList =null;
		if(customerId!=0){
		//fetch store register lsit based on customer id
		salesOrdersList = storeRegisterService.findBySalesOrderItemOrdersCustomerCustomerIdAndQcStatus(customerId,qcStatus);
		}else{
			salesOrdersList = storeRegisterService.findByQcStatus(qcStatus);
		}
		
		ArrayList<String> salesOrders = new ArrayList<>();
		for (int iterator = 0; iterator < salesOrdersList.size(); iterator++) {
			String soNo = salesOrdersList.get(iterator).getOrderId();
  		if (!salesOrders.contains(soNo)) {
				salesOrders.add(soNo);
			}//end of if (!salesOrders.contains(soNo)) loop
			Collections.sort(salesOrders,Collections.reverseOrder());//sort sales order in descending order
		}//end of for loop

		return salesOrders;
	}
		 /**
	   * This method return store register records for grid
	   * @param searchObject,filters,pageNumber,rowsPerPage,sortColName,sortOrder
	   * @return JqgridResponse<StoreRegisterDTO> response
	   */
	@RequestMapping(value = "/records", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	JqgridResponse<StoreRegisterDTO> records(
			@RequestParam(value = "searchObject", required = false) String searchObject,
			@RequestParam("_search") Boolean search,
			@RequestParam(value = "filters", required = false) String filters,
			@RequestParam(value = "page", required = false) Integer pageNumber,
			@RequestParam(value = "rows", required = false) Integer rowsPerPage,
			@RequestParam(value = "sidx", required = false) String sortColName,
			@RequestParam(value = "sord", required = false, defaultValue = "asc") String sortOrder) {
		 /*grid column sorting*/
		  if(sortColName.equalsIgnoreCase("customerCode")){
				sortColName="salesOrderItem.orders.customer.customerCode";
			}
		  if(sortColName.equalsIgnoreCase("customerName")){
				sortColName="salesOrderItem.orders.customer.customerName";
			}
		  if(sortColName.equalsIgnoreCase("itemDescription")){
				sortColName="salesOrderItem.items.itemDescription";
			}
		  if(sortColName.equalsIgnoreCase("workOrderNo")){
				sortColName="productionWorkOrder.workOrderNo";
			}
		  if(sortColName.equalsIgnoreCase("status")){
				sortColName="salesOrderItem.orders.orderStatus.status";
			}
		  if (searchObject != null
				&& !(searchObject.equalsIgnoreCase("allSearch"))) {
			//Method to fetch store register item based on serach object
			return getFilteredRecords(searchObject, pageNumber - 1,
					rowsPerPage, sortColName, sortOrder);
		}//end of if loop
		else {
			//Method to fetch store Register items for jq grid without any specific search parameter
			Page<StoreRegister> storeReg = storeRegisterService.getQCPagedStore(pageNumber - 1, rowsPerPage, sortColName, sortOrder);
			/*Intialize JQ grid response of type StoreRegisterDTO */
			JqgridResponse<StoreRegisterDTO> response = new JqgridResponse<StoreRegisterDTO>();
			/*Method to set StoreRegister item list to StoreRegisterDTO*/
			List<StoreRegisterDTO> storeDTOs = convertToStoreDTO(storeReg.getContent());
			response.setRows(storeDTOs);
			response.setRecords(Long.valueOf(storeReg.getTotalElements()).toString());
			response.setTotal(Long.valueOf(storeReg.getTotalPages()).toString());
			response.setPage(Integer.valueOf(storeReg.getNumber() + 1).toString());
			return response;
		}//end of else loop
	}

	
	 /**
	   * This method to fetch store regsiter item based on search parameter and set response to JQGRID
	   * Fetch store Regsiter item details for grid
	   * @param filters,pageNumber,rowsPerPage,sortColName,sortOrder
	   * @return JqgridResponse<StoreRegisterDTO> response
	   */
	private JqgridResponse<StoreRegisterDTO> getFilteredRecords(String filters,
			int pagenumber, Integer rows, String sortColName, String sortOrder) {

		String qOrderId = null;
		Long qCustomerId = null;
		String qItemCode = null;
		Integer qNumberOfCopperStrands = 0;
		String qCopperKey = null;
		String qOuterDiameter = null;
		String qMainColour = null;
		String qInnerColor = null;
		String qCableStdKey = null;
		String qLayLength = null;
		String qLayType = null;
		String qProductKey = null;
		String qWorkOrderNo = null;
		String qQcStatus = null;
  //JQ Grid filtering parameters
		JqgridFilter jqgridFilter = JqgridObjectMapper.map(filters);
		for (JqgridFilter.Rule rule : jqgridFilter.getRules()) {
			if (rule.getField().equals("orderId"))
				qOrderId = rule.getData();
			else if (rule.getField().equals("itemCode"))
				qItemCode = rule.getData();
			else if (rule.getField().equals("workOrderNo"))
				qWorkOrderNo = rule.getData();
			else if (rule.getField().equals("customerId")) {
				if (rule.getData() == "" || rule.getData() == null)
					qCustomerId = (long) 0;
				else
					qCustomerId = Long.valueOf(rule.getData());
			} else if (rule.getField().equals("numberOfCopperStrands")) {
				if (rule.getData() == "" || rule.getData() == null)
					qNumberOfCopperStrands = 0;
				else
					qNumberOfCopperStrands = Integer.parseInt(rule.getData());
			} else if (rule.getField().equals("copperkey"))
				qCopperKey = rule.getData();
			else if (rule.getField().equals("outerDiameter"))
				qOuterDiameter = rule.getData();
			else if (rule.getField().equals("mainColour"))
				qMainColour = rule.getData();
			else if (rule.getField().equals("innerColor"))
				qInnerColor = rule.getData();
			else if (rule.getField().equals("cableStdKey"))
				qCableStdKey = rule.getData();
			else if (rule.getField().equals("layLength"))
				qLayLength = rule.getData();
			else if (rule.getField().equals("layType"))
				qLayType = rule.getData();
			else if (rule.getField().equals("productKey"))
				qProductKey = rule.getData();
			else if (rule.getField().equals("qcStatus"))
				qQcStatus = rule.getData();
		}
		//Method to fetch store register items based on filtering params
		List<StoreRegister> storeRegItem = storeRegisterService.fetchBySearch(
				qOrderId, qWorkOrderNo, qCustomerId, qItemCode,
				qNumberOfCopperStrands, qCopperKey, qOuterDiameter,
				qMainColour, qInnerColor, qCableStdKey, qLayLength, qLayType,
				qProductKey,qQcStatus, pagenumber, rows, sortColName, sortOrder);

		List<StoreRegister> pagedList;
		int fromIndex = Math.min(storeRegItem.size(), pagenumber * rows);//start index of response set to JQ Grid
		int toIndex = Math.min(storeRegItem.size(), fromIndex + rows);//end index of response set to JQ Grid

		if (fromIndex == 0 && toIndex == (storeRegItem.size() - 1)) {
			pagedList = storeRegItem;
		}//end of if loop
		else {
			pagedList = storeRegItem.subList(fromIndex, toIndex);
		}//end of else loop
         //Set paged store regsiter response to store register dto
		List<StoreRegisterDTO> storeRegisterDto = StoreRegisterMapper
				.map(pagedList);
		/*Intialize JQ grid response of type StoreRegisterDTO*/
		JqgridResponse<StoreRegisterDTO> response = new JqgridResponse<StoreRegisterDTO>();

		response.setRows(storeRegisterDto);
		response.setRecords(Long.valueOf(storeRegItem.size()).toString());
		//set grid total row count based on response
		if (storeRegItem.size() > 0)
			response.setTotal(Integer.valueOf(
					(int) Math.ceil(Double.valueOf(storeRegItem.size())
							/ Double.valueOf(rows.toString()))).toString());
		else
			response.setTotal("0");
		response.setPage(Integer.valueOf(pagenumber + 1).toString());
		return response;

	}

	
	 /**
	   * This method to set store regsiter item to StoreRegisterDTO
	   * @param StoreRegister
	   * @return List<StoreRegisterDTO>
	   */
	private List<StoreRegisterDTO> convertToStoreDTO(
			List<StoreRegister> storeRegs) {
		List<StoreRegisterDTO> storeRegDTOs = new ArrayList<>();
		for (StoreRegister storeReg : storeRegs) {
			StoreRegisterDTO storeRegDTO = new StoreRegisterDTO();
			storeRegDTO.setStoreRegisterId(storeReg.getStoreRegisterId());
			storeRegDTO.setStoreId(storeReg.getStore().getStoreId());
			storeRegDTO.setStoreAddress(storeReg.getStore().getStoreAddress());
			storeRegDTO.setItemId(storeReg.getSalesOrderItem().getItem()
					.getItemId());
			storeRegDTO.setItemCode(storeReg.getSalesOrderItem().getItem()
					.getItemCode());
			storeRegDTO.setOrderId(storeReg.getSalesOrderItem().getOrder()
					.getOrderId());
			storeRegDTO.setCustomerId(storeReg.getSalesOrderItem().getOrder()
					.getCustomer().getCustomerId());
			storeRegDTO.setCustomerName(storeReg.getSalesOrderItem().getOrder()
					.getCustomer().getCustomerName());
			storeRegDTO.setCustomerCode(storeReg.getSalesOrderItem().getOrder()
					.getCustomer().getCustomerCode());
			storeRegDTO.setWorkOrderNo(storeReg.getProductionWorkOrder()
					.getWorkOrderNo());
			storeRegDTO.setStockQty(storeReg.getStockQty());
			storeRegDTO.setBundleId(storeReg.getBundleId());
			storeRegDTO.setOrderDetailId(storeReg.getSalesOrderItem()
					.getOrderDetailId());
			storeRegDTO.setItemDescription(storeReg.getSalesOrderItem()
					.getItem().getItemDescription());
			storeRegDTO.setPackingSlipNo(storeReg.getPackingSlipNo());
			storeRegDTO.setSupervisor(storeReg.getSupervisor());
			storeRegDTO.setWeight(storeReg.getWeight());
			storeRegDTO.setUnits(storeReg.getSalesOrderItem().getItem()
					.getUnit().getUnits());
			storeRegDTO.setBagWeight(storeReg.getBagWeight());
			storeRegDTO.setQcStatus(storeReg.getQcStatus());
			storeRegDTO.setQcSupervisor(storeReg.getQcSupervisor());
			storeRegDTO.setStatus(storeReg.getSalesOrderItem().getOrder().getOrderStatus().getStatus());
			storeRegDTOs.add(storeRegDTO);
		}//end of for loop
		return storeRegDTOs;
	}

	
	
	 /**
	   * Crud functionality of StoreRegister
	   * @param StoreRegisterid,oper,itemCode,workOrderNo,customerName,stockQty,bundleId,orderId,orderDetailId,
			   itemId,supervisor,packingSlipNo,weight
	   * @return List<StoreRegisterDTO>
	   */
	@RequestMapping(value = "/crud", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	StatusResponse crud(@RequestParam Long id, @RequestParam String oper,
			@RequestParam(required = false) String stockQty,
			@RequestParam(required = false) String weight

	) {
		Boolean result = false;
		Boolean updateSalesOrderItem=false;
		Boolean stockQtyPatternMatch = false;
		Boolean weightPatternMatch = false;

			String decimalPattern = "((-|\\+)?[0-9]+(\\.[0-9]+)?)+";
			stockQtyPatternMatch = Pattern.matches(decimalPattern, stockQty);
			weightPatternMatch = Pattern.matches(decimalPattern, weight);

		if (stockQtyPatternMatch == true && weightPatternMatch==true) {
		if (stockQty!= null && weight!=null) {
		Double stockQtyValid = Double.valueOf(stockQty);
		Double weightValid = Double.valueOf(weight);
		List<StoreRegister>storeRegList=storeRegisterService.findById(id);
		String units=null;
		Double oldweight=0.0;
		Double oldStockQty=0.0;
		Long salesOrderItemId=null;
		if(storeRegList.size()>0){
			//String soNo=storeRegList.get(0).getSalesOrderItem().getOrder().getOrderId();
			String woNo=storeRegList.get(0).getProductionWorkOrder().getWorkOrderNo();
			String bundleId=storeRegList.get(0).getBundleId();
			Long soItemid=storeRegList.get(0).getSalesOrderItem().getOrderDetailId();
			String confirmStatus="Yes";
			Double stockInQty=storeRegList.get(0).getStockQty();
			Double stockWeight=storeRegList.get(0).getWeight();
           	
			units=storeRegList.get(0).getSalesOrderItem().getItem().getUnit().getUnits();
			oldweight=storeRegList.get(0).getWeight();
			oldStockQty=storeRegList.get(0).getStockQty();
			salesOrderItemId=storeRegList.get(0).getSalesOrderItem().getOrderDetailId();
			StoreRegisterDTO storeRegDTO = new StoreRegisterDTO();
			storeRegDTO.setStoreRegisterId(id);
			storeRegDTO.setStoreId(1);
			storeRegDTO.setItemCode(storeRegList.get(0).getSalesOrderItem().getItem().getItemCode());
			storeRegDTO.setWorkOrderNo(storeRegList.get(0).getProductionWorkOrder().getWorkOrderNo());
			storeRegDTO.setCustomerName(storeRegList.get(0).getCustomerName());
			storeRegDTO.setStockQty(stockQtyValid);
			storeRegDTO.setBundleId(storeRegList.get(0).getBundleId());
			storeRegDTO.setOrderId(storeRegList.get(0).getSalesOrderItem().getOrder().getOrderId());
			storeRegDTO.setOrderDetailId(storeRegList.get(0).getSalesOrderItem().getOrderDetailId());
			storeRegDTO.setItemId(storeRegList.get(0).getSalesOrderItem().getItem().getItemId());
			storeRegDTO.setPackingSlipNo(storeRegList.get(0).getPackingSlipNo());
			storeRegDTO.setSupervisor(storeRegList.get(0).getSupervisor());
			storeRegDTO.setWeight(weightValid);
			storeRegDTO.setBagWeight(storeRegList.get(0).getBagWeight());
			storeRegDTO.setQcStatus(storeRegList.get(0).getQcStatus());
			storeRegDTO.setRemarks(storeRegList.get(0).getRemarks());
			storeRegDTO.setQcSupervisor(storeRegList.get(0).getQcSupervisor());
			storeRegDTO.setRejectStatus(storeRegList.get(0).getRejectStatus());
			
			StoreRegister storeReg = storeRegDTO.getStoreRegister();
			result= storeRegisterService.update(storeReg);//create store register entry
			List<StockIn>stockInList=stockInService.findBySoNoAndWoNoAndBundleIdAndSoItemIdAndQuantity(woNo,bundleId,soItemid,stockInQty,stockWeight,confirmStatus);
			if(stockInList.size()>0 && result==true ){
				    StockInDTO stockInDTO = new StockInDTO();
				    stockInDTO.setStockInId(stockInList.get(0).getStockInId());
					stockInDTO.setStoreId(stockInList.get(0).getStore().getStoreId());
					stockInDTO.setOrderDetailId(stockInList.get(0).getSalesOrderItem().getOrderDetailId());
					stockInDTO.setOrderId(stockInList.get(0).getSalesOrderItem().getOrder().getOrderId());
					stockInDTO.setItemId(stockInList.get(0).getSalesOrderItem().getItem().getItemId());
					stockInDTO.setItemCode(stockInList.get(0).getSalesOrderItem().getItem().getItemCode());
					stockInDTO.setSoItemQty(stockInList.get(0).getSalesOrderItem().getQuantity());
					stockInDTO.setWorkOrderNo(stockInList.get(0).getProductionWorkOrder().getWorkOrderNo());
					stockInDTO.setQcStatus(stockInList.get(0).getQcStatus());
					stockInDTO.setStockQty(stockQtyValid);
					stockInDTO.setCustomerName(stockInList.get(0).getSalesOrderItem().getOrder().getCustomer().getCustomerName());
					stockInDTO.setBundleId(stockInList.get(0).getBundleId());
					if(stockInList.get(0).getStockInDateTime()!=null){
						stockInDTO.setStockInDateTime(stockInList.get(0).getStockInDateTime().toString());
					}
					stockInDTO.setWeight(weightValid);
					stockInDTO.setBatchNo(stockInList.get(0).getBatchNo());
					stockInDTO.setConfirmStatus(stockInList.get(0).getConfirmStatus());
					
			        stockInDTO.setSupervisor(stockInList.get(0).getSupervisor());
			        StockIn stockIns = stockInDTO.getStockIn();
				    stockInService.update(stockIns);//create store register entry
			}
		}
	  if(result==true && units!=null && salesOrderItemId!=null){
		  List<SalesOrderItem>soItemList=orderDetailsService.findById(salesOrderItemId);
		  if(soItemList.size()>0){
			  String unitsValue=soItemList.get(0).getItem().getUnit().getUnits();
			  Double newBalanceQty=0.0;
			  Double newCompletedQty=0.0;
			  Double oldCompletedQty=soItemList.get(0).getCompletedQty();
			  Double oldProductionQty=soItemList.get(0).getProductionQty();
			  Double oldDisaptchedQty=soItemList.get(0).getDispatchedQty();
			  Double totalQty=soItemList.get(0).getQuantity();
			  if(unitsValue.equalsIgnoreCase("Kgs")|| unitsValue.equalsIgnoreCase("Kg")){
				  if(oldCompletedQty>oldweight)
				    newCompletedQty=(oldCompletedQty-oldweight)+weightValid;
				  else
				    newCompletedQty=weightValid;  
			  }else{
				  if(oldCompletedQty>oldStockQty)
				    newCompletedQty=(oldCompletedQty-oldStockQty)+stockQtyValid;
				  else
				    newCompletedQty=stockQtyValid;
			  }
			  if(totalQty>(oldProductionQty+newCompletedQty+oldDisaptchedQty)){
				  newBalanceQty=totalQty-(oldProductionQty+newCompletedQty+oldDisaptchedQty);
			  }
		
			  
			  
			  
				SalesOrderItemsDTO soItemDTO=new SalesOrderItemsDTO();
		  		soItemDTO.setOrderDetailId(soItemList.get(0).getOrderDetailId());
		  		soItemDTO.setOrderId(soItemList.get(0).getOrder().getOrderId());
		  		soItemDTO.setItemId(soItemList.get(0).getItem().getItemId());
		  		soItemDTO.setQuantity(soItemList.get(0).getQuantity());
		  		soItemDTO.setBalanceQty(newBalanceQty);
		  		soItemDTO.setWeight(soItemList.get(0).getWeight());
		  		soItemDTO.setPvcWeight(soItemList.get(0).getPvcWeight());
		  		soItemDTO.setBundleSize(soItemList.get(0).getBundleSize());
		  		soItemDTO.setRate(soItemList.get(0).getRate());
		  		soItemDTO.setWoQty(soItemList.get(0).getWoQty());
		  		soItemDTO.setCompletedQty(newCompletedQty);
		  		soItemDTO.setItemCode(soItemList.get(0).getItemCode());
		  		soItemDTO.setProductionQty(oldProductionQty);
		  		soItemDTO.setDispatchedQty(oldDisaptchedQty);
		  		soItemDTO.setUpdatedBy(soItemList.get(0).getUpdatedBy());
		  		soItemDTO.setUpdatedTime(soItemList.get(0).getUpdatedTime().toString());
		  		
		  		SalesOrderItem soItem=soItemDTO.getOrderDetail();
		  		updateSalesOrderItem=orderDetailsService.update(soItem);
		 	}
		  }}}
		return new StatusResponse(updateSalesOrderItem);

	}
	
	 /**
	   * fetch sales order from store register
	   * @param storeRegId,customerId
	   * @return List<String>SalesOrderList
	   */
	@RequestMapping(value = "/fetchSalesOrder", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	List<String> fetchSalesOrder(
			@RequestParam(value = "storeRegId", required = true) Long storeRegId,
			@RequestParam(value = "customerId", required = true) Long customerId) {
		
		ArrayList<String> soNoList = new ArrayList<>();
		//Method to fetch store register item by store register id
		List<StoreRegister> storeRegList = storeRegisterService.findById(storeRegId);
		if (storeRegList.size() > 0) {
			String itemCode = storeRegList.get(0).getSalesOrderItem().getItem()	.getItemCode();
			//Method to find sales order item by item code and customer Id
			List<SalesOrderItem> soItemList = orderDetailsService.findByItemCodeAndCustomerId(itemCode, customerId);
			if (soItemList.size() > 0) {
				for (int iterator = 0; iterator < soItemList.size(); iterator++) {
					String soNo = soItemList.get(iterator).getOrder().getOrderId();
					Double stockInQuantity = soItemList.get(iterator).getCompletedQty();
					Double orderedQty = soItemList.get(iterator).getQuantity();
					String orderStatus = soItemList.get(iterator).getOrder().getOrderStatus().getStatus();
					if (orderStatus.equalsIgnoreCase("Approved")|| orderStatus.equalsIgnoreCase("Approved For Prodn")) {
					//change so status to completed even if 96% of stock is done
						if (!(stockInQuantity >= (96 * orderedQty) / 100)) {
							if (!soNoList.contains(soNo)) {
								soNoList.add(soNo);
							}//end of if (!soNoList.contains(soNo)) loop
						}//end of inner fi loop
					}
				}//end of for loop
			}//end of inner if loop
		}//end of if loop

		return soNoList;
	}
	
	 /**
	   * QC Approval/reject process of store items
	   * @param remarks,status,selected store register id
	   * @return List<String>
	   */
	@RequestMapping(value = "/approveOrRejectQC", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	List<String> approveQC(
			@RequestParam(value = "remarks", required = true) String remarks,
			@RequestParam(value = "status", required = true) String status,
			@RequestParam(value = "idsOfSelectedRows[]", required = false) Long[] idsOfSelectedRows)
		 {
		List<String> retstatus=new ArrayList<>();
		//fetch logged in user
		CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();;
	 	String supervisor = user.getFirstName()+" "+user.getLastName();
		//ArrayList<Long> soNoList = new ArrayList<>();
		List<StoreRegister> storeRegList = null;
		
		for (int i = 0; i < idsOfSelectedRows.length; i++) {
		 storeRegList = storeRegisterService.findById(idsOfSelectedRows[i]);

			if(storeRegList.size()>0){
				
				Long  soItemId=storeRegList.get(0).getSalesOrderItem().getOrderDetailId();	
				List<SalesOrderItem>soItemsList=orderDetailsService.findById(soItemId);
				String itemUnit=null;
				Double orderedQty=0.0;
				Double oldProductionQty=0.0;
				Double oldCompletedQty=0.0;
				Double oldBalanceQty=0.0;
				Double newProductionQty=0.0;
				Double newCompletedQty=0.0;
				Double newBalanceQty=0.0;
				Double dispatchedQty=0.0;
				Boolean updateStoreRegStatus=false;
				if(soItemsList.size()>0){
					itemUnit=soItemsList.get(0).getItem().getUnit().getUnits();
					  Double newStockQty=0.0;
					  orderedQty=soItemsList.get(0).getQuantity();
					
					oldProductionQty=soItemsList.get(0).getProductionQty();
					oldCompletedQty=soItemsList.get(0).getCompletedQty();
					oldBalanceQty=soItemsList.get(0).getBalanceQty();
					dispatchedQty=soItemsList.get(0).getDispatchedQty();
					
					//Calculating production qty,balance qty,completed qty based on qc reject/approve and item type
					  if(itemUnit.equalsIgnoreCase("Kgs") || itemUnit.equalsIgnoreCase("Kg") )
					      newStockQty=storeRegList.get(0).getWeight();
					else 
						 newStockQty=storeRegList.get(0).getStockQty();
				
					  
				//Check status change condition and update balancy qty of sales order item
					 if(storeRegList.get(0).getQcStatus().equalsIgnoreCase("Pending") && status.equalsIgnoreCase("Approved")){  
						   newProductionQty=oldProductionQty;
						   newCompletedQty=oldCompletedQty;
						   newBalanceQty=oldBalanceQty; 
					 } //end of  if loop:Pending to Approved
					 else if(storeRegList.get(0).getQcStatus().equalsIgnoreCase("Pending") && (status.equalsIgnoreCase("Scrap")||status.equalsIgnoreCase("Rework"))){
				     	   newProductionQty=oldProductionQty+newStockQty;
				     	   if(oldCompletedQty>newStockQty)
						   newCompletedQty=oldCompletedQty-newStockQty;	
				     	   else
				     		newCompletedQty=0.0;
				 		  if(orderedQty>(newProductionQty+newCompletedQty+dispatchedQty))
							   newBalanceQty=orderedQty-(newProductionQty+newCompletedQty+dispatchedQty);
					      else
							  newBalanceQty=0.0; 
					 }//end of else if loop:Pending to Scrap/Rework
					 else if(storeRegList.get(0).getQcStatus().equalsIgnoreCase("Approved") && status.equalsIgnoreCase("Pending")){   
						   newProductionQty=oldProductionQty;
						   newCompletedQty=oldCompletedQty;
						   newBalanceQty=oldBalanceQty; 
					 } //end of else if loop:Approved to pending
					 else if(storeRegList.get(0).getQcStatus().equalsIgnoreCase("Approved") && (status.equalsIgnoreCase("Scrap")||status.equalsIgnoreCase("Rework"))){
				     	   newProductionQty=oldProductionQty+newStockQty;
				     	   if(oldCompletedQty>newStockQty)
						   newCompletedQty=oldCompletedQty-newStockQty;	
				     	   else
				     		newCompletedQty=0.0;
				 		  if(orderedQty>(newProductionQty+newCompletedQty+dispatchedQty))
							   newBalanceQty=orderedQty-(newProductionQty+newCompletedQty+dispatchedQty);
					      else
							  newBalanceQty=0.0; 
					}//end of else if loop :Approved to Scrap/Rework
					
					 else if(storeRegList.get(0).getQcStatus().equalsIgnoreCase("Rejected") && status.equalsIgnoreCase("Approved")){
						 newCompletedQty=oldCompletedQty+newStockQty;	
    			     	 if(oldProductionQty>newStockQty)
				     		  newProductionQty=oldProductionQty-newStockQty;
				     	   else
				     		  newProductionQty=0.0;
				 		  if(orderedQty>(newProductionQty+newCompletedQty+dispatchedQty))
							   newBalanceQty=orderedQty-(newProductionQty+newCompletedQty+dispatchedQty);
					      else
							  newBalanceQty=0.0;
					   }//end of if loop :Rejected to Approved
					 else if(storeRegList.get(0).getQcStatus().equalsIgnoreCase("Rejected") && status.equalsIgnoreCase("Pending")){
						 newCompletedQty=oldCompletedQty+newStockQty;	
    			     	 if(oldProductionQty>newStockQty)
				     		  newProductionQty=oldProductionQty-newStockQty;
				     	   else
				     		  newProductionQty=0.0;
				 		  if(orderedQty>(newProductionQty+newCompletedQty+dispatchedQty))
							   newBalanceQty=orderedQty-(newProductionQty+newCompletedQty+dispatchedQty);
					      else
							  newBalanceQty=0.0;
					   }//end of if loop :Rejected to Pending
					 
					 else{
						   newProductionQty=oldProductionQty;
						   newCompletedQty=oldCompletedQty;
						   newBalanceQty=oldBalanceQty; 
					 }
			
	
					   StoreRegisterDTO storeRegisterDTO=new StoreRegisterDTO();
			    	   storeRegisterDTO.setStoreRegisterId(storeRegList.get(0).getStoreRegisterId());
			    	   storeRegisterDTO.setStoreId(storeRegList.get(0).getStore().getStoreId());
			    	   storeRegisterDTO.setItemCode(storeRegList.get(0).getSalesOrderItem().getItem().getItemCode());
			    	   storeRegisterDTO.setWorkOrderNo(storeRegList.get(0).getProductionWorkOrder().getWorkOrderNo());
			    	   storeRegisterDTO.setCustomerName(storeRegList.get(0).getSalesOrderItem().getOrder().getCustomer().getCustomerName());
			    	   storeRegisterDTO.setStockQty(storeRegList.get(0).getStockQty());
	           		   storeRegisterDTO.setBundleId(storeRegList.get(0).getBundleId());
			    	   storeRegisterDTO.setOrderId(storeRegList.get(0).getSalesOrderItem().getOrder().getOrderId());
			    	   storeRegisterDTO.setOrderDetailId(storeRegList.get(0).getSalesOrderItem().getOrderDetailId());
			    	   storeRegisterDTO.setItemId(storeRegList.get(0).getSalesOrderItem().getItem().getItemId());
			    	   storeRegisterDTO.setPackingSlipNo(storeRegList.get(0).getPackingSlipNo());
			    	   storeRegisterDTO.setSupervisor(storeRegList.get(0).getSupervisor());
			    	   storeRegisterDTO.setQcSupervisor(supervisor);
			    	
			    	   storeRegisterDTO.setWeight(storeRegList.get(0).getWeight());
			    	   storeRegisterDTO.setBagWeight(storeRegList.get(0).getBagWeight());
				     String qcStatus="";
				//set qc status and reject status based on status value
				if(status.equalsIgnoreCase("Approved")){
					storeRegisterDTO.setRejectStatus("");
					storeRegisterDTO.setQcStatus("Approved");
					storeRegisterDTO.setRemarks(remarks);
					qcStatus="Approved";
				}//end of if loop
				else if(status.equalsIgnoreCase("Scrap")){
					storeRegisterDTO.setRejectStatus(status);
					storeRegisterDTO.setQcStatus("Rejected");
					storeRegisterDTO.setRemarks(remarks);
					qcStatus="Rejected";
				}//end of first else if
				else if(status.equalsIgnoreCase("Rework")){
					storeRegisterDTO.setRejectStatus(status);
					storeRegisterDTO.setQcStatus("Rejected");
					storeRegisterDTO.setRemarks(remarks);
					qcStatus="Rejected";
				}//end of second else if
				else if(status.equalsIgnoreCase("Pending")){
					storeRegisterDTO.setRejectStatus("");
					storeRegisterDTO.setQcStatus("Pending");
					storeRegisterDTO.setRemarks(remarks);
					qcStatus="Pending";
				}//end of second else if
				
		    	   StoreRegister storeRegisters=storeRegisterDTO.getStoreRegister();
		    	   updateStoreRegStatus=storeRegisterService.update(storeRegisters);
		    	      String soNo=storeRegList.get(0).getSalesOrderItem().getOrder().getOrderId();
		    	       String woNo=storeRegList.get(0).getProductionWorkOrder().getWorkOrderNo();
			    	   String bundleId=storeRegList.get(0).getBundleId();
			    	   Long soItemid=storeRegList.get(0).getSalesOrderItem().getOrderDetailId();
			    	   Double stockInQty=storeRegList.get(0).getStockQty();
			    	   Double stockWeight=storeRegList.get(0).getWeight();
			    	   String itemCode=storeRegList.get(0).getSalesOrderItem().getItem().getItemCode();
			    	   String confirmStatus="Yes";
			    	   String confirmSemiFinishedStock="No";
			    	   List<SemifinishedStockOut>semifinishedStockList=semifinishedStockOutService.findByOrderIdAndItemCodeAndBundleIdAndWorkOrderAndConfirmStatus(soNo, itemCode, bundleId, woNo, confirmSemiFinishedStock);
			    	   if(updateStoreRegStatus==true && semifinishedStockList.size()>0){
		             		SemifinishedStockOutDTO semifinishedStockOutDTO = new SemifinishedStockOutDTO();
		             		semifinishedStockOutDTO.setSemifinishedStockOutId(semifinishedStockList.get(0).getSemifinishedStockOutId());
		             		semifinishedStockOutDTO.setStockedOutFor(semifinishedStockList.get(0).getProductionWorkOrder().getWorkOrderNo());
		             		semifinishedStockOutDTO.setWorkOrderNo(semifinishedStockList.get(0).getProductionWorkOrders().getWorkOrderNo());
		             		semifinishedStockOutDTO.setStoreId(semifinishedStockList.get(0).getStore().getStoreId());
		             		semifinishedStockOutDTO.setOrderDetailId(semifinishedStockList.get(0).getSalesOrderItem().getOrderDetailId());
		             		semifinishedStockOutDTO.setOrderId(semifinishedStockList.get(0).getSalesOrderItem().getOrder().getOrderId());
		             		semifinishedStockOutDTO.setItemId(semifinishedStockList.get(0).getSalesOrderItem().getItem().getItemId());
		             		semifinishedStockOutDTO.setItemCode(semifinishedStockList.get(0).getSalesOrderItem().getItem().getItemCode());
		             		semifinishedStockOutDTO.setStockOutQty(semifinishedStockList.get(0).getStockOutQty());
                         	semifinishedStockOutDTO.setBundleId(semifinishedStockList.get(0).getBundleId());
		             		semifinishedStockOutDTO.setWeight(semifinishedStockList.get(0).getWeight());
		             		semifinishedStockOutDTO.setSupervisor(semifinishedStockList.get(0).getSupervisor());
		             		semifinishedStockOutDTO.setConfirmStatus(semifinishedStockList.get(0).getConfirmStatus());
		             		semifinishedStockOutDTO.setQcSupervisor(supervisor);
		             		semifinishedStockOutDTO.setQcStatus(qcStatus);
		        
				  			        SemifinishedStockOut semifinishedStockOuts = semifinishedStockOutDTO.getSemifinishedStockOut();
				  				    semifinishedStockOutService.update(semifinishedStockOuts);//create store register entry
			    	   }
			    	   List<StockIn>stockInList=stockInService.findBySoNoAndWoNoAndBundleIdAndSoItemIdAndQuantity(woNo,bundleId,soItemid,stockInQty,stockWeight,confirmStatus);
		           	   if(updateStoreRegStatus==true && stockInList.size()>0){
		             		StockInDTO stockInDTO = new StockInDTO();
		  				    stockInDTO.setStockInId(stockInList.get(0).getStockInId());
		  					stockInDTO.setStoreId(stockInList.get(0).getStore().getStoreId());
		  					stockInDTO.setOrderDetailId(stockInList.get(0).getSalesOrderItem().getOrderDetailId());
		  					stockInDTO.setOrderId(stockInList.get(0).getSalesOrderItem().getOrder().getOrderId());
		  					stockInDTO.setItemId(stockInList.get(0).getSalesOrderItem().getItem().getItemId());
		  					stockInDTO.setItemCode(stockInList.get(0).getSalesOrderItem().getItem().getItemCode());
		  					stockInDTO.setSoItemQty(stockInList.get(0).getSalesOrderItem().getQuantity());
		  					stockInDTO.setWorkOrderNo(stockInList.get(0).getProductionWorkOrder().getWorkOrderNo());
		  					stockInDTO.setQcStatus(status);
		  					stockInDTO.setStockQty(stockInList.get(0).getStockQty());
		  					stockInDTO.setCustomerName(stockInList.get(0).getSalesOrderItem().getOrder().getCustomer().getCustomerName());
		  					stockInDTO.setBundleId(stockInList.get(0).getBundleId());
		  					stockInDTO.setWeight(stockInList.get(0).getWeight());
		  					stockInDTO.setBatchNo(stockInList.get(0).getBatchNo());
		  					stockInDTO.setConfirmStatus(stockInList.get(0).getConfirmStatus());
		  				    stockInDTO.setSupervisor(stockInList.get(0).getSupervisor());
		  					if(stockInList.get(0).getStockInDateTime()!=null){
								stockInDTO.setStockInDateTime(stockInList.get(0).getStockInDateTime().toString());
							}
		  			        StockIn stockIns = stockInDTO.getStockIn();
		  				    stockInService.update(stockIns);//create store register entry
		  		  
				    	   }//end of  if(updateStoreRegStatus==true && stockInList.size()>0) loop
					Long orderDetailId=storeRegList.get(0).getSalesOrderItem().getOrderDetailId();
					String workOrderNo=storeRegList.get(0).getProductionWorkOrder().getWorkOrderNo();
					String bundleIds=storeRegList.get(0).getBundleId();
					//fetch stock out by sales order item id and work order no and bundle id
					List<StockOut>stockOutList=stockOutService.findByOrderDetailIdWorkOrderNoBundleId(orderDetailId, workOrderNo, bundleIds);
					if(stockOutList.size()>0){
						StockOutDTO stockOutDTO=new StockOutDTO();
						stockOutDTO.setStockOutId(stockOutList.get(0).getStockOutId());
						stockOutDTO.setStoreId(stockOutList.get(0).getStore().getStoreId());
						stockOutDTO.setOrderDetailId(stockOutList.get(0).getSalesOrderItem().getOrderDetailId());
						stockOutDTO.setOrderId(stockOutList.get(0).getSalesOrderItem().getOrder().getOrderId());
						stockOutDTO.setItemId(stockOutList.get(0).getSalesOrderItem().getItem().getItemId());
						stockOutDTO.setItemCode(stockOutList.get(0).getSalesOrderItem().getItem().getItemCode());
						stockOutDTO.setSoItemQty(stockOutList.get(0).getSalesOrderItem().getQuantity());
						stockOutDTO.setWorkOrderNo(stockOutList.get(0).getProductionWorkOrder().getWorkOrderNo());

						stockOutDTO.setStockOutQty(stockOutList.get(0).getStockOutQty());
						stockOutDTO.setQcStatus(storeRegList.get(0).getQcStatus());
						stockOutDTO.setCustomerName(stockOutList.get(0).getSalesOrderItem().getOrder().getCustomer().getCustomerName());
						stockOutDTO.setBundleId(bundleIds);
						stockOutDTO.setPackingSlipNo(stockOutList.get(0).getPackingSlipNo());
						stockOutDTO.setSupervisor(supervisor);
						stockOutDTO.setWeight(stockOutList.get(0).getWeight());
						stockOutDTO.setRemarks(stockOutList.get(0).getRemarks());
						stockOutDTO.setConfirmStatus(stockOutList.get(0).getConfirmStatus());
						stockOutDTO.setBagWeight(stockOutList.get(0).getBagWeight());
						stockOutDTO.setDeliveryChallanNo(stockOutList.get(0).getDeliveryChallanNo());
						stockOutDTO.setQcSupervisor(storeRegList.get(0).getQcSupervisor());
						stockOutService.update(stockOutDTO.getStockOut());//update stockOut

	
					}//end of if(stockOutList.size()>0) loop
				}//end of if(updateStoreRegStatus==true) loop
				retstatus.add("updated");//add status message to list
				
				
				
				
				if(updateStoreRegStatus==true){
					//set updated production qty,balance qty and completed qty of sales order item
					SalesOrderItemsDTO salesOrderItemsDTO=new SalesOrderItemsDTO();
					salesOrderItemsDTO.setOrderDetailId(soItemsList.get(0).getOrderDetailId());
					salesOrderItemsDTO.setOrderId(soItemsList.get(0).getOrder().getOrderId());
					salesOrderItemsDTO.setItemId(soItemsList.get(0).getItem().getItemId());
					salesOrderItemsDTO.setQuantity(soItemsList.get(0).getQuantity());
				    salesOrderItemsDTO.setBalanceQty(newBalanceQty);
				    salesOrderItemsDTO.setProductionQty(newProductionQty);
				    salesOrderItemsDTO.setCompletedQty(newCompletedQty);
				    salesOrderItemsDTO.setWoQty(soItemsList.get(0).getWoQty());
				    salesOrderItemsDTO.setDispatchedQty(soItemsList.get(0).getDispatchedQty());
				    salesOrderItemsDTO.setWeight(soItemsList.get(0).getWeight());
				    salesOrderItemsDTO.setBundleSize(soItemsList.get(0).getBundleSize());
				    salesOrderItemsDTO.setUnit(soItemsList.get(0).getItem().getUnit().getUnits());
				    salesOrderItemsDTO.setRate(soItemsList.get(0).getRate());
					salesOrderItemsDTO.setItemCode(soItemsList.get(0).getItem().getItemCode());
				    salesOrderItemsDTO.setPvcWeight(soItemsList.get(0).getPvcWeight());
					salesOrderItemsDTO.setUpdatedBy(soItemsList.get(0).getUpdatedBy());
		    		SalesOrderItem soItems=salesOrderItemsDTO.getOrderDetail();
			    	orderDetailsService.update(soItems);//update sales order item
				 }//end of if(updateStoreRegStatus==true) loop
	
			}
			
		}//end of if loop
		
		return retstatus;
	}
}
	
/*	 *//**
	   * QC Approval/reject process of store items
	   * @param remarks,status,selected store register id
	   * @return List<String>
	   *//*
	@RequestMapping(value = "/revertToPending", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	List<String> revertToPending(
			@RequestParam(value = "remarks", required = true) String remarks,
			@RequestParam(value = "status", required = true) String status,
			@RequestParam(value = "idsOfSelectedRows[]", required = false) Long[] idsOfSelectedRows)
		 {
		List<String> resetStatus=new ArrayList<>();
		//fetch logged in user
		CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();;
	 	String supervisor = user.getFirstName()+" "+user.getLastName();
		//ArrayList<Long> soNoList = new ArrayList<>();
		List<StoreRegister> storeRegList = null;
		for (int i = 0; i < idsOfSelectedRows.length; i++) {
			 storeRegList = storeRegisterService.findById(idsOfSelectedRows[i]);
			
			 if(storeRegList.size()>0){
				  Boolean updateStoreRegStatus=false;
				   StoreRegisterDTO storeRegisterDTO=new StoreRegisterDTO();
		    	   storeRegisterDTO.setStoreRegisterId(storeRegList.get(0).getStoreRegisterId());
		    	   storeRegisterDTO.setStoreId(storeRegList.get(0).getStore().getStoreId());
		    	   storeRegisterDTO.setItemCode(storeRegList.get(0).getSalesOrderItem().getItem().getItemCode());
		    	   storeRegisterDTO.setWorkOrderNo(storeRegList.get(0).getProductionWorkOrder().getWorkOrderNo());
		    	   storeRegisterDTO.setCustomerName(storeRegList.get(0).getSalesOrderItem().getOrder().getCustomer().getCustomerName());
		    	   storeRegisterDTO.setStockQty(storeRegList.get(0).getStockQty());
           		   storeRegisterDTO.setBundleId(storeRegList.get(0).getBundleId());
		    	   storeRegisterDTO.setOrderId(storeRegList.get(0).getSalesOrderItem().getOrder().getOrderId());
		    	   storeRegisterDTO.setOrderDetailId(storeRegList.get(0).getSalesOrderItem().getOrderDetailId());
		    	   storeRegisterDTO.setItemId(storeRegList.get(0).getSalesOrderItem().getItem().getItemId());
		    	   storeRegisterDTO.setPackingSlipNo(storeRegList.get(0).getPackingSlipNo());
		    	   storeRegisterDTO.setSupervisor(storeRegList.get(0).getSupervisor());
		     	   storeRegisterDTO.setQcStatus("Pending");
		    	   storeRegisterDTO.setQcSupervisor(supervisor);
		    	   storeRegisterDTO.setRejectStatus("");
		    	   storeRegisterDTO.setRemarks(remarks);
		    	   storeRegisterDTO.setWeight(storeRegList.get(0).getWeight());
		    	   storeRegisterDTO.setBagWeight(storeRegList.get(0).getBagWeight());
		    	   StoreRegister storeRegisters=storeRegisterDTO.getStoreRegister();
		    	   updateStoreRegStatus=storeRegisterService.update(storeRegisters);
		    	   String woNo=storeRegList.get(0).getProductionWorkOrder().getWorkOrderNo();
		    	   String bundleId=storeRegList.get(0).getBundleId();
		    	   Long soItemid=storeRegList.get(0).getSalesOrderItem().getOrderDetailId();
		    	   Double stockInQty=storeRegList.get(0).getStockQty();
		    	   Double stockWeight=storeRegList.get(0).getWeight();
		    	   String confirmStatus="Yes";
				   List<StockIn>stockInList=stockInService.findBySoNoAndWoNoAndBundleIdAndSoItemIdAndQuantity(woNo,bundleId,soItemid,stockInQty,stockWeight,confirmStatus);
             	   if(updateStoreRegStatus==true && stockInList.size()>0){
             		StockInDTO stockInDTO = new StockInDTO();
  				    stockInDTO.setStockInId(stockInList.get(0).getStockInId());
  					stockInDTO.setStoreId(stockInList.get(0).getStore().getStoreId());
  					stockInDTO.setOrderDetailId(stockInList.get(0).getSalesOrderItem().getOrderDetailId());
  					stockInDTO.setOrderId(stockInList.get(0).getSalesOrderItem().getOrder().getOrderId());
  					stockInDTO.setItemId(stockInList.get(0).getSalesOrderItem().getItem().getItemId());
  					stockInDTO.setItemCode(stockInList.get(0).getSalesOrderItem().getItem().getItemCode());
  					stockInDTO.setSoItemQty(stockInList.get(0).getSalesOrderItem().getQuantity());
  					stockInDTO.setWorkOrderNo(stockInList.get(0).getProductionWorkOrder().getWorkOrderNo());
  					stockInDTO.setQcStatus("Pending");
  					stockInDTO.setStockQty(stockInList.get(0).getStockQty());
  					stockInDTO.setCustomerName(stockInList.get(0).getSalesOrderItem().getOrder().getCustomer().getCustomerName());
  					stockInDTO.setBundleId(stockInList.get(0).getBundleId());
  					stockInDTO.setWeight(stockInList.get(0).getWeight());
  					stockInDTO.setBatchNo(stockInList.get(0).getBatchNo());
  					stockInDTO.setConfirmStatus(stockInList.get(0).getConfirmStatus());
  				    stockInDTO.setSupervisor(stockInList.get(0).getSupervisor());
  			        StockIn stockIns = stockInDTO.getStockIn();
  				    stockInService.update(stockIns);//create store register entry
  		  
		    	   }
		     }
		}
		
			return resetStatus;
		
		 }	
}*/
