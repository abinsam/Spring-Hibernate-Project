package org.balajicables.salesmanager.controller;

import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import org.balajicables.salesmanager.common.JqgridFilter;
import org.balajicables.salesmanager.common.JqgridObjectMapper;
import org.balajicables.salesmanager.common.JqgridResponse;
import org.balajicables.salesmanager.common.StoreRegisterMapper;
import org.balajicables.salesmanager.dto.StoreRegisterDTO;
import org.balajicables.salesmanager.model.SalesOrder;
import org.balajicables.salesmanager.model.StoreRegister;
import org.balajicables.salesmanager.service.CustomerService;
import org.balajicables.salesmanager.service.OrderService;
import org.balajicables.salesmanager.service.StoreRegisterService;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
/**
* This class demonstrates store register report module
* @author Abin Sam
*/
@Controller
@RequestMapping("/storeRegisterReport")
public class StoreRegisterReportController {

	
	@Resource
	private StoreRegisterService storeRegisterService;
	
	@Resource 
	private OrderService orderService;

	@Resource
	private CustomerService customerService;
	
	
	 /**
	   * This method returns storeRegisterReport.jsp.
	   * Fetch all customers and sales order Nos based on month and year selected
	   * @param Model to set the attribute.
	   * @return storeRegisterReport.jsp.
	   */
	
	@RequestMapping(method = RequestMethod.GET)
	public String getStockOnDatePage(Model model) {
		ArrayList<String> salesOrders = new ArrayList<>();
		List<SalesOrder>salesOrderList=orderService.findAll();
		
		
		for (int iterator = 0; iterator < salesOrderList.size(); iterator++) {
			String woNo = salesOrderList.get(iterator).getOrderId();
         	if (!salesOrders.contains(woNo)) {
				salesOrders.add(woNo);
			}//end of if loop
		}//end of for loop
		
		Collections.sort(salesOrders,Collections.reverseOrder());//sort salesorder in descending order
		model.addAttribute("orderIds",salesOrders);//add sales orders to model attribute
		model.addAttribute("customers", customerService.findAll());//add customers to model attribute
		return "storeRegisterReport";
	}
	
	
	 /**
	   * This method to populate salesOrders nos based on customer Id
	   * Fetch  salesOrders Nos to populate on select box
	   * @param customerId
	   * @return ArrayList<String> salesOrders No
	   */
	@RequestMapping(value = "/getSalesOrders", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	ArrayList<String> getSalesOrders(
			@RequestParam("customerId") Long customerId) {
		/*Method to fetch sales orders based on customer*/
		List<SalesOrder> salesOrdersList = orderService.findByCustomerId(customerId);
		ArrayList<String> salesOrders = new ArrayList<>();
		for (int iterator = 0; iterator < salesOrdersList.size(); iterator++) {
			String soNo = salesOrdersList.get(iterator).getOrderId();
			if (!salesOrders.contains(soNo)) {
				salesOrders.add(soNo);
			}//end of if loop
		}//end of for loop
		Collections.sort(salesOrders,Collections.reverseOrder());//sort salesorder in descending order
		return salesOrders;
	}	
	
	 /**
	   * This method to fetch store Regsiter item details based on search parameters
	   * Fetch store Regsiter item details for grid
	   * @param searchObject,filters,pageNumber,rowsPerPage,sortColName,sortOrder
	   * @return JqgridResponse<DeliveryChallanItemsDTO> response
	   */
	@RequestMapping(value="/records", produces="application/json", method=RequestMethod.POST)
	public @ResponseBody
	JqgridResponse<StoreRegisterDTO> records(
			@RequestParam(value="searchObject", required=false) String searchObject,
		    @RequestParam("_search") Boolean search,
    		@RequestParam(value="filters", required=false) String filters,
			@RequestParam(value = "page", required = false) Integer pageNumber,
			@RequestParam(value = "rows", required = false) Integer rowsPerPage,
			@RequestParam(value = "sidx", required = false) String sortColName,
			@RequestParam(value = "sord", required = false, defaultValue = "asc") String sortOrder) throws ParseException {
		 
		 /*grid column sorting*/
		  if(sortColName.equalsIgnoreCase("customerCode")){
				sortColName="salesOrderItem.orders.customer.customerCode";
			}
		  if(sortColName.equalsIgnoreCase("customerName")){
				sortColName="salesOrderItem.orders.customer.customerName";
			}
		  if(sortColName.equalsIgnoreCase("itemDescription")){
				sortColName="salesOrderItem.items.itemDescription";
			}
		  if(sortColName.equalsIgnoreCase("workOrderNo")){
				sortColName="productionWorkOrder.workOrderNo";
			}
		  if(sortColName.equalsIgnoreCase("status")){
				sortColName="salesOrderItem.orders.orderStatus.status";
			}
		if (searchObject != null ) {
			//Method to fetch store regsiter item based on default search
	           return getFilteredRecords(searchObject, pageNumber-1,rowsPerPage,sortColName,sortOrder);
	   } //end of if (searchObject != null )  loop
		if(search==true){
			//Method to fetch store regsiter item based on  search parameter
			   return getFilteredRecords(filters, pageNumber-1, rowsPerPage,sortColName,sortOrder);
			}
		else{
			    	   //Method to fetch store Regsiter item when search parameter is null
			            Page<StoreRegister>storeRegItem=  storeRegisterService.getPagedStore(pageNumber - 1,
						                                        rowsPerPage, sortColName, sortOrder);
			    		/*Intialize JQ grid response of type StoreRegisterDTO*/
			            JqgridResponse<StoreRegisterDTO> response = new JqgridResponse<StoreRegisterDTO>();
			    		/*Method to set StoreRegister item list to StoreRegisterDTO*/
			            List<StoreRegisterDTO> storeRegsiterDTOs = convertToStoreDTO(storeRegItem.getContent());
						response.setRows(storeRegsiterDTOs);
						response.setRecords(Long.valueOf(storeRegItem.getTotalElements()).toString());
						response.setTotal(Long.valueOf(storeRegItem.getTotalPages()).toString());
						response.setPage(Integer.valueOf(storeRegItem.getNumber()+1).toString());
						return response;


		}//end of else loop

	}
	
	 /**
	   * This method to fetch store regsiter item based on search parameter and set response to JQGRID
	   * Fetch store Regsiter item details for grid
	   * @param filters,pageNumber,rowsPerPage,sortColName,sortOrder
	   * @return JqgridResponse<StoreRegisterDTO> response
	   */
	private JqgridResponse<StoreRegisterDTO> getFilteredRecords(
			String filters, int pagenumber, Integer rows,
			String sortColName, String sortOrder) {
		    
		    String qOrderId = null;
	        Long qCustomerId = null;
	       
	      //JQ grid filtered rows based on order id or customer id or both
	      	JqgridFilter jqgridFilter = JqgridObjectMapper.map(filters);
	        for (JqgridFilter.Rule rule: jqgridFilter.getRules()) {
	                if (rule.getField().equals("orderId"))
	                	   qOrderId = rule.getData();
	              
	                else if (rule.getField().equals("customerId")){
		             	  if(rule.getData()=="" || rule.getData()==null)
		             		 qCustomerId =(long) 0;
		             		  else
		             		 qCustomerId = Long.valueOf(rule.getData());
		               }
                 
	         }//end of for loop
	        //Method to gfetch store register items based on order id and customer Id
	        List<StoreRegister>storeRegItem=
	           storeRegisterService.fetchByQcStatusSearch
	        		(qOrderId, qCustomerId,pagenumber,rows,sortColName,sortOrder);
	   
	        List<StoreRegister> pagedList;
	        int fromIndex = Math.min(storeRegItem.size(), pagenumber * rows);//from index of JQ grid
	        int toIndex = Math.min(storeRegItem.size(), fromIndex + rows);//to index of JQ grid
	        
	        if (fromIndex == 0 && toIndex == (storeRegItem.size() - 1)){
	            pagedList = storeRegItem;
	        }//end of if loop
	        else{
	           pagedList = storeRegItem.subList(fromIndex, toIndex);
	        }//end of else loop

	    	List<StoreRegisterDTO> storeRegisterDto = StoreRegisterMapper.map(pagedList);
    		/*Intialize JQ grid response of type StoreRegisterDTO*/
	        JqgridResponse<StoreRegisterDTO> response = new JqgridResponse<StoreRegisterDTO>();
	        
	        response.setRows(storeRegisterDto);
	        response.setRecords(Long.valueOf(storeRegItem.size()).toString());
	        if(storeRegItem.size()>0)
	        response.setTotal(Integer.valueOf((int)Math.ceil(Double.valueOf(storeRegItem.size())/Double.valueOf(rows.toString()))).toString());
	       else
	       response.setTotal("0");
	       response.setPage(Integer.valueOf(pagenumber+1).toString());
	       return response;
	}
	
	
	 /**
	   * This method to fetch sales orderof items present in store register
	   * Fetch store Regsiter item details for grid
	   * @param salesOrderNo
	   * @return ArrayList<String> salesOrder
	   */
	@RequestMapping(value = "/getDcDetails", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	ArrayList<String> getDcDetailsnNos(
			@RequestParam("salesOrderNo") String salesOrderNo, Model model) {
		
		ArrayList<String> salesOrder = new ArrayList<>();
		//Method to fetch store register items by sales order no
		List<StoreRegister> salesOrderList=storeRegisterService.findByOrderId(salesOrderNo);
	   	if(salesOrderList.size()>0){
			salesOrder.add(salesOrderList.get(0).getSalesOrderItem().getOrder().getCustomer().getCustomerId().toString());
	    }//end of if loop
		return salesOrder;
	}
	
	
	 /**
	   * This method to set store register to store register dto
	   * @param StoreRegister
	   * @return List<StoreRegisterDTO>
	   */
	private List<StoreRegisterDTO> convertToStoreDTO(List<StoreRegister> storeRegs) {
		List<StoreRegisterDTO> storeRegDTOs = new ArrayList<>();
		for(StoreRegister storeReg : storeRegs) {
			StoreRegisterDTO storeRegDTO=new StoreRegisterDTO();
			storeRegDTO.setStoreRegisterId(storeReg.getStoreRegisterId());
			storeRegDTO.setStoreId(storeReg.getStore().getStoreId());
			storeRegDTO.setStoreAddress(storeReg.getStore().getStoreAddress());
			storeRegDTO.setItemId(storeReg.getSalesOrderItem().getItem().getItemId());
			storeRegDTO.setItemCode(storeReg.getSalesOrderItem().getItem().getItemCode());
			storeRegDTO.setOrderId(storeReg.getSalesOrderItem().getOrder().getOrderId());
			storeRegDTO.setCustomerId(storeReg.getSalesOrderItem().getOrder().getCustomer().getCustomerId());
			storeRegDTO.setCustomerName(storeReg.getSalesOrderItem().getOrder().getCustomer().getCustomerName());
			storeRegDTO.setCustomerCode(storeReg.getSalesOrderItem().getOrder().getCustomer().getCustomerCode());
			storeRegDTO.setWorkOrderNo(storeReg.getProductionWorkOrder().getWorkOrderNo());
			storeRegDTO.setStockQty(storeReg.getStockQty());
			storeRegDTO.setBundleId(storeReg.getBundleId());
			storeRegDTO.setOrderDetailId(storeReg.getSalesOrderItem().getOrderDetailId());
			storeRegDTO.setItemDescription(storeReg.getSalesOrderItem().getItem().getItemDescription());
			storeRegDTO.setPackingSlipNo(storeReg.getPackingSlipNo());
			storeRegDTO.setSupervisor(storeReg.getSupervisor());
			storeRegDTO.setWeight(storeReg.getWeight());
			storeRegDTO.setUnits(storeReg.getSalesOrderItem().getItem().getUnit().getUnits());
			storeRegDTO.setBagWeight(storeReg.getBagWeight());
			storeRegDTO.setStatus(storeReg.getSalesOrderItem().getOrder().getOrderStatus().getStatus());
			storeRegDTO.setRejectStatus(storeReg.getRejectStatus());
			storeRegDTO.setQcSupervisor(storeReg.getQcSupervisor());
			storeRegDTO.setRemarks(storeReg.getRemarks());
			storeRegDTO.setQcStatus(storeReg.getQcStatus());
			storeRegDTO.setQcSupervisor(storeReg.getQcSupervisor());
			storeRegDTOs.add(storeRegDTO)	;
		}//end of for loop
		return storeRegDTOs;
	}

	
	 /**
	   * This method to generate stock report
	   * @param 
	   * @return
	   */
	@RequestMapping(value = "/stockReport", produces = "application/pdf", method = RequestMethod.GET)

	public void StoreRegisterReport(javax.servlet.http.HttpServletResponse response) throws IOException, InterruptedException, ParseException{
		InputStream inputStream = getClass().getClassLoader().getResourceAsStream("/org/balajicables/salesmanager/report/StoreRegisterReport.jrxml");
		Map<String, Object> hm= new HashMap<String, Object>();
	    byte[] content = ReportGenerator.newReportGenerator(inputStream,hm);
		response.setContentType("application/pdf");
        response.setHeader("Content-Disposition", "attachment;filename=" + "Stock_Report"+".pdf");
		response.setContentLength(content.length);
	    FileCopyUtils.copy(content, response.getOutputStream());
	}
	
	
	 /**
	   * This method to generate stock report based on salers orders
	   * @param salesOrderNo
	   * @return
	   */
	@RequestMapping(value = "/stockSalesOrderReport", produces = "application/pdf", method = RequestMethod.GET)
	public void StoreRegisterSOReport(@RequestParam(value = "salesOrderNo", required = true) String salesOrderNo,javax.servlet.http.HttpServletResponse response) throws IOException, InterruptedException, ParseException{
		if(salesOrderNo!=null && salesOrderNo!=""){
		InputStream inputStream = getClass().getClassLoader().getResourceAsStream("/org/balajicables/salesmanager/report/StoreRegisterSalesOrderReport.jrxml");
		
		 Map<String, Object> hm= new HashMap<String, Object>();
		 hm.put("SALES_ORDER_NO", salesOrderNo);//set sales order as report parameter
	     byte[] content = ReportGenerator.newReportGenerator(inputStream,hm);
	    
		response.setContentType("application/pdf");
        response.setHeader("Content-Disposition", "attachment;filename=" + "Stock_Report"+salesOrderNo+".pdf");
		response.setContentLength(content.length);
	    FileCopyUtils.copy(content, response.getOutputStream());
	}
	}
	
	
	 /**
	   * This method to generate stock report based on customer
	   * @param customer
	   * @return
	   */
	@RequestMapping(value = "/stockPartyReport", produces = "application/pdf", method = RequestMethod.GET)
	public void StoreRegisterPartyReport(@RequestParam(value = "customerName", required = true) String customerName,javax.servlet.http.HttpServletResponse response) throws IOException, InterruptedException, ParseException{
		if(customerName!=null && customerName!=""){
		InputStream inputStream = getClass().getClassLoader().getResourceAsStream("/org/balajicables/salesmanager/report/StoreRegisterCustomerReport.jrxml");
		
		 Map<String, Object> hm= new HashMap<String, Object>();
		 hm.put("CUSTOMER_NAME", customerName);//set customer as report parameter
	     byte[] content = ReportGenerator.newReportGenerator(inputStream,hm);
	    
		response.setContentType("application/pdf");
        response.setHeader("Content-Disposition", "attachment;filename=" + "Stock_Report"+customerName+".pdf");
		response.setContentLength(content.length);
	    FileCopyUtils.copy(content, response.getOutputStream());
	}
	}
}
