package org.balajicables.salesmanager.controller;

import java.util.ArrayList;
import java.util.List;
import javax.annotation.Resource;
import org.balajicables.salesmanager.common.JqgridFilter;
import org.balajicables.salesmanager.common.JqgridObjectMapper;
import org.balajicables.salesmanager.common.JqgridResponse;
import org.balajicables.salesmanager.common.StatusResponse;
import org.balajicables.salesmanager.common.TaxRateMapper;
import org.balajicables.salesmanager.dto.TaxRateDTO;
import org.balajicables.salesmanager.model.TaxRate;
import org.balajicables.salesmanager.service.CustomerService;
import org.balajicables.salesmanager.service.TaxRateService;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
/**
* This class demonstrates Tax Details Module.
* @author Abin Sam
*/
@Controller
@RequestMapping("/taxDetails")
public class TaxDetailsController {

	@Resource 
	private TaxRateService taxRateService;
	
	@Resource
	private CustomerService customerService;
	
	 /**
	   * This method returns taxDetails.jsp.
	   * Fetch all customers
	   * @param Model to set the attribute.
	   * @return taxDetails.jsp.
	   */
	@RequestMapping(method = RequestMethod.GET)
	public String getTaxDetails(Model model) {
		
		model.addAttribute("customers", customerService.findAll());
		return "taxDetails";
	}

	 /**
	   * This method to fetch tax details 
	   * Fetch tax details for grid
	   * @param filters,pageNumber,rowsPerPage,sortColName,sortOrder
	   * @return JqgridResponse<TaxRateDTO> response
	   */
	@RequestMapping(value = "/records", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	JqgridResponse<TaxRateDTO> records(
			@RequestParam(value = "searchObject", required = false) String searchObject,
			@RequestParam("_search") Boolean search,
			@RequestParam(value = "filters", required = false) String filters,
			@RequestParam(value = "page", required = false) Integer pageNumber,
			@RequestParam(value = "rows", required = false) Integer rowsPerPage,
			@RequestParam(value = "sidx", required = false) String sortColName,
			@RequestParam(value = "sord", required = false, defaultValue = "asc") String sortOrder) {
		/*grid column sorting*/
		  if(sortColName.equalsIgnoreCase("customerCode")){
				sortColName="customer.customerCode";
			}
		  if(sortColName.equalsIgnoreCase("customerName")){
				sortColName="customer.customerName";
			}

		if (searchObject != null
				&& !(searchObject.equalsIgnoreCase("allSearch"))) {
			return getFilteredRecords(searchObject, pageNumber - 1,
					rowsPerPage, sortColName, sortOrder);//default search fetch method
		} //end of if loop 
		else {
			//Method to fetch tax details and set response to JQgrid
			Page<TaxRate> taxRates = taxRateService.getPagedTaxes(pageNumber - 1,rowsPerPage, sortColName, sortOrder);
			/*Intialize JQ grid response of type taxrate DTO*/
			JqgridResponse<TaxRateDTO> response = new JqgridResponse<TaxRateDTO>();
			List<TaxRateDTO> taxRateDTOs = convertToDTO(taxRates.getContent());
			response.setRows(taxRateDTOs);
			response.setRecords(Long.valueOf(taxRates.getTotalElements()).toString());
			response.setTotal(Long.valueOf(taxRates.getTotalPages()).toString());
			response.setPage(Integer.valueOf(taxRates.getNumber()+1).toString());

			return response;
		}
	}
	
	 /**
	   * This method to fetch tax rate details based on search criteria
	   * Fetch  Delivery Challan Item details for grid
	   * @param deliveryChallanNo,filters,pageNumber,rowsPerPage,sortColName,sortOrder
	   * @return JqgridResponse<DeliveryChallanItemsDTO> response
	   */
	private JqgridResponse<TaxRateDTO> getFilteredRecords(String filters,
			int pagenumber, Integer rows, String sortColName, String sortOrder) {
		
		Long qCustomerId = null;
		
		JqgridFilter jqgridFilter = JqgridObjectMapper.map(filters);
		for (JqgridFilter.Rule rule : jqgridFilter.getRules()) {
	
			 if (rule.getField().equals("customerId")) {
				if (rule.getData() == "" || rule.getData() == null)
					qCustomerId = (long) 0;
				else
					qCustomerId = Long.valueOf(rule.getData());
			} 
		}//end of for loop
		List<TaxRate> taxRate = taxRateService.fetchBySearch(
	 qCustomerId, pagenumber, rows, sortColName, sortOrder);//fetch tax rate details by customer Id

		List<TaxRate> pagedList;
		int fromIndex = Math.min(taxRate.size(), pagenumber * rows);//from index of JQgrid to which response is set
		int toIndex = Math.min(taxRate.size(), fromIndex + rows);//to index of JQgrid to which response is set

		if (fromIndex == 0 && toIndex == (taxRate.size() - 1)) {
			pagedList = taxRate;
		} else {
			pagedList = taxRate.subList(fromIndex, toIndex);
		}

		List<TaxRateDTO> taxRateDto = TaxRateMapper.map(pagedList);//method to set tax details to tax rate dto
		/*Intialize JQ grid response of type taxrate DTO*/
		JqgridResponse<TaxRateDTO> response = new JqgridResponse<TaxRateDTO>();

		response.setRows(taxRateDto);
		response.setRecords(Long.valueOf(taxRate.size()).toString());
		if (taxRate.size() > 0)
			response.setTotal(Integer.valueOf(
					(int) Math.ceil(Double.valueOf(taxRate.size())
							/ Double.valueOf(rows.toString()))).toString());
		else
			response.setTotal("0");
		response.setPage(Integer.valueOf(pagenumber + 1).toString());
		return response;

	}

	 /**
	   * This Method to set TaxRate list to TaxRateDTO
	   * @param List<TaxRate> TaxRate
	   * @return List<TaxRateDTO> response
	   */
	private List<TaxRateDTO> convertToDTO(List<TaxRate> taxRates) {
		List<TaxRateDTO> taxRateDTOs = new ArrayList<>();
		for(TaxRate taxRate : taxRates) {
			
			TaxRateDTO taxRateDTO = new TaxRateDTO();
			
			taxRateDTO.setTaxRateId(taxRate.getTaxRateId());
			taxRateDTO.setCustomerId(taxRate.getCustomer().getCustomerId());
			taxRateDTO.setCustomerName(taxRate.getCustomer().getCustomerName());
			taxRateDTO.setCustomerCode(taxRate.getCustomer().getCustomerCode());
			taxRateDTO.setExciseDuty(taxRate.getExciseDuty());
			taxRateDTO.setEduCess(taxRate.getEduCess());
			taxRateDTO.setHigherEduCess(taxRate.getHigherEduCess());
			taxRateDTO.setCst(taxRate.getCst());
			taxRateDTO.setVat(taxRate.getVat());
			taxRateDTO.setFreight(taxRate.getFreight());
			taxRateDTO.setPaymentTerms(taxRate.getPaymentTerms());
			taxRateDTOs.add(taxRateDTO);
		}//end of for loop
		return taxRateDTOs;
	}

	
	 /**
	   * Crud functionality of tax rate 
	  * @param taxrateid,oper,customerId,customerName,customerCode,exciseDuty,eduCess,higherEduCess,
	  *         vat,cst,freight,paymentTerms
	   * @return StatusResponse
	   */
	@RequestMapping(value = "/crud", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	StatusResponse crud(@RequestParam Long id,
			@RequestParam String oper,
			@RequestParam(required = true) Long customerId,
			@RequestParam(required = false) String customerName,
			@RequestParam(required = false) String customerCode,
		    @RequestParam(required = false) Float exciseDuty,
			@RequestParam(required = false) Float eduCess,
			@RequestParam(required = false) Float higherEduCess,
			@RequestParam(required = false) Float vat,
			@RequestParam(required = false) Float cst,
			@RequestParam(required = false) String freight,
			@RequestParam(required = false) String paymentTerms
			) {
	
		Boolean result = false;
		
		TaxRateDTO taxRateDTO = new TaxRateDTO();
		
		taxRateDTO.setCustomerId(customerId);
		taxRateDTO.setTaxRateId(id);
		taxRateDTO.setCustomerCode(customerCode);
		taxRateDTO.setCustomerName(customerName);
		taxRateDTO.setExciseDuty(exciseDuty);
		taxRateDTO.setHigherEduCess(higherEduCess);
		taxRateDTO.setEduCess(eduCess);
		taxRateDTO.setCst(cst);
		taxRateDTO.setVat(vat);
		taxRateDTO.setFreight(freight);
		taxRateDTO.setPaymentTerms(paymentTerms);
		
		TaxRate taxRate = taxRateDTO.getTaxRate();
		
		switch (oper) {
		case "edit":
			result=taxRateService.update(taxRate);//update tax rate
			break;
		}	//end of switch loop
		return new StatusResponse(result);
	}
}