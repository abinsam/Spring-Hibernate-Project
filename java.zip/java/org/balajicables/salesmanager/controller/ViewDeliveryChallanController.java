package org.balajicables.salesmanager.controller;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import org.balajicables.salesmanager.CustomUser;
import org.balajicables.salesmanager.common.JqgridResponse;
import org.balajicables.salesmanager.dto.DeliveryChallanItemsDTO;
import org.balajicables.salesmanager.dto.OrderDTO;
import org.balajicables.salesmanager.dto.SalesOrderItemsDTO;
import org.balajicables.salesmanager.dto.ScrapStoreRegDTO;
import org.balajicables.salesmanager.dto.StoreRegisterDTO;
import org.balajicables.salesmanager.model.Customer;
import org.balajicables.salesmanager.model.DeliveryChallan;
import org.balajicables.salesmanager.model.DeliveryChallanItems;
import org.balajicables.salesmanager.model.OrderStatus;
import org.balajicables.salesmanager.model.PackingSlip;
import org.balajicables.salesmanager.model.SalesOrder;
import org.balajicables.salesmanager.model.SalesOrderItem;
import org.balajicables.salesmanager.model.ScrapStoreReg;
import org.balajicables.salesmanager.model.StockOut;
import org.balajicables.salesmanager.model.StoreRegister;
import org.balajicables.salesmanager.service.CustomerService;
import org.balajicables.salesmanager.service.DeliveryChallanItemsService;
import org.balajicables.salesmanager.service.DeliveryChallanService;
import org.balajicables.salesmanager.service.OrderDetailsService;
import org.balajicables.salesmanager.service.OrderService;
import org.balajicables.salesmanager.service.OrderStatusService;
import org.balajicables.salesmanager.service.PackingSlipService;
import org.balajicables.salesmanager.service.ScrapStoreRegService;
import org.balajicables.salesmanager.service.StockOutService;
import org.balajicables.salesmanager.service.StoreRegisterService;
import org.balajicables.salesmanager.utils.Utility;
import org.joda.time.DateTime;
import org.springframework.data.domain.Page;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
/**
* This class demonstrates View Delivery Challan Module.
* @author Abin Sam
*/
@Controller
@RequestMapping("/viewdeliverychallan")

public class ViewDeliveryChallanController {
	@Resource
	private CustomerService customerService;
	@Resource
	private DeliveryChallanService deliveryChallanService;
	@Resource
	private DeliveryChallanItemsService deliveryChallanItemsService;
	@Resource
	private StockOutService stockOutService;
	@Resource
	private PackingSlipService packingSlipService;
	@Resource
	private StoreRegisterService storeRegisterService;
	@Resource
	private OrderService orderService;
	@Resource
	private OrderStatusService orderStatusService;
	@Resource
	private ScrapStoreRegService scrapStoreRegService;
	@Resource
	private OrderDetailsService orderDetailsService;

	 /**
	   * This method returns viewDeliveryChallan.jsp.
	   * Fetch all customers and Delivery ChallanNos based on month and year selected
	   * @param Model to set the attribute.
	   * @return viewDeliveryChallan.jsp.
	   */
	
	@RequestMapping
	public String getItemsPage(Model model) {
		List<Customer> customers = customerService.findAll();
		DateTime dt = new DateTime();  // current time
		int month =dt.getMonthOfYear();//current month
		int year=dt.getYear(); //current year
		/*Method to fetch delivery challan for selected month & YEAR*/
		List<DeliveryChallan> deliveryChallanNos =deliveryChallanService.finddByStockOutsAndMonthYear(month,year);
		model.addAttribute("deliveryChallans", deliveryChallanNos);	//set delivery challan nos to model attribute
		model.addAttribute("customers", customers);	//set customers nos to model attribute
		return "viewDeliveryChallan";
	}
	 /**
	   * This method to populate delivery challan nos based on month year selected
	   * Fetch  Delivery Challan Nos to populate on select box
	   * @param month,year
	   * @return ArrayList<String> deliveryChallanNos
	   */
	@RequestMapping(value = "/fetchDeliveryChallan", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	ArrayList<String> getWorkOrderNos(
			@RequestParam(value = "month", required = true) String month,
			@RequestParam(value = "year", required = true) String year) {
		ArrayList<String> dcNosList = new ArrayList<>();
	    int monthValue=0;
        int yearValue=0;
        if(month!=null && month!=""){
        	monthValue=Integer.parseInt(month);//parse month string to integer
        }//end of if loop
       if(year!=null && year!=""){
    	   yearValue=Integer.parseInt(year);//parse year string to integer
        }//end of if loop
        /*method to fetch stock out records based on moth and year*/ 
    	List<StockOut> stockOuts =stockOutService.finddByStockOutsAndMonthYear((monthValue+1),yearValue);
		
		for (int iterator = 0; iterator < stockOuts.size(); iterator++) {
			if(stockOuts.get(iterator).getDeliveryChallanNo()!=null && stockOuts.get(iterator).getDeliveryChallanNo()!=""){
			String dcNo = stockOuts.get(iterator).getDeliveryChallanNo();
			if (!dcNosList.contains(dcNo)) {
				dcNosList.add(dcNo);
			}//end of if (!dcNosList.contains(dcNo)) loop
			}//end of outer if loop
		}//end of for loop
		return dcNosList;
	}
	
	
	 /**
	   * This method to populate delivery challan nos based on month year and customer selected
	   * Fetch  Delivery Challan Nos to populate on select box
	   * @param month,year,customer Id
	   * @return ArrayList<String> deliveryChallanNos
	   */
	@RequestMapping(value = "/getDeliveryChallanNos", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	ArrayList<String> getDeliveryChallanNos(
			@RequestParam(value = "customer", required = true) Long customerId,
			@RequestParam(value = "month", required = false) String month,
			@RequestParam(value = "year", required = false) String year) {
		    
		DateTime dt = new DateTime();  // current time
		ArrayList<String> dcNosList = new ArrayList<>();
		    int monthValue=0;
	        int yearValue=0;
	        if(month!=null && month!="")
	        	monthValue=Integer.parseInt(month)+1;//parse month string to integer:if loop
	        
	        else
	        	monthValue =dt.getMonthOfYear();//parse month string to integer:else loop
	        
	       if(year!=null && year!="")
	    	   yearValue=Integer.parseInt(year);//parse year string to integer:if loop
	       else
	    	   yearValue =dt.getYear();//parse year string to integer:else loop
	       /*method to fetch DeliveryChallan records based on customer, moth and year*/ 
			List<DeliveryChallan> deliveryChallanNos =deliveryChallanService.finddByCustomerAndMonthYear(customerId,monthValue,yearValue);

	  		for (int iterator = 0; iterator < deliveryChallanNos.size(); iterator++) {
			if(deliveryChallanNos.get(iterator).getDeliveryChallanNo()!=null && deliveryChallanNos.get(iterator).getDeliveryChallanNo()!="")
			dcNosList.add(deliveryChallanNos.get(iterator).getDeliveryChallanNo());//adding DC nos to list
		    
		}//end of for loop

		return dcNosList;
	}

	
	 /**
	   * This method to fetch details of selected delivery challan no
	   * Fetch  Delivery Challan Nos details for text box
	   * @param deliveryChallanNo
	   * @return ArrayList<String> deliveryChallanNo details
	   */
	@RequestMapping(value = "/getDcDetails", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	ArrayList<String> getDcDetailsnNos(
			@RequestParam("deliveryChallanNo") String deliveryChallanNo, Model model) {
		ArrayList<String> dcDetails = new ArrayList<>();//initialize array list for delivery challan no details
		ArrayList<String> bagNoList = new ArrayList<>();//initialize array list for packing details of selected DC No
		
		int bagCount= 0;
		/*Method to fetch Stock out records based on delivery challan no*/
		List<StockOut> stockOutList=stockOutService.findByDeliveryChallanNo(deliveryChallanNo);
		/*Method to fetch delivery challan records based on delivery challan no*/
		List<DeliveryChallan> dcDetailsList=deliveryChallanService.findByDeliveryChallanNo(deliveryChallanNo);
		/*Method to fetch Packing Slip records based on delivery challan no*/
		List<PackingSlip> packingSlipList=packingSlipService.findByDeliveryChallanNo(deliveryChallanNo);
	   
	    if(packingSlipList.size()>0){
			for (int iterator = 0; iterator < packingSlipList.size(); iterator++) {
				String bagNo = packingSlipList.get(iterator).getPackingSlipNo();
				if (!bagNoList.contains(bagNo)) {
					bagNoList.add(bagNo);
				}
			}
	    }//end of  if(packingSlipList.size()>0) loop
	    if(bagNoList.size()>0){
	    	bagCount=bagNoList.size();
	    }//end of  if(bagNoList.size()>0) loop
 	    
	    	if(stockOutList.size()>0){
	    		/*Add delivery challan details to Array list*/
			dcDetails.add(stockOutList.get(0).getSalesOrderItem().getOrder().getOrderId());//adding order id
			dcDetails.add(dcDetailsList.get(0).getChallanDate().toString());//adding challan date
			dcDetails.add(String.valueOf(bagCount));//adding bag count
			dcDetails.add(dcDetailsList.get(0).getInvoiceNo());//adding invoice no
			dcDetails.add(dcDetailsList.get(0).getInvoiceStatus());//adding invoice status
			dcDetails.add(stockOutList.get(0).getSalesOrderItem().getOrder().getCustomer().getCustomerName());//adding customer name
			dcDetails.add(stockOutList.get(0).getSalesOrderItem().getOrder().getCustomer().getCustomerId().toString());//adding customer Id
		   dcDetails.add(stockOutList.get(0).getSalesOrderItem().getOrder().getCustomer().getAddress());//adding customer address
	    }//end of if(stockOutList.size()>0) loop
	    	else
			dcDetails.add("Cancelled DeliveryChallan");//adding cancel message
		return dcDetails;
	}
	
	 /**
	   * This method to fetch item details of selected delivery challan no
	   * Fetch  Delivery Challan Item details for grid
	   * @param deliveryChallanNo,filters,pageNumber,rowsPerPage,sortColName,sortOrder
	   * @return JqgridResponse<DeliveryChallanItemsDTO> response
	   */
	@RequestMapping(value="/records", produces="application/json", method=RequestMethod.POST)
	public @ResponseBody
	JqgridResponse<DeliveryChallanItemsDTO> records(
			@RequestParam("deliveryChallanNo") String deliveryChallanNo,
			@RequestParam("_search") Boolean search,
    		@RequestParam(value="filters", required=false) String filters,
			@RequestParam(value = "page", required = false) Integer pageNumber,
			@RequestParam(value = "rows", required = false) Integer rowsPerPage,
			@RequestParam(value = "sidx", required = false) String sortColName,
			@RequestParam(value = "sord", required = false, defaultValue = "asc") String sortOrder) {
		/*Method to fetch JQGRID paged records of delivery challan item based on delivery challan no*/
		Page<DeliveryChallanItems> deliveryChallanItems = deliveryChallanItemsService.getPagedDeliveryChallanItems(deliveryChallanNo,pageNumber - 1,
				rowsPerPage, sortColName, sortOrder);
		/*Intialize JQ grid response of type delivery challan items DTO*/
		JqgridResponse<DeliveryChallanItemsDTO> response = new JqgridResponse<DeliveryChallanItemsDTO>();
		/*Method to set delivery challan item list to DeliveryChallanItemsDTO*/
		List<DeliveryChallanItemsDTO> dcItemDTOs = convertToDTO(deliveryChallanItems.getContent());
		response.setRows(dcItemDTOs);
		response.setRecords(Long.valueOf(deliveryChallanItems.getTotalElements()).toString());
		response.setTotal(Long.valueOf(deliveryChallanItems.getTotalPages()).toString());
		response.setPage(Integer.valueOf(deliveryChallanItems.getNumber()+1).toString());
        
		return response;
	}

	 /**
	   * This Method to set delivery challan item list to DeliveryChallanItemsDTO
	   * @param List<DeliveryChallanItems> DeliveryChallanItems
	   * @return List<DeliveryChallanItemsDTO> response
	   */
	private List<DeliveryChallanItemsDTO> convertToDTO(List<DeliveryChallanItems> challanItems) {
		List<DeliveryChallanItemsDTO> dcItemDTOs = new ArrayList<>();
		for(DeliveryChallanItems challanItem : challanItems) {
			DeliveryChallanItemsDTO dcItemDTO = new DeliveryChallanItemsDTO();
			dcItemDTO.setDcItemId(challanItem.getDcItemId());
			dcItemDTO.setDeliveryChallanNo(challanItem.getDeliveryChallan().getDeliveryChallanNo());
			dcItemDTO.setItemDescription(challanItem.getItemDescription());
			dcItemDTO.setNoOfRolls(challanItem.getNoOfRolls());
			dcItemDTO.setQtyPerRoll(challanItem.getQtyPerRoll());
			dcItemDTO.setTotalQty(challanItem.getTotalQty());
			dcItemDTO.setItemId(challanItem.getItem().getItemId());
			dcItemDTO.setUnits(challanItem.getUnits());
			dcItemDTO.setProductTypeKey(challanItem.getProductTypeKey());
			dcItemDTOs.add(dcItemDTO);
		}//end of for loop
		return dcItemDTOs;
}

	 /**
	   * This Method to delete deliveryChallan
	   * @param deliveryChallanNo
	   * @return List<String>
	   */
	@RequestMapping(value = "/delete", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	List<String> deleteId(
			@RequestParam(value = "deliveryChallanNo", required = true) String deliveryChallanNo) {
		
		//fetch logged in user
		CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();;
	 	String userName = user.getFirstName()+" "+user.getLastName();
		
	 	/*Method to fetch DC Items records based on delivery challan no*/
	 	List<DeliveryChallanItems>dcItemList=deliveryChallanItemsService.findByDeliveryChallanNo(deliveryChallanNo);
	 	/*Method to fetch DC  records based on delivery challan no*/
	 	List<DeliveryChallan>dcList=deliveryChallanService.findByDeliveryChallanNo(deliveryChallanNo);
	 	/*Method to fetch StockOut records based on delivery challan no*/
	 	List<StockOut>stockOutList=stockOutService.findByDeliveryChallanNo(deliveryChallanNo);
		Long customerId=dcList.get(0).getOrders().getCustomer().getCustomerId();//get customer Id
		String salesorderNumber=dcList.get(0).getOrders().getOrderId();//get sales order id
		Boolean deleteDcItemResult=false;
		Boolean deleteDcResult=false;
		Boolean deleteStockOutResult=false;
		Boolean deletepackingSlipResult=false;
		if(dcItemList.size()>0){
			for(int k=0;k<dcItemList.size();k++){
				deleteDcItemResult=deliveryChallanItemsService.delete(dcItemList.get(k).getDcItemId());
			}//end of for loop
		}//end of if(dcItemList.size()>0) loop
		if(deleteDcItemResult==true){
			List<PackingSlip>packingSlipList=packingSlipService.findByDeliveryChallanNo(deliveryChallanNo);
		for(int m=0;m<packingSlipList.size();m++){
			deletepackingSlipResult=packingSlipService.delete(packingSlipList.get(m).getPackingSlipId());
		}
			if(deletepackingSlipResult==true)
			deleteDcResult=deliveryChallanService.delete(deliveryChallanNo);
		}//end of if(deleteDcItemResult==true) loop
		if(deleteDcResult==true && stockOutList.size()>0){
			for(int l=0;l<stockOutList.size();l++){
			/*Method to fetch StockOut records based on StockOut id*/
			List<StockOut>stockOutIdList=stockOutService.findByStockOutId(stockOutList.get(l).getStockOutId());
			if(stockOutIdList.size()>0){
				String itemType=stockOutIdList.get(0).getSalesOrderItem().getItem().getItemType();
				Long itemId=stockOutIdList.get(0).getSalesOrderItem().getItem().getItemId();
				Long soItemId=stockOutIdList.get(0).getSalesOrderItem().getOrderDetailId();
				String unitsValue=stockOutIdList.get(0).getSalesOrderItem().getItem().getUnit().getUnits();
				Double stockOutQtyMts=stockOutIdList.get(0).getStockOutQty();
				Double stockOutQtyWeight=stockOutIdList.get(0).getWeight();
				if(itemType.equalsIgnoreCase("SCRAP")){
					List<ScrapStoreReg>scrapStoreRegList=scrapStoreRegService.findByItemsItemId(itemId);
					if(scrapStoreRegList.size()>0){
						
					ScrapStoreRegDTO scrapStoreRegDTO=new ScrapStoreRegDTO();
					scrapStoreRegDTO.setScrapStoreRegId(scrapStoreRegList.get(0).getScrapStoreRegId());
					/*Set Stock qty of scrap based on condition*/
					if(scrapStoreRegList.get(0).getStockQuantity()==null && stockOutIdList.get(0).getStockOutQty()==null)
					scrapStoreRegDTO.setStockQuantity(0.0);
                	else if(scrapStoreRegList.get(0).getStockQuantity()==null)
    				scrapStoreRegDTO.setStockQuantity(0+stockOutIdList.get(0).getStockOutQty());
                	else if(stockOutIdList.get(0).getStockOutQty()==null)
                	scrapStoreRegDTO.setStockQuantity(scrapStoreRegList.get(0).getStockQuantity()+0);
                	else
        			scrapStoreRegDTO.setStockQuantity(scrapStoreRegList.get(0).getStockQuantity()+stockOutIdList.get(0).getStockOutQty());

					
					
					scrapStoreRegDTO.setStockQuantity(scrapStoreRegList.get(0).getStockQuantity()+stockOutIdList.get(0).getStockOutQty());
					scrapStoreRegDTO.setUpdatedBy(scrapStoreRegList.get(0).getUpdatedBy());
					scrapStoreRegDTO.setItemId(scrapStoreRegList.get(0).getItems().getItemId());
					scrapStoreRegDTO.setStockOutQty(scrapStoreRegList.get(0).getStockOutQty());
					scrapStoreRegDTO.setStoreId(scrapStoreRegList.get(0).getStore().getStoreId());
					ScrapStoreReg scrapStoreReg=scrapStoreRegDTO.getScrapStoreReg();
					scrapStoreRegService.update(scrapStoreReg);
					   deleteStockOutResult=stockOutService.delete(stockOutIdList.get(0).getStockOutId());

					}//end of inner if loop
					else{
					ScrapStoreRegDTO scrapStoreRegDTOs=new ScrapStoreRegDTO();
					scrapStoreRegDTOs.setStockQuantity(stockOutIdList.get(0).getStockOutQty());
					scrapStoreRegDTOs.setUpdatedBy(userName);
					scrapStoreRegDTOs.setItemId(stockOutIdList.get(0).getSalesOrderItem().getItems().getItemId());
					scrapStoreRegDTOs.setStockOutQty(null);
					scrapStoreRegDTOs.setStoreId(stockOutIdList.get(0).getStore().getStoreId());
					ScrapStoreReg scrapStoreRegs=scrapStoreRegDTOs.getScrapStoreReg();
					/*Method to create ScrapStoreReg entry*/
					ScrapStoreReg craetedScrapStoreReg=scrapStoreRegService.create(scrapStoreRegs);
					 if(craetedScrapStoreReg!=null){
						 /*Method to delete Scrap in Stock Out*/
					   deleteStockOutResult=stockOutService.delete(stockOutIdList.get(0).getStockOutId());
					 }
				
					}//end of inner else loop
					
				}//delete delivery challan of scrap items
				else{
					Boolean storeCreate=false;
					List<StoreRegister>storeRgisterDetails=storeRegisterService.
							findByOrderDetailIdAndBundleIdAndWorkOrderNo(stockOutIdList.get(0).getSalesOrderItem().getOrderDetailId(),
									stockOutIdList.get(0).getBundleId(), stockOutIdList.get(0).getProductionWorkOrder().getWorkOrderNo());
					if(!(storeRgisterDetails.size()>0)){
					StoreRegisterDTO storeRegisterDTO=new StoreRegisterDTO();
					storeRegisterDTO.setItemCode(stockOutIdList.get(0).getItemCode());
					storeRegisterDTO.setStoreId(stockOutIdList.get(0).getStore().getStoreId());
					storeRegisterDTO.setWorkOrderNo(stockOutIdList.get(0).getProductionWorkOrder().getWorkOrderNo());
					storeRegisterDTO.setCustomerName(stockOutIdList.get(0).getSalesOrderItem().getOrder().getCustomer().getCustomerName());
					storeRegisterDTO.setStockQty(stockOutIdList.get(0).getStockOutQty());
					storeRegisterDTO.setBundleId(stockOutIdList.get(0).getBundleId());
					storeRegisterDTO.setOrderId(stockOutIdList.get(0).getOrderId());
					storeRegisterDTO.setOrderDetailId(stockOutIdList.get(0).getSalesOrderItem().getOrderDetailId());
					storeRegisterDTO.setItemId(stockOutIdList.get(0).getItemId());
					storeRegisterDTO.setPackingSlipNo(null);
					storeRegisterDTO.setSupervisor(userName);
					storeRegisterDTO.setWeight(stockOutIdList.get(0).getWeight());
					storeRegisterDTO.setBagWeight(null);
					storeRegisterDTO.setQcStatus(stockOutIdList.get(0).getQcStatus());
					storeRegisterDTO.setRejectStatus("");
					storeRegisterDTO.setQcSupervisor(stockOutIdList.get(0).getQcSupervisor());
					storeRegisterDTO.setRemarks(stockOutIdList.get(0).getRemarks());
					StoreRegister storeRegister=storeRegisterDTO.getStoreRegister();
					 /*Method to create entry in StoreRegister*/
					StoreRegister craetedStoreReg=storeRegisterService.create(storeRegister);
					if(craetedStoreReg!=null)
						storeCreate=true;
					}else
						storeCreate=true;
					if(storeCreate==true && stockOutIdList.get(0).getStockOutId()!=null){
						 /*Method to delete entry in StockOut*/
						deleteStockOutResult=stockOutService.delete(stockOutIdList.get(0).getStockOutId());
					   }//end of if loop
					
				 }//delete delivery challan of items
				        /*Method to fetch SalesOrderItem based on SalesOrderItem id*/
					    List<SalesOrderItem>soItemList=orderDetailsService.findById(soItemId);
					    //Updating Sales order item quantities after deleting delivery challan:Restock In
					    if(soItemList.size()>0){
					    Double newDispatchedQty=0.0;
					    Double newCompletedQty=0.0;
					   // if(soItemList.get(0).getDispatchedQty()>0)
					    /*Calculating dispatched and completed qty based on tyope of item*/	
					    	if(unitsValue.equalsIgnoreCase("Kgs") || unitsValue.equalsIgnoreCase("Kg")){
					    		  newDispatchedQty=soItemList.get(0).getDispatchedQty()-stockOutQtyWeight;
						          newCompletedQty=soItemList.get(0).getCompletedQty()+stockOutQtyWeight;
						  
					    	}else{
					    	      newDispatchedQty=soItemList.get(0).getDispatchedQty()-stockOutQtyMts;
						          newCompletedQty=soItemList.get(0).getCompletedQty()+stockOutQtyMts;
						    
					    	}
					    Double balanceQty=0.0;
					    //calculating balance quantity
					    balanceQty=soItemList.get(0).getQuantity()-(soItemList.get(0).getProductionQty()+newCompletedQty+newDispatchedQty);
					    if(balanceQty<0.0)
					    	balanceQty=0.0;
					    SalesOrderItemsDTO dto = new SalesOrderItemsDTO();
						dto.setOrderDetailId(soItemList.get(0).getOrderDetailId());
						dto.setOrderId(soItemList.get(0).getOrder().getOrderId());
                     	dto.setItemId(soItemList.get(0).getItem().getItemId());
                		dto.setQuantity(soItemList.get(0).getQuantity());
						dto.setBalanceQty(balanceQty);
						dto.setProductionQty(soItemList.get(0).getProductionQty());
						dto.setCompletedQty(newCompletedQty);
						dto.setDispatchedQty(newDispatchedQty);
						dto.setWoQty(soItemList.get(0).getWoQty());
						dto.setWeight(soItemList.get(0).getWeight());
						dto.setBundleSize(soItemList.get(0).getBundleSize());
						dto.setRate(soItemList.get(0).getRate());
						dto.setItemCode(soItemList.get(0).getItemCode());
						dto.setUpdatedBy(soItemList.get(0).getUpdatedBy());
						dto.setPvcWeight(soItemList.get(0).getPvcWeight());
						
						SalesOrderItem newSoItemList=dto.getOrderDetail();
						orderDetailsService.update(newSoItemList);//update sales order item
							    
					}//end of if loop
			
				}//end of if(stockOutIdList.size()>0) loop
			}//end of for loop
		}//end of if(deleteDcResult==true && stockOutList.size()>0) loop
		//Converting dispatched sales order status to Approved on deleting delivery challan:Restockin
		if(deleteDcResult==true){
			 /*Method to fetch SalesOrder based on salesorderNumber*/
			List<SalesOrder>salesOrderList=orderService.findBySalesOrderNoId(salesorderNumber);
			String orderStatus="Approved";
			 /*Method to fetch SalesOrderStatus Id for status ="Approved"*/
			List<OrderStatus>orderStatusList=orderStatusService.findByStatus(orderStatus);
			if(salesOrderList.size()>0){
				OrderDTO orderDTO=new OrderDTO();
				orderDTO.setCreatedBy(salesOrderList.get(0).getCreatedBy());
				orderDTO.setCreatedTime(salesOrderList.get(0).getCreatedTime().toString());
				orderDTO.setCustomerId(salesOrderList.get(0).getCustomer().getCustomerId());
				orderDTO.setCustomerName(salesOrderList.get(0).getCustomer().getCustomerName());
				orderDTO.setInputQuantity(salesOrderList.get(0).getInputQuantity());
				orderDTO.setModeOfReceipt(salesOrderList.get(0).getModeOfReceipt());
				if(salesOrderList.get(0).getOrderAcceptanceDate()!=null)
				orderDTO.setOrderAcceptanceDate(Utility.formDateFormatter.print(salesOrderList.get(0).getOrderAcceptanceDate().getTime()));//formatting OrderAcceptanceDate 
				if(salesOrderList.get(0).getOrderDeliveryDate()!=null)
				orderDTO.setOrderDeliveryDate(Utility.formDateFormatter.print(salesOrderList.get(0).getOrderDeliveryDate().getTime()));//formatting OrderDeliveryDate 
			
				orderDTO.setOrderId(salesOrderList.get(0).getOrderId());
				if(salesOrderList.get(0).getOrderRecDate()!=null)
				orderDTO.setOrderRecDate(Utility.formDateFormatter.print(salesOrderList.get(0).getOrderRecDate().getTime()));//formatting OrderRecDate
				orderDTO.setOrderStatusId(orderStatusList.get(0).getOrderStatusId());
				orderDTO.setPoDetails(salesOrderList.get(0).getPoDetails());
				orderDTO.setStatus("Approved");
				if(salesOrderList.get(0).getTargetDate()!=null)
				orderDTO.setTargetDate(Utility.formDateFormatter.print(salesOrderList.get(0).getTargetDate().getTime()));//formatting TargetDate
				orderDTO.setUpdatedBy(salesOrderList.get(0).getUpdatedBy());
				orderDTO.setUpdatedTime(salesOrderList.get(0).getUpdatedTime().toString());
				orderDTO.setMailStatus(salesOrderList.get(0).getMailStatus());
				SalesOrder soOrder=orderDTO.getOrder();
				orderService.update(soOrder);//method to update sales order
			}//end of if loop
		}//end of if(deleteDcResult==true) loop
		ArrayList<String> dcNosList = new ArrayList<>();
		if(deleteStockOutResult==true && customerId!=null ){
			/*Method to fetch delivery challan details based on customer Id*/
			List<DeliveryChallan> dcDetails = deliveryChallanService.findByOrderCustomerCustomerId(customerId);
		    	for (int iterator = 0; iterator < dcDetails.size(); iterator++) {
				String dcNos = dcDetails.get(iterator).getDeliveryChallanNo();
				if (!dcNosList.contains(dcNos) && dcNos!=null) {
					dcNosList.add(dcNos);//adding dc no to return list
				}//end of if loop for iterating distinct delivery challan nos
			}//end of for loop

		}//end of if(deleteStockOutResult==true && customerId!=null ) loop
		return dcNosList;
	}
	 /**
	   * This Method to generate deliveryChallan report
	   * @param deliveryChallanNo
	   * @return 
	   */
	@RequestMapping(value = "/deliveryChallanReport", produces = "application/pdf", method = RequestMethod.GET)
	public void DeliveryChallanReport(@RequestParam(value = "deliveryChallanNo", required = true) String deliveryChallanNo,javax.servlet.http.HttpServletResponse response) throws IOException, InterruptedException{
		if(deliveryChallanNo!=null && deliveryChallanNo!=""){
		InputStream inputStream = getClass().getClassLoader().getResourceAsStream("/org/balajicables/salesmanager/report/DeliveryChallanReport.jrxml");
    	
    	 Map<String, Object> hm= new HashMap<String, Object>();
         hm.put("DELIVERY_CHALLAN_NO", deliveryChallanNo);//add report parameter to hash map
         byte[] content = ReportGenerator.newReportGenerator(inputStream,hm);
	    
	    response.setContentType("application/pdf");
		response.setHeader("Content-Disposition", "attachment;filename=" + "DeliveryChallan"+deliveryChallanNo+".pdf");
		response.setContentLength(content.length);
	    FileCopyUtils.copy(content, response.getOutputStream());
       
   }//end of if loop
}
	 /**
	   * This Method to generate report for workorder tracking for a delivery challan 
	   * @param deliveryChallanNo
	   * @return 
	   */
	@RequestMapping(value = "/workOrderTrackReport", produces = "application/pdf", method = RequestMethod.GET)
	public void WorkOrderTrackReport(@RequestParam(value = "deliveryChallanNo", required = true) String deliveryChallanNo,javax.servlet.http.HttpServletResponse response) throws IOException, InterruptedException{
		if(deliveryChallanNo!=null && deliveryChallanNo!=""){
		InputStream inputStream = getClass().getClassLoader().getResourceAsStream("/org/balajicables/salesmanager/report/DcWoTrackReport.jrxml");
  	
  	 Map<String, Object> hm= new HashMap<String, Object>();
       hm.put("DELIVERY_CHALLAN_NO", deliveryChallanNo);//add report parameter to hash map
       byte[] content = ReportGenerator.newReportGenerator(inputStream,hm);
	    
	    response.setContentType("application/pdf");
		response.setHeader("Content-Disposition", "attachment;filename=" + "WorkOrder Tracking For "+deliveryChallanNo+".pdf");
		response.setContentLength(content.length);
	    FileCopyUtils.copy(content, response.getOutputStream());
     
 }//end of if loop
}
}