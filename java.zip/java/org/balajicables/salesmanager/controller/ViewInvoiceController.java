package org.balajicables.salesmanager.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import org.balajicables.salesmanager.common.JqgridResponse;
import org.balajicables.salesmanager.common.MailMail;
import org.balajicables.salesmanager.common.StatusResponse;
import org.balajicables.salesmanager.dto.DeliveryChallanDTO;
import org.balajicables.salesmanager.dto.InvoiceDTO;
import org.balajicables.salesmanager.dto.InvoiceItemsDTO;
import org.balajicables.salesmanager.dto.OrderDTO;
import org.balajicables.salesmanager.dto.SalesOrderItemsDTO;
import org.balajicables.salesmanager.dto.ScrapStoreRegDTO;
import org.balajicables.salesmanager.dto.StoreRegisterDTO;
import org.balajicables.salesmanager.model.Customer;
import org.balajicables.salesmanager.model.DeliveryChallan;
import org.balajicables.salesmanager.model.DeliveryChallanItems;
import org.balajicables.salesmanager.model.Invoice;
import org.balajicables.salesmanager.model.InvoiceItems;
import org.balajicables.salesmanager.model.OrderStatus;
import org.balajicables.salesmanager.model.PackingSlip;
import org.balajicables.salesmanager.model.SalesOrder;
import org.balajicables.salesmanager.model.SalesOrderItem;
import org.balajicables.salesmanager.model.ScrapStoreReg;
import org.balajicables.salesmanager.model.StockOut;
import org.balajicables.salesmanager.model.StoreRegister;
import org.balajicables.salesmanager.service.CustomerService;
import org.balajicables.salesmanager.service.DeliveryChallanItemsService;
import org.balajicables.salesmanager.service.DeliveryChallanService;
import org.balajicables.salesmanager.service.InvoiceItemsService;
import org.balajicables.salesmanager.service.InvoiceService;
import org.balajicables.salesmanager.service.OrderDetailsService;
import org.balajicables.salesmanager.service.OrderService;
import org.balajicables.salesmanager.service.OrderStatusService;
import org.balajicables.salesmanager.service.PackingSlipService;
import org.balajicables.salesmanager.service.ScrapStoreRegService;
import org.balajicables.salesmanager.service.StockOutService;
import org.balajicables.salesmanager.service.StoreRegisterService;
import org.balajicables.salesmanager.utils.Utility;
import org.joda.time.DateTime;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
/**
* This class demonstartes View Invoice Module.
* @author Abin Sam
*/
@Controller
@RequestMapping("/viewInvoice")
public class ViewInvoiceController {

	@Resource
	private CustomerService customerService;
	@Resource
	private InvoiceService invoiceService;
	@Resource
	private InvoiceItemsService invoiceItemsService;
	@Resource
	private DeliveryChallanService deliveryChallanService;
	@Resource
	private DeliveryChallanItemsService deliveryChallanItemsService;
	@Resource
	private PackingSlipService packingSlipService;
	@Resource
	private StockOutService stockOutService;
	@Resource
	private ScrapStoreRegService scrapStoreRegService;
	@Resource
	private OrderDetailsService orderDetailsService;
	@Resource
	private StoreRegisterService storeRegisterService;
	@Resource
	private OrderService orderService;
	@Resource
	private OrderStatusService orderStatusService;
	 /**
	   * This method returns viewInvoice.jsp.
	   * Fetch all customers and invoices based on month and year selected
	   * @param Model to set the attribute.
	   * @return viewInvoice.jsp.
	   */
	@RequestMapping
	public String getItemsPage(Model model) {
		List<Customer> customers = customerService.findAll();
		DateTime dt = new DateTime();  // current time
		int month =dt.getMonthOfYear();//current month
		int year=dt.getYear(); //current year
		/*Method to fetch invoices for selected month & YEAR*/
        List<Invoice> invoices =invoiceService.findByMonthYear(month,year);
		model.addAttribute("invoices", invoices);//set invoice numbers to model attribute	
		model.addAttribute("customers", customers);//set customers to model attribute
		return "viewInvoice";
	}
	 /**
	   * This method to populate invoice nos based on month year selected
	   * Fetch  invoice Nos to populate on select box
	   * @param month,year
	   * @return ArrayList<String> invoiceNos
	   */
	@RequestMapping(value = "/fetchInvoiceNos", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	ArrayList<String> getWorkOrderNos(
			@RequestParam(value = "month", required = true) String month,
			@RequestParam(value = "year", required = true) String year) {
		ArrayList<String> invoiceNoList = new ArrayList<>();
		
        int monthValue=0;
        int yearValue=0;
        if(month!=null && month!=""){
        	monthValue=Integer.parseInt(month);//parse month string to integer
        }
       if(year!=null && year!=""){
    	   yearValue=Integer.parseInt(year);//parse year string to integer
        }
       /*method to fetch invoice records based on moth and year*/ 
       List<Invoice> invoices =invoiceService.findByMonthYear((monthValue+1),yearValue);
		
		for (int iterator = 0; iterator < invoices.size(); iterator++) {
			if(invoices.get(iterator).getDeliveryChallanNo()!=null && invoices.get(iterator).getDeliveryChallanNo()!=""){
			String invoiceNo = invoices.get(iterator).getDeliveryChallanNo();
			if (!invoiceNoList.contains(invoiceNo)) {
				invoiceNoList.add(invoiceNo);
			}//end of if (!invoiceNoList.contains(dcNo)) loop
			}//end of outer if loop
		}//end of for loop

		return invoiceNoList;
	}
	
	
	 /**
	   * This method to populate invoice nos based on month year and customer selected
	   * Fetch  invoice Nos to populate on select box
	   * @param month,year,customer Id
	   * @return ArrayList<String>invoice Nos
	   */
	@RequestMapping(value = "/getInvoiveNos", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	ArrayList<String> getDeliveryChallanNos(
			@RequestParam(value = "customer", required = true) Long customerId,
			@RequestParam(value = "month", required = true) String month,
			@RequestParam(value = "year", required = true) String year) {
		    
		DateTime dt = new DateTime();  // current time
		ArrayList<String> invoiceNoList = new ArrayList<>();
		    int monthValue=0;
	        int yearValue=0;
	        if(month!=null && month!="")
	        	monthValue=Integer.parseInt(month)+1;//parse month string to integer:if loop
	        else
	        	monthValue =dt.getMonthOfYear();//parse month string to integer:else loop
	        
	       if(year!=null && year!="")
	    	   yearValue=Integer.parseInt(year);//parse year string to integer:if loop
	       else
	    	   yearValue =dt.getYear();//parse year string to integer:else loop
	       /*method to fetch invoice records based on customer, moth and year*/ 
			List<Invoice> invoiceNos =invoiceService.finddByCustomerAndMonthYear(customerId,monthValue,yearValue);

	  		for (int iterator = 0; iterator < invoiceNos.size(); iterator++) {
			if(invoiceNos.get(iterator).getDeliveryChallanNo()!=null && invoiceNos.get(iterator).getDeliveryChallanNo()!="")
			invoiceNoList.add(invoiceNos.get(iterator).getDeliveryChallanNo());//adding invoiceNos to list
		    
		}//end of for loop

		return invoiceNoList;
	}

	 /**
	   * This method to fetch details of selected invoice no
	   * Fetch  invoice Nos details for text box
	   * @param invoiceNo
	   * @return ArrayList<String> invoice details
	   */
	@RequestMapping(value = "/invoiceDetails", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	List<String> getInvoiceDetails(@RequestParam("invoiceNo") String invoiceNo,
			Model model) {
		ArrayList<String> invoiceDetailsList = new ArrayList<>();//initialize array list for invoice no details
		String transportCharge="";
		String finalAmount="";
		/*Method to fetch invoiceDetails based on Invoice no*/
		List<Invoice> invoiceDetails = invoiceService.findByInvoiceNo(invoiceNo);
		if (invoiceDetails.size() > 0) {
			/*Add invoiceDetails to Array list*/
			if(invoiceDetails.get(0).getTransportCharges()!=null)
				transportCharge=invoiceDetails.get(0).getTransportCharges().toString();//adding transport charges
			if(invoiceDetails.get(0).getFinalAmount()!=null)
				finalAmount=invoiceDetails.get(0).getFinalAmount().toString();//adding final amount
			if(invoiceDetails.get(0).getCreatedTime()!=null)
			invoiceDetailsList.add(invoiceDetails.get(0).getCreatedTime().toString());//adding created date
			invoiceDetailsList.add(invoiceDetails.get(0).getTransportDetails());//adding transport details
			invoiceDetailsList.add(invoiceDetails.get(0).getLrDetails());//adding lr details
			invoiceDetailsList.add(invoiceDetails.get(0).getMailStatus());//adding mail status
			invoiceDetailsList.add(invoiceDetails.get(0).getDeliveryChallanNo());//adding delivery challan no
			invoiceDetailsList.add(transportCharge);//adding transport charges
			invoiceDetailsList.add(finalAmount);//adding final amount
			invoiceDetailsList.add(invoiceDetails.get(0).getCustomer().getCustomerId().toString());//adding customer id
			invoiceDetailsList.add(invoiceDetails.get(0).getStatus());//adding invoice status
			invoiceDetailsList.add(invoiceDetails.get(0).getLrmailStatus());//adding lr mail status
		}//end of if loop
		return invoiceDetailsList;
	}
	 /**
	   * This method to fetch item details of selected invoiceNo
	   * Fetch  Delivery Challan Item details for grid
	   * @param deliveryChallanNo,filters,pageNumber,rowsPerPage,sortColName,sortOrder
	   * @return JqgridResponse<DeliveryChallanItemsDTO> response
	   */
	@RequestMapping(value = "/records", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	JqgridResponse<InvoiceItemsDTO> records(
			@RequestParam("invoiceNo") String invoiceNo,
			@RequestParam("_search") Boolean search,
			@RequestParam(value = "filters", required = false) String filters,
			@RequestParam(value = "page", required = false) Integer pageNumber,
			@RequestParam(value = "rows", required = false) Integer rowsPerPage,
			@RequestParam(value = "sidx", required = false) String sortColName,
			@RequestParam(value = "sord", required = false, defaultValue = "asc") String sortOrder) {
		/*Method to fetch JQGRID paged records of Invoice item based on Invoice no*/
		Page<InvoiceItems> invoiceItems = invoiceItemsService.getPagedOrders(invoiceNo,
				pageNumber - 1, rowsPerPage, sortColName, sortOrder);
		/*Intialize JQ grid response of type Invoice challan items DTO*/
		JqgridResponse<InvoiceItemsDTO> response = new JqgridResponse<InvoiceItemsDTO>();
		/*Method to set Invoice item list to InvoiceItemsDTO*/
		List<InvoiceItemsDTO> invoiceDTOs = convertToDTO(invoiceItems.getContent());
		response.setRows(invoiceDTOs);
		response.setRecords(Long.valueOf(invoiceItems.getTotalElements())
				.toString());
		response.setTotal(Long.valueOf(invoiceItems.getTotalPages()).toString());
		response.setPage(Integer.valueOf(invoiceItems.getNumber() + 1).toString());

		return response;
	}
	 /**
	   * This Method to set Invoice item list to InvoiceItemsDTO
	   * @param List<InvoiceItems> InvoiceItems
	   * @return List<InvoiceItemsDTO> response
	   */
	private List<InvoiceItemsDTO> convertToDTO(List<InvoiceItems> invoices) {
		List<InvoiceItemsDTO> invoiceDTOs = new ArrayList<>();
		for (InvoiceItems invoice : invoices) {
			InvoiceItemsDTO invoiceDTO = new InvoiceItemsDTO();

			invoiceDTO.setInvoiceNo(invoice.getInvoice().getInvoiceNo());
			invoiceDTO.setInvoiceId(invoice.getInvoiceId());
			invoiceDTO.setAssortedItem(invoice.getAssortedItem());
			invoiceDTO.setProductTypeKey(invoice.getProductTypeKey());
			invoiceDTO.setNoOfRolls(invoice.getNoOfRolls());
			invoiceDTO.setRatePerUnit(invoice.getRatePerUnit());
			invoiceDTO.setTotalValue(invoice.getTotalValue());
			invoiceDTO.setRateOfDuty(invoice.getRateOfDuty());
			invoiceDTO.setTotalDuty(invoice.getTotalDuty());
			invoiceDTO.setTotalEduCess(invoice.getTotalEduCess());
			invoiceDTO.setTotalHigherEduCess(invoice.getTotalHigherEduCess());
			invoiceDTO.setUnits(invoice.getUnits());
			invoiceDTO.setTotalVat(invoice.getTotalVat());
			invoiceDTO.setTotalCst(invoice.getTotalCst());
			invoiceDTO.setTotalQuantity(invoice.getTotalQuantity());
			invoiceDTO.setAmount(invoice.getAmount());
			invoiceDTOs.add(invoiceDTO);
		}//end of for loop
		return invoiceDTOs;
	}
	 /**
	   * This Method to submit invoice and send amil to customer with invoice report as attachemnet
	   * @param invoiceNo.lrDetails
	   * @return StatusResponse
	   */
	@RequestMapping(value = "/submitInvoice", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	StatusResponse submitInvoice(
			@RequestParam(value = "invoiceNo", required = true) String invoiceNo,
			@RequestParam(value = "lrDetails", required = true) String lrDetails) throws IOException {
		
		/*Method to fetch invoiceDetails based on Invoice no*/
		List<Invoice> invoiceDetails = invoiceService.findByInvoiceNo(invoiceNo);
	 	Boolean updatedInvoice = false;
	     String[] toEmailIds=null;
		 String pathC = "C:\\ReportPDFs";//path to create temp report
		 File fileC = new File(pathC);
		if (invoiceDetails.size() > 0) {
			//amountValue=invoiceDetails.get(0).getAmount();
			 Long custId=invoiceDetails.get(0).getCustomer().getCustomerId();//get customer id
			 Date invoiceDate=invoiceDetails.get(0).getInvoiceDate();//ghet invoice date
			 String customertName=invoiceDetails.get(0).getCustomer().getCustomerName();//get customer name
			 /*Method to fetch custDetail based on  customer id*/
			 List<Customer> custDetail=customerService.findById(custId);
			 String emailAddress=null;
			  if(custDetail.size()>0){
				  emailAddress= custDetail.get(0).getEmail();//get customer email id
			 }//end of if loop
			  //Generate invoice report for attaching with customer mail
				 InputStream inputStreamInvoicePrint = getClass().getClassLoader().getResourceAsStream("/org/balajicables/salesmanager/report/InvoiceReport.jrxml");
				 Map<String, Object> hm= new HashMap<String, Object>();
			     hm.put("INVOICE_NO", invoiceNo);
				 byte[] content = ReportGenerator.newReportGenerator(inputStreamInvoicePrint,hm);
              
			

				 if(fileC.exists()){
                     ReportGenerator.deleteDir(fileC);//delete the folder if exist
                     fileC.mkdir();//create temp folder for  report
                  }//end of if loop
				 else{
                     fileC.mkdir();//create temp folder for  report
                  }//end of else loop
				   String[] fileName={pathC+"\\InvoiceReport"+invoiceNo+".pdf"};//create report file
					File f = new File(fileName[0]);
					
					FileOutputStream fos = new FileOutputStream(f);
					fos.write(content, 0, content.length);
					fos.close();
            if(emailAddress!=null){
            	toEmailIds = emailAddress.split(";", -1);//adding email ids as string list
            }
            Format formatter = new SimpleDateFormat("dd-MM-yyyy");//date formatter
            String invoiceDateString = formatter.format(invoiceDate);//formate invoice datetime to date

    		
            ApplicationContext context =new ClassPathXmlApplicationContext("Spring-Mail.xml");//Springmail.xml for send mail bean
		    if(toEmailIds!=null && invoiceDetails.size()>0){
		    	 MailMail mailsender = (MailMail) context.getBean("mailMail");
        	     String templateName="invoiceTemplate.vm";
        	     HashMap<String, String> model=new HashMap<>();
        	     model.put("transporterDetails", invoiceDetails.get(0).getTransportDetails());//adding transport details as mail parameter
        	     model.put("lrDetails", lrDetails);//adding lrDetails as mail parameter
                 String subject=invoiceNo+" dated "+invoiceDateString+"-"+customertName;//formatting subject line for mail

    			 mailsender.sendEmailsWithAttachment(toEmailIds, 
    					 subject,  fileName, templateName,model);//method to send mail with to mail id,subject,attachment name,template name as parameters
      
	
				InvoiceDTO invoiceDTO = new InvoiceDTO();
				invoiceDTO.setInvoiceNo(invoiceDetails.get(0).getInvoiceNo());
				if(invoiceDetails.get(0).getInvoiceDate()!=null)
				invoiceDTO.setInvoiceDate(Utility.formDateFormatter.print(invoiceDetails.get(0).getInvoiceDate().getTime()));//formatting invoice date
				invoiceDTO.setCreatedTime(invoiceDetails.get(0).getCreatedTime());
				invoiceDTO.setAmount(invoiceDetails.get(0).getAmount());
				invoiceDTO.setCustomerId(invoiceDetails.get(0).getCustomer().getCustomerId());
				invoiceDTO.setDeliveryChallanNo(invoiceDetails.get(0).getDeliveryChallanNo());
				invoiceDTO.setTransportDetails(invoiceDetails.get(0).getTransportDetails());
				invoiceDTO.setModeOfTransport(invoiceDetails.get(0).getModeOfTransport());
				invoiceDTO.setTransportCharges(invoiceDetails.get(0).getTransportCharges());
				invoiceDTO.setLrDetails(lrDetails);
				invoiceDTO.setMailStatus("Yes");
				invoiceDTO.setLrmailStatus("No");
				invoiceDTO.setBagCount(invoiceDetails.get(0).getBagCount());
				invoiceDTO.setFinalAmount(invoiceDetails.get(0).getFinalAmount());
				invoiceDTO.setInvoiceAmtInWords(invoiceDetails.get(0).getInvoiceAmtInWords());
				invoiceDTO.setStatus(invoiceDetails.get(0).getStatus());
				Invoice invoices = invoiceDTO.getInvoice();
				updatedInvoice = invoiceService.update(invoices);//method to update invoice with mail status
			}
		}//end of if loop
        if(updatedInvoice==true)
        	 ReportGenerator.deleteDir(fileC);//delete tep folder of report
		return new StatusResponse(updatedInvoice);
	}
	/**
	   * This Method to delete invoice 
	   * @param invoiceNo
	   * @return List<String> updated Invoice nos list
	   */
	@RequestMapping(value = "/delete", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	List<String> deleteId(
			@RequestParam(value = "invoiceNo", required = true) String invoiceNo) {
		Boolean result = false;
		Boolean invoiceDeleteResult=false;
		Boolean updateDc=false;
		 /*Method to fetch InvoiceItems details based on  invoiceNo*/
		List<InvoiceItems>invoiceItemList=invoiceItemsService.findByInvoiceNo(invoiceNo);
		 /*Method to fetch Invoice details based on  invoiceNo*/
		List<Invoice> invoiceList=invoiceService.findByInvoiceNo(invoiceNo);
		Long customerId=null;
		 customerId=invoiceList.get(0).getCustomer().getCustomerId();//get customer id
		String dcNo=invoiceList.get(0).getDeliveryChallanNo();//get delivery challan nos
		if(invoiceItemList.size()>0){
			for(int k=0;k<invoiceItemList.size();k++){
				result=invoiceItemsService.delete(invoiceItemList.get(k).getInvoiceId());//method to delete invoice items
			}//end of for loop
		}//end of if loop
		if(result==true){
			invoiceDeleteResult=invoiceService.delete(invoiceNo);//method to delete invoice
		}
		if(invoiceDeleteResult==true){
			//Revert dc status after deleting invoice
			 /*Method to fetch DeliveryChallan details based on  DeliveryChallan No*/
			List<DeliveryChallan> dcList=deliveryChallanService.findByDeliveryChallanNo(dcNo);
			if(dcList.size()>0){
				for(int m=0;m<dcList.size();m++){
					DeliveryChallanDTO deliveryChallanDTO=new DeliveryChallanDTO();
				
					deliveryChallanDTO.setDeliveryChallanNo(dcList.get(m).getDeliveryChallanNo());
					if(dcList.get(m).getChallanDate()!=null)
					deliveryChallanDTO.setChallanDate(Utility.formDateFormatter.print(dcList.get(m).getChallanDate().getTime()));
					if(dcList.get(m).getCreatedTime()!=null)
					deliveryChallanDTO.setCreatedTime(dcList.get(m).getCreatedTime().toString());
					deliveryChallanDTO.setInvoiceStatus("No");
					deliveryChallanDTO.setInvoiceNo(null);
					deliveryChallanDTO.setOrderId(dcList.get(m).getOrders().getOrderId());
					deliveryChallanDTO.setStatus(dcList.get(m).getStatus());
	    			deliveryChallanDTO.setRemarks(dcList.get(m).getRemarks());
	    		
				   	DeliveryChallan deliveryChallan=deliveryChallanDTO.getDeliveryChallan();
					updateDc=deliveryChallanService.update(deliveryChallan);//method to update delivery challan 
				}//end of for loop
			}//end of inner if loop
		}
		ArrayList<String> invoiceNosList = new ArrayList<>();
		if(updateDc==true && customerId!=null ){
			/*Method to fetch remaining invoice nos for selected customer after deleting invoice */
				List<Invoice> invoiceDetails = invoiceService.findByCustomerId(customerId);
		    	for (int iterator = 0; iterator < invoiceDetails.size(); iterator++) {
				String invoiceNos = invoiceDetails.get(iterator).getInvoiceNo();//get invoice nos
				if (!invoiceNosList.contains(invoiceNos)) {
					invoiceNosList.add(invoiceNos);//adding distinct invoice nos to list
				}
			}//end of for loop

		}//end of if loop
		return invoiceNosList;
	}
	/**
	   * This Method to generate invoice report
	   * @param invoiceNo
	   * @return 
	   */
	@RequestMapping(value = "/testReport", produces = "application/pdf", method = RequestMethod.GET)
	public void InvoiceReport(@RequestParam(value = "invoiceNo", required = true) String invoiceNo,javax.servlet.http.HttpServletResponse response) throws IOException, InterruptedException{
		
		InputStream inputStreamInvoicePrint = getClass().getClassLoader().getResourceAsStream("/org/balajicables/salesmanager/report/InvoiceReport.jrxml");
		 Map<String, Object> hm= new HashMap<String, Object>();
	     hm.put("INVOICE_NO", invoiceNo);//add report parameter
		 byte[] content = ReportGenerator.newReportGenerator(inputStreamInvoicePrint,hm);//m,ethod to generate report
	     response.setContentType("application/pdf");
			
		response.setHeader("Content-Disposition", "attachment;filename=" + "InvoiceReport"+invoiceNo+".pdf");
		response.setContentLength(content.length);
	    FileCopyUtils.copy(content, response.getOutputStream());		 
	}
	/**
	   * This Method to generate invoice report for print and set invoice to submitted
	   * @param invoiceNo
	   * @return 
	   */
@RequestMapping(value = "/invoicePrintReport", produces = "application/pdf", method = RequestMethod.GET)
public void InvoicePrintReport(@RequestParam(value = "invoiceNo", required = true) String invoiceNo,javax.servlet.http.HttpServletResponse response) throws IOException, InterruptedException{
	String dcNo=null;	
	/*This Method to fetch invoice details based on invoice no*/
	List<Invoice>invoiceList=invoiceService.findByInvoiceNo(invoiceNo);
	Boolean submitDcResult=false;
	Boolean submitInvoiceResult=false;
	if(invoiceList.size()>0){
		dcNo=invoiceList.get(0).getDeliveryChallanNo();//get delivery challan no
		/*This Method to fetch delivery challan details based on DeliveryChallan no*/
		List<DeliveryChallan>dcList=deliveryChallanService.findByDeliveryChallanNo(dcNo);
		if(dcNo!=null && dcNo!="" && dcList.size()>0){
			DeliveryChallanDTO deliveryChallanDTO=new DeliveryChallanDTO();
			deliveryChallanDTO.setDeliveryChallanNo(dcList.get(0).getDeliveryChallanNo());
			deliveryChallanDTO.setChallanDate(Utility.formDateFormatter.print(dcList.get(0).getChallanDate().getTime()));//formatting challan date
		    if(dcList.get(0).getCreatedTime()!=null)
			deliveryChallanDTO.setCreatedTime(dcList.get(0).getCreatedTime().toString());
			deliveryChallanDTO.setInvoiceStatus(dcList.get(0).getInvoiceStatus());
			deliveryChallanDTO.setInvoiceNo(dcList.get(0).getInvoiceNo());
			deliveryChallanDTO.setOrderId(dcList.get(0).getOrders().getOrderId());
			deliveryChallanDTO.setDcSupervisor(dcList.get(0).getDcSupervisor());
			deliveryChallanDTO.setStatus("Submitted");//set statsutosubmitted
			deliveryChallanDTO.setRemarks(dcList.get(0).getRemarks());
			DeliveryChallan deliveryChallan=deliveryChallanDTO.getDeliveryChallan();
			submitDcResult = deliveryChallanService.update(deliveryChallan);//method to update delivery challan

			InvoiceDTO invoiceDTO = new InvoiceDTO();
			invoiceDTO.setInvoiceNo(invoiceList.get(0).getInvoiceNo());
			if(invoiceList.get(0).getInvoiceDate()!=null)
			invoiceDTO.setInvoiceDate(Utility.formDateFormatter.print(invoiceList.get(0).getInvoiceDate().getTime()));//formatting invoice date
			invoiceDTO.setCreatedTime(invoiceList.get(0).getCreatedTime());
			invoiceDTO.setAmount(invoiceList.get(0).getAmount());
			invoiceDTO.setCustomerId(invoiceList.get(0).getCustomer().getCustomerId());
			invoiceDTO.setDeliveryChallanNo(invoiceList.get(0).getDeliveryChallanNo());
			invoiceDTO.setTransportDetails(invoiceList.get(0).getTransportDetails());
			invoiceDTO.setModeOfTransport(invoiceList.get(0).getModeOfTransport());
			invoiceDTO.setTransportCharges(invoiceList.get(0).getTransportCharges());
			invoiceDTO.setLrDetails(invoiceList.get(0).getLrDetails());
			invoiceDTO.setMailStatus(invoiceList.get(0).getMailStatus());
			invoiceDTO.setLrmailStatus(invoiceList.get(0).getMailStatus());
			invoiceDTO.setBagCount(invoiceList.get(0).getBagCount());
			invoiceDTO.setFinalAmount(invoiceList.get(0).getFinalAmount());
			invoiceDTO.setInvoiceAmtInWords(invoiceList.get(0).getInvoiceAmtInWords());

			invoiceDTO.setStatus("Submitted");//set status to submitted
			invoiceDTO.setRemarks(invoiceList.get(0).getRemarks());
			Invoice invoices = invoiceDTO.getInvoice();
			submitInvoiceResult = invoiceService.update(invoices);//methdo to update invoice
		}//end of inner if loop
	}//end of if loop
			 if(submitDcResult==true && submitInvoiceResult==true){
	            InputStream inputStreamInvoicePrint = getClass().getClassLoader().getResourceAsStream("/org/balajicables/salesmanager/report/Invoice.jrxml");
				Map<String, Object> hm= new HashMap<String, Object>();
			        hm.put("INVOICE_NO", invoiceNo);//adding invoice report parameter
			        byte[] content = ReportGenerator.newReportGenerator(inputStreamInvoicePrint,hm);
			  		response.setContentType("application/pdf");
         			response.setHeader("Content-Disposition", "attachment;filename=" + "InvoicePrint"+invoiceNo+".pdf");
				response.setContentLength(content.length);
			    FileCopyUtils.copy(content, response.getOutputStream());
			 }	//end of if loop
}	
/**
 * This Method to cancel invoice report
 * @param invoiceNo,remark
 * @return List<String> cancel message
 */
@RequestMapping(value = "/cancelInvoice", produces = "application/json", method = RequestMethod.POST)
public @ResponseBody
List<String> cancelInvoice(	@RequestParam(value = "invoiceNo", required = true) String invoiceNo,
	                    	@RequestParam(value = "remarks", required = true) String remarks) {
	
	/*This Method to fetch Invoice details based on Invoice no*/
	List<Invoice>invoiceList=invoiceService.findByInvoiceNo(invoiceNo);
	List<String>cancelMessage=new ArrayList<>();
	String cancelMssg="";
	Boolean invoiceItemResult=false;
	Boolean updatedInvoiceResult=false;
	//Boolean dcItemResult=false;
	//Boolean packingSlipResult=false;
	String dcNo="";
	if(invoiceList.size()>0){
		String status=invoiceList.get(0).getStatus();//get invoice status
		dcNo=invoiceList.get(0).getDeliveryChallanNo();//get delivery challan no
		if(status.equalsIgnoreCase("submitted")){
			/*This Method to fetch Invoice Item details based on Invoice no*/
			List<InvoiceItems>invoiceItemList=invoiceItemsService.findByInvoiceNo(invoiceNo);	
			if(invoiceItemList.size()>0){
				for(int k=0;k<invoiceItemList.size();k++){
					invoiceItemResult=invoiceItemsService.delete(invoiceItemList.get(k).getInvoiceId());
				}
			}//end of if(invoiceItemList.size()>0) loop
			if(invoiceItemResult==true){
				InvoiceDTO invoiceDTO = new InvoiceDTO();
				invoiceDTO.setInvoiceNo(invoiceList.get(0).getInvoiceNo());
				if(invoiceList.get(0).getInvoiceDate()!=null)
				invoiceDTO.setInvoiceDate(Utility.formDateFormatter.print(invoiceList.get(0).getInvoiceDate().getTime()));//formatting invoice date
				invoiceDTO.setCreatedTime(invoiceList.get(0).getCreatedTime());
				invoiceDTO.setAmount(invoiceList.get(0).getAmount());
				invoiceDTO.setCustomerId(invoiceList.get(0).getCustomer().getCustomerId());
				invoiceDTO.setDeliveryChallanNo(invoiceList.get(0).getDeliveryChallanNo());
				invoiceDTO.setTransportDetails(invoiceList.get(0).getTransportDetails());
				invoiceDTO.setModeOfTransport(invoiceList.get(0).getModeOfTransport());
				invoiceDTO.setTransportCharges(invoiceList.get(0).getTransportCharges());
				invoiceDTO.setLrDetails(invoiceList.get(0).getLrDetails());
				invoiceDTO.setMailStatus(invoiceList.get(0).getMailStatus());
				invoiceDTO.setLrmailStatus(invoiceList.get(0).getLrmailStatus());
				invoiceDTO.setBagCount(invoiceList.get(0).getBagCount());
				invoiceDTO.setFinalAmount(invoiceList.get(0).getFinalAmount());
				invoiceDTO.setInvoiceAmtInWords(invoiceList.get(0).getInvoiceAmtInWords());
				
				invoiceDTO.setStatus("Cancelled");//set invoice status to cancelled
				invoiceDTO.setRemarks(remarks);
				Invoice invoices = invoiceDTO.getInvoice();
				updatedInvoiceResult = invoiceService.update(invoices);
			}//end of if(invoiceItemResult==true) loop
			if(updatedInvoiceResult==true && dcNo!=null && dcNo!=""){
				/*This Method to fetch DeliveryChallan Item details based on DeliveryChallan no*/
				List<DeliveryChallanItems>dcItemList=deliveryChallanItemsService.findByDeliveryChallanNo(dcNo);
				/*This Method to fetch DeliveryChallan details based on DeliveryChallan no*/
				List<DeliveryChallan>dcList=deliveryChallanService.findByDeliveryChallanNo(dcNo);
				/*This Method to fetch StockOut details based on DeliveryChallan no*/
				List<StockOut>stockOutList=stockOutService.findByDeliveryChallanNo(dcNo);
			//	Long customerId=dcList.get(0).getOrders().getCustomer().getCustomerId();
				String salesorderNumber=dcList.get(0).getOrders().getOrderId();//get salesorder no
				Boolean deleteDcItemResult=false;
				Boolean updateDcResult=false;
				//Boolean deleteStockOutResult=false;
				Boolean deletepackingSlipResult=false;
				if(dcItemList.size()>0){
					for(int k=0;k<dcItemList.size();k++){
						//deleting dc items of cancelled delivery challan no
						deleteDcItemResult=deliveryChallanItemsService.delete(dcItemList.get(k).getDcItemId());
					}
				}//end of if loop
				if(deleteDcItemResult==true){
					/*This Method to fetch PackingSlip details based on DeliveryChallan no*/
					List<PackingSlip>packingSlipList=packingSlipService.findByDeliveryChallanNo(dcNo);
				for(int m=0;m<packingSlipList.size();m++){
					//deleting packing slip entries of cancelled delivery challan no
					deletepackingSlipResult=packingSlipService.delete(packingSlipList.get(m).getPackingSlipId());
				}//end of for loop
					if(deletepackingSlipResult==true){
						DeliveryChallanDTO deliveryChallanDTO=new DeliveryChallanDTO();
						deliveryChallanDTO.setDeliveryChallanNo(dcList.get(0).getDeliveryChallanNo());
						deliveryChallanDTO.setChallanDate(Utility.formDateFormatter.print(dcList.get(0).getChallanDate().getTime()));
						if(dcList.get(0).getCreatedTime()!=null)
						deliveryChallanDTO.setCreatedTime(dcList.get(0).getCreatedTime().toString());
						deliveryChallanDTO.setInvoiceStatus(dcList.get(0).getInvoiceStatus());
						deliveryChallanDTO.setInvoiceNo(dcList.get(0).getInvoiceNo());
						deliveryChallanDTO.setOrderId(dcList.get(0).getOrders().getOrderId());
						deliveryChallanDTO.setDcSupervisor(dcList.get(0).getDcSupervisor());
						deliveryChallanDTO.setStatus("Cancelled");//set status to cancelled
						deliveryChallanDTO.setRemarks(remarks);
						DeliveryChallan deliveryChallan=deliveryChallanDTO.getDeliveryChallan();
					    updateDcResult = deliveryChallanService.update(deliveryChallan);//method to update delivery challan
					}
				}
				if(updateDcResult==true && stockOutList.size()>0){
					for(int l=0;l<stockOutList.size();l++){
						/*This Method to fetch StockOut details based on StockOut id*/
					List<StockOut>stockOutIdList=stockOutService.findByStockOutId(stockOutList.get(l).getStockOutId());
					if(stockOutIdList.size()>0){
						String itemType=stockOutIdList.get(0).getSalesOrderItem().getItem().getItemType();
						Long itemId=stockOutIdList.get(0).getSalesOrderItem().getItem().getItemId();
						Long soItemId=stockOutIdList.get(0).getSalesOrderItem().getOrderDetailId();
						String unitsValue=stockOutIdList.get(0).getSalesOrderItem().getItem().getUnit().getUnits();
						Double stockOutQtyMts=stockOutIdList.get(0).getStockOutQty();
						Double stockOutQtyWeight=stockOutIdList.get(0).getWeight();
						if(itemType.equalsIgnoreCase("SCRAP")){
							List<ScrapStoreReg>scrapStoreRegList=scrapStoreRegService.findByItemsItemId(itemId);
							if(scrapStoreRegList.size()>0){
								
							ScrapStoreRegDTO scrapStoreRegDTO=new ScrapStoreRegDTO();
							scrapStoreRegDTO.setScrapStoreRegId(scrapStoreRegList.get(0).getScrapStoreRegId());
							
							if(scrapStoreRegList.get(0).getStockQuantity()==null && stockOutIdList.get(0).getStockOutQty()==null)
							scrapStoreRegDTO.setStockQuantity(0.0);
		                	else if(scrapStoreRegList.get(0).getStockQuantity()==null)
		    				scrapStoreRegDTO.setStockQuantity(0+stockOutIdList.get(0).getStockOutQty());
		                	else if(stockOutIdList.get(0).getStockOutQty()==null)
		                	scrapStoreRegDTO.setStockQuantity(scrapStoreRegList.get(0).getStockQuantity()+0);
		                	else
		        			scrapStoreRegDTO.setStockQuantity(scrapStoreRegList.get(0).getStockQuantity()+stockOutIdList.get(0).getStockOutQty());

							
							
							scrapStoreRegDTO.setStockQuantity(scrapStoreRegList.get(0).getStockQuantity()+stockOutIdList.get(0).getStockOutQty());
							scrapStoreRegDTO.setUpdatedBy(scrapStoreRegList.get(0).getUpdatedBy());
							scrapStoreRegDTO.setItemId(scrapStoreRegList.get(0).getItems().getItemId());
							scrapStoreRegDTO.setStockOutQty(scrapStoreRegList.get(0).getStockOutQty());
							scrapStoreRegDTO.setStoreId(scrapStoreRegList.get(0).getStore().getStoreId());
							ScrapStoreReg scrapStoreReg=scrapStoreRegDTO.getScrapStoreReg();
							scrapStoreRegService.update(scrapStoreReg);
							  stockOutService.delete(stockOutIdList.get(0).getStockOutId());

							}else{
							ScrapStoreRegDTO scrapStoreRegDTOs=new ScrapStoreRegDTO();
							scrapStoreRegDTOs.setStockQuantity(stockOutIdList.get(0).getStockOutQty());
							scrapStoreRegDTOs.setUpdatedBy(stockOutIdList.get(0).getSupervisor());
							scrapStoreRegDTOs.setItemId(stockOutIdList.get(0).getSalesOrderItem().getItems().getItemId());
							scrapStoreRegDTOs.setStockOutQty(null);
							scrapStoreRegDTOs.setStoreId(stockOutIdList.get(0).getStore().getStoreId());
							ScrapStoreReg scrapStoreRegs=scrapStoreRegDTOs.getScrapStoreReg();
							ScrapStoreReg craetedScrapStoreReg=scrapStoreRegService.create(scrapStoreRegs);
							 if(craetedScrapStoreReg!=null){
							   stockOutService.delete(stockOutIdList.get(0).getStockOutId());
							 }
						
							}
							
						}//delete delivery challan of scrap items
						else{
							Boolean storeCreate=false;
							List<StoreRegister>storeRegList=storeRegisterService.
									findByOrderDetailIdAndBundleIdAndWorkOrderNo(stockOutIdList.get(0).getSalesOrderItem().getOrderDetailId(), stockOutIdList.get(0).getBundleId(),
											stockOutIdList.get(0).getProductionWorkOrder().getWorkOrderNo());
							if(!(storeRegList.size()>0)){
							StoreRegisterDTO storeRegisterDTO=new StoreRegisterDTO();
							storeRegisterDTO.setItemCode(stockOutIdList.get(0).getItemCode());
							storeRegisterDTO.setStoreId(stockOutIdList.get(0).getStore().getStoreId());
							storeRegisterDTO.setWorkOrderNo(stockOutIdList.get(0).getProductionWorkOrder().getWorkOrderNo());
							storeRegisterDTO.setCustomerName(stockOutIdList.get(0).getSalesOrderItem().getOrder().getCustomer().getCustomerName());
							storeRegisterDTO.setStockQty(stockOutIdList.get(0).getStockOutQty());
							storeRegisterDTO.setBundleId(stockOutIdList.get(0).getBundleId());
							storeRegisterDTO.setOrderId(stockOutIdList.get(0).getOrderId());
							storeRegisterDTO.setOrderDetailId(stockOutIdList.get(0).getSalesOrderItem().getOrderDetailId());
							storeRegisterDTO.setItemId(stockOutIdList.get(0).getItemId());
							storeRegisterDTO.setPackingSlipNo(null);
							storeRegisterDTO.setSupervisor(stockOutIdList.get(0).getSupervisor());
							storeRegisterDTO.setWeight(stockOutIdList.get(0).getWeight());
							storeRegisterDTO.setBagWeight(null);
							storeRegisterDTO.setQcStatus(stockOutIdList.get(0).getQcStatus());
							storeRegisterDTO.setRejectStatus("");
							storeRegisterDTO.setQcSupervisor(stockOutIdList.get(0).getQcSupervisor());
							storeRegisterDTO.setRemarks(stockOutIdList.get(0).getRemarks());
							StoreRegister storeRegister=storeRegisterDTO.getStoreRegister();
							StoreRegister craetedStoreReg=storeRegisterService.create(storeRegister);
							if(craetedStoreReg!=null)
								storeCreate=true;
							}else
								storeCreate=true;
							if(storeCreate==true && stockOutIdList.get(0).getStockOutId()!=null){
								stockOutService.delete(stockOutIdList.get(0).getStockOutId());
							   }
						 }//delete delivery challan of items
						//Reverting back item quantities of sales order after cancelling DC
						//method to fetch sales order items based on sales order item id
							    List<SalesOrderItem>soItemList=orderDetailsService.findById(soItemId);
							    if(soItemList.size()>0){
							    Double newDispatchedQty=0.0;
							    Double newCompletedQty=0.0;
							    if(soItemList.get(0).getDispatchedQty()>0)
							    	//calculating dispatched and completed quantity based on item type
							    	if(unitsValue.equalsIgnoreCase("Kgs") || unitsValue.equalsIgnoreCase("Kg") ){
							    		  newDispatchedQty=soItemList.get(0).getDispatchedQty()-stockOutQtyWeight;
								          newCompletedQty=soItemList.get(0).getCompletedQty()+stockOutQtyWeight;
								  
							    	}else{
							    	      newDispatchedQty=soItemList.get(0).getDispatchedQty()-stockOutQtyMts;
								          newCompletedQty=soItemList.get(0).getCompletedQty()+stockOutQtyMts;
								    
							    	}
							    
							    Double balanceQty=0.0;
							    //calcualte balance quantity
							    balanceQty=soItemList.get(0).getQuantity()-(soItemList.get(0).getProductionQty()+newCompletedQty+newDispatchedQty);
							    if(balanceQty<0.0)
							    balanceQty=0.0;
							    SalesOrderItemsDTO dto = new SalesOrderItemsDTO();
								dto.setOrderDetailId(soItemList.get(0).getOrderDetailId());
								dto.setOrderId(soItemList.get(0).getOrder().getOrderId());
		                     	dto.setItemId(soItemList.get(0).getItem().getItemId());
		                		dto.setQuantity(soItemList.get(0).getQuantity());
								dto.setBalanceQty(balanceQty);
								dto.setProductionQty(soItemList.get(0).getProductionQty());
								dto.setCompletedQty(newCompletedQty);
								dto.setDispatchedQty(newDispatchedQty);
								dto.setWoQty(soItemList.get(0).getWoQty());
								dto.setWeight(soItemList.get(0).getWeight());
								dto.setBundleSize(soItemList.get(0).getBundleSize());
								dto.setRate(soItemList.get(0).getRate());
								dto.setItemCode(soItemList.get(0).getItemCode());
								dto.setUpdatedBy(soItemList.get(0).getUpdatedBy());
								dto.setPvcWeight(soItemList.get(0).getPvcWeight());
								
								SalesOrderItem newSoItemList=dto.getOrderDetail();
								orderDetailsService.update(newSoItemList);//method to update sales order item
							}
					
						}//end of if(stockOutIdList.size()>0) loop
					}//end of for loop
				}//end of if loop
				
				if(updateDcResult==true){
					//Updating statusof sales order after cancelling corresponding delivery challan
					//method to fetch sales order detaisl based on sales order no
					List<SalesOrder>salesOrderList=orderService.findBySalesOrderNoId(salesorderNumber);
					String orderStatus="Approved";
					//method to fetch sales order status id for status="Approved"
					List<OrderStatus>orderStatusList=orderStatusService.findByStatus(orderStatus);
					if(salesOrderList.size()>0){
						OrderDTO orderDTO=new OrderDTO();
						orderDTO.setCreatedBy(salesOrderList.get(0).getCreatedBy());
						orderDTO.setCreatedTime(salesOrderList.get(0).getCreatedTime().toString());
						orderDTO.setCustomerId(salesOrderList.get(0).getCustomer().getCustomerId());
						orderDTO.setCustomerName(salesOrderList.get(0).getCustomer().getCustomerName());
						orderDTO.setInputQuantity(salesOrderList.get(0).getInputQuantity());
						orderDTO.setModeOfReceipt(salesOrderList.get(0).getModeOfReceipt());
						if(salesOrderList.get(0).getOrderAcceptanceDate()!=null)
						orderDTO.setOrderAcceptanceDate(Utility.formDateFormatter.print(salesOrderList.get(0).getOrderAcceptanceDate().getTime()));//formtting date
						if(salesOrderList.get(0).getOrderDeliveryDate()!=null)
						orderDTO.setOrderDeliveryDate(Utility.formDateFormatter.print(salesOrderList.get(0).getOrderDeliveryDate().getTime()));//formtting date
					
						orderDTO.setOrderId(salesOrderList.get(0).getOrderId());
						if(salesOrderList.get(0).getOrderRecDate()!=null)
						orderDTO.setOrderRecDate(Utility.formDateFormatter.print(salesOrderList.get(0).getOrderRecDate().getTime()));//formtting date
						orderDTO.setOrderStatusId(orderStatusList.get(0).getOrderStatusId());
						orderDTO.setPoDetails(salesOrderList.get(0).getPoDetails());
						orderDTO.setStatus("Approved");//set sales order status to approved
						if(salesOrderList.get(0).getTargetDate()!=null)
						orderDTO.setTargetDate(Utility.formDateFormatter.print(salesOrderList.get(0).getTargetDate().getTime()));//formtting date
						orderDTO.setUpdatedBy(salesOrderList.get(0).getUpdatedBy());
						orderDTO.setUpdatedTime(salesOrderList.get(0).getUpdatedTime().toString());
						orderDTO.setMailStatus(salesOrderList.get(0).getMailStatus());
						SalesOrder soOrder=orderDTO.getOrder();
						orderService.update(soOrder);//method to updates ales order
					}//endof inner if loop
				}//end of if(updateDcResult==true)loop
			}// end of if loop of dc functionality
			cancelMssg="Cancelled";//cancel message
		}else{
			cancelMssg="Not Submitted";//not submitted message
		}
		
	}//end of outer if loop
	cancelMessage.add(cancelMssg);//adding mesaage to return lsit
	return cancelMessage;
}
/**
 * This Method to send invoice mail with 3 attachments(dc report,packig slip report and invoice report)
 * @param invoiceNo
 * @return StatusResponse
 */
@RequestMapping(value = "/invoiceMail", produces = "application/json", method = RequestMethod.POST)
public @ResponseBody
StatusResponse invoiceMail(@RequestParam(value = "invoiceNo", required = true) String invoiceNo) throws IOException {
	 String pathC = "C:\\ReportPDFs";//report temp folder 
	 File fileC = new File(pathC);//create report temp folder
	 //Method to fetch invoice details based on invoice no
 	 List<Invoice> invoiceDetails = invoiceService.findByInvoiceNo(invoiceNo);
 	 Boolean updatedInvoice = false;
     String[] toEmailIds=null;//sinitialize string array for multiple customer mail ids
	 
	if (invoiceDetails.size() > 0) {
		//amountValue=invoiceDetails.get(0).getAmount();
		 Long custId=invoiceDetails.get(0).getCustomer().getCustomerId();//get customer id
		 Date invoiceDate=invoiceDetails.get(0).getInvoiceDate();//get invoice date
		 String customertName=invoiceDetails.get(0).getCustomer().getCustomerName();//get customer name
		 String dcNo=invoiceDetails.get(0).getDeliveryChallanNo();//get delivery challan no
		 //method to fetch customer details by customer id
		 List<Customer> custDetail=customerService.findById(custId);
		 String emailAddress=null;
		  if(custDetail.size()>0){
			  emailAddress= custDetail.get(0).getEmail();//get customer enmail
		 }//end of if loo[
		
		  String invoiceFileName= generateInvoiceReport(invoiceNo,pathC,fileC);//method to generate invoice report
		  String dcFileName =generateDeliveryChallanReport(dcNo,pathC,fileC);//method to generate delivery challan report
		  String packingSlipFileName =generatePackingSlipReport(dcNo,pathC,fileC);//method to generate packing slip report
	
		  String[] attachmentFileName={invoiceFileName,dcFileName,packingSlipFileName};
		  
        if(emailAddress!=null){
        	toEmailIds = emailAddress.split(";", -1);//adding list to customer emails to a string 
        }
	 
        Format formatter = new SimpleDateFormat("dd-MM-yyyy");//date formatter
        String invoiceDateString = formatter.format(invoiceDate);//formatting invoice date time to date

        ApplicationContext context =new ClassPathXmlApplicationContext("Spring-Mail.xml");
	    if(toEmailIds!=null && invoiceDetails.size()>0){
	    	 MailMail mailsender = (MailMail) context.getBean("mailMail");//get amil sender bean from spring mail.xml
    	     String templateName="invoiceTemplate.vm";//invoice mail template
    	     HashMap<String, String> model=new HashMap<>();
    	   //adding parameters of report to model attribute
    	     model.put("invoiceNo", invoiceNo);
    	     model.put("invoiceDate", invoiceDateString);
    	     model.put("customerName", customertName);
    	    // model.put("lrDetails", lrDetails);
             String subject=invoiceNo+" dated "+invoiceDateString+"-"+customertName;//Subject of email

			 mailsender.sendEmailsWithAttachment(toEmailIds, subject,  attachmentFileName, templateName,model);//call send email with attachments method
  
			InvoiceDTO invoiceDTO = new InvoiceDTO();
			invoiceDTO.setInvoiceNo(invoiceDetails.get(0).getInvoiceNo());
			if(invoiceDetails.get(0).getInvoiceDate()!=null)
			invoiceDTO.setInvoiceDate(Utility.formDateFormatter.print(invoiceDetails.get(0).getInvoiceDate().getTime()));//formatting date
			invoiceDTO.setCreatedTime(invoiceDetails.get(0).getCreatedTime());
			invoiceDTO.setAmount(invoiceDetails.get(0).getAmount());
			invoiceDTO.setCustomerId(invoiceDetails.get(0).getCustomer().getCustomerId());
			invoiceDTO.setDeliveryChallanNo(invoiceDetails.get(0).getDeliveryChallanNo());
			invoiceDTO.setTransportDetails(invoiceDetails.get(0).getTransportDetails());
			invoiceDTO.setModeOfTransport(invoiceDetails.get(0).getModeOfTransport());
			invoiceDTO.setTransportCharges(invoiceDetails.get(0).getTransportCharges());
			invoiceDTO.setLrDetails(invoiceDetails.get(0).getLrDetails());
			invoiceDTO.setMailStatus("Yes");//set mail status
			invoiceDTO.setLrmailStatus(invoiceDetails.get(0).getLrmailStatus());
			invoiceDTO.setBagCount(invoiceDetails.get(0).getBagCount());
			invoiceDTO.setFinalAmount(invoiceDetails.get(0).getFinalAmount());
			invoiceDTO.setInvoiceAmtInWords(invoiceDetails.get(0).getInvoiceAmtInWords());
			invoiceDTO.setStatus(invoiceDetails.get(0).getStatus());
			Invoice invoices = invoiceDTO.getInvoice();
			updatedInvoice = invoiceService.update(invoices);//update invoice
		}
	}//end of outer if loop
    if(updatedInvoice==true)
    	 ReportGenerator.deleteDir(fileC);//delete temp folder of reports
	return new StatusResponse(updatedInvoice);
}
/**
 * This Method to generate packing slip report
 * @param deliveryChallanNo
 * @return List<String>
 */
private String generatePackingSlipReport(String deliveryChallanNo, String pathC, File fileC) throws IOException {
	InputStream inputStream = getClass().getClassLoader().getResourceAsStream("/org/balajicables/salesmanager/report/PackingSlipReport.jrxml");
	
	 Map<String, Object> hm= new HashMap<String, Object>();
    hm.put("DC_NO", deliveryChallanNo);//adding report parameter
    byte[] content = ReportGenerator.newReportGenerator(inputStream,hm);
    if(!(fileC.exists())){
       fileC.mkdir();//create temp report folder
    }
	   String fileName=pathC+"\\PackingSlip"+deliveryChallanNo+".pdf";//packing slip file name
		File f = new File(fileName);
		
		FileOutputStream fos = new FileOutputStream(f);
		fos.write(content, 0, content.length);
		fos.close();
		return fileName;

}

/**
 * This Method to generate DeliveryChallan report
 * @param deliveryChallanNo
 * @return List<String>
 */
private String generateDeliveryChallanReport(String deliveryChallanNo, String pathC,File fileC) throws IOException {
	InputStream inputStream = getClass().getClassLoader().getResourceAsStream("/org/balajicables/salesmanager/report/DeliveryChallanReport.jrxml");
	
	 Map<String, Object> hm= new HashMap<String, Object>();
    hm.put("DELIVERY_CHALLAN_NO", deliveryChallanNo);//adding report parameter
    byte[] content = ReportGenerator.newReportGenerator(inputStream,hm);
   
    if(!(fileC.exists())){
        fileC.mkdir();//create temp report folder
     }
	   String fileName=pathC+"\\DeliveryChallan"+deliveryChallanNo+".pdf";//DeliveryChallan file name
		File f = new File(fileName);
		
		FileOutputStream fos = new FileOutputStream(f);
		fos.write(content, 0, content.length);
		fos.close();
		return fileName;
}

/**
 * This Method to generate Invoice report
 * @param deliveryChallanNo
 * @return List<String>
 */
private String generateInvoiceReport(String invoiceNo,String pathC,File fileC) throws IOException {
	InputStream inputStreamInvoicePrint = getClass().getClassLoader().getResourceAsStream("/org/balajicables/salesmanager/report/InvoiceReport.jrxml");
	 Map<String, Object> hm= new HashMap<String, Object>();
     hm.put("INVOICE_NO", invoiceNo);//adding report parameter
	 byte[] content = ReportGenerator.newReportGenerator(inputStreamInvoicePrint,hm);
	  if(!(fileC.exists())){
	       fileC.mkdir();//create temp report folder
	    }
	   String fileName=pathC+"\\InvoiceReport"+invoiceNo+".pdf";//Invoice file name
		File f = new File(fileName);
		
		FileOutputStream fos = new FileOutputStream(f);
		fos.write(content, 0, content.length);
		fos.close();
		return fileName;
}
/**
 * This Method to send lr mail
 * @param invoiceNo,lrDetails
 * @return StatusResponse
 */
@RequestMapping(value = "/lrMaill", produces = "application/json", method = RequestMethod.POST)
public @ResponseBody
StatusResponse lrMaill(@RequestParam(value = "invoiceNo", required = true) String invoiceNo,
		@RequestParam(value = "lrDetails", required = true) String lrDetails) throws IOException {
//method to fetch invoice details based on invoice no
	List<Invoice> invoiceDetails = invoiceService.findByInvoiceNo(invoiceNo);
 	Boolean updatedInvoice = false;
     String[] toEmailIds=null;
		if (invoiceDetails.size() > 0) {
		//amountValue=invoiceDetails.get(0).getAmount();
		 Long custId=invoiceDetails.get(0).getCustomer().getCustomerId();//get customer id
		 Date invoiceDate=invoiceDetails.get(0).getInvoiceDate();//get invoice date
		 String customertName=invoiceDetails.get(0).getCustomer().getCustomerName();//get customer name
		//method to fetch Customer details based on customer id
		 List<Customer> custDetail=customerService.findById(custId);
		 String emailAddress=null;
		  if(custDetail.size()>0){
			  emailAddress= custDetail.get(0).getEmail();//get customer email ids
		 }//end of if loop

        if(emailAddress!=null){
        	toEmailIds = emailAddress.split(";", -1);//adding multiple email ids tos tring
        }
	 
        Format formatter = new SimpleDateFormat("dd-MM-yyyy");//date formatter
        String invoiceDateString = formatter.format(invoiceDate);//fromatting invoice adte time to date

        ApplicationContext context =new ClassPathXmlApplicationContext("Spring-Mail.xml");
	    if(toEmailIds!=null && invoiceDetails.size()>0){
	    	 MailMail mailsender = (MailMail) context.getBean("mailMail");//get mail sender bean from springmail.xml
    	     String templateName="lrMailTemplate.vm";//lr mail template
    	     HashMap<String, String> model=new HashMap<>();
    	     model.put("transporterDetails", invoiceDetails.get(0).getTransportDetails());//adding mail parameters:transport details
    	     model.put("lrDetails", lrDetails);//adding mail parameters:lrDetails
    	     model.put("invoiceNo", invoiceNo);//adding mail parameters:invoiceNo
    	     model.put("invoiceDate", invoiceDateString);//adding mail parameters:invoiceNo
    	     model.put("customerName", customertName);//adding mail parameters:invoiceDate
             String subject="Dispatch details for invoice No:"+invoiceNo+" dated "+invoiceDateString;//Subject of LR amil

			mailsender.sendEmailsWithOutAttachment(toEmailIds, subject,templateName,model);//method tos end mailw ith attchments
  
     		InvoiceDTO invoiceDTO = new InvoiceDTO();
			invoiceDTO.setInvoiceNo(invoiceDetails.get(0).getInvoiceNo());
			if(invoiceDetails.get(0).getInvoiceDate()!=null)
			invoiceDTO.setInvoiceDate(Utility.formDateFormatter.print(invoiceDetails.get(0).getInvoiceDate().getTime()));//formatting date
			invoiceDTO.setCreatedTime(invoiceDetails.get(0).getCreatedTime());
			invoiceDTO.setAmount(invoiceDetails.get(0).getAmount());
			invoiceDTO.setCustomerId(invoiceDetails.get(0).getCustomer().getCustomerId());
			invoiceDTO.setDeliveryChallanNo(invoiceDetails.get(0).getDeliveryChallanNo());
			invoiceDTO.setTransportDetails(invoiceDetails.get(0).getTransportDetails());
			invoiceDTO.setModeOfTransport(invoiceDetails.get(0).getModeOfTransport());
			invoiceDTO.setTransportCharges(invoiceDetails.get(0).getTransportCharges());
			invoiceDTO.setLrDetails(lrDetails);
			invoiceDTO.setMailStatus(invoiceDetails.get(0).getMailStatus());
			invoiceDTO.setBagCount(invoiceDetails.get(0).getBagCount());
			invoiceDTO.setFinalAmount(invoiceDetails.get(0).getFinalAmount());
			invoiceDTO.setInvoiceAmtInWords(invoiceDetails.get(0).getInvoiceAmtInWords());
			invoiceDTO.setStatus(invoiceDetails.get(0).getStatus());
			invoiceDTO.setLrmailStatus("Yes");//set lr mail statsu to yes
			Invoice invoices = invoiceDTO.getInvoice();
			updatedInvoice = invoiceService.update(invoices);//update invoice
		}//end of inner if loop
	}//end of outer if loop
    	
	return new StatusResponse(updatedInvoice);
}
}
