package org.balajicables.salesmanager.controller;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
import javax.annotation.Resource;
import org.balajicables.salesmanager.common.JqgridResponse;
import org.balajicables.salesmanager.common.StatusResponse;
import org.balajicables.salesmanager.dto.PurchaseOrderItemDTO;
import org.balajicables.salesmanager.model.PurchaseOrder;
import org.balajicables.salesmanager.model.PurchaseOrderItem;
import org.balajicables.salesmanager.service.PurchaseOrderItemService;
import org.balajicables.salesmanager.service.PurchaseOrderService;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
/**
* This class demonstrates View Purchase Order Item Module.
* @author Abin Sam
*/
@Controller
@RequestMapping("/viewpoitems")
public class ViewPoItemsController {

	@Resource
	private PurchaseOrderItemService purchaseOrderItemService;
	
	@Resource
	private PurchaseOrderService purchaseOrderService;
	
	 /**
	   * This method returns viewPurchaseOrderItems.jsp.
	   * Fetch all Purcahse Order details based on Purcahse Order No
	   * @param Model to set the attribute.
	   * @return viewPurchaseOrderItems.jsp.
	   */
	@RequestMapping(method = RequestMethod.GET)
	public String getSalesItemPage(Model model, @RequestParam(value="poNo") String poNo,
			 @RequestParam(value="status") String statusValue) {
		List<String> statusList = new ArrayList<String>();
	    model.addAttribute("poNo", poNo);//add poNo to model attribute
	    //method to fetch PO Detaisl based on poNo
	    List<PurchaseOrder>poList=purchaseOrderService.findByPoNo(poNo);
	    model.addAttribute("vendor", poList.get(0).getCustomer().getCustomerName());//add vendor to model attribute
	    model.addAttribute("mailSent",poList.get(0).getMailSent());//add mailSent status to model attribute
	    //Add status to list based on current PO status
	    if(statusValue.equalsIgnoreCase("Submitted")){
	   	statusList.add("Approved");
	 	statusList.add("Closed");
	    }else if(statusValue.equalsIgnoreCase("Approved")){
	    	statusList.add("Submitted");
	    	statusList.add("Closed");
	    }else if(statusValue.equalsIgnoreCase("Closed")){
	    	statusList.add("Submitted");
	     	statusList.add("Approved");
	    }
	    model.addAttribute("statusValue", statusValue);//add current status of PO to model attribute
	    model.addAttribute("status", statusList);//add list of Status to model attribute
		return "viewPurchaseOrderItems";
	}
	 /**
	   * This method to fetch purcahse order item details of selected po no
	   * Fetch Purcahse Order items records for Grid based on PO No
	   * @param PO No,filters,pageNumber,rowsPerPage,sortColName,sortOrder
	   * @return JqgridResponse<PurchaseOrderItemDTO> response
	   */
	@RequestMapping(value="/items/{poNo}", produces="application/json" , method=RequestMethod.POST)
	public @ResponseBody
	JqgridResponse<PurchaseOrderItemDTO> items(
		    @PathVariable("poNo") String poNo,
   	        @RequestParam("_search") Boolean search,
    		@RequestParam(value="filters", required=false) String filters,
	    	@RequestParam(value = "page", required = false) Integer pageNumber,
			@RequestParam(value = "rows", required = false) Integer rowsPerPage,
			@RequestParam(value = "sidx", required = false) String sortColName,
			@RequestParam(value = "sord", required = false, defaultValue = "asc") String sortOrder) {
		   //JQGrid column sorting
				if(sortColName.equalsIgnoreCase("itemCode")){
					sortColName="item.itemCode";
				}
				if(sortColName.equalsIgnoreCase("itemDescription")){
					sortColName="item.itemDescription";
				}
				if(sortColName.equalsIgnoreCase("unit")){
					sortColName="item.unit.units";
				}
		/*Method to fetch JQGRID paged records of PurchaseOrderItem based on PurchaseOrder No*/
		Page<PurchaseOrderItem> poItemOutput = purchaseOrderItemService.getPagedPurchaseOrderItems(poNo,pageNumber - 1,rowsPerPage, sortColName, sortOrder);
		/*Intialize JQ grid response of type PurchaseOrder items DTO*/
		JqgridResponse<PurchaseOrderItemDTO> response = new JqgridResponse<PurchaseOrderItemDTO>();
		/*Method to set PurchaseOrder item list to PurchaseOrderItemsDTO*/
		List<PurchaseOrderItemDTO> purchaseOrderItemDTOs = convertToPOItemDTO(poItemOutput.getContent(),poNo);
		response.setRows(purchaseOrderItemDTOs);
		response.setRecords(Long.valueOf(poItemOutput.getTotalElements()).toString());
		response.setTotal(Long.valueOf(poItemOutput.getTotalPages()).toString());
		response.setPage(Integer.valueOf(poItemOutput.getNumber()+1).toString());
		return response;
	}	
	 /**
	   * This Method to set PurchaseOrder item list to PurchaseOrderItemsDTO
	   * @param List<PurchaseOrderItem> PurchaseOrderItem
	   * @return List<PurchaseOrderItemDTO> response
	   */
	private List<PurchaseOrderItemDTO> convertToPOItemDTO(List<PurchaseOrderItem> purchaseorderitems,String poNo) {
		List<PurchaseOrderItemDTO> poItemDTOs = new ArrayList<>();
		for(PurchaseOrderItem poItem : purchaseorderitems) {
			PurchaseOrderItemDTO purchaseOrderItemDTO=new PurchaseOrderItemDTO();
			purchaseOrderItemDTO.setPurchaseOrderItemId(poItem.getPurchaseOrderItemId());
			purchaseOrderItemDTO.setPoNo(poItem.getPurchaseOrder().getPoNo());
			purchaseOrderItemDTO.setItemId(poItem.getItem().getItemId());
			purchaseOrderItemDTO.setItemCode(poItem.getItem().getItemCode());
			purchaseOrderItemDTO.setDescription(poItem.getItem().getItemDescription());
			purchaseOrderItemDTO.setQuantity(poItem.getQuantity());
			purchaseOrderItemDTO.setRate(poItem.getRate());
			purchaseOrderItemDTO.setPrice(poItem.getPrice());
			purchaseOrderItemDTO.setBalanceQty(poItem.getBalanceQty());
			purchaseOrderItemDTO.setUnit(poItem.getItem().getUnit().getUnits());
		    poItemDTOs.add(purchaseOrderItemDTO);
	   }//end of for loop
		return poItemDTOs;
	}
	 /**
	   * Crud functionality of PurchaseOrder item 
	   * @param id, oper(edit/add/del), poNo,itemId,quantity,description,rate
	   * @return StatusResponse
	   */
	@RequestMapping(value = "/crudPOItems", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	StatusResponse crudPOItems(@RequestParam Long id, 
			@RequestParam String oper,
			@RequestParam(required = false) String poNo,
			@RequestParam(required = false) Long itemId,
			@RequestParam(required = true) String quantity,
			@RequestParam(required = true) String description,
			@RequestParam(required = true) String rate
	) {
		PurchaseOrderItem purchaseOrderItem =null;
		Boolean result = false;
		boolean qtyMatch =false;
		boolean rateMatch =false;
		Double poTotalQty=0.0;
		Double poBalanceTotQty=0.0;
		
		/*Method to fetch PurchaseOrderItem records  on PurchaseOrderItem id*/
		List<PurchaseOrderItem> poItemList=purchaseOrderItemService.findByPoItemId(id);
		Boolean updatedPO=false;
		if(oper.equalsIgnoreCase("edit")){
			String decimalPattern = "((-|\\+)?[0-9]+(\\.[0-9]+)?)+";  
			//Pattern matching check for valid quantity and rate
			qtyMatch = Pattern.matches(decimalPattern, quantity);
			rateMatch = Pattern.matches(decimalPattern, rate);
		if(qtyMatch==true && rateMatch==true){
				Double newQuantity=Double.valueOf(quantity);//quantity to double
				Float newRate=Float.valueOf(rate);	//rate to float		
			Double existTotalQty=0.0;
			Double existBalQty=0.0;
			PurchaseOrderItemDTO poItemDTO = new PurchaseOrderItemDTO();
			if(poItemList.size()>0){
				existTotalQty=poItemList.get(0).getQuantity();
				existBalQty=poItemList.get(0).getBalanceQty();
				//Calculating balance quantity of PO
				if(newQuantity>existTotalQty){
					existBalQty=existBalQty+(newQuantity-existTotalQty);
				}
				  else{
					  existBalQty=existBalQty-(existTotalQty-newQuantity);
				  }
				Integer status=poItemList.get(0).getStatus();//get PO Status	
				poItemDTO.setPurchaseOrderItemId(id);
				poItemDTO.setPoNo(poNo);
				poItemDTO.setItemId(itemId);
			    poItemDTO.setDescription(description);
				poItemDTO.setRate(newRate);
				poItemDTO.setQuantity(newQuantity);
				if (rate != null && quantity != null)
					poItemDTO.setPrice((double) (newRate * newQuantity));//Price calculation
				poItemDTO.setStatus(status);
				poItemDTO.setBalanceQty(existBalQty);
			
			}//end of if(poItemList.size()>0) loop
		 purchaseOrderItem = poItemDTO.getPoItem();	
		}//end of inner if loop
		
		switch (oper) {
		case "edit":
			if(qtyMatch==true && rateMatch==true){
			result = purchaseOrderItemService.update(purchaseOrderItem);//method to update Purcahse order item
			}
			break;
		case "del":
			Long poItemIdToDelete = id;
			result = purchaseOrderItemService.delete(poItemIdToDelete);//method to delete Purcahse order item
			break;
		}//end of switch loop
		
		if (result == true) {
			/*Method to fetch Purcahse Order Item By PO*/
			List<PurchaseOrderItem> poItemsList = purchaseOrderItemService.findByPoNo(poNo);
            if(poItemsList.size()>0){
         	   for(int i=0;i<poItemsList.size();i++){
         	   poTotalQty=poTotalQty+poItemsList.get(i).getQuantity();//calculate Po toatl Quantity
         	   poBalanceTotQty=poBalanceTotQty+poItemsList.get(i).getBalanceQty();//Calculate PO Balance quantity
         	 }//end of for loop
            }//end of if(poItemsList.size()>0) loop
            /*Method to fetch Purcahse Order based on PO No*/
          List<PurchaseOrder> poList=purchaseOrderService.findByPoNo(poNo);
          if(poList.size()>0){
         	 poList.get(0).setQuantity(poTotalQty);//set po total quantity
         	 poList.get(0).setBalanceQuantity(poBalanceTotQty);//set po balanace quantity
         	 updatedPO=purchaseOrderService.update(poList.get(0));//update Purchase Order
          }//end of if(poList.size()>0) loop
			}//end of if (result == true) loop 
		}//end of if loop
		return new StatusResponse(updatedPO);
	}
	 /**
	   * delete functionality of PurchaseOrder item 
	   * @param purchaseOrderItemId,purchaseOrderNo
	   * @return StatusResponse
	   */
	@RequestMapping(value = "/delete/{purchaseOrderItemId}", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	StatusResponse deleteId(@PathVariable("purchaseOrderItemId") Long purchaseOrderItemId,
			@RequestParam(required = false) String purchaseOrderNo) {
		Boolean result=false;
		Boolean updatedPO=false;
		Double poTotalQty =0.0;
		Double poBalanceTotQty =0.0;
		
		   result = purchaseOrderItemService.delete(purchaseOrderItemId);//delete purchase order item
		   if(result==true){
			   /*Method to fetch Purcahse order Item list by poNo*/
				List<PurchaseOrderItem> poItemsList = purchaseOrderItemService.findByPoNo(purchaseOrderNo);
	               if(poItemsList.size()>0){
	            	   for(int i=0;i<poItemsList.size();i++){
	            	   poTotalQty=poTotalQty+poItemsList.get(i).getQuantity();
	            	   poBalanceTotQty=poBalanceTotQty+poItemsList.get(i).getBalanceQty();
	            	 }//end of for loop
	               }//end of if(poItemsList.size()>0) loop
	               /*Method to fetch Purcahse order list by poNo*/
	             List<PurchaseOrder> poList=purchaseOrderService.findByPoNo(purchaseOrderNo);
	             if(poList.size()>0){
	            	 poList.get(0).setQuantity(poTotalQty);
	            	 poList.get(0).setBalanceQuantity(poBalanceTotQty);
	            	 updatedPO=purchaseOrderService.update(poList.get(0));
	             }   //end of if(poList.size()>0) loop
		   }//end of if loop
			return new StatusResponse(updatedPO);
	}		
	 /**
	   * generate purcahse order report
	   * @param purchaseOrderNo
	   * @return 
	   */
@RequestMapping(value = "/purchaseOrderReport", produces = "application/pdf", method = RequestMethod.GET)
	
	public void PurchaseOrderReport(@RequestParam(value = "purchaseOrderNo", required = true) String purchaseOrderNo,javax.servlet.http.HttpServletResponse response) throws IOException, InterruptedException{
	 if(purchaseOrderNo!=null && purchaseOrderNo!=""){	
	InputStream inputStream = getClass().getClassLoader().getResourceAsStream("/org/balajicables/salesmanager/report/PurchaseOrderReport.jrxml");
    	
       Map<String, Object> hm= new HashMap<String, Object>();
 	   hm.put("PO_NO", purchaseOrderNo);//add pono as parameter
 	   byte[] content = ReportGenerator.newReportGenerator(inputStream,hm);//method to generate report
     
    response.setContentType("application/pdf");	
	response.setHeader("Content-Disposition", "attachment;filename=" + "PurchaseOrder"+purchaseOrderNo+".pdf");
	response.setContentLength(content.length);
    FileCopyUtils.copy(content, response.getOutputStream());
	 }//end of if loop
	}

}
