package org.balajicables.salesmanager.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import org.balajicables.salesmanager.common.JqgridResponse;
import org.balajicables.salesmanager.common.MailMail;
import org.balajicables.salesmanager.common.StatusResponse;
import org.balajicables.salesmanager.dto.PurchaseOrderDTO;
import org.balajicables.salesmanager.model.PurchaseOrder;
import org.balajicables.salesmanager.model.PurchaseOrderItem;
import org.balajicables.salesmanager.model.TaxRate;
import org.balajicables.salesmanager.service.PurchaseOrderItemService;
import org.balajicables.salesmanager.service.PurchaseOrderService;
import org.balajicables.salesmanager.service.TaxRateService;
import org.balajicables.salesmanager.utils.Utility;
import org.joda.time.DateTime;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
/**
* This class demonstrates Purchase Order Module.
* @author Abin Sam
*/
@Controller
@RequestMapping("/viewpurchaseorder")
public class ViewPurchaseOrderController {

	@Resource
	private PurchaseOrderService purchaseOrderService;
	
	@Resource
	private PurchaseOrderItemService purchaseOrderItemService;

	@Resource
	private TaxRateService taxRateService;
	
	 /**
	   * This method returns viewPurchaseOrder.jsp.
	   * @param Model to set the attribute.
	   * @return viewPurchaseOrder.jsp.
	   */
	@RequestMapping(method = RequestMethod.GET)
	public String getPurchaseOrderPage(Model model) {
		return "viewPurchaseOrder";
	}
	
	 /**
	   * This method to fetch purchase order details of Default order status
	   * Fetch  purchase order details details for grid
	   * @param orderStatus,month,year,filters,pageNumber,rowsPerPage,sortColName,sortOrder
	   * @return JqgridResponse<PurchaseOrderDTO> response
	   */
	@RequestMapping(value = "/defaultRecords", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	JqgridResponse<PurchaseOrderDTO> defaultRecords(
			@RequestParam(value ="orderStatus", required = false) String orderStatus,
			@RequestParam(value = "month", required = false) String month,
			@RequestParam(value = "year", required = false) String year,
			@RequestParam("_search") Boolean search,
			@RequestParam(value = "filters", required = false) String filters,
			@RequestParam(value = "page", required = false) Integer pageNumber,
			@RequestParam(value = "rows", required = false) Integer rowsPerPage,
			@RequestParam(value = "sidx", required = false) String sortColName,
			@RequestParam(value = "sord", required = false, defaultValue = "asc") String sortOrder) {
		
		DateTime dt = new DateTime();  // current time
		 
		   if(month==null)
			   month =String.valueOf(dt.getMonthOfYear()-1);//parse month string to integer:if loop

		   if(year==null)
			   year =String.valueOf(dt.getYear());//parse year string to integer:if loop 

		   if(orderStatus==null || orderStatus=="")
			   orderStatus = "Submitted";  //default order status			   
		   //method to fetch search parameter filtered Purchase Order 
	       return getFilteredRecords(orderStatus,month,year, pageNumber-1,rowsPerPage,sortColName,sortOrder);
	
	}
	
	 /**
	   * This method to fetch purchase order details of selected order status
	   * Fetch  purchase order details details for grid
	   * @param orderStatus,month,year,filters,pageNumber,rowsPerPage,sortColName,sortOrder
	   * @return JqgridResponse<PurchaseOrderDTO> response
	   */
	@RequestMapping(value = "/records", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	JqgridResponse<PurchaseOrderDTO> records(
			@RequestParam("orderStatus") String orderStatus,
			@RequestParam(value = "month", required = true) String month,
			@RequestParam(value = "year", required = true) String year,
			@RequestParam("_search") Boolean search,
			@RequestParam(value = "filters", required = false) String filters,
			@RequestParam(value = "page", required = false) Integer pageNumber,
			@RequestParam(value = "rows", required = false) Integer rowsPerPage,
			@RequestParam(value = "sidx", required = false) String sortColName,
			@RequestParam(value = "sord", required = false, defaultValue = "asc") String sortOrder) {
 
		  //method to fetch search parameter filtered Purchase Order 
	       return getFilteredRecords(orderStatus,month,year, pageNumber-1,rowsPerPage,sortColName,sortOrder);
	
	}	
	 /**
	   * This method to fetch purchase order details of selected order status
	   * Fetch  purchase order details for grid
	   * @param orderStatus,month,year,filters,pageNumber,rowsPerPage,sortColName,sortOrder
	   * @return JqgridResponse<PurchaseOrderDTO> response
	   */
	private JqgridResponse<PurchaseOrderDTO> getFilteredRecords(
			 String orderStatus,String month, String year,int pagenumber, Integer rows,
			String sortColName, String sortOrder) {

		 int monthValue=0;
	        int yearValue=0;
	        if(month!=null && month!=""){
	        	monthValue=Integer.parseInt(month);//parse month string to integer
	        }
	       if(year!=null && year!=""){
	    	   yearValue=Integer.parseInt(year);//parse year string to integer
	        }
	       if(sortColName.equalsIgnoreCase("customerCode")){
				sortColName="customer.customerCode";
			}
	       //Method to fetch Purchase Order based on order status
	        List<PurchaseOrder> purchaseOrderList = purchaseOrderService.getPagedSalesOrder(orderStatus,monthValue+1,yearValue,pagenumber-1,rows,sortColName,sortOrder);
	         List<PurchaseOrder> pagedList;
	        int fromIndex = Math.min(purchaseOrderList.size(), pagenumber * rows);//from index of JQgrid to which response is set
	        int toIndex = Math.min(purchaseOrderList.size(), fromIndex + rows);//to index of JQgrid to which response is set
	        
	        if (fromIndex == 0 && toIndex == (purchaseOrderList.size() - 1))
	        {
	            pagedList = purchaseOrderList;
	        }//end of if loop
	        else
	        {
	           pagedList = purchaseOrderList.subList(fromIndex, toIndex);
	        }//end of else loop
		
	        /*Method to set PurchaseOrder list to PurchaseOrderDTO*/
	    	List<PurchaseOrderDTO> purchaseOrderDTO = convertToPODTO(pagedList);
	    	/*Intialize JQ grid response of type PurchaseOrder DTO*/
	        JqgridResponse<PurchaseOrderDTO> response = new JqgridResponse<PurchaseOrderDTO>();
	        
	        response.setRows(purchaseOrderDTO);
	        response.setRecords(Long.valueOf(purchaseOrderList.size()).toString());
	        if(purchaseOrderList.size()>0)
	        response.setTotal(Integer.valueOf((int)Math.ceil(Double.valueOf(purchaseOrderList.size())/Double.valueOf(rows.toString()))).toString());
	       else
	       response.setTotal("0");
	       response.setPage(Integer.valueOf(pagenumber+1).toString());
	       return response;	       
				
	}	
	 /**
	   * This Method to set PurchaseOrder list to PurchaseOrderDTO
	   * @param List<PurchaseOrders> purchaseorders
	   * @return List<PurchaseOrderDTO> response
	   */
	private List<PurchaseOrderDTO> convertToPODTO(
			List<PurchaseOrder> purchaseorders) {
		List<PurchaseOrderDTO> poDTOs = new ArrayList<>();
		for (PurchaseOrder poOrder : purchaseorders) {
			PurchaseOrderDTO purchaseOrderDTO = new PurchaseOrderDTO();
			purchaseOrderDTO.setPoNo(poOrder.getPoNo());
			if (poOrder.getPoDate() != null)
			purchaseOrderDTO.setPoDate(Utility.formDateFormatter.print(poOrder.getPoDate().getTime()));//format po date
			purchaseOrderDTO.setCustomerId(poOrder.getCustomer().getCustomerId());
			purchaseOrderDTO.setCustomerName(poOrder.getCustomer().getCustomerName());
			purchaseOrderDTO.setCustomerCode(poOrder.getCustomer().getCustomerCode());
			purchaseOrderDTO.setPoStatus(poOrder.getPoStatus());
			purchaseOrderDTO.setQuantity(poOrder.getQuantity());
		    purchaseOrderDTO.setBalanceQuantity(poOrder.getBalanceQuantity());
		    purchaseOrderDTO.setCreatedBy(poOrder.getCreatedBy());
		    purchaseOrderDTO.setUpdatedBy(poOrder.getUpdatedBy());
		    if(poOrder.getCreatedTime()!=null)
		    	purchaseOrderDTO.setCreatedTime(poOrder.getCreatedTime().toString());
		    purchaseOrderDTO.setTotalPrice(poOrder.getTotalPrice());
		    purchaseOrderDTO.setExciseDuty(poOrder.getExciseDuty());
		    purchaseOrderDTO.setCstValue(poOrder.getCstValue());
		    purchaseOrderDTO.setAmount(poOrder.getAmount());
		    purchaseOrderDTO.setMailSent(poOrder.getMailSent());
			poDTOs.add(purchaseOrderDTO);
			}//end of for loop
		return poDTOs;
	}

	
	 /**
	   * Crud functionality of Purchase Order Module
	   * @param PurchaseOrder No,oper(add/edit/del),customerId,poDate
	   * @return StatusResponse
	   */
	@RequestMapping(value = "/crudPO", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	StatusResponse crudPO(@RequestParam String id, @RequestParam String oper,
			@RequestParam(required = false) Long customerId,
			@RequestParam(required = false) String poDate) {

		Boolean result = false;
		PurchaseOrderDTO poDTO = new PurchaseOrderDTO();
		//Method to fetch purcahse order list by PO No
		List<PurchaseOrder> poOrderList=purchaseOrderService.findByPoNo(id);
		if(poOrderList.size()>0){
			poDTO.setPoNo(id);
			poDTO.setCustomerId(poOrderList.get(0).getCustomer().getCustomerId());
			poDTO.setPoDate(poDate);
			poDTO.setPoStatus(poOrderList.get(0).getPoStatus());
			poDTO.setCreatedTime(poOrderList.get(0).getCreatedTime().toString());
			poDTO.setQuantity(poOrderList.get(0).getQuantity());
			poDTO.setBalanceQuantity(poOrderList.get(0).getBalanceQuantity());
			poDTO.setUpdatedTime(poOrderList.get(0).getUpdatedTime().toString());
			poDTO.setCreatedBy(poOrderList.get(0).getCreatedBy());
			poDTO.setUpdatedBy(poOrderList.get(0).getUpdatedBy());
			poDTO.setMailSent(poOrderList.get(0).getMailSent());
			poDTO.setAmount(poOrderList.get(0).getAmount());
			poDTO.setExciseDuty(poOrderList.get(0).getExciseDuty());
			poDTO.setTotalPrice(poOrderList.get(0).getTotalPrice());
			poDTO.setCstValue(poOrderList.get(0).getCstValue());
			poDTO.setMailSent(poOrderList.get(0).getMailSent());
		}//end of if loop
		PurchaseOrder purchaseOrder = poDTO.getPurchaseOrder();
		switch (oper) {
		case "edit":
			result = purchaseOrderService.update(purchaseOrder);//update Purcahse Order
			break;
		case "del":
			String poToDelete = id;
			result = purchaseOrderService.delete(poToDelete);//delete purchase Order
			break;
		}//end of switch loop
		return new StatusResponse(result);
	}	
	 /**
	   * delete functionality of Purchase Order Items
	   * @param PurchaseOrderItem Id,purchaseOrderNo
	   * @return StatusResponse
	   */
	@RequestMapping(value = "/delete/{purchaseOrderItemId}", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	StatusResponse deleteId(@PathVariable("purchaseOrderItemId") Long purchaseOrderItemId,
			@RequestParam(required = false) String purchaseOrderNo) {
		Boolean result=false;
		Boolean updatedPO=false;
		Double poTotalQty =0.0;
		Double poBalanceTotQty =0.0;
		Double totalPrice=0.0;
		Float exciseDuty=(float) 0;
		Float cstVatValue=(float) 0;
		Double amount=0.0;
		Double exciseDutyAmount=0.0;
		Double taxableAmount=0.0;
		Double cstVatAmount=0.0;
		Long customerId=null;
		   result = purchaseOrderItemService.delete(purchaseOrderItemId);//delete Purcahse order Item
		   if(result==true){
			   /*Method to fetch Purcahse Order Item details By PO No*/
				List<PurchaseOrderItem> poItemsList = purchaseOrderItemService.findByPoNo(purchaseOrderNo);
	               if(poItemsList.size()>0){
	            	   for(int i=0;i<poItemsList.size();i++){
	            	   poTotalQty=poTotalQty+poItemsList.get(i).getQuantity();//calculate quantity
	            	   poBalanceTotQty=poBalanceTotQty+poItemsList.get(i).getBalanceQty();//calculate balance qty
	            	   totalPrice=totalPrice+poItemsList.get(i).getPrice();//calculate price
	            	 }//end of for loop
	            	   customerId=poItemsList.get(0).getPurchaseOrder().getCustomer().getCustomerId();//get customerId
	               }//end of  if(poItemsList.size()>0) loop
	               
	        		//Method to fetch tax rate details by customer Id
					List<TaxRate>taxRateList=taxRateService.findByCustomerId(customerId);
					if(taxRateList.size()>0){
						if(taxRateList.get(0).getExciseDuty()!=null)
						exciseDuty=taxRateList.get(0).getExciseDuty();//get excise duty
						if(taxRateList.get(0).getCst()!=null && taxRateList.get(0).getCst()!=0)
							cstVatValue=taxRateList.get(0).getCst();//get CSt
						else
							cstVatValue=taxRateList.get(0).getVat();//get VAT if CST is null
					}//end of if loop
					
					exciseDutyAmount=(totalPrice*exciseDuty)/100;//calculate Excise Duty
					taxableAmount=totalPrice+exciseDutyAmount;//calculate taxableAmount on which cst is calculated
					cstVatAmount=(taxableAmount*cstVatValue)/100;//Calculate CST
					
					amount= Math.round(totalPrice*100.0)/100.0+
							Math.round(exciseDutyAmount*100.0)/100.0+
							   Math.round(cstVatAmount*100.0)/100.0;  //Calculate final amount
	               //Method to fetch purchase Order List by PONO 
	             List<PurchaseOrder> poList=purchaseOrderService.findByPoNo(purchaseOrderNo);
	             if(poList.size()>0){
	            	 poList.get(0).setQuantity(poTotalQty);
	            	 poList.get(0).setBalanceQuantity(poBalanceTotQty);
	            	 poList.get(0).setAmount(amount);
	            	 poList.get(0).setCstValue(Math.round(cstVatAmount*100.0)/100.0);
	            	 poList.get(0).setExciseDuty(Math.round(exciseDutyAmount*100.0)/100.0);
	            	 poList.get(0).setTotalPrice(Math.round(totalPrice*100.0)/100.0);
	            	 updatedPO=purchaseOrderService.update(poList.get(0));
	             }//end of if loop   
		   }//end of if loop
		   
		   
			return new StatusResponse(updatedPO);
	}		
	 /**
	   * update Purcahse Order status
	   * @param purchaseOrderNo,orderStatus,updatedStatus
	   * @return StatusResponse
	   */
	@RequestMapping(value = "/updateOrderStatus", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	StatusResponse updateOrderStatus(
			@RequestParam String purchaseOrderNo,
			@RequestParam String orderStatus,
			@RequestParam String updatedStatus
			) {
		  //Method to fetch purchase Order List by PONO 
	   List<PurchaseOrder>poList=purchaseOrderService.findByPoNo(purchaseOrderNo);
	   Boolean updatePo=false;
	   if(poList.size()>0){
		   PurchaseOrderDTO poDTO=new PurchaseOrderDTO();
		   poDTO.setPoNo(poList.get(0).getPoNo());
		   poDTO.setCustomerId(poList.get(0).getCustomer().getCustomerId());
		   if(poList.get(0).getPoDate()!=null)
		   poDTO.setPoDate(Utility.formDateFormatter.print(poList.get(0).getPoDate().getTime()));//format date
		   poDTO.setPoStatus(updatedStatus);
		   poDTO.setCreatedTime(poList.get(0).getCreatedTime().toString());
		   poDTO.setQuantity(poList.get(0).getQuantity());
		   poDTO.setBalanceQuantity(poList.get(0).getBalanceQuantity());
		   poDTO.setUpdatedTime(poList.get(0).getUpdatedTime().toString());
		   poDTO.setCreatedBy(poList.get(0).getCreatedBy());
		   poDTO.setUpdatedBy(poList.get(0).getUpdatedBy());
		   poDTO.setTotalPrice(poList.get(0).getTotalPrice());
		   poDTO.setExciseDuty(poList.get(0).getExciseDuty());
		   poDTO.setCstValue(poList.get(0).getCstValue());
		   poDTO.setAmount(poList.get(0).getAmount());
		   poDTO.setMailSent(poList.get(0).getMailSent());
		   PurchaseOrder purchaseOrder=poDTO.getPurchaseOrder();
		   updatePo=purchaseOrderService.update(purchaseOrder);//update purchase order
		   
	   }//end of if loop
		
			return new StatusResponse(updatePo);
	}
	 /**
	   * send submitted Purcahse Order mail
	   * @param purchaseOrderNo
	   * @return StatusResponse
	   */
	@RequestMapping(value = "/sendPoMail", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	StatusResponse submitInvoice(
			@RequestParam(value = "purchaseOrderNo", required = true) String purchaseOrderNo ) throws IOException{
		 Boolean updatemailSent=false;
		 String pathC = "C:\\ReportPDFs";//temporary  folder for reports
		 File fileC = new File(pathC);//create temp folder
	        if(purchaseOrderNo!=null){
			InputStream inputStream = getClass().getClassLoader().getResourceAsStream("/org/balajicables/salesmanager/report/PurchaseOrderReport.jrxml");
	    	
	    	 Map<String, Object> hm= new HashMap<String, Object>();
	 	    hm.put("PO_NO", purchaseOrderNo);//set report parameters
	 	    byte[] content = ReportGenerator.newReportGenerator(inputStream,hm);
  
		 if(fileC.exists()){
             ReportGenerator.deleteDir(fileC);//delete existing temp folder for report
             fileC.mkdir();//create temp folder for report
          }else{
             fileC.mkdir();//create temp folder for report
          }
		   String fileName[]={pathC+"\\PurchaseOrder"+purchaseOrderNo+".pdf"};//purcahse order report filename
			File f = new File(fileName[0]);
			FileOutputStream fos = new FileOutputStream(f);
			fos.write(content, 0, content.length);
			fos.close();
        //Method to fetch Purchase order Details by PONO 
		 List<PurchaseOrder>poList=purchaseOrderService.findByPoNo(purchaseOrderNo);
		 //initialize variables
		 String toMailAddress=null;
		 String customerName=null; 
		 Long customerId=(long) 0;
		 String customerCode="";
		 String contactPerson="";
		 String contactNo="";
		 String altContactNo="";
		 String address="";
		 String city="";
		 String state="";
		 String country="";
		 Integer pincode=0;
		 String vatRegNo="";
		 String cstRegNo="";
		 String eccNo="";
		 String tinNo="";
		 String panNo="";
		 String paymentTerms="";
		 String freight="";	
		 Date poDate=null;
		 String poStatus="";
		 String createdBy="";
		 String createdTime="";
		 String updatedBy="";
		 String updatedTime="";
		 String quantity="";
		 String balanceQty="";
		 String totalPrice="";
		 String exciseDuty = "";
		 String cstValue="";
		 String amount="";
		 String mailSent="";
	
	     if(poList.size()>0){
	         if(poList.get(0).getCustomer().getCustomerName()!=null)
	    	 customerName=poList.get(0).getCustomer().getCustomerName();   	 
	    	 if(poList.get(0).getPoDate()!=null)
				 poDate=poList.get(0).getPoDate();
			 if(poList.get(0).getPoStatus()!=null)
				 poStatus=poList.get(0).getPoStatus();
			 if(poList.get(0).getCreatedBy()!=null)
				 createdBy=poList.get(0).getCreatedBy();
			 if(poList.get(0).getCreatedTime()!=null)
				 createdTime=poList.get(0).getCreatedTime().toString();
			 if(poList.get(0).getUpdatedBy()!=null)
				 updatedBy=poList.get(0).getUpdatedBy();
			 if(poList.get(0).getUpdatedTime()!=null)
				 updatedTime=poList.get(0).getUpdatedTime().toString();
			 if(poList.get(0).getQuantity()!=null)
				 quantity=String.valueOf(poList.get(0).getQuantity());
			 if(poList.get(0).getBalanceQuantity()!=null)
				 balanceQty=String.valueOf(poList.get(0).getBalanceQuantity());	 
			 if(poList.get(0).getTotalPrice()!=null)
				 totalPrice=String.valueOf(poList.get(0).getTotalPrice());
			 if(poList.get(0).getExciseDuty()!=null)
				 exciseDuty=String.valueOf(poList.get(0).getExciseDuty());
			 if(poList.get(0).getCstValue()!=null)
				 cstValue=String.valueOf(poList.get(0).getCstValue());
			 if(poList.get(0).getAmount()!=null)
				 amount=String.valueOf(poList.get(0).getAmount());
			 if(poList.get(0).getMailSent()!=null)
				 mailSent=poList.get(0).getMailSent();		  
			 if(poList.get(0).getCustomer().getCustomerId()!=null)
				customerId=poList.get(0).getCustomer().getCustomerId();
			 if(poList.get(0).getCustomer().getCustomerCode()!=null)
				 customerCode=poList.get(0).getCustomer().getCustomerCode();
			 if(poList.get(0).getCustomer().getContactPerson()!=null)
				 contactPerson=poList.get(0).getCustomer().getContactPerson();
			 if(poList.get(0).getCustomer().getContactNo()!=null)
				 contactNo=poList.get(0).getCustomer().getContactNo();
			 if(poList.get(0).getCustomer().getAltContactNo()!=null)
				 altContactNo=poList.get(0).getCustomer().getAltContactNo();
			 if(poList.get(0).getCustomer().getEmail()!=null)
				 toMailAddress=poList.get(0).getCustomer().getEmail();
			 if(poList.get(0).getCustomer().getAddress()!=null)
				 address=poList.get(0).getCustomer().getAddress();
			 if(poList.get(0).getCustomer().getCity()!=null)
				 city=poList.get(0).getCustomer().getCity();
			 if(poList.get(0).getCustomer().getState()!=null)
				 state=poList.get(0).getCustomer().getState();
			 if(poList.get(0).getCustomer().getCountry()!=null)
				 country=poList.get(0).getCustomer().getCountry(); 
			 if(poList.get(0).getCustomer().getPincode()!=null)
				 pincode=poList.get(0).getCustomer().getPincode();
			 if(poList.get(0).getCustomer().getVatRegNo()!=null)
				 vatRegNo=poList.get(0).getCustomer().getVatRegNo();
			 if(poList.get(0).getCustomer().getCstRegNo()!=null)
				 cstRegNo=poList.get(0).getCustomer().getCstRegNo();
			 if(poList.get(0).getCustomer().getEccNo()!=null)
				 eccNo=poList.get(0).getCustomer().getEccNo();
			 if(poList.get(0).getCustomer().getTinNo()!=null)
				 tinNo=poList.get(0).getCustomer().getTinNo();
			 if(poList.get(0).getCustomer().getPanNo()!=null)
				 panNo=poList.get(0).getCustomer().getPanNo();
		   }//end of  if(poList.size()>0) loop
	     String[] toEmailIds=null;
	     if(toMailAddress!=null){
         	toEmailIds = toMailAddress.split(";", -1);//multiple customer mails set to string
         }//end of if loop
        ApplicationContext context =new ClassPathXmlApplicationContext("Spring-Mail.xml");
		    if(toEmailIds!=null && purchaseOrderNo!=null && purchaseOrderNo!="" && customerName!=null ){
		    	 MailMail mailsender = (MailMail) context.getBean("mailMail");//get mailsender bean from springMial.xml
	    	     String templateName="purchaseOrderTemplate.vm";//PO mail template
	    	     HashMap<String, String> model=new HashMap<>();//initialize hashmap for template parameters
	    	    //set mail template parameters to model	     
	    	     model.put("CUSTOMER_NAME", customerName);
	    	     model.put("CUSTOMER_CODE", customerCode);
	    	     model.put("CUSTOMER_ID", String.valueOf(customerId)); 
	    	     model.put("CONTACT_PERSON", contactPerson);
	    	     model.put("CONTACT_NO", contactNo);
	    	     model.put("ALT_CONTACT_NO", altContactNo);
	    	     model.put("EMAIL", toMailAddress);
	    	     model.put("ADDRESS", address);
	             model.put("CITY", city);
	             model.put("STATE", state);
	    	     model.put("COUNTRY", country);
	    	     model.put("PINCODE",String.valueOf(pincode));
	    	     model.put("VAT_REG_NO", vatRegNo);
	             model.put("CST_REG_NO", cstRegNo);
	    	     model.put("ECC_NO", eccNo);
	    	     model.put("TIN_NO", tinNo);
	    	     model.put("PAN_NO", panNo);
	    	     model.put("PAYMENT_TERMS", paymentTerms);
	             model.put("FRIEGHT", freight);
	    	     
	             Format formatter = new SimpleDateFormat("dd-MM-yyyy");
	             String poDateString = formatter.format(poDate);
   	     
	             model.put("PO_NO", purchaseOrderNo);
	             model.put("PO_DATE", poDateString);
	             model.put("PO_STATUS", poStatus);
	             model.put("CREATED_BY", createdBy); 
	             model.put("CREATED_TIME", createdTime);
	             model.put("UPDATED_BY", updatedBy);
	             model.put("UPDATED_TIME", updatedTime);
	             model.put("QUANTITY", quantity);
	             model.put("BALANCE_QUANTITY", balanceQty);
	             model.put("TOTAL_PRICE", totalPrice);
	             model.put("EXCISE_DUTY", exciseDuty);
	             model.put("CST_VALUE", cstValue);
	             model.put("AMOUNT", amount);
	             model.put("MAIL_SENT", mailSent);
	    	     
	             String subject="Purchase Order :"+purchaseOrderNo+" is generated";//subject line of PO mail
				 mailsender.sendEmailsWithAttachment(toEmailIds, 
						 subject,  fileName, templateName,model);//send email method with attchments
	    
	    	 PurchaseOrderDTO purchaseOrderDTO=new PurchaseOrderDTO();
	    	 purchaseOrderDTO.setPoNo(poList.get(0).getPoNo());
	    	 purchaseOrderDTO.setCustomerId(poList.get(0).getCustomer().getCustomerId());
	    	 if(poList.get(0).getPoDate()!=null)
	    	 purchaseOrderDTO.setPoDate(Utility.formDateFormatter.print(poList.get(0).getPoDate().getTime()));//format date
	    	 purchaseOrderDTO.setPoStatus(poList.get(0).getPoStatus());
	    	 purchaseOrderDTO.setCreatedTime(poList.get(0).getCreatedTime().toString());
	    	 purchaseOrderDTO.setQuantity(poList.get(0).getQuantity());
	    	 purchaseOrderDTO.setBalanceQuantity(poList.get(0).getBalanceQuantity());
	    	 purchaseOrderDTO.setUpdatedTime(poList.get(0).getUpdatedTime().toString());
	    	 purchaseOrderDTO.setCreatedBy(poList.get(0).getCreatedBy());
	    	 purchaseOrderDTO.setUpdatedBy(poList.get(0).getUpdatedBy());
	    	 purchaseOrderDTO.setTotalPrice(poList.get(0).getTotalPrice());
	    	 purchaseOrderDTO.setExciseDuty(poList.get(0).getExciseDuty());
	    	 purchaseOrderDTO.setCstValue(poList.get(0).getCstValue());
	    	 purchaseOrderDTO.setAmount(poList.get(0).getAmount());
	    	 purchaseOrderDTO.setMailSent("Yes");
	    	 PurchaseOrder poOrder=purchaseOrderDTO.getPurchaseOrder();
	    	 updatemailSent=purchaseOrderService.update(poOrder);//update purcahse order with new mail status
	     }
	        if(updatemailSent==true){
	        	 ReportGenerator.deleteDir(fileC);//delete temp folder of reports
		 } 
	        }//end of if loop
 		 return new StatusResponse(updatemailSent);
	}
	 /**
	   * check status of Purcahse Order
	   * @param purchaseOrderNo
	   * @return List<String> PoStatus
	   */
	@RequestMapping(value = "/checkOrderStatus", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	List<String> checkOrderStatus(
			@RequestParam(value = "purchaseOrderNo", required = true) String purchaseOrderNo ){
		//Method to fetch PO details by PO No
		List<PurchaseOrder>poList=purchaseOrderService.findByPoNo(purchaseOrderNo);
		 String orderStatus=null;
		  if(poList.size()>0){
			  orderStatus=poList.get(0).getPoStatus();
		  }//end of if loop
		
		  List<String>orderStatusList=new ArrayList<String>();
		  orderStatusList.add(orderStatus);//add po Statsu to List for return
		  return orderStatusList;
	}
	
}