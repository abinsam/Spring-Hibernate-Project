package org.balajicables.salesmanager.controller;


import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Resource;
import org.balajicables.salesmanager.CustomUser;
import org.balajicables.salesmanager.common.JqgridFilter;
import org.balajicables.salesmanager.common.JqgridObjectMapper;
import org.balajicables.salesmanager.common.JqgridResponse;
import org.balajicables.salesmanager.common.StatusResponse;
import org.balajicables.salesmanager.model.Customer;
import org.balajicables.salesmanager.model.OrderStatus;
import org.balajicables.salesmanager.model.SalesOrder;
import org.balajicables.salesmanager.model.SalesOrderItem;
import org.balajicables.salesmanager.dto.OrderDTO;
import org.balajicables.salesmanager.dto.SalesOrderItemsDTO;
import org.balajicables.salesmanager.service.CustomerService;
import org.balajicables.salesmanager.service.OrderDetailsService;
import org.balajicables.salesmanager.service.OrderService;
import org.balajicables.salesmanager.service.OrderStatusService;
import org.balajicables.salesmanager.utils.Utility;
import org.joda.time.DateTime;
import org.springframework.data.domain.Page;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
/**
* This class demonstrates Sales Order  Module.
* @author Abin Sam
*/
@Controller
@RequestMapping("/viewSalesOrders")
public class ViewSalesOrderController {

	@Resource 
	private OrderService orderService;
	@Resource 
	private OrderStatusService orderStatusService;
	@Resource
	private OrderDetailsService orderDetailsService;
	@Resource
	private CustomerService customerService;
	
	 /**
	   * This method returns salesOrders.jsp.
	   * @param Model to set the attribute.
	   * @return salesOrders.jsp.
	   */
	@RequestMapping(method = RequestMethod.GET)
	public String getSalesOrdersPage(Model model) {
		List<Customer> customers = customerService.findAll();//fetch all customers
		model.addAttribute("customers", customers);//set customers to model attribute
		/*Method to fetch list of order status*/
		List<OrderStatus> orderStatusList=orderStatusService.findAll();
		if(orderStatusList.size()>0){
			for(int i=0;i<orderStatusList.size();i++){
				if(orderStatusList.get(i).getStatus().equalsIgnoreCase("Created"))
					orderStatusList.remove(i);
			}//end of for loop
		}//end of if(orderStatusList.size()>0) loop
		model.addAttribute("status",orderStatusList);//add order status list to model attribute
		model.addAttribute("customer",customerService.findAll());//add customer list to model attribute
     	return "salesOrders";
	}
    
	 /**
	   * This method to fetch sales order details of Default order status
	   * Fetch  sales order details details for grid
	   * @param orderStatus,month,year,filters,pageNumber,rowsPerPage,sortColName,sortOrder
	   * @return JqgridResponse<OrderDTO> response
	   */
	@RequestMapping(value="/records", produces="application/json", method=RequestMethod.POST)
	public @ResponseBody
	JqgridResponse<OrderDTO> records(
			@RequestParam(value="searchObject", required=false) String searchObject,
			@RequestParam(value = "customerId", required = false) Long customerId,
			@RequestParam("_search") Boolean search,
			@RequestParam(value = "filters", required = false) String filters,
			@RequestParam(value = "page", required = false) Integer pageNumber,
			@RequestParam(value = "rows", required = false) Integer rowsPerPage,
			@RequestParam(value = "sidx", required = false) String sortColName,
			@RequestParam(value = "sord", required = false, defaultValue = "asc") String sortOrder) {
		   DateTime dt = new DateTime();  // current time
		   int month=dt.getMonthOfYear();
	        int year=dt.getYear();

        //Sorting of JQ Grid data based on sort column name
	   if(sortColName.equalsIgnoreCase("customerName")){
			sortColName="customer.customerName";
		}
	   if(sortColName.equalsIgnoreCase("customerId")){
			sortColName="customer.customerId";
		}
	   if(sortColName.equalsIgnoreCase("customerCode")){
			sortColName="customer.customerCode";
		}
	   if(sortColName.equalsIgnoreCase("status")){
			sortColName="orderStatus.status";
		}
	 	   //method to fetch search parameter filtered Sales Order 
	   if (searchObject != null && !(searchObject.equalsIgnoreCase("allSearch"))) {
	       return getFilteredSoRecords(searchObject, pageNumber-1,rowsPerPage,sortColName,sortOrder);
	   }else{
		   return  getAllSoRecords(month,year, pageNumber-1,rowsPerPage,sortColName,sortOrder);
	   }
	
	}
	 private JqgridResponse<OrderDTO> getAllSoRecords(int month, int year,
			int pagenumber, Integer rows, String sortColName, String sortOrder) {
	      //Method to fetch SalesOrder based on order status
	        List<SalesOrder> salesOrderList = orderService.getAllSalesOrder(month, year, pagenumber-1,rows,sortColName,sortOrder);
	        List<SalesOrder> pagedList;
	        int fromIndex = Math.min(salesOrderList.size(), pagenumber * rows);//from index of JQgrid to which response is set
	        int toIndex = Math.min(salesOrderList.size(), fromIndex + rows);//to index of JQgrid to which response is set
	        
	        if (fromIndex == 0 && toIndex == (salesOrderList.size() - 1))
	        {
	            pagedList = salesOrderList;
	        }//end of if loop
	        else
	        {
	           pagedList = salesOrderList.subList(fromIndex, toIndex);
	        }//end of else loop
	        /*Method to set SalesOrder list to Sales OrderDTO*/
	    	List<OrderDTO> salesOrderDTO = convertToDTO(pagedList);
	    	/*Intialize JQ grid response of type SalesOrder DTO*/
	        JqgridResponse<OrderDTO> response = new JqgridResponse<OrderDTO>();
	        
	        response.setRows(salesOrderDTO);
	        response.setRecords(Long.valueOf(salesOrderList.size()).toString());
	        if(salesOrderList.size()>0)
	        response.setTotal(Integer.valueOf((int)Math.ceil(Double.valueOf(salesOrderList.size())/Double.valueOf(rows.toString()))).toString());
	       else
	       response.setTotal("0");
	       response.setPage(Integer.valueOf(pagenumber+1).toString());
	       return response;
	}

	/**
	   * This method to fetch sales order details of selected order status
	   * Fetch  sales order details  for grid
	   * @param orderStatus,month,year,filters,pageNumber,rowsPerPage,sortColName,sortOrder
	   * @return JqgridResponse<OrderDTO> response
	   */
	private JqgridResponse<OrderDTO> getFilteredSoRecords(
			String filters,int pagenumber, Integer rows,
			String sortColName, String sortOrder) {
		Long qCustomerId=null;
        String qStatus=null; 
        int month=0;
        int year=0;
        DateTime dt = new DateTime();  // current time
	
	        //JQ Grid filtering parameters
	      	JqgridFilter jqgridFilter = JqgridObjectMapper.map(filters);
	        for (JqgridFilter.Rule rule: jqgridFilter.getRules()) {
	               if (rule.getField().equals("orderStatus"))
	            	   qStatus = rule.getData();
	              else if (rule.getField().equals("customerId")){
	            	  if(rule.getData()!=null && rule.getData()!="")
	                	qCustomerId =Long.valueOf(rule.getData());
	              }
	              else if (rule.getField().equals("month")){
	            	 if(rule.getData()!=null && rule.getData()!="" )
	            		 month=Integer.parseInt(rule.getData())+1;
	            	 else
	            		 month=dt.getMonthOfYear();
	             }
	             else if (rule.getField().equals("year")){
		            	 if(rule.getData()!=null && rule.getData()!="" )
		            		 year=Integer.parseInt(rule.getData());
		            	 else
		            		 year=dt.getYear();
		        }
	               
	         }//end of for loop
	 		    //Method to fetch SalesOrder based on order status
	        List<SalesOrder> salesOrderList = orderService.fetchBySearch(qCustomerId, qStatus, month, year, pagenumber, rows, sortColName, sortOrder);
      
	        List<SalesOrder> pagedList;
	        int fromIndex = Math.min(salesOrderList.size(), pagenumber * rows);//from index of JQgrid to which response is set
	        int toIndex = Math.min(salesOrderList.size(), fromIndex + rows);//to index of JQgrid to which response is set
	        
	        if (fromIndex == 0 && toIndex == (salesOrderList.size() - 1))
	        {
	            pagedList = salesOrderList;
	        }//end of if loop
	        else
	        {
	           pagedList = salesOrderList.subList(fromIndex, toIndex);
	        }//end of else loop
	        /*Method to set SalesOrder list to Sales OrderDTO*/
	    	List<OrderDTO> salesOrderDTO = convertToDTO(pagedList);
	    	/*Intialize JQ grid response of type SalesOrder DTO*/
	        JqgridResponse<OrderDTO> response = new JqgridResponse<OrderDTO>();
	        
	        response.setRows(salesOrderDTO);
	        response.setRecords(Long.valueOf(salesOrderList.size()).toString());
	        if(salesOrderList.size()>0)
	        response.setTotal(Integer.valueOf((int)Math.ceil(Double.valueOf(salesOrderList.size())/Double.valueOf(rows.toString()))).toString());
	        else
	        response.setTotal("0");
	        response.setPage(Integer.valueOf(pagenumber+1).toString());
	       
	        return response;
				
	}
	 /**
	   * This Method to set SalesOrder list to SalesOrderDTO
	   * @param List<SalesOrder> SalesOrder
	   * @return List<OrderDTO> response
	   */
	private List<OrderDTO> convertToDTO( List<SalesOrder>orders) {
		List<OrderDTO> orderDTOs = new ArrayList<>();
		for(SalesOrder order : orders) {
			if( !(order.getOrderId().equalsIgnoreCase("BS000001"))){
           	OrderDTO orderDTO = new OrderDTO();
			orderDTO.setOrderId(order.getOrderId());
			
			orderDTO.setCustomerCode(order.getCustomer().getCustomerCode());	
			orderDTO.setCustomerId(order.getCustomer().getCustomerId());
			orderDTO.setCustomerName(order.getCustomer().getCustomerName());
			
			orderDTO.setPoDetails(order.getPoDetails());
			if(order.getOrderRecDate()!=null)
			orderDTO.setOrderRecDate(Utility.formDateFormatter.print(order.getOrderRecDate().getTime()));//formatting date
			if(order.getOrderDeliveryDate()!=null)
			orderDTO.setOrderDeliveryDate(Utility.formDateFormatter.print(order.getOrderDeliveryDate().getTime()));//formatting date
			if(order.getOrderAcceptanceDate()!=null)
			orderDTO.setOrderAcceptanceDate(Utility.formDateFormatter.print(order.getOrderAcceptanceDate().getTime()));//formatting date
			
			orderDTO.setModeOfReceipt(order.getModeOfReceipt());
			orderDTO.setStatus(order.getOrderStatus().getStatus());
			orderDTO.setCreatedBy(order.getCreatedBy());
			orderDTO.setCreatedTime(order.getCreatedTime().toString());
			
			orderDTO.setUpdatedBy(order.getUpdatedBy());
			orderDTO.setUpdatedTime(order.getUpdatedTime().toString());
			orderDTO.setInputQuantity(order.getInputQuantity());
			orderDTO.setMailStatus(order.getMailStatus());
			orderDTO.setLmeDetails(order.getLmeDetails());
			orderDTOs.add(orderDTO);
			}//end of if not Dummy sales order loop
			}//end of for loop
		return orderDTOs;
	}
	 /**
	   * This method to fetch sales orderitem  details of selected sales order
	   * Fetch  sales orderitem details details for grid
	   * @param orderId,filters,pageNumber,rowsPerPage,sortColName,sortOrder
	   * @return JqgridResponse<SalesOrderItemsDTO> response
	   */
	@RequestMapping(value="/items/{orderId}", produces="application/json", method=RequestMethod.GET)
	public @ResponseBody
	JqgridResponse<SalesOrderItemsDTO> items(
		    @PathVariable("orderId") String orderId,
			@RequestParam("_search") Boolean search,
    		@RequestParam(value="filters", required=false) String filters,
	    	@RequestParam(value = "page", required = false) Integer pageNumber,
			@RequestParam(value = "rows", required = false) Integer rowsPerPage,
			@RequestParam(value = "sidx", required = false) String sortColName,
			@RequestParam(value = "sord", required = false, defaultValue = "asc") String sortOrder) {
		  /*Method to fecth SalesOrderitem list by sales order id*/
		Page<SalesOrderItem> orderOutput = orderDetailsService.getPagedSalesOrderItems(orderId,pageNumber - 1,
		rowsPerPage, sortColName, sortOrder);
		/*Intialize JQ grid response of type SalesOrderItemsDTO DTO*/
		JqgridResponse<SalesOrderItemsDTO> response = new JqgridResponse<SalesOrderItemsDTO>();
		List<SalesOrderItemsDTO> salesOrderItemDTOs = convertToItemDTO(orderOutput.getContent(),orderId);
		response.setRows(salesOrderItemDTOs);
		response.setRecords(Long.valueOf(orderOutput.getTotalElements()).toString());
		response.setTotal(Long.valueOf(orderOutput.getTotalPages()).toString());
		response.setPage(Integer.valueOf(orderOutput.getNumber()+1).toString());
		return response;	
	}
	 /**
	   * This Method to set sales order items list to SalesOrderItemsDTO
	   * @param List<SalesOrderItem> SalesOrderItem
	   * @return List<SalesOrderItemsDTO> response
	   */
private List<SalesOrderItemsDTO> convertToItemDTO(List<SalesOrderItem> salesOrderItem,String salesOrderId) {
	List<SalesOrderItemsDTO> salesOrderItemrDTOs = new ArrayList<>();
	for(SalesOrderItem orderItem : salesOrderItem) {
		SalesOrderItemsDTO salesOrderItemsDTO = new SalesOrderItemsDTO();
		salesOrderItemsDTO.setOrderDetailId(orderItem.getOrderDetailId());
		salesOrderItemsDTO.setItemId(orderItem.getItem().getItemId());
		salesOrderItemsDTO.setItemCode(orderItem.getItem().getItemCode());
		salesOrderItemsDTO.setItemDescription(orderItem.getItem().getItemDescription());
		salesOrderItemsDTO.setBalanceQty(orderItem.getBalanceQty());
		salesOrderItemsDTO.setQuantity(orderItem.getQuantity());
		salesOrderItemsDTO.setRate(orderItem.getRate());
		salesOrderItemsDTO.setOrderId(salesOrderId);
	    salesOrderItemrDTOs.add(salesOrderItemsDTO);
		}//end of for loop
	return salesOrderItemrDTOs;
}
/**
 * Crud functionality of Sales order
  * @param SalesOrder No,oper(add/edit/del),poDetails,modeOfReceipt, orderRecDate, orderDeliveryDate,
		 orderAcceptanceDate,customerId, status,createdBy, createdTime,inputQuantity,mailStatus, lmeDetails
 * @return StatusResponse
 */
@RequestMapping(value = "/modifyorders", produces = "application/json", method = RequestMethod.POST)
public @ResponseBody
StatusResponse modifyorders(@RequestParam String id,
		@RequestParam String oper,
		@RequestParam(required = false) String poDetails,
		@RequestParam(required = false) String modeOfReceipt,
		@RequestParam(required = false) String orderRecDate,
		@RequestParam(required = false) String orderDeliveryDate,
		@RequestParam(required = false) String orderAcceptanceDate,
		@RequestParam(required = true) long customerId,
		@RequestParam(required = true) String status,
		@RequestParam(required = true) String createdBy,
		@RequestParam(required = true) String createdTime,
		@RequestParam(required = true) Double inputQuantity,
		@RequestParam(required = true) String mailStatus,
		@RequestParam(required = false) String lmeDetails
		
		) {
	//fetch logged in user
	CustomUser user = (CustomUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();;

 	String userName = user.getFirstName()+" "+user.getLastName();
	
	Boolean result = false;
	OrderDTO orderDTO = new OrderDTO();
	if(id != null && !"".equalsIgnoreCase(id.trim()) &&
			!"_empty".equalsIgnoreCase(id.trim()) && 
			!"new_row".equalsIgnoreCase(id.trim())) {
		/*Mthod to fetch sales order details by Sales order No*/
	    List<SalesOrder>soOrderList=orderService.findBySalesOrderNoId(id);
	    if(soOrderList.size()>0){
	    	orderDTO.setOrderId(soOrderList.get(0).getOrderId());
	    	orderDTO.setCreatedTime(soOrderList.get(0).getCreatedTime().toString());
	    	orderDTO.setCreatedBy(soOrderList.get(0).getCreatedBy());
	    	orderDTO.setCustomerId(soOrderList.get(0).getCustomer().getCustomerId());
	    	
	    }//en dof inner if loop
		
	}//end of if loop

	orderDTO.setPoDetails(poDetails);
	orderDTO.setOrderDeliveryDate(orderDeliveryDate);
	orderDTO.setOrderAcceptanceDate(orderAcceptanceDate);
	orderDTO.setOrderRecDate(orderRecDate);
	orderDTO.setModeOfReceipt(modeOfReceipt);
	orderDTO.setUpdatedBy(userName);
	orderDTO.setInputQuantity(inputQuantity);
	orderDTO.setMailStatus(mailStatus);
	orderDTO.setLmeDetails(lmeDetails);
	java.util.Date date= new java.util.Date();
	orderDTO.setUpdatedTime(new Timestamp(date.getTime()).toString());//format sales order updated date time
 	//Method to fetch order status details by status
	List<OrderStatus> statusIdList=orderService.fetchStatusId(status);
	Integer statusId=statusIdList.get(0).getOrderStatusId();//get order statsu id
	orderDTO.setOrderStatusId(statusId);
	SalesOrder order = orderDTO.getOrder();
	switch (oper) {
	case "edit":
		result = orderService.update(order);//updates ales order
		break;
	case "del":
		String orderIdToDelete = id;
		result = orderService.delete(orderIdToDelete);//delete sales order
		break;
	}//end of switch loop
	return new StatusResponse(result);
}
/**
 * This Method to update sales order 
 * @param orderId,orderStatus,lmeDetails
 * @return StatusResponse
 */
@RequestMapping(value = "/updateOrderStatus", produces = "application/json", method = RequestMethod.POST)
public @ResponseBody
StatusResponse updateOrderStatus(
		@RequestParam(value="orderId",required = true) String orderId,
		@RequestParam (value="orderStatus",required = true)String orderStatus,
		@RequestParam (value="lmeDetails",required = false)String lmeDetails) {
	//Method to fetch order status  List by order Status
    List<OrderStatus> statusList=orderService.fetchStatusId(orderStatus);
    int orderStatusId=statusList.get(0).getOrderStatusId();//get order status id
    //Method to fetch Sales Order List by order Id
    List<SalesOrder>soList=orderService.findBySalesOrderNoId(orderId);
    Boolean result = false;
    if(soList.size()>0 && orderId!=null && orderStatusId !=0){
    	OrderDTO orderDTO = new OrderDTO();
		orderDTO.setOrderId(orderId);
		if(soList.get(0).getOrderRecDate()!=null)
		orderDTO.setOrderRecDate(Utility.formDateFormatter.print(soList.get(0).getOrderRecDate().getTime()));//format date
		if(soList.get(0).getOrderAcceptanceDate()!=null)
		orderDTO.setOrderAcceptanceDate(Utility.formDateFormatter.print(soList.get(0).getOrderAcceptanceDate().getTime()));//format date
		if(soList.get(0).getOrderDeliveryDate()!=null)
		orderDTO.setOrderDeliveryDate(Utility.formDateFormatter.print(soList.get(0).getOrderDeliveryDate().getTime()));//format date
		orderDTO.setCustomerId(soList.get(0).getCustomer().getCustomerId());
		orderDTO.setMailStatus(soList.get(0).getMailStatus());
		orderDTO.setModeOfReceipt(soList.get(0).getModeOfReceipt());
    	orderDTO.setPoDetails(soList.get(0).getPoDetails());
    	orderDTO.setOrderStatusId(orderStatusId);
    	orderDTO.setCreatedTime(soList.get(0).getCreatedTime().toString());
    	if(soList.get(0).getTargetDate()!=null)
    	orderDTO.setTargetDate(Utility.formDateFormatter.print(soList.get(0).getTargetDate().getTime()));//formate date
     	orderDTO.setCreatedBy(soList.get(0).getCreatedBy());
     	orderDTO.setUpdatedBy(soList.get(0).getUpdatedBy());
    	java.util.Date date= new java.util.Date();
    	orderDTO.setUpdatedTime(new Timestamp(date.getTime()).toString());
      	orderDTO.setInputQuantity(soList.get(0).getInputQuantity());
       	orderDTO.setLmeDetails(lmeDetails);
    
    	SalesOrder soOrder=orderDTO.getOrder();
    	result=orderService.update(soOrder);//update sales order
  }//end of if loop
	
return new StatusResponse(result);
}
}
