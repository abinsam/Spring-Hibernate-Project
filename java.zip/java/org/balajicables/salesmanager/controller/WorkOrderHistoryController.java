package org.balajicables.salesmanager.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.annotation.Resource;
import org.balajicables.salesmanager.common.JqgridResponse;
import org.balajicables.salesmanager.dto.ScrapDetailsDTO;
import org.balajicables.salesmanager.dto.StockOutDTO;
import org.balajicables.salesmanager.dto.WorkOrderItemsDTO;
import org.balajicables.salesmanager.dto.WorkOrderOutputDTO;
import org.balajicables.salesmanager.model.ProductionProcess;
import org.balajicables.salesmanager.model.ProductionWorkOrder;
import org.balajicables.salesmanager.model.ScrapDetails;
import org.balajicables.salesmanager.model.SemifinishedStockOut;
import org.balajicables.salesmanager.model.StockOut;
import org.balajicables.salesmanager.model.StoreRegister;
import org.balajicables.salesmanager.model.WorkOrderItems;
import org.balajicables.salesmanager.model.WorkOrderOutput;
import org.balajicables.salesmanager.repository.ProductionProcessRepository;
import org.balajicables.salesmanager.service.ProductionWorkOrderService;
import org.balajicables.salesmanager.service.ScrapDetailsService;
import org.balajicables.salesmanager.service.SemifinishedStockOutService;
import org.balajicables.salesmanager.service.StockOutService;
import org.balajicables.salesmanager.service.StoreRegisterService;
import org.balajicables.salesmanager.service.WorkOrderItemService;
import org.balajicables.salesmanager.service.WorkOrderOutputService;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
/**
* This class demonstrates WorkOrder History fetch process.
* @author Abin Sam
*/
@Controller
@RequestMapping("/workOrderHistory")
public class WorkOrderHistoryController {

	@Resource
	private ProductionProcessRepository productionProcessRepository;
	@Resource
	private StoreRegisterService storeRegisterService;
	@Resource
	private StockOutService stockOutService;
	@Resource
	private ProductionWorkOrderService productionWorkOrderService;
	@Resource
	private ScrapDetailsService scrapDetailsService;
	
	@Resource
	private WorkOrderItemService workOrderItemService;
	@Resource
	private WorkOrderOutputService workOrderOutputService;
	@Resource
	private SemifinishedStockOutService semifinishedStockOutService;
	 /**
	   * This method returns workOrderHistoryDetails.jsp.
	   * Fetch all processes  
	   * @param Model to set the attribute.
	   * @return workOrderHistoryDetails.jsp.
	   */
	@RequestMapping(method = RequestMethod.GET)
	public String viewWorkOrderHistory(Model model) {
		List<ProductionProcess> pdnProcessList = productionProcessRepository
				.findAll();
		if (pdnProcessList.size() > 0) {
			for (int i = 0; i < pdnProcessList.size(); i++) {
				if (pdnProcessList.get(i).getProcessType().equalsIgnoreCase("RBD"))
					pdnProcessList.remove(pdnProcessList.get(i));
			}//end of for loop
		}//end of if (pdnProcessList.size() > 0)
		model.addAttribute("processes", pdnProcessList);
		return "workOrderHistoryDetails";
	}

	 /**
	   * This method to populate workorder number dropdown based on the process selected
	   * @param processType,month,rowsPerPage,year
	   * @param Model to set the attribute.
	   * @return pdnWoValuesList
	   */
	@RequestMapping(value = "/getWorkOrders/{processType}", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	List<String> getWODetails(@PathVariable("processType") String processType,
			@RequestParam("month") int month, @RequestParam("year") int year,
			Model model) {
        /*List pdnWorkOrders of type ProductionWorkOrder to fetch work orders based on process type,month and year*/
		List<ProductionWorkOrder> pdnWorkOrders = productionWorkOrderService.findByProcessTypeAndMonthYear(processType, month + 1, year);
        /*Empty arraylist pdnWoValuesList of type String initialized*/
		ArrayList<String> pdnWoValuesList = new ArrayList<String>();
		for (int iterator = 0; iterator < pdnWorkOrders.size(); iterator++) {
			ProductionWorkOrder productionWorkOrder = pdnWorkOrders.get(iterator);
			pdnWoValuesList.add(productionWorkOrder.getWorkOrderNo());
		}//end of for
		Collections.sort(pdnWoValuesList,Collections.reverseOrder());//sorts the list of Work Order numbers into descending order
		return pdnWoValuesList;
	}

	 /**
	   * This method to populate Extrusion WorkOrder grid
	   * Fetch details of WorkOrder History
	   * @param workOrder,search,filters,pageNumber,rowsPerPage,sortColName,sortOrder
	   * @return JqgridResponse<WorkOrderItemsDTO> response
	   */
	@RequestMapping(value = "/extrusionRecords", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	JqgridResponse<WorkOrderItemsDTO> extrusionRecords(
			@RequestParam(value = "workOrder", required = true) String workOrder,
			@RequestParam("_search") Boolean search,
			@RequestParam(value = "filters", required = false) String filters,
			@RequestParam(value = "page", required = false) Integer pageNumber,
			@RequestParam(value = "rows", required = false) Integer rowsPerPage,
			@RequestParam(value = "sidx", required = false) String sortColName,
			@RequestParam(value = "sord", required = false, defaultValue = "asc") String sortOrder) {
		/*JQGrid column sorting*/
		if(sortColName.equalsIgnoreCase("workOrderNo")){
			sortColName="productionWorkOrder.workOrderNo";
		}
		if(sortColName.equalsIgnoreCase("itemDescription")){
			sortColName="salesOrderItem.items.itemDescription";
		}
		if(sortColName.equalsIgnoreCase("customerName")){
			sortColName="salesOrderItem.orders.customer.customerName";
		}
		if(sortColName.equalsIgnoreCase("updatedBy")){
			sortColName="salesOrderItem.orders.customer.updatedBY";
		}
		/*Method to fetch JQGRID paged records items from work Order items*/
		Page<WorkOrderItems> orderOutput = workOrderItemService.getPagedOrders(workOrder, pageNumber - 1, rowsPerPage, sortColName, sortOrder);
		/*Intialize JQ grid response of type WorkOrderItemsDTO*/	
		JqgridResponse<WorkOrderItemsDTO> response = new JqgridResponse<WorkOrderItemsDTO>();
		/*Method to set work order items list to WorkOrderItemsDTO*/
		List<WorkOrderItemsDTO> workOrderItemDTOs = convertToWoItemDTO(orderOutput.getContent());
		
		response.setRows(workOrderItemDTOs);
		response.setRecords(Long.valueOf(orderOutput.getTotalElements()).toString());
		response.setTotal(Long.valueOf(orderOutput.getTotalPages()).toString());
		response.setPage(Integer.valueOf(orderOutput.getNumber() + 1).toString());
		return response;

	}
	/**
	   * This method to populate Bunching WorkOrder grid
	   * Fetch details of WorkOrder History
	   * @param workOrder,search,filters,pageNumber,rowsPerPage,sortColName,sortOrder
	   * @return JqgridResponse<WorkOrderOutputDTO> response
	   */
	@RequestMapping(value = "/bunchingRecords", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	JqgridResponse<WorkOrderOutputDTO> bunchingRecords(
			@RequestParam(value = "workOrder", required = true) String workOrder,
			@RequestParam("_search") Boolean search,
			@RequestParam(value = "filters", required = false) String filters,
			@RequestParam(value = "page", required = false) Integer pageNumber,
			@RequestParam(value = "rows", required = false) Integer rowsPerPage,
			@RequestParam(value = "sidx", required = false) String sortColName,
			@RequestParam(value = "sord", required = false, defaultValue = "asc") String sortOrder) {
		/*JQGrid column sorting*/
		if(sortColName.equalsIgnoreCase("workOrderNo")){
			sortColName="productionWorkOrder.workOrderNo";
		}
		/*Method to fetch JQGRID records items from work Order output*/	
		List<ProductionWorkOrder> pdnList = productionWorkOrderService.findByProductionWorkOrderNo(workOrder);
		/*Intialize JQ grid response of type WorkOrderOutputDTO*/	
		JqgridResponse<WorkOrderOutputDTO> response = new JqgridResponse<WorkOrderOutputDTO>();

		if(pdnList.size()>0){
			String process = pdnList.get(0).getProcess().getProcessType();
			if (process.equalsIgnoreCase("Bunching")) {
				Page<WorkOrderOutput> orderOutput = workOrderOutputService
						.getWoOutputPagedList(workOrder, pageNumber - 1,
								rowsPerPage, sortColName, sortOrder);
				List<WorkOrderOutputDTO> workOrderOutputDTOs = convertToWoOutputDTO(orderOutput.getContent());
				response.setRows(workOrderOutputDTOs);
				response.setRecords(Long.valueOf(orderOutput.getTotalElements()).toString());
				response.setTotal(Long.valueOf(orderOutput.getTotalPages()).toString());
				response.setPage(Integer.valueOf(orderOutput.getNumber() + 1).toString());
			} else {
				sortColName = "semifinishedStockOutId";
				String woStockedOutProcess = "Bunching";
				String confirmStatus="Yes";
				/*Method to fetch JQGRID paged records items from semifinished stock out*/	
				Page<SemifinishedStockOut> semiFinishStockOutList = semifinishedStockOutService.findByStockedOutForAndWorkOrderProcess(workOrder,
								woStockedOutProcess,confirmStatus, pageNumber - 1,
								rowsPerPage, sortColName, sortOrder);
				/*Method to fetch JQGRID paged records items from semifinished stock out*/	
                List<WorkOrderOutputDTO> workOrderSemifinisedDTOs = convertToSemifinishedOutputDTO(semiFinishStockOutList
						.getContent());
				response.setRows(workOrderSemifinisedDTOs);
				response.setRecords(Long.valueOf(
						semiFinishStockOutList.getTotalElements()).toString());
				response.setTotal(Long.valueOf(
						semiFinishStockOutList.getTotalPages()).toString());
				response.setPage(Integer.valueOf(
						semiFinishStockOutList.getNumber() + 1).toString());

			}//end of if else loop
		}//end of if(pdnList.size()>0)
		return response;

	}
	/**
	   * This method to populate Multiwire WorkOrder grid
	   * Fetch details of WorkOrder History
	   * @param workOrder,search,filters,pageNumber,rowsPerPage,sortColName,sortOrder
	   * @return JqgridResponse<WorkOrderOutputDTO> response
	   */
	@RequestMapping(value = "/multiwireRecords", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	JqgridResponse<WorkOrderOutputDTO> multiwireRecords(
			@RequestParam(value = "workOrder", required = true) String workOrder,
			@RequestParam("_search") Boolean search,
			@RequestParam(value = "filters", required = false) String filters,
			@RequestParam(value = "page", required = false) Integer pageNumber,
			@RequestParam(value = "rows", required = false) Integer rowsPerPage,
			@RequestParam(value = "sidx", required = false) String sortColName,
			@RequestParam(value = "sord", required = false, defaultValue = "asc") String sortOrder) {
		/*JQGrid column sorting*/
		if(sortColName.equalsIgnoreCase("workOrderNo")){
			sortColName="productionWorkOrder.workOrderNo";
		}
		/*Method to fetch the workorder number list based on the process type selected*/
		List<ProductionWorkOrder> pdnList = productionWorkOrderService.findByProductionWorkOrderNo(workOrder);
		/*Intialize JQ grid response of type WorkOrderOutputDTO*/	
		JqgridResponse<WorkOrderOutputDTO> response = new JqgridResponse<WorkOrderOutputDTO>();

		if (pdnList.size() > 0) {
			String process = pdnList.get(0).getProcess().getProcessType();
			if (process.equalsIgnoreCase("MWD")) {
				Page<WorkOrderOutput> orderOutput = workOrderOutputService
						.getWoOutputPagedList(workOrder, pageNumber - 1,
								rowsPerPage, sortColName, sortOrder);
				List<WorkOrderOutputDTO> workOrderOutputDTOs = convertToWoOutputDTO(orderOutput
						.getContent());
				response.setRows(workOrderOutputDTOs);
				response.setRecords(Long
						.valueOf(orderOutput.getTotalElements()).toString());
				response.setTotal(Long.valueOf(orderOutput.getTotalPages())
						.toString());
				response.setPage(Integer.valueOf(orderOutput.getNumber() + 1)
						.toString());
			} else if (process.equalsIgnoreCase("Bunching")) {
				sortColName = "semifinishedStockOutId";
				String woStockedOutProcess = "MWD";
				String confirmstatus="Yes";
				/*Method to fetch the Paged JQGrid records based on the process type selected and work order number*/
				Page<SemifinishedStockOut> semiFinishStockOutList = semifinishedStockOutService
						.findByStockedOutForAndWorkOrderProcess(workOrder,
								woStockedOutProcess,confirmstatus, pageNumber - 1,
								rowsPerPage, sortColName, sortOrder);
				List<WorkOrderOutputDTO> workOrderSemifinisedDTOs = convertToSemifinishedOutputDTO(semiFinishStockOutList
						.getContent());
				response.setRows(workOrderSemifinisedDTOs);
				response.setRecords(Long.valueOf(
						semiFinishStockOutList.getTotalElements()).toString());
				response.setTotal(Long.valueOf(
						semiFinishStockOutList.getTotalPages()).toString());
				response.setPage(Integer.valueOf(
						semiFinishStockOutList.getNumber() + 1).toString());

			} else if (process.equalsIgnoreCase("Extrusion")) {
				String woStockedOutProcess = "MWD";
				List<SemifinishedStockOut> semiFinishedStockList = new ArrayList<>();
				ArrayList<String> bunchingWoList = new ArrayList<>();
				List<SemifinishedStockOut> semifinishedStockOutList = semifinishedStockOutService
						.findByStockedOutFor(workOrder);
				if (semifinishedStockOutList.size() > 0) {
					for (int iterator = 0; iterator < semifinishedStockOutList
							.size(); iterator++) {
						String bunchingWoNo = semifinishedStockOutList
								.get(iterator).getProductionWorkOrders()
								.getWorkOrderNo();
						if (!bunchingWoList.contains(bunchingWoNo)) {
							bunchingWoList.add(bunchingWoNo);
						}// end of if (!bunchingWoList.contains(bunchingWoNo))
					}//end of for loop
					if (bunchingWoList.size() > 0) {
						for (int k = 0; k < bunchingWoList.size(); k++) {
							List<SemifinishedStockOut> semiFinishedList = semifinishedStockOutService
									.findByStockedOutForAndProductionWo(
											bunchingWoList.get(k),
											woStockedOutProcess);
							semiFinishedStockList.addAll(semiFinishedList);
						}// end of for
					}// end of if(bunchingWoList.size()>0)
				} // end of if(semifinishedStockOutList.size()>0)
				int pagenumber = pageNumber - 1;
				List<SemifinishedStockOut> pagedList;
				int fromIndex = Math.min(semiFinishedStockList.size(),
						pagenumber * rowsPerPage);
				int toIndex = Math.min(semiFinishedStockList.size(), fromIndex
						+ rowsPerPage);

				if (fromIndex == 0
						&& toIndex == (semiFinishedStockList.size() - 1)) {
					pagedList = semiFinishedStockList;
				} else {
					pagedList = semiFinishedStockList.subList(fromIndex,
							toIndex);
				}

				List<WorkOrderOutputDTO> semifinisedDTOs = convertToSemifinishedOutputDTO(pagedList);
				response.setRows(semifinisedDTOs);
				response.setRecords(Long.valueOf(semiFinishedStockList.size())
						.toString());
				if (semiFinishedStockList.size() > 0)
					response.setTotal(Integer.valueOf(
							(int) Math.ceil(Double
									.valueOf(semiFinishedStockList.size())
									/ Double.valueOf(rowsPerPage.toString())))
							.toString());
				else
					response.setTotal("0");
				response.setPage(Integer.valueOf(pagenumber + 1).toString());
			}// end of else if(process.equalsIgnoreCase("Extrusion"))
		}//end of if (pdnList.size() > 0)
		return response;

	}
	 /**
	   * This Method to set work order item list to WorkOrderOutputDTO
	   * returns BunchingWOOutputDTOs
	   */
	private List<WorkOrderOutputDTO> convertToSemifinishedOutputDTO(
			List<SemifinishedStockOut> content) {
		List<WorkOrderOutputDTO> BunchingWOOutputDTOs = new ArrayList<>();
		for (SemifinishedStockOut semifinishedStockOut : content) {
			WorkOrderOutputDTO workOrderDTO = new WorkOrderOutputDTO();
			workOrderDTO.setWoOutPutId(semifinishedStockOut
					.getSemifinishedStockOutId());
			workOrderDTO.setWorkOrderNo(semifinishedStockOut
					.getProductionWorkOrders().getWorkOrderNo());
			workOrderDTO.setNetLength(semifinishedStockOut.getStockOutQty());
			workOrderDTO.setNetWeight(semifinishedStockOut.getWeight());
			workOrderDTO.setSize(semifinishedStockOut.getSalesOrderItem()
					.getItem().getItemDescription());
			String bundleId = (semifinishedStockOut.getBundleId()).substring(1,
					3);
			workOrderDTO.setBatchNo(semifinishedStockOut
					.getProductionWorkOrders().getWorkOrderNo()
					+ "/"
					+ bundleId);
			workOrderDTO.setUpdatedBy(semifinishedStockOut.getSupervisor());
			Long orderDetailsId=semifinishedStockOut.getSalesOrderItem().getOrderDetailId();
			String bundles=semifinishedStockOut.getBundleId();
			String woNo=semifinishedStockOut.getProductionWorkOrders().getWorkOrderNo();
			List<StoreRegister>storeReglist=storeRegisterService.findByOrderDetailIdAndBundleIdAndWorkOrderNo(orderDetailsId, bundles, woNo);
			if(storeReglist.size()>0){
				workOrderDTO.setSpeed(storeReglist.get(0).getQcStatus());
				workOrderDTO.setAnnealingPercent(storeReglist.get(0).getQcSupervisor());
				workOrderDTO.setRemarks(storeReglist.get(0).getRemarks());
			
			}
			else{
				List<StockOut>stockOutlist=stockOutService.findByOrderDetailIdWorkOrderNoBundleId(orderDetailsId, woNo, bundles);
				if(stockOutlist.size()>0){
					workOrderDTO.setSpeed(stockOutlist.get(0).getQcStatus());
					workOrderDTO.setAnnealingPercent(stockOutlist.get(0).getQcSupervisor());
					workOrderDTO.setRemarks(stockOutlist.get(0).getRemarks());
				
				}//end of if(stockOutlist.size()>0)
			}//end of if else ladder
			BunchingWOOutputDTOs.add(workOrderDTO);
		}
		return BunchingWOOutputDTOs;
	}
	 /**
	   * This Method to set work order item list to WorkOrderOutputDTO
	   * returns BunchingWOOutputDTOs
	   */
	private List<WorkOrderOutputDTO> convertToWoOutputDTO(
			List<WorkOrderOutput> workOrderOutputs) {
		List<WorkOrderOutputDTO> BunchingWOOutputDTOs = new ArrayList<>();
		for(WorkOrderOutput workOrderOutput : workOrderOutputs) {
			WorkOrderOutputDTO workOrderDTO = new WorkOrderOutputDTO();
			workOrderDTO.setWoOutPutId(workOrderOutput.getWoOutPutId());
			workOrderDTO.setWorkOrderNo(workOrderOutput.getProductionWorkOrder().getWorkOrderNo());
			workOrderDTO.setNetLength(workOrderOutput.getNetLength());
			workOrderDTO.setGrossWeight(workOrderOutput.getGrossWeight());
			workOrderDTO.setTareWeight(workOrderOutput.getTareWeight());
			workOrderDTO.setNetWeight(workOrderOutput.getNetWeight());
			workOrderDTO.setNoOfStrands(workOrderOutput.getNoOfStrands());
			workOrderDTO.setSize(workOrderOutput.getSalesOrderItem().getItem().getItemDescription());
			workOrderDTO.setOuterDiameter(workOrderOutput.getOuterDiameter());
			workOrderDTO.setUpdatedBy(workOrderOutput.getUpdatedBy());
			workOrderDTO.setBatchNo(workOrderOutput.getBatchNo());
			workOrderDTO.setStockIn(workOrderOutput.getStockIn());
			workOrderDTO.setOrderDetailId(workOrderOutput.getSalesOrderItem().getOrderDetailId());
			Long orderDetailId=workOrderOutput.getSalesOrderItem().getOrderDetailId();
			String bundleIds="0"+ workOrderOutput.getBatchNo().split("/")[1];
			String woNo=workOrderOutput.getProductionWorkOrder().getWorkOrderNo();
			
			List<StoreRegister>storeReglist=storeRegisterService.findByOrderDetailIdAndBundleIdAndWorkOrderNo(orderDetailId, bundleIds, woNo);
			if(storeReglist.size()>0){
				workOrderDTO.setSpeed(storeReglist.get(0).getQcStatus());
				workOrderDTO.setAnnealingPercent(storeReglist.get(0).getQcSupervisor());
				workOrderDTO.setRemarks(storeReglist.get(0).getRemarks());
			
			}
			else{
				List<StockOut>stockOutlist=stockOutService.findByOrderDetailIdWorkOrderNoBundleId(orderDetailId, woNo, bundleIds);
				if(stockOutlist.size()>0){
					workOrderDTO.setSpeed(stockOutlist.get(0).getQcStatus());
					workOrderDTO.setAnnealingPercent(stockOutlist.get(0).getQcSupervisor());
					workOrderDTO.setRemarks(stockOutlist.get(0).getRemarks());
				
				}
			}// end of if else
		
			BunchingWOOutputDTOs.add(workOrderDTO);
		}
		return BunchingWOOutputDTOs;
	}
	 /**
	   * This Method to set work order item list to WorkOrderItemsDTO
	   * returns workOrderItemsDTOs
	   */
	private List<WorkOrderItemsDTO> convertToWoItemDTO(List<WorkOrderItems> content) {
		List<WorkOrderItemsDTO> workOrderItemsDTOs = new ArrayList<>();
		for (WorkOrderItems workOrderItems : content) {
			WorkOrderItemsDTO workOrderItemDTO = new WorkOrderItemsDTO();
			workOrderItemDTO.setWorkOrderItemId(workOrderItems
					.getWorkOrderItemId());
			workOrderItemDTO.setWorkOrderNo(workOrderItems
					.getProductionWorkOrder().getWorkOrderNo());
			workOrderItemDTO.setItemDescription(workOrderItems
					.getSalesOrderItem().getItem().getItemDescription());
			workOrderItemDTO
					.setTotalQuantity(workOrderItems.getTotalQuantity());
			workOrderItemDTO.setCustomerName(workOrderItems.getSalesOrderItem()
					.getOrder().getCustomer().getCustomerName());
			workOrderItemDTO.setUpdatedBy(workOrderItems.getUpdatedBY());
			workOrderItemDTO.setOrderDetailId(workOrderItems.getSalesOrderItem().getOrderDetailId());
			
			WorkOrderOutput workOrderOutput=new WorkOrderOutput();
			Long orderDetailId=workOrderItems.getSalesOrderItem().getOrderDetailId();
			String woNo=workOrderItems.getProductionWorkOrder().getWorkOrderNo();
			
			if(workOrderOutput.getBatchNo()!=null){
				String bundleIds="0"+ workOrderOutput.getBatchNo().split("/")[1];	
				WorkOrderOutputDTO workOrderDTO = new WorkOrderOutputDTO();
				List<StoreRegister>storeReglist=storeRegisterService.findByOrderDetailIdAndBundleIdAndWorkOrderNo(orderDetailId, bundleIds, woNo);
				if(storeReglist.size()>0){
				
		 	     workOrderDTO.setRemarks(storeReglist.get(0).getRemarks());
				
				}
				else{
					List<StockOut>stockOutlist=stockOutService.findByOrderDetailIdWorkOrderNoBundleId(orderDetailId, woNo, bundleIds);
					if(stockOutlist.size()>0){
				
						workOrderDTO.setRemarks(stockOutlist.get(0).getRemarks());
					
					}
				}
			}//end of if else

			workOrderItemsDTOs.add(workOrderItemDTO);
		}//end of for loop
		return workOrderItemsDTOs;
	}
	
	@RequestMapping(value = "/scrapRecords", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	JqgridResponse<ScrapDetailsDTO> scrapRecords(
			@RequestParam(value = "workOrder", required = true) String workOrder,
			@RequestParam("_search") Boolean search,
			@RequestParam(value = "filters", required = false) String filters,
			@RequestParam(value = "page", required = false) Integer pageNumber,
			@RequestParam(value = "rows", required = false) Integer rowsPerPage,
			@RequestParam(value = "sidx", required = false) String sortColName,
			@RequestParam(value = "sord", required = false, defaultValue = "asc") String sortOrder) {
		/*JQGrid column sorting*/
		if(sortColName.equalsIgnoreCase("workOrderNo")){
			sortColName="productionWorkOrder.workOrderNo";
		}
		if(sortColName.equalsIgnoreCase("itemDescription")){
			sortColName="item.itemDescription";
		}
		if(sortColName.equalsIgnoreCase("machineDesciption")){
			sortColName="machineDetails.description";
		}
		if(sortColName.equalsIgnoreCase("shiftPattern")){
			sortColName="Shift.shiftPattern";
		}
		if(sortColName.equalsIgnoreCase("shiftPattern")){
            sortColName="Shift.shiftId";
		}
		if(sortColName.equalsIgnoreCase("shiftPattern")){
            sortColName="Shift.shiftDesc";
		}
		String stockedInstatus="Yes";
		/*Method to fetch JQGRID paged records items from scrap details*/
		Page<ScrapDetails> scrapList =scrapDetailsService.getPagedScrapByWorkOrderAndStockedInStatus(workOrder,stockedInstatus,pageNumber - 1,
				rowsPerPage, sortColName, sortOrder);
		/*Intialize JQ grid response of type ScrapDetailsDTO*/	
        JqgridResponse<ScrapDetailsDTO> response = new JqgridResponse<ScrapDetailsDTO>();
		/*Method to set work order items list to ScrapDetailsDTO*/
        List<ScrapDetailsDTO> scrapDetailsDTOs = convertToScrapDetailsDTO(scrapList.getContent());
		response.setRows(scrapDetailsDTOs);
		response.setRecords(Long.valueOf(scrapList.getTotalElements()).toString());
		response.setTotal(Long.valueOf(scrapList.getTotalPages()).toString());
		response.setPage(Integer.valueOf(scrapList.getNumber()+1).toString());
		return response;
		
	}
	 /**
	   * This Method to set work order item list to ScrapDetailsDTO
	   * returns scrapDetailsDTOs
	   */
	private List<ScrapDetailsDTO> convertToScrapDetailsDTO(
			List<ScrapDetails> scrapDetails) {
		List<ScrapDetailsDTO> scrapDetailsDTOs = new ArrayList<>();
		for(ScrapDetails scrapDetailObj : scrapDetails) {
			ScrapDetailsDTO scrapDetailsDTO = new ScrapDetailsDTO();
			
			scrapDetailsDTO.setWorkOrderNo(scrapDetailObj.getProductionWorkOrder().getWorkOrderNo());
			scrapDetailsDTO.setItemCode(scrapDetailObj.getItem().getItemCode());
			scrapDetailsDTO.setItemId(scrapDetailObj.getItem().getItemId());
			scrapDetailsDTO.setItemDesc(scrapDetailObj.getItem().getItemDescription());
			scrapDetailsDTO.setMachineNo(scrapDetailObj.getMachineDetails().getMachineNo());
			scrapDetailsDTO.setMachineDesciption(scrapDetailObj.getMachineDetails().getDescription());
			scrapDetailsDTO.setQuantity(scrapDetailObj.getQuantity());
			scrapDetailsDTO.setStockedInStatus(scrapDetailObj.getStockedInStatus());
			scrapDetailsDTO.setScrapDate(scrapDetailObj.getScrapDate());
			scrapDetailsDTO.setShiftId(scrapDetailObj.getShift().getShiftId());
			scrapDetailsDTO.setShiftPattern(scrapDetailObj.getShift().getShiftPattern());
			scrapDetailsDTO.setSupervisor(scrapDetailObj.getSupervisor());
			scrapDetailsDTO.setScrapId(scrapDetailObj.getScrapId());
			scrapDetailsDTO.setProductKey(scrapDetailObj.getItem().getProductType().getProductKey());

			scrapDetailsDTOs.add(scrapDetailsDTO);
		}//end of for loop
		return scrapDetailsDTOs;
	}
	
	
	@RequestMapping(value = "/extrusionQualityRecords", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody
	JqgridResponse<StockOutDTO> extrusionQualityRecords(
			@RequestParam("workOrderItemId") Long workOrderItemId,
			@RequestParam("_search") Boolean search,
			@RequestParam(value = "filters", required = false) String filters,
			@RequestParam(value = "page", required = false) Integer pageNumber,
			@RequestParam(value = "rows", required = false) Integer rowsPerPage,
			@RequestParam(value = "sidx", required = false) String sortColName,
			@RequestParam(value = "sord", required = false, defaultValue = "asc") String sortOrder) {
		List<WorkOrderItems>workOrderItemList=workOrderItemService.findById(workOrderItemId);
		   JqgridResponse<StockOutDTO> response = new JqgridResponse<StockOutDTO>();
		   if(sortColName.equalsIgnoreCase("stockOutId"))
			   sortColName="stockId";
		   else
			   sortColName="bundleId";
        	 
		if(workOrderItemList.size()>0){
			String workOrderNo=workOrderItemList.get(0).getProductionWorkOrder().getWorkOrderNo();
			Long salesOrderItemId=workOrderItemList.get(0).getSalesOrderItem().getOrderDetailId();
			String confrimstatus="Yes";
			if(workOrderNo!=null && salesOrderItemId!=null ){
				//List<StockOut>stockOutlist=stockOutService.findBySalesOrderItemIdAndWorkOrderNoAndConfirmStatus(salesOrderItemId,workOrderNo,confrimstatus);
			//	List<StoreRegister>storeRegList=storeRegisterService.findBySalesOrderItemIdAndWorkOrderNo(salesOrderItemId,workOrderNo);
				 List<Object[]> storeBundleList=stockOutService.getStoreRegBundleDetails(salesOrderItemId,workOrderNo,sortColName,sortOrder);
				 List<Object[]> stockOutBundleList=stockOutService.getStockOutBundleDetails(salesOrderItemId,workOrderNo,confrimstatus,sortColName,sortOrder);

				 List<Object[]> bundleList = new ArrayList<Object[]>();
				 bundleList.addAll(storeBundleList);
				 bundleList.addAll(stockOutBundleList);
				 
				 List<StockOutDTO> stockOutDTOs = new ArrayList<>();
				 Integer pagenumber=0;
				 if(pageNumber!=null)
			     pagenumber= pageNumber-1;
			 
				  int fromIndex = Math.min(bundleList.size(), pagenumber * rowsPerPage);
			      int toIndex = Math.min(bundleList.size(), fromIndex + rowsPerPage);
			      List<Object[]> pagedList;
				   if (fromIndex == 0 && toIndex == (bundleList.size() - 1))
			          pagedList = bundleList;
			       else
			          pagedList = bundleList.subList(fromIndex, toIndex);
				   for(Object[] element : pagedList) {
						
						  Long stockId=(Long) element[0]; 
						  //Long soItemId=(Long) element[1];
						 // String woNo=(String) element[2];
						  String bundleId=(String) element[1];
						  String qcSupervisor=(String) element[2];
						  String qcStatus=(String) element[3];
						  String remarks=(String) element[4];
						  String stockstatus=(String) element[5];
				    	    StockOutDTO stockOutDTO=new StockOutDTO();
		    		        stockOutDTO.setStockOutId(stockId);
		    		        stockOutDTO.setBundleId(bundleId);
		    		        stockOutDTO.setRemarks(remarks);
		    		        stockOutDTO.setQcSupervisor(qcSupervisor);
		    		        stockOutDTO.setQcStatus(qcStatus);
		    		        stockOutDTO.setStatus(stockstatus);
		    		        stockOutDTOs.add(stockOutDTO);
			
				   	}   
				   
			       response.setRows(stockOutDTOs);
			       response.setRecords(Long.valueOf(bundleList.size()).toString());
			       if(bundleList.size()>0)
			        response.setTotal(Integer.valueOf((int)Math.ceil(Double.valueOf(bundleList.size())/Double.valueOf(rowsPerPage.toString()))).toString());
			       else
			       response.setTotal("0");
			       response.setPage(Integer.valueOf(pagenumber+1).toString());
			       return response;


          	}
	  }

	       return response;
	}


		
}