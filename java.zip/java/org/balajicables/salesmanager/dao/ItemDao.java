package org.balajicables.salesmanager.dao;

import java.util.List;

import org.balajicables.salesmanager.model.CableStdPvc;
import org.balajicables.salesmanager.model.Colour;
import org.balajicables.salesmanager.model.CopperDiameter;
import org.balajicables.salesmanager.model.Item;
import org.balajicables.salesmanager.model.ProductType;
import org.balajicables.salesmanager.model.Unit;

public interface ItemDao {

	public void create(Item item);

	public void delete(Item item);

	public void update(Item item);

	public List<Item> getAll();

	public List<Item> get(int page, int rowsPerPage, String sortColName,
			String sortOrder);

	public long getItemsCount();

	public Item getById(Long itemId);

	public List<CableStdPvc> getAllCableStdPvcs();

	public List<CopperDiameter> getAllCopperDiameters();

	public List<Colour> getAllColours();

	public List<ProductType> getAllProductTypes();

	public List<Item> getAllItemId();

	public List<Item> getAllRawMaterial();

	public List<Unit> getAllUnit();


}
