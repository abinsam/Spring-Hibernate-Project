package org.balajicables.salesmanager.dao;

import org.balajicables.salesmanager.model.User;

public interface UserDao {
	public void save(User user);

	public User get(String userId);

	public User findByName(String userName);

	User findByEmailId(String emailId);

}
