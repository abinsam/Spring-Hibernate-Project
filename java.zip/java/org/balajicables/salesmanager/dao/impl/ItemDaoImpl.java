package org.balajicables.salesmanager.dao.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Order;
import javax.persistence.criteria.Root;

import org.balajicables.salesmanager.dao.ItemDao;
import org.balajicables.salesmanager.model.CableStdPvc;
import org.balajicables.salesmanager.model.Colour;
import org.balajicables.salesmanager.model.CopperDiameter;
import org.balajicables.salesmanager.model.Item;
import org.balajicables.salesmanager.model.ProductType;
import org.balajicables.salesmanager.model.Unit;
import org.springframework.stereotype.Repository;

@Repository
public class ItemDaoImpl implements ItemDao {

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public void create(Item item) {
		entityManager.persist(item);
	}

	@Override
	public void delete(Item item) {
		entityManager.remove(item);
	}

	@Override
	public void update(Item item) {
		entityManager.merge(item);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Item> getAll() {
		return entityManager.createQuery("from Item i").getResultList();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Item> get(int page, int rowsPerPage, String sortColName,
			String sortOrder) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Object> criteriaQuery = criteriaBuilder.createQuery();
		Root<Item> from = criteriaQuery.from(Item.class);
		CriteriaQuery<Object> select = criteriaQuery.select(from);
		if (sortColName != null && !"".equals(sortColName)) {
			Order orderCriteria = null;
			if ("desc".equalsIgnoreCase(sortOrder)) {
				orderCriteria = criteriaBuilder.desc(from.get(sortColName));
			} else {
				orderCriteria = criteriaBuilder.asc(from.get(sortColName));
			}
			select.orderBy(orderCriteria);
		}
		TypedQuery<Object> typedQuery = entityManager.createQuery(select);
		typedQuery.setFirstResult(page * rowsPerPage);
		typedQuery.setMaxResults(rowsPerPage);
		@SuppressWarnings("rawtypes")
		List resultList = typedQuery.getResultList();
		return resultList;
	}

	@Override
	public long getItemsCount() {
		Long count = (Long) entityManager
				.createQuery("SELECT COUNT(i.itemCode) FROM Item i")
				.getSingleResult();
		return count.longValue();
	}

	@Override
	public Item getById(Long itemId) {
		return entityManager.find(Item.class, itemId);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<CableStdPvc> getAllCableStdPvcs() {
		return entityManager.createQuery("from CableStdPvc c").getResultList();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<CopperDiameter> getAllCopperDiameters() {
		return entityManager.createQuery("from CopperDiameter c").getResultList();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Colour> getAllColours() {
		return entityManager.createQuery("from Colour c").getResultList();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<ProductType> getAllProductTypes() {
		return entityManager.createQuery("from ProductType p").getResultList();
	}

	@Override
	public List<Item> getAllItemId() {
		return entityManager.createQuery("from Item i ").getResultList();
	}

	@Override
	public List<Item> getAllRawMaterial() {
		return entityManager.createQuery("from Item i where i.itemType='RAW'").getResultList();
	}

	@Override
	public List<Unit> getAllUnit() {
		return entityManager.createQuery("from Unit p").getResultList();
	}
	
	
}
