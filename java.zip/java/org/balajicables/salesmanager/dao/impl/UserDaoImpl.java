package org.balajicables.salesmanager.dao.impl;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.balajicables.salesmanager.dao.UserDao;
import org.balajicables.salesmanager.model.User;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("userDao")
public class UserDaoImpl implements UserDao {

	Logger logger = LoggerFactory.getLogger(UserDaoImpl.class);
	
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	@Transactional
	public void save(User user) {
		entityManager.persist(user);
	}

	@Override
	public User get(String userId) {
		return entityManager.find(User.class, userId);
	}

	@Override
	public User findByName(String userName) {
		logger.info("In findByName method for userName:" + userName);
		Query query = entityManager.createQuery("from User u where u.userName = :userName");
		query.setParameter("userName", userName);
		User user = (User) query.getSingleResult();
		return user;
	}

	@Override
	public User findByEmailId(String emailId) {
		Query query = entityManager.createQuery("from User u where u.emailId ="+emailId);
		query.setParameter("emailId", emailId);
		User user = (User) query.getSingleResult();
		return user;
	}

}
