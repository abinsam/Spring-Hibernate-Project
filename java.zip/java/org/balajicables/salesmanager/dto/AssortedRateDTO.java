package org.balajicables.salesmanager.dto;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.balajicables.salesmanager.model.AssortedRate;

public class AssortedRateDTO implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Long assortedRateId;
	private String customerCode;
	private String assortedType;
	private Float rate;
	private String updatedTime;
	private Long bundleSize;
	public Long getAssortedRateId() {
		return assortedRateId;
	}
	public void setAssortedRateId(Long assortedRateId) {
		this.assortedRateId = assortedRateId;
	}
	public String getCustomerCode() {
		return customerCode;
	}
	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}
	public String getAssortedType() {
		return assortedType;
	}
	public void setAssortedType(String assortedType) {
		this.assortedType = assortedType;
	}
	public Float getRate() {
		return rate;
	}
	public void setRate(Float rate) {
		this.rate = rate;
	}
	public String getUpdatedTime() {
		return updatedTime;
	}
	public void setUpdatedTime(String updatedTime) {
		this.updatedTime = updatedTime;
	}
	public Long getBundleSize() {
		return bundleSize;
	}
	public void setBundleSize(Long bundleSize) {
		this.bundleSize = bundleSize;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	public AssortedRate getAssortedRate() {
		AssortedRate assortedRate = new AssortedRate();
		assortedRate.setAssortedRateId(assortedRateId);
		assortedRate.setCustomerCode(customerCode);
		assortedRate.setAssortedType(assortedType);
		assortedRate.setRate(rate);
		assortedRate.setBundleSize(bundleSize);
		if(updatedTime!=null){

		      SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss.SSS");
		      java.util.Date parsedDate = null;
			  try {
				parsedDate = dateFormat.parse(updatedTime);
			  } catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			 }
		      java.sql.Timestamp timestamp = new java.sql.Timestamp(parsedDate.getTime());
		      assortedRate.setUpdatedTime(timestamp);
		}	
		return assortedRate;
	}
}
