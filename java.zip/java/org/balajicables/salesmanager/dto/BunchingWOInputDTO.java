package org.balajicables.salesmanager.dto;

import java.io.Serializable;
import org.balajicables.salesmanager.model.BunchingWOInput;
import org.balajicables.salesmanager.model.Customer;
import org.balajicables.salesmanager.model.ProductionWorkOrder;
import org.balajicables.salesmanager.model.SalesOrderItem;

public class BunchingWOInputDTO implements Serializable {

	private static final long serialVersionUID = 1L;
	private Long bunchWoInputId;
	private String workOrderNo;
	private  String size;	
	private  Double netLength;
	private Long noOfDrums;
	private Double lengthPerDrum;
	private Long orderDetailId;
	private Integer layLength;
	private  String status;
	private String updatedBy;
	private String customerName;
    private  Double totalQty;
    private String createdBy;
    private  String selectStatus;
	private String customerCode;
	
	public String getCustomerCode() {
		return customerCode;
	}



	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}



	public Long getBunchWoInputId() {
		return bunchWoInputId;
	}



	public void setBunchWoInputId(Long bunchWoInputId) {
		this.bunchWoInputId = bunchWoInputId;
	}



	public String getWorkOrderNo() {
		return workOrderNo;
	}



	public void setWorkOrderNo(String workOrderNo) {
		this.workOrderNo = workOrderNo;
	}



	public String getSize() {
		return size;
	}



	public void setSize(String size) {
		this.size = size;
	}



	public Double getNetLength() {
		return netLength;
	}



	public void setNetLength(Double netLength) {
		this.netLength = netLength;
	}



	public Long getNoOfDrums() {
		return noOfDrums;
	}



	public void setNoOfDrums(Long noOfDrums) {
		this.noOfDrums = noOfDrums;
	}



	public Double getLengthPerDrum() {
		return lengthPerDrum;
	}



	public void setLengthPerDrum(Double lengthPerDrum) {
		this.lengthPerDrum = lengthPerDrum;
	}



	public Long getOrderDetailId() {
		return orderDetailId;
	}



	public void setOrderDetailId(Long orderDetailId) {
		this.orderDetailId = orderDetailId;
	}



	public Integer getLayLength() {
		return layLength;
	}



	public void setLayLength(Integer layLength) {
		this.layLength = layLength;
	}



	public String getStatus() {
		return status;
	}



	public void setStatus(String status) {
		this.status = status;
	}



	public String getUpdatedBy() {
		return updatedBy;
	}



	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}



	public String getCustomerName() {
		return customerName;
	}



	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}



	public Double getTotalQty() {
		return totalQty;
	}



	public void setTotalQty(Double totalQty) {
		this.totalQty = totalQty;
	}



	public String getCreatedBy() {
		return createdBy;
	}



	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}



	public static long getSerialversionuid() {
		return serialVersionUID;
	}



	public String getSelectStatus() {
		return selectStatus;
	}



	public void setSelectStatus(String selectStatus) {
		this.selectStatus = selectStatus;
	}



	public BunchingWOInput getBunchingWOInput() {
       BunchingWOInput bunchingWOInput = new BunchingWOInput();
       bunchingWOInput.setBunchWoInputId(bunchWoInputId);
       
       Customer customer = new Customer();
	   customer.setCustomerCode(customerCode);
       
       ProductionWorkOrder pdnWorkOrder=new ProductionWorkOrder();
       pdnWorkOrder.setWorkOrderNo(workOrderNo);
       
       SalesOrderItem salesOrderItem = new SalesOrderItem();
       salesOrderItem.setOrderDetailId(orderDetailId);
       
       bunchingWOInput.setProductionWorkOrder(pdnWorkOrder);
       bunchingWOInput.setSalesOrderItem(salesOrderItem);
       bunchingWOInput.setSize(size);
       bunchingWOInput.setNetLength(netLength);
       bunchingWOInput.setNoOfDrums(noOfDrums);
       bunchingWOInput.setLengthPerDrum(lengthPerDrum);
       bunchingWOInput.setLayLength(layLength);
       bunchingWOInput.setCustomerName(customerName);
       bunchingWOInput.setCreatedBy(createdBy);
       bunchingWOInput.setUpdatedBy(updatedBy);
       bunchingWOInput.setTotalQty(totalQty);
       bunchingWOInput.setSelectStatus(selectStatus);
       bunchingWOInput.setStatus(status);
       return bunchingWOInput;
	}

}