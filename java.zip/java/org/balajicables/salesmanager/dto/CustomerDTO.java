package org.balajicables.salesmanager.dto;

import java.io.Serializable;
import org.balajicables.salesmanager.model.Customer;
import org.hibernate.validator.constraints.NotBlank;

public class CustomerDTO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Long customerId;

	@NotBlank
	private String customerName;

	private String customerCode;

	private String contactPerson;

	private String contactNo;

	private String altContactNo;

	private String email;

	private String address;

	private String city;

	private String state;

	private String country;

	private Integer pincode;

	private String vatRegNo;

	private String cstRegNo;

	private String eccNo;

	private String tinNo;

	private String panNo;



	private Float exciseDuty;

	private Float eduCess;

	private Float higherEduCess;

	private Float vat;

	private Float cst;




	public Float getExciseDuty() {
		return exciseDuty;
	}

	public void setExciseDuty(Float exciseDuty) {
		this.exciseDuty = exciseDuty;
	}

	public Float getEduCess() {
		return eduCess;
	}

	public void setEduCess(Float eduCess) {
		this.eduCess = eduCess;
	}

	public Float getHigherEduCess() {
		return higherEduCess;
	}

	public void setHigherEduCess(Float higherEduCess) {
		this.higherEduCess = higherEduCess;
	}

	public Float getVat() {
		return vat;
	}

	public void setVat(Float vat) {
		this.vat = vat;
	}

	public Float getCst() {
		return cst;
	}

	public void setCst(Float cst) {
		this.cst = cst;
	}



	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public Long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerCode() {
		return customerCode;
	}

	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}

	public String getContactPerson() {
		return contactPerson;
	}

	public void setContactPerson(String contactPerson) {
		this.contactPerson = contactPerson;
	}

	public String getAltContactNo() {
		return altContactNo;
	}

	public void setAltContactNo(String altContactNo) {
		this.altContactNo = altContactNo;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public Integer getPincode() {
		return pincode;
	}

	public void setPincode(Integer pincode) {
		this.pincode = pincode;
	}

	public String getVatRegNo() {
		return vatRegNo;
	}

	public void setVatRegNo(String vatRegNo) {
		this.vatRegNo = vatRegNo;
	}

	public String getCstRegNo() {
		return cstRegNo;
	}

	public void setCstRegNo(String cstRegNo) {
		this.cstRegNo = cstRegNo;
	}

	public String getEccNo() {
		return eccNo;
	}

	public void setEccNo(String eccNo) {
		this.eccNo = eccNo;
	}

	public String getTinNo() {
		return tinNo;
	}

	public void setTinNo(String tinNo) {
		this.tinNo = tinNo;
	}

	public String getPanNo() {
		return panNo;
	}

	public void setPanNo(String panNo) {
		this.panNo = panNo;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public Customer getCustomer(){
	
		Customer customer = new Customer();
		
			customer.setAddress(address);
			customer.setAltContactNo(altContactNo);
			customer.setCity(city);
			customer.setContactNo(altContactNo);
			customer.setContactPerson(contactPerson);
			customer.setCountry(country);
			customer.setCstRegNo(cstRegNo);
			customer.setCustomerCode(customerCode);
			customer.setCustomerId(customerId);
			customer.setCustomerName(customerName);
			customer.setEccNo(eccNo);
			customer.setEmail(email);
			customer.setVatRegNo(vatRegNo);
			customer.setTinNo(tinNo);
			customer.setState(state);
			customer.setPincode(pincode);
		
			customer.setPanNo(panNo);
		
		return customer;

	}

}
