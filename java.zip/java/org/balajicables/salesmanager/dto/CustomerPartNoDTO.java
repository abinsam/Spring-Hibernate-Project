package org.balajicables.salesmanager.dto;

import java.io.Serializable;
import org.balajicables.salesmanager.model.Customer;
import org.balajicables.salesmanager.model.CustomerPartNo;
import org.balajicables.salesmanager.model.Item;

public class CustomerPartNoDTO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Long customerId;
	private Integer partNoId;
	private String customerName;
	private String partNo;
	private String itemCode;
	private long itemId;
	private String itemDescription;
	
	public Long getCustomerId() {
		return customerId;
	}
	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}
	public String getItemCode() {
		return itemCode;
	}
	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}
	public String getItemDescription() {
		return itemDescription;
	}
	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}
	public Integer getPartNoId() {
		return partNoId;
	}
	public void setPartNoId(Integer partNoId) {
		this.partNoId = partNoId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getPartNo() {
		return partNo;
	}
	public void setPartNo(String partNo) {
		this.partNo = partNo;
	}
	public long getItemId() {
		return itemId;
	}
	public void setItemId(long itemId) {
		this.itemId = itemId;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public CustomerPartNo getCustomerPartNo()
	{
		CustomerPartNo customerPartNo = new CustomerPartNo();
		customerPartNo.setPartNoId(partNoId);
		Customer customer = new Customer();
		customer.setCustomerId(customerId);
		customer.setCustomerName(customerName);
		
		Item items = new Item();
		items.setItemCode(itemCode);
		items.setItemId(itemId);
		items.setItemDescription(itemDescription);
		
		customerPartNo.setCustomer(customer);
		customerPartNo.setItems(items);
		customerPartNo.setPartNo(partNo);
		return customerPartNo;
	}
	
}
