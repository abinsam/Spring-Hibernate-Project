package org.balajicables.salesmanager.dto;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import org.balajicables.salesmanager.model.DeliveryChallan;
import org.balajicables.salesmanager.model.SalesOrder;
import org.balajicables.salesmanager.utils.Utility;

public class DeliveryChallanDTO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * 
	 */

	private  String deliveryChallanNo;
	private Long workOrderItemId;
	private String workOrderNo;
	private String inputSize;
	private Double totalQuantity;
	private String challanDate;
	private Long stockOutId;
	private Integer storeId;
	private  String storeAddress;
	private long itemId;
	private String itemCode;
	private String itemDescription;
	private  String orderId;
	private  String customerName;
	private  Double stockOutQty;
	private  String invoiceStatus;
    private String invoiceNo;
	private  String dcStatus;
	private  String bundleId;
	private  String qcStatus;
	private Long packingSlipNo;
    private String createdTime ;
    private Double weight;
	private Long orderDetailId;
    private Float rate;
    private String assortedType;
    private String poDetails;
    private String units;
    private String dcSupervisor;
    private String status;
    private String remarks;

    public String getDcSupervisor() {
		return dcSupervisor;
	}


	public void setDcSupervisor(String dcSupervisor) {
		this.dcSupervisor = dcSupervisor;
	}


	public static long getSerialversionuid() {
		return serialVersionUID;
	}


	public String getInputSize() {
		return inputSize;
	}


	public void setInputSize(String inputSize) {
		this.inputSize = inputSize;
	}


    
    public Long getWorkOrderItemId() {
		return workOrderItemId;
	}


	public void setWorkOrderItemId(Long workOrderItemId) {
		this.workOrderItemId = workOrderItemId;
	}


	public String getWorkOrderNo() {
		return workOrderNo;
	}


	public void setWorkOrderNo(String workOrderNo) {
		this.workOrderNo = workOrderNo;
	}

	public Double getTotalQuantity() {
		return totalQuantity;
	}


	public void setTotalQuantity(Double totalQuantity) {
		this.totalQuantity = totalQuantity;
	}
	
	
	public String getCreatedTime() {
		return createdTime;
	}


	public void setCreatedTime(String createdTime) {
		this.createdTime = createdTime;
	}


	public String getInvoiceNo() {
		return invoiceNo;
	}


	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}
	
public String getPoDetails() {
		return poDetails;
	}


	public void setPoDetails(String poDetails) {
		this.poDetails = poDetails;
	}


public String getAssortedType() {
		return assortedType;
	}


	public void setAssortedType(String assortedType) {
		this.assortedType = assortedType;
	}


	public String getDeliveryChallanNo() {
		return deliveryChallanNo;
	}


	public void setDeliveryChallanNo(String deliveryChallanNo) {
		this.deliveryChallanNo = deliveryChallanNo;
	}





	public Long getStockOutId() {
		return stockOutId;
	}


	public void setStockOutId(Long stockOutId) {
		this.stockOutId = stockOutId;
	}


public Integer getStoreId() {
		return storeId;
	}


	public void setStoreId(Integer storeId) {
		this.storeId = storeId;
	}


	public String getStoreAddress() {
		return storeAddress;
	}


	public void setStoreAddress(String storeAddress) {
		this.storeAddress = storeAddress;
	}


	public long getItemId() {
		return itemId;
	}


	public void setItemId(long itemId) {
		this.itemId = itemId;
	}


	public String getItemCode() {
		return itemCode;
	}


	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}


	public String getItemDescription() {
		return itemDescription;
	}


	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}


	public String getOrderId() {
		return orderId;
	}


	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}


	public String getCustomerName() {
		return customerName;
	}


	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}


	public Double getStockOutQty() {
		return stockOutQty;
	}


	public void setStockOutQty(Double stockOutQty) {
		this.stockOutQty = stockOutQty;
	}




	public Long getPackingSlipNo() {
		return packingSlipNo;
	}


	public void setPackingSlipNo(Long packingSlipNo) {
		this.packingSlipNo = packingSlipNo;
	}


	public Double getWeight() {
		return weight;
	}


	public void setWeight(Double weight) {
		this.weight = weight;
	}
	
public Long getOrderDetailId() {
		return orderDetailId;
	}


	public void setOrderDetailId(Long orderDetailId) {
		this.orderDetailId = orderDetailId;
	}

	public String getDcStatus() {
		return dcStatus;
	}


	public void setDcStatus(String dcStatus) {
		this.dcStatus = dcStatus;
	}

public String getChallanDate() {
	return challanDate;
}


public void setChallanDate(String challanDate) {
	this.challanDate = challanDate;
}

public String getBundleId() {
	return bundleId;
}


public void setBundleId(String bundleId) {
	this.bundleId = bundleId;
}


public String getQcStatus() {
	return qcStatus;
}


public void setQcStatus(String qcStatus) {
	this.qcStatus = qcStatus;
}


public String getInvoiceStatus() {
	return invoiceStatus;
}


public Float getRate() {
	return rate;
}


public void setRate(Float rate) {
	this.rate = rate;
}


public String getUnits() {
	return units;
}


public void setUnits(String units) {
	this.units = units;
}


public void setInvoiceStatus(String invoiceStatus) {
	this.invoiceStatus = invoiceStatus;
}


public String getStatus() {
	return status;
}


public void setStatus(String status) {
	this.status = status;
}


public String getRemarks() {
	return remarks;
}


public void setRemarks(String remarks) {
	this.remarks = remarks;
}


public DeliveryChallan getDeliveryChallan() {
	DeliveryChallan deliveryChallan=new DeliveryChallan();
	if(challanDate!=null && challanDate!="")
		deliveryChallan.setChallanDate(Utility.formDateFormatter.parseDateTime(challanDate).toDate());
		else
			deliveryChallan.setChallanDate(null);
	
    deliveryChallan.setDeliveryChallanNo(deliveryChallanNo);
	deliveryChallan.setInvoiceStatus(invoiceStatus);
	deliveryChallan.setInvoiceNo(invoiceNo);
	deliveryChallan.setDcSupervisor(dcSupervisor);
	deliveryChallan.setStatus(status);
	deliveryChallan.setRemarks(remarks);
	SalesOrder orders=new SalesOrder();
	orders.setOrderId(orderId);
	deliveryChallan.setOrders(orders);
	if(createdTime!=null){

	      SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
	      java.util.Date parsedDate = null;
		  try {
			parsedDate = dateFormat.parse(createdTime);
		  } catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		 }
	      java.sql.Timestamp timestamp = new java.sql.Timestamp(parsedDate.getTime());
			
			
	      deliveryChallan.setCreatedTime(timestamp);
	}

		return deliveryChallan;
	}











}