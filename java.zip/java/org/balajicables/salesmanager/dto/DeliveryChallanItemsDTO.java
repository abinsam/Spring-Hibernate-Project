package org.balajicables.salesmanager.dto;

import java.io.Serializable;

import org.balajicables.salesmanager.model.DeliveryChallan;
import org.balajicables.salesmanager.model.DeliveryChallanItems;
import org.balajicables.salesmanager.model.Item;

public class DeliveryChallanItemsDTO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * 
	 */
	private Long dcItemId;
	private  String deliveryChallanNo;
	private  Long itemId;
	private  String itemDescription;
	private  String units;
	private Long noOfRolls;
	private Double qtyPerRoll;
	private Double totalQty;
	private Float rate;
	private  String assortedType;
	private  String unitType;
	private  String productTypeKey;
	
public Long getDcItemId() {
		return dcItemId;
	}


	public void setDcItemId(Long dcItemId) {
		this.dcItemId = dcItemId;
	}


	public String getDeliveryChallanNo() {
		return deliveryChallanNo;
	}


	public void setDeliveryChallanNo(String deliveryChallanNo) {
		this.deliveryChallanNo = deliveryChallanNo;
	}


	public String getItemDescription() {
		return itemDescription;
	}


	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}


	public Long getNoOfRolls() {
		return noOfRolls;
	}


	public void setNoOfRolls(Long noOfRolls) {
		this.noOfRolls = noOfRolls;
	}


	public Double getQtyPerRoll() {
		return qtyPerRoll;
	}


	public void setQtyPerRoll(Double qtyPerRoll) {
		this.qtyPerRoll = qtyPerRoll;
	}


	public Double getTotalQty() {
		return totalQty;
	}


	public void setTotalQty(Double totalQty) {
		this.totalQty = totalQty;
	}


	public static long getSerialversionuid() {
		return serialVersionUID;
	}


public String getAssortedType() {
		return assortedType;
	}


	public void setAssortedType(String assortedType) {
		this.assortedType = assortedType;
	}


public String getUnits() {
		return units;
	}


	public void setUnits(String units) {
		this.units = units;
	}


public Float getRate() {
		return rate;
	}


	public void setRate(Float rate) {
		this.rate = rate;
	}


public String getUnitType() {
		return unitType;
	}


	public void setUnitType(String unitType) {
		this.unitType = unitType;
	}


public String getProductTypeKey() {
		return productTypeKey;
	}


	public void setProductTypeKey(String productTypeKey) {
		this.productTypeKey = productTypeKey;
	}


public Long getItemId() {
		return itemId;
	}


	public void setItemId(Long itemId) {
		this.itemId = itemId;
	}


public DeliveryChallanItems getDeliveryChallanItems() {
	DeliveryChallanItems deliveryChallanItems=new DeliveryChallanItems();
	deliveryChallanItems.setDcItemId(dcItemId);
	DeliveryChallan dc=new DeliveryChallan();
	dc.setDeliveryChallanNo(deliveryChallanNo);
	
	Item itemObj=new Item();
	itemObj.setItemId(itemId);
	deliveryChallanItems.setItem(itemObj);
	
	deliveryChallanItems.setDeliveryChallan(dc);
	deliveryChallanItems.setItemDescription(itemDescription);
	deliveryChallanItems.setNoOfRolls(noOfRolls);
	deliveryChallanItems.setQtyPerRoll(qtyPerRoll);
	deliveryChallanItems.setTotalQty(totalQty);
	deliveryChallanItems.setUnits(units);
	deliveryChallanItems.setRate(rate);
	deliveryChallanItems.setUnitType(unitType);
	deliveryChallanItems.setAssortedType(assortedType);
	deliveryChallanItems.setProductTypeKey(productTypeKey);
	return deliveryChallanItems;
	}











}