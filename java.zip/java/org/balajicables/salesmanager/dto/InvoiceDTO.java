package org.balajicables.salesmanager.dto;

import java.io.Serializable;
import java.sql.Timestamp;

import org.balajicables.salesmanager.model.Customer;
import org.balajicables.salesmanager.model.Invoice;
import org.balajicables.salesmanager.utils.Utility;

public class InvoiceDTO implements Serializable {

	private static final long serialVersionUID = 5864038683834374118L;
	private String invoiceNo;
	private String invoiceDate;
	private Timestamp createdTime;
	private Double amount;
	private Long customerId;
	private String transportDetails;
	private String modeOfTransport;
	private String deliveryChallanNo;
	private String lrDetails;
	private String mailStatus;
	private Long bagCount;
	private Double transportCharges;
	private Double finalAmount;
	private  String invoiceSupervisor;
	private  String status;
	private  String remarks;
	private String lrmailStatus;
	private String invoiceAmtInWords;
	
	public String getInvoiceAmtInWords() {
		return invoiceAmtInWords;
	}


	public void setInvoiceAmtInWords(String invoiceAmtInWords) {
		this.invoiceAmtInWords = invoiceAmtInWords;
	}


	public String getInvoiceSupervisor() {
		return invoiceSupervisor;
	}


	public void setInvoiceSupervisor(String invoiceSupervisor) {
		this.invoiceSupervisor = invoiceSupervisor;
	}


	public String getInvoiceNo() {
		return invoiceNo;
	}


	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}


	public String getInvoiceDate() {
		return invoiceDate;
	}


	public void setInvoiceDate(String invoiceDate) {
		this.invoiceDate = invoiceDate;
	}


	public Timestamp getCreatedTime() {
		return createdTime;
	}


	public void setCreatedTime(Timestamp createdTime) {
		this.createdTime = createdTime;
	}


	public Double getAmount() {
		return amount;
	}


	public void setAmount(Double amount) {
		this.amount = amount;
	}


	public Long getCustomerId() {
		return customerId;
	}


	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}


	public String getTransportDetails() {
		return transportDetails;
	}


	public void setTransportDetails(String transportDetails) {
		this.transportDetails = transportDetails;
	}


	public String getModeOfTransport() {
		return modeOfTransport;
	}


	public void setModeOfTransport(String modeOfTransport) {
		this.modeOfTransport = modeOfTransport;
	}


	public String getDeliveryChallanNo() {
		return deliveryChallanNo;
	}


	public void setDeliveryChallanNo(String deliveryChallanNo) {
		this.deliveryChallanNo = deliveryChallanNo;
	}


	public String getLrDetails() {
		return lrDetails;
	}


	public void setLrDetails(String lrDetails) {
		this.lrDetails = lrDetails;
	}


	public String getMailStatus() {
		return mailStatus;
	}


	public void setMailStatus(String mailStatus) {
		this.mailStatus = mailStatus;
	}


	public static long getSerialversionuid() {
		return serialVersionUID;
	}


	public Long getBagCount() {
		return bagCount;
	}


	public void setBagCount(Long bagCount) {
		this.bagCount = bagCount;
	}


	public Double getTransportCharges() {
		return transportCharges;
	}


	public void setTransportCharges(Double transportCharges) {
		this.transportCharges = transportCharges;
	}


	public Double getFinalAmount() {
		return finalAmount;
	}


	public void setFinalAmount(Double finalAmount) {
		this.finalAmount = finalAmount;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public String getRemarks() {
		return remarks;
	}


	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}


	public String getLrmailStatus() {
		return lrmailStatus;
	}


	public void setLrmailStatus(String lrmailStatus) {
		this.lrmailStatus = lrmailStatus;
	}


	public Invoice getInvoice() {

		Invoice invoice = new Invoice();
		
		invoice.setInvoiceNo(invoiceNo);
		if (invoiceDate != null && invoiceDate != "")
			invoice.setInvoiceDate(Utility.formDateFormatter.parseDateTime(
					invoiceDate).toDate());
		else
			invoice.setInvoiceDate(null);
		invoice.setCreatedTime(createdTime);
		invoice.setInvoiceSupervisor(invoiceSupervisor);
		invoice.setAmount(amount);
		Customer customer = new Customer();
		customer.setCustomerId(customerId);
		invoice.setCustomer(customer);
		invoice.setTransportDetails(transportDetails);
		invoice.setModeOfTransport(modeOfTransport);
		invoice.setDeliveryChallanNo(deliveryChallanNo);
		invoice.setLrDetails(lrDetails);
		invoice.setMailStatus(mailStatus);
		invoice.setLrmailStatus(lrmailStatus);
		invoice.setBagCount(bagCount);
		invoice.setTransportCharges(transportCharges);
		invoice.setFinalAmount(finalAmount);
		invoice.setStatus(status);
		invoice.setRemarks(remarks);
		invoice.setInvoiceAmtInWords(invoiceAmtInWords);
		return invoice;
	}

}