package org.balajicables.salesmanager.dto;

import java.io.Serializable;
import java.sql.Timestamp;

import org.balajicables.salesmanager.model.Customer;
import org.balajicables.salesmanager.model.Invoice;
import org.balajicables.salesmanager.model.InvoiceItems;
import org.balajicables.salesmanager.utils.Utility;

public class InvoiceItemsDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5864038683834374118L;
	private Long invoiceId;
	private String invoiceNo;
	private String invoiceDate;
	private Timestamp createdTime;
	private String assortedItem;
	private Long noOfRolls;
	/*private Double quantity;*/
	private Float ratePerUnit;
	private Double totalValue;
	private Float rateOfDuty;
	private Double totalDuty;
	private Double amount;
	private Long customerId;
	private String transportDetails;
	private String modeOfTransport;

	private Double totalQuantity;
	private Double totalEduCess;
	private Double totalHigherEduCess;
	private Double totalSalesTax;
	private Double totalVat;
	private Double totalCst;
	private String deliveryChallanNo;
	private String units;
	private String productTypeKey;

	public Double getTotalQuantity() {
		return totalQuantity;
	}

	public void setTotalQuantity(Double totalQuantity) {
		this.totalQuantity = totalQuantity;
	}

	public String getTransportDetails() {
		return transportDetails;
	}

	public void setTransportDetails(String transportDetails) {
		this.transportDetails = transportDetails;
	}

	public Long getInvoiceId() {
		return invoiceId;
	}

	public void setInvoiceId(Long invoiceId) {
		this.invoiceId = invoiceId;
	}

	public String getInvoiceNo() {
		return invoiceNo;
	}

	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}

	public String getInvoiceDate() {
		return invoiceDate;
	}

	public void setInvoiceDate(String invoiceDate) {
		this.invoiceDate = invoiceDate;
	}

	public String getAssortedItem() {
		return assortedItem;
	}

	public void setAssortedItem(String assortedItem) {
		this.assortedItem = assortedItem;
	}

	public Long getNoOfRolls() {
		return noOfRolls;
	}

	public void setNoOfRolls(Long noOfRolls) {
		this.noOfRolls = noOfRolls;
	}

/*	public Double getQuantity() {
		return quantity;
	}

	public void setQuantity(Double quantity) {
		this.quantity = quantity;
	}*/

	public Float getRatePerUnit() {
		return ratePerUnit;
	}

	public void setRatePerUnit(Float ratePerUnit) {
		this.ratePerUnit = ratePerUnit;
	}

	public Double getTotalValue() {
		return totalValue;
	}

	public void setTotalValue(Double totalValue) {
		this.totalValue = totalValue;
	}

	public Float getRateOfDuty() {
		return rateOfDuty;
	}

	public void setRateOfDuty(Float rateOfDuty) {
		this.rateOfDuty = rateOfDuty;
	}

	public Double getTotalDuty() {
		return totalDuty;
	}

	public void setTotalDuty(Double totalDuty) {
		this.totalDuty = totalDuty;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public Long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}

	public Double getTotalEduCess() {
		return totalEduCess;
	}

	public void setTotalEduCess(Double totalEduCess) {
		this.totalEduCess = totalEduCess;
	}

	public Double getTotalHigherEduCess() {
		return totalHigherEduCess;
	}

	public void setTotalHigherEduCess(Double totalHigherEduCess) {
		this.totalHigherEduCess = totalHigherEduCess;
	}

	public Double getTotalSalesTax() {
		return totalSalesTax;
	}

	public void setTotalSalesTax(Double totalSalesTax) {
		this.totalSalesTax = totalSalesTax;
	}

	public Double getTotalVat() {
		return totalVat;
	}

	public void setTotalVat(Double totalVat) {
		this.totalVat = totalVat;
	}

	public Double getTotalCst() {
		return totalCst;
	}

	public void setTotalCst(Double totalCst) {
		this.totalCst = totalCst;
	}

	public String getDeliveryChallanNo() {
		return deliveryChallanNo;
	}

	public void setDeliveryChallanNo(String deliveryChallanNo) {
		this.deliveryChallanNo = deliveryChallanNo;
	}

	public String getUnits() {
		return units;
	}

	public void setUnits(String units) {
		this.units = units;
	}

	public Timestamp getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Timestamp createdTime) {
		this.createdTime = createdTime;
	}

	public String getModeOfTransport() {
		return modeOfTransport;
	}

	public void setModeOfTransport(String modeOfTransport) {
		this.modeOfTransport = modeOfTransport;
	}



	public String getProductTypeKey() {
		return productTypeKey;
	}

	public void setProductTypeKey(String productTypeKey) {
		this.productTypeKey = productTypeKey;
	}

	public InvoiceItems getInvoiceItems() {

		InvoiceItems invoiceItems = new InvoiceItems();
		
		
		invoiceItems.setInvoiceId(invoiceId);
		invoiceItems.setAssortedItem(assortedItem);
		invoiceItems.setNoOfRolls(noOfRolls);
		invoiceItems.setTotalValue(totalValue);
		invoiceItems.setRatePerUnit(ratePerUnit);
		invoiceItems.setRateOfDuty(rateOfDuty);
		invoiceItems.setTotalDuty(totalDuty);
		invoiceItems.setTotalEduCess(totalEduCess);
		invoiceItems.setTotalHigherEduCess(totalHigherEduCess);
		invoiceItems.setProductTypeKey(productTypeKey);
		invoiceItems.setTotalVat(totalVat);
		invoiceItems.setTotalCst(totalCst);
		invoiceItems.setUnits(units);
		invoiceItems.setTotalQuantity(totalQuantity);
		invoiceItems.setAmount(amount);

		Invoice invoice=new Invoice();
		invoice.setInvoiceNo(invoiceNo);
		if (invoiceDate != null && invoiceDate != "")
			invoice.setInvoiceDate(Utility.formDateFormatter.parseDateTime(
					invoiceDate).toDate());
		else
			invoice.setInvoiceDate(null);
		invoice.setCreatedTime(createdTime);
		Customer customer = new Customer();
		customer.setCustomerId(customerId);
		invoice.setCustomer(customer);
		invoice.setTransportDetails(transportDetails);
		invoice.setModeOfTransport(modeOfTransport);
		invoice.setDeliveryChallanNo(deliveryChallanNo);
		invoiceItems.setInvoice(invoice);
		return invoiceItems;
	}

}