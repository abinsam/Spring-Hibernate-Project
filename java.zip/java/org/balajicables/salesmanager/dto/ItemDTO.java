package org.balajicables.salesmanager.dto;

import java.io.Serializable;

import org.balajicables.salesmanager.model.Area;
import org.balajicables.salesmanager.model.CableStdPvc;
import org.balajicables.salesmanager.model.Colour;
import org.balajicables.salesmanager.model.CopperDiameter;
import org.balajicables.salesmanager.model.Item;
import org.balajicables.salesmanager.model.ProductType;
import org.balajicables.salesmanager.model.Unit;

public class ItemDTO implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private long itemId;
	private String itemCode;
	private Integer numberOfCopperStrand;
	private String copperKey;
	private String outerDiameter;
    private String odLabel;
    private String mainColorKey;
    private String innerColorKey;
    private String productTypeKey;
    private String cableStdKey;
    private Integer layLength;
    private String layType;
    private String itemDescription;
    private String itemLabel;
    private String specificDetails;
    private String areaValue;
    private String area;
    private String itemType;
    private String assortedType;
    private String inputSize;
    private Integer unitId;
    private String mainColourItem;
	private String innerColourItem;
    private Double weight;
    private Double pvcWeight;
    private Long mainOrderSequence;
	private Long stripeOrderSequence;
	public Integer getUnitId() {
		return unitId;
	}

	public void setUnitId(Integer unitId) {
		this.unitId = unitId;
	}

	public String getAssortedType() {
		return assortedType;
	}

	public void setAssortedType(String assortedType) {
		this.assortedType = assortedType;
	}

	public String getInputSize() {
		return inputSize;
	}

	public void setInputSize(String inputSize) {
		this.inputSize = inputSize;
	}

	public long getItemId() {
		return itemId;
	}

	public void setItemId(long itemId) {
		this.itemId = itemId;
	}

	public String getItemCode() {
		return itemCode;
	}

	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}

	public Integer getNumberOfCopperStrand() {
		return numberOfCopperStrand;
	}

	public void setNumberOfCopperStrand(Integer numberOfCopperStrand) {
		this.numberOfCopperStrand = numberOfCopperStrand;
	}

	public String getCopperKey() {
		return copperKey;
	}

	public void setCopperKey(String copperKey) {
		this.copperKey = copperKey;
	}

	public String getOuterDiameter() {
		return outerDiameter;
	}

	public void setOuterDiameter(String outerDiameter) {
		this.outerDiameter = outerDiameter;
	}

	public String getOdLabel() {
		return odLabel;
	}

	public void setOdLabel(String odLabel) {
		this.odLabel = odLabel;
	}

	public String getMainColorKey() {
		return mainColorKey;
	}

	public void setMainColorKey(String mainColorKey) {
		this.mainColorKey = mainColorKey;
	}

	public String getInnerColorKey() {
		return innerColorKey;
	}

	public void setInnerColorKey(String innerColorKey) {
		this.innerColorKey = innerColorKey;
	}

	public String getProductTypeKey() {
		return productTypeKey;
	}

	public void setProductTypeKey(String productTypeKey) {
		this.productTypeKey = productTypeKey;
	}

	public String getCableStdKey() {
		return cableStdKey;
	}

	public void setCableStdKey(String cableStdKey) {
		this.cableStdKey = cableStdKey;
	}

	public Integer getLayLength() {
		return layLength;
	}

	public void setLayLength(Integer layLength) {
		this.layLength = layLength;
	}

	public String getLayType() {
		return layType;
	}

	public void setLayType(String layType) {
		this.layType = layType;
	}

	public String getItemDescription() {
		return itemDescription;
	}

	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}

	public String getItemLabel() {
		return itemLabel;
	}

	public void setItemLabel(String itemLabel) {
		this.itemLabel = itemLabel;
	}

	public String getSpecificDetails() {
		return specificDetails;
	}

	public void setSpecificDetails(String specificDetails) {
		this.specificDetails = specificDetails;
	}


	public String getAreaValue() {
		return areaValue;
	}

	public void setAreaValue(String areaValue) {
		this.areaValue = areaValue;
	}

	public String getItemType() {
		return itemType;
	}

	public void setItemType(String itemType) {
		this.itemType = itemType;
	}
	
	public Double getWeight() {
		return weight;
	}

	public void setWeight(Double weight) {
		this.weight = weight;
	}

	public Double getPvcWeight() {
		return pvcWeight;
	}

	public void setPvcWeight(Double pvcWeight) {
		this.pvcWeight = pvcWeight;
	}
	
	

	

	public Long getMainOrderSequence() {
		return mainOrderSequence;
	}

	public void setMainOrderSequence(Long mainOrderSequence) {
		this.mainOrderSequence = mainOrderSequence;
	}

	public Long getStripeOrderSequence() {
		return stripeOrderSequence;
	}

	public void setStripeOrderSequence(Long stripeOrderSequence) {
		this.stripeOrderSequence = stripeOrderSequence;
	}

	public String getMainColourItem() {
		return mainColourItem;
	}

	public void setMainColourItem(String mainColourItem) {
		this.mainColourItem = mainColourItem;
	}

	public String getInnerColourItem() {
		return innerColourItem;
	}

	public void setInnerColourItem(String innerColourItem) {
		this.innerColourItem = innerColourItem;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public Item getItem() {
		Item itemObj = new Item();
		
		     itemObj.setItemCode(itemCode);
		     itemObj.setNumberOfCopperStrands(numberOfCopperStrand);
		     itemObj.setOuterDiameter(outerDiameter);
		     itemObj.setOdLabel(odLabel);
		     itemObj.setLayLength(layLength);
		     itemObj.setLayType(layType);
		     itemObj.setItemDescription(itemDescription);
		     itemObj.setItemLabel(itemLabel);
             itemObj.setSpecificDetails(specificDetails);
             Area areaObj=new Area();
             areaObj.setAreaValue(areaValue);
             areaObj.setArea(area);
          CopperDiameter copper=new CopperDiameter();
                   
          copper.setCopperkey(copperKey);
          itemObj.setCopperStrandDiameter(copper);
          itemObj.setArea(areaObj);
           CableStdPvc cableStd=new CableStdPvc();
          cableStd.setCableStdKey(cableStdKey) ;
            itemObj.setCableStdPvc(cableStd);
                  Colour color=new Colour();
         color.setColorKey(mainColorKey);
         color.setColor(mainColourItem);
         color.setOrderSequence(mainOrderSequence);
          itemObj.setMainColour(color);
      
        Colour innercolor=new Colour();
         innercolor.setColorKey(innerColorKey);
         innercolor.setColor(innerColourItem);
         innercolor.setOrderSequence(stripeOrderSequence);
         itemObj.setInnerColour(innercolor);
            
          ProductType product=new ProductType();
          product.setProductKey(productTypeKey);
          
          Unit unit =new Unit();
          unit.setUnitId(unitId);
          itemObj.setUnit(unit);
          itemObj.setProductType(product);
		  itemObj.setItemType(itemType);
		  itemObj.setAssortedType(assortedType);
		  itemObj.setInputSize(inputSize);
		  itemObj.setCopperWeight(weight);
		  itemObj.setPvcWeight(pvcWeight);
			return itemObj;
		}

	
}
	