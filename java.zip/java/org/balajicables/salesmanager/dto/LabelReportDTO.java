package org.balajicables.salesmanager.dto;

import java.io.Serializable;
import org.balajicables.salesmanager.model.Customer;
import org.balajicables.salesmanager.model.LabelReport;
import org.balajicables.salesmanager.model.WorkOrderItems;

public class LabelReportDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long labelReportId;
	private Long workOrderItemId;
	private String itemDescription;
	private String salesOrderNo;
	private String poNo;
	private Long customerId;
	private String workOrderNo;
	private String batchNo;
	private Integer qtyPerCoil;
	private Double totalQuantity;
	private String cableStd;
	private String area ;
	private String partNo;
	private String bundleId;
	
	
	
	
	
    public Long getLabelReportId() {
		return labelReportId;
	}
	public void setLabelReportId(Long labelReportId) {
		this.labelReportId = labelReportId;
	}

	public Long getWorkOrderItemId() {
		return workOrderItemId;
	}

	public void setWorkOrderItemId(Long workOrderItemId) {
		this.workOrderItemId = workOrderItemId;
	}
	public String getItemDescription() {
		return itemDescription;
	}

	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}
	public String getSalesOrderNo() {
		return salesOrderNo;
	}

	public void setSalesOrderNo(String salesOrderNo) {
		this.salesOrderNo = salesOrderNo;
	}

    public String getPoNo() {
		return poNo;
	}
	public void setPoNo(String poNo) {
		this.poNo = poNo;
	}
   public Long getCustomerId() {
		return customerId;
	}
	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}

	public String getWorkOrderNo() {
		return workOrderNo;
	}
	public void setWorkOrderNo(String workOrderNo) {
		this.workOrderNo = workOrderNo;
	}
	public String getBatchNo() {
		return batchNo;
	}

	public void setBatchNo(String batchNo) {
		this.batchNo = batchNo;
	}

	public Integer getQtyPerCoil() {
		return qtyPerCoil;
	}
	public void setQtyPerCoil(Integer qtyPerCoil) {
		this.qtyPerCoil = qtyPerCoil;
	}
	public Double getTotalQuantity() {
		return totalQuantity;
	}

	public void setTotalQuantity(Double totalQuantity) {
		this.totalQuantity = totalQuantity;
	}
	public String getCableStd() {
		return cableStd;
	}

	public void setCableStd(String cableStd) {
		this.cableStd = cableStd;
	}

	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

    public String getPartNo() {
		return partNo;
	}
	public void setPartNo(String partNo) {
		this.partNo = partNo;
	}
	
public String getBundleId() {
		return bundleId;
	}
	public void setBundleId(String bundleId) {
		this.bundleId = bundleId;
	}
public LabelReport getLabelReport() {
	LabelReport labelReport = new LabelReport();
	labelReport.setLabelReportId(labelReportId);
	
	WorkOrderItems workOrderItems = new WorkOrderItems();
	workOrderItems.setWorkOrderItemId(workOrderItemId);
	labelReport.setWorkOrderItems(workOrderItems);
	
	
	labelReport.setItemDescription(itemDescription);
	labelReport.setSalesOrderNo(salesOrderNo);
	labelReport.setPoNo(poNo);
	
	Customer customer = new Customer();
	customer.setCustomerId(customerId);
	labelReport.setCustomer(customer);
	
	
	labelReport.setWorkOrderNo(workOrderNo);
	labelReport.setBatchNo(batchNo);
	labelReport.setQtyPerCoil(qtyPerCoil);
	labelReport.setTotalQuantity(totalQuantity);
	labelReport.setCableStd(cableStd);
	labelReport.setArea(area) ;
	labelReport.setPartNo(partNo);
	labelReport.setBundleId(bundleId);
	
	return labelReport;
	}






}