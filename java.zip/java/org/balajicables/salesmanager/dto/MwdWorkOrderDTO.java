package org.balajicables.salesmanager.dto;

import java.io.Serializable;

import org.balajicables.salesmanager.model.Customer;
import org.balajicables.salesmanager.model.MwdWorkOrder;
import org.balajicables.salesmanager.model.ProductionWorkOrder;
import org.balajicables.salesmanager.model.SalesOrderItem;

public class MwdWorkOrderDTO implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private Long mwdWoInputId;
	private String workOrderNo;
	private  String size;
	private  Double netLength;
	private String anealingPercent;
    private String createdBy;
    private Long orderDetailId;
    private  Double totalQty;

	private String status;
	private String customerName;
	private String updatedBy;
	private String selectStatus;
	private String customerCode;
	public String getCustomerCode() {
		return customerCode;
	}


	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}


	public String getCreatedBy() {
		return createdBy;
	}


	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	


	public double getNetLength() {
		return netLength;
	}


	public void setNetLength(Double netLength) {
		this.netLength = netLength;
	}


	public String getAnealingPercent() {
		return anealingPercent;
	}


	public void setAnealingPercent(String anealingPercent) {
		this.anealingPercent = anealingPercent;
	}


	public String getUpdatedBy() {
		return updatedBy;
	}


	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}


	public Long getMwdWoInputId() {
		return mwdWoInputId;
	}


	public void setMwdWoInputId(Long mwdWoInputId) {
		this.mwdWoInputId = mwdWoInputId;
	}


	public String getWorkOrderNo() {
		return workOrderNo;
	}


	public void setWorkOrderNo(String workOrderNo) {
		this.workOrderNo = workOrderNo;
	}


	public String getSize() {
		return size;
	}


	public void setSize(String size) {
		this.size = size;
	}



	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}



	public String getCustomerName() {
		return customerName;
	}


	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}


	public static long getSerialversionuid() {
		return serialVersionUID;
	}


	public Long getOrderDetailId() {
		return orderDetailId;
	}


	public void setOrderDetailId(Long orderDetailId) {
		this.orderDetailId = orderDetailId;
	}


	public Double getTotalQty() {
		return totalQty;
	}


	public void setTotalQty(Double totalQty) {
		this.totalQty = totalQty;
	}


	public String getSelectStatus() {
		return selectStatus;
	}


	public void setSelectStatus(String selectStatus) {
		this.selectStatus = selectStatus;
	}


	public MwdWorkOrder getMwdWorkerOrder() {
	       
		MwdWorkOrder mwdWorkerOrder = new MwdWorkOrder();
		mwdWorkerOrder.setMwdWoInputId(mwdWoInputId);
		Customer customer = new Customer();
		customer.setCustomerCode(customerCode);
		ProductionWorkOrder pdnWO= new ProductionWorkOrder();
		pdnWO.setWorkOrderNo(workOrderNo);
		SalesOrderItem soItem=new SalesOrderItem();
		soItem.setOrderDetailId(orderDetailId);
		mwdWorkerOrder.setSalesOrderItem(soItem);
		mwdWorkerOrder.setProductionWorkOrder(pdnWO);
		mwdWorkerOrder.setNetLength(netLength);
		
		mwdWorkerOrder.setSize(size);
		mwdWorkerOrder.setAnealingPercent(anealingPercent);
		mwdWorkerOrder.setTotalQty(totalQty);
		mwdWorkerOrder.setStatus(status);
		mwdWorkerOrder.setCustomerName(customerName);
		
		mwdWorkerOrder.setUpdatedBy(updatedBy);
		mwdWorkerOrder.setCreatedBy(createdBy);
		mwdWorkerOrder.setSelectStatus(selectStatus);
		return mwdWorkerOrder;
	}


}
