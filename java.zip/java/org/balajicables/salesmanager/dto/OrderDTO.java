package org.balajicables.salesmanager.dto;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import org.balajicables.salesmanager.model.Customer;
import org.balajicables.salesmanager.model.OrderStatus;
import org.balajicables.salesmanager.model.SalesOrder;
import org.balajicables.salesmanager.utils.Utility;



public class OrderDTO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String orderId;
	private Long customerId;
    private String customerName;
	private String orderRecDate;
	private String orderDeliveryDate;
	private String orderAcceptanceDate;
	private String poDetails;
	private String modeOfReceipt;
	private String status;
    private Integer orderStatusId;	
    private String createdTime ;
    private String targetDate;
    private String createdBy;
    private String updatedBy;
    private String updatedTime;
    private Double inputQuantity;
    private Double outputQuantity;
    private String mailStatus;
    private String lmeDetails;
    private String customerCode;
    
    
	public String getCustomerCode() {
		return customerCode;
	}

	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}

	public String getMailStatus() {
	return mailStatus;
     }

    public void setMailStatus(String mailStatus) {
	this.mailStatus = mailStatus;
    }
    
	public Double getOutputQuantity() {
		return outputQuantity;
	}

	public void setOutputQuantity(Double outputQuantity) {
		this.outputQuantity = outputQuantity;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getCreatedBy() {
		return createdBy;
	}


	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public OrderDTO(){
		super();
	}

    public String getOrderId() {
		return orderId;
	}

    public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public Long getCustomerId() {
		return customerId;
	}




	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}


	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getOrderRecDate() {
		return orderRecDate;
	}

	public void setOrderRecDate(String orderRecDate) {
		this.orderRecDate = orderRecDate;
	}

	public String getOrderDeliveryDate() {
		return orderDeliveryDate;
	}

	public void setOrderDeliveryDate(String orderDeliveryDate) {
		this.orderDeliveryDate = orderDeliveryDate;
	}

	public String getOrderAcceptanceDate() {
		return orderAcceptanceDate;
	}

	public void setOrderAcceptanceDate(String orderAcceptanceDate) {
		this.orderAcceptanceDate = orderAcceptanceDate;
	}

	public String getPoDetails() {
		return poDetails;
	}

	public void setPoDetails(String poDetails) {
		this.poDetails = poDetails;
	}

	public String getModeOfReceipt() {
		return modeOfReceipt;
	}

	public void setModeOfReceipt(String modeOfReceipt) {
		this.modeOfReceipt = modeOfReceipt;
	}

	public String getStatus() {
		return status;
	}




	public void setStatus(String status) {
		this.status = status;
	}








public Integer getOrderStatusId() {
		return orderStatusId;
	}




	public void setOrderStatusId(Integer orderStatusId) {
		this.orderStatusId = orderStatusId;
	}




public String getCreatedTime() {
		return createdTime;
	}




	public String getLmeDetails() {
	return lmeDetails;
}




public void setLmeDetails(String lmeDetails) {
	this.lmeDetails = lmeDetails;
}




	public void setCreatedTime(String createdTime) {
		this.createdTime = createdTime;
	}

    public String getTargetDate() {
		return targetDate;
	}
	public void setTargetDate(String targetDate) {
		this.targetDate = targetDate;
	}


public SalesOrder getOrder() {
	SalesOrder order = new SalesOrder();
		order.setOrderId(orderId);
		Customer customer = new Customer();
		customer.setCustomerName(customerName);
		customer.setCustomerId(customerId);
		customer.setCustomerCode(customerCode);
		order.setCustomer(customer)	;
		order.setModeOfReceipt(modeOfReceipt);
		order.setPoDetails(poDetails);
		order.setCreatedBy(createdBy);
		
		if(orderDeliveryDate!=null && orderDeliveryDate!="")
		order.setOrderDeliveryDate(Utility.formDateFormatter.parseDateTime(orderDeliveryDate).toDate());
		else
		order.setOrderDeliveryDate(null);
		
		
		if(orderAcceptanceDate!=null && orderAcceptanceDate!="")
		order.setOrderAcceptanceDate(Utility.formDateFormatter.parseDateTime(orderAcceptanceDate).toDate());
		else
			order.setOrderAcceptanceDate(null);
		if(orderRecDate!=null && orderRecDate!="")
		order.setOrderRecDate(Utility.formDateFormatter.parseDateTime(orderRecDate).toDate());
		else
		order.setOrderRecDate(null);
		if(targetDate!=null && targetDate!="")
			order.setTargetDate(Utility.formDateFormatter.parseDateTime(targetDate).toDate());
		else
			order.setTargetDate(null);
		
		OrderStatus orderStatus=new OrderStatus();
		orderStatus.setStatus(status);
		orderStatus.setOrderStatusId(orderStatusId);
		order.setOrderStatus(orderStatus);
		order.setInputQuantity(inputQuantity);
		//order.setOutputQuantity(outputQuantity);
		order.setMailStatus(mailStatus);
		order.setLmeDetails(lmeDetails);
if(createdTime!=null){

      SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
      java.util.Date parsedDate = null;
	  try {
		parsedDate = dateFormat.parse(createdTime);
	  } catch (ParseException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	 }
      java.sql.Timestamp timestamp = new java.sql.Timestamp(parsedDate.getTime());
		
		
		order.setCreatedTime(timestamp);
}		
if(updatedTime!=null){

	 SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
     java.util.Date parsedDate = null;
	  try {
		parsedDate = dateFormat.parse(updatedTime);
	  } catch (ParseException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	 }
    java.sql.Timestamp updatedTimestamp = new java.sql.Timestamp(parsedDate.getTime());
	order.setUpdatedTime(updatedTimestamp);
}		
		order.setCreatedBy(createdBy);
		order.setUpdatedBy(updatedBy);
		
		return order;
	}




public Double getInputQuantity() {
	return inputQuantity;
}




public void setInputQuantity(Double inputQuantity) {
	this.inputQuantity = inputQuantity;
}



/*
public Double getOutputQuantity() {
	return outputQuantity;
}




public void setOutputQuantity(Double outputQuantity) {
	this.outputQuantity = outputQuantity;
}*/




public String getUpdatedBy() {
	return updatedBy;
}




public void setUpdatedBy(String updatedBy) {
	this.updatedBy = updatedBy;
}




public String getUpdatedTime() {
	return updatedTime;
}




public void setUpdatedTime(String updatedTime) {
	this.updatedTime = updatedTime;
}





}