package org.balajicables.salesmanager.dto;

import java.io.Serializable;

import org.balajicables.salesmanager.model.DeliveryChallan;
import org.balajicables.salesmanager.model.PackingSlip;

public class PackingSlipDTO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * 
	 */
	private long itemId;
	private Integer packingSlipId;
    private  String deliveryChallanNo;
	private Double totalQuantity;
	private String inputSize;
	private String  packingSlipNo;
	private String itemCode;
	private Double weight;
	private Integer noOfRolls;
	private Double quanityPerRoll;
	private String units;
	private String unitType;

	public long getItemId() {
		return itemId;
	}
	public void setItemId(long itemId) {
		this.itemId = itemId;
	}
	
	
	public String getDeliveryChallanNo() {
		return deliveryChallanNo;
	}
	public void setDeliveryChallanNo(String deliveryChallanNo) {
		this.deliveryChallanNo = deliveryChallanNo;
	}
	public Double getTotalQuantity() {
		return totalQuantity;
	}
	public void setTotalQuantity(Double totalQuantity) {
		this.totalQuantity = totalQuantity;
	}
	
	public String getInputSize() {
		return inputSize;
	}
	public void setInputSize(String inputSize) {
		this.inputSize = inputSize;
	}
	public String getPackingSlipNo() {
		return packingSlipNo;
	}
	public void setPackingSlipNo(String packingSlipNo) {
		this.packingSlipNo = packingSlipNo;
	}
	public String getItemCode() {
		return itemCode;
	}
	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}
	public Double getWeight() {
		return weight;
	}
	public void setWeight(Double weight) {
		this.weight = weight;
	}
	public Integer getNoOfRolls() {
		return noOfRolls;
	}
	public void setNoOfRolls(Integer noOfRolls) {
		this.noOfRolls = noOfRolls;
	}
	public Double getQuanityPerRoll() {
		return quanityPerRoll;
	}
	public void setQuanityPerRoll(Double quanityPerRoll) {
		this.quanityPerRoll = quanityPerRoll;
	}
	public Integer getPackingSlipId() {
		return packingSlipId;
	}
	public void setPackingSlipId(Integer packingSlipId) {
		this.packingSlipId = packingSlipId;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
   public String getUnits() {
		return units;
	}
	public void setUnits(String units) {
		this.units = units;
	}
	
	
	
public String getUnitType() {
		return unitType;
	}
	public void setUnitType(String unitType) {
		this.unitType = unitType;
	}
public PackingSlip getPackingSlip(){
		
		PackingSlip packingSlip=new PackingSlip();
		packingSlip.setPackingSlipId(packingSlipId);
		packingSlip.setPackingSlipNo(packingSlipNo);
		DeliveryChallan dcObj=new DeliveryChallan();
		dcObj.setDeliveryChallanNo(deliveryChallanNo);
		
		packingSlip.setDeliveryChallan(dcObj);
		
		packingSlip.setNoOfRolls(noOfRolls);
		packingSlip.setQuanityPerRoll(quanityPerRoll);
		packingSlip.setTotalQuantity(totalQuantity);
		packingSlip.setWeight(weight);
		packingSlip.setInputSize(inputSize);
		packingSlip.setUnits(units);
		packingSlip.setUnitType(unitType);
		return packingSlip;
	
	}

	
}
