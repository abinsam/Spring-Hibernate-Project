package org.balajicables.salesmanager.dto;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import org.balajicables.salesmanager.model.MachineDetails;
import org.balajicables.salesmanager.model.ProductionProcess;
import org.balajicables.salesmanager.model.ProductionWorkOrder;
import org.balajicables.salesmanager.utils.Utility;


public class ProductionWorkOrderDTO implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private String workOrderNo;
	private Integer processId;
	private String processType;
	private Long machineNo;
	private  String startDate;
	private String startTime;
	private String endDate;
	private String endTime;
	private  String status;
	private String createdTime;
	private String createdBy;
	private Double inputWeight;
	private Double outputWeight;
	private Double balanceWeight;




	public String getCreatedBy() {
		return createdBy;
	}




	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}




	public String getWorkOrderNo() {
		return workOrderNo;
	}




	public void setWorkOrderNo(String workOrderNo) {
		this.workOrderNo = workOrderNo;
	}




	public Integer getProcessId() {
		return processId;
	}




	public void setProcessId(Integer processId) {
		this.processId = processId;
	}




	public String getProcessType() {
		return processType;
	}




	public void setProcessType(String processType) {
		this.processType = processType;
	}




	public Long getMachineNo() {
		return machineNo;
	}




	public void setMachineNo(Long machineNo) {
		this.machineNo = machineNo;
	}










	public String getStartDate() {
		return startDate;
	}




	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}




	public String getStartTime() {
		return startTime;
	}




	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}




	public String getEndDate() {
		return endDate;
	}




	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}




	public String getEndTime() {
		return endTime;
	}




	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}




	public String getStatus() {
		return status;
	}




	public void setStatus(String status) {
		this.status = status;
	}




	public String getCreatedTime() {
		return createdTime;
	}




	public void setCreatedTime(String createdTime) {
		this.createdTime = createdTime;
	}




	public static long getSerialversionuid() {
		return serialVersionUID;
	}




	public Double getInputWeight() {
		return inputWeight;
	}




	public void setInputWeight(Double inputWeight) {
		this.inputWeight = inputWeight;
	}




	public Double getOutputWeight() {
		return outputWeight;
	}




	public void setOutputWeight(Double outputWeight) {
		this.outputWeight = outputWeight;
	}




	public Double getBalanceWeight() {
		return balanceWeight;
	}




	public void setBalanceWeight(Double balanceWeight) {
		this.balanceWeight = balanceWeight;
	}




	public ProductionWorkOrder getPdnWorkOrder() {
		ProductionWorkOrder productionWorkOrder = new ProductionWorkOrder();
		productionWorkOrder.setWorkOrderNo(workOrderNo);
		productionWorkOrder.setStatus(status);
			
		//productionWorkOrder.setEndTime(endTime);
		//productionWorkOrder.setStartTime(startTime);
		
		MachineDetails machine =new MachineDetails();
		machine.setMachineNo(machineNo);
		productionWorkOrder.setMachine(machine);
	
		productionWorkOrder.setCreatedBy(createdBy);
		productionWorkOrder.setInputWeight(inputWeight);
		productionWorkOrder.setOutputWeight(outputWeight);
		productionWorkOrder.setBalanceWeight(balanceWeight);
		ProductionProcess process=new ProductionProcess();
		process.setProcessId(processId);
		productionWorkOrder.setProcess(process);
		
		  
		   if(startDate!=null & startDate!=""){
			   productionWorkOrder.setStartDate(Utility.formDateFormatter.parseDateTime(startDate).toDate()); 
		   }
		   else
			   productionWorkOrder.setStartDate(null);
		   if(endDate!=null & endDate!=""){
			   productionWorkOrder.setEndDate(Utility.formDateFormatter.parseDateTime(endDate).toDate()); 
		   }
		   else
			   productionWorkOrder.setEndDate(null);  
		   
			
		   if(createdTime!=null){

		         SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
		         java.util.Date parsedDate = null;
		   	  try {
		   		parsedDate = dateFormat.parse(createdTime);
		   	  } catch (ParseException e) {
		   		// TODO Auto-generated catch block
		   		e.printStackTrace();
		   	 }
		         java.sql.Timestamp timestamp = new java.sql.Timestamp(parsedDate.getTime());
		   		
		   		
		         productionWorkOrder.setCreatedTime(timestamp);
		   }		
		   	
			return productionWorkOrder;
	}
	
}	
	
		
	