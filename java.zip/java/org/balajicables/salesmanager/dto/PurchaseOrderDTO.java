package org.balajicables.salesmanager.dto;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import org.balajicables.salesmanager.model.Customer;
import org.balajicables.salesmanager.model.PurchaseOrder;
import org.balajicables.salesmanager.utils.Utility;

public class PurchaseOrderDTO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String poNo;
	private String poDate;
	private String poStatus;
	private String customerName;
	private Long customerId;
	private Double quantity;
	private Double  balanceQuantity;
	private String createdTime ;
	
	private String createdBy ;
	private String updatedBy ;
	private String updatedTime ;
	
	private Double totalPrice;
	private Double exciseDuty;
	private Double cstValue;
	private Double amount;

	private String mailSent ;
	private String customerCode;
	
    public String getCustomerCode() {
		return customerCode;
	}



	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}



	public PurchaseOrderDTO(){
		super();
	}



	public String getPoNo() {
		return poNo;
	}

	public void setPoNo(String poNo) {
		this.poNo = poNo;
	}


	public String getPoDate() {
		return poDate;
	}


	public void setPoDate(String poDate) {
		this.poDate = poDate;
	}

	public String getPoStatus() {
		return poStatus;
	}

	public void setPoStatus(String poStatus) {
		this.poStatus = poStatus;
	}
	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}


	public Long getCustomerId() {
		return customerId;
	}


	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}


public String getCreatedTime() {
	return createdTime;
}

public void setCreatedTime(String createdTime) {
	this.createdTime = createdTime;
}

public Double getQuantity() {
	return quantity;
}



public void setQuantity(Double quantity) {
	this.quantity = quantity;
}

public static long getSerialversionuid() {
	return serialVersionUID;
}


public Double getBalanceQuantity() {
	return balanceQuantity;
}



public void setBalanceQuantity(Double balanceQuantity) {
	this.balanceQuantity = balanceQuantity;
}



public String getCreatedBy() {
	return createdBy;
}



public void setCreatedBy(String createdBy) {
	this.createdBy = createdBy;
}



public String getUpdatedBy() {
	return updatedBy;
}



public void setUpdatedBy(String updatedBy) {
	this.updatedBy = updatedBy;
}



public String getUpdatedTime() {
	return updatedTime;
}



public void setUpdatedTime(String updatedTime) {
	this.updatedTime = updatedTime;
}



public Double getTotalPrice() {
	return totalPrice;
}



public void setTotalPrice(Double totalPrice) {
	this.totalPrice = totalPrice;
}



public Double getExciseDuty() {
	return exciseDuty;
}



public void setExciseDuty(Double exciseDuty) {
	this.exciseDuty = exciseDuty;
}



public Double getCstValue() {
	return cstValue;
}



public void setCstValue(Double cstValue) {
	this.cstValue = cstValue;
}



public Double getAmount() {
	return amount;
}



public void setAmount(Double amount) {
	this.amount = amount;
}



public String getMailSent() {
	return mailSent;
}



public void setMailSent(String mailSent) {
	this.mailSent = mailSent;
}



public PurchaseOrder getPurchaseOrder() {
	PurchaseOrder poOrder = new PurchaseOrder();
	
	poOrder.setPoNo(poNo);
	if(poDate!=null && poDate!="")
		poOrder.setPoDate(Utility.formDateFormatter.parseDateTime(poDate).toDate());
	 Customer customer = new Customer();
		customer.setCustomerName(customerName);
		customer.setCustomerId(customerId);
		customer.setCustomerCode(customerCode);
		poOrder.setCustomer(customer);
		poOrder.setPoStatus(poStatus);
		poOrder.setQuantity(quantity);
		poOrder.setBalanceQuantity(balanceQuantity);
		poOrder.setUpdatedBy(updatedBy);
		poOrder.setCreatedBy(createdBy);
		poOrder.setTotalPrice(totalPrice);
		poOrder.setExciseDuty(exciseDuty);
		poOrder.setCstValue(cstValue);
		poOrder.setAmount(amount);
		poOrder.setMailSent(mailSent);
if(createdTime!=null){

      SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
      java.util.Date parsedDate = null;
	  try {
		parsedDate = dateFormat.parse(createdTime);
	  } catch (ParseException e) {
		e.printStackTrace();
	 }
      java.sql.Timestamp timestamp = new java.sql.Timestamp(parsedDate.getTime());
		
		
      poOrder.setCreatedTime(timestamp);
    
}		
if(updatedTime!=null){
    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    java.util.Date parsedDate = null;
	  try {
		parsedDate = dateFormat.parse(updatedTime);
	  } catch (ParseException e) {
		e.printStackTrace();
	 }
    java.sql.Timestamp updatedTimestamp = new java.sql.Timestamp(parsedDate.getTime());
    poOrder.setUpdatedTime(updatedTimestamp);
  
}			
		
	return poOrder;
	}

}