package org.balajicables.salesmanager.dto;

import java.io.Serializable;

import org.balajicables.salesmanager.model.Customer;
import org.balajicables.salesmanager.model.Item;
import org.balajicables.salesmanager.model.PurchaseOrder;
import org.balajicables.salesmanager.model.PurchaseOrderItem;
import org.balajicables.salesmanager.model.Unit;
import org.balajicables.salesmanager.utils.Utility;


public class PurchaseOrderItemDTO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long purchaseOrderItemId;
	private String poNo;
	private String poDate;
	private Long itemId;
	private String itemCode;
	private String description;
	private Float rate;
	private Double quantity;
	private Double balanceQty;
	private Double price;
    private String poStatus;
    private String customerName;
	private Long customerId;
	private int status;
	private String unit;
    
	 
	public Double getBalanceQty() {
		return balanceQty;
	}


	public void setBalanceQty(Double balanceQty) {
		this.balanceQty = balanceQty;
	}

	public int getStatus() {
		return status;
	}


	public void setStatus(int status) {
		this.status = status;
	}


	public String getPoNo() {
		return poNo;
	}


	public void setPoNo(String poNo) {
		this.poNo = poNo;
	}


	public Long getItemId() {
		return itemId;
	}


	public void setItemId(Long itemId) {
		this.itemId = itemId;
	}


	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}


	public Float getRate() {
		return rate;
	}


	public void setRate(Float rate) {
		this.rate = rate;
	}


	public Double getQuantity() {
		return quantity;
	}


	public void setQuantity(Double quantity) {
		this.quantity = quantity;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}
	 public String getCustomerName() {
			return customerName;
		}

		public void setCustomerName(String customerName) {
			this.customerName = customerName;
		}

		public Long getCustomerId() {
			return customerId;
		}

		public void setCustomerId(Long customerId) {
			this.customerId = customerId;
		}
		public String getPoDate() {
			return poDate;
		}

		public void setPoDate(String poDate) {
			this.poDate = poDate;
		}
	 public String getPoStatus() {
		return poStatus;
	}

	 public void setPoStatus(String poStatus) {
		this.poStatus = poStatus;
	}
		public Long getPurchaseOrderItemId() {
			return purchaseOrderItemId;
		}


		public void setPurchaseOrderItemId(Long purchaseOrderItemId) {
			this.purchaseOrderItemId = purchaseOrderItemId;
		}

	
	
	public String getUnit() {
			return unit;
		}


		public void setUnit(String unit) {
			this.unit = unit;
		}


	public PurchaseOrderItem getPoItem() {
	PurchaseOrderItem poItemDetail = new PurchaseOrderItem();
	poItemDetail.setPurchaseOrderItemId(purchaseOrderItemId);
	poItemDetail.setDescription(description);
	Item itemobj=new Item();
	itemobj.setItemId(itemId);
	itemobj.setItemCode(itemCode);
	itemobj.setItemDescription(description);
	
	Unit unitObj=new Unit();
	unitObj.setUnits(unit);
	itemobj.setUnit(unitObj);
	
	
	poItemDetail.setItem(itemobj);
	poItemDetail.setRate(rate);
	poItemDetail.setQuantity(quantity);
	poItemDetail.setPrice(price);
	poItemDetail.setStatus(status);
	
	poItemDetail.setBalanceQty(balanceQty);
	PurchaseOrder poOrder=new PurchaseOrder();
	       Customer customer = new Customer();
			customer.setCustomerName(customerName);
			customer.setCustomerId(customerId);
		
			poOrder.setCustomer(customer);
		
	    poOrder.setPoNo(poNo);
	   	poOrder.setPoStatus(poStatus);
	    if(poDate!=null && poDate!="")
			poOrder.setPoDate(Utility.formDateFormatter.parseDateTime(poDate).toDate());
			else
			poOrder.setPoDate(null);
	
	    poItemDetail.setPurchaseOrder(poOrder);
        
		return poItemDetail;
	}


	public String getItemCode() {
		return itemCode;
	}


	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}





}