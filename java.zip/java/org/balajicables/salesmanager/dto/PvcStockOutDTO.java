package org.balajicables.salesmanager.dto;

import java.io.Serializable;

import org.balajicables.salesmanager.model.Item;
import org.balajicables.salesmanager.model.ProductionWorkOrder;
import org.balajicables.salesmanager.model.PvcStockOut;



public class PvcStockOutDTO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * 
	 */
	private Long pvcStockOutId;
	private String workOrderNo;
	private  Double quantity;
	private  String batch;
	private  String itemDescription;
	private Long itemId;
	
	
	public Long getPvcStockOutId() {
		return pvcStockOutId;
	}


	public void setPvcStockOutId(Long pvcStockOutId) {
		this.pvcStockOutId = pvcStockOutId;
	}


	public String getWorkOrderNo() {
		return workOrderNo;
	}


	public void setWorkOrderNo(String workOrderNo) {
		this.workOrderNo = workOrderNo;
	}


	public Double getQuantity() {
		return quantity;
	}


	public void setQuantity(Double quantity) {
		this.quantity = quantity;
	}


	public String getBatch() {
		return batch;
	}


	public void setBatch(String batch) {
		this.batch = batch;
	}


	public static long getSerialversionuid() {
		return serialVersionUID;
	}


	public String getItemDescription() {
		return itemDescription;
	}


	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}


	public Long getItemId() {
		return itemId;
	}


	public void setItemId(Long itemId) {
		this.itemId = itemId;
	}


	public PvcStockOut getPvcStockOut() {
		
		PvcStockOut pvcStockOut = new PvcStockOut();
		pvcStockOut.setPvcStockOutID(pvcStockOutId);
		pvcStockOut.setBatch(batch);
		pvcStockOut.setQuantity(quantity);
		ProductionWorkOrder pdnWo=new ProductionWorkOrder();
		pdnWo.setWorkOrderNo(workOrderNo);
		pvcStockOut.setProductionWorkOrder(pdnWo);
		Item itemObj=new Item();
		itemObj.setItemId(itemId);
		//itemObj.setItemDescription(itemDescription);
		pvcStockOut.setItem(itemObj);
		
		return pvcStockOut;
	}


}