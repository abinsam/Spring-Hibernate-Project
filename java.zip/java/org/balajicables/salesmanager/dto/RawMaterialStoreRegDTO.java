package org.balajicables.salesmanager.dto;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import org.balajicables.salesmanager.model.PurchaseOrder;
import org.balajicables.salesmanager.model.PurchaseOrderItem;
import org.balajicables.salesmanager.model.RawMaterialStoreReg;
import org.balajicables.salesmanager.model.Store;

public class RawMaterialStoreRegDTO implements Serializable {
	
	private static final long serialVersionUID = 1L;
	

	
	private Long rwStoreRegId;
	private Integer storeId;
	private Long purchaseOrderItemId;
	private String supervisorName;
	private String dateTime;
	private  String qcStatus;
	private  Double grossWeight;
	private  Double netWeight;
	private  Double tareWeight;
	private String customerCode;
	private String customerName;
	private String itemCode;
	private String itemDescription;
	private String sendToRbd;
	private String batchNo;
	private int noOfBags;
	private double totalQty;
	private double balanceQty;
    private String units;
    private String poNo;
    private Double quantity;
    private String stockInStatus;
    private  Double stockOutQty;
   
    
    private String qcSupervisor;
    private String rejectStatus;
    private String poStatus;
    private String remarks;
    
    
public Double getQuantity() {
		return quantity;
	}



	public void setQuantity(Double quantity) {
		this.quantity = quantity;
	}





	public String getPoNo() {
		return poNo;
	}



	public void setPoNo(String poNo) {
		this.poNo = poNo;
	}



	public static long getSerialversionuid() {
		return serialVersionUID;
	}



public double getBalanceQty() {
		return balanceQty;
	}



	public void setBalanceQty(double balanceQty) {
		this.balanceQty = balanceQty;
	}



public String getBatchNo() {
		return batchNo;
	}



	public void setBatchNo(String batchNo) {
		this.batchNo = batchNo;
	}



	public int getNoOfBags() {
		return noOfBags;
	}



	public void setNoOfBags(int noOfBags) {
		this.noOfBags = noOfBags;
	}



	public double getTotalQty() {
		return totalQty;
	}



	public void setTotalQty(double totalQty) {
		this.totalQty = totalQty;
	}



public String getSendToRbd() {
		return sendToRbd;
	}



	public void setSendToRbd(String sendToRbd) {
		this.sendToRbd = sendToRbd;
	}



public Long getRwStoreRegId() {
		return rwStoreRegId;
	}



	public void setRwStoreRegId(Long rwStoreRegId) {
		this.rwStoreRegId = rwStoreRegId;
	}



	public Integer getStoreId() {
		return storeId;
	}



	public void setStoreId(Integer storeId) {
		this.storeId = storeId;
	}



	public Long getPurchaseOrderItemId() {
		return purchaseOrderItemId;
	}



	public void setPurchaseOrderItemId(Long purchaseOrderItemId) {
		this.purchaseOrderItemId = purchaseOrderItemId;
	}



	public String getSupervisorName() {
		return supervisorName;
	}



	public void setSupervisorName(String supervisorName) {
		this.supervisorName = supervisorName;
	}



	public String getDateTime() {
		return dateTime;
	}



	public void setDateTime(String dateTime) {
		this.dateTime = dateTime;
	}



	public String getQcStatus() {
		return qcStatus;
	}



	public void setQcStatus(String qcStatus) {
		this.qcStatus = qcStatus;
	}



	public Double getGrossWeight() {
		return grossWeight;
	}



	public void setGrossWeight(Double grossWeight) {
		this.grossWeight = grossWeight;
	}



	public Double getNetWeight() {
		return netWeight;
	}



	public void setNetWeight(Double netWeight) {
		this.netWeight = netWeight;
	}



	public Double getTareWeight() {
		return tareWeight;
	}



	public void setTareWeight(Double tareWeight) {
		this.tareWeight = tareWeight;
	}


public String getCustomerCode() {
		return customerCode;
	}



	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}

	public String getCustomerName() {
		return customerName;
	}



	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	
	public String getItemCode() {
		return itemCode;
	}



	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}

	public String getItemDescription() {
		return itemDescription;
	}



	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}

public String getUnits() {
		return units;
	}



	public void setUnits(String units) {
		this.units = units;
	}



public String getStockInStatus() {
		return stockInStatus;
	}



	public void setStockInStatus(String stockInStatus) {
		this.stockInStatus = stockInStatus;
	}



public Double getStockOutQty() {
		return stockOutQty;
	}



	public void setStockOutQty(Double stockOutQty) {
		this.stockOutQty = stockOutQty;
	}



public String getQcSupervisor() {
		return qcSupervisor;
	}



	public void setQcSupervisor(String qcSupervisor) {
		this.qcSupervisor = qcSupervisor;
	}



	public String getRejectStatus() {
		return rejectStatus;
	}



	public void setRejectStatus(String rejectStatus) {
		this.rejectStatus = rejectStatus;
	}



	public String getPoStatus() {
		return poStatus;
	}



	public void setPoStatus(String poStatus) {
		this.poStatus = poStatus;
	}



public String getRemarks() {
		return remarks;
	}



	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}



public RawMaterialStoreReg getRawMaterialStoreReg() {
	RawMaterialStoreReg rawMaterialStoreReg=new RawMaterialStoreReg();
	Store storeObj=new Store();
	storeObj.setStoreId(storeId);
    rawMaterialStoreReg.setRwStoreRegId(rwStoreRegId);
    rawMaterialStoreReg.setStore(storeObj);
    
    PurchaseOrderItem purchaseOrderItem=new PurchaseOrderItem();
    purchaseOrderItem.setPurchaseOrderItemId(purchaseOrderItemId);
    PurchaseOrder purchaseOrder = new PurchaseOrder();
    purchaseOrder.setPoNo(poNo);
    purchaseOrder.setPoStatus(poStatus);
     purchaseOrderItem.setPurchaseOrder(purchaseOrder);
    rawMaterialStoreReg.setPurchaseOrderItem(purchaseOrderItem);
    
    
   	if(dateTime!=null){

	      SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss.SSS");
	      java.util.Date parsedDate = null;
		  try {
			parsedDate = dateFormat.parse(dateTime);
		  } catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		 }
	      java.sql.Timestamp timestamp = new java.sql.Timestamp(parsedDate.getTime());
	      rawMaterialStoreReg.setDateTime(timestamp);
	}	
	
	rawMaterialStoreReg.setQcStatus(qcStatus);
	rawMaterialStoreReg.setGrossWeight(grossWeight);
	rawMaterialStoreReg.setTareWeight(tareWeight);
	rawMaterialStoreReg.setNetWeight(netWeight);
	rawMaterialStoreReg.setBatchNo(batchNo);
	rawMaterialStoreReg.setNoOfBags(noOfBags);
	rawMaterialStoreReg.setTotalQty(totalQty);
	rawMaterialStoreReg.setSupervisor(supervisorName);
	rawMaterialStoreReg.setSendToRbd(sendToRbd);
	rawMaterialStoreReg.setStockInStatus(stockInStatus);
	rawMaterialStoreReg.setStockOutQty(stockOutQty);
	rawMaterialStoreReg.setRejectStatus(rejectStatus);
	rawMaterialStoreReg.setQcSupervisor(qcSupervisor);
	rawMaterialStoreReg.setRemarks(remarks);
	return rawMaterialStoreReg;
	}











}