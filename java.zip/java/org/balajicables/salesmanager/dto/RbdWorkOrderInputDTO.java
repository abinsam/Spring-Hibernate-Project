package org.balajicables.salesmanager.dto;

import java.io.Serializable;
import org.balajicables.salesmanager.model.Customer;
import org.balajicables.salesmanager.model.Item;
import org.balajicables.salesmanager.model.ProductionWorkOrder;
import org.balajicables.salesmanager.model.PurchaseOrder;
import org.balajicables.salesmanager.model.PurchaseOrderItem;
import org.balajicables.salesmanager.model.RawMaterialStoreReg;
import org.balajicables.salesmanager.model.RbdWorkOrderInput;
import org.balajicables.salesmanager.model.Unit;


public class RbdWorkOrderInputDTO implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private Long rbdWoInputId;
	private String workOrderNo;
	private Long rwStoreRegId;
	private  Double grossWeight;
	private  Double netWeight;
	private  Double tareWeight;
	private String customerCode;
	private String customerName;
	private String itemCode;
	private String itemDescription;
	
	private String batchNo;
	private int noOfBags;
	private double qtyPerBag;
	private double totalQty;
	
	private String units;
	
	

	public String getBatchNo() {
		return batchNo;
	}


	public void setBatchNo(String batchNo) {
		this.batchNo = batchNo;
	}


	public int getNoOfBags() {
		return noOfBags;
	}


	public void setNoOfBags(int noOfBags) {
		this.noOfBags = noOfBags;
	}


	public double getQtyPerBag() {
		return qtyPerBag;
	}


	public void setQtyPerBag(double qtyPerBag) {
		this.qtyPerBag = qtyPerBag;
	}


	public double getTotalQty() {
		return totalQty;
	}


	public void setTotalQty(double totalQty) {
		this.totalQty = totalQty;
	}


	public String getItemCode() {
		return itemCode;
	}


	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}


	public String getItemDescription() {
		return itemDescription;
	}


	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}


	public String getCustomerCode() {
		return customerCode;
	}


	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}


	public String getCustomerName() {
		return customerName;
	}


	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}


	public Long getRbdWoInputId() {
		return rbdWoInputId;
	}


	public void setRbdWoInputId(Long rbdWoInputId) {
		this.rbdWoInputId = rbdWoInputId;
	}


	public String getWorkOrderNo() {
		return workOrderNo;
	}


	public void setWorkOrderNo(String workOrderNo) {
		this.workOrderNo = workOrderNo;
	}


	public Long getRwStoreRegId() {
		return rwStoreRegId;
	}


	public void setRwStoreRegId(Long rwStoreRegId) {
		this.rwStoreRegId = rwStoreRegId;
	}


	public Double getGrossWeight() {
		return grossWeight;
	}


	public void setGrossWeight(Double grossWeight) {
		this.grossWeight = grossWeight;
	}


	public Double getNetWeight() {
		return netWeight;
	}


	public void setNetWeight(Double netWeight) {
		this.netWeight = netWeight;
	}


	public Double getTareWeight() {
		return tareWeight;
	}


	public void setTareWeight(Double tareWeight) {
		this.tareWeight = tareWeight;
	}


	public static long getSerialversionuid() {
		return serialVersionUID;
	}


	public String getUnits() {
		return units;
	}


	public void setUnits(String units) {
		this.units = units;
	}


	public RbdWorkOrderInput getRbdWorkOrderInput() {
		RbdWorkOrderInput rbdWorkOrderInput = new RbdWorkOrderInput();
		rbdWorkOrderInput.setRbdWoInputId(rbdWoInputId);
		
		ProductionWorkOrder productionWorkOrder= new ProductionWorkOrder();
		productionWorkOrder.setWorkOrderNo(workOrderNo);
		rbdWorkOrderInput.setProductionWorkOrder(productionWorkOrder);
		
		RawMaterialStoreReg rawMaterialStoreReg=new RawMaterialStoreReg();
		rawMaterialStoreReg.setRwStoreRegId(rwStoreRegId);
		PurchaseOrder purchaseOrder=new PurchaseOrder();
		Customer customer=new Customer();
		customer.setCustomerName(customerName);
		customer.setCustomerCode(customerCode);
		purchaseOrder.setCustomer(customer);
		PurchaseOrderItem poItem=new PurchaseOrderItem();
		Item item=new Item();
		item.setItemCode(itemCode);
		item.setItemDescription(itemDescription);
		Unit unitObj=new Unit();
		unitObj.setUnits(units);
		item.setUnit(unitObj);
		poItem.setItem(item);
		rawMaterialStoreReg.setPurchaseOrderItem(poItem);
		rawMaterialStoreReg.setBatchNo(batchNo);
		rawMaterialStoreReg.setNoOfBags(noOfBags);
		rawMaterialStoreReg.setTotalQty(totalQty);
		
		
		rbdWorkOrderInput.setRawMaterialStoreReg(rawMaterialStoreReg);
		
		rbdWorkOrderInput.setGrossWeight(grossWeight);
		rbdWorkOrderInput.setNetWeight(netWeight);
		rbdWorkOrderInput.setTareWeight(tareWeight);
		
		
		return rbdWorkOrderInput;
	}
	
}	
	
		
	