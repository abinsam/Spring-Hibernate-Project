package org.balajicables.salesmanager.dto;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.balajicables.salesmanager.model.Area;
import org.balajicables.salesmanager.model.CableStdPvc;
import org.balajicables.salesmanager.model.Colour;
import org.balajicables.salesmanager.model.CopperDiameter;
import org.balajicables.salesmanager.model.Customer;
import org.balajicables.salesmanager.model.Item;
import org.balajicables.salesmanager.model.OrderStatus;
import org.balajicables.salesmanager.model.ProductType;
import org.balajicables.salesmanager.model.SalesOrder;
import org.balajicables.salesmanager.model.SalesOrderItem;
import org.balajicables.salesmanager.model.Unit;
import org.balajicables.salesmanager.utils.Utility;

public class SalesOrderItemsDTO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long orderDetailId;

	private Long itemId;
	private String itemCode;
	private Integer numberOfCopperStrands;
	private String outerDiameter;
	private String mainColour;
	private String innerColour;
	private String copperlabel;
	private String itemDescription;
	private Integer layLength;
	private String layType;
	private String orderAcceptanceDate;
	private Double quantity;
	private Integer unitId;
	private String unit;
	private Float rate;
	private Double balanceQty;
	private Integer bundleSize;
	private String odLabel;
	private String orderId;
	private String customerName;
	private Long customerId;
	private String status;
	private String area;
	private String areaValue;
	private String copperkey;
	private String productKey;
	private String cableStdKey;
	private Double woQty;
	private Double completedQty;
	private Double productionQty;
	private Double dispatchedQty;
	private String createdBy;
	private String updatedBy;
	private String updatedTime;
	private Double pvcWeight;
	private Double weight;
	private String customerCode;
	private String delivered;

	public String getCustomerCode() {
		return customerCode;
	}

	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	
	public String getOdLabel() {
		return odLabel;
	}

	public void setOdLabel(String odLabel) {
		this.odLabel = odLabel;
	}
	public Double getPvcWeight() {
		return pvcWeight;
	}

	public void setPvcWeight(Double pvcWeight) {
		this.pvcWeight = pvcWeight;
	}

	public String getOrderAcceptanceDate() {
		return orderAcceptanceDate;
	}

	public void setOrderAcceptanceDate(String orderAcceptanceDate) {
		this.orderAcceptanceDate = orderAcceptanceDate;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public Long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Long getItemId() {
		return itemId;
	}

	public void setItemId(Long itemId) {
		this.itemId = itemId;
	}

	public Integer getLayLength() {
		return layLength;
	}

	public void setLayLength(Integer layLength) {
		this.layLength = layLength;
	}

	public String getLayType() {
		return layType;
	}

	public void setLayType(String layType) {
		this.layType = layType;
	}

	public Integer getNumberOfCopperStrands() {
		return numberOfCopperStrands;
	}

	public void setNumberOfCopperStrands(Integer numberOfCopperStrands) {
		this.numberOfCopperStrands = numberOfCopperStrands;
	}

	public String getOuterDiameter() {
		return outerDiameter;
	}

	public void setOuterDiameter(String outerDiameter) {
		this.outerDiameter = outerDiameter;
	}

	public String getMainColour() {
		return mainColour;
	}

	public void setMainColour(String mainColour) {
		this.mainColour = mainColour;
	}

	public String getInnerColor() {
		return innerColour;
	}

	public void setInnerColour(String innerColour) {
		this.innerColour = innerColour;
	}

	public String getCopperlabel() {
		return copperlabel;
	}

	public void setCopperlabel(String copperlabel) {
		this.copperlabel = copperlabel;
	}

	public SalesOrderItemsDTO() {
		super();
	}

	public Long getOrderDetailId() {
		return orderDetailId;
	}

	public void setOrderDetailId(Long orderDetailId) {
		this.orderDetailId = orderDetailId;
	}

	public Double getQuantity() {
		return quantity;
	}

	public void setQuantity(Double quantity) {
		this.quantity = quantity;
	}

	public String getUnit() {
		return unit;
	}

	public void setUnit(String unit) {
		this.unit = unit;
	}

	public Float getRate() {
		return rate;
	}

	public void setRate(Float rate) {
		this.rate = rate;
	}

	public Double getBalanceQty() {
		return balanceQty;
	}

	public void setBalanceQty(Double balanceQty) {
		this.balanceQty = balanceQty;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getItemDescription() {
		return itemDescription;
	}

	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}

	public String getItemCode() {
		return itemCode;
	}

	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}

	public Integer getBundleSize() {
		return bundleSize;
	}

	public void setBundleSize(Integer bundleSize) {
		this.bundleSize = bundleSize;
	}

	public Integer getUnitId() {
		return unitId;
	}

	public void setUnitId(Integer unitId) {
		this.unitId = unitId;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public String getProductKey() {
		return productKey;
	}

	public void setProductKey(String productKey) {
		this.productKey = productKey;
	}

	public String getCableStdKey() {
		return cableStdKey;
	}

	public void setCableStdKey(String cableStdKey) {
		this.cableStdKey = cableStdKey;
	}

	public String getInnerColour() {
		return innerColour;
	}

	public String getCustomerName() {
		return customerName;
	}

	public String getCopperkey() {
		return copperkey;
	}

	public void setCopperkey(String copperkey) {
		this.copperkey = copperkey;
	}

	public Double getWoQty() {
		return woQty;
	}

	public void setWoQty(Double woQty) {
		this.woQty = woQty;
	}

	public Double getProductionQty() {
		return productionQty;
	}

	public void setProductionQty(Double productionQty) {
		this.productionQty = productionQty;
	}

	public Double getCompletedQty() {
		return completedQty;
	}

	public Double getDispatchedQty() {
		return dispatchedQty;
	}

	public void setDispatchedQty(Double dispatchedQty) {
		this.dispatchedQty = dispatchedQty;
	}

	public void setCompletedQty(Double completedQty) {
		this.completedQty = completedQty;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public String getUpdatedTime() {
		return updatedTime;
	}

	public void setUpdatedTime(String updatedTime) {
		this.updatedTime = updatedTime;
	}

	public Double getWeight() {
		return weight;
	}

	public void setWeight(Double weight) {
		this.weight = weight;
	}

	public String getAreaValue() {
		return areaValue;
	}

	public void setAreaValue(String areaValue) {
		this.areaValue = areaValue;
	}




	public String getDelivered() {
		return delivered;
	}

	public void setDelivered(String delivered) {
		this.delivered = delivered;
	}

	public SalesOrderItem getOrderDetail() {
		SalesOrderItem orderDetail = new SalesOrderItem();
		orderDetail.setOrderDetailId(orderDetailId);
		
		Item item = new Item();
		item.setItemId(itemId);
		item.setItemCode(itemCode);
		item.setItemDescription(itemDescription);
		
		Area areaObj=new Area();
		areaObj.setArea(area);
		areaObj.setAreaValue(areaValue);
		
		item.setArea(areaObj);
		item.setLayLength(layLength);
		item.setLayType(layType);
		Unit unitObj = new Unit();
		unitObj.setUnitId(unitId);
		unitObj.setUnits(unit);
		
		
		item.setUnit(unitObj);

		CopperDiameter copperDiameter = new CopperDiameter();
		copperDiameter.setCopperlabel(copperlabel);
		copperDiameter.setCopperkey(copperkey);
		item.setCopperStrandDiameter(copperDiameter);

		CableStdPvc cablestd = new CableStdPvc();
		cablestd.setCableStdKey(cableStdKey);
		item.setCableStdPvc(cablestd);
		ProductType pdtType = new ProductType();
		pdtType.setProductKey(productKey);
		item.setProductType(pdtType);

		item.setNumberOfCopperStrands(numberOfCopperStrands);
		item.setOuterDiameter(outerDiameter);
		item.setOdLabel(odLabel);
		item.setItemDescription(itemDescription);
		Colour color = new Colour();

		color.setColor(mainColour);

		item.setMainColour(color);
		color.setColor(innerColour);
		item.setInnerColour(color);
		orderDetail.setItem(item);

		SalesOrder order = new SalesOrder();
		
		order.setOrderId(orderId);
		
		Customer customer = new Customer();
		
		customer.setCustomerName(customerName);
		customer.setCustomerId(customerId);
		customer.setCustomerCode(customerCode);
		order.setCustomer(customer);
		if (orderAcceptanceDate != null)
			order.setOrderAcceptanceDate(Utility.formDateFormatter
					.parseDateTime(orderAcceptanceDate).toDate());
		else
			order.setOrderAcceptanceDate(null);
		OrderStatus orderStatus = new OrderStatus();
		
		orderStatus.setStatus(status);
		order.setOrderStatus(orderStatus);
		orderDetail.setOrder(order);
		orderDetail.setItemCode(itemCode);
		orderDetail.setRate(rate);
		orderDetail.setQuantity(quantity);
		orderDetail.setBalanceQty(balanceQty);
		orderDetail.setBundleSize(bundleSize);
		orderDetail.setWoQty(woQty);
		orderDetail.setCompletedQty(completedQty);
		orderDetail.setProductionQty(productionQty);
		orderDetail.setDispatchedQty(dispatchedQty);
		orderDetail.setUpdatedBy(updatedBy);
		orderDetail.setWeight(weight);
		orderDetail.setPvcWeight(pvcWeight);
		orderDetail.setDelivered(delivered);
		if (updatedTime != null) {

			SimpleDateFormat dateFormat = new SimpleDateFormat(
					"yyyy-MM-dd HH:mm:ss.SSS");
			java.util.Date parsedDate = null;
			try {
				parsedDate = dateFormat.parse(updatedTime);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			java.sql.Timestamp updatedTimestamp = new java.sql.Timestamp(
					parsedDate.getTime());

			orderDetail.setUpdatedTime(updatedTimestamp);
		}
		return orderDetail;
	}

}