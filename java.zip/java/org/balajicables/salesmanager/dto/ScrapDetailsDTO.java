package org.balajicables.salesmanager.dto;

import java.io.Serializable;
import org.balajicables.salesmanager.model.Item;
import org.balajicables.salesmanager.model.MachineDetails;
import org.balajicables.salesmanager.model.ProductType;
import org.balajicables.salesmanager.model.ProductionWorkOrder;
import org.balajicables.salesmanager.model.ScrapDetails;
import org.balajicables.salesmanager.model.Shift;
import org.balajicables.salesmanager.model.StockOut;
import org.balajicables.salesmanager.model.StoreRegister;



public class ScrapDetailsDTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 5864038683834374118L;
	private Long scrapId;
	private  String workOrderNo;
	private Long itemId;
	private Long machineNo;
	private  String supervisor;
	private  String scrapDate;
    private  String createdDate;
    private  Double quantity;
    private Integer shiftId;
	private String stockedInStatus  ;
	private String shiftPattern;
	private String productKey;
	private String itemCode;
	private String itemDescription;
	private String machineDesciption;
	private  String remarks;
    
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public String getProductKey() {
		return productKey;
	}
	public void setProductKey(String productKey) {
		this.productKey = productKey;
	}
	public String getStockedInStatus() {
		return stockedInStatus;
	}
	public void setStockedInStatus(String stockedInStatus) {
		this.stockedInStatus = stockedInStatus;
	}
	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}
	public Long getItemId() {
		return itemId;
	}
	public void setItemId(Long itemId) {
		this.itemId = itemId;
	}
	public Long getScrapId() {
		return scrapId;
	}
	public void setScrapId(Long id) {
		this.scrapId = id;
	}
	public String getWorkOrderNo() {
		return workOrderNo;
	}
	public void setWorkOrderNo(String workOrderNo) {
		this.workOrderNo = workOrderNo;
	}

	public String getItemCode() {
		return itemCode;
	}
	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}
	public String getItemDescription() {
		return itemDescription;
	}
	public void setItemDesc(String itemDescription) {
		this.itemDescription =itemDescription;
	}

	public String getShiftPattern() {
		return shiftPattern;
	}
	public void setShiftPattern(String shiftPattern) {
		this.shiftPattern = shiftPattern;
	}
	
	public String getMachineDesciption() {
		return machineDesciption;
	}
	public void setMachineDesciption(String machineDesciption) {
		this.machineDesciption = machineDesciption;
	}
	public String getSupervisor() {
		return supervisor;
	}
	public void setSupervisor(String supervisor) {
		this.supervisor = supervisor;
	}
	public String getScrapDate() {
		return scrapDate;
	}
	public void setScrapDate(String scrapDate) {
		this.scrapDate = scrapDate;
	}
	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	public Double getQuantity() {
		return quantity;
	}
	public void setQuantity(Double quantity) {
		this.quantity = quantity;
	}
	
	
	public Long getMachineNo() {
		return machineNo;
	}
	public void setMachineNo(Long machineNo) {
		this.machineNo = machineNo;
	}
	public Integer getShiftId() {
		return shiftId;
	}
	public void setShiftId(Integer shiftId) {
		this.shiftId = shiftId;
	}
	public ScrapDetails getScrapDetails() {
		ScrapDetails scrapDetails = new ScrapDetails();
		
		ProductionWorkOrder productionWorkOrder =  new ProductionWorkOrder();
		productionWorkOrder.setWorkOrderNo(workOrderNo);
		
		MachineDetails machineDetails = new MachineDetails();
		machineDetails.setMachineNo(machineNo);
		machineDetails.setDescription(machineDesciption);
		
		Item item = new Item();
		item.setItemId(itemId);
		
		ProductType pdtType=new ProductType();
		pdtType.setProductKey(productKey);
		
		item.setProductType(pdtType);
		
		Shift shiftObj = new Shift();
		shiftObj.setShiftId(shiftId);
		shiftObj.setShiftPattern(shiftPattern);
		
		scrapDetails.setScrapId(scrapId);
		scrapDetails.setStockedInStatus(stockedInStatus);
		scrapDetails.setProductionWorkOrder(productionWorkOrder);
		scrapDetails.setMachineDetails(machineDetails);
		scrapDetails.setItem(item);
		scrapDetails.setShift(shiftObj);
		scrapDetails.setScrapDate(scrapDate);
		scrapDetails.setCreatedDate(createdDate);
		scrapDetails.setQuantity(quantity);
		scrapDetails.setSupervisor(supervisor);
		
		StockOut stockOut = new StockOut();
		stockOut.setRemarks(remarks);
		
		StoreRegister storeRegister = new StoreRegister();
		storeRegister.setRemarks(remarks);
		
		return scrapDetails;
	} 
 




}