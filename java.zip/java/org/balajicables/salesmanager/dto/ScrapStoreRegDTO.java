package org.balajicables.salesmanager.dto;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.balajicables.salesmanager.model.Item;
import org.balajicables.salesmanager.model.ScrapStoreReg;
import org.balajicables.salesmanager.model.Store;


public class ScrapStoreRegDTO implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private Long scrapStoreRegId;
	
	private  String  updatedTime;
	private  String  updatedBy;
	private  Double stockQuantity;
	private Long itemId;
	
	private  String  itemCode;
	private  String  itemDescription;
	private  Double stockOutQty;

	private int storeId;


	public Long getScrapStoreRegId() {
		return scrapStoreRegId;
	}





	public void setScrapStoreRegId(Long scrapStoreRegId) {
		this.scrapStoreRegId = scrapStoreRegId;
	}





	public String getUpdatedTime() {
		return updatedTime;
	}





	public void setUpdatedTime(String updatedTime) {
		this.updatedTime = updatedTime;
	}





	public String getUpdatedBy() {
		return updatedBy;
	}





	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}





	public Double getStockQuantity() {
		return stockQuantity;
	}





	public void setStockQuantity(Double stockQuantity) {
		this.stockQuantity = stockQuantity;
	}





	public Long getItemId() {
		return itemId;
	}





	public void setItemId(Long itemId) {
		this.itemId = itemId;
	}





	public String getItemCode() {
		return itemCode;
	}





	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}





	public String getItemDescription() {
		return itemDescription;
	}





	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}





	public static long getSerialversionuid() {
		return serialVersionUID;
	}





	public Double getStockOutQty() {
		return stockOutQty;
	}





	public void setStockOutQty(Double stockOutQty) {
		this.stockOutQty = stockOutQty;
	}





	public int getStoreId() {
		return storeId;
	}





	public void setStoreId(int storeId) {
		this.storeId = storeId;
	}





	public ScrapStoreReg getScrapStoreReg() {
		ScrapStoreReg scrapStoreReg = new ScrapStoreReg();
		scrapStoreReg.setScrapStoreRegId(scrapStoreRegId);
		
		Item itemObj=new Item();
		itemObj.setItemId(itemId);
		itemObj.setItemCode(itemCode);
		itemObj.setItemDescription(itemDescription);
		scrapStoreReg.setItems(itemObj);
		
		scrapStoreReg.setUpdatedBy(updatedBy);
	    if(updatedTime!=null){

		      SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
		      java.util.Date parsedDate = null;
			  try {
				parsedDate = dateFormat.parse(updatedTime);
			  } catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			 }
		      java.sql.Timestamp timestamp = new java.sql.Timestamp(parsedDate.getTime());
				
				
		      scrapStoreReg.setUpdatedTime(timestamp);
		}	
	    
	    scrapStoreReg.setStockQuantity(stockQuantity);
	    scrapStoreReg.setStockOutQty(stockOutQty);
	    
	    Store storeObj=new Store();
	    storeObj.setStoreId(storeId);
	    scrapStoreReg.setStore(storeObj);
			return scrapStoreReg;
	}
	
}	
	
		
	