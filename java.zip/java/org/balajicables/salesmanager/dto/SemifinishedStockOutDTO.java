package org.balajicables.salesmanager.dto;

import java.io.Serializable;

import org.balajicables.salesmanager.model.Customer;
import org.balajicables.salesmanager.model.Item;
import org.balajicables.salesmanager.model.OrderStatus;
import org.balajicables.salesmanager.model.ProductionWorkOrder;
import org.balajicables.salesmanager.model.SalesOrder;
import org.balajicables.salesmanager.model.SalesOrderItem;
import org.balajicables.salesmanager.model.SemifinishedStockOut;
import org.balajicables.salesmanager.model.Store;



public class SemifinishedStockOutDTO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * 
	 */
	private Long semifinishedStockOutId;
	private String stockedOutFor;
	private String workOrderNo;
	private Integer storeId;
	private Long orderDetailId;
	private  String orderId;
	private long itemId;
	private String itemCode;
	private String itemDescription;
	private  Double stockOutQty;
	private  String bundleId;
	private Double weight;
	private String supervisor;
	private String confirmStatus;
	private String customerName;
	private String customerCode;
	private String qcStatus;
	private String qcSupervisor;
	private String status;
	
	
public Long getSemifinishedStockOutId() {
		return semifinishedStockOutId;
	}

	public void setSemifinishedStockOutId(Long semifinishedStockOutId) {
		this.semifinishedStockOutId = semifinishedStockOutId;
	}

	public String getStockedOutFor() {
		return stockedOutFor;
	}

	public void setStockedOutFor(String stockedOutFor) {
		this.stockedOutFor = stockedOutFor;
	}

	public String getWorkOrderNo() {
		return workOrderNo;
	}

	public void setWorkOrderNo(String workOrderNo) {
		this.workOrderNo = workOrderNo;
	}

	public Integer getStoreId() {
		return storeId;
	}

	public void setStoreId(Integer storeId) {
		this.storeId = storeId;
	}

	public Long getOrderDetailId() {
		return orderDetailId;
	}

	public void setOrderDetailId(Long orderDetailId) {
		this.orderDetailId = orderDetailId;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public long getItemId() {
		return itemId;
	}

	public void setItemId(long itemId) {
		this.itemId = itemId;
	}

	public String getItemCode() {
		return itemCode;
	}

	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}

	public Double getStockOutQty() {
		return stockOutQty;
	}

	public void setStockOutQty(Double stockOutQty) {
		this.stockOutQty = stockOutQty;
	}

	public String getBundleId() {
		return bundleId;
	}

	public void setBundleId(String bundleId) {
		this.bundleId = bundleId;
	}

	public Double getWeight() {
		return weight;
	}

	public void setWeight(Double weight) {
		this.weight = weight;
	}

	
public String getSupervisor() {
		return supervisor;
	}

	public void setSupervisor(String supervisor) {
		this.supervisor = supervisor;
	}

public String getItemDescription() {
		return itemDescription;
	}

	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}





public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerCode() {
		return customerCode;
	}

	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}

public String getConfirmStatus() {
		return confirmStatus;
	}

	public void setConfirmStatus(String confirmStatus) {
		this.confirmStatus = confirmStatus;
	}

public String getQcStatus() {
		return qcStatus;
	}

	public void setQcStatus(String qcStatus) {
		this.qcStatus = qcStatus;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

public String getQcSupervisor() {
		return qcSupervisor;
	}

	public void setQcSupervisor(String qcSupervisor) {
		this.qcSupervisor = qcSupervisor;
	}

public SemifinishedStockOut getSemifinishedStockOut() {
	SemifinishedStockOut semifinishedStockOut = new SemifinishedStockOut();
	semifinishedStockOut.setSemifinishedStockOutId(semifinishedStockOutId);
	ProductionWorkOrder pdnWorkOrder=new ProductionWorkOrder();
	pdnWorkOrder.setWorkOrderNo(stockedOutFor);
	semifinishedStockOut.setProductionWorkOrder(pdnWorkOrder);
	
	ProductionWorkOrder pdnWorkOrders=new ProductionWorkOrder();
	pdnWorkOrders.setWorkOrderNo(workOrderNo);
	semifinishedStockOut.setProductionWorkOrders(pdnWorkOrders);
	
	Store storeObj=new Store();
	storeObj.setStoreId(storeId);
	semifinishedStockOut.setStore(storeObj);
	
	SalesOrder soOrder=new SalesOrder();
	soOrder.setOrderId(orderId);
	OrderStatus statusObj=new OrderStatus();
	statusObj.setStatus(status);
	soOrder.setOrderStatus(statusObj);
	
	Customer customer=new Customer();
	customer.setCustomerName(customerName);
	customer.setCustomerCode(customerCode);
	soOrder.setCustomer(customer);
	Item itemObj=new Item();
	itemObj.setItemId(itemId);
	itemObj.setItemCode(itemCode);
	itemObj.setItemDescription(itemDescription);
	
	SalesOrderItem soItem=new SalesOrderItem();
	soItem.setOrderDetailId(orderDetailId);
	soItem.setItem(itemObj);
	soItem.setOrder(soOrder);
	semifinishedStockOut.setConfirmStatus(confirmStatus);
	
	semifinishedStockOut.setSalesOrderItem(soItem);
	semifinishedStockOut.setOrderId(orderId);
	semifinishedStockOut.setItemId(itemId);
	semifinishedStockOut.setItemCode(itemCode);
	semifinishedStockOut.setSupervisor(supervisor);
	semifinishedStockOut.setStockOutQty(stockOutQty);
	semifinishedStockOut.setBundleId(bundleId);
	semifinishedStockOut.setQcStatus(qcStatus);
	semifinishedStockOut.setQcSupervisor(qcSupervisor);
	semifinishedStockOut.setWeight(weight);
	return semifinishedStockOut;
	}


}