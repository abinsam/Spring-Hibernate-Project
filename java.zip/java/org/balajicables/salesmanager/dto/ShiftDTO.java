package org.balajicables.salesmanager.dto;

import java.io.Serializable;



public class ShiftDTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 5864038683834374118L;
	private Integer shiftId;
	private  String shiftPattern;
	private String shiftDesc;
	public Integer getShiftId() {
		return shiftId;
	}
	public void setShiftId(Integer shiftId) {
		this.shiftId = shiftId;
	}
	public String getShiftPattern() {
		return shiftPattern;
	}
	public void setShiftPattern(String shiftPattern) {
		this.shiftPattern = shiftPattern;
	}
	public String getShiftDesc() {
		return shiftDesc;
	}
	public void setShiftDesc(String shiftDesc) {
		this.shiftDesc = shiftDesc;
	}



}