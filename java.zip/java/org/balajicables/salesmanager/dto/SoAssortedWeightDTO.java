package org.balajicables.salesmanager.dto;

import java.io.Serializable;
import org.balajicables.salesmanager.model.SalesOrder;
import org.balajicables.salesmanager.model.SoAssortedWeight;

public class SoAssortedWeightDTO implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Long soAssortedWeightId;
	private SalesOrder orders;
	private Integer assortedType  ;
	private Integer weight;
	public Long getSoAssortedWeightId() {
		return soAssortedWeightId;
	}
	public void setSoAssortedWeightId(Long soAssortedWeightId) {
		this.soAssortedWeightId = soAssortedWeightId;
	}
	public SalesOrder getOrders() {
		return orders;
	}
	public void setOrders(SalesOrder orders) {
		this.orders = orders;
	}
	public Integer getAssortedType() {
		return assortedType;
	}
	public void setAssortedType(Integer assortedType) {
		this.assortedType = assortedType;
	}
	public Integer getWeight() {
		return weight;
	}
	public void setWeight(Integer weight) {
		this.weight = weight;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	public SoAssortedWeight getSoAssortedweight(){
		
		SoAssortedWeight soAssortedWeight = new SoAssortedWeight();
		
		
		return soAssortedWeight;
		
	}
}
