package org.balajicables.salesmanager.dto;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.balajicables.salesmanager.model.Customer;
import org.balajicables.salesmanager.model.Item;
import org.balajicables.salesmanager.model.ProductionWorkOrder;
import org.balajicables.salesmanager.model.SalesOrder;
import org.balajicables.salesmanager.model.SalesOrderItem;
import org.balajicables.salesmanager.model.StockIn;
import org.balajicables.salesmanager.model.Store;
import org.balajicables.salesmanager.model.Unit;



public class StockInDTO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * 
	 */
	private Long stockInId;
	private Integer storeId;
	private  String storeAddress;
	private long itemId;
	private String itemCode;
	private String itemDescription;
	private String stockInDateTime;
	private  String orderId;
	private  String customerName;
	private  Long customerId;
	private String workOrderNo;
	private  Double stockQty;
	private  String bundleId;
    private Long orderDetailId;
	private  String qcStatus;
	private  Double soItemQty;
	private  String units;
    private String assortedType;
    
    private String dcStatus;
    private Integer deliveryChallanNo;
  
    private  Double weight;
    private String batchNo;

    private String confirmStatus;
    private String supervisor;
    private  String customerCode;
    
	public String getCustomerCode() {
		return customerCode;
	}

	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}

	public String getBatchNo() {
		return batchNo;
	}

	public void setBatchNo(String batchNo) {
		this.batchNo = batchNo;
	}

	public Integer getStoreId() {
		return storeId;
	}

	public void setStoreId(Integer storeId) {
		this.storeId = storeId;
	}

	public String getStoreAddress() {
		return storeAddress;
	}

	public void setStoreAddress(String storeAddress) {
		this.storeAddress = storeAddress;
	}

	public long getItemId() {
		return itemId;
	}

	public void setItemId(long itemId) {
		this.itemId = itemId;
	}

	public String getItemCode() {
		return itemCode;
	}

	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}


	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getWorkOrderNo() {
		return workOrderNo;
	}

	public void setWorkOrderNo(String workOrderNo) {
		this.workOrderNo = workOrderNo;
	}

	public Double getStockQty() {
		return stockQty;
	}

	public void setStockQty(Double stockQty) {
		this.stockQty = stockQty;
	}

	public String getBundleId() {
		return bundleId;
	}

	public void setBundleId(String bundleId) {
		this.bundleId = bundleId;
	}



	public Long getOrderDetailId() {
		return orderDetailId;
	}

	public void setOrderDetailId(Long orderDetailId) {
		this.orderDetailId = orderDetailId;
	}

	public String getQcStatus() {
		return qcStatus;
	}

	public void setQcStatus(String qcStatus) {
		this.qcStatus = qcStatus;
	}
	public Long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}
	public Double getSoItemQty() {
		return soItemQty;
	}

	public void setSoItemQty(Double soItemQty) {
		this.soItemQty = soItemQty;
	}
	public String getItemDescription() {
		return itemDescription;
	}

	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}

	public Integer getDeliveryChallanNo() {
		return deliveryChallanNo;
	}

	public void setDeliveryChallanNo(Integer deliveryChallanNo) {
		this.deliveryChallanNo = deliveryChallanNo;
	}

	public String getDcStatus() {
		return dcStatus;
	}

	public void setDcStatus(String dcStatus) {
		this.dcStatus = dcStatus;
	}


public Long getStockInId() {
		return stockInId;
	}

	public void setStockInId(Long stockInId) {
		this.stockInId = stockInId;
	}

	public String getStockInDateTime() {
		return stockInDateTime;
	}

	public void setStockInDateTime(String stockInDateTime) {
		this.stockInDateTime = stockInDateTime;
	}
	public Double getWeight() {
		return weight;
	}

	public void setWeight(Double weight) {
		this.weight = weight;
	}

	
	
public String getConfirmStatus() {
		return confirmStatus;
	}

	public void setConfirmStatus(String confirmStatus) {
		this.confirmStatus = confirmStatus;
	}

public String getUnits() {
		return units;
	}

	public void setUnits(String units) {
		this.units = units;
	}

public String getAssortedType() {
		return assortedType;
	}

	public void setAssortedType(String assortedType) {
		this.assortedType = assortedType;
	}

public String getSupervisor() {
		return supervisor;
	}

	public void setSupervisor(String supervisor) {
		this.supervisor = supervisor;
	}

public StockIn getStockIn() {
	StockIn stockIn = new StockIn();
	stockIn.setStockInId(stockInId);
	
	Store storeObj=new Store();
	storeObj.setStoreId(storeId);
	storeObj.setStoreAddress(storeAddress);
	stockIn.setStore(storeObj);
	stockIn.setBatchNo(batchNo);
	stockIn.setItemCode(itemCode);
	stockIn.setItemId(itemId);
	if(stockInDateTime!=null){

	      //SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
		  SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	      java.util.Date parsedDate = null;
		  try {
			parsedDate = dateFormat.parse(stockInDateTime);
		  } catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		 }
	      java.sql.Timestamp timestamp = new java.sql.Timestamp(parsedDate.getTime());
	      stockIn.setStockInDateTime(timestamp);
	}	
	

	
	SalesOrderItem soItem=new SalesOrderItem();
	soItem.setCompletedQty(stockQty);
	soItem.setOrderDetailId(orderDetailId);
	SalesOrder order=new SalesOrder();
	order.setOrderId(orderId);
	Customer customer=new Customer();
	customer.setCustomerName(customerName);
	customer.setCustomerId(customerId);
	customer.setCustomerCode(customerCode);
	order.setCustomer(customer);
	soItem.setOrder(order);
	soItem.setQuantity(soItemQty);
	
	Item itemObj=new Item();
	itemObj.setItemId(itemId);
	itemObj.setItemCode(itemCode);
	itemObj.setItemDescription(itemDescription);
	
	Unit unitObj=new Unit();
	unitObj.setUnits(units);
	itemObj.setUnit(unitObj);
	itemObj.setAssortedType(assortedType);
	soItem.setItem(itemObj);
	
	stockIn.setSoItemQty(soItemQty);
	stockIn.setCustomerName(customerName);
	stockIn.setSalesOrderItem(soItem);
	stockIn.setStockQty(stockQty);
	stockIn.setBundleId(bundleId);
	stockIn.setQcStatus(qcStatus);
	stockIn.setOrderId(orderId);
	stockIn.setSupervisor(supervisor);
	ProductionWorkOrder workOrderObj=new ProductionWorkOrder();
	workOrderObj.setWorkOrderNo(workOrderNo);
	stockIn.setProductionWorkOrder(workOrderObj);
	stockIn.setWeight(weight);
	stockIn.setConfirmStatus(confirmStatus);
	
	return stockIn;
	}











}