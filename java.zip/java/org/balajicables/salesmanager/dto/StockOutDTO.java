package org.balajicables.salesmanager.dto;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.balajicables.salesmanager.model.Customer;
import org.balajicables.salesmanager.model.Item;
import org.balajicables.salesmanager.model.OrderStatus;
import org.balajicables.salesmanager.model.ProductionWorkOrder;
import org.balajicables.salesmanager.model.SalesOrder;
import org.balajicables.salesmanager.model.SalesOrderItem;
import org.balajicables.salesmanager.model.StockOut;
import org.balajicables.salesmanager.model.Store;
import org.balajicables.salesmanager.model.Unit;



public class StockOutDTO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * 
	 */
	private Long stockOutId;
	private Integer storeId;
	private String storeAddress;
	private long itemId;
	private String itemCode;
	private String itemType;
	private String itemDescription;
	private String stockOutDateTime;
	private  String orderId;
	private  String customerName;
	private  Long customerId;
	private String workOrderNo;
	private  Double stockOutQty;
	private  String bundleId;
    private Long orderDetailId;
	private  String qcStatus;
	private  Double soItemQty;
	private Long packingSlipNo;
    private String supervisor;
    private String deliveryChallanNo;
    private String status;
    private String confirmStatus;
    private String units;
	private Double weight;
	private Double bagWeight;
	private String qcSupervisor;
	private String remarks;
	 private  String customerCode;
	    
		public String getCustomerCode() {
			return customerCode;
		}

		public void setCustomerCode(String customerCode) {
			this.customerCode = customerCode;
		}
    public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public Long getStockOutId() {
		return stockOutId;
	}

	public void setStockOutId(Long stockOutId) {
		this.stockOutId = stockOutId;
	}

	public Integer getStoreId() {
		return storeId;
	}

	public void setStoreId(Integer storeId) {
		this.storeId = storeId;
	}

	public long getItemId() {
		return itemId;
	}

	public void setItemId(long itemId) {
		this.itemId = itemId;
	}

	public String getItemCode() {
		return itemCode;
	}

	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}

	public String getItemDescription() {
		return itemDescription;
	}

	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}

	public String getStockOutDateTime() {
		return stockOutDateTime;
	}

	public void setStockOutDateTime(String stockOutDateTime) {
		this.stockOutDateTime = stockOutDateTime;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public Long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}

	public String getWorkOrderNo() {
		return workOrderNo;
	}

	public void setWorkOrderNo(String workOrderNo) {
		this.workOrderNo = workOrderNo;
	}

	public Double getStockOutQty() {
		return stockOutQty;
	}

	public void setStockOutQty(Double stockOutQty) {
		this.stockOutQty = stockOutQty;
	}

	public String getBundleId() {
		return bundleId;
	}

	public void setBundleId(String bundleId) {
		this.bundleId = bundleId;
	}

	public Long getOrderDetailId() {
		return orderDetailId;
	}

	public void setOrderDetailId(Long orderDetailId) {
		this.orderDetailId = orderDetailId;
	}

	public String getQcStatus() {
		return qcStatus;
	}

	public void setQcStatus(String qcStatus) {
		this.qcStatus = qcStatus;
	}

	public Double getSoItemQty() {
		return soItemQty;
	}

	public void setSoItemQty(Double soItemQty) {
		this.soItemQty = soItemQty;
	}

	
	public String getSupervisor() {
		return supervisor;
	}

	public void setSupervisor(String supervisor) {
		this.supervisor = supervisor;
	}

public Long getPackingSlipNo() {
		return packingSlipNo;
	}

	public void setPackingSlipNo(Long packingSlipNo) {
		this.packingSlipNo = packingSlipNo;
	}

	
	public Double getWeight() {
		return weight;
	}

	public void setWeight(Double weight) {
		this.weight = weight;
	}



public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

public String getConfirmStatus() {
		return confirmStatus;
	}

	public void setConfirmStatus(String confirmStatus) {
		this.confirmStatus = confirmStatus;
	}

public String getUnits() {
		return units;
	}

	public void setUnits(String units) {
		this.units = units;
	}

public Double getBagWeight() {
		return bagWeight;
	}

	public void setBagWeight(Double bagWeight) {
		this.bagWeight = bagWeight;
	}


public String getDeliveryChallanNo() {
		return deliveryChallanNo;
	}

	public void setDeliveryChallanNo(String deliveryChallanNo) {
		this.deliveryChallanNo = deliveryChallanNo;
	}

public String getQcSupervisor() {
		return qcSupervisor;
	}

	public void setQcSupervisor(String qcSupervisor) {
		this.qcSupervisor = qcSupervisor;
	}

public String getStoreAddress() {
		return storeAddress;
	}

	public void setStoreAddress(String storeAddress) {
		this.storeAddress = storeAddress;
	}

public String getItemType() {
		return itemType;
	}

	public void setItemType(String itemType) {
		this.itemType = itemType;
	}

public StockOut getStockOut() {
	StockOut stockOut = new StockOut();
	stockOut.setStockOutId(stockOutId);
	
	
	Store storeObj=new Store();
	storeObj.setStoreId(storeId);
	storeObj.setStoreAddress(storeAddress);
	stockOut.setStore(storeObj);
	
	Item itemObj=new Item();
	itemObj.setItemId(itemId);
	itemObj.setItemCode(itemCode);
	itemObj.setItemDescription(itemDescription);
	itemObj.setItemType(itemType);
	Unit unitObj=new Unit();
	unitObj.setUnits(units);
	itemObj.setUnit(unitObj);
	
	
	stockOut.setItemId(itemId);
	stockOut.setItemCode(itemCode);
	
	if(stockOutDateTime!=null){
 
	  	SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
	  	try{
	  	java.util.Date date = sdf.parse(stockOutDateTime);
	  	java.sql.Timestamp timest = new java.sql.Timestamp(date.getTime()); 
        stockOut.setStockOutDateTime(timest);
	  	}
	  	catch (ParseException e) {
			
			e.printStackTrace();
		 }}

	SalesOrderItem soItem=new SalesOrderItem();
	soItem.setOrderDetailId(orderDetailId);
	SalesOrder order=new SalesOrder();
	order.setOrderId(orderId);
	OrderStatus orderStatus=new OrderStatus();
	orderStatus.setStatus(status);
	order.setOrderStatus(orderStatus);
	Customer customer=new Customer();
	customer.setCustomerName(customerName);
	customer.setCustomerId(customerId);
	customer.setCustomerCode(customerCode);
	order.setCustomer(customer);
	soItem.setOrder(order);
	soItem.setQuantity(soItemQty);
	soItem.setItem(itemObj);
	
	stockOut.setSoItemQty(soItemQty);
	stockOut.setCustomerName(customerName);
	stockOut.setSalesOrderItem(soItem);
	stockOut.setStockOutQty(stockOutQty);
	stockOut.setBundleId(bundleId);
	stockOut.setQcStatus(qcStatus);
	stockOut.setQcSupervisor(qcSupervisor);
	stockOut.setOrderId(orderId);
	ProductionWorkOrder workOrderObj=new ProductionWorkOrder();
	workOrderObj.setWorkOrderNo(workOrderNo);
	stockOut.setProductionWorkOrder(workOrderObj);
	stockOut.setRemarks(remarks);
	stockOut.setPackingSlipNo(packingSlipNo);
	stockOut.setSupervisor(supervisor);
	stockOut.setWeight(weight);
	stockOut.setConfirmStatus(confirmStatus);
    stockOut.setBagWeight(bagWeight);
    stockOut.setDeliveryChallanNo(deliveryChallanNo);
	return stockOut;
	}


}