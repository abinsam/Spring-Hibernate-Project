package org.balajicables.salesmanager.dto;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.balajicables.salesmanager.model.Customer;
import org.balajicables.salesmanager.model.Item;
import org.balajicables.salesmanager.model.OrderStatus;
import org.balajicables.salesmanager.model.ProductionWorkOrder;
import org.balajicables.salesmanager.model.SalesOrder;
import org.balajicables.salesmanager.model.SalesOrderItem;
import org.balajicables.salesmanager.model.StoreRegister;
import org.balajicables.salesmanager.model.Store;
import org.balajicables.salesmanager.model.Unit;



public class StoreRegisterDTO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * 
	 */
	private Long storeRegisterId;
	private Integer storeId;
	private  String storeAddress;
	private long itemId;
	private String itemCode;
	private String itemDescription;
	private String updatedDateTime;
	private  String orderId;
	private  String customerName;
	private  Long customerId;
	private String workOrderNo;
	private  Double stockQty;
	private  String bundleId;
    private Long orderDetailId;
    private  Long packingSlipNo;	
    private  String supervisor;
    private  Double weight;
    private  Double bagWeight;
    private String units;
    private String status;
    private  String qcStatus;
    private  String rejectStatus;
    private  String qcSupervisor;
    private  String remarks;
    private  String customerCode;
	
public String getCustomerCode() {
		return customerCode;
	}

	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}

public String getQcStatus() {
		return qcStatus;
	}

	public void setQcStatus(String qcStatus) {
		this.qcStatus = qcStatus;
	}

	public String getRejectStatus() {
		return rejectStatus;
	}

	public void setRejectStatus(String rejectStatus) {
		this.rejectStatus = rejectStatus;
	}

public Long getStoreRegisterId() {
		return storeRegisterId;
	}

	public void setStoreRegisterId(Long storeRegisterId) {
		this.storeRegisterId = storeRegisterId;
	}

	public Integer getStoreId() {
		return storeId;
	}

	public void setStoreId(Integer storeId) {
		this.storeId = storeId;
	}

	public String getStoreAddress() {
		return storeAddress;
	}

	public void setStoreAddress(String storeAddress) {
		this.storeAddress = storeAddress;
	}

	public long getItemId() {
		return itemId;
	}

	public void setItemId(long itemId) {
		this.itemId = itemId;
	}

	public String getItemCode() {
		return itemCode;
	}

	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}

	

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getWorkOrderNo() {
		return workOrderNo;
	}

	public void setWorkOrderNo(String workOrderNo) {
		this.workOrderNo = workOrderNo;
	}

	public Double getStockQty() {
		return stockQty;
	}

	public void setStockQty(Double stockQty) {
		this.stockQty = stockQty;
	}

	public String getBundleId() {
		return bundleId;
	}

	public void setBundleId(String bundleId) {
		this.bundleId = bundleId;
	}



	public Long getOrderDetailId() {
		return orderDetailId;
	}

	public void setOrderDetailId(Long orderDetailId) {
		this.orderDetailId = orderDetailId;
	}

	
	public Long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}
	
	public String getItemDescription() {
		return itemDescription;
	}

	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}

	public Long getPackingSlipNo() {
		return packingSlipNo;
	}

	public void setPackingSlipNo(Long packingSlipNo) {
		this.packingSlipNo = packingSlipNo;
	}

	public String getSupervisor() {
		return supervisor;
	}

	public void setSupervisor(String supervisor) {
		this.supervisor = supervisor;
	}

	public Double getWeight() {
		return weight;
	}

	public void setWeight(Double weight) {
		this.weight = weight;
	}

    public String getUnits() {
		return units;
	}

	public void setUnits(String units) {
		this.units = units;
	}

public Double getBagWeight() {
		return bagWeight;
	}

	public void setBagWeight(Double bagWeight) {
		this.bagWeight = bagWeight;
	}

public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	
	
	
public String getUpdatedDateTime() {
		return updatedDateTime;
	}

	public void setUpdatedDateTime(String updatedDateTime) {
		this.updatedDateTime = updatedDateTime;
	}

	public String getQcSupervisor() {
		return qcSupervisor;
	}

	public void setQcSupervisor(String qcSupervisor) {
		this.qcSupervisor = qcSupervisor;
	}

public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

public StoreRegister getStoreRegister() {
	StoreRegister storeRegister = new StoreRegister();
	storeRegister.setStoreRegisterId(storeRegisterId);
	
	Store storeObj=new Store();
	storeObj.setStoreId(storeId);
	storeObj.setStoreAddress(storeAddress);
	storeRegister.setStore(storeObj);
	

	
	if(updatedDateTime!=null){

	   //   SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss.SSS");
	      SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");

	      java.util.Date parsedDate = null;
		  try {
			parsedDate = dateFormat.parse(updatedDateTime);
		  } catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		 }
	      java.sql.Timestamp timestamp = new java.sql.Timestamp(parsedDate.getTime());
	      storeRegister.setUpdatedDateTime(timestamp);
	}	
	
	
	
	SalesOrderItem soItem=new SalesOrderItem();
	soItem.setOrderDetailId(orderDetailId);
	SalesOrder order=new SalesOrder();
	order.setOrderId(orderId);
	Customer customer=new Customer();
	customer.setCustomerName(customerName);
	customer.setCustomerId(customerId);
	customer.setCustomerCode(customerCode);
	order.setCustomer(customer);
	
	OrderStatus statusObj=new OrderStatus();
	statusObj.setStatus(status);
	order.setOrderStatus(statusObj);
	soItem.setOrder(order);
	Item itemobj=new Item();
	itemobj.setItemCode(itemCode);
	itemobj.setItemId(itemId);
	itemobj.setItemDescription(itemDescription);
	
	Unit unitObj=new Unit();
	unitObj.setUnits(units);
	itemobj.setUnit(unitObj);
	soItem.setItem(itemobj);
	
	storeRegister.setSalesOrderItem(soItem);
	
	storeRegister.setItemCode(itemCode);
	storeRegister.setItemId(itemId);
	storeRegister.setCustomerName(customerName);

	storeRegister.setStockQty(stockQty);
	storeRegister.setBundleId(bundleId);
	storeRegister.setOrderId(orderId);
	ProductionWorkOrder workOrderObj=new ProductionWorkOrder();
	workOrderObj.setWorkOrderNo(workOrderNo);
	storeRegister.setProductionWorkOrder(workOrderObj);
	storeRegister.setPackingSlipNo(packingSlipNo);
	storeRegister.setSupervisor(supervisor);
	storeRegister.setWeight(weight);
	storeRegister.setBagWeight(bagWeight);
	storeRegister.setQcStatus(qcStatus);
	storeRegister.setRejectStatus(rejectStatus);
	storeRegister.setQcSupervisor(qcSupervisor);
	storeRegister.setRemarks(remarks);
	return storeRegister;
	}











}