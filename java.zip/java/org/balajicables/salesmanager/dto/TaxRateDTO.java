package org.balajicables.salesmanager.dto;

import java.io.Serializable;

import org.balajicables.salesmanager.model.Customer;
import org.balajicables.salesmanager.model.TaxRate;

public class TaxRateDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long taxRateId;
	private Long customerId;
	private String customerName;
	private String customerCode;
	private Float exciseDuty;
	private Float eduCess;
	private Float higherEduCess;
	private Float salesTax;
	private Float vat;
	private Float cst;

	private String freight;
	private String paymentTerms;




	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerCode() {
		return customerCode;
	}

	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	public Long getTaxRateId() {
		return taxRateId;
	}

	public void setTaxRateId(Long taxRateId) {
		this.taxRateId = taxRateId;
	}

	public Long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}

	public Float getExciseDuty() {
		return exciseDuty;
	}

	public void setExciseDuty(Float exciseDuty) {
		this.exciseDuty = exciseDuty;
	}

	public Float getEduCess() {
		return eduCess;
	}

	public void setEduCess(Float eduCess) {
		this.eduCess = eduCess;
	}

	public Float getHigherEduCess() {
		return higherEduCess;
	}

	public void setHigherEduCess(Float higherEduCess) {
		this.higherEduCess = higherEduCess;
	}

	public Float getSalesTax() {
		return salesTax;
	}

	public void setSalesTax(Float salesTax) {
		this.salesTax = salesTax;
	}

	public Float getVat() {
		return vat;
	}

	public void setVat(Float vat) {
		this.vat = vat;
	}

	public Float getCst() {
		return cst;
	}

	public void setCst(Float cst) {
		this.cst = cst;
	}

	public String getFreight() {
		return freight;
	}

	public void setFreight(String freight) {
		this.freight = freight;
	}

	public String getPaymentTerms() {
		return paymentTerms;
	}

	public void setPaymentTerms(String paymentTerms) {
		this.paymentTerms = paymentTerms;
	}

	public TaxRate getTaxRate() {
		
		TaxRate taxRate = new TaxRate();
		taxRate.setTaxRateId(taxRateId);
		Customer customer = new Customer();
		customer.setCustomerId(customerId);
		customer.setCustomerName(customerName);
		customer.setCustomerCode(customerCode);

		taxRate.setCustomer(customer);
		taxRate.setExciseDuty(exciseDuty);
		taxRate.setCst(cst);
		taxRate.setEduCess(eduCess);
		taxRate.setHigherEduCess(higherEduCess);
		taxRate.setVat(vat);
		taxRate.setPaymentTerms(paymentTerms);
		taxRate.setFreight(freight);
		return taxRate;

	}

}