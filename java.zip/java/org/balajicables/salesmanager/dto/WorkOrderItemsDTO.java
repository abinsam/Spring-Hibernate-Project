package org.balajicables.salesmanager.dto;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.balajicables.salesmanager.model.Area;
import org.balajicables.salesmanager.model.CableStdPvc;
import org.balajicables.salesmanager.model.Colour;
import org.balajicables.salesmanager.model.CopperDiameter;
import org.balajicables.salesmanager.model.Customer;
import org.balajicables.salesmanager.model.Item;
import org.balajicables.salesmanager.model.ProductionWorkOrder;
import org.balajicables.salesmanager.model.SalesOrder;
import org.balajicables.salesmanager.model.SalesOrderItem;
import org.balajicables.salesmanager.model.StockOut;
import org.balajicables.salesmanager.model.StoreRegister;
import org.balajicables.salesmanager.model.WorkOrderItems;

public class WorkOrderItemsDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long workOrderItemId;
	private String workOrderNo;
	private Long orderDetailId;
	private Integer noOfCoils;
	private Integer qtyPerCoil;
	private Double totalQuantity;
	private String packingType;
	private String pvcGrade;
	private String masterBatch;
	private String toBeLabelled;
	private Integer numberOfCopperStrands;
	private String outerDiameter;
	private String odLabel;
	private String itemDescription;
	private String itemCode;
	private String copperKey;
	private String copperlabel;
	private String mainColour;
	private String innerColour;
	private String cableStd;
	private String customerName;
	private Long customerId;
	private String orderId;
	private Double stockInQty;
	private String stockInStatus;
	private String updatedBy;
	private String updatedTime;
	private String area;
	private Long mainOrderSequence;
	private Long stripeOrderSequence;
	private String poDetails;
	private String remarks;	
	
	public String getRemarks() {
		return remarks;
	}


	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}


	public String getCustomerCode() {
		return customerCode;
	}


	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}


	private String customerCode;

	public String getPoDetails() {
		return poDetails;
	}


	public void setPoDetails(String poDetails) {
		this.poDetails = poDetails;
	}


	public static long getSerialversionuid() {
		return serialVersionUID;
	}


	public String getArea() {
		return area;
	}


	public void setArea(String area) {
		this.area = area;
	}


	public WorkOrderItemsDTO(){
		super();
	}


public Long getWorkOrderItemId() {
		return workOrderItemId;
	}


	public void setWorkOrderItemId(Long workOrderItemId) {
		this.workOrderItemId = workOrderItemId;
	}


	public String getWorkOrderNo() {
		return workOrderNo;
	}


	public void setWorkOrderNo(String workOrderNo) {
		this.workOrderNo = workOrderNo;
	}


	public Long getOrderDetailId() {
		return orderDetailId;
	}


	public void setOrderDetailId(Long orderDetailId) {
		this.orderDetailId = orderDetailId;
	}


	public Integer getNoOfCoils() {
		return noOfCoils;
	}


	public void setNoOfCoils(Integer noOfCoils) {
		this.noOfCoils = noOfCoils;
	}


	public Integer getQtyPerCoil() {
		return qtyPerCoil;
	}


	public void setQtyPerCoil(Integer qtyPerCoil) {
		this.qtyPerCoil = qtyPerCoil;
	}


	public Double getTotalQuantity() {
		return totalQuantity;
	}


	public void setTotalQuantity(Double totalQuantity) {
		this.totalQuantity = totalQuantity;
	}


	public String getPackingType() {
		return packingType;
	}


	public void setPackingType(String packingType) {
		this.packingType = packingType;
	}


	public String getPvcGrade() {
		return pvcGrade;
	}


	public void setPvcGrade(String pvcGrade) {
		this.pvcGrade = pvcGrade;
	}


	public String getMasterBatch() {
		return masterBatch;
	}


	public void setMasterBatch(String masterBatch) {
		this.masterBatch = masterBatch;
	}


	public String getToBeLabelled() {
		return toBeLabelled;
	}


	public void setToBeLabelled(String toBeLabelled) {
		this.toBeLabelled = toBeLabelled;
	}


	public Integer getNumberOfCopperStrands() {
		return numberOfCopperStrands;
	}


	public void setNumberOfCopperStrands(Integer numberOfCopperStrands) {
		this.numberOfCopperStrands = numberOfCopperStrands;
	}


	public String getOuterDiameter() {
		return outerDiameter;
	}


	public void setOuterDiameter(String outerDiameter) {
		this.outerDiameter = outerDiameter;
	}


	public String getOdLabel() {
		return odLabel;
	}


	public void setOdLabel(String odLabel) {
		this.odLabel = odLabel;
	}


	public String getItemDescription() {
		return itemDescription;
	}


	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}


	public String getItemCode() {
		return itemCode;
	}


	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}


	public String getCopperKey() {
		return copperKey;
	}


	public void setCopperKey(String copperKey) {
		this.copperKey = copperKey;
	}


	public String getCopperlabel() {
		return copperlabel;
	}


	public void setCopperlabel(String copperlabel) {
		this.copperlabel = copperlabel;
	}


	public String getMainColour() {
		return mainColour;
	}


	public void setMainColour(String mainColour) {
		this.mainColour = mainColour;
	}


	public String getInnerColour() {
		return innerColour;
	}


	public void setInnerColour(String innerColour) {
		this.innerColour = innerColour;
	}


	public String getCableStd() {
		return cableStd;
	}


	public void setCableStd(String cableStd) {
		this.cableStd = cableStd;
	}


	public String getCustomerName() {
		return customerName;
	}


	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}


	public Long getCustomerId() {
		return customerId;
	}


	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}


	public String getOrderId() {
		return orderId;
	}


	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}


public Double getStockInQty() {
		return stockInQty;
	}


	public void setStockInQty(Double stockInQty) {
		this.stockInQty = stockInQty;
	}


	public String getStockInStatus() {
		return stockInStatus;
	}


	public void setStockInStatus(String stockInStatus) {
		this.stockInStatus = stockInStatus;
	}


public String getUpdatedBy() {
		return updatedBy;
	}


	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}


	public String getUpdatedTime() {
		return updatedTime;
	}


	public void setUpdatedTime(String updatedTime) {
		this.updatedTime = updatedTime;
	}


public Long getMainOrderSequence() {
		return mainOrderSequence;
	}


	public void setMainOrderSequence(Long mainOrderSequence) {
		this.mainOrderSequence = mainOrderSequence;
	}


	public Long getStripeOrderSequence() {
		return stripeOrderSequence;
	}


	public void setStripeOrderSequence(Long stripeOrderSequence) {
		this.stripeOrderSequence = stripeOrderSequence;
	}


public WorkOrderItems getWorkOrderItem() {
	WorkOrderItems workOrderItems = new WorkOrderItems();
	
	ProductionWorkOrder workOrder=new ProductionWorkOrder();
	workOrder.setWorkOrderNo(workOrderNo);
	workOrderItems.setProductionWorkOrder(workOrder);
    	
	SalesOrderItem salesOrderItem=new SalesOrderItem();
	salesOrderItem.setOrderDetailId(orderDetailId);
	
	Item itemobj=new Item();
	itemobj.setNumberOfCopperStrands(numberOfCopperStrands);
	itemobj.setOuterDiameter(outerDiameter);
	itemobj.setOdLabel(odLabel);
	itemobj.setItemDescription(itemDescription);
	itemobj.setItemCode(itemCode);
	Area areaObj=new Area();
	areaObj.setArea(area);
	itemobj.setArea(areaObj);
	
	CopperDiameter cuObj=new CopperDiameter();
	cuObj.setCopperkey(copperKey);
	cuObj.setCopperlabel(copperlabel);
	itemobj.setCopperStrandDiameter(cuObj);
	
	Colour mainColorObj=new Colour();
	mainColorObj.setColor(mainColour);
	mainColorObj.setOrderSequence(mainOrderSequence);
	itemobj.setMainColour(mainColorObj);
	
	Colour stripeColorObj=new Colour();
	stripeColorObj.setColor(innerColour);
	stripeColorObj.setOrderSequence(mainOrderSequence);
	itemobj.setInnerColour(stripeColorObj);
	 
	CableStdPvc cableObj=new CableStdPvc();
	cableObj.setCableStd(cableStd);
	itemobj.setCableStdPvc(cableObj);
	
	Customer customer=new Customer();
	customer.setCustomerId(customerId);
	customer.setCustomerName(customerName);
	customer.setCustomerCode(customerCode);
	
	SalesOrder salesOrder=new SalesOrder();
	salesOrder.setOrderId(orderId);
	salesOrder.setCustomer(customer);
	salesOrder.setPoDetails(poDetails);
	
	
	salesOrderItem.setOrder(salesOrder);
	salesOrderItem.setItem(itemobj);
	workOrderItems.setSalesOrderItem(salesOrderItem);
	
	StoreRegister storeRegister=new StoreRegister();
	storeRegister.setRemarks(remarks);
	
	StockOut stockOut=new StockOut();
	stockOut.setRemarks(remarks);
	
	workOrderItems.setWorkOrderItemId(workOrderItemId);
	workOrderItems.setMasterBatch(masterBatch);
	workOrderItems.setNoOfCoils(noOfCoils);
	workOrderItems.setPackingType(packingType);
	workOrderItems.setPvcGrade(pvcGrade);
	workOrderItems.setQtyPerCoil(qtyPerCoil);
	workOrderItems.setToBeLabelled(toBeLabelled);
	workOrderItems.setStockInQty(stockInQty);
	workOrderItems.setTotalQuantity(totalQuantity);
	workOrderItems.setStockInStatus(stockInStatus);
	
	workOrderItems.setUpdatedBY(updatedBy);
    if(updatedTime!=null){

        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
        java.util.Date parsedDate = null;
    	  try {
    		parsedDate = dateFormat.parse(updatedTime);
    	  } catch (ParseException e) {
    		// TODO Auto-generated catch block
    		e.printStackTrace();
    	 }
        java.sql.Timestamp updatedTimestamp = new java.sql.Timestamp(parsedDate.getTime());
    		
    		
        workOrderItems.setUpdatedTime(updatedTimestamp);
    }	
	
	return workOrderItems;
	}






}