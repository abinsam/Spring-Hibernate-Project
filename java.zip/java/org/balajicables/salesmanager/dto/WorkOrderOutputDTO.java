package org.balajicables.salesmanager.dto;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import org.balajicables.salesmanager.model.ProductionWorkOrder;
import org.balajicables.salesmanager.model.SalesOrderItem;
import org.balajicables.salesmanager.model.WorkOrderOutput;

public class WorkOrderOutputDTO implements Serializable {

	private static final long serialVersionUID = 1L;
	private Long woOutPutId;
	private String workOrderNo;
	private Double netLength;
	private Double grossWeight;
	private Double tareWeight;
	private Double netWeight;
	private Integer noOfStrands;
	private String size;
	private String speed;
	private Long noOfDrums;
	private Double lengthPerDrum;
	private Integer layLength;
	private String annealingPercent;
	private String outerDiameter;
	private String createdTime;
	private String updatedBy;
	private String batchNo;
	private String stockIn;
	private Long orderDetailId;
	private  String remarks;


	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public Long getNoOfDrums() {
		return noOfDrums;
	}

	public void setNoOfDrums(Long noOfDrums) {
		this.noOfDrums = noOfDrums;
	}

	public Double getLengthPerDrum() {
		return lengthPerDrum;
	}

	public void setLengthPerDrum(Double lengthPerDrum) {
		this.lengthPerDrum = lengthPerDrum;
	}

	public Integer getLayLength() {
		return layLength;
	}

	public void setLayLength(Integer layLength) {
		this.layLength = layLength;
	}

	public String getStockIn() {
		return stockIn;
	}

	public void setStockIn(String stockIn) {
		this.stockIn = stockIn;
	}

	public String getBatchNo() {
		return batchNo;
	}

	public void setBatchNo(String batchNo) {
		this.batchNo = batchNo;
	}

	public Long getWoOutPutId() {
		return woOutPutId;
	}

	public void setWoOutPutId(Long woOutPutId) {
		this.woOutPutId = woOutPutId;
	}

	public String getWorkOrderNo() {
		return workOrderNo;
	}

	public void setWorkOrderNo(String workOrderNo) {
		this.workOrderNo = workOrderNo;
	}

	public Double getNetLength() {
		return netLength;
	}

	public void setNetLength(Double netLength) {
		this.netLength = netLength;
	}

	public Double getGrossWeight() {
		return grossWeight;
	}

	public void setGrossWeight(Double grossWeight) {
		this.grossWeight = grossWeight;
	}

	public Double getTareWeight() {
		return tareWeight;
	}

	public void setTareWeight(Double tareWeight) {
		this.tareWeight = tareWeight;
	}

	public Double getNetWeight() {
		return netWeight;
	}

	public void setNetWeight(Double netWeight) {
		this.netWeight = netWeight;
	}

	public Integer getNoOfStrands() {
		return noOfStrands;
	}

	public void setNoOfStrands(Integer noOfStrands) {
		this.noOfStrands = noOfStrands;
	}

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	public String getSpeed() {
		return speed;
	}

	public void setSpeed(String speed) {
		this.speed = speed;
	}

	public String getAnnealingPercent() {
		return annealingPercent;
	}

	public void setAnnealingPercent(String annealingPercent) {
		this.annealingPercent = annealingPercent;
	}

	public String getOuterDiameter() {
		return outerDiameter;
	}

	public void setOuterDiameter(String outerDiameter) {
		this.outerDiameter = outerDiameter;
	}

	public String getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(String createdTime) {
		this.createdTime = createdTime;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public Long getOrderDetailId() {
		return orderDetailId;
	}

	public void setOrderDetailId(Long orderDetailId) {
		this.orderDetailId = orderDetailId;
	}

	public WorkOrderOutput getWorkOrderOutput() {
		WorkOrderOutput workOrderOutput = new WorkOrderOutput();
		workOrderOutput.setWoOutPutId(woOutPutId);

		ProductionWorkOrder pdnWorkOrder = new ProductionWorkOrder();
		pdnWorkOrder.setWorkOrderNo(workOrderNo);
		workOrderOutput.setProductionWorkOrder(pdnWorkOrder);
		SalesOrderItem salesOrderItem=new SalesOrderItem();
		salesOrderItem.setOrderDetailId(orderDetailId);
		workOrderOutput.setSalesOrderItem(salesOrderItem);
		
		workOrderOutput.setNetLength(netLength);
		workOrderOutput.setNetWeight(netWeight);
		workOrderOutput.setTareWeight(tareWeight);
		workOrderOutput.setAnnealingPercent(annealingPercent);
		workOrderOutput.setGrossWeight(grossWeight);
		workOrderOutput.setNoOfStrands(noOfStrands);
		workOrderOutput.setOuterDiameter(outerDiameter);
	
		workOrderOutput.setSize(size);
		workOrderOutput.setSpeed(speed);
		workOrderOutput.setUpdatedBy(updatedBy);
		workOrderOutput.setBatchNo(batchNo);
		workOrderOutput.setStockIn(stockIn);
		if (createdTime != null) {

			SimpleDateFormat dateFormat = new SimpleDateFormat(
					"yyyy-MM-dd HH:mm:ss.SSS");
			java.util.Date parsedDate = null;
			try {
				parsedDate = dateFormat.parse(createdTime);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			java.sql.Timestamp timestamp = new java.sql.Timestamp(
					parsedDate.getTime());

			workOrderOutput.setCreatedTime(timestamp);
		}
		return workOrderOutput;
	}

}
