package org.balajicables.salesmanager.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Immutable;

@Entity
@Table(name="LOOKUP_AREA")
@Immutable
public class Area {
	
	@Id
	@Column(name="AREA" , updatable=false,insertable=false )
	private String area;
	
	@Column(name="AREA_VALUE" , updatable=false,insertable=false)
	private String areaValue;

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public String getAreaValue() {
		return areaValue;
	}

	public void setAreaValue(String areaValue) {
		this.areaValue = areaValue;
	}
	
	
	
}
