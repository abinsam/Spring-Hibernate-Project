package org.balajicables.salesmanager.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="ASSORTED_RATE")
public class AssortedRate implements Serializable {

  private static final long serialVersionUID = 1L;	
 
  @Id @GeneratedValue
	@Column(name = "ASSORTED_RATE_ID")
	private Long assortedRateId;
	
    @Column(name = "CUSTOMER_CODE",nullable=false)
	private String customerCode;
    
    @Column(name = "ASSORTED_TYPE",nullable=false)
	private String assortedType;
    
    @Column(name = "RATE")
	private Float rate;
    
	@Column(name = "UPDATED_TIME")
	private Timestamp updatedTime;

	  
	@Column(name = "BUNDLE_SIZE")
    private Long bundleSize;
	
	
	
	public Long getAssortedRateId() {
		return assortedRateId;
	}

	public void setAssortedRateId(Long assortedRateId) {
		this.assortedRateId = assortedRateId;
	}

	public String getCustomerCode() {
		return customerCode;
	}

	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}

	public String getAssortedType() {
		return assortedType;
	}

	public void setAssortedType(String assortedType) {
		this.assortedType = assortedType;
	}

	public Float getRate() {
		return rate;
	}

	public void setRate(Float rate) {
		this.rate = rate;
	}

	public Timestamp getUpdatedTime() {
		return updatedTime;
	}

	public void setUpdatedTime(Timestamp updatedTime) {
		this.updatedTime = updatedTime;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public Long getBundleSize() {
		return bundleSize;
	}

	public void setBundleSize(Long bundleSize) {
		this.bundleSize = bundleSize;
	}
	
	
	
	
	
}
