package org.balajicables.salesmanager.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="BUNCHING_WORK_ORDER_INPUT")
public class BunchingWOInput {
	@Id @GeneratedValue
	@Column(name = "BUNCH_WO_INPUT_ID")
	private Long bunchWoInputId;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name="WORK_ORDER_NO", referencedColumnName="WORK_ORDER_NO",nullable = false)
	private ProductionWorkOrder productionWorkOrder;

    @ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="ORDER_DETAIL_ID", referencedColumnName="ORDER_DETAIL_ID",nullable = false)
	private SalesOrderItem salesOrderItem;
	
	@Column(name = "SIZE")
	private  String size;
	
	@Column(name = "NET_LENGTH")
	private  Double netLength;
    
	@Column(name = "NO_OF_DRUMS")
	private Long noOfDrums;
    
	@Column(name = "LENGTH_PER_DRUM")
	private Double lengthPerDrum;
	

	@Column(name = "LAY_LENGTH")
	private Integer layLength;
		
	@Column(name = "CUSTOMER_NAME")
	private  String customerName;
		
	@Column(name = "STATUS")
	private  String status;
	
	@Column(name = "UPDATED_BY")
	private  String updatedBy;

	@Column(name = "CREATED_BY")
	private  String createdBy;
	
	@Column(name = "TOTAL_QTY")
	private  Double totalQty;

	
	@Column(name = "SELECT_STATUS")
	private  String selectStatus;
	
	public Long getBunchWoInputId() {
		return bunchWoInputId;
	}

	public void setBunchWoInputId(Long bunchWoInputId) {
		this.bunchWoInputId = bunchWoInputId;
	}

	public ProductionWorkOrder getProductionWorkOrder() {
		return productionWorkOrder;
	}

	public void setProductionWorkOrder(ProductionWorkOrder productionWorkOrder) {
		this.productionWorkOrder = productionWorkOrder;
	}

	public SalesOrderItem getSalesOrderItem() {
		return salesOrderItem;
	}

	public void setSalesOrderItem(SalesOrderItem salesOrderItem) {
		this.salesOrderItem = salesOrderItem;
	}

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	public Double getNetLength() {
		return netLength;
	}

	public void setNetLength(Double netLength) {
		this.netLength = netLength;
	}

	public Long getNoOfDrums() {
		return noOfDrums;
	}

	public void setNoOfDrums(Long noOfDrums) {
		this.noOfDrums = noOfDrums;
	}

	public Double getLengthPerDrum() {
		return lengthPerDrum;
	}

	public void setLengthPerDrum(Double lengthPerDrum) {
		this.lengthPerDrum = lengthPerDrum;
	}

	public Integer getLayLength() {
		return layLength;
	}

	public void setLayLength(Integer layLength) {
		this.layLength = layLength;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Double getTotalQty() {
		return totalQty;
	}

	public void setTotalQty(Double totalQty) {
		this.totalQty = totalQty;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getSelectStatus() {
		return selectStatus;
	}

	public void setSelectStatus(String selectStatus) {
		this.selectStatus = selectStatus;
	}
	  
   
	
}
