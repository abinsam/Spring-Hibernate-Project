package org.balajicables.salesmanager.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.Immutable;

@Entity
@Table(name = "LOOKUP_CABLE_STD_PVC")
@Immutable
public class CableStdPvc {
	@Id
	@Column(name = "CABLE_STD_PVC_KEY" , updatable=false,insertable=false)
	private String cableStdKey;
	
	@Column(name = "CABLE_STD" , updatable=false,insertable=false)
	private String cableStd;

	@Column(name = "PVC_TYPE" , updatable=false,insertable=false)
	private String pvcType;

	public CableStdPvc(String cableStdKey) {
		super();
		this.cableStdKey = cableStdKey;
	}

	public CableStdPvc(){
		super();
	}
	
	@Transient
	public String getDescription() {
		return cableStd + "-" + pvcType;
	}

	public String getCableStdKey() {
		return cableStdKey;
	}

	public void setCableStdKey(String cableStdKey) {
		this.cableStdKey = cableStdKey;
	}

	public String getCableStd() {
		return cableStd;
	}

	public void setCableStd(String cableStd) {
		this.cableStd = cableStd;
	}

	public String getPvcType() {
		return pvcType;
	}

	public void setPvcType(String pvcType) {
		this.pvcType = pvcType;
	}
	
	

}
