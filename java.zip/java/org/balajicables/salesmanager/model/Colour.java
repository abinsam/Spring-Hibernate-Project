package org.balajicables.salesmanager.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Immutable;

@Entity
@Table(name="LOOKUP_COLOUR")
@Immutable
public class Colour {
	
	@Id
	@Column(name="COLOUR_KEY" , updatable=false,insertable=false )
	private String colorKey;
	
	@Column(name="COLOUR" , updatable=false,insertable=false)
	private String color;
	
	@Column(name="ORDER_SEQUENCE" , updatable=false,insertable=false)
	private Long orderSequence;

	public Colour() {
		super();
	}
	public Colour(String colorKey) {
		super();
		this.colorKey = colorKey;
	}
	public String getColorKey() {
		return colorKey;
	}
	public void setColorKey(String colorKey) {
		this.colorKey = colorKey;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public Long getOrderSequence() {
		return orderSequence;
	}
	public void setOrderSequence(Long orderSequence) {
		this.orderSequence = orderSequence;
	}

	
}
