package org.balajicables.salesmanager.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Immutable;

@Entity
@Table(name="LOOKUP_COPPER_DIAMETER")
@Immutable
public class CopperDiameter {
	
	@Id
	@Column(name="COPPER_DIAMETER_KEY" , updatable=false,insertable=false)
	private String copperkey;
	
	@Column(name="COPPER_DIAMETER_LABEL" , updatable=false,insertable=false)
	private String copperlabel;

	public CopperDiameter() {
		super();
	}
	public CopperDiameter(String copperkey) {
		super();
		this.copperkey = copperkey;
	}
	public String getCopperkey() {
		return copperkey;
	}
	public void setCopperkey(String copperkey) {
		this.copperkey = copperkey;
	}
	public String getCopperlabel() {
		return copperlabel;
	}
	public void setCopperlabel(String copperlabel) {
		this.copperlabel = copperlabel;
	}

	
}
