package org.balajicables.salesmanager.model;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;
import javax.persistence.Transient;
import org.balajicables.salesmanager.model.SalesOrder;
import org.codehaus.jackson.annotate.JsonIgnore;

@Entity
@Table(name = "CUSTOMER")
public class Customer implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue
	@Column(name = "CUSTOMER_ID")
	private Long customerId;

	@Column(name = "CUSTOMER_NAME", nullable = false, length = 60)
	private String customerName;

	@Column(name = "CUSTOMER_CODE", length = 20)
	private String customerCode;

	@Column(name = "CONTACT_PERSON")
	private String contactPerson;

	@Column(name = "CONTACT_NO")
	private String contactNo;

	@Column(name = "ALT_CONTACT_NO")
	private String altContactNo;

	@Column(name = "EMAIL")
	private String email;

	@Column(name = "ADDRESS")
	private String address;

	@Column(name = "CITY")
	private String city;

	@Column(name = "STATE")
	private String state;

	@Column(name = "COUNTRY")
	private String country;

	@Column(name = "PINCODE")
	private Integer pincode;

	@Column(name = "VAT_REG_NO")
	private String vatRegNo;

	@Column(name = "CST_REG_NO")
	private String cstRegNo;

	@Column(name = "ECC_NO")
	private String eccNo;

	@Column(name = "TIN_NO")
	private String tinNo;

	@Column(name = "PAN_NO")
	private String panNo;





	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@JsonIgnore
	@OneToMany(mappedBy = "customer", fetch = FetchType.LAZY)
	@OrderBy("orderRecDate ASC")
	private List<SalesOrder> orders;

	@JsonIgnore
	@OneToMany(mappedBy = "customer", fetch = FetchType.LAZY)
	private List<PurchaseOrder> purchaseOrder;

	/*
	 * public Float getSalesTax() { return salesTax; }
	 * 
	 * public void setSalesTax(Float salesTax) { this.salesTax = salesTax; }
	 */
	public List<PurchaseOrder> getPurchaseOrder() {
		return purchaseOrder;
	}

	public void setPurchaseOrder(List<PurchaseOrder> purchaseOrder) {
		this.purchaseOrder = purchaseOrder;
	}

	@Transient
	public String getFullAddress() {
		return address + " " + city + " " + state + " " + country + " "
				+ pincode;
	}

	public Long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerCode() {
		return customerCode;
	}

	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}

	public String getContactPerson() {
		return contactPerson;
	}

	public void setContactPerson(String contactPerson) {
		this.contactPerson = contactPerson;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public String getAltContactNo() {
		return altContactNo;
	}

	public void setAltContactNo(String altContactNo) {
		this.altContactNo = altContactNo;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public Integer getPincode() {
		return pincode;
	}

	public void setPincode(Integer pincode) {
		this.pincode = pincode;
	}

	public String getVatRegNo() {
		return vatRegNo;
	}

	public void setVatRegNo(String vatRegNo) {
		this.vatRegNo = vatRegNo;
	}

	public String getCstRegNo() {
		return cstRegNo;
	}

	public void setCstRegNo(String cstRegNo) {
		this.cstRegNo = cstRegNo;
	}

	public String getEccNo() {
		return eccNo;
	}

	public void setEccNo(String eccNo) {
		this.eccNo = eccNo;
	}

	public String getTinNo() {
		return tinNo;
	}

	public void setTinNo(String tinNo) {
		this.tinNo = tinNo;
	}

	public String getPanNo() {
		return panNo;
	}

	public void setPanNo(String panNo) {
		this.panNo = panNo;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName="
				+ customerName + ", customerCode=" + customerCode
				+ ", contactPerson=" + contactPerson + ", contactNo="
				+ contactNo + ", altContactNo=" + altContactNo + ", email="
				+ email + ", address=" + address + ", city=" + city
				+ ", state=" + state + ", country=" + country + ", pincode="
				+ pincode + ", vatRegNo=" + vatRegNo + ", cstRegNo=" + cstRegNo
				+ ", eccNo=" + eccNo + ", tinNo=" + tinNo + ", panNo=" + panNo
				+ "]";
	}

	public List<SalesOrder> getOrders() {
		return orders;
	}

	public void setOrders(List<SalesOrder> orders) {
		this.orders = orders;
	}


}
