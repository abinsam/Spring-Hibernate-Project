package org.balajicables.salesmanager.model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="CUSTOMER_PART_NO")
public class CustomerPartNo implements Serializable{
	
	private static final long serialVersionUID = 1L;

	
	@Id 
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "PART_NO_ID")
	private Integer partNoId;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name="ITEM_ID", referencedColumnName="ITEM_ID",nullable = false)
    private Item items;
	
	 @ManyToOne
     @JoinColumn(name="CUSTOMER_ID",referencedColumnName="CUSTOMER_ID", nullable = false)
     private Customer customer;
	 
     @Column(name = "PART_NO")
     private String partNo;

	public Integer getPartNoId() {
		return partNoId;
	}

	public void setPartNoId(Integer partNoId) {
		this.partNoId = partNoId;
	}

	public Item getItems() {
		return items;
	}

	public void setItems(Item items) {
		this.items = items;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public String getPartNo() {
		return partNo;
	}

	public void setPartNo(String partNo) {
		this.partNo = partNo;
	}
	
}