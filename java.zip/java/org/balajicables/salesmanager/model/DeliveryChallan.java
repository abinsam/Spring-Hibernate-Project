package org.balajicables.salesmanager.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "DELIVERY_CHALLAN")
public class DeliveryChallan implements Serializable{

	private static final long serialVersionUID = 1L;
	@Id
	@Column(name = "DELIVERY_CHALLAN_NO")
	private  String deliveryChallanNo;
	
	
    @Column(name = "CHALLAN_DATE")
	private Date challanDate;

	@Column(name = "CREATED_TIME")
	private Timestamp createdTime;

	@Column(name = "INVOICE_STATUS")
	private String invoiceStatus;
	
	@Column(name = "INVOICE_NO")
	private String invoiceNo;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "ORDER_ID", referencedColumnName = "ORDER_ID", nullable = false)
	private SalesOrder orders;
	
	@Column(name = "DC_SUPERVISOR")
	private String dcSupervisor;
	
	@Column(name = "STATUS")
	private String status;
	
	@Column(name = "REMARKS")
	private String remarks;
	
	
	public String getDcSupervisor() {
		return dcSupervisor;
	}

	public void setDcSupervisor(String dcSupervisor) {
		this.dcSupervisor = dcSupervisor;
	}

	public String getDeliveryChallanNo() {
		return deliveryChallanNo;
	}

	public void setDeliveryChallanNo(String deliveryChallanNo) {
		this.deliveryChallanNo = deliveryChallanNo;
	}

	public Date getChallanDate() {
		return challanDate;
	}

	public void setChallanDate(Date challanDate) {
		this.challanDate = challanDate;
	}

	public Timestamp getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Timestamp createdTime) {
		this.createdTime = createdTime;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	public String getInvoiceStatus() {
		return invoiceStatus;
	}

	public void setInvoiceStatus(String invoiceStatus) {
		this.invoiceStatus = invoiceStatus;
	}

	public String getInvoiceNo() {
		return invoiceNo;
	}

	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}

	public SalesOrder getOrders() {
		return orders;
	}

	public void setOrders(SalesOrder orders) {
		this.orders = orders;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	
}

	
	
	