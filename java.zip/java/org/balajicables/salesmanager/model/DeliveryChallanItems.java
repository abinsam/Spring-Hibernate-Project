package org.balajicables.salesmanager.model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "DELIVERY_CHALLAN_ITEMS")
public class DeliveryChallanItems implements Serializable{

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "DC_ITEM_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long dcItemId;

	 @ManyToOne
     @JoinColumn(name="DELIVERY_CHALLAN_NO",referencedColumnName="DELIVERY_CHALLAN_NO", nullable = false)
     private DeliveryChallan deliveryChallan;
     
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name="ITEM_ID", referencedColumnName="ITEM_ID",nullable = false)
	private Item  item;
	
	@Column(name = "ITEM_DESC")
	private  String itemDescription;
	
	@Column(name = "ASSORTED_TYPE")
	private  String assortedType;
	
    @Column(name = "NO_OF_ROLLS")
	private Long noOfRolls;
	
    @Column(name = "QTY_PER_ROLL")
	private Double qtyPerRoll;

		
    @Column(name = "TOTAL_QTY")
	private Double totalQty;
   
    @Column(name = "UNITS")
	private String units;
    
    @Column(name = "UNIT_TYPE")
  	private String unitType;

    @Column(name = "RATE")
	private Float rate;
    
    
    @Column(name = "PRODUCT_TYPE_KEY")
    private  String productTypeKey;
    
	public Long getDcItemId() {
		return dcItemId;
	}


	public void setDcItemId(Long dcItemId) {
		this.dcItemId = dcItemId;
	}




	public DeliveryChallan getDeliveryChallan() {
		return deliveryChallan;
	}


	public void setDeliveryChallan(DeliveryChallan deliveryChallan) {
		this.deliveryChallan = deliveryChallan;
	}


	public String getItemDescription() {
		return itemDescription;
	}


	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}


	public Long getNoOfRolls() {
		return noOfRolls;
	}


	public void setNoOfRolls(Long noOfRolls) {
		this.noOfRolls = noOfRolls;
	}


	public Double getQtyPerRoll() {
		return qtyPerRoll;
	}


	public void setQtyPerRoll(Double qtyPerRoll) {
		this.qtyPerRoll = qtyPerRoll;
	}


	public Double getTotalQty() {
		return totalQty;
	}


	public void setTotalQty(Double totalQty) {
		this.totalQty = totalQty;
	}


	public static long getSerialversionuid() {
		return serialVersionUID;
	}


	public String getUnits() {
		return units;
	}


	public void setUnits(String units) {
		this.units = units;
	}


	public Float getRate() {
		return rate;
	}


	public void setRate(Float rate) {
		this.rate = rate;
	}


	public String getAssortedType() {
		return assortedType;
	}


	public void setAssortedType(String assortedType) {
		this.assortedType = assortedType;
	}


	public String getUnitType() {
		return unitType;
	}


	public void setUnitType(String unitType) {
		this.unitType = unitType;
	}


	public String getProductTypeKey() {
		return productTypeKey;
	}


	public void setProductTypeKey(String productTypeKey) {
		this.productTypeKey = productTypeKey;
	}


	public Item getItem() {
		return item;
	}


	public void setItem(Item item) {
		this.item = item;
	}
	
	
}

	
	
	