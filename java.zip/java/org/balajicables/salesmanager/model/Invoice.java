package org.balajicables.salesmanager.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "INVOICE")
public class Invoice implements Serializable{

	private static final long serialVersionUID = 1L;

	
	@Id
	@Column(name = "INVOICE_NO")
	private  String invoiceNo;
	
	
    @Column(name = "INVOICE_DATE")
	private Date invoiceDate;

	@Column(name = "CREATED_TIME")
	private Timestamp createdTime;

    
    @Column(name = "AMOUNT")
    private  Double amount;


    @Column(name = "TRANSPORT_DETAILS")
    private  String transportDetails;
    
    @Column(name = "MODE_OF_TRANSPORT")
    private  String modeOfTransport;
     
	@Column(name = "DELIVERY_CHALLAN_NO")
	private  String deliveryChallanNo;
	
	 @ManyToOne
    @JoinColumn(name="CUSTOMER_ID",referencedColumnName="CUSTOMER_ID", nullable = false)
    private Customer customer;

	 
	 @Column(name = "LR_DETAILS")
		private  String lrDetails;
	 @Column(name = "MAIL_STATUS")
		private  String mailStatus;
	
	 @Column(name = "LRMAIL_STATUS")
		private  String lrmailStatus;
	 
	 @Column(name = "BAG_COUNT")
		private  Long bagCount;
	 
	    @Column(name = "TRANSPORT_CHARGES")
	    private  Double transportCharges;
	    
	    @Column(name = "FINAL_AMOUNT")
	    private  Double finalAmount;
	 
	    @Column(name = "INVOICE_SUPERVISOR")
		private  String invoiceSupervisor;
	 
		@Column(name = "STATUS")
		private  String status;
		
		@Column(name = "REMARKS")
		private  String remarks;
		
		@Column(name = "INVOICE_AMT_IN_WORDS")
		private  String invoiceAmtInWords;
		
	public String getInvoiceAmtInWords() {
			return invoiceAmtInWords;
		}

		public void setInvoiceAmtInWords(String invoiceAmtInWords) {
			this.invoiceAmtInWords = invoiceAmtInWords;
		}

	public String getInvoiceSupervisor() {
			return invoiceSupervisor;
		}

		public void setInvoiceSupervisor(String invoiceSupervisor) {
			this.invoiceSupervisor = invoiceSupervisor;
		}

	public String getInvoiceNo() {
		return invoiceNo;
	}

	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}

	public Date getInvoiceDate() {
		return invoiceDate;
	}

	public void setInvoiceDate(Date invoiceDate) {
		this.invoiceDate = invoiceDate;
	}

	public Timestamp getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Timestamp createdTime) {
		this.createdTime = createdTime;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public String getTransportDetails() {
		return transportDetails;
	}

	public void setTransportDetails(String transportDetails) {
		this.transportDetails = transportDetails;
	}

	public String getModeOfTransport() {
		return modeOfTransport;
	}

	public void setModeOfTransport(String modeOfTransport) {
		this.modeOfTransport = modeOfTransport;
	}

	public String getDeliveryChallanNo() {
		return deliveryChallanNo;
	}

	public void setDeliveryChallanNo(String deliveryChallanNo) {
		this.deliveryChallanNo = deliveryChallanNo;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getLrDetails() {
		return lrDetails;
	}

	public void setLrDetails(String lrDetails) {
		this.lrDetails = lrDetails;
	}

	public String getMailStatus() {
		return mailStatus;
	}

	public void setMailStatus(String mailStatus) {
		this.mailStatus = mailStatus;
	}

	public Long getBagCount() {
		return bagCount;
	}

	public void setBagCount(Long bagCount) {
		this.bagCount = bagCount;
	}

	public Double getTransportCharges() {
		return transportCharges;
	}

	public void setTransportCharges(Double transportCharges) {
		this.transportCharges = transportCharges;
	}

	public Double getFinalAmount() {
		return finalAmount;
	}

	public void setFinalAmount(Double finalAmount) {
		this.finalAmount = finalAmount;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getLrmailStatus() {
		return lrmailStatus;
	}

	public void setLrmailStatus(String lrmailStatus) {
		this.lrmailStatus = lrmailStatus;
	}
  
}

	
	
	