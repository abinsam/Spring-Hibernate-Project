package org.balajicables.salesmanager.model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "INVOICE_ITEMS")
public class InvoiceItems implements Serializable{

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "INVOICE_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long invoiceId;
	
	@Column(name = "ASSORTED_ITEM")
	private  String assortedItem;
	
    @Column(name = "NO_OF_ROLLS")
    private  Long noOfRolls;
/*    
    @Column(name = "QUANTITY")
    private  Double quantity;*/

    @Column(name = "RATE_PER_UNIT")
    private  Float ratePerUnit;

    @Column(name = "TOTAL_VALUE")
    private  Double totalValue;
    
    @Column(name = "RATE_OF_DUTY")
    private  Float rateOfDuty;
    
    @Column(name = "TOTAL_DUTY")
    private  Double totalDuty;
    
    @Column(name = "AMOUNT")
    private  Double amount;

	@Column(name = "EDU_CESS")
    private  Double totalEduCess;
     
    @Column(name = "HIGHER_EDU_CESS")
    private  Double totalHigherEduCess;

    
	@Column(name = "UNITS")
	private  String units;
    
    
    @Column(name = "VAT")
    private  Double totalVat;
    
    @Column(name = "CST")
    private  Double totalCst;
    
    @Column(name = "TOTAL_QUANTITY")
    private  Double totalQuantity;
    
    @Column(name = "PRODUCT_TYPE_KEY")
    private  String productTypeKey;

	 @ManyToOne
    @JoinColumn(name="INVOICE_NO",referencedColumnName="INVOICE_NO", nullable = false)
    private Invoice invoice;


	public Long getInvoiceId() {
		return invoiceId;
	}


	public void setInvoiceId(Long invoiceId) {
		this.invoiceId = invoiceId;
	}


	public String getAssortedItem() {
		return assortedItem;
	}


	public void setAssortedItem(String assortedItem) {
		this.assortedItem = assortedItem;
	}


	public Long getNoOfRolls() {
		return noOfRolls;
	}


	public void setNoOfRolls(Long noOfRolls) {
		this.noOfRolls = noOfRolls;
	}


	public Float getRatePerUnit() {
		return ratePerUnit;
	}


	public void setRatePerUnit(Float ratePerUnit) {
		this.ratePerUnit = ratePerUnit;
	}


	public Double getTotalValue() {
		return totalValue;
	}


	public void setTotalValue(Double totalValue) {
		this.totalValue = totalValue;
	}


	public Float getRateOfDuty() {
		return rateOfDuty;
	}


	public void setRateOfDuty(Float rateOfDuty) {
		this.rateOfDuty = rateOfDuty;
	}


	public Double getTotalDuty() {
		return totalDuty;
	}


	public void setTotalDuty(Double totalDuty) {
		this.totalDuty = totalDuty;
	}


	public Double getAmount() {
		return amount;
	}


	public void setAmount(Double amount) {
		this.amount = amount;
	}


	public Double getTotalEduCess() {
		return totalEduCess;
	}


	public void setTotalEduCess(Double totalEduCess) {
		this.totalEduCess = totalEduCess;
	}


	public Double getTotalHigherEduCess() {
		return totalHigherEduCess;
	}


	public void setTotalHigherEduCess(Double totalHigherEduCess) {
		this.totalHigherEduCess = totalHigherEduCess;
	}


	public String getUnits() {
		return units;
	}


	public void setUnits(String units) {
		this.units = units;
	}


	public Double getTotalVat() {
		return totalVat;
	}


	public void setTotalVat(Double totalVat) {
		this.totalVat = totalVat;
	}


	public Double getTotalQuantity() {
		return totalQuantity;
	}


	public void setTotalQuantity(Double totalQuantity) {
		this.totalQuantity = totalQuantity;
	}


	public Invoice getInvoice() {
		return invoice;
	}


	public void setInvoice(Invoice invoice) {
		this.invoice = invoice;
	}


	public static long getSerialversionuid() {
		return serialVersionUID;
	}


	public Double getTotalCst() {
		return totalCst;
	}


	public void setTotalCst(Double totalCst) {
		this.totalCst = totalCst;
	}


	public String getProductTypeKey() {
		return productTypeKey;
	}


	public void setProductTypeKey(String productTypeKey) {
		this.productTypeKey = productTypeKey;
	}


	


    
	

    
}

	
	
	