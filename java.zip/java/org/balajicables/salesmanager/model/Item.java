package org.balajicables.salesmanager.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;


import org.balajicables.salesmanager.model.SalesOrderItem;

@Entity
@Table(name="ITEM")
public class Item implements Serializable{

	private static final long serialVersionUID = 1L;

	@Id 
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ITEM_ID")
	private long itemId;
	
	@Column(name = "ITEM_CODE",nullable=false)
	private String itemCode;
	
	
	@Column(name = "NUMBER_OF_COPPER_STRANDS", nullable = false)
	private Integer numberOfCopperStrands;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "COPPER_STRAND_DIAMETER", nullable = false)
	private CopperDiameter copperStrandDiameter;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "UNIT", nullable = false)
	private Unit unit;
	
	@Column(name = "OUTER_DIAMETER")
	private String outerDiameter;
	
	@Column(name = "OD_LABEL")
	private String odLabel;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "MAIN_COLOUR_KEY", nullable = false)
	private Colour mainColour;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "INNER_COLOUR_KEY", nullable = false)
	private Colour innerColour;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "PRODUCT_TYPE_KEY", nullable = false)
	private ProductType productType;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "CABLE_STD_PVC_KEY", nullable = false)
	private CableStdPvc cableStdPvc;

	@Column(name = "LAY_LENGTH")
	private Integer layLength;
	
	@Column(name = "LAY_TYPE")
	private String layType;
	
	@Column(name = "ITEM_DESCRIPTION")
	private String itemDescription;
	
	@Column(name = "ITEM_LABEL")
	private String itemLabel;
	
	@Column(name = "SPECIFIC_DETAILS")
	private String specificDetails;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "AREA", nullable = false)
	private Area area;
	
	@Column(name = "ITEM_TYPE")
	private String itemType;
	
	@Column(name = "ASSORTED_TYPE")
	private String assortedType;
	
	@Column(name = "INPUT_SIZE")
	private String inputSize;

	@Column(name = "COPPER_WEIGHT")
	private Double copperWeight;
	
	@Column(name = "PVC_WEIGHT")
	private Double pvcWeight;

	public Unit getUnit() {
		return unit;
	}


	public void setUnit(Unit unit) {
		this.unit = unit;
	}

	public String getAssortedType() {
		return assortedType;
	}


	public void setAssortedType(String assortedType) {
		this.assortedType = assortedType;
	}


	public String getInputSize() {
		return inputSize;
	}


	public void setInputSize(String inputSize) {
		this.inputSize = inputSize;
	}


	public String getItemCode() {
		return itemCode;
	}


	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}
	
	
	
	public String getLayType() {
		return layType;
	}


	public void setLayType(String layType) {
		this.layType = layType;
	}



	
	
	@OneToMany(mappedBy = "items")
	private List<SalesOrderItem> orderDetails;


	public long getItemId() {
		return itemId;
	}


	public void setItemId(long itemId) {
		this.itemId = itemId;
	}


	public Integer getNumberOfCopperStrands() {
		return numberOfCopperStrands;
	}


	public void setNumberOfCopperStrands(Integer numberOfCopperStrands) {
		this.numberOfCopperStrands = numberOfCopperStrands;
	}


	public CopperDiameter getCopperStrandDiameter() {
		return copperStrandDiameter;
	}


	public void setCopperStrandDiameter(CopperDiameter copperStrandDiameter) {
		this.copperStrandDiameter = copperStrandDiameter;
	}


	public String getOuterDiameter() {
		return outerDiameter;
	}


	public void setOuterDiameter(String outerDiameter) {
		this.outerDiameter = outerDiameter;
	}


	public String getOdLabel() {
		return odLabel;
	}


	public void setOdLabel(String odLabel) {
		this.odLabel = odLabel;
	}


	public Colour getMainColour() {
		return mainColour;
	}


	public void setMainColour(Colour mainColour) {
		this.mainColour = mainColour;
	}


	public Colour getInnerColour() {
		return innerColour;
	}


	public void setInnerColour(Colour innerColour) {
		this.innerColour = innerColour;
	}


	public ProductType getProductType() {
		return productType;
	}


	public void setProductType(ProductType productType) {
		this.productType = productType;
	}


	public CableStdPvc getCableStdPvc() {
		return cableStdPvc;
	}


	public void setCableStdPvc(CableStdPvc cableStdPvc) {
		this.cableStdPvc = cableStdPvc;
	}


	public Integer getLayLength() {
		return layLength;
	}


	public void setLayLength(Integer layLength) {
		this.layLength = layLength;
	}


	public String getItemDescription() {
		return itemDescription;
	}


	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}


	public String getItemLabel() {
		return itemLabel;
	}


	public void setItemLabel(String itemLabel) {
		this.itemLabel = itemLabel;
	}


	public String getSpecificDetails() {
		return specificDetails;
	}


	public void setSpecificDetails(String specificDetails) {
		this.specificDetails = specificDetails;
	}


	public List<SalesOrderItem> getOrderDetails() {
		return orderDetails;
	}


	public void setOrderDetails(List<SalesOrderItem> orderDetails) {
		this.orderDetails = orderDetails;
	}

	
	public Area getArea() {
		return area;
	}


	public void setArea(Area area) {
		this.area = area;
	}


	public String getItemType() {
		return itemType;
	}


	public void setItemType(String itemType) {
		this.itemType = itemType;
	}


	public Double getCopperWeight() {
		return copperWeight;
	}


	public void setCopperWeight(Double copperWeight) {
		this.copperWeight = copperWeight;
	}


	public Double getPvcWeight() {
		return pvcWeight;
	}


	public void setPvcWeight(Double pvcWeight) {
		this.pvcWeight = pvcWeight;
	}

}
