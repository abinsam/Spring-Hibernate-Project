package org.balajicables.salesmanager.model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "LABEL_REPORT")
public class LabelReport implements Serializable{

	private static final long serialVersionUID = 1L;

	@Id @GeneratedValue
	@Column(name = "LABEL_REPORT_ID")
	private Long labelReportId;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name="WO_ITEM_ID", referencedColumnName="WO_ITEM_ID",nullable = false)
	private WorkOrderItems workOrderItems;
	
	
	@Column(name = "ITEM_DESCRIPTION")
	private String itemDescription ;
	
	@Column(name = "SALES_ORDER_NO")
	private String salesOrderNo ;
	
	
	@Column(name = "PO_NO")
	private String poNo  ;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name="CUSTOMER_ID", referencedColumnName="CUSTOMER_ID",nullable = false)
	private Customer customer;
	
	@Column(name = "WORK_ORDER_NO")
	private String workOrderNo  ;
	
	
	@Column(name = "BATCH_NO")
	private String batchNo  ;
	

	@Column(name = "QTY_PER_COIL")
	private Integer qtyPerCoil;

	@Column(name = "TOTAL_QTY")
	private Double totalQuantity;
	
	@Column(name = "PART_NO")
	private String partNo;

	
	@Column(name = "CABLE_STD")
	private String cableStd  ;
	
	
	@Column(name = "AREA")
	private String area ;
	@Column(name = "BUNDLE_ID")
	private String bundleId  ;

	public Long getLabelReportId() {
		return labelReportId;
	}


	public void setLabelReportId(Long labelReportId) {
		this.labelReportId = labelReportId;
	}


	public WorkOrderItems getWorkOrderItems() {
		return workOrderItems;
	}


	public void setWorkOrderItems(WorkOrderItems workOrderItems) {
		this.workOrderItems = workOrderItems;
	}


	public String getItemDescription() {
		return itemDescription;
	}


	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}


	public String getSalesOrderNo() {
		return salesOrderNo;
	}


	public void setSalesOrderNo(String salesOrderNo) {
		this.salesOrderNo = salesOrderNo;
	}


	public String getPoNo() {
		return poNo;
	}


	public void setPoNo(String poNo) {
		this.poNo = poNo;
	}


	public Customer getCustomer() {
		return customer;
	}


	public void setCustomer(Customer customer) {
		this.customer = customer;
	}


	public String getWorkOrderNo() {
		return workOrderNo;
	}


	public void setWorkOrderNo(String workOrderNo) {
		this.workOrderNo = workOrderNo;
	}


	public String getBatchNo() {
		return batchNo;
	}


	public void setBatchNo(String batchNo) {
		this.batchNo = batchNo;
	}


	public Integer getQtyPerCoil() {
		return qtyPerCoil;
	}


	public void setQtyPerCoil(Integer qtyPerCoil) {
		this.qtyPerCoil = qtyPerCoil;
	}


	public Double getTotalQuantity() {
		return totalQuantity;
	}


	public void setTotalQuantity(Double totalQuantity) {
		this.totalQuantity = totalQuantity;
	}




	public String getPartNo() {
		return partNo;
	}


	public void setPartNo(String partNo) {
		this.partNo = partNo;
	}


	public String getCableStd() {
		return cableStd;
	}


	public void setCableStd(String cableStd) {
		this.cableStd = cableStd;
	}


	public String getArea() {
		return area;
	}


	public void setArea(String area) {
		this.area = area;
	}


	public static long getSerialversionuid() {
		return serialVersionUID;
	}


	public String getBundleId() {
		return bundleId;
	}


	public void setBundleId(String bundleId) {
		this.bundleId = bundleId;
	}
	
	
	


}	
	

	
	
	