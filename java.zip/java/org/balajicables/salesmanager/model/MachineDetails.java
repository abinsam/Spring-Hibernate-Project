package org.balajicables.salesmanager.model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="MACHINE_DETAILS")
public class MachineDetails implements Serializable {

  private static final long serialVersionUID = 1L;	
	
	@Id @GeneratedValue
	@Column(name = "MACHINE_NO" , updatable=false,insertable=false)
	private Long machineNo;

	@Column(name = "DESCRIPTION", updatable=false,insertable=false)
	private String description  ;

	@Column(name = "MACHINE_NAME", updatable=false,insertable=false)
	private String machineName;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name="PROCESS_ID", referencedColumnName="PROCESS_ID",nullable = false)
	private  ProductionProcess process;
	
	public String getMachineName() {
		return machineName;
	}

	public void setMachineName(String machineName) {
		this.machineName = machineName;
	}

	public ProductionProcess getProcess() {
		return process;
	}

	public void setProcess(ProductionProcess process) {
		this.process = process;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public Long getMachineNo() {
		return machineNo;
	}

	public void setMachineNo(Long machineNo) {
		this.machineNo = machineNo;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	

}
