package org.balajicables.salesmanager.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="MWD_WO_INPUT")
public class MwdWorkOrder {
	

	@Id @GeneratedValue
	@Column(name = "MWD_WO_INPUT_ID")
	private Long mwdWoInputId;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name="WORK_ORDER_NO", referencedColumnName="WORK_ORDER_NO",nullable = false)
	private  ProductionWorkOrder productionWorkOrder;

	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="ORDER_DETAIL_ID", referencedColumnName="ORDER_DETAIL_ID",nullable = false)
	private SalesOrderItem salesOrderItem;
	
	@Column(name = "SIZE")
	private  String size;
	
	@Column(name = "NET_LENGTH")
	private  Double netLength;
		
	@Column(name = "ANNEALING_PERCENT")
	private String anealingPercent;
	
	@Column(name = "STATUS")
	private String status;
	
	@Column(name = "CUSTOMER_NAME")
	private String  customerName;

	@Column(name = "UPDATED_BY")
	private  String updatedBy;
	
	@Column(name = "CREATED_BY")
	private  String createdBy;
	
	@Column(name = "TOTAL_QTY")
	private  Double totalQty;
	
	@Column(name = "SELECT_STATUS")
	private  String selectStatus;
	
	
	public SalesOrderItem getSalesOrderItem() {
		return salesOrderItem;
	}

	public void setSalesOrderItem(SalesOrderItem salesOrderItem) {
		this.salesOrderItem = salesOrderItem;
	}


	public Double getTotalQty() {
		return totalQty;
	}

	public void setTotalQty(Double totalQty) {
		this.totalQty = totalQty;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Long getMwdWoInputId() {
		return mwdWoInputId;
	}

	public void setMwdWoInputId(Long mwdWoInputId) {
		this.mwdWoInputId = mwdWoInputId;
	}

	public ProductionWorkOrder getProductionWorkOrder() {
		return productionWorkOrder;
	}

	public void setProductionWorkOrder(ProductionWorkOrder productionWorkOrder) {
		this.productionWorkOrder = productionWorkOrder;
	}

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	public Double getNetLength() {
		return netLength;
	}

	public void setNetLength(Double netLength) {
		this.netLength = netLength;
	}

	public String getAnealingPercent() {
		return anealingPercent;
	}

	public void setAnealingPercent(String anealingPercent) {
		this.anealingPercent = anealingPercent;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public String getSelectStatus() {
		return selectStatus;
	}

	public void setSelectStatus(String selectStatus) {
		this.selectStatus = selectStatus;
	}
	
	
	
}
