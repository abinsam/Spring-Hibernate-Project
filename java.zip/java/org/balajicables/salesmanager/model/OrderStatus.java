package org.balajicables.salesmanager.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Immutable;

@Entity
@Table(name="ORDER_STATUS")
@Immutable
public class OrderStatus {
	@Id
	@Column(name="ORDER_STATUS_ID", updatable=false,insertable=false)
	private Integer orderStatusId;
	
	@Column(name="STATUS", updatable=false, insertable=false)
	private String status;

	public Integer getOrderStatusId() {
		return orderStatusId;
	}

	public void setOrderStatusId(Integer orderStatusId) {
		this.orderStatusId = orderStatusId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}



}
