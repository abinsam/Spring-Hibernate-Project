package org.balajicables.salesmanager.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "PACKING_SLIP")
public class PackingSlip implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "PACKING_SLIP_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer packingSlipId;
	
	 @ManyToOne
     @JoinColumn(name="DELIVERY_CHALLAN_NO",referencedColumnName="DELIVERY_CHALLAN_NO", nullable = false)
     private DeliveryChallan deliveryChallan;

	

	@Column(name = "PACKING_SLIP_NO")
	private  String packingSlipNo;
	
	
    @Column(name = "INPUT_SIZE")
	private String inputSize;

	@Column(name = "NO_OF_ROLLS")
	private Integer noOfRolls;

	@Column(name = "QUANTITY_PER_ROLL")
	private Double quanityPerRoll;
	
	@Column(name = "TOTAL_QUANITY")
	private Double totalQuantity;
	
	@Column(name = "WEIGHT")
	private Double weight;
	
	@Column(name = "UNITS")
	private String units;
	
	@Column(name = "UNIT_TYPE")
	private String unitType;

	public Integer getPackingSlipId() {
		return packingSlipId;
	}

	public void setPackingSlipId(Integer packingSlipId) {
		this.packingSlipId = packingSlipId;
	}




	public DeliveryChallan getDeliveryChallan() {
		return deliveryChallan;
	}

	public void setDeliveryChallan(DeliveryChallan deliveryChallan) {
		this.deliveryChallan = deliveryChallan;
	}

	public String getPackingSlipNo() {
		return packingSlipNo;
	}

	public void setPackingSlipNo(String packingSlipNo) {
		this.packingSlipNo = packingSlipNo;
	}

	public String getInputSize() {
		return inputSize;
	}

	public void setInputSize(String inputSize) {
		this.inputSize = inputSize;
	}

	public Integer getNoOfRolls() {
		return noOfRolls;
	}

	public void setNoOfRolls(Integer noOfRolls) {
		this.noOfRolls = noOfRolls;
	}

	public Double getQuanityPerRoll() {
		return quanityPerRoll;
	}

	public void setQuanityPerRoll(Double quanityPerRoll) {
		this.quanityPerRoll = quanityPerRoll;
	}

	public Double getTotalQuantity() {
		return totalQuantity;
	}

	public void setTotalQuantity(Double totalQuantity) {
		this.totalQuantity = totalQuantity;
	}

	public Double getWeight() {
		return weight;
	}

	public void setWeight(Double weight) {
		this.weight = weight;
	}

	public String getUnits() {
		return units;
	}

	public void setUnits(String units) {
		this.units = units;
	}

	public String getUnitType() {
		return unitType;
	}

	public void setUnitType(String unitType) {
		this.unitType = unitType;
	}

}
