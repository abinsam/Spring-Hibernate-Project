package org.balajicables.salesmanager.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "LOOKUP_PRODUCT_TYPE")
public class ProductType {

	@Id
	@Column(name="PRODUCT_TYPE_KEY" , updatable=false,insertable=false)
	private String productKey;
	
	@Column(name="PRODUCT_TYPE" , updatable=false,insertable=false)
	private String productType;

	@Column(name="RAW_MATERIAL" , updatable=false,insertable=false)
	private String rawMaterial;
	
	@Column(name="PROCESS_TYPE" , updatable=false,insertable=false)
	private String processType;
	
	@Column(name="TARIFF_NO" , updatable=false,insertable=false)
	private String tariffNo;
	
	@Column(name="TARIFF_NAME" , updatable=false,insertable=false)
	private String tariffName;

	public String getTariffNo() {
		return tariffNo;
	}

	public void setTariffNo(String tariffNo) {
		this.tariffNo = tariffNo;
	}

	public String getTariffName() {
		return tariffName;
	}

	public void setTariffName(String tariffName) {
		this.tariffName = tariffName;
	}

	public String getProductKey() {
		return productKey;
	}

	public void setProductKey(String productKey) {
		this.productKey = productKey;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public String getRawMaterial() {
		return rawMaterial;
	}

	public void setRawMaterial(String rawMaterial) {
		this.rawMaterial = rawMaterial;
	}

	public String getProcessType() {
		return processType;
	}

	public void setProcessType(String processType) {
		this.processType = processType;
	}


	
}
