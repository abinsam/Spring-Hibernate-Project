package org.balajicables.salesmanager.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Immutable;

@Entity
@Table(name="PRODUCTION_PROCESS")
@Immutable
public class ProductionProcess {
	@Id
	@Column(name="PROCESS_ID", updatable=false,insertable=false)
	private Integer processId;
	
	@Column(name="PROCESS_TYPE", updatable=false, insertable=false)
	private String processType;

	public Integer getProcessId() {
		return processId;
	}

	public void setProcessId(Integer processId) {
		this.processId = processId;
	}

	public String getProcessType() {
		return processType;
	}

	public void setProcessType(String processType) {
		this.processType = processType;
	}


}
