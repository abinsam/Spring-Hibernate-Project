package org.balajicables.salesmanager.model;

import java.sql.Time;
import java.sql.Timestamp;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Immutable;

@Entity
@Table(name="PRODUCTION_WORK_ORDER")
@Immutable
public class ProductionWorkOrder {
	

	@Id
	@Column(name = "WORK_ORDER_NO")
	private String workOrderNo;

	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name="PROCESS_ID", referencedColumnName="PROCESS_ID",nullable = false)
	private  ProductionProcess process;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name="MACHINE_NO", referencedColumnName="MACHINE_NO",nullable = false)
	private MachineDetails machine;

	
	@Column(name = "START_DATE")
	private  Date startDate;
		
	@Column(name = "START_TIME")
	private Time startTime;
	
	@Column(name = "END_DATE")
	private Date endDate;
	
	@Column(name = "END_TIME")
	private Time endTime;
	
	@Column(name = "STATUS")
	private  String status;
	
	@Column(name = "CREATED_BY")
	private  String createdBy;

	@Column(name = "CREATED_TIME")
	private Timestamp createdTime;
	
	@Column(name = "INPUT_WEIGHT")
	private Double inputWeight;
	
	@Column(name = "OUTPUT_WEIGHT")
	private Double outputWeight;
	
	@Column(name = "BALANCE_WEIGHT")
	private Double balanceWeight;
	
	
	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	
	
	public Timestamp getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Timestamp createdTime) {
		this.createdTime = createdTime;
	}

	public String getWorkOrderNo() {
		return workOrderNo;
	}

	public void setWorkOrderNo(String workOrderNo) {
		this.workOrderNo = workOrderNo;
	}

	public ProductionProcess getProcess() {
		return process;
	}

	public void setProcess(ProductionProcess process) {
		this.process = process;
	}

	public MachineDetails getMachine() {
		return machine;
	}

	public void setMachine(MachineDetails machine) {
		this.machine = machine;
	}


	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Time getStartTime() {
		return startTime;
	}

	public void setStartTime(Time startTime) {
		this.startTime = startTime;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public Time getEndTime() {
		return endTime;
	}

	public void setEndTime(Time endTime) {
		this.endTime = endTime;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Double getInputWeight() {
		return inputWeight;
	}

	public void setInputWeight(Double inputWeight) {
		this.inputWeight = inputWeight;
	}

	public Double getOutputWeight() {
		return outputWeight;
	}

	public void setOutputWeight(Double outputWeight) {
		this.outputWeight = outputWeight;
	}

	public Double getBalanceWeight() {
		return balanceWeight;
	}

	public void setBalanceWeight(Double balanceWeight) {
		this.balanceWeight = balanceWeight;
	}

}
