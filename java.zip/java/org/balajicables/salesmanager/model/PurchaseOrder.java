package org.balajicables.salesmanager.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "PURCHASE_ORDER")
public class PurchaseOrder implements Serializable{

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "PO_NO")
	private String poNo;
	

	 @ManyToOne(fetch=FetchType.EAGER)
     @JoinColumn(name="CUSTOMER_ID",referencedColumnName="CUSTOMER_ID", nullable = false)
     private Customer customer;
	
	 @OneToMany(mappedBy = "purchaseOrder",  fetch= FetchType.LAZY)
	 private List<PurchaseOrderItem> poItems;
	
	 @Column(name = "PO_DATE")
	 private Date poDate;

	@Column(name = "PO_STATUS")
	private String poStatus;
	
	@Column(name = "CREATED_BY")
	private String createdBy;

	@Column(name = "CREATED_TIME")
	private Timestamp createdTime;
	
	
	@Column(name = "UPDATED_BY")
	private String updatedBy;

	@Column(name = "UPDATED_TIME")
	private Timestamp updatedTime;
	
	@Column(name = "QUANTITY")
	private Double quantity;
	
	@Column(name = "BALANCE_QUANTITY")
	private Double balanceQuantity;
	
	
	@Column(name = "TOTAL_PRICE")
	private Double totalPrice;
	
	@Column(name = "EXCISE_DUTY")
	private Double exciseDuty;
	
	@Column(name = "CST_VALUE")
	private Double cstValue;
	
	@Column(name = "AMOUNT")
	private Double amount;
	
	@Column(name = "MAIL_SENT")
	private String mailSent;
	
	public Double getBalanceQuantity() {
		return balanceQuantity;
	}

	public void setBalanceQuantity(Double balanceQuantity) {
		this.balanceQuantity = balanceQuantity;
	}

	public Double getQuantity() {
		return quantity;
	}

	public void setQuantity(Double quantity) {
		this.quantity = quantity;
	}

	public Timestamp getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Timestamp createdTime) {
		this.createdTime = createdTime;
	}

	public String getPoStatus() {
		return poStatus;
	}

	public void setPoStatus(String poStatus) {
		this.poStatus = poStatus;
	}

	public String getPoNo() {
		return poNo;
	}

	public void setPoNo(String poNo) {
		this.poNo = poNo;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public List<PurchaseOrderItem> getPoItems() {
		return poItems;
	}

	public void setPoItems(List<PurchaseOrderItem> poItems) {
		this.poItems = poItems;
	}

	public Date getPoDate() {
		return poDate;
	}

	public void setPoDate(Date poDate) {
		this.poDate = poDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Timestamp getUpdatedTime() {
		return updatedTime;
	}

	public void setUpdatedTime(Timestamp updatedTime) {
		this.updatedTime = updatedTime;
	}

	public Double getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(Double totalPrice) {
		this.totalPrice = totalPrice;
	}

	public Double getExciseDuty() {
		return exciseDuty;
	}

	public void setExciseDuty(Double exciseDuty) {
		this.exciseDuty = exciseDuty;
	}

	public Double getCstValue() {
		return cstValue;
	}

	public void setCstValue(Double cstValue) {
		this.cstValue = cstValue;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public String getMailSent() {
		return mailSent;
	}

	public void setMailSent(String mailSent) {
		this.mailSent = mailSent;
	}
	 
}	
	

	
	
	