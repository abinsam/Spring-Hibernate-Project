package org.balajicables.salesmanager.model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@SuppressWarnings("serial")
@Entity
@Table(name = "PO_ITEM_DETAILS")
public class PurchaseOrderItem implements Serializable{

	@Id @GeneratedValue
	@Column(name = "PO_ITEM_ID")
	private Long purchaseOrderItemId;
	
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name="PO_NO", referencedColumnName="PO_NO",nullable = false)
	private PurchaseOrder purchaseOrder;

	@Column(name = "DESCRIPTION")
	private String description;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name="ITEM_ID", referencedColumnName="ITEM_ID",nullable = false)
	private Item  item;

	@Column(name = "QUANTITY")
	private Double quantity;

	
	@Column(name = "RATE")
	private Float rate;
	
	@Column(name = "Price")
	private Double price;

	@Column(name = "STOCKED_IN_STATUS")
	private int status;
	
	@Column(name = "BALANCE_QUANTITY")
	private Double balanceQty;
	
	
	public Double getBalanceQty() {
		return balanceQty;
	}

	public void setBalanceQty(Double balanceQty) {
		this.balanceQty = balanceQty;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public Long getPurchaseOrderItemId() {
		return purchaseOrderItemId;
	}

	public void setPurchaseOrderItemId(Long purchaseOrderItemId) {
		this.purchaseOrderItemId = purchaseOrderItemId;
	}

	public PurchaseOrder getPurchaseOrder() {
		return purchaseOrder;
	}

	public void setPurchaseOrder(PurchaseOrder purchaseOrder) {
		this.purchaseOrder = purchaseOrder;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Item getItem() {
		return item;
	}

	public void setItem(Item item) {
		this.item = item;
	}

	public Double getQuantity() {
		return quantity;
	}

	public void setQuantity(Double quantity) {
		this.quantity = quantity;
	}



	public Float getRate() {
		return rate;
	}

	public void setRate(Float rate) {
		this.rate = rate;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

}	