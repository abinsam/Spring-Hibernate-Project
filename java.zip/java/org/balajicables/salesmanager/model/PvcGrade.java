package org.balajicables.salesmanager.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "PVC_GRADE")
public class PvcGrade implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "PVC_GRADE_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long pvcGradeId;
	
	@Column(name = "GRADE_NAME")
	private  String grade;
	

	@Column(name = "ITEM_CODE")
	private  String itemCode;


	public Long getPvcGradeId() {
		return pvcGradeId;
	}


	public void setPvcGradeId(Long pvcGradeId) {
		this.pvcGradeId = pvcGradeId;
	}


	public String getGrade() {
		return grade;
	}


	public void setGrade(String grade) {
		this.grade = grade;
	}


	public String getItemCode() {
		return itemCode;
	}


	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}


	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
}
