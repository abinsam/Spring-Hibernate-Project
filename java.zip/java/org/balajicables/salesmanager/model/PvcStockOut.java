package org.balajicables.salesmanager.model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "PVC_STOCK_OUT")
public class PvcStockOut implements Serializable{

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "PVC_STOCK_OUT_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long pvcStockOutID;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name="WORK_ORDER_NO", referencedColumnName="WORK_ORDER_NO",nullable = false)
	private ProductionWorkOrder productionWorkOrder;
	
	@Column(name = "QUANTITY")
	private  Double quantity;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name="ITEM_ID", referencedColumnName="ITEM_ID",nullable = false)
	private Item item;
	

	@Column(name = "BATCH")
	private  String batch;

	public Long getPvcStockOutID() {
		return pvcStockOutID;
	}



	public void setPvcStockOutID(Long pvcStockOutID) {
		this.pvcStockOutID = pvcStockOutID;
	}



	public ProductionWorkOrder getProductionWorkOrder() {
		return productionWorkOrder;
	}



	public void setProductionWorkOrder(ProductionWorkOrder productionWorkOrder) {
		this.productionWorkOrder = productionWorkOrder;
	}



	public Double getQuantity() {
		return quantity;
	}



	public void setQuantity(Double quantity) {
		this.quantity = quantity;
	}



	public String getBatch() {
		return batch;
	}



	public void setBatch(String batch) {
		this.batch = batch;
	}



	public static long getSerialversionuid() {
		return serialVersionUID;
	}



	public Item getItem() {
		return item;
	}



	public void setItem(Item item) {
		this.item = item;
	}
	
	
}	
	

	
	
	