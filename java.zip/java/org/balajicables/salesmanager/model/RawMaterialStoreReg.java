package org.balajicables.salesmanager.model;

import java.io.Serializable;
import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "RAW_MATERIAL_STORE_REG")
public class RawMaterialStoreReg implements Serializable{

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "RW_STORE_REG_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long rwStoreRegId;
	
	@ManyToOne
	@JoinColumn(name="STORE_ID", referencedColumnName="STORE_ID",nullable = false)
	private  Store store;
	
	@ManyToOne
	@JoinColumn(name="PO_ITEM_ID", referencedColumnName="PO_ITEM_ID",nullable = false)
	private  PurchaseOrderItem purchaseOrderItem;
		
	
	@Column(name = "SUPERVISOR_NAME")
	private  String supervisor;

	@Column(name = "QC_SUPERVISOR")
	private  String qcSupervisor;
	
	@Column(name = "REJECT_STATUS")
	private  String rejectStatus;
	
	@Column(name = "DATE_TIME")
	private Timestamp dateTime;
	
		
	@Column(name = "QC_STATUS")
	private  String qcStatus;

	@Column(name = "REMARKS")
	private  String remarks;
	
	@Column(name = "GROSS_WEIGHT")
	private  Double grossWeight;

	@Column(name = "NET_WEIGHT")
	private  Double netWeight;

	@Column(name = "TARE_WEIGHT")
	private  Double tareWeight;

	@Column(name = "BATCH_NO")
	private  String batchNo;
	
	@Column(name = "NO_OF_BAGS")
	private  Integer noOfBags;
	
	@Column(name = "TOTAL_QTY")
	private  double totalQty;
	
	@Column(name = "SEND_TO_RBD")
	private  String sendToRbd;

	@Column(name = "STOCK_IN_STATUS")
	private  String stockInStatus;
	
	
	@Column(name = "STOCK_OUT_QTY")
	private  Double stockOutQty;

	public String getBatchNo() {
		return batchNo;
	}

	public void setBatchNo(String batchNo) {
		this.batchNo = batchNo;
	}

	public Integer getNoOfBags() {
		return noOfBags;
	}

	public void setNoOfBags(Integer noOfBags) {
		this.noOfBags = noOfBags;
	}

	public double getTotalQty() {
		return totalQty;
	}

	public void setTotalQty(double totalQty) {
		this.totalQty = totalQty;
	}

	
	public String getSendToRbd() {
		return sendToRbd;
	}

	public void setSendToRbd(String sendToRbd) {
		this.sendToRbd = sendToRbd;
	}

	public Long getRwStoreRegId() {
		return rwStoreRegId;
	}

	public void setRwStoreRegId(Long rwStoreRegId) {
		this.rwStoreRegId = rwStoreRegId;
	}

	public Store getStore() {
		return store;
	}

	public void setStore(Store store) {
		this.store = store;
	}

	public PurchaseOrderItem getPurchaseOrderItem() {
		return purchaseOrderItem;
	}

	public void setPurchaseOrderItem(PurchaseOrderItem purchaseOrderItem) {
		this.purchaseOrderItem = purchaseOrderItem;
	}

	public String getSupervisor() {
		return supervisor;
	}

	public void setSupervisor(String supervisor) {
		this.supervisor = supervisor;
	}

	public Timestamp getDateTime() {
		return dateTime;
	}

	public void setDateTime(Timestamp dateTime) {
		this.dateTime = dateTime;
	}

	public String getQcStatus() {
		return qcStatus;
	}

	public void setQcStatus(String qcStatus) {
		this.qcStatus = qcStatus;
	}

	public Double getGrossWeight() {
		return grossWeight;
	}

	public void setGrossWeight(Double grossWeight) {
		this.grossWeight = grossWeight;
	}

	public Double getNetWeight() {
		return netWeight;
	}

	public void setNetWeight(Double netWeight) {
		this.netWeight = netWeight;
	}

	public Double getTareWeight() {
		return tareWeight;
	}

	public void setTareWeight(Double tareWeight) {
		this.tareWeight = tareWeight;
	}

	public String getStockInStatus() {
		return stockInStatus;
	}

	public void setStockInStatus(String stockInStatus) {
		this.stockInStatus = stockInStatus;
	}

	public Double getStockOutQty() {
		return stockOutQty;
	}

	public void setStockOutQty(Double stockOutQty) {
		this.stockOutQty = stockOutQty;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getQcSupervisor() {
		return qcSupervisor;
	}

	public void setQcSupervisor(String qcSupervisor) {
		this.qcSupervisor = qcSupervisor;
	}

	public String getRejectStatus() {
		return rejectStatus;
	}

	public void setRejectStatus(String rejectStatus) {
		this.rejectStatus = rejectStatus;
	}

	
	
}	
	

	
	
	