package org.balajicables.salesmanager.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Immutable;

@Entity
@Table(name="RBD_WO_INPUT")
@Immutable
public class RbdWorkOrderInput {
	
	@Id @GeneratedValue
	@Column(name = "RBD_WO_INPUT_ID")
	private Long rbdWoInputId;
	
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name="WORK_ORDER_NO", referencedColumnName="WORK_ORDER_NO",nullable = false)
	private  ProductionWorkOrder productionWorkOrder;
	
	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name="RW_STORE_REG_ID", referencedColumnName="RW_STORE_REG_ID",nullable = false)
	private RawMaterialStoreReg rawMaterialStoreReg;

	
	@Column(name = "GROSS_WEIGHT")
	private  Double grossWeight;
	
	@Column(name = "NET_WEIGHT")
	private  Double netWeight;
		
	@Column(name = "TARE_WEIGHT")
	private  Double tareWeight;
	
	@Column(name = "UPDATED_BY")
	private  String updatedBy;

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Long getRbdWoInputId() {
		return rbdWoInputId;
	}

	public void setRbdWoInputId(Long rbdWoInputId) {
		this.rbdWoInputId = rbdWoInputId;
	}

	public ProductionWorkOrder getProductionWorkOrder() {
		return productionWorkOrder;
	}

	public void setProductionWorkOrder(ProductionWorkOrder productionWorkOrder) {
		this.productionWorkOrder = productionWorkOrder;
	}

	public RawMaterialStoreReg getRawMaterialStoreReg() {
		return rawMaterialStoreReg;
	}

	public void setRawMaterialStoreReg(RawMaterialStoreReg rawMaterialStoreReg) {
		this.rawMaterialStoreReg = rawMaterialStoreReg;
	}

	public Double getGrossWeight() {
		return grossWeight;
	}

	public void setGrossWeight(Double grossWeight) {
		this.grossWeight = grossWeight;
	}

	public Double getNetWeight() {
		return netWeight;
	}

	public void setNetWeight(Double netWeight) {
		this.netWeight = netWeight;
	}

	public Double getTareWeight() {
		return tareWeight;
	}

	public void setTareWeight(Double tareWeight) {
		this.tareWeight = tareWeight;
	}
	
	
}
