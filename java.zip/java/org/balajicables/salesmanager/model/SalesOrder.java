package org.balajicables.salesmanager.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.balajicables.salesmanager.model.Customer;

@Entity
@Table(name="SALES_ORDER")
public class SalesOrder implements Serializable {

  private static final long serialVersionUID = 1L;	
	@Id
   // @GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ORDER_ID")
	private String orderId;

	@Column(name = "ORDER_RECEIVED_DATE")
	private Date orderRecDate;
	
	@Column(name = "ORDER_ACCEPTANCE_DATE")
	private Date orderAcceptanceDate;
	
	@Column(name = "PO_DETAILS")
	private String poDetails;
	
	@Column(name = "MODE_OF_RECEIPT")
	private String modeOfReceipt;
	
	@Column(name = "ORDER_DELIVERY_DATE")
	private Date orderDeliveryDate;
    
	@Column(name = "CREATED_TIME")
	private Timestamp createdTime;

	@Column(name = "TARGET_DATE")
	private Date targetDate;
	
	@Column(name = "CREATED_BY")
	private String createdBy;
	
	@Column(name = "UPDATED_BY")
	private String updatedBy;
	
	@Column(name = "INPUT_QUANTITY")
	private Double inputQuantity;
	
	@Column(name = "MAIL_STATUS")
	private String mailStatus;
	
	@Column(name = "LME_DETAILS")
	private String lmeDetails;
	
	@Column(name = "UPDATED_TIME")
	private Timestamp updatedTime;
	
	 @ManyToOne
     @JoinColumn(name="CUSTOMER_ID",referencedColumnName="CUSTOMER_ID", nullable = false)
     private Customer customer;
	
	
	
	@OneToMany(mappedBy = "orders",  fetch= FetchType.LAZY)
	private List<SalesOrderItem> orderDetails;
		
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name="ORDER_STATUS_ID", nullable = false)
	private OrderStatus orderStatus;
	
	
	public String getMailStatus() {
		return mailStatus;
	}




	public void setMailStatus(String mailStatus) {
		this.mailStatus = mailStatus;
	}




	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	

	public String getCreatedBy() {
		return createdBy;
	}




	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}




	public String getOrderId() {
		return orderId;
	}




	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}




	public Date getOrderRecDate() {
		return orderRecDate;
	}




	public void setOrderRecDate(Date orderRecDate) {
		this.orderRecDate = orderRecDate;
	}




	public Date getOrderAcceptanceDate() {
		return orderAcceptanceDate;
	}




	public void setOrderAcceptanceDate(Date orderAcceptanceDate) {
		this.orderAcceptanceDate = orderAcceptanceDate;
	}




	public String getPoDetails() {
		return poDetails;
	}




	public void setPoDetails(String poDetails) {
		this.poDetails = poDetails;
	}




	public String getModeOfReceipt() {
		return modeOfReceipt;
	}




	public void setModeOfReceipt(String modeOfReceipt) {
		this.modeOfReceipt = modeOfReceipt;
	}




	public Date getOrderDeliveryDate() {
		return orderDeliveryDate;
	}




	public void setOrderDeliveryDate(Date orderDeliveryDate) {
		this.orderDeliveryDate = orderDeliveryDate;
	}




	public Customer getCustomer() {
		return customer;
	}




	public void setCustomer(Customer customer) {
		this.customer = customer;
	}




	public List<SalesOrderItem> getOrderDetails() {
		return orderDetails;
	}




	public void setOrderDetails(List<SalesOrderItem> orderDetails) {
		this.orderDetails = orderDetails;
	}




	public OrderStatus getOrderStatus() {
		return orderStatus;
	}




	public void setOrderStatus(OrderStatus orderStatus) {
		this.orderStatus = orderStatus;
	}



	public Timestamp getCreatedTime() {
		return createdTime;
	}



	public void setCreatedTime(Timestamp createdTime) {
		this.createdTime = createdTime;
	}


	public Date getTargetDate() {
		return targetDate;
	}


	public void setTargetDate(Date targetDate) {
		this.targetDate = targetDate;
	}


	public String getUpdatedBy() {
		return updatedBy;
	}




	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}




	public Timestamp getUpdatedTime() {
		return updatedTime;
	}




	public void setUpdatedTime(Timestamp updatedTime) {
		this.updatedTime = updatedTime;
	}




	public Double getInputQuantity() {
		return inputQuantity;
	}




	public void setInputQuantity(Double inputQuantity) {
		this.inputQuantity = inputQuantity;
	}






	public String getLmeDetails() {
		return lmeDetails;
	}




	public void setLmeDetails(String lmeDetails) {
		this.lmeDetails = lmeDetails;
	}




	@Override
	public String toString() {
		return "SalesOrder [orderId=" + orderId + ", customerName="
				+ customer.getCustomerName() + ", poDetails=" + poDetails
				+ ", orderRecDate=" + orderRecDate + ", orderAcceptanceDate="
				+ orderAcceptanceDate + ", orderDeliveryDate=" + orderDeliveryDate + ", modeOfReceipt="
				+ modeOfReceipt + ", status=" + orderStatus.getStatus()  + ", orderStatusId="
						+ orderStatus.getOrderStatusId() + ",createdTime="+createdTime
				+ "]";
	}
	
	
	
	

}
