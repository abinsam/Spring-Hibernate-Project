package org.balajicables.salesmanager.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.balajicables.salesmanager.model.Item;

@Entity
@Table(name = "SALES_ORDER_ITEM")
public class SalesOrderItem implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue
	@Column(name = "ORDER_DETAIL_ID")
	private Long orderDetailId;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "ORDER_ID", referencedColumnName = "ORDER_ID", nullable = false)
	private SalesOrder orders;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "ITEM_ID", referencedColumnName = "ITEM_ID", nullable = false)
	private Item items;

	@Column(name = "ITEM_CODE", nullable = false)
	private String itemCode;

	@Column(name = "QUANTITY")
	private Double quantity;

	@Column(name = "UNIT")
	private Integer unitId;

	@Column(name = "BUNDLE_SIZE")
	private Integer bundleSize;

	@Column(name = "DELIVERED")
	private String delivered;

	@Column(name = "RATE")
	private Float rate;

	@Column(name = "BALANCE_QTY")
	private Double balanceQty;

	@Column(name = "WO_QTY")
	private Double woQty;

	@Column(name = "COMPLETED_QTY")
	private Double completedQty;

	@Column(name = "PRODUCTION_QTY")
	private Double productionQty;
	

	@Column(name = "DISPATCHED_QTY")
	private Double dispatchedQty;

	@OneToMany(mappedBy = "salesOrderItem")
	private List<StockOut> stockOut;

	@Column(name = "UPDATED_BY")
	private String updatedBy;

	@Column(name = "UPDATED_TIME")
	private Timestamp updatedTime;

	@Column(name = "WEIGHT")
	private Double weight;

	@Column(name = "PVC_WEIGHT")
	private Double pvcWeight;

	public Double getPvcWeight() {
		return pvcWeight;
	}

	public void setPvcWeight(Double pvcWeight) {
		this.pvcWeight = pvcWeight;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public SalesOrder getOrders() {
		return orders;
	}

	public void setOrders(SalesOrder orders) {
		this.orders = orders;
	}

	public Item getItems() {
		return items;
	}

	public void setItems(Item items) {
		this.items = items;
	}

	public List<StockOut> getStockOut() {
		return stockOut;
	}

	public void setStockOut(List<StockOut> stockOut) {
		this.stockOut = stockOut;
	}

	/*
	 * @Transient public Integer getNumberOfBundles() { return
	 * (quantity+bundleSize-1)/bundleSize; }
	 */
	public SalesOrder getOrder() {
		return orders;
	}

	public void setOrder(SalesOrder orders) {
		this.orders = orders;
	}

	public Item getItem() {
		return items;
	}

	public void setItem(Item items) {
		this.items = items;
	}

	public Double getQuantity() {
		return quantity;
	}

	public void setQuantity(Double quantity) {
		this.quantity = quantity;
	}

	public Integer getUnitId() {
		return unitId;
	}

	public void setUnitId(Integer unitId) {
		this.unitId = unitId;
	}

	public Long getOrderDetailId() {
		return orderDetailId;
	}

	public void setOrderDetailId(Long orderDetailId) {
		this.orderDetailId = orderDetailId;
	}

	public String getDelivered() {
		return delivered;
	}

	public void setDelivered(String delivered) {
		this.delivered = delivered;
	}

	public Float getRate() {
		return rate;
	}

	public void setRate(Float rate) {
		this.rate = rate;
	}

	public Double getBalanceQty() {
		return balanceQty;
	}

	public void setBalanceQty(Double balanceQty) {
		this.balanceQty = balanceQty;
	}

	public Integer getBundleSize() {
		return bundleSize;
	}

	public void setBundleSize(Integer bundleSize) {
		this.bundleSize = bundleSize;
	}

	public Double getCompletedQty() {
		return completedQty;
	}

	public void setCompletedQty(Double completedQty) {
		this.completedQty = completedQty;
	}

	public Double getWoQty() {
		return woQty;
	}

	public void setWoQty(Double woQty) {
		this.woQty = woQty;
	}

	public String getItemCode() {
		return itemCode;
	}

	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}

	public Double getProductionQty() {
		return productionQty;
	}

	public void setProductionQty(Double productionQty) {
		this.productionQty = productionQty;
	}

	public Double getDispatchedQty() {
		return dispatchedQty;
	}

	public void setDispatchedQty(Double dispatchedQty) {
		this.dispatchedQty = dispatchedQty;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Timestamp getUpdatedTime() {
		return updatedTime;
	}

	public void setUpdatedTime(Timestamp updatedTime) {
		this.updatedTime = updatedTime;
	}

	public Double getWeight() {
		return weight;
	}

	public void setWeight(Double weight) {
		this.weight = weight;
	}

}
