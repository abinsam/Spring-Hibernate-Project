package org.balajicables.salesmanager.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="SCRAP_DETAILS")

public class ScrapDetails {
	
	@Id  @GeneratedValue
	@Column(name="SCRAP_ID")
	private Long scrapId;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name="WORK_ORDER_NO", referencedColumnName="WORK_ORDER_NO",nullable = false)
	private  ProductionWorkOrder productionWorkOrder;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name="ITEM_ID", referencedColumnName="ITEM_ID",nullable = false)
	private  Item item;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name="SHIFT_ID", referencedColumnName="SHIFT_ID",nullable = false)
	private  Shift Shift;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name="MACHINE_NO", referencedColumnName="MACHINE_NO",nullable = false)
	private  MachineDetails machineDetails;

	@Column(name = "SUPERVISOR")
	private String supervisor  ;
	
	@Column(name = "SCRAP_DATE")
	private String scrapDate  ;
	
	@Column(name = "CREATED_DATE")
	private String createdDate  ;
	
	@Column(name = "QUANTITY")
	private Double quantity  ;
	
	@Column(name = "STOCKED_IN_STATUS")
	private String stockedInStatus  ;

	
	
	public String getStockedInStatus() {
		return stockedInStatus;
	}

	public void setStockedInStatus(String stockedInStatus) {
		this.stockedInStatus = stockedInStatus;
	}

	public Long getScrapId() {
		return scrapId;
	}

	public void setScrapId(Long scrapId) {
		this.scrapId = scrapId;
	}

	public ProductionWorkOrder getProductionWorkOrder() {
		return productionWorkOrder;
	}

	public void setProductionWorkOrder(ProductionWorkOrder productionWorkOrder) {
		this.productionWorkOrder = productionWorkOrder;
	}

	public Item getItem() {
		return item;
	}

	public void setItem(Item item) {
		this.item = item;
	}

	public Shift getShift() {
		return Shift;
	}

	public void setShift(Shift shift) {
		Shift = shift;
	}

	public MachineDetails getMachineDetails() {
		return machineDetails;
	}

	public void setMachineDetails(MachineDetails machineDetails) {
		this.machineDetails = machineDetails;
	}

	public String getSupervisor() {
		return supervisor;
	}

	public void setSupervisor(String supervisor) {
		this.supervisor = supervisor;
	}

	public String getScrapDate() {
		return scrapDate;
	}

	public void setScrapDate(String scrapDate) {
		this.scrapDate = scrapDate;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public Double getQuantity() {
		return quantity;
	}

	public void setQuantity(Double quantity) {
		this.quantity = quantity;
	}
	

}
