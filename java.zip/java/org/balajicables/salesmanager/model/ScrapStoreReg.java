package org.balajicables.salesmanager.model;

import java.io.Serializable;
import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="SCRAP_STORE_REG")
public class ScrapStoreReg implements Serializable {

  private static final long serialVersionUID = 1L;	
	
	@Id @GeneratedValue
	@Column(name = "SCRAP_STORE_REG_ID")
	private Long scrapStoreRegId;
	
	@Column(name = "STOCK_QUANTITY")
	private  Double stockQuantity;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "ITEM_ID", referencedColumnName = "ITEM_ID", nullable = false)
	private Item items;

	@ManyToOne
	@JoinColumn(name="STORE_ID", referencedColumnName="STORE_ID",nullable = false)
	private  Store store;


	@Column(name = "UPDATED_TIME")
	private Timestamp updatedTime;

	@Column(name = "UPDATED_BY")
	private  String  updatedBy;

	
	@Column(name = "STOCK_OUT_QTY")
	private Double stockOutQty;
	
	
	
	public Long getScrapStoreRegId() {
		return scrapStoreRegId;
	}

	public void setScrapStoreRegId(Long scrapStoreRegId) {
		this.scrapStoreRegId = scrapStoreRegId;
	}

	public Double getStockQuantity() {
		return stockQuantity;
	}

	public void setStockQuantity(Double stockQuantity) {
		this.stockQuantity = stockQuantity;
	}

	public Item getItems() {
		return items;
	}

	public void setItems(Item items) {
		this.items = items;
	}

	public Timestamp getUpdatedTime() {
		return updatedTime;
	}

	public void setUpdatedTime(Timestamp updatedTime) {
		this.updatedTime = updatedTime;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public Double getStockOutQty() {
		return stockOutQty;
	}

	public void setStockOutQty(Double stockOutQty) {
		this.stockOutQty = stockOutQty;
	}
	
	public Store getStore() {
		return store;
	}

	public void setStore(Store store) {
		this.store = store;
	}	
}
