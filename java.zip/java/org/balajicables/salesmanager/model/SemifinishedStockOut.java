package org.balajicables.salesmanager.model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "SEMIFINISHED_STOCK_OUT")
public class SemifinishedStockOut implements Serializable{

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "SEMIFINISHED_STOCK_OUT_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long semifinishedStockOutId;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name="STOCKED_OUT_FOR", referencedColumnName="WORK_ORDER_NO",nullable = false)
	private  ProductionWorkOrder productionWorkOrder;
	
	@ManyToOne
	@JoinColumn(name="WORK_ORDER_NO", referencedColumnName="WORK_ORDER_NO",nullable = false)
	private  ProductionWorkOrder productionWorkOrders;
	
	@ManyToOne
	@JoinColumn(name="STORE_ID", referencedColumnName="STORE_ID",nullable = false)
	private  Store store;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name="ORDER_DETAIL_ID", referencedColumnName="ORDER_DETAIL_ID",nullable = false)
	private  SalesOrderItem salesOrderItem;

	@Column(name = "ORDER_ID")
	private  String orderId;
	
	
	@Column(name = "ITEM_ID")
	private  Long itemId;
	
	@Column(name = "ITEM_CODE")
	private  String itemCode;
	
		
    @Column(name = "STOCK_OUT_QTY")
    private  Double stockOutQty;

	
	@Column(name = "BUNDLE_ID")
	private  String bundleId;	
	
	@Column(name = "WEIGHT")
	private  Double weight;
	
	@Column(name = "SUPERVISOR")
	private  String supervisor;
	
	@Column(name = "CONFIRM_STATUS")
	private  String confirmStatus;
	
	@Column(name = "QC_SUPERVISOR")
	private  String qcSupervisor;
	
	@Column(name = "QC_STATUS")
	private  String qcStatus;
	
	
	public String getConfirmStatus() {
		return confirmStatus;
	}

	public void setConfirmStatus(String confirmStatus) {
		this.confirmStatus = confirmStatus;
	}

	public Long getSemifinishedStockOutId() {
		return semifinishedStockOutId;
	}

	public void setSemifinishedStockOutId(Long semifinishedStockOutId) {
		this.semifinishedStockOutId = semifinishedStockOutId;
	}

	public ProductionWorkOrder getProductionWorkOrder() {
		return productionWorkOrder;
	}

	public void setProductionWorkOrder(ProductionWorkOrder productionWorkOrder) {
		this.productionWorkOrder = productionWorkOrder;
	}

	public ProductionWorkOrder getProductionWorkOrders() {
		return productionWorkOrders;
	}

	public void setProductionWorkOrders(ProductionWorkOrder productionWorkOrders) {
		this.productionWorkOrders = productionWorkOrders;
	}

	public Store getStore() {
		return store;
	}

	public void setStore(Store store) {
		this.store = store;
	}

	public SalesOrderItem getSalesOrderItem() {
		return salesOrderItem;
	}

	public void setSalesOrderItem(SalesOrderItem salesOrderItem) {
		this.salesOrderItem = salesOrderItem;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public Long getItemId() {
		return itemId;
	}

	public void setItemId(Long itemId) {
		this.itemId = itemId;
	}

	public String getItemCode() {
		return itemCode;
	}

	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}

	public Double getStockOutQty() {
		return stockOutQty;
	}

	public void setStockOutQty(Double stockOutQty) {
		this.stockOutQty = stockOutQty;
	}


	public String getBundleId() {
		return bundleId;
	}

	public void setBundleId(String bundleId) {
		this.bundleId = bundleId;
	}

	public Double getWeight() {
		return weight;
	}

	public void setWeight(Double weight) {
		this.weight = weight;
	}

	public String getSupervisor() {
		return supervisor;
	}

	public void setSupervisor(String supervisor) {
		this.supervisor = supervisor;
	}

	public String getQcSupervisor() {
		return qcSupervisor;
	}

	public void setQcSupervisor(String qcSupervisor) {
		this.qcSupervisor = qcSupervisor;
	}

	public String getQcStatus() {
		return qcStatus;
	}

	public void setQcStatus(String qcStatus) {
		this.qcStatus = qcStatus;
	}


	
	
	

}

	
	
	