package org.balajicables.salesmanager.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Immutable;

@Entity
@Table(name="SHIFT")
@Immutable
public class Shift {
	
	@Id
	@Column(name="SHIFT_ID" , updatable=false,insertable=false )
	private Integer shiftId;
	
	@Column(name="SHIFT_PATTERN" , updatable=false,insertable=false)
	private String shiftPattern;

	@Column(name="SHIFT_DESCRIPTION" , updatable=false,insertable=false)
	private String shiftDesc;

	public Integer getShiftId() {
		return shiftId;
	}

	public void setShiftId(Integer shiftId) {
		this.shiftId = shiftId;
	}

	public String getShiftPattern() {
		return shiftPattern;
	}

	public void setShiftPattern(String shiftPattern) {
		this.shiftPattern = shiftPattern;
	}

	public String getShiftDesc() {
		return shiftDesc;
	}

	public void setShiftDesc(String shiftDesc) {
		this.shiftDesc = shiftDesc;
	}
	
	
}
