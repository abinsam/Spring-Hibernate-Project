package org.balajicables.salesmanager.model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="SO_ASSORTED_WEIGHT")
public class SoAssortedWeight implements Serializable {

  private static final long serialVersionUID = 1L;	
 
  @Id @GeneratedValue
	@Column(name = "SO_ASSORETED_WEIGHT_ID")
	private Long soAssortedWeightId;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name="ORDER_ID", referencedColumnName="ORDER_ID",nullable = false)
	private SalesOrder orders;
	
	@Column(name = "WEIGHT")
	private Integer weight;
	
	@Column(name = "ASSORTED_TYPE")
	private Integer assortedType  ;

	public Long getSoAssortedWeightId() {
		return soAssortedWeightId;
	}

	public void setSoAssortedWeightId(Long soAssortedWeightId) {
		this.soAssortedWeightId = soAssortedWeightId;
	}

	public SalesOrder getOrders() {
		return orders;
	}

	public void setOrders(SalesOrder orders) {
		this.orders = orders;
	}

	public Integer getWeight() {
		return weight;
	}

	public void setWeight(Integer weight) {
		this.weight = weight;
	}

	public Integer getAssortedType() {
		return assortedType;
	}

	public void setAssortedType(Integer assortedType) {
		this.assortedType = assortedType;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
}
