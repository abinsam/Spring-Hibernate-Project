package org.balajicables.salesmanager.model;

import java.io.Serializable;
import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "STOCK_IN")
public class StockIn implements Serializable{

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "STOCK_IN_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long stockInId;

	
	@ManyToOne
	@JoinColumn(name="STORE_ID", referencedColumnName="STORE_ID",nullable = false)
	private  Store store;
	
	@ManyToOne
	@JoinColumn(name="SO_ITEM_ID",nullable = false)
	private  SalesOrderItem salesOrderItem;

	
	@Column(name = "ORDER_ID")
	private  String orderId;
	
	
	@Column(name = "ITEM_ID")
	private  Long itemId;
	
	@Column(name = "ITEM_CODE")
	private  String itemCode;
	
	@Column(name = "SO_ITEM_QTY")
	private  Double soItemQty;
	
	@ManyToOne
	@JoinColumn(name="WORK_ORDER_NO", referencedColumnName="WORK_ORDER_NO",nullable = false)
	private  ProductionWorkOrder productionWorkOrder;
	

	@Column(name = "STOCK_IN_DATE_TIME")
	private Timestamp stockInDateTime;

	
    @Column(name = "STOCK_QTY")
    private  Double stockQty;
	
	@Column(name = "QC_STATUS")
	private  String qcStatus;

	@Column(name = "CUSTOMER_NAME")
	private  String customerName;
	
	@Column(name = "BUNDLE_ID")
	private  String bundleId;

	@Column(name = "WEIGHT")
	private  Double weight;
	
	@Column(name = "BATCH_NO")
	private  String batchNo;
	
	@Column(name = "CONFIRM_STATUS")
	private  String confirmStatus;

	
	@Column(name = "SUPERVISOR")
	private  String supervisor;
	
	public String getBatchNo() {
		return batchNo;
	}

	public void setBatchNo(String batchNo) {
		this.batchNo = batchNo;
	}

	public Long getStockInId() {
		return stockInId;
	}

	public void setStockInId(Long stockInId) {
		this.stockInId = stockInId;
	}

	public Store getStore() {
		return store;
	}

	public void setStore(Store store) {
		this.store = store;
	}

	public SalesOrderItem getSalesOrderItem() {
		return salesOrderItem;
	}

	public void setSalesOrderItem(SalesOrderItem salesOrderItem) {
		this.salesOrderItem = salesOrderItem;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public Long getItemId() {
		return itemId;
	}

	public void setItemId(Long itemId) {
		this.itemId = itemId;
	}

	public String getItemCode() {
		return itemCode;
	}

	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}

	public Double getSoItemQty() {
		return soItemQty;
	}

	public void setSoItemQty(Double soItemQty) {
		this.soItemQty = soItemQty;
	}

	public ProductionWorkOrder getProductionWorkOrder() {
		return productionWorkOrder;
	}

	public void setProductionWorkOrder(ProductionWorkOrder productionWorkOrder) {
		this.productionWorkOrder = productionWorkOrder;
	}

	public Timestamp getStockInDateTime() {
		return stockInDateTime;
	}

	public void setStockInDateTime(Timestamp stockInDateTime) {
		this.stockInDateTime = stockInDateTime;
	}

	public Double getStockQty() {
		return stockQty;
	}

	public void setStockQty(Double stockQty) {
		this.stockQty = stockQty;
	}

	public String getQcStatus() {
		return qcStatus;
	}

	public void setQcStatus(String qcStatus) {
		this.qcStatus = qcStatus;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getBundleId() {
		return bundleId;
	}

	public void setBundleId(String bundleId) {
		this.bundleId = bundleId;
	}
	

	public Double getWeight() {
		return weight;
	}

	public void setWeight(Double weight) {
		this.weight = weight;
	}

	public String getConfirmStatus() {
		return confirmStatus;
	}

	public void setConfirmStatus(String confirmStatus) {
		this.confirmStatus = confirmStatus;
	}

	public String getSupervisor() {
		return supervisor;
	}

	public void setSupervisor(String supervisor) {
		this.supervisor = supervisor;
	}
	
}

	
	
	