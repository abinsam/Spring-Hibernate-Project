package org.balajicables.salesmanager.model;

import java.io.Serializable;
import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "STOCK_OUT")
public class StockOut implements Serializable{

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "STOCK_OUT_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long stockOutId;

	
	@ManyToOne
	@JoinColumn(name="STORE_ID", referencedColumnName="STORE_ID",nullable = false)
	private  Store store;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name="ORDER_DETAIL_ID", referencedColumnName="ORDER_DETAIL_ID",nullable = false)
	private  SalesOrderItem salesOrderItem;

	
	@Column(name = "ORDER_ID")
	private  String orderId;
	
	
	@Column(name = "ITEM_ID")
	private  Long itemId;
	
	@Column(name = "ITEM_CODE")
	private  String itemCode;
	
	@Column(name = "SO_ITEM_QTY")
	private  Double soItemQty;
	
	@ManyToOne
	@JoinColumn(name="WORK_ORDER_NO", referencedColumnName="WORK_ORDER_NO",nullable = false)
	private  ProductionWorkOrder productionWorkOrder;
	

	@Column(name = "STOCK_OUT_DATE_TIME")
	private Timestamp stockOutDateTime;

	
    @Column(name = "STOCKOUT_QTY")
    private  Double stockOutQty;
	
	@Column(name = "QC_STATUS")
	private  String qcStatus;

	@Column(name = "CUSTOMER_NAME")
	private  String customerName;
	
	@Column(name = "BUNDLE_ID")
	private  String bundleId;	
	
	@Column(name = "PACKING_SLIP_NO")
	private  Long packingSlipNo;	
	

	/*@Column(name = "DC_STATUS")
	private  String dcStatus;*/
	

	@Column(name = "SUPERVISOR")
	private  String supervisor;

	@Column(name = "WEIGHT")
	private  Double weight;

	@Column(name = "CONFIRM_STATUS")
	private  String confirmStatus;
	
	@Column(name = "BAG_WEIGHT")
	private  Double bagWeight;
	
	@Column(name = "DELIVERY_CHALLAN_NO")
	private  String deliveryChallanNo;	
	
	@Column(name = "REMARKS")
	private  String remarks;
	
	@Column(name = "QC_SUPERVISOR")
	private  String qcSupervisor;
	
	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public Double getBagWeight() {
		return bagWeight;
	}

	public void setBagWeight(Double bagWeight) {
		this.bagWeight = bagWeight;
	}


	public Long getStockOutId() {
		return stockOutId;
	}

	public void setStockOutId(Long stockOutId) {
		this.stockOutId = stockOutId;
	}

	public Store getStore() {
		return store;
	}

	public void setStore(Store store) {
		this.store = store;
	}

	public SalesOrderItem getSalesOrderItem() {
		return salesOrderItem;
	}

	public void setSalesOrderItem(SalesOrderItem salesOrderItem) {
		this.salesOrderItem = salesOrderItem;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public Long getItemId() {
		return itemId;
	}

	public void setItemId(Long itemId) {
		this.itemId = itemId;
	}

	public String getItemCode() {
		return itemCode;
	}

	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}

	public Double getSoItemQty() {
		return soItemQty;
	}

	public void setSoItemQty(Double soItemQty) {
		this.soItemQty = soItemQty;
	}



	public ProductionWorkOrder getProductionWorkOrder() {
		return productionWorkOrder;
	}

	public void setProductionWorkOrder(ProductionWorkOrder productionWorkOrder) {
		this.productionWorkOrder = productionWorkOrder;
	}

	public Timestamp getStockOutDateTime() {
		return stockOutDateTime;
	}

	public void setStockOutDateTime(Timestamp stockOutDateTime) {
		this.stockOutDateTime = stockOutDateTime;
	}

	public Double getStockOutQty() {
		return stockOutQty;
	}

	public void setStockOutQty(Double stockOutQty) {
		this.stockOutQty = stockOutQty;
	}

	public String getQcStatus() {
		return qcStatus;
	}

	public void setQcStatus(String qcStatus) {
		this.qcStatus = qcStatus;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getBundleId() {
		return bundleId;
	}

	public void setBundleId(String bundleId) {
		this.bundleId = bundleId;
	}

	public Long getPackingSlipNo() {
		return packingSlipNo;
	}

	public void setPackingSlipNo(Long packingSlipNo) {
		this.packingSlipNo = packingSlipNo;
	}

/*	public String getDcStatus() {
		return dcStatus;
	}

	public void setDcStatus(String dcStatus) {
		this.dcStatus = dcStatus;
	}*/

	public String getSupervisor() {
		return supervisor;
	}

	public void setSupervisor(String supervisor) {
		this.supervisor = supervisor;
	}

	public Double getWeight() {
		return weight;
	}

	public void setWeight(Double weight) {
		this.weight = weight;
	}




	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getConfirmStatus() {
		return confirmStatus;
	}

	public void setConfirmStatus(String confirmStatus) {
		this.confirmStatus = confirmStatus;
	}

	public String getDeliveryChallanNo() {
		return deliveryChallanNo;
	}

	public void setDeliveryChallanNo(String deliveryChallanNo) {
		this.deliveryChallanNo = deliveryChallanNo;
	}

	public String getQcSupervisor() {
		return qcSupervisor;
	}

	public void setQcSupervisor(String qcSupervisor) {
		this.qcSupervisor = qcSupervisor;
	}
	
	
	

}

	
	
	