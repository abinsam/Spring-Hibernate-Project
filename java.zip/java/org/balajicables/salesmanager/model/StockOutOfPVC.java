package org.balajicables.salesmanager.model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "STOCK_OUT_OF_PVC")
public class StockOutOfPVC implements Serializable{

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "STOCK_OUT_OF_PVC_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long stockOutOfPvcId;

	public Long getStockOutOfPvcId() {
		return stockOutOfPvcId;
	}

	public void setStockOutOfPvcId(Long stockOutOfPvcId) {
		this.stockOutOfPvcId = stockOutOfPvcId;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
}	
	

	
	
	