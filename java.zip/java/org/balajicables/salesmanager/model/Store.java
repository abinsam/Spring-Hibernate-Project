package org.balajicables.salesmanager.model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "STORE")
public class Store implements Serializable{

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "STORE_ID")
	private Integer storeId;
	
	@Column(name = "STORE_ADDRESS")
	private  String storeAddress;

	public Integer getStoreId() {
		return storeId;
	}

	public void setStoreId(Integer storeId) {
		this.storeId = storeId;
	}

	public String getStoreAddress() {
		return storeAddress;
	}

	public void setStoreAddress(String storeAddress) {
		this.storeAddress = storeAddress;
	}

	
}	
	

	
	
	