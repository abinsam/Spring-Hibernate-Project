package org.balajicables.salesmanager.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "STORE_REGISTER")
public class StoreRegister implements Serializable{

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "STORE_REGISTER_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long storeRegisterId;

	@Column(name = "ITEM_CODE")
	private  String itemCode;
	
	
	@ManyToOne
	@JoinColumn(name="STORE_ID", referencedColumnName="STORE_ID",nullable = false)
	private  Store store;
	
	@ManyToOne
	@JoinColumn(name="WORK_ORDER_NO", referencedColumnName="WORK_ORDER_NO",nullable = false)
	private  ProductionWorkOrder productionWorkOrder;

	
	@Column(name = "PARTY")
	private  String customerName;
	
	@Column(name = "STOCK_QTY")
	private  Double stockQty;
	

	@Column(name = "UPDATED_DATETIME")
	private Timestamp updatedDateTime;
	
	@Column(name = "BUNDLE_ID")
	private  String bundleId;
	
	@Column(name = "ORDER_ID")
	private  String orderId;
	
	@Column(name = "REJECT_STATUS")
	private  String rejectStatus;
	
	@ManyToOne
	@JoinColumn(name="ORDER_DETAIL_ID",nullable = false)
	private  SalesOrderItem salesOrderItem;
	
	@Column(name = "ITEM_ID")
	private  Long itemId;
	
	@Column(name = "PACKING_SLIP_NO")
	private  Long packingSlipNo;	
	

	@Column(name = "SUPERVISOR")
	private  String supervisor;
	
	@Column(name = "QC_SUPERVISOR")
	private  String qcSupervisor;

	@Column(name = "WEIGHT")
	private  Double weight;
	

	@Column(name = "BAG_WEIGHT")
	private  Double bagWeight;
	
	@Column(name = "QC_STATUS")
	private  String qcStatus;
	
	@Column(name = "REMARKS")
	private  String remarks;
	
	
	public Double getBagWeight() {
		return bagWeight;
	}

	public void setBagWeight(Double bagWeight) {
		this.bagWeight = bagWeight;
	}

	public Long getStoreRegisterId() {
		return storeRegisterId;
	}

	public void setStoreRegisterId(Long storeRegisterId) {
		this.storeRegisterId = storeRegisterId;
	}

	public String getItemCode() {
		return itemCode;
	}

	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}

	public Store getStore() {
		return store;
	}

	public void setStore(Store store) {
		this.store = store;
	}

	


	public ProductionWorkOrder getProductionWorkOrder() {
		return productionWorkOrder;
	}

	public void setProductionWorkOrder(ProductionWorkOrder productionWorkOrder) {
		this.productionWorkOrder = productionWorkOrder;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public Double getStockQty() {
		return stockQty;
	}

	public void setStockQty(Double stockQty) {
		this.stockQty = stockQty;
	}

	public Timestamp getUpdatedDateTime() {
		return updatedDateTime;
	}

	public void setUpdatedDateTime(Timestamp updatedDateTime) {
		this.updatedDateTime = updatedDateTime;
	}

	public String getBundleId() {
		return bundleId;
	}

	public void setBundleId(String bundleId) {
		this.bundleId = bundleId;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public SalesOrderItem getSalesOrderItem() {
		return salesOrderItem;
	}

	public void setSalesOrderItem(SalesOrderItem salesOrderItem) {
		this.salesOrderItem = salesOrderItem;
	}

	public Long getItemId() {
		return itemId;
	}

	public void setItemId(Long itemId) {
		this.itemId = itemId;
	}

	public Long getPackingSlipNo() {
		return packingSlipNo;
	}

	public void setPackingSlipNo(Long packingSlipNo) {
		this.packingSlipNo = packingSlipNo;
	}

	public String getSupervisor() {
		return supervisor;
	}

	public void setSupervisor(String supervisor) {
		this.supervisor = supervisor;
	}

	public Double getWeight() {
		return weight;
	}

	public void setWeight(Double weight) {
		this.weight = weight;
	}

	public String getQcStatus() {
		return qcStatus;
	}

	public void setQcStatus(String qcStatus) {
		this.qcStatus = qcStatus;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getQcSupervisor() {
		return qcSupervisor;
	}

	public void setQcSupervisor(String qcSupervisor) {
		this.qcSupervisor = qcSupervisor;
	}

	public String getRejectStatus() {
		return rejectStatus;
	}

	public void setRejectStatus(String rejectStatus) {
		this.rejectStatus = rejectStatus;
	}


}

	
	
	