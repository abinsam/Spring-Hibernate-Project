package org.balajicables.salesmanager.model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="TAX_RATES")
public class TaxRate implements Serializable{

	private static final long serialVersionUID = 1L;

	@Id @GeneratedValue
	@Column(name = "TAX_RATE_ID")
	private Long taxRateId;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name="CUSTOMER_ID", referencedColumnName="CUSTOMER_ID",nullable = false)
	private Customer customer;

	
	@Column(name = "EXCISE_DUTY")
	private Float exciseDuty;
	
	@Column(name = "EDU_CESS")
	private Float eduCess;
	
	@Column(name = "HIGHER_EDU_CESS")
	private Float higherEduCess;
	

	
	@Column(name = "VAT")
	private Float vat;
	
	@Column(name = "CST")
	private Float cst;

	@Column(name = "PAYMENT_TERMS")
	private String paymentTerms;
	
	@Column(name = "FRIEGHT")
	private String freight;
	
	
	public Long getTaxRateId() {
		return taxRateId;
	}

	public void setTaxRateId(Long taxRateId) {
		this.taxRateId = taxRateId;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Float getExciseDuty() {
		return exciseDuty;
	}

	public void setExciseDuty(Float exciseDuty) {
		this.exciseDuty = exciseDuty;
	}

	public Float getEduCess() {
		return eduCess;
	}

	public void setEduCess(Float eduCess) {
		this.eduCess = eduCess;
	}

	public Float getHigherEduCess() {
		return higherEduCess;
	}

	public void setHigherEduCess(Float higherEduCess) {
		this.higherEduCess = higherEduCess;
	}


	public Float getVat() {
		return vat;
	}

	public void setVat(Float vat) {
		this.vat = vat;
	}

	public Float getCst() {
		return cst;
	}

	public void setCst(Float cst) {
		this.cst = cst;
	}

	public String getPaymentTerms() {
		return paymentTerms;
	}

	public void setPaymentTerms(String paymentTerms) {
		this.paymentTerms = paymentTerms;
	}

	public String getFreight() {
		return freight;
	}

	public void setFreight(String freight) {
		this.freight = freight;
	}


	
	

}

