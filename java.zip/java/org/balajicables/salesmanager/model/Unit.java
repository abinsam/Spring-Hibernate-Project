package org.balajicables.salesmanager.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Immutable;

@Entity
@Table(name="UNIT_MASTER")
@Immutable
public class Unit {
	
	@Id
	@Column(name="UNIT_ID" , updatable=false,insertable=false )
	private Integer unitId;
	
	@Column(name="UNITS" , updatable=false,insertable=false)
	private String units;
	
	@Column(name="UNIT_TYPE" , updatable=false,insertable=false)
	private String unitType;

	public Unit() {
		super();
	}

	public Integer getUnitId() {
		return unitId;
	}

	public void setUnitId(Integer unitId) {
		this.unitId = unitId;
	}

	public String getUnits() {
		return units;
	}

	public void setUnits(String units) {
		this.units = units;
	}

	public String getUnitType() {
		return unitType;
	}

	public void setUnitType(String unitType) {
		this.unitType = unitType;
	}
	

	
}
