package org.balajicables.salesmanager.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "WORK_ORDER_ITEMS")
public class WorkOrderItems implements Serializable{

	private static final long serialVersionUID = 1L;

	@Id @GeneratedValue
	@Column(name = "WO_ITEM_ID")
	private Long workOrderItemId;
	
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name="WORK_ORDER_NO", referencedColumnName="WORK_ORDER_NO",nullable = false)
	private ProductionWorkOrder productionWorkOrder;
		
	
	@OneToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="ORDER_DETAIL_ID", referencedColumnName="ORDER_DETAIL_ID",nullable = false)
	private SalesOrderItem salesOrderItem;
	
	@Column(name = "NO_OF_COILS")
	private Integer noOfCoils  ;
	
	@Column(name = "QTY_PER_COIL")
	private Integer qtyPerCoil;

	@Column(name = "TOTAL_QTY")
	private Double totalQuantity;
	
	@Column(name = "PACKING_TYPE")
	private String packingType  ;
	
		
	@Column(name = "PVC_GRADE")
	private String pvcGrade;
	
	@Column(name = "MASTER_BATCH")
	private String masterBatch;
	
	@Column(name = "TO_BE_LABELLED")
	private String toBeLabelled;

	@Column(name = "STOCK_IN_QTY")
	private Double stockInQty;
	
	@Column(name = "STOCK_IN_STATUS")
	private String stockInStatus;

	@Column(name = "UPDATED_BY")
	private String updatedBY;
	
	
	@Column(name = "UPDATED_TIME")
	private Timestamp updatedTime;
	

	public Long getWorkOrderItemId() {
		return workOrderItemId;
	}


	public void setWorkOrderItemId(Long workOrderItemId) {
		this.workOrderItemId = workOrderItemId;
	}




	public SalesOrderItem getSalesOrderItem() {
		return salesOrderItem;
	}

	public void setSalesOrderItem(SalesOrderItem salesOrderItem) {
		this.salesOrderItem = salesOrderItem;
	}


	public Integer getNoOfCoils() {
		return noOfCoils;
	}


	public void setNoOfCoils(Integer noOfCoils) {
		this.noOfCoils = noOfCoils;
	}


	public Integer getQtyPerCoil() {
		return qtyPerCoil;
	}


	public void setQtyPerCoil(Integer qtyPerCoil) {
		this.qtyPerCoil = qtyPerCoil;
	}


	public Double getTotalQuantity() {
		return totalQuantity;
	}


	public void setTotalQuantity(Double totalQuantity) {
		this.totalQuantity = totalQuantity;
	}


	public String getPackingType() {
		return packingType;
	}


	public void setPackingType(String packingType) {
		this.packingType = packingType;
	}





	public String getPvcGrade() {
		return pvcGrade;
	}





	public void setPvcGrade(String pvcGrade) {
		this.pvcGrade = pvcGrade;
	}





	public String getMasterBatch() {
		return masterBatch;
	}





	public void setMasterBatch(String masterBatch) {
		this.masterBatch = masterBatch;
	}


	public String getToBeLabelled() {
		return toBeLabelled;
	}


	public void setToBeLabelled(String toBeLabelled) {
		this.toBeLabelled = toBeLabelled;
	}


	public ProductionWorkOrder getProductionWorkOrder() {
		return productionWorkOrder;
	}


	public void setProductionWorkOrder(ProductionWorkOrder productionWorkOrder) {
		this.productionWorkOrder = productionWorkOrder;
	}


	public Double getStockInQty() {
		return stockInQty;
	}


	public void setStockInQty(Double stockInQty) {
		this.stockInQty = stockInQty;
	}


	public String getStockInStatus() {
		return stockInStatus;
	}


	public void setStockInStatus(String stockInStatus) {
		this.stockInStatus = stockInStatus;
	}


	public String getUpdatedBY() {
		return updatedBY;
	}


	public void setUpdatedBY(String updatedBY) {
		this.updatedBY = updatedBY;
	}


	public Timestamp getUpdatedTime() {
		return updatedTime;
	}


	public void setUpdatedTime(Timestamp updatedTime) {
		this.updatedTime = updatedTime;
	}


}	
	

	
	
	