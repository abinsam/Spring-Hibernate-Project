package org.balajicables.salesmanager.model;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="WORK_ORDER_OUTPUT")
public class WorkOrderOutput {
	

	@Id @GeneratedValue
	@Column(name = "WO_OUTPUT_ID")
	private Long woOutPutId;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name="WORK_ORDER_NO", referencedColumnName="WORK_ORDER_NO",nullable = false)
	private  ProductionWorkOrder productionWorkOrder;
	
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="ORDER_DETAIL_ID", referencedColumnName="ORDER_DETAIL_ID",nullable = false)
	private SalesOrderItem salesOrderItem;
	
	@Column(name = "BATCH_NO")
	private  String  batchNo;
	
	
	@Column(name = "NET_LENGTH")
	private  Double netLength;
	
	@Column(name = "GROSS_WEIGHT")
	private  Double grossWeight;
	
	@Column(name = "TARE_WEIGHT")
	private  Double tareWeight;
	
	@Column(name = "NET_WEIGHT")
	private  Double netWeight;
	
	@Column(name = "NO_OF_STRANDS")
	private  Integer  noOfStrands;
	
	@Column(name = "SIZE")
	private  String  size;
	
	@Column(name = "SPEED")
	private  String  speed;

	@Column(name = "ANNEALING_PERCENT")
	private  String  annealingPercent;
	
	@Column(name = "OUTER_DIAMETER")
	private  String  outerDiameter;

	@Column(name = "CREATED_TIME")
	private Timestamp createdTime;

	@Column(name = "UPDATED_BY")
	private  String  updatedBy;
	

	@Column(name = "STOCK_IN")
	private  String  stockIn;
	

	public String getStockIn() {
		return stockIn;
	}

	public void setStockIn(String stockIn) {
		this.stockIn = stockIn;
	}

	public Long getWoOutPutId() {
		return woOutPutId;
	}

	public void setWoOutPutId(Long woOutPutId) {
		this.woOutPutId = woOutPutId;
	}

	public ProductionWorkOrder getProductionWorkOrder() {
		return productionWorkOrder;
	}

	public void setProductionWorkOrder(ProductionWorkOrder productionWorkOrder) {
		this.productionWorkOrder = productionWorkOrder;
	}

	public Double getNetLength() {
		return netLength;
	}

	public void setNetLength(Double netLength) {
		this.netLength = netLength;
	}

	public Double getGrossWeight() {
		return grossWeight;
	}

	public void setGrossWeight(Double grossWeight) {
		this.grossWeight = grossWeight;
	}

	public Double getTareWeight() {
		return tareWeight;
	}

	public void setTareWeight(Double tareWeight) {
		this.tareWeight = tareWeight;
	}

	public Double getNetWeight() {
		return netWeight;
	}

	public void setNetWeight(Double netWeight) {
		this.netWeight = netWeight;
	}

	public Integer getNoOfStrands() {
		return noOfStrands;
	}

	public void setNoOfStrands(Integer noOfStrands) {
		this.noOfStrands = noOfStrands;
	}

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	public String getSpeed() {
		return speed;
	}

	public void setSpeed(String speed) {
		this.speed = speed;
	}

	public String getAnnealingPercent() {
		return annealingPercent;
	}

	public void setAnnealingPercent(String annealingPercent) {
		this.annealingPercent = annealingPercent;
	}

	public String getOuterDiameter() {
		return outerDiameter;
	}

	public void setOuterDiameter(String outerDiameter) {
		this.outerDiameter = outerDiameter;
	}

	public Timestamp getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Timestamp createdTime) {
		this.createdTime = createdTime;
	}


	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public String getBatchNo() {
		return batchNo;
	}

	public void setBatchNo(String batchNo) {
		this.batchNo = batchNo;
	}

	public SalesOrderItem getSalesOrderItem() {
		return salesOrderItem;
	}

	public void setSalesOrderItem(SalesOrderItem salesOrderItem) {
		this.salesOrderItem = salesOrderItem;
	}
	
	
	
}
