package org.balajicables.salesmanager.repository;

import java.util.List;

import org.balajicables.salesmanager.model.AssortedRate;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Repository:AssortedRate.
 * @author Abin Sam
 */

public interface AssortedRateRepository extends
		JpaRepository<AssortedRate, Long> {
	
	  /* Fetch all Assorted Rate based on Customer Code and Assorted Tye */
	List<AssortedRate> findByCustomerCodeAndAssortedType(String customerCode,
			String assortedType);

}