package org.balajicables.salesmanager.repository;

import org.balajicables.salesmanager.model.BasketDetails;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Repository:BasketDetails.
 * 
 * @author Abin Sam
 */

public interface BasketDetailsRepository extends
		JpaRepository<BasketDetails, Long> {

}