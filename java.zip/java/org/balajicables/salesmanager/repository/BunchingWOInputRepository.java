package org.balajicables.salesmanager.repository;

import java.util.List;
import org.balajicables.salesmanager.model.BunchingWOInput;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Repository:Bunching Work order Input.
 * 
 * @author Abin Sam
 */
public interface BunchingWOInputRepository extends
		JpaRepository<BunchingWOInput, Long> {
	
	  /* Fetch paged bunching work order input record based on work order no */
	Page<BunchingWOInput> findByProductionWorkOrderWorkOrderNo(
			String workOrderNo, Pageable pageable);
	
	/* Fetch list of bunching  work order input record based on work order no */
	List<BunchingWOInput> findByProductionWorkOrderWorkOrderNo(String woNo);

	/* Fetch list of bunching work order input record based on work order input Id */
	List<BunchingWOInput> findByBunchWoInputId(Long id);

	/* Fetch list of bunching work order input record based on work order No ,item input size and customer */
	List<BunchingWOInput> findByProductionWorkOrderWorkOrderNoAndSizeAndCustomerName(
			String bunchingWorkOrderNoTag, String inputSize, String customerName);
	
	/* Fetch list of bunching work order input record based on work order No and sales order item id */
	List<BunchingWOInput> findBySalesOrderItemOrderDetailIdAndProductionWorkOrderWorkOrderNo(
			Long soItemId, String workOrderNo);

	/* Fetch list of bunching work order input record based on work order No ,item code and sales order no*/
	List<BunchingWOInput> findBySalesOrderItemOrdersOrderIdAndSalesOrderItemItemsItemCodeAndProductionWorkOrderWorkOrderNo(
			String dummySalesOrder, String itemCode, String woNo);

}
