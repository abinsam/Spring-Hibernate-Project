package org.balajicables.salesmanager.repository;

import org.balajicables.salesmanager.model.CableStdPvc;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Repository:CableStdPvc.
 * 
 * @author Abin Sam
 */
public interface CableStdPvcRepository extends
		JpaRepository<CableStdPvc, String> {

}