package org.balajicables.salesmanager.repository;

import java.util.List;

import org.balajicables.salesmanager.model.CustomerPartNo;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Repository:CustomerPartNo.
 * 
 * @author Abin Sam
 */
public interface CustomerPartNoRepository extends
		JpaRepository<CustomerPartNo, Integer> {

	/* Fetch list of CustomerPartNo record based on customer Id and item id*/
	List<CustomerPartNo> findByCustomerCustomerIdAndItemsItemId(Long custId,
			Long itemId);
	
	/* Fetch list of CustomerPartNo record based on item id*/
	List<CustomerPartNo> findByItemsItemId(Long itemIdToDelete);

	/* Fetch list of CustomerPartNo record based on CustomerPartNo id*/
	List<CustomerPartNo> findByPartNoId(Integer id);

	/* delete CustomerPartNo record based on CustomerPartNo id*/
	void delete(Integer partNoId);

	/* Fetch list of CustomerPartNo record based on Customer id and item Code*/
	List<CustomerPartNo> findByCustomerCustomerIdAndItemsItemCode(
			Long customerSelect, String itemIdSelect);

}
