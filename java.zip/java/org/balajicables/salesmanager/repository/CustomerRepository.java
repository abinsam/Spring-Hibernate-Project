package org.balajicables.salesmanager.repository;

import java.util.List;

import org.balajicables.salesmanager.model.Customer;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Repository:Customer.
 * 
 * @author Abin Sam
 */
public interface CustomerRepository extends JpaRepository<Customer, Long> {
	/* Fetch list of Customer record based on Customer id */
	List<Customer> findByCustomerId(Long customerId);

	/* Fetch list of Customer record based on Customer Name */
	List<Customer> findByCustomerName(String custName);

	/* Fetch paged list of Customer record based on Customer Id */
	Page<Customer> findByCustomerId(Long customerId, Pageable pageable);

	/* Fetch list of Customer record based on Customer Code */
	List<Customer> findByCustomerCode(String customerCode);

}
