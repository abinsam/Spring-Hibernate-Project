package org.balajicables.salesmanager.repository;

import java.util.List;
import org.balajicables.salesmanager.model.DeliveryChallanItems;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Repository:DeliveryChallan Items.
 * 
 * @author Abin Sam
 */
public interface DeliveryChallanItemsRepository extends
		JpaRepository<DeliveryChallanItems, Long> {

	/* Fetch paged list of DeliveryChallanItems record based on deliveryChallan No */
	Page<DeliveryChallanItems> findByDeliveryChallanDeliveryChallanNo(
			String deliveryChallanNo, Pageable pageable);

	/* Fetch paged list of DeliveryChallanItems record based on deliveryChallan No and Invoice status  */
	Page<DeliveryChallanItems> findByDeliveryChallanDeliveryChallanNoAndDeliveryChallanInvoiceStatus(
			String deliveryChallanNo, String invoiceStatus, Pageable pageable);

	/* Fetch  list of DeliveryChallanItems record based on deliveryChallan No and Invoice status  */
	List<DeliveryChallanItems> findByDeliveryChallanDeliveryChallanNoAndDeliveryChallanInvoiceStatus(
			String deliveryChallanNo, String invoiceStatus);

	/* Fetch  list of DeliveryChallanItems record based on deliveryChallan No */
	List<DeliveryChallanItems> findByDeliveryChallanDeliveryChallanNo(
			String deliveryChallanNo);

	List<DeliveryChallanItems> findByItemItemIdAndDeliveryChallanOrdersOrderId(
			Long itemId, String orderId);

}