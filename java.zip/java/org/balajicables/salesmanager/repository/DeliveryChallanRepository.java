package org.balajicables.salesmanager.repository;

import java.util.List;
import org.balajicables.salesmanager.model.DeliveryChallan;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Repository:DeliveryChallan.
 * 
 * @author Abin Sam
 */
public interface DeliveryChallanRepository extends
		JpaRepository<DeliveryChallan, String> {

	/* Fetch paged list of DeliveryChallan record based on deliveryChallan No */
	Page<DeliveryChallan> findByDeliveryChallanNo(String dcNo, Pageable pageable);

	/* Fetch list of DeliveryChallan record based on deliveryChallan No */
	List<DeliveryChallan> findByDeliveryChallanNo(String deliveryChallanNo);

	/* Fetch paged list of DeliveryChallan record based on deliveryChallan No and Invoice status */
	Page<DeliveryChallan> findByDeliveryChallanNoAndInvoiceStatus(
			String deliveryChallanNo, String invoiceStatus, Pageable pageable);

	/* Fetch list of DeliveryChallan record based on deliveryChallan No and Invoice status */
	List<DeliveryChallan> findByDeliveryChallanNoAndInvoiceStatus(
			String deliveryChallanNo, String invoiceStatus);

	/* Fetch list of DeliveryChallan record based on CustomerId */
	List<DeliveryChallan> findByOrdersCustomerCustomerId(Long customerId);
	



}