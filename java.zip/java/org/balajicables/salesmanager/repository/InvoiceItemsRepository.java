package org.balajicables.salesmanager.repository;

import java.util.List;

import org.balajicables.salesmanager.model.InvoiceItems;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Repository:Invoice Items.
 * 
 * @author Abin Sam
 */

public interface InvoiceItemsRepository extends
		JpaRepository<InvoiceItems, Long> {

	/* Fetch list of InvoiceItems record based on Invoice No */
	List<InvoiceItems> findByInvoiceInvoiceNo(String newdInvoiceNo);

	/* Fetch paged list of InvoiceItems record based on Invoice No */
	Page<InvoiceItems> findByInvoiceInvoiceNo(String invoiceNo,
			Pageable pageable);

}