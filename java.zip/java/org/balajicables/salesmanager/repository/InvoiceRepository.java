package org.balajicables.salesmanager.repository;

import java.util.List;

import org.balajicables.salesmanager.model.Invoice;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Repository:Invoice.
 * 
 * @author Abin Sam
 */

public interface InvoiceRepository extends JpaRepository<Invoice, String> {

	/* Fetch  list of Invoice record based on Invoice No */
	List<Invoice> findByInvoiceNo(String newdInvoiceNo);

	/* Fetch  list of Invoice record based on CustomerId */
	List<Invoice> findByCustomerCustomerId(Long customerId);

}