package org.balajicables.salesmanager.repository;

import java.util.List;

import org.balajicables.salesmanager.model.Item;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Repository:Item.
 * 
 * @author Abin Sam
 */
public interface ItemRepository extends JpaRepository<Item, Long> {

	
	/* Fetch  list of Item record based on ItemCode */
	List<Item> findByItemCode(String itemCode);

	/* Fetch  list of Item record based on ProductKey */
	List<Item> findByProductTypeProductKey(String type);

	/* Fetch  list of Item record based on ItemId */
	List<Item> findByItemId(Long itemId);

	/* Fetch  list of Item record based on InputSize */
	List<Item> findByInputSize(String bunchingSize);

	/* Fetch  list of Item record based on ItemType */
	List<Item> findByItemType(String itemType);

	
	/* Fetch  list of Item record based on CopperStrandDiameter Copperkey, ProductType and LayLength */
	List<Item> findByCopperStrandDiameterCopperkeyAndNumberOfCopperStrandsAndProductTypeProductTypeAndLayLength(
			String copperDiameterSelect, Integer numberOfCopperStrandsSelect,
			String productType, Integer layLengthSelect);

	/* Fetch  list of Item record based on Process Type */
	List<Item> findByProductTypeProcessType(String processType);

	/* Fetch  list of Item record based on item Type and numberOfCopperStrand */
	List<Item> findByItemTypeAndNumberOfCopperStrands(String itemType,
			Integer numberOfCopperStrand);

	/* Fetch  list of Item record based on item Type, numberOfCopperStrand and copperDiameter */
	List<Item> findByItemTypeAndNumberOfCopperStrandsAndCopperStrandDiameterCopperkey(
			String itemType, Integer numberOfCopperStrandsSelect,
			String copperDiameterSelect);

	/* Fetch  list of Item record based on copperDiameter, numberOfCopperStrand and product Type  */
	List<Item> findByCopperStrandDiameterCopperkeyAndNumberOfCopperStrandsAndProductTypeProductKey(
			String copperDiameterSelect, Integer numberOfCopperStrandsSelect,
			String productType);

	/* Fetch  list of Item record based on product Type  */
	List<Item> findByProductTypeProductType(String productType);

	/* Fetch  list of Item record based on product Type and numberOfCopperStrand */
	List<Item> findByProductTypeProductTypeAndNumberOfCopperStrands(
			String productType, Integer numberOfCopperStrand);

	/* Fetch  list of Item record based on copperDiameter,numberOfCopperStrand and  product Type */
	List<Item> findByCopperStrandDiameterCopperkeyAndNumberOfCopperStrandsAndProductTypeProductType(
			String copperDiameterSelect, Integer numberOfCopperStrandsSelect,
			String productType);

}
