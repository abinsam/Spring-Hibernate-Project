package org.balajicables.salesmanager.repository;

import java.util.List;

import org.balajicables.salesmanager.model.LabelReport;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Repository: Label report.
 * 
 * @author Abin Sam
 */
public interface LabelReportRepository extends JpaRepository<LabelReport, Long> {

	/* Fetch  list of LabelReport record based on ProductionWorkOrderNo */
	List<LabelReport> findByWorkOrderItemsProductionWorkOrderWorkOrderNo(
			String workOrderNo);

	/* Fetch  list of LabelReport record based on WorkOrder Item Id */
	List<LabelReport> findByWorkOrderItemsWorkOrderItemId(Long woItemId);

}