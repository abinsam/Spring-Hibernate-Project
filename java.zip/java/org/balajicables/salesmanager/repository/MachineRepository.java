package org.balajicables.salesmanager.repository;

import java.util.List;

import org.balajicables.salesmanager.model.MachineDetails;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Repository:Machine.
 * 
 * @author Abin Sam
 */
public interface MachineRepository extends JpaRepository<MachineDetails, Long> {

	/* Fetch  list of Machine record based on MachineNo */
	List<MachineDetails> findByMachineNo(Long mwdWoMachineNoSelect);

	/* Fetch  list of Machine record based on Machine Description */
	List<MachineDetails> findByDescription(String machineDesciption);

	/* Fetch  list of Machine record based on Work Order ProcessType */
	List<MachineDetails> findByProcessProcessType(String processType);

}