package org.balajicables.salesmanager.repository;

import java.util.List;

import org.balajicables.salesmanager.model.MwdWorkOrder;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Repository:MWD Work Order.
 * 
 * @author Abin Sam
 */
public interface MwdWorkOrderRepository extends
		JpaRepository<MwdWorkOrder, Long> {

	/* Fetch paged list of MWD Work Order record based on ProductionWorkOrder No */
	Page<MwdWorkOrder> findByProductionWorkOrderWorkOrderNo(String workOrderNo,
			Pageable pageable);
	
	/* Fetch list of MWD Work Order record based on ProductionWorkOrder No */
	List<MwdWorkOrder> findByProductionWorkOrderWorkOrderNo(String woNo);

	/* Fetch list of MWD Work Order record based on MWD Work Order Input Id*/
	List<MwdWorkOrder> findByMwdWoInputId(Long mwdWoInputId);

	/* Fetch list of MWD Work Order record based on Production WorkOrder No,inputSize And Customer Name*/
	List<MwdWorkOrder> findByProductionWorkOrderWorkOrderNoAndSizeAndCustomerName(
			String mwdWorkOrderNo, String inputSize, String customerName);

	/* Fetch list of MWD Work Order record based on Sales order item Id and Production WorkOrder No*/
	List<MwdWorkOrder> findBySalesOrderItemOrderDetailIdAndProductionWorkOrderWorkOrderNo(
			Long soItemId, String workOrderNo);

	/* Fetch list of MWD Work Order record based on Sales order,Item Code and Production WorkOrder No*/
	List<MwdWorkOrder> findBySalesOrderItemOrdersOrderIdAndSalesOrderItemItemsItemCodeAndProductionWorkOrderWorkOrderNo(
			String dummySalesOrder, String itemCode, String woNo);
}
