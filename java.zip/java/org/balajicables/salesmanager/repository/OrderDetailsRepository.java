package org.balajicables.salesmanager.repository;

import java.util.List;

import org.balajicables.salesmanager.model.SalesOrderItem;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Repository:Sales Order Items.
 * 
 * @author Abin Sam
 */

public interface OrderDetailsRepository extends
		JpaRepository<SalesOrderItem, Long> {

	/* Fetch paged list of Sales Order Item record based on Sales Order No */
	public Page<SalesOrderItem> findByOrdersOrderId(String sales,Pageable pageable);

	/* Fetch paged list of Sales Order Item record based on Sales OrderItem Id */
	public Page<SalesOrderItem> findByOrderDetailId(Long sales,
			Pageable pageable);

	/* Fetch  list of Sales Order Item record based on Sales OrderItem Id */
	public List<SalesOrderItem> findByOrderDetailId(Long ids);

	/* Fetch paged list of Sales Order Item record based on Sales Order No which matches entered character */
	public Page<SalesOrderItem> findByOrdersOrderIdLike(String orderId,
			Pageable pageRequest);

	/* Fetch paged list of Sales Order Item record based on CustomerName which matches entered character */
	public Page<SalesOrderItem> findByOrdersCustomerCustomerNameLike(
			String customer, Pageable pageRequest);

	/* Fetch paged list of Sales Order Item record based on Item code which matches entered character */
	public Page<SalesOrderItem> findByItemsItemCodeLike(String itemCode,
			Pageable pageRequest);

	/* Fetch list of Sales Order Item record based on Sales order No and Item code  */
	public List<SalesOrderItem> findByOrdersOrderIdAndItemsItemCode(
			String salesOrderId, String itemCode);

	/* Fetch list of Sales Order Item record based on Customer name ,Assorted type and sales order Status */
	public List<SalesOrderItem> findByOrdersCustomerCustomerNameAndItemsAssortedTypeAndOrdersOrderStatusStatusIn(
			String customerName, String assortedType, String[] orderStatus);

	/* Fetch paged list of Sales Order Item record with balance quantity greater than 0 */
	public Page<SalesOrderItem> findByBalanceQtyGreaterThan(Double d,
			Pageable pageable);

	/* Fetch list of Sales Order Item record based on sales order No */
	public List<SalesOrderItem> findByOrdersOrderId(String orderId);

	/* Fetch paged list of Sales Order Item record based on sales order No */
	public Page<SalesOrderItem> findByOrdersOrderStatusStatusIn(
			String[] orderStatus, Pageable pageable);
	
	/* Fetch paged list of Sales Order Item record with balance quantity greater than 0 based on itemType */
	public Page<SalesOrderItem> findByItemsItemTypeAndBalanceQtyGreaterThan(
			String itemType, Double balQty, Pageable pageable);

	/* Fetch paged list of Sales Order Item record based on itemType and sales order id */
	public Page<SalesOrderItem> findByOrdersOrderIdAndItemsAssortedType(
			String orderId, String itemType, Pageable pageable);

	/* Fetch list of Sales Order Item record based on itemCode */
	public List<SalesOrderItem> findByItemCode(String itemCode);

	/* Fetch list of Sales Order Item record based on itemCode and CustomerId  */
	public List<SalesOrderItem> findByItemCodeAndOrdersCustomerCustomerId(
			String itemCode, Long customerId);

	/* Fetch paged list of Sales Order Item record with balance quantity greater than 0 based on ProductType */
	public Page<SalesOrderItem> findByItemsProductTypeProductKeyAndBalanceQtyGreaterThan(
			String pdtTypeKey, Double balQty, Pageable pageable);

	/* Fetch list of Sales Order Item record  based on Item Type,customer id and sales Order Status*/
	public List<SalesOrderItem> findByItemsItemTypeAndOrdersCustomerCustomerIdAndOrdersOrderStatusStatus(
			String itemType, Long customerId, String status);

	/* Fetch list of Sales Order Item record  based on Item id*/
	public List<SalesOrderItem> findByItemsItemId(Long itemIdToDelete);

	/* Fetch paged list of Sales Order Item record  with balance quantity greater than 0 based on Customer id*/
	public Page<SalesOrderItem> findByOrdersCustomerCustomerIdGreaterThanAndBalanceQtyGreaterThan(
			Long customerId, Double balQty, Pageable pageable);

	/* Fetch paged list of Sales Order Item record  with balance quantity greater than 0 for customer other than balaji and based on item type*/
	public Page<SalesOrderItem> findByItemsItemTypeAndBalanceQtyGreaterThanAndOrdersCustomerCustomerIdGreaterThan(
			String itemType, Double balQty, Long customerId, Pageable pageable);

	/* Fetch paged list of Sales Order Item record  with balance quantity greater than 0 for customer other than balaji and based on  ProductKey*/
	public Page<SalesOrderItem> findByItemsProductTypeProductKeyAndBalanceQtyGreaterThanAndOrdersCustomerCustomerIdGreaterThan(
			String pdtTypeKey, Double balQty, Long customerId, Pageable pageable);

	/* Fetch paged list of Sales Order Item record  with balance quantity greater than 0 for customer other than balaji and based on  Sales order status*/
	public Page<SalesOrderItem> findByOrdersOrderStatusStatusInAndOrdersCustomerCustomerIdGreaterThanAndBalanceQtyGreaterThan(
			String[] orderStatus, Long customerId, Double balQty,
			Pageable pageable);

	/* Fetch paged list of Sales Order Item record  with balance quantity greater than 0 for customer other than balaji and based on  Sales order status*/
	public Page<SalesOrderItem> findByItemsItemTypeAndBalanceQtyGreaterThanAndOrdersCustomerCustomerIdGreaterThanAndOrdersOrderStatusStatusIn(
			String itemType, Double balQty, Long customerId,
			String[] orderStatus, Pageable pageable);
	
	/* Fetch list of Sales Order Item record  with balance quantity greater than 0 based on item type and  Sales order status*/
	public List<SalesOrderItem> findByItemsItemTypeAndOrdersOrderStatusStatusInAndBalanceQtyGreaterThan(
			String itemType, String[] orderStatus, Double balQty);

	/* Fetch list of Sales Order Item record  with balance quantity greater than 0 based on customer Id, item type and  Sales order status*/
	public List<SalesOrderItem> findByOrdersCustomerCustomerIdAndItemsItemTypeAndOrdersOrderStatusStatusInAndBalanceQtyGreaterThan(
			Long customerId, String itemType, String[] orderStatus,
			Double balQty);

	/* Fetch list of Sales Order Item record  with balance quantity greater than 0 based on Sales order status*/
	public List<SalesOrderItem> findByOrdersOrderStatusStatusInAndBalanceQtyGreaterThan(
			String[] orderStatus, Double balQty);

	/* Fetch list of Sales Order Item record  with balance quantity greater than 0 based on customer id and Sales order status*/
	public List<SalesOrderItem> findByOrdersCustomerCustomerIdAndOrdersOrderStatusStatusInAndBalanceQtyGreaterThan(
			Long customerId, String[] orderStatus, Double balQty);

	public List<SalesOrderItem> findByItemsItemTypeAndOrdersOrderStatusStatus(
			String itemType, String status);



}
