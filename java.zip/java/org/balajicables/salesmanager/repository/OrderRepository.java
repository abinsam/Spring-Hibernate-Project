package org.balajicables.salesmanager.repository;

import java.util.Date;
import java.util.List;

import org.balajicables.salesmanager.model.Customer;
import org.balajicables.salesmanager.model.SalesOrder;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

/**
 * Repository:Sales Order.
 * 
 * @author Abin Sam
 */
public interface OrderRepository extends JpaRepository<SalesOrder, String> {

	/* Fetch list of Sales Order record based on customer */
	public List<SalesOrder> findByCustomer(Customer customer);

	/* Fetch paged list of Sales Order record based on customer */
	public Page<SalesOrder> findByCustomer(Customer customer, Pageable pageable);

	/* Doing an eager fetch of Sales Order and customer record based on Sales Order No */
	@Query(value = "select o FROM SalesOrder o JOIN FETCH o.customer where o.orderId = ?")
	SalesOrder findOneWithCustomerLoaded(String id);

	/* Fetch paged list of Sales Order record  */
	public Page<SalesOrder> findAll(Pageable pageable);

	/* Fetch paged list of Sales Order record  based on sales order status*/
	public Page<SalesOrder> findByOrderStatusStatus(String orderStatus,
			Pageable pageable);

	
	/* Fetch list of Sales Order record  based on sales order No*/
	public List<SalesOrder> findByOrderId(String salesOrderId);

	
	/* Fetch list of Sales Order record based on CustomerId*/
	public List<SalesOrder> findByCustomerCustomerId(Long customerId);

	/* Fetch paged list of Sales Order record based on sales order status and order acceptance date between selected date*/
	public Page<SalesOrder> findByOrderStatusStatusAndOrderAcceptanceDateBetween(
			String status, Date fromDate, Date toDate, Pageable pageable);

	/* Fetch paged list of Sales Order record based on order acceptance date between selected date*/
	public Page<SalesOrder> findByOrderAcceptanceDateBetween(Date fromDate,
			Date toDate, Pageable pageable);

	/* Fetch list of Sales Order record  based on Sales order status*/
	public List<SalesOrder> findByOrderStatusStatus(String status);

	/* Fetch paged list of Sales Order record based on order acceptance date between selected date and Sales order status*/
	public Page<SalesOrder> findByOrderAcceptanceDateBetweenAndOrderStatusStatusNotIn(
			Date fromDate, Date toDate, String status, Pageable pageable);

	/* Fetch paged list of Sales Order record based on CustomerId and Sales order status*/
	public Page<SalesOrder> findByCustomerCustomerIdAndOrderStatusStatusIn(
			long customerId, String[] salesOrderStatus, Pageable pageable);


}
