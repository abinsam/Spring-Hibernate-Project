package org.balajicables.salesmanager.repository;

import java.util.List;

import org.balajicables.salesmanager.model.OrderStatus;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Repository:OrderStatus.
 * 
 * @author Abin Sam
 */
public interface OrderStatusRepository extends
		JpaRepository<OrderStatus, Integer> {
	/* Fetch list of Sales Order Status record based on Status */
	List<OrderStatus> findByStatus(String status);

}
