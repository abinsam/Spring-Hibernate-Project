package org.balajicables.salesmanager.repository;

import java.util.List;

import org.balajicables.salesmanager.model.PackingSlip;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Repository: PackingSlip.
 * 
 * @author Abin Sam
 */
public interface PackingSlipRepository extends
		JpaRepository<PackingSlip, Integer> {

	Page<PackingSlip> findByDeliveryChallanDeliveryChallanNo(
			String deliveryChallanNo, Pageable pageable);

	/*
	 * Page<PackingSlip> findByDeliveryChallansDeliveryChallanId( Long
	 * deliveryChallanId, Pageable pageable);
	 */
	/* Fetch list of PackingSlip record based on Delivery Challan No */
	List<PackingSlip> findByDeliveryChallanDeliveryChallanNo(
			String deliveryChallanNo);

}