package org.balajicables.salesmanager.repository;

import java.util.List;
import org.balajicables.salesmanager.model.ProductType;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Repository: ProductType.
 * 
 * @author Abin Sam
 */
public interface ProductTypeRepository extends
		JpaRepository<ProductType, String> {

	/* Fetch  list of ProductType record based on Product type*/
	List<ProductType> findByProductKey(String productType);

	/* Fetch  list of ProductType record based on Process type*/
	List<ProductType> findByProcessType(String processType);

}