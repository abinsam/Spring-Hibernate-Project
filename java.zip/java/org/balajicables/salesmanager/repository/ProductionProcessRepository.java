package org.balajicables.salesmanager.repository;

import java.util.List;

import org.balajicables.salesmanager.model.ProductionProcess;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Repository: ProductionProcess.
 * 
 * @author Abin Sam
 */
public interface ProductionProcessRepository extends
		JpaRepository<ProductionProcess, String> {
	
	/* Fetch list of ProductionProcess record based on Process Type */
	List<ProductionProcess> findByProcessType(String string);

}
