package org.balajicables.salesmanager.repository;

import java.util.List;

import org.balajicables.salesmanager.model.ProductionWorkOrder;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Repository: ProductionWorkOrder.
 * 
 * @author Abin Sam
 */
public interface ProductionWorkOrderRepository extends
		JpaRepository<ProductionWorkOrder, String> {

	/* Fetch list of ProductionWorkOrder record based on WorkOrderNo */
	List<ProductionWorkOrder> findByWorkOrderNo(String woNo);

	/* Fetch list of ProductionWorkOrder record based on Process Type */
	List<ProductionWorkOrder> findByProcessProcessType(String processType);

	/* Fetch list of ProductionWorkOrder record based on Process Type and work order status */
	List<ProductionWorkOrder> findByProcessProcessTypeAndStatus(
			String processType, String status);

}
