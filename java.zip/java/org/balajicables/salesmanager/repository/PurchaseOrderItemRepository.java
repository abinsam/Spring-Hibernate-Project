package org.balajicables.salesmanager.repository;

import java.util.List;

import org.balajicables.salesmanager.model.PurchaseOrderItem;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Repository: PurchaseOrder item.
 * 
 * @author Abin Sam
 */
public interface PurchaseOrderItemRepository extends
		JpaRepository<PurchaseOrderItem, Long> {
	
	/* Fetch  list of PurchaseOrderItem record based on Purchase Order No*/
	public Page<PurchaseOrderItem> findByPurchaseOrderPoNo(String poNo,
			Pageable pageable);

	/* Fetch  list of PurchaseOrderItem record based on Purchase Order No*/
	public List<PurchaseOrderItem> findByPurchaseOrderPoNo(String poNo);

	/* Fetch paged list of PurchaseOrderItem record based on Purchase Order No and purchase order status*/
	public Page<PurchaseOrderItem> findByPurchaseOrderPoNoAndStatus(
			String poNo, int status, Pageable pageable);

	/* Fetch  list of PurchaseOrderItem record based on Purchase OrderItem id*/
	public List<PurchaseOrderItem> findByPurchaseOrderItemId(Long id);

	/* Fetch  list of PurchaseOrderItem record based on Purchase Order Status*/
	public List<PurchaseOrderItem> findByPurchaseOrderPoStatus(String poNoStatus);

	/* Fetch  list of PurchaseOrderItem record based on item id*/
	public List<PurchaseOrderItem> findByItemItemId(Long itemIdToDelete);

}