package org.balajicables.salesmanager.repository;

import java.util.Date;
import java.util.List;

import org.balajicables.salesmanager.model.PurchaseOrder;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

/**
 * Repository: PurchaseOrder.
 * 
 * @author Abin Sam
 */
public interface PurchaseOrderRepository extends
		JpaRepository<PurchaseOrder, String> {

	/* Fetch paged list of PurchaseOrder record based on CustomerId */
	Page<PurchaseOrder> findByCustomerCustomerId(long customerId,
			Pageable pageable);

	/* Eager Fetch PurchaseOrder and vendor record based on Purchase order No */
	@Query(value = "select o FROM PurchaseOrder o JOIN FETCH o.customer where o.poNo = ?")
	PurchaseOrder findOneWithCustomerLoaded(String poNo);

	/* Fetch  list of PurchaseOrder record based on CustomerId */
	List<PurchaseOrder> findByCustomerCustomerId(Long customerId);

	/* Fetch paged list of PurchaseOrder record based on Purchase Order status */
	Page<PurchaseOrder> findByPoStatus(String orderStatus, Pageable pageable);

	/* Fetch  list of PurchaseOrder record based on Purchase Order No */
	List<PurchaseOrder> findByPoNo(String poNo);

	/* Fetch  list of PurchaseOrder record based on CustomerId and Purchase Order status*/
	List<PurchaseOrder> findByCustomerCustomerIdAndPoStatus(Long customerId,
			String poStatus);

	/* Fetch paged list of PurchaseOrder record based on Purchase order date between selected range of dates*/
	Page<PurchaseOrder> findByPoDateBetween(Date fromDate, Date toDate,
			Pageable pageable);

	/* Fetch paged list of PurchaseOrder record based on Purchase order date between selected range of dates and Purchase Order status*/
	Page<PurchaseOrder> findByPoStatusAndPoDateBetween(String orderStatus,
			Date fromDate, Date toDate, Pageable pageable);

	/* Fetch  list of PurchaseOrder record based on  Purchase Order status*/
	List<PurchaseOrder> findByPoStatus(String string);

}