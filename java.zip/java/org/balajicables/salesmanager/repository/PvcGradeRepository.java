package org.balajicables.salesmanager.repository;

import org.balajicables.salesmanager.model.PvcGrade;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Repository: PvcGrade.
 * 
 * @author Abin Sam
 */

public interface PvcGradeRepository extends JpaRepository<PvcGrade, Long> {

}