package org.balajicables.salesmanager.repository;

import java.util.List;

import org.balajicables.salesmanager.model.PvcStockOut;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Repository: PvcStockOut.
 * 
 * @author Abin Sam
 */
public interface PvcStockOutRepository extends JpaRepository<PvcStockOut, Long> {
	
	/* Fetch list of PvcStockOut record based on Batch and Production WorkOrder No */
	List<PvcStockOut> findByBatchAndProductionWorkOrderWorkOrderNo(
			String batch, String extrusionWoNo);
	
	/* Fetch list of PvcStockOut record based on Production WorkOrder No */
	Page<PvcStockOut> findByProductionWorkOrderWorkOrderNo(String woNo,
			Pageable pageable);
	
	/* Fetch list of PvcStockOut record based on ItemId*/
	List<PvcStockOut> findByItemItemId(Long itemIdToDelete);

}