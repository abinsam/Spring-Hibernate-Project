package org.balajicables.salesmanager.repository;

import java.util.Date;
import java.util.List;
import org.balajicables.salesmanager.model.RawMaterialStoreReg;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Repository:Raw Material StoreRegister.
 * 
 * @author Abin Sam
 */
public interface RawMaterialStoreRegrRepository extends
		JpaRepository<RawMaterialStoreReg, Long> {

	/* Fetch list of RawMaterial Store Register record  */
	List<RawMaterialStoreReg> findAll();

	/* Fetch list of  RawMaterial Store Register record based on Raw Material Store register Id */
	List<RawMaterialStoreReg> findByRwStoreRegId(Long idSelected);

	/* Fetch paged list of  RawMaterial Store Register record send as input for  RBD process*/
	Page<RawMaterialStoreReg> findBySendToRbd(Pageable pageable,
			String sendToRbd);

	/* Fetch paged list of  RawMaterial Store Register record send as input for  RBD process based on Stock in status and product type */
	Page<RawMaterialStoreReg> findBySendToRbdAndStockInStatusAndPurchaseOrderItemItemProductTypeProductKeyIn(
			Pageable pageable, String sendToRbd, String stockInStatus,
			String[] productType);

	/* Fetch paged list of  RawMaterial Store Register record send as input for  RBD process based on Stock in status and Purchase order No*/
	Page<RawMaterialStoreReg> findBySendToRbdAndStockInStatusAndPurchaseOrderItemPurchaseOrderPoNo(
			Pageable pageable, String sendToRbd, String stockInStatus,
			String poNo);

	/* Fetch list of  RawMaterial Store Register record based on Stock in status */
	List<RawMaterialStoreReg> findByStockInStatus(String stockedInStatus);

	/* Fetch paged list of  RawMaterial Store Register record based on Stock in status and send to RBD */
	Page<RawMaterialStoreReg> findBySendToRbdAndStockInStatus(
			Pageable pageable, String sendToRbd, String stockInStatus);

	/* Fetch paged list of  RawMaterial Store Register record based on Stock in status ,send to RBD and Item Type */
	Page<RawMaterialStoreReg> findByPurchaseOrderItemItemItemCodeAndSendToRbdAndStockInStatus(
			String itemIdSelect, String sendToRbd, String stockInstatus,
			Pageable pageable);

	/* Fetch paged list of  RawMaterial Store Register record based on QC status*/
	Page<RawMaterialStoreReg> findByQcStatus(Pageable pageable, String status);

	/* Fetch paged list of  RawMaterial Store Register record based on QC status and stock in date between selected range of date*/
	Page<RawMaterialStoreReg> findByQcStatusAndDateTimeBetween(String string,
			Date fromDate, Date toDate, Pageable pageable);

	/* Fetch paged list of  RawMaterial Store Register record based on QC status and reject status */
	Page<RawMaterialStoreReg> findByQcStatusAndRejectStatus(String qcStatus,
			String rejectStatus, Pageable pageable);

	/* Fetch paged list of  RawMaterial Store Register record based on QC status,reject status and stock in date between selected range of date*/
	Page<RawMaterialStoreReg> findByQcStatusAndRejectStatusAndDateTimeBetween(
			String qcStatus, String rejectStatus, Date fromDate, Date toDate,
			Pageable pageable);

	/* Fetch paged list of  RawMaterial Store Register record based on stock in date between selected range of date*/
	Page<RawMaterialStoreReg> findByDateTimeBetween(Date stockFromDate,
			Date stockToDate, Pageable pageable);

	/* Fetch paged list of  RawMaterial Store Register record based on QC status,stockIn status,send to rbd status and item Code*/
	Page<RawMaterialStoreReg> findByPurchaseOrderItemItemItemCodeAndSendToRbdAndStockInStatusAndQcStatus(
			String itemIdSelect, String sendToRbd, String stockInstatus,
			String qcStatus, Pageable pageable);
	
	/* Fetch paged list of  RawMaterial Store Register record based on QC status,stockIn status,send to rbd status and Product type*/
	Page<RawMaterialStoreReg> findBySendToRbdAndStockInStatusAndPurchaseOrderItemItemProductTypeProductKeyInAndQcStatusIn(
			Pageable pageable, String sendToRbd, String stockInstatus,
			String[] productType, String[] qcStatus);
	
	/* Fetch paged list of  RawMaterial Store Register record based on QC status,stockIn status and send to rbd status */
	Page<RawMaterialStoreReg> findBySendToRbdAndStockInStatusAndQcStatusIn(
			Pageable pageable, String sendToRbd, String stockInstatus,
			String[] qcStatus);

	/* Fetch paged list of  RawMaterial Store Register record based on QC status,stockIn status,item code ,stock date between selected range of date and send to rbd status */
	Page<RawMaterialStoreReg> findBySendToRbdAndStockInStatusAndPurchaseOrderItemItemItemCodeAndDateTimeBetweenAndQcStatusIn(
			Pageable pageable, String sendToRbd, String stockInstatus,
			String itemCode, Date stockFromDate, Date stockToDate,
			String[] qcStatus);

	/* Fetch paged list of  RawMaterial Store Register record based on QC status,stockIn status ,stock date between selected range of date and send to rbd status */
	Page<RawMaterialStoreReg> findBySendToRbdAndStockInStatusAndDateTimeBetweenAndQcStatusIn(
			Pageable pageable, String sendToRbd, String stockInstatus,
			Date stockFromDate, Date stockToDate, String[] qcStatus);

	/* Fetch paged list of  RawMaterial Store Register record based on QC status,stockIn status,item code and send to rbd status */
	Page<RawMaterialStoreReg> findBySendToRbdAndStockInStatusAndPurchaseOrderItemItemItemCodeAndQcStatusIn(
			Pageable pageable, String sendToRbd, String stockInstatus,
			String itemCode, String[] qcStatus);
	
	/* Fetch list of  RawMaterial Store Register record based on QC status */
	List<RawMaterialStoreReg> findByQcStatus(String status);

}
