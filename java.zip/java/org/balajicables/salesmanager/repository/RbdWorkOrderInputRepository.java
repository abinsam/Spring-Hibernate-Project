package org.balajicables.salesmanager.repository;

import java.util.List;

import org.balajicables.salesmanager.model.RbdWorkOrderInput;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Repository:Rbd WorkOrder Input.
 * 
 * @author Abin Sam
 */
public interface RbdWorkOrderInputRepository extends
		JpaRepository<RbdWorkOrderInput, Long> {

	/* Fetch paged list of RbdWorkOrderInput record based  Production WorkOrder No */
	Page<RbdWorkOrderInput> findByProductionWorkOrderWorkOrderNo(
			String workOrderNo, Pageable pageable);

	/* Fetch list of RbdWorkOrderInput record based on Production WorkOrder No */
	List<RbdWorkOrderInput> findByProductionWorkOrderWorkOrderNo(
			String workOrderNo);

}
