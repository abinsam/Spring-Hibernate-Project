package org.balajicables.salesmanager.repository;

import java.util.List;

import org.balajicables.salesmanager.model.ScrapDetails;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Repository:Scrap Details.
 * 
 * @author Abin Sam
 */
public interface ScrapDetailsRepository extends
		JpaRepository<ScrapDetails, Long> {
	
	/* Fetch list of  ScrapDetails record based on ScrapId */
	List<ScrapDetails> findByScrapId(Long id);

	/* Fetch list of  ScrapDetails record based on ItemId And StockedIn Status */
	List<ScrapDetails> findByItemItemIdAndStockedInStatus(Long itemId,
			String stockedInstatus);
	
	/* Fetch list of  ScrapDetails record based on ItemId */
	List<ScrapDetails> findByItemItemId(Long itemIdToDelete);

	/* Fetch paged list of  ScrapDetails record based on Production WorkOrderNo And StockedIn Status */
	Page<ScrapDetails> findByProductionWorkOrderWorkOrderNoAndStockedInStatus(
			String workOrder, String stockedInstatus, Pageable pageable);

}
