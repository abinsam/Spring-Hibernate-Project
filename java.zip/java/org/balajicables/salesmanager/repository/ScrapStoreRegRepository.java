package org.balajicables.salesmanager.repository;

import java.util.ArrayList;
import java.util.List;

import org.balajicables.salesmanager.model.ScrapStoreReg;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Repository:Scrap Store Register.
 * 
 * @author Abin Sam
 */

public interface ScrapStoreRegRepository extends
		JpaRepository<ScrapStoreReg, Long> {

	/* Fetch list of  Scrap store Register record based on ItemId */
	List<ScrapStoreReg> findByItemsItemId(Long itemId);

	/* Fetch list of  Scrap store Register record based on Scrap store Register Id */
	List<ScrapStoreReg> findByScrapStoreRegId(Long scrapStoreRegId);

	/* Fetch paged list of  Scrap store Register record based on ItemCode */
	Page<ScrapStoreReg> findByItemsItemCodeIn(ArrayList<String> itemCode,
			Pageable pageable);

}
