package org.balajicables.salesmanager.repository;

import java.util.List;

import org.balajicables.salesmanager.model.SemifinishedStockOut;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Repository: Semifinished Stock Out.
 * 
 * @author Abin Sam
 */

public interface SemifinishedStockOutRepository extends
		JpaRepository<SemifinishedStockOut, Long> {

	/* Fetch paged list of  Semifinished Stock Out record based on Production WorkOrderNo And ConfirmStatus */
	Page<SemifinishedStockOut> findByProductionWorkOrderWorkOrderNoAndConfirmStatus(
			String woNo, String confrimStatus, Pageable pageable);

	/* Fetch paged list of  Semifinished Stock Out record based on Production WorkOrderNo,stock Out process And ConfirmStatus */
	Page<SemifinishedStockOut> findByProductionWorkOrderWorkOrderNoAndProductionWorkOrdersProcessProcessTypeAndConfirmStatus(
			String workOrder, String woStockedOutProcess, String confirmStatus,
			Pageable pageable);

	/* Fetch  list of  Semifinished Stock Out record based on Production WorkOrderNo */
	List<SemifinishedStockOut> findByProductionWorkOrderWorkOrderNo(
			String workOrder);
	
	/* Fetch list of  Semifinished Stock Out record based on Production WorkOrderNo And stock Out process */
	List<SemifinishedStockOut> findByProductionWorkOrderWorkOrderNoAndProductionWorkOrdersProcessProcessType(
			String workOrder, String woStockedOutProcess);

	/* Fetch paged list of  Semifinished Stock Out record based on logged in user,item type and confirm status */
	Page<SemifinishedStockOut> findByConfirmStatusAndSupervisorAndSalesOrderItemItemsItemTypeIn(
			String confirmStatus, String userName, String[] itemTypeArray,
			Pageable pageable);
	
	/* Fetch  list of  Semifinished Stock Out record based on Semifinished Stock Out Id */
	List<SemifinishedStockOut> findBySemifinishedStockOutId(
			Long semifinishedStockOutId);
	
	/* Fetch  list of  Semifinished Stock Out record based on Production Work order No,SalesOrderNo ,item code,bundle id And confirm status */
	List<SemifinishedStockOut> findBySalesOrderItemOrdersOrderIdAndSalesOrderItemItemsItemCodeAndProductionWorkOrdersWorkOrderNoAndBundleIdAndConfirmStatus(
			String soNo, String itemCode, String woNo, String bundleId,
			String confirmStatus);

}