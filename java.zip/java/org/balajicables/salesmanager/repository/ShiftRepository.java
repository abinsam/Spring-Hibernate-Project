package org.balajicables.salesmanager.repository;

import java.util.List;

import org.balajicables.salesmanager.model.Shift;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Repository: Shift.
 * 
 * @author Abin Sam
 */

public interface ShiftRepository extends JpaRepository<Shift, Integer> {

     /* Fetch  Shift record based on Shift Id */
    	Shift findByShiftId(Integer shiftSelect);

    /* Fetch list of Shift record based on Shift pattern */
	List<Shift> findByShiftPattern(String shiftPattern);

}