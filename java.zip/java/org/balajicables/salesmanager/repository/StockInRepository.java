package org.balajicables.salesmanager.repository;

import java.util.List;
import org.balajicables.salesmanager.model.StockIn;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Repository: StockIn.
 * 
 * @author Abin Sam
 */

public interface StockInRepository extends JpaRepository<StockIn, Long> {

    /* Fetch list of StockIn record based on sales order item id */
	List<StockIn> findBySalesOrderItemOrderDetailId(Long soItemId);

    /* Fetch paged list of StockIn record based on confirm status */
	Page<StockIn> findByConfirmStatus(String confirmStatus, Pageable pageable);

    /* Fetch list of StockIn record based on stock in id */
	List<StockIn> findByStockInId(Long stockInId);

    /* Fetch list of StockIn record based on sales order item id,bundle id and Production work order no */
	List<StockIn> findBySalesOrderItemOrderDetailIdAndBundleIdAndProductionWorkOrderWorkOrderNo(
			Long soItemDetailsId, String bundleId, String workOrderNo);
   
	/* Fetch list of StockIn record based on sales order No ,item code,bundle id and Production work order no */
	List<StockIn> findBySalesOrderItemOrdersOrderIdAndSalesOrderItemItemsItemCodeAndProductionWorkOrderWorkOrderNoAndBundleId(
			String salesOrderId, String itemCode, String workOrderNo,
			String bundleId);

	/* Fetch paged list of StockIn record based on confirm status andlogged in user */
	Page<StockIn> findByConfirmStatusAndSupervisor(String confirmStatus,
			String userName, Pageable pageable);
	
	/* Fetch list of StockIn record based on sales order No ,item code,bundle id  Production work order no and Confirm status */
	List<StockIn> findBySalesOrderItemOrdersOrderIdAndSalesOrderItemItemsItemCodeAndProductionWorkOrderWorkOrderNoAndBundleIdAndConfirmStatus(
			String salesOrderId, String itemCode, String workOrderNo,
			String bundleId, String confirmStatus);

	/* Fetch list of StockIn record based on sales order item id,  Production work order no and Confirm status */
	List<StockIn> findBySalesOrderItemOrderDetailIdAndProductionWorkOrderWorkOrderNoAndConfirmStatus(
			Long newSalesOrderItemId, String oldWoNo, String confirmStatus);
	
	/* Fetch list of StockIn record based on sales order No ,item code and Production work order no */
	List<StockIn> findBySalesOrderItemOrdersOrderIdAndSalesOrderItemItemsItemCodeAndProductionWorkOrderWorkOrderNo(
			String newSalesOrderNo, String itemCode, String oldWoNo);

}
