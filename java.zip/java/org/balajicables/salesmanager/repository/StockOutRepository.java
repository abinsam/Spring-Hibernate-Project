package org.balajicables.salesmanager.repository;

import java.util.List;

import org.balajicables.salesmanager.model.StockOut;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Repository: StockOut.
 * 
 * @author Abin Sam
 */
public interface StockOutRepository extends JpaRepository<StockOut, Long> {

	/* Fetch  list of StockOut record based on StockOut Id*/
	List<StockOut> findByStockOutId(Long stockOutId);
	
	/* Fetch  list of StockOut record based on Sales order item id,work order no and bundle id*/
	List<StockOut> findBySalesOrderItemOrderDetailIdAndProductionWorkOrderWorkOrderNoAndBundleId(
			Long orderDetailsId, String workOrderNo, String bundleId);
	
	/* Fetch paged list of StockOut record based on confirm status*/
	Page<StockOut> findByConfirmStatus(String confirmStatus, Pageable pageable);
	
	/* Fetch  list of StockOut record based on Sales order item id*/
	List<StockOut> findBySalesOrderItemOrderDetailId(Long orderDetailsId);
	
	/* Fetch  list of StockOut record based on Sales order item id,work order no and bag No*/
	List<StockOut> findBySalesOrderItemOrderDetailIdAndProductionWorkOrderWorkOrderNoAndPackingSlipNo(
			Long orderDetailId, String workOrderNo, Long bagNo);

	/* Fetch  list of StockOut record based on Delivery challan No*/
	List<StockOut> findByDeliveryChallanNo(String newdeliveryChallanNo);
	
	/* Fetch  list of StockOut record based on customer id*/
	List<StockOut> findBySalesOrderItemOrdersCustomerCustomerId(Long customerId);
	
	/* Fetch  list of StockOut record based on Sales order No,confirm status and bag No*/
	List<StockOut> findBySalesOrderItemOrdersOrderIdAndPackingSlipNoAndConfirmStatus(
			String soNo, Long bagNo, String confirmStatus);
	
	/* Fetch  list of StockOut record based on Sales order no,work order no and bag No*/
	List<StockOut> findBySalesOrderItemOrdersOrderIdAndProductionWorkOrderWorkOrderNoAndPackingSlipNo(
			String orderId, String workOrderNo, Long bagNo);

	/* Fetch  list of StockOut record based on Sales order no,item Code,work order no and bundleId*/
	List<StockOut> findBySalesOrderItemOrdersOrderIdAndSalesOrderItemItemsItemCodeAndProductionWorkOrderWorkOrderNoAndBundleId(
			String salesOrderId, String itemCode, String workOrderNo,
			String bundleId);
	
	/* Fetch  list of StockOut record based on Sales order no and confirm Status*/
	List<StockOut> findBySalesOrderItemOrdersOrderIdAndConfirmStatus(
			String salesOrderNo, String confirmStatus);
	
	/* Fetch  list of StockOut record based on Sales order item id and confirm Status*/
	List<StockOut> findBySalesOrderItemOrderDetailIdAndConfirmStatus(
			Long orderDetailId, String confirmStatus);
	
	/* Fetch paged list of StockOut record based on ConfirmStatus and item type*/
	Page<StockOut> findByConfirmStatusAndSalesOrderItemItemsItemTypeIn(
			String confirmStatus, String[] itemType, Pageable pageable);

	
	
	/* Fetch list of StockOut record based on work order no and process type*/
	List<StockOut> findByProductionWorkOrderWorkOrderNoAndProductionWorkOrderProcessProcessType(
			String workOrder, String process);

	/* Fetch paged list of StockOut record based on ConfirmStatus and logged in user*/
	Page<StockOut> findByConfirmStatusAndSupervisor(String confirmStatus,
			String userName, Pageable pageable);

	/* Fetch  list of StockOut record based on salesOrderId,itemCode,workOrderNo, bundleId and ConfirmStatus */
	List<StockOut> findBySalesOrderItemOrdersOrderIdAndSalesOrderItemItemsItemCodeAndProductionWorkOrderWorkOrderNoAndBundleIdAndConfirmStatus(
			String salesOrderId, String itemCode, String workOrderNo,
			String bundleId, String confirmStatus);

	List<StockOut> findBySalesOrderItemOrderDetailIdAndProductionWorkOrderWorkOrderNoAndConfirmStatus(
			Long salesOrderItemId, String workOrderNo, String confrimstatus);

	List<StockOut> findDistinctDeliveryChallanNoBySalesOrderItemOrderDetailId(
			Long salesOrderItemId);

}