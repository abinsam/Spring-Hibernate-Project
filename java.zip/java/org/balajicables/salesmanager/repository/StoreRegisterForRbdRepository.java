package org.balajicables.salesmanager.repository;

import java.util.List;

import org.balajicables.salesmanager.model.RawMaterialStoreReg;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Repository: Raw Material StoreRegister For RBD.
 * 
 * @author Abin Sam
 */
public interface StoreRegisterForRbdRepository extends
		JpaRepository<RawMaterialStoreReg, Long> {

	 /* Fetch list of raw material store register records based on raw material store register id */
	List<RawMaterialStoreReg> findByRwStoreRegId(Long rwStoreRegId);

}
