package org.balajicables.salesmanager.repository;

import java.util.Date;
import java.util.List;

import org.balajicables.salesmanager.model.StoreRegister;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Repository: StoreRegister.
 * 
 * @author Abin Sam
 */
public interface StoreRegisterRepository extends
		JpaRepository<StoreRegister, Long> {

	 /* Fetch list of StoreRegister records based on store register id */
	List<StoreRegister> findByStoreRegisterId(Long storeRegisterId);
	
	 /* Fetch list of StoreRegister records based on salesOrderId,itemCode,bundleId and workOrderNo */
	List<StoreRegister> findByOrderIdAndSalesOrderItemItemsItemCodeAndBundleIdAndProductionWorkOrderWorkOrderNo(
			String salesOrderId, String itemCode, String bundleId,
			String workOrderNo);
	
	 /* Fetch list of StoreRegister records based on sales order item id */
	List<StoreRegister> findBySalesOrderItemOrderDetailId(Long orderDetailsId);
	
	 /* Fetch list of StoreRegister records based on sales order item id,bundle id and work order no */
	List<StoreRegister> findBySalesOrderItemOrderDetailIdAndBundleIdAndProductionWorkOrderWorkOrderNo(
			Long orderDetailId, String bundleId, String woNo);
	
	 /* Fetch list of StoreRegister records based on sales order item id, work order no  and bag no*/
	List<StoreRegister> findBySalesOrderItemOrderDetailIdAndProductionWorkOrderWorkOrderNoAndPackingSlipNo(
			Long orderDetailId, String workOrderNo, Long bagNo);

	 /* Fetch list of StoreRegister records based on sales order no and bag no*/
	List<StoreRegister> findBySalesOrderItemOrdersOrderIdAndPackingSlipNo(
			String soNo, Long bagNo);

	 /* Fetch paged list of StoreRegister records based on item type*/
	Page<StoreRegister> findBySalesOrderItemItemsItemTypeIn(String[] itemType,
			Pageable pageable);

	 /* Fetch list of StoreRegister records based on soNo, itemCode and woNo*/
	List<StoreRegister> findByOrderIdAndItemCodeAndProductionWorkOrderWorkOrderNo(
			String soNo, String itemCode, String woNo);

	 /* Fetch list of StoreRegister records based on soNo, bagNo and woNo*/
	List<StoreRegister> findBySalesOrderItemOrdersOrderIdAndProductionWorkOrderWorkOrderNoAndPackingSlipNo(
			String orderId, String workOrderNo, Long bagNo);

	 /* Fetch paged list of StoreRegister records based on qc status*/
	Page<StoreRegister> findByQcStatus(Pageable pageable, String status);

	 /* Fetch paged list of StoreRegister records based on reject status*/
	Page<StoreRegister> findByRejectStatusNotIn(Pageable pageable, String string);

	 /* Fetch paged list of StoreRegister records based on qc status*/
	Page<StoreRegister> findByQcStatusNotIn(Pageable pageable, String string);

	 /* Fetch paged list of StoreRegister records based on qc status and updated date between selected range of date*/
	Page<StoreRegister> findByQcStatusAndUpdatedDateTimeBetween(String string,
			Date fromDate, Date toDate, Pageable pageable);
	
	/* Fetch paged list of StoreRegister records based on reject status*/
	Page<StoreRegister> findByRejectStatus(String rejectStatus,
			Pageable pageable);
	
	 /* Fetch paged list of StoreRegister records based on reject status and updated date between selected range of date*/
	Page<StoreRegister> findByRejectStatusAndUpdatedDateTimeBetween(
			String rejectStatus, Date fromDate, Date toDate, Pageable pageable);

	 /* Fetch paged list of StoreRegister records based on updated date between selected range of date*/
	Page<StoreRegister> findByUpdatedDateTimeBetween(Date stockFromDate,
			Date stockToDate, Pageable pageable);

	 /* Fetch  list of StoreRegister records based on sales order Number*/
	List<StoreRegister> findBySalesOrderItemOrdersOrderId(
			String salesorderNumber);

	 /* Fetch  list of StoreRegister records based on CustomerName*/
	List<StoreRegister> findBySalesOrderItemOrdersCustomerCustomerName(
			String customerId);

	 /* Fetch  list of StoreRegister records based on workOrder and process */
	List<StoreRegister> findByProductionWorkOrderWorkOrderNoAndProductionWorkOrderProcessProcessType(
			String workOrder, String process);

	 /* Fetch  list of StoreRegister records based on QcStatus */
	List<StoreRegister> findByQcStatus(String status);

	 /* Fetch  list of StoreRegister records based on QcStatus and customer id */
	List<StoreRegister> findBySalesOrderItemOrdersCustomerCustomerIdAndQcStatus(
			Long customerId, String qcStatus);

	 /* Fetch  list of StoreRegister records based on processType*/
	List<StoreRegister> findByProductionWorkOrderProcessProcessType(
			String processType);

	 /* Fetch  list of StoreRegister records based on qcStatus and processType*/
	List<StoreRegister> findByQcStatusAndProductionWorkOrderProcessProcessType(
			String qcStatus, String processType);

	List<StoreRegister> findBySalesOrderItemOrderDetailIdAndProductionWorkOrderWorkOrderNo(
			Long salesOrderItemId, String workOrderNo);

	List<StoreRegister> findBySalesOrderItemItemsItemId(Long itemIds);

}
