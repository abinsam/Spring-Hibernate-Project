package org.balajicables.salesmanager.repository;

import java.util.List;

import org.balajicables.salesmanager.model.TaxRate;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Repository:Tax Rate.
 * 
 * @author Abin Sam
 */

public interface TaxRateRepository extends JpaRepository<TaxRate, Long> {

	/* Fetch  list of TaxRate record based on Customer Id*/
	List<TaxRate> findByCustomerCustomerId(long customerId);

}