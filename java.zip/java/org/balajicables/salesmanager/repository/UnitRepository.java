package org.balajicables.salesmanager.repository;

import org.balajicables.salesmanager.model.Unit;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Repository:Unit.
 * 
 * @author Abin Sam
 */

public interface UnitRepository extends JpaRepository<Unit, Long> {

}