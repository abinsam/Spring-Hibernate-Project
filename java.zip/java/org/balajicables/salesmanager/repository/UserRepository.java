package org.balajicables.salesmanager.repository;

import org.balajicables.salesmanager.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Repository:User.
 * 
 * @author Abin Sam
 */
public interface UserRepository extends JpaRepository<User, String> {

	/* Fetch   User record based on emailId*/
	public User findByEmailId(String emailId);

	/* Fetch   User record based on user name*/
	public User findByUserName(String userName);

}
