package org.balajicables.salesmanager.repository;

import java.util.List;

import org.balajicables.salesmanager.model.WorkOrderItems;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Repository:WorkOrderItem(Extrusion).
 * 
 * @author Abin Sam
 */
public interface WorkOrderItemRepository extends
		JpaRepository<WorkOrderItems, Long> {

	/* Fetch paged list of WorkOrderItems record based on work order no*/
	Page<WorkOrderItems> findByProductionWorkOrderWorkOrderNo(
			String workOrderNo, Pageable pageable);

	// List<WorkOrderItems> findByWorkOrderItemId(Long woItemId);

	/* Fetch  list of WorkOrderItems record based on sales order item id*/
	List<WorkOrderItems> findBySalesOrderItemOrderDetailId(Long soItemId);

	/* Fetch  list of WorkOrderItems record based on sales order  no*/
	List<WorkOrderItems> findBySalesOrderItemOrdersOrderId(String orderId);

	/* Fetch  list of WorkOrderItems record based on work order  no*/
	List<WorkOrderItems> findByProductionWorkOrderWorkOrderNo(String workOrderNo);

	/* Fetch  list of WorkOrderItems record based on sales order item id and work order no*/
	List<WorkOrderItems> findBySalesOrderItemOrderDetailIdAndProductionWorkOrderWorkOrderNo(
			Long soItemId, String workOrderNo);

	/* Fetch  list of WorkOrderItems record based on  work order item id*/
	List<WorkOrderItems> findByWorkOrderItemId(Long woItemId);

	/* Fetch  list of WorkOrderItems record based on sales order  no,item code and work order no*/
	List<WorkOrderItems> findBySalesOrderItemOrdersOrderIdAndSalesOrderItemItemsItemCodeAndProductionWorkOrderWorkOrderNo(
			String salesOrderId, String itemCode, String workOrderNo);

	/* Fetch  list of WorkOrderItems record based on work order process type*/
	List<WorkOrderItems> findByProductionWorkOrderProcessProcessType(
			String process);

	/* Fetch  list of WorkOrderItems record based on work order no and stock in status of wo items*/
	List<WorkOrderItems> findByProductionWorkOrderWorkOrderNoAndStockInStatus(
			String workOrderNo, String status);

	Page<WorkOrderItems> findBySalesOrderItemOrderDetailId(
			Long salesOrderItemId, Pageable pageable);



}