package org.balajicables.salesmanager.repository;

import java.util.List;

import org.balajicables.salesmanager.model.WorkOrderOutput;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Repository:WorkOrderOutput.
 * 
 * @author Abin Sam
 */

public interface WorkOrderOutputRepository extends
		JpaRepository<WorkOrderOutput, Long> {

	/* Fetch paged list of WorkOrderOutput record based on work order no*/
	Page<WorkOrderOutput> findByProductionWorkOrderWorkOrderNo(
			String workOrderNo, Pageable pageable);

	/* Fetch  list of WorkOrderOutput record based on work order no*/
	List<WorkOrderOutput> findByProductionWorkOrderWorkOrderNo(
			String workOrderNo);

	/* Fetch  list of WorkOrderOutput record based on batch no*/
	List<WorkOrderOutput> findByBatchNo(String batchNo);

	/* Fetch  list of WorkOrderOutput record based on WorkOrderOutput Id*/
	List<WorkOrderOutput> findByWoOutPutId(Long id);

	/* Fetch  list of WorkOrderOutput record based on sales order item id and work order no*/
	List<WorkOrderOutput> findBySalesOrderItemOrderDetailIdAndProductionWorkOrderWorkOrderNo(
			Long soItemId, String workOrderNo);

	/* Fetch  list of WorkOrderOutput record based on sales order no ,item code and work order no*/
	List<WorkOrderOutput> findBySalesOrderItemOrdersOrderIdAndSalesOrderItemItemsItemCodeAndProductionWorkOrderWorkOrderNo(
			String soNo, String itemCode, String woNo);

	/* Fetch  list of WorkOrderOutput record based on sales order no item id,batch no and work order no*/
	List<WorkOrderOutput> findBySalesOrderItemOrderDetailIdAndProductionWorkOrderWorkOrderNoAndBatchNo(
			Long orderDetailsId, String workOrderNo, String batchNo);

	/* Fetch  list of WorkOrderOutput record based on sales order no,item code,batch no and work order no*/
	List<WorkOrderOutput> findBySalesOrderItemOrdersOrderIdAndSalesOrderItemItemsItemCodeAndProductionWorkOrderWorkOrderNoAndBatchNo(
			String soNo, String itemCode, String woNo, String batchNo);

	/* Fetch  list of WorkOrderOutput record based on sales order item id*/
	List<WorkOrderOutput> findBySalesOrderItemOrderDetailId(Long soItemId);

	Page<WorkOrderOutput> findBySalesOrderItemOrderDetailId(
			Long salesOrderItemId, Pageable pageable);

}