package org.balajicables.salesmanager.service;

import java.util.List;

import org.balajicables.salesmanager.model.AssortedRate;

/**
 * Service Interface of Assorted Rate.
 * 
 * @author Abin Sam
 */
public interface AssortedRateService {

	List<AssortedRate> findByCustomerCodeAndAssortedType(String customerCode,
			String assortedType);

	AssortedRate create(AssortedRate assortedRate);

	Boolean update(AssortedRate assortedRate);

}
