package org.balajicables.salesmanager.service;

/**
 * Service Interface of BasketDetails.
 * 
 * @author Abin Sam
 */

public interface BasketDetailsService {

}
