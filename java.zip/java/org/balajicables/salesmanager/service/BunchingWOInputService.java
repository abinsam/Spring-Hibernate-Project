package org.balajicables.salesmanager.service;

import java.util.List;

import org.balajicables.salesmanager.model.BunchingWOInput;
import org.springframework.data.domain.Page;

/**
 * Service Interface of Bunching WO Input.
 * 
 * @author Abin Sam
 */

public interface BunchingWOInputService {

	BunchingWOInput create(BunchingWOInput bunchingWOInput);

	Boolean update(BunchingWOInput bunchingWoInput);

	Page<BunchingWOInput> getPagedOrders(String workOrderNo, int i,
			Integer rowsPerPage, String sortColName, String sortOrder);

	Boolean delete(BunchingWOInput bunchingWOInput);

	List<BunchingWOInput> findbyWorkOrderNoBunchingSizeCustomerName(
			String bunchingWorkOrderNoTag, String inputSize, String customerName);

	List<BunchingWOInput> fetchLatestByProductionWorkOrderWorkOrderNo(
			String bunchingWorkOrderNoTag);

	List<BunchingWOInput> findBySoItemIdAndWorkOrderNo(Long long1,
			String workOrderNo);

	List<BunchingWOInput> findById(Long id);

	List<BunchingWOInput> findByOrderIdAndItemCodeAndWorkOrderNo(
			String dummySalesOrder, String itemCode, String woNo);

}