package org.balajicables.salesmanager.service;

import java.util.List;
import org.balajicables.salesmanager.model.CableStdPvc;

/**
 * Service Interface of CableStdPvc.
 * 
 * @author Abin Sam
 */
public interface CableStdPvcService {

	public List<CableStdPvc> findAll();

}
