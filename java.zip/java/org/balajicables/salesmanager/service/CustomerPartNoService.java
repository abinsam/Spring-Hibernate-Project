package org.balajicables.salesmanager.service;

import java.util.List;

import org.balajicables.salesmanager.model.CustomerPartNo;
import org.springframework.data.domain.Page;

/**
 * Service Interface of CustomerPartNo.
 * 
 * @author Abin Sam
 */
public interface CustomerPartNoService {

	List<CustomerPartNo> findByCustomerIdAndItemId(Long custId, Long itemId);

	List<CustomerPartNo> findByItemsItemId(Long itemIdToDelete);

	Page<CustomerPartNo> getPagedTaxes(int i, Integer rowsPerPage,
			String sortColName, String sortOrder);

	List<CustomerPartNo> fetchBySearch(Long qCustomerId, Long qitemId,
			int pagenumber, Integer rows, String sortColName, String sortOrder);

	CustomerPartNo create(CustomerPartNo itemObj);

	Boolean update(CustomerPartNo itemObj);

	List<CustomerPartNo> findById(Integer id);

	Boolean delete(Integer partNoId);

	List<CustomerPartNo> findByCustomerIdAndItemCode(Long customerSelect,
			String itemIdSelect);

}
