package org.balajicables.salesmanager.service;

import java.util.List;

import org.balajicables.salesmanager.model.Customer;
import org.springframework.data.domain.Page;

/**
 * Service Interface of Customer.
 * 
 * @author Abin Sam
 */
public interface CustomerService {

	Boolean create(Customer customer);

	Boolean update(Customer customer);

	Boolean delete(Long customerIdToDelete);

	Page<Customer> getPagedCustomers(int i, Integer rowsPerPage,
			String sortColName, String sortOrder);

	List<Customer> findAll();

//	void setCustomerId(Long customerId);

	List<Customer> findById(Long customerId);

	List<Customer> findByCustomerName(String custName);

	Page<Customer> findById(Long customerId, int i, Integer rowsPerPage,
			String sortColName, String sortOrder);

	List<Customer> findByCustomerCode(String customerCode);

}
