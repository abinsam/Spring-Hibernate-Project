package org.balajicables.salesmanager.service;

import java.util.List;

import org.balajicables.salesmanager.model.DeliveryChallanItems;
import org.springframework.data.domain.Page;

/**
 * Service Interface of DeliveryChallanItems.
 * 
 * @author Abin Sam
 */

public interface DeliveryChallanItemsService {

	DeliveryChallanItems create(DeliveryChallanItems dcItemList);

	Page<DeliveryChallanItems> getPagedDeliveryChallanItems(
			String deliveryChallanNo, int i, Integer rowsPerPage,
			String sortColName, String sortOrder);

	Page<DeliveryChallanItems> getPagedRecords(int i, Integer rowsPerPage,
			String sortColName, String sortOrder, String invoiceStatus,
			String deliveryChallanNo);

	List<DeliveryChallanItems> findByDeliveryChallanDeliveryChallanNoAndDeliveryChallanInvoiceStatus(
			String deliveryChallanNo, String invoiceStatus);

	List<DeliveryChallanItems> findByDeliveryChallanNo(String deliveryChallanNo);
	
	

	Boolean delete(Long dcItemId);

	List<DeliveryChallanItems> findByItemItemIdAndDeliveryChallanOrdersOrderId(
			Long itemId, String orderId);

}
