package org.balajicables.salesmanager.service;

import java.util.List;
import org.balajicables.salesmanager.model.DeliveryChallan;
import org.springframework.data.domain.Page;

/**
 * Service Interface of Delivery Challan.
 * 
 * @author Abin Sam
 */

public interface DeliveryChallanService {

	DeliveryChallan create(DeliveryChallan dcItem);

	Page<DeliveryChallan> getPagedPackingSlipDetails(String dcNo, int i,
			Integer rowsPerPage, String sortColName, String sortOrder);

	List<DeliveryChallan> fetchLatestDeliveryChallan();

	Page<DeliveryChallan> getPagedRecords(int i, Integer rowsPerPage,
			String sortColName, String sortOrder, String invoiceStatus,
			String deliveryChallanNo);

	Boolean delete(String dcNo);

	List<DeliveryChallan> findByDeliveryChallanNo(String deliveryChallanNo);

	List<DeliveryChallan> findByDeliveryChallanNoAndInvoiceStatus(
			String deliveryChallanNo, String invoiceStatus);

	Boolean update(DeliveryChallan deliveryChallan);

	List<DeliveryChallan> findByOrderCustomerCustomerId(Long customerId);

	List<DeliveryChallan> finddByStockOutsAndMonthYear(int month, int year);

	List<DeliveryChallan> finddByCustomerAndMonthYear(Long customerId,
			int monthValue, int yearValue);


}
