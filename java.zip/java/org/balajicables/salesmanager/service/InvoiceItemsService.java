package org.balajicables.salesmanager.service;

import java.util.List;

import org.balajicables.salesmanager.model.InvoiceItems;
import org.springframework.data.domain.Page;

/**
 * Service Interface of InvoiceItems.
 * 
 * @author Abin Sam
 */
public interface InvoiceItemsService {

	InvoiceItems save(InvoiceItems invoice);

	Page<InvoiceItems> getPagedOrders(String invoiceNo, int pageNumber,
			Integer rowsPerPage, String sortColName, String sortOrder);

	List<InvoiceItems> findByInvoiceNo(String newdInvoiceNo);

	Boolean delete(Long invoiceId);

}
