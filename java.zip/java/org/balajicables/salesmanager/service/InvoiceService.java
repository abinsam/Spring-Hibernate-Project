package org.balajicables.salesmanager.service;

import java.util.List;

import org.balajicables.salesmanager.model.Invoice;

/**
 * Service Interface of Invoice.
 * 
 * @author Abin Sam
 */

public interface InvoiceService {

	List<Invoice> fetchLatestInvoiceNo();

	Invoice save(Invoice invoice);

	List<Invoice> findByInvoiceNo(String newdInvoiceNo);

	List<Invoice> findByCustomerId(Long customerId);

	Boolean update(Invoice invoices);

	Boolean delete(String invoiceNo);

	List<Invoice> findByMonthYear(int month, int year);

	List<Invoice> finddByCustomerAndMonthYear(Long customerId, int monthValue,
			int yearValue);

}
