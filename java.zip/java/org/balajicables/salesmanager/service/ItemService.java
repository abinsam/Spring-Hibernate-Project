package org.balajicables.salesmanager.service;

import java.util.List;
import org.balajicables.salesmanager.model.Area;
import org.balajicables.salesmanager.model.CableStdPvc;
import org.balajicables.salesmanager.model.Colour;
import org.balajicables.salesmanager.model.CopperDiameter;
import org.balajicables.salesmanager.model.Item;
import org.balajicables.salesmanager.model.ProductType;
import org.balajicables.salesmanager.model.Unit;
import org.springframework.data.domain.Page;

/**
 * Service Interface of Item Master.
 * 
 * @author Abin Sam
 */
public interface ItemService {

	public List<Item> getAll();

	public List<Item> getPagedItems(int pageNumber, int recordsPerPage,
			String sortColName, String sortOrder);

	public long getItemsCount();

	public Boolean update(Long itemId, String itemCode, String itemName,
			String color);

	public Boolean delete(Long itemId);

	List<Colour> getAllColours();

	List<CopperDiameter> getAllCopperDiameters();

	List<CableStdPvc> getAllCableStdPvcs();

	List<ProductType> getAllProductTypes();

	List<Item> getAllItems();

	public List<Item> findByItemCode(String itemCode);

	public Item create(Item item);

	public List<Item> fetchItemId(String itemCode);

	public List<CopperDiameter> getCopperDiameter(String copperkey);

	public List<Colour> getColor(String colour);

	public List<CableStdPvc> getCableStd(String cableStdKey);

	public List<ProductType> getProductType(String productType);

	List<Item> getAllRawMaterials();

	public List<Unit> getAllUnits();

	public List<Item> findByItemType(String string);

	public List<Item> findByItemInputSize(String itemIdSelect);

	public List<Item> findAll();

	public List<Item> findByCuDiameterAndCuStrandAndLayLengthAndProductType(
			String copperDiameterSelect, Integer numberOfCopperStrandsSelect,
			Integer layLengthSelect, String productType);

	public List<Item> findByCuDiameterAndCuStrandAndProductType(
			String copperDiameterSelect, Integer numberOfCopperStrandsSelect,
			String productType);

	public List<Item> findByProductTypeProcessType(String string);

	public List<Item> findByProductKey(String string);

	public List<Item> findByItemTypeAndNumberOfCuStrands(String string,
			Integer numberOfCopperStrand);

	public Page<Item> getItemPagedStore(int i, Integer rowsPerPage,
			String sortColName, String sortOrder);

	public List<Item> fetchBySearch(String qItemCode,
			Integer qNumberOfCopperStrands, String qCopperKey,
			String qOuterDiameter, String qOdLabel, String qMainColour,
			String qInnerColor, String qMainColourKey, String qInnerColorKey,
			String qCableStdKey, String qLayLength, String qLayType,
			String qProductKey, int pagenumber, Integer rows,
			String sortColName, String sortOrder);

	public List<String> selectAllItemCodes();

	public List<String> findByItemTypeQuery(String string);

	public List<Item> findByItemTypeAndNumberOfCuStrandsAndCopperStrandDia(
			String string, Integer numberOfCopperStrandsSelect,
			String copperDiameterSelect);

	public List<Area> getAreaValue(String cuStrandLabel);

	public List<Item> getItemProductType(String productType);

	public List<Item> findByProductTypeAndNumberOfCuStrands(String productType,
			Integer numberOfCopperStrand);

	public List<Item> findByItemId(Long itemId);

	public List<String> fetchInventoryItemCodes();

}
