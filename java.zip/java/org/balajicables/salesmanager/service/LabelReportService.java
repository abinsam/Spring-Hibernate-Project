package org.balajicables.salesmanager.service;

import java.util.List;

import org.balajicables.salesmanager.model.LabelReport;

/**
 * Service Interface of LabelReport.
 * 
 * @author Abin Sam
 */
public interface LabelReportService {

	LabelReport create(LabelReport labelReport);

	List<LabelReport> findByWorkOrderNo(String workOrderNo);

	List<LabelReport> findByWorkOrderItemsWorkOrderItemId(Long woItemId);

	void delete(Long labelReportId);

	List<LabelReport> findAll();

	Boolean deleteByWorkOrderNo(String workOrderNo);

}
