package org.balajicables.salesmanager.service;

import java.util.List;

import org.balajicables.salesmanager.model.MachineDetails;

/**
 * Service Interface of Machine Master.
 * 
 * @author Abin Sam
 */
public interface MachineService {

	List<MachineDetails> findAll();

	List<MachineDetails> findProcessMachineNo(String processType);
}
