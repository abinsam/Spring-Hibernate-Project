package org.balajicables.salesmanager.service;

import java.util.List;

import org.balajicables.salesmanager.model.MwdWorkOrder;
import org.springframework.data.domain.Page;

/**
 * Service Interface of Mwd WorkOrder Input.
 * 
 * @author Abin Sam
 */
public interface MwdWorkOrderInputService {													

	MwdWorkOrder create(MwdWorkOrder mwdWorkOrder);

	Boolean update(MwdWorkOrder mwdWorkOrder);

	Page<MwdWorkOrder> getPagedOrders(String workOrderNo, int i,
			Integer rowsPerPage, String sortColName, String sortOrder);

	Boolean delete(MwdWorkOrder mwdWorkOrder);

	List<MwdWorkOrder> findByProductionWorkOrderWorkOrderNo(String workOrderNo);

	List<MwdWorkOrder> findbyWorkOrderNoSizeCUstomerName(
			String mwdWorkOrderNoTag, String inputSize, String customerName);

	List<MwdWorkOrder> findBySoItemIdAndWorkOrderNo(Long long1,
			String workOrderNo);

	List<MwdWorkOrder> findById(Long id);

	List<MwdWorkOrder> findByOrderIdAndItemCodeAndWorkOrderNo(
			String dummySalesOrder, String itemCode, String woNo);

}
