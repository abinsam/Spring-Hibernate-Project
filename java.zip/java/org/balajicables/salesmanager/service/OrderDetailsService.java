package org.balajicables.salesmanager.service;

import java.util.List;

import org.balajicables.salesmanager.model.SalesOrderItem;
import org.springframework.data.domain.Page;
/**
* Service Interface of   Sales Order Item.
* @author Abin Sam
*/
public interface OrderDetailsService {

	Page<SalesOrderItem> getPagedSalesOrderItems(String orderId, int i,
			Integer rowsPerPage, String sortColName, String sortOrder);

	SalesOrderItem create(SalesOrderItem soitem);

	List<SalesOrderItem> findByOrderIdItemId(String orderId, String itemCode);

	Boolean update(SalesOrderItem itemObj);

	Page<SalesOrderItem> getPagedSalesOrderItems(int i, Integer rowsPerPage,
			String sortColName, String sortOrder);

	List<SalesOrderItem> findById(Long Ids);

	List<SalesOrderItem> fetchBySearch(String qOrderId, Long qCustomerId,
			Integer qNumberOfCopperStrands, String qCopperKey,
			String qOdLabel, String qMainColour, String qInnerColor,
			String qCableStdKey, String qLayLength, String qLayType,
			String qProductKey, String qItemCode, String qOrderAcceptanceDate,
			String qOrderAcceptanceDateTo, int pagenumber, int rows,
			String sortColName, String sortOrder, String reportType);

	Boolean updateBalQty(Long id, Double newBalanceQty, Double woQty);

	Boolean updatePdnQty(Long id, Double newProductionQty, Double woQty);

	Double fetchPdnQty(Long customerId, String itemCode);

	Double fetchItemPdnQty(Long customerId, String itemCode);

	Boolean delete(Long soItemId);

	List<SalesOrderItem> checkSoItemRates(String orderId);

	List<SalesOrderItem> findByOrdersOrderIdItemsItemCode(String salesOrderId,
			String itemCode);

	Page<SalesOrderItem> getPendingSalesOrderItems(int i, Integer rowsPerPage,
			String sortColName, String sortOrder);

	List<SalesOrderItem> findByCustomerAssortedTypeStatusIn(
			String customerName, String assortedType, String[] orderStatus);

	List<SalesOrderItem> findByOrderId(String orderId);

	Page<SalesOrderItem> getPendingSoItems(int i, Integer rowsPerPage,
			String sortColName, String sortOrder, String[] orderStatus,
			String reportType);

	Boolean updateBalPdnQty(Long salesOrderItemId, Double totalQty,
			Double newBalQty, Double newPdnQty);

	Page<SalesOrderItem> getSoItemPendingReport(int i, Integer rowsPerPage,
			String sortColName, String sortOrder, String[] orderStatus);

	Page<SalesOrderItem> getSoItemAssortedType(String orderId, int i,
			Integer rowsPerPage, String sortColName, String sortOrder,
			String itemType);

	List<SalesOrderItem> findByItemCodeAndCustomerId(String itemCode,
			Long customerId);

	List<SalesOrderItem> findByItemCode(String itemCode);

	List<SalesOrderItem> finddByCustomerIdAndScrapItem(Long customerId,
			String itemType, String status);

	List<SalesOrderItem> findByItemsItemId(Long itemIdToDelete);

	List<SalesOrderItem> findByItemsItemTypeAndOrderStatusInAndBalanceQtyGreaterThan(String itemType,String[] orderStatus);

	List<SalesOrderItem> findByCustomerIdAndItemsItemTypeAndOrderStatusInAndBalanceQtyGreaterThan(
			Long customerId, String itemType, String[] orderStatus);

	List<SalesOrderItem> findByOrderStatusInAndBalanceQtyGreaterThan(
			String[] orderStatus);

	List<SalesOrderItem> findByCustomerIdAndOrderStatusInAndBalanceQtyGreaterThan(
			Long customerId, String[] orderStatus);

	List<SalesOrderItem> findByOrderStatusInAndStockOutQtyPending(
			String orderStatus,String sortCol,String sortOrder);

	List<SalesOrderItem> fetchByPendingStockOutSearch(String qOrderId,
			Long qCustomerId, Integer qNumberOfCopperStrands,
			String qCopperKey, String qOdLabel, String qMainColour,
			String qInnerColor, String qCableStdKey, String qLayLength,
			String qLayType, String qProductKey, String qItemCode,
			String orderAccDate, String orderAccDateTo, int pagenumber,
			Integer rows, String sortColName, String sortOrder);

	List<SalesOrderItem> findByCustomerIdAndOrderStatusInAndQuantityGreaterThanDispatchedQty(
			Long customerId, String orderStatus);

	List<SalesOrderItem> findByScrapItem(String itemType, String status);





}
