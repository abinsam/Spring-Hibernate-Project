package org.balajicables.salesmanager.service;

import java.util.Date;
import java.util.List;
import org.balajicables.salesmanager.model.Customer;
import org.balajicables.salesmanager.model.OrderStatus;
import org.balajicables.salesmanager.model.SalesOrder;
import org.springframework.data.domain.Page;

/**
 * Service Interface of Sales Order.
 * 
 * @author Abin Sam
 */
public interface OrderService {

	public List<SalesOrder> findByCustomer(Customer customer);

	SalesOrder create(SalesOrder order);

	Boolean update(SalesOrder order);

	Boolean delete(String orderIdToDelete);

	Page<SalesOrder> getPagedOrders(long customerId, int pageNumber,
			Integer rowsPerPage, String sortColName, String sortOrder);

	List<SalesOrder> fetchBySearch(Long qCustomerName, String qStatus,int month,
			int year, int pagenumber, Integer rows,
			String sortColName, String sortOrder);
	List<SalesOrder> findAll();

	SalesOrder findByIdWithCustomer(String id);

	public List<SalesOrder> fetchLatestSalesOrder();

	public List<OrderStatus> fetchStatusId(String status);

	public Boolean updateSoStatus(String orderId);

	public Boolean updateOrderStatus(String orderId, int orderStatusId);

	public Page<SalesOrder> getSearchSalesOrder(String orderStatus, int i,
			Integer rowsPerPage, String sortColName, String sortOrder);

	public List<SalesOrder> findBySalesOrderNoId(String salesOrderId);

	public List<SalesOrder> findByCustomerId(Long customerId);

	public Page<SalesOrder> getSalesOrderReport(Date fromDate, Date toDate,
			String invalidstatus, int i, Integer rowsPerPage,
			String sortColName, String sortOrder);

	public Page<SalesOrder> getSalesOrderReportWithStatus(Date fromDate,
			Date toDate, String orderStatus, int i, Integer rowsPerPage,
			String sortColName, String sortOrder);

	public List<SalesOrder> findByOrderStatusStatus(String status);

	public List<SalesOrder> getPagedSalesOrder(String orderStatus, int month,
			int year, int i, Integer rows, String sortColName, String sortOrder);
	
	public List<SalesOrder> getAllSalesOrder(int month, int year, int i,
			Integer rows, String sortColName, String sortOrder);

	public Page<SalesOrder> getPagedCustomerPendingSalesorders(long customerId,
			String[] salesOrderStatus, int i, Integer rowsPerPage,
			String sortColName, String sortOrder);

	public List<SalesOrder> findSalesOrderByMonthYear(int monthValue, int yearValue);

}
