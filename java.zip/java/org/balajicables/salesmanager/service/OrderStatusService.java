package org.balajicables.salesmanager.service;

import java.util.List;

import org.balajicables.salesmanager.model.OrderStatus;

/**
 * Service Interface of Sales Order Status.
 * 
 * @author Abin Sam
 */

public interface OrderStatusService {

	List<OrderStatus> findAll();

	List<OrderStatus> findByStatus(String string);

}
