package org.balajicables.salesmanager.service;

import java.util.List;

import org.balajicables.salesmanager.model.PackingSlip;
import org.springframework.data.domain.Page;

/**
 * Service Interface of PackingSlip.
 * 
 * @author Abin Sam
 */
public interface PackingSlipService {

	Page<PackingSlip> getPagedPackingSlipDetails(String packingSlipNo,
			int pageNumber, Integer rowsPerPage, String sortColName,
			String sortOrder);

	Page<PackingSlip> findAll(int pageNumber, Integer rowsPerPage,
			String sortColName, String sortOrde);

	public PackingSlip create(PackingSlip packingSlip);

	List<PackingSlip> findByDeliveryChallanNo(String deliveryChallanNo);

	List<PackingSlip> findPackingSlipCount(String deliveryChallanNo);

	Boolean delete(Integer packingSlipId);

}
