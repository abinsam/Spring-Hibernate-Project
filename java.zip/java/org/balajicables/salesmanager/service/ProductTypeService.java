package org.balajicables.salesmanager.service;

import java.util.List;
import org.balajicables.salesmanager.model.ProductType;

/**
 * Service Interface of Product Type.
 * 
 * @author Abin Sam
 */

public interface ProductTypeService {

	List<ProductType> findByProcessType(String processType);

	List<String> findProductTypeByProcessType(String processType);

	public List<ProductType> findAll();
}
