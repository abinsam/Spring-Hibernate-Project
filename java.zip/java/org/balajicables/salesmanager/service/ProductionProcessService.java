package org.balajicables.salesmanager.service;

import java.util.List;

import org.balajicables.salesmanager.model.ProductionProcess;

/**
 * Service Interface of ProductionProcess.
 * 
 * @author Abin Sam
 */
public interface ProductionProcessService {

	List<ProductionProcess> getAllProcesses();

	List<ProductionProcess> findByProcessType(String processType);

}
