package org.balajicables.salesmanager.service;

import java.util.List;

import org.balajicables.salesmanager.model.ProductionWorkOrder;

/**
 * Service Interface of Production WorkOrder Master.
 * 
 * @author Abin Sam
 */

public interface ProductionWorkOrderService {

	List<ProductionWorkOrder> fetchLatestWorkOrder(String processType);

	ProductionWorkOrder create(ProductionWorkOrder prdnWorkOrder);

	List<ProductionWorkOrder> findByProcess(String processType);

	List<ProductionWorkOrder> findByProductionWorkOrderNo(String workOrderNo);

	Boolean updateWorkOrderWeight(String newWorkOrderNo, Double inputWeight,
			Double outputWeight, Double balanceWeight);

	Boolean updateWorkOrderStatus(String workOrderNo, String updateStatus);

	Boolean updateStatus(String workOrderNo);

	List<ProductionWorkOrder> findAll();

	Boolean update(ProductionWorkOrder pdnWorkOrder);

	List<ProductionWorkOrder> findByProcessTypeAndStatus(String processType,
			String status);

	List<ProductionWorkOrder> findByProcessTypeAndStatusAndMonthYear(
			String processType, String status, int month, int year);

	List<ProductionWorkOrder> findByProcessTypeAndMonthYear(String processType,
			int month, int year);

	List<ProductionWorkOrder> findByProcessType(String rbd, int month, int year);

}
