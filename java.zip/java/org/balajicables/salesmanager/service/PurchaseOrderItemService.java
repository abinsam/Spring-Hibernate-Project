package org.balajicables.salesmanager.service;

import java.util.List;
import org.balajicables.salesmanager.model.PurchaseOrderItem;
import org.springframework.data.domain.Page;

/**
 * Service Interface of PurchaseOrderItem.
 * 
 * @author Abin Sam
 */
public interface PurchaseOrderItemService {

	PurchaseOrderItem create(PurchaseOrderItem poItemDetail);

	Boolean update(PurchaseOrderItem purchaseOrderItem);

	Boolean delete(Long poItemToDelete);

	Page<PurchaseOrderItem> getPagedPurchaseOrderItems(String poNo,
			int pageNumber, Integer rowsPerPage, String sortColName,
			String sortOrder);

	List<PurchaseOrderItem> findByPoNoItemId(String poNo, String itemCode);

	List<PurchaseOrderItem> checkPrice(String poNo);

	List<PurchaseOrderItem> findByPoNo(String poNo);

	Page<PurchaseOrderItem> getPagedPurchaseOrderItemsByStatus(String poNo,
			int i, Integer rowsPerPage, String sortColName, String sortOrder);

	List<PurchaseOrderItem> findByPoItemId(Long id);

	List<PurchaseOrderItem> findByPoNoStatus(String poNoStatus);

	List<PurchaseOrderItem> findByItemItemId(Long itemIdToDelete);

}
