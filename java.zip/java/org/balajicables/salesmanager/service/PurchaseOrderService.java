package org.balajicables.salesmanager.service;

import java.util.Date;
import java.util.List;

import org.balajicables.salesmanager.model.PurchaseOrder;
import org.springframework.data.domain.Page;

/**
 * Service Interface of PurchaseOrder.
 * 
 * @author Abin Sam
 */

public interface PurchaseOrderService {

	List<PurchaseOrder> fetchLatestPO();

	PurchaseOrder create(PurchaseOrder purchaseorder);

	Boolean update(PurchaseOrder purchaseOrder);

	Boolean delete(String poToDelete);

	Page<PurchaseOrder> getPagedOrders(long customerId, int i,
			Integer rowsPerPage, String sortColName, String sortOrder);

	PurchaseOrder findByIdWithCustomer(String poNo);

	List<PurchaseOrder> findByCustId(Long customerId);

	Boolean updatePoStatusCompleted(String poNo);

	List<PurchaseOrder> findAll();

	List<PurchaseOrder> findByPoNo(String poNo);

	List<PurchaseOrder> findByCustIdAndPurchaseOrderStatus(Long customerId,
			String poStatus);

	Page<PurchaseOrder> getPurchaseOrderReport(Date fromDate, Date toDate,
			int i, Integer rowsPerPage, String sortColName, String sortOrder);

	Page<PurchaseOrder> getPurchaseOrderReportWithStatus(Date fromDate,
			Date toDate, String orderStatus, int i, Integer rowsPerPage,
			String sortColName, String sortOrder);

	List<PurchaseOrder> findByCustIdAndPurchaseOrderStatusAndMonthYear(
			String customer, String poStatus, int monthValue, int yearValue);

	List<PurchaseOrder> getPagedSalesOrder(String orderStatus, int month,
			int year, int i, Integer rowsPerPage, String sortColName,
			String sortOrder);

	List<PurchaseOrder> getPagedPo(String orderStatus, String month,
			String year, Integer pageNumber, Integer rowsPerPage,
			String sortColName, String sortOrder);

	List<PurchaseOrder> findByPurchaseOrderStatus(String string);

	List<String> findByPoStatusDistinct();

	List<PurchaseOrder> finddByStatusMonthYear(String poStatus, int month,
			int year);

}
