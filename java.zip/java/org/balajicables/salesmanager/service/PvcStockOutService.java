package org.balajicables.salesmanager.service;

import java.util.List;

import org.balajicables.salesmanager.model.PvcStockOut;
import org.springframework.data.domain.Page;

/**
 * Service Interface of PvcStockOut.
 * 
 * @author Abin Sam
 */
public interface PvcStockOutService {

	List<PvcStockOut> findByBatchAndProductionWorkOrderNo(String batch,
			String extrsuionWoNo);

	Boolean update(PvcStockOut pvcStockOut);

	PvcStockOut create(PvcStockOut pvcStockOuts);

	Page<PvcStockOut> getPvcStockOutRecords(String woNo, int i,
			Integer rowsPerPage, String sortColName, String sortOrder);

	List<PvcStockOut> findByItemItemId(Long itemIdToDelete);

}
