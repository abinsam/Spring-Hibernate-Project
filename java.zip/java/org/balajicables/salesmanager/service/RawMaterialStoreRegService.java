package org.balajicables.salesmanager.service;

import java.util.Date;
import java.util.List;
import org.balajicables.salesmanager.model.RawMaterialStoreReg;
import org.springframework.data.domain.Page;

/**
 * Service Interface of Raw Material Store Register.
 * 
 * @author Abin Sam
 */
public interface RawMaterialStoreRegService {

	RawMaterialStoreReg create(RawMaterialStoreReg rawMaterialStoreReg);

	Page<RawMaterialStoreReg> getRawMaterialToStock(int i, Integer rowsPerPage,
			String sortColName, String sortOrder, String sendToRbd,
			String stockInStatus, String purchaseOrderNo);

	Page<RawMaterialStoreReg> getPagedStore(String[] qcStatus, int i,
			Integer rowsPerPage, String sortColName, String sortOrder);

	Page<RawMaterialStoreReg> getPagedItemEntry(String itemIdSelect,
			int pageNumber, Integer rowsPerPage, String sortColName,
			String sortOrder);

	List<RawMaterialStoreReg> fetchBySearch(String qCustomerName,
			String qItemCode, int pagenumber, Integer rows, String sortColName,
			String sortOrder);

	List<RawMaterialStoreReg> findById(Long idSelected);

	Page<RawMaterialStoreReg> getPagedStoreAndProductType(int i,
			Integer rowsPerPage, String sortColName, String sortOrder,
			String[] productType);

	Boolean update(RawMaterialStoreReg rawMaterialStoreReg);

	Boolean delete(Long rawMaterialIdTodelete);

	List<RawMaterialStoreReg> findByStockedInStatus(String stockedInStatus);

	Page<RawMaterialStoreReg> getQCPagedStore(int i, Integer rowsPerPage,
			String sortColName, String sortOrder);

	Page<RawMaterialStoreReg> getRejectOrderWithDateAndStatus(String status,
			Date fromDate, Date toDate, int i, Integer rowsPerPage,
			String sortColName, String sortOrder);

	Page<RawMaterialStoreReg> getQCRejectedPagedStore(int i,
			Integer rowsPerPage, String sortColName, String sortOrder);

	Page<RawMaterialStoreReg> getRejectOrderWithRejectStatus(String qcStatus,
			String rejectStatus, int i, Integer rowsPerPage,
			String sortColName, String sortOrder);

	Page<RawMaterialStoreReg> getRejectOrderWithStatusAndDate(String string,
			Date fromDate, Date toDate, String rejectStatus, int i,
			Integer rowsPerPage, String sortColName, String sortOrder);

	Page<RawMaterialStoreReg> getStockDatePagedStore(Date stockFromDate,
			Date stockToDate, int i, Integer rowsPerPage, String sortColName,
			String sortOrder);

	List<RawMaterialStoreReg> findAll();

	Page<RawMaterialStoreReg> getPagedApprovedPvcStock(int i,
			Integer rowsPerPage, String sortColName, String sortOrder,
			String[] productType, String[] qcStatus);

	Page<RawMaterialStoreReg> getPagedRawMaterialStore(int i,
			Integer rowsPerPage, String sortColName, String sortOrder,
			String[] qcStatus);

	Page<RawMaterialStoreReg> getOnDatePagedRawMaterialStore(
			Date stockFromDate, Date stockToDate, String itemCode,
			String[] qcStatus, int i, Integer rowsPerPage, String sortColName,
			String sortOrder);

	Page<RawMaterialStoreReg> getStockDatePagedQcStatusStore(
			Date stockFromDate, Date stockToDate, String[] qcStatus, int i,
			Integer rowsPerPage, String sortColName, String sortOrder);

	Page<RawMaterialStoreReg> getItemPagedStore(String[] qcStatus,
			String itemCode, int i, Integer rowsPerPage, String sortColName,
			String sortOrder);

	List<RawMaterialStoreReg> findByQcStatus(String status);

}
