package org.balajicables.salesmanager.service;

import org.balajicables.salesmanager.model.RbdWorkOrderInput;
import org.springframework.data.domain.Page;

/**
 * Service Interface of Rbd WorkOrder Input.
 * 
 * @author Abin Sam
 */
public interface RbdWorkOrderInputService {

	RbdWorkOrderInput create(RbdWorkOrderInput rbdWorkOrderInput);

	Page<RbdWorkOrderInput> getRbdPagedList(String workOrderNo, int i,
			Integer rowsPerPage, String sortColName, String sortOrder);

}
