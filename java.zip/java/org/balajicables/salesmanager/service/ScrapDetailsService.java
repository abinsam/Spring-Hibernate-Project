package org.balajicables.salesmanager.service;

import java.util.List;

import org.balajicables.salesmanager.model.ScrapDetails;
import org.springframework.data.domain.Page;

/**
 * Service Interface of Scrap Details .
 * 
 * @author Abin Sam
 */
public interface ScrapDetailsService {

	ScrapDetails create(ScrapDetails scrapDetails);

	Page<ScrapDetails> getScrapDetailsPagedList(int i, Integer rowsPerPage,
			String sortColName, String sortOrder);

	Boolean update(ScrapDetails scrapDetails);

	Boolean delete(Long id);

	void updateStockedInStatusById(Long id);

	List<ScrapDetails> findById(Long id);

	List<ScrapDetails> findByItemIdAndStockedInStatus(Long itemId,
			String stockedInstatus);

	List<ScrapDetails> findByItemItemId(Long itemIdToDelete);

	Page<ScrapDetails> getPagedScrapByWorkOrderAndStockedInStatus(
			String workOrder, String stockedInstatus, int i,
			Integer rowsPerPage, String sortColName, String sortOrder);

}
