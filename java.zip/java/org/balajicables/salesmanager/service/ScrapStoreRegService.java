package org.balajicables.salesmanager.service;

import java.util.ArrayList;
import java.util.List;

import org.balajicables.salesmanager.model.ScrapStoreReg;
import org.springframework.data.domain.Page;

/**
 * Service Interface of Scrap Store Register .
 * 
 * @author Abin Sam
 */

public interface ScrapStoreRegService {
	List<ScrapStoreReg> findAll();

	List<ScrapStoreReg> findByItemsItemId(Long itemId);

	Boolean update(ScrapStoreReg scrapStoreReg);

	ScrapStoreReg create(ScrapStoreReg scrapStoreReg);

	Page<ScrapStoreReg> getScrapStoreRegDetailsPagedList(int i,
			Integer rowsPerPage, String sortColName, String sortOrder);

	List<ScrapStoreReg> findByScrapStoreRegId(Long scrapStoreRegId);

	Page<ScrapStoreReg> findByItemsItemCodeIn(int i, Integer rowsPerPage,
			String sortColName, String sortOrder, ArrayList<String> itemCode);

}
