package org.balajicables.salesmanager.service;

import java.util.List;

import org.balajicables.salesmanager.model.SemifinishedStockOut;
import org.springframework.data.domain.Page;

/**
 * Service Interface of Semi Finished Stock Out .
 * 
 * @author Abin Sam
 */

public interface SemifinishedStockOutService {

	Page<SemifinishedStockOut> getConfirmedSemifinishedStockOut(String woNo,
			String confrimStatus, int i, Integer rowsPerPage,
			String sortColName, String sortOrder);

	Page<SemifinishedStockOut> findByStockedOutForAndWorkOrderProcess(
			String workOrder, String woStockedOutProcess, String confirmStatus,
			int i, Integer rowsPerPage, String sortColName, String sortOrder);

	List<SemifinishedStockOut> findByStockedOutFor(String workOrder);

	List<SemifinishedStockOut> findByStockedOutForAndProductionWo(
			String string, String woStockedOutProcess);

	Page<SemifinishedStockOut> getPagedNotConfirmedUserBasedSemiFinishedSotck(
			int i, Integer rowsPerPage, String sortColName, String sortOrder,
			String confirmStatus, String[] itemTypeArray, String userName);

	SemifinishedStockOut create(SemifinishedStockOut semifinishedStockOut);

	List<SemifinishedStockOut> findBySemifinishedStockOutId(Long long1);

	List<SemifinishedStockOut> findByOrderIdAndItemCodeAndBundleIdAndWorkOrderAndConfirmStatus(
			String soNo, String itemCode, String bundleId, String woNo,
			String confirmStatus);

	Boolean delete(Long id);

	void update(SemifinishedStockOut semifinishedStockOuts);

}
