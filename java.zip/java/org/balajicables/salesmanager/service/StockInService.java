package org.balajicables.salesmanager.service;

import java.util.Date;
import java.util.List;
import org.balajicables.salesmanager.model.StockIn;
import org.springframework.data.domain.Page;

/**
 * Service Interface of Stock in .
 * 
 * @author Abin Sam
 */

public interface StockInService {

	List<StockIn> findByOrderIdItemIdBundleId(String salesOrderId,
			String itemCode, String bundleId);

	StockIn create(StockIn stockInItem);

	Boolean update(StockIn stockIn);

	List<StockIn> findByOrderIdItemIdBatchNo(String orderId, String itemCode,
			String batchNo);

	List<StockIn> findBySalesOrderItemOrderDetailId(Long soItemId);

	Page<StockIn> getPagedStockIn(int i, Integer rowsPerPage,
			String sortColName, String sortOrder, String confirmStatus);

	List<StockIn> findByStockInId(Long long1);

	Boolean delete(Long stockInId);

	List<StockIn> findByOrderDetailIdBundleIdWorkOrderNo(Long soItemDetailsId,
			String bundleId, String workOrderNo);

	List<StockIn> getStockInDetails(Date fromDates, Date toDates, Long party,
			String itemCode, String asortedtype);

	List<Object[]> getStockDetails(String fromDates, String toDates,
			String party, String itemCode, String salesOrder, String workOrder,
			String mainColour, String stripeColour, String od,
			String cablesStd, String productType, Integer layLength,
			String layType, String cuDiameter, Long noOfCuStrand);

	List<StockIn> findByOrderIdAndItemCodeAndWoNoAndBundleId(
			String salesOrderId, String itemCode, String workOrderNo,
			String bundleId);

	Page<StockIn> getPagedStockInBySupervisor(int i, Integer rowsPerPage,
			String sortColName, String sortOrder, String confirmStatus,
			String userName);

	List<StockIn> findByOrderIdAndItemCodeAndWoNoAndBundleIdAndConfirmStatus(
			String salesOrderId, String itemCode, String workOrderNo,
			String bundleId, String confirmStatus);

	List<StockIn> findByOrderDetailIdAndWorkOrderNoAndConfirmStatusAndMaxBundleId(
			Long orderDetailsId, String workOrderNo, String confirmStatus);

	List<StockIn> findByOrderDetailIdAndWoNoAndBundleId(
			Long newSalesOrderItemId, String oldWoNo, String confirmStatus);

	List<StockIn> findByOrderIdAndItemCodeAndWoNo(String newSalesOrderNo,
			String itemCode, String oldWoNo);

	List<StockIn> findBySoNoAndWoNoAndBundleIdAndSoItemIdAndQuantity(
			 String woNo, String bundleId, Long soItemid,
			Double stockInQty, Double stockWeight,String confirmStatus);

}
