package org.balajicables.salesmanager.service;

import java.util.List;

import org.balajicables.salesmanager.model.StockOut;
import org.springframework.data.domain.Page;

/**
 * Service Interface of Stock Out .
 * 
 * @author Abin Sam
 */
public interface StockOutService {

	List<StockOut> findByOrderIdItemIdBundleId(String salesOrderId,
			String itemCode, String bundleId);

	StockOut create(StockOut stockOutItem);

	Boolean update(StockOut stockOut);

	List<StockOut> findByStockOutId(Long long1);

	List<StockOut> findByItemId(Long long1);

	Boolean delete(Long id);

	List<StockOut> findByOrderDetailIdWorkOrderNoBundleId(Long orderDetailsId,
			String workOrderNo, String bundleId);

	Page<StockOut> getPagedStockOut(int i, Integer rowsPerPage,
			String sortColName, String sortOrder, String confirmStatus);

	Page<StockOut> getPagedStockOutUserName(int i, Integer rowsPerPage,
			String sortColName, String sortOrder, String confirmStatus,
			String userName);

	List<StockOut> findBySalesOrderItemOrderDetailId(Long orderDetailsId);

	List<StockOut> findByOrderDetailIdWorkOrderNoPackingSlipNo(
			Long orderDetailId, String workOrderNo, Long bagNo);

	List<StockOut> fetchStockOutBySearch(String qOrderId, String confirmStatus,
			int pagenumber, Integer rows, String sortColName, String sortOrder);

	List<StockOut> findByDeliveryChallanNo(String newdeliveryChallanNo);

	List<StockOut> finddByStockOutsCustomerId(Long customerId);

	List<StockOut> findByOrderIdoPackingSlipNoConfirmStatus(String soNo,
			Long bagNo, String confirmStatus);

	List<StockOut> findByOrderIdWorkOrderNoPackingSlip(String orderId,
			String workOrderNo, Long bagNo);

	List<StockOut> findByOrderIdAndItemCodeAndBundleIdAndWorkOrderNo(
			String salesOrderId, String itemCode, String bundleId,
			String workOrderNo);

	List<StockOut> findBySalesOrderItemOrdersOrderIdAndConfirmStatus(
			String salesOrderNo, String string);

	List<StockOut> findBySalesOrderItemOrderDetailIdAndConfirmStatus(
			Long orderDetailId, String string);

	Page<StockOut> getPagedNotConfirmedSemiFinishedSotck(int i,
			Integer rowsPerPage, String sortColName, String sortOrder,
			String confirmStatus, String[] itemType);

	List<StockOut> findByWorkOrderNoAndProductionProcess(String workOrder,
			String string);

	List<StockOut> finddByStockOutsAndMonthYear(int monthValue, int yearValue);

	List<StockOut> finddByStockOutsCustomerIdAndMonthYear(Long customerId,
			int monthValue, int yearValue);

	List<StockOut> fetchStockOutBySearchUserName(String qOrderId,
			String confirmStatus, String userName, int pagenumber,
			Integer rows, String sortColName, String sortOrder);

	List<StockOut> findByOrderIdAndItemCodeAndBundleIdAndWorkOrderNoAndConfirmStatus(
			String salesOrderId, String itemCode, String bundleId,
			String workOrderNo, String confirmstatus);

	List<StockOut> findBySalesOrderItemIdAndWorkOrderNoAndConfirmStatus(
			Long salesOrderItemId, String workOrderNo, String confrimstatus);

	List<Object[]> getStoreRegBundleDetails(Long salesOrderItemId,
			String workOrderNo, String sortColName, String sortOrder);

	List<Object[]> getStockOutBundleDetails(Long salesOrderItemId,
			String workOrderNo, String confrimstatus, String sortColName, String sortOrder);

	List<StockOut> findDistinctDcBySalesOrderItem(Long salesOrderItemId);

}
