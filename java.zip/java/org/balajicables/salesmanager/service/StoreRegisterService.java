package org.balajicables.salesmanager.service;

import java.util.Date;
import java.util.List;

import org.balajicables.salesmanager.model.StoreRegister;
import org.springframework.data.domain.Page;

/**
 * Service Interface of Store register .
 * 
 * @author Abin Sam
 */

public interface StoreRegisterService {

	List<StoreRegister> findByOrderIdItemCodeBundleId(String salesOrderId,
			String itemCode, String bundleId);

	Boolean updateStoreQuantity(Long storeRegisterId, int stockQty);

	StoreRegister create(StoreRegister storeRegister);

	List<StoreRegister> fetchBySearch(String qOrderId, String WorkOrderNo,
			Long qCustomerName, String qItemCode, int qNumberOfCopperStrands,
			String qCopperKey, String qOuterDiameter, String qMainColour,
			String qInnerColor, String qCableStdKey, String qLayLength,
			String qLayType, String qProductKey,String qQcStatus,Integer pagenumber,
			Integer rows, String sortColName, String sortOrder);

	Page<StoreRegister> getPagedStore(int i, Integer rowsPerPage,
			String sortColName, String sortOrder);

	Page<StoreRegister> getQCPagedStore(int i, Integer rowsPerPage,
			String sortColName, String sortOrder);

	Page<StoreRegister> getQCRejectedPagedStore(int i, Integer rowsPerPage,
			String sortColName, String sortOrder);

	Boolean deleteEmptyStock(Long storeRegisterId);

	Double fetchStockQty(Long customerId, String itemCode,String unitType);

	Double fetchItemStockQty(Long customerId, String itemCode,String unitType);

	List<StoreRegister> findByOrderIdItemIdBundleId(String orderId,
			String itemCode, String bundleId);

	List<StoreRegister> findById(Long storeRegisterId);

	Boolean update(StoreRegister storeRegister);

	List<StoreRegister> findByOrderIdAndItemCodeAndBundleIdAndWorkOrderNo(
			String salesOrderId, String itemCode, String bundleId,
			String workOrderNo);

	List<StoreRegister> findBySalesOrderItemOrderDetailId(Long orderDetailsId);

	Boolean delete(Long storeRegId);

	List<StoreRegister> findByOrderDetailIdAndBundleIdAndWorkOrderNo(
			Long orderDetailId, String bundleId, String woNo);

	List<StoreRegister> findByOrderDetailIdWorkOrderNoPackingSlipNo(
			Long orderDetailId, String workOrderNo, Long bagNo);

	List<StoreRegister> findByOrderIdoPackingSlipNo(String soNo, Long bagNos);

	List<StoreRegister> findAll();

	Page<StoreRegister> getPagedSemiFinishedStoreReg(int i,
			Integer rowsPerPage, String sortColName, String sortOrder,
			String[] itemType);

	List<StoreRegister> findByOrderIdAndItemCodeAndWorkOrderNo(String soNo,
			String itemCode, String woNo);

	List<StoreRegister> findByOrderIdWorkOrderNoPackingSlip(String orderId,
			String workOrderNo, Long bagNo);

	List<StoreRegister> findByOrderDetailId(Long newSalesOrderItemId);

	List<StoreRegister> fetchByRejectStatusSearch(String rejectStatus);

	Page<StoreRegister> getRejectOrderWithDate(Date fromDate, Date toDate,
			int i, Integer rowsPerPage, String sortColName, String sortOrder);

	Page<StoreRegister> getRejectOrderWithStatus(String rejectStatus, int i,
			Integer rowsPerPage, String sortColName, String sortOrder);

	Page<StoreRegister> getRejectOrderWithStatusAndDate(Date fromDate,
			Date toDate, String rejectStatus, int i, Integer rowsPerPage,
			String sortColName, String sortOrder);

	List<StoreRegister> fetchByRejectStatusSearch(String qOrderId,
			String qWorkOrderNo, String qCustomerName, String qItemCode,
			Integer qNumberOfCopperStrands, String qCopperKey,
			String qOuterDiameter, String qMainColour, String qInnerColor,
			String qCableStdKey, String qLayLength, String qLayType,
			String qProductKey, int pagenumber, Integer rows,
			String sortColName, String sortOrder);

	Page<StoreRegister> getStockDatePagedStore(Date stockFromDate,
			Date stockToDate, int i, Integer rowsPerPage, String sortColName,
			String sortOrder);

	Page<StoreRegister> fetchByQcStatusNotIn(String string, int i,
			Integer rowsPerPage, String sortColName, String sortOrder);

	List<StoreRegister> findByOrderId(String salesorderNumber);

	List<StoreRegister> findBySalesOrderItemOrdersCustomerCustomerName(
			String customerId);

	List<StoreRegister> findByWorkOrderNoAndProductionProcess(String workOrder,
			String process);

	List<StoreRegister> distinctItemCodes();

	List<StoreRegister> findByQcStatus(String status);

	List<StoreRegister> fetchByQcStatusSearch(String qOrderId,
			Long qCustomerId, int pagenumber, Integer rows, String sortColName,
			String sortOrder);

	List<StoreRegister> findBySalesOrderItemOrdersCustomerCustomerIdAndQcStatus(
			Long customerId, String qcStatus);

	List<StoreRegister> findByProductionWorkOrderProcess(String processType);

	List<StoreRegister> findByQcStatusAndProductionWorkOrderProcess(
			String qcStatus, String processType);

	List<StoreRegister> findBySalesOrderItemIdAndWorkOrderNo(
			Long salesOrderItemId, String workOrderNo);


	List<StoreRegister> findBySalesorderItemItemItemId(Long itemIds);
}
