package org.balajicables.salesmanager.service;

import java.util.List;

import org.balajicables.salesmanager.model.TaxRate;
import org.springframework.data.domain.Page;

/**
 * Service Interface of Tax Rate .
 * 
 * @author Abin Sam
 */

public interface TaxRateService {

	List<TaxRate> findByCustomerId(long customerId);

	Boolean update(TaxRate taxRate);

	Boolean delete(Long taxId);

	Page<TaxRate> getPagedTaxes(int i, Integer rowsPerPage, String sortColName,
			String sortOrder);

	List<TaxRate> fetchBySearch(Long qCustomerId, int pagenumber, Integer rows,
			String sortColName, String sortOrder);

	Boolean create(TaxRate taxRate);

}
