package org.balajicables.salesmanager.service;

import java.util.List;

import org.balajicables.salesmanager.model.Unit;

/**
 * Service Interface of Unit Master .
 * 
 * @author Abin Sam
 */

public interface UnitService {

	List<Unit> findAll();

}
