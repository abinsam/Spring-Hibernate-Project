package org.balajicables.salesmanager.service;

import java.util.List;

import org.balajicables.salesmanager.model.ProductionWorkOrder;
import org.balajicables.salesmanager.model.WorkOrderItems;
import org.springframework.data.domain.Page;

/**
 * Service Interface of Work Order Item(Extrusion Output) .
 * 
 * @author Abin Sam
 */

public interface WorkOrderItemService {

	WorkOrderItems create(WorkOrderItems workOrderItems);

	Page<WorkOrderItems> getPagedOrders(String workOrderNo, int pageNumber,
			Integer rowsPerPage, String sortColName, String sortOrder);

	Boolean update(WorkOrderItems woItems);

	Boolean delete(Long woItemIdToDelete);

	List<WorkOrderItems> findBySoItemIdAndWorkOrder(Long soItemId,
			String workOrderNo);

	List<WorkOrderItems> findBySalesOrderItem(Long soItemId);

	List<WorkOrderItems> findBySalesOrderItemOrdersOrderId(String orderId);

	List<WorkOrderItems> getRecords(String workOrderNo);

	List<WorkOrderItems> fetchLatestByProductionWorkOrderWorkOrderNo(
			String bunchingWorkOrderNoTag);

	List<WorkOrderItems> findBySoItemIdAndWorkOrderNo(Long soItemId,
			String workOrderNo);

	List<WorkOrderItems> findById(Long woItemId);

	List<WorkOrderItems> findByOrderIdAndItemCodeAndWorkOrderNo(
			String salesOrderId, String itemCode, String workOrderNo);

	List<WorkOrderItems> findByProductionWorkOrderProcessType(String string);

	List<WorkOrderItems> findByProductionWorkOrderWorkOrderNo(String workOrderNo);

	List<WorkOrderItems> findWoItemList(String workOrderNo);

	List<WorkOrderItems> findWoItemList(Long workOrderItemId);

	List<ProductionWorkOrder> findByProcessTypeAndMonthYear(String processType,
			int month, int year);

	List<WorkOrderItems> findWoItemListMonthYear(String woNo, int month,
			int year);

	List<WorkOrderItems> findByProductionWorkOrderWorkOrderNoAndStockInStatus(
			String workOrderNo, String status);

	Page<WorkOrderItems> findByPagedSalesOrderItem(Long salesOrderItemId,
			int i, Integer rowsPerPage, String sortColName, String sortOrder);


}
