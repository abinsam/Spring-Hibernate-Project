package org.balajicables.salesmanager.service;

import java.util.List;

import org.balajicables.salesmanager.model.WorkOrderOutput;
import org.springframework.data.domain.Page;

/**
 * Service Interface of Work Order Output(RBD,MWD and Bunching Output) .
 * 
 * @author Abin Sam
 */
public interface WorkOrderOutputService {

	List<WorkOrderOutput> fetchLatestBatchNo(String workOrderNo);

	WorkOrderOutput create(WorkOrderOutput workOrderOutput);

	Page<WorkOrderOutput> getWoOutputPagedList(String workOrderNo,
			int pageNumber, Integer rowsPerPage, String sortColName,
			String sortOrder);

	Boolean update(WorkOrderOutput woOutput);

	List<WorkOrderOutput> findByWorkOrderNo(String workOrderNo);

	List<WorkOrderOutput> findByBatchNo(String batchNo);

	List<WorkOrderOutput> findByWoOutputId(Long id);

	Boolean delete(Long id);

	Boolean delete(WorkOrderOutput workOrderOutput);

	Boolean updateStockedInStatusById(Long id);

	List<WorkOrderOutput> findBySoItemIdAndWorkOrderNo(Long long1,
			String workOrderNo);

	List<WorkOrderOutput> findByOrderIdAndItemCodeAndWorkOrderNo(String soNo,
			String itemCode, String woNo);

	List<WorkOrderOutput> findBySoItemIdAndWorkOrderNoAndBatchNo(
			Long orderDetailsId, String workOrderNo, String batchNo);

	List<WorkOrderOutput> findByOrderIdAndItemCodeAndWorkOrderNoAndBatchNo(
			String soNo, String itemCode, String woNo, String batchNo);

	List<WorkOrderOutput> findBySalesOrderItem(Long soItemId);

	Page<WorkOrderOutput> findByPagedSalesOrderItem(Long salesOrderItemId,
			int i, Integer rowsPerPage, String sortColName, String sortOrder);

}
