package org.balajicables.salesmanager.service.impl;

import java.util.List;
import javax.annotation.Resource;
import org.balajicables.salesmanager.model.AssortedRate;
import org.balajicables.salesmanager.repository.AssortedRateRepository;
import org.balajicables.salesmanager.service.AssortedRateService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * This class demonstrates the implementation of the AssortedRates service methods
 * 
 * @author Abin Sam
 */
@Service
public class AssortedRateServiceImpl implements AssortedRateService {

	@Resource
	AssortedRateRepository assortedRateRepository;
	
    /*Method to find assorted type rates by customerCode and assortedType*/
	@Override
	@Transactional
	public List<AssortedRate> findByCustomerCodeAndAssortedType(
			String customerCode, String assortedType) {
		return assortedRateRepository.findByCustomerCodeAndAssortedType(
				customerCode, assortedType);
	}
    /*Method to save the assorted type rates*/
	@Override
	@Transactional
	public AssortedRate create(AssortedRate assortedRate) {
		return assortedRateRepository.save(assortedRate);
	}
	/*Method to update the assorted type rates*/
	@Override
	@Transactional
	public Boolean update(AssortedRate assortedRate) {
		AssortedRate saved = assortedRateRepository.save(assortedRate);
		if (saved == null) {
			return false;
		}//end of if (saved == null) condition
		return true;
	}
}