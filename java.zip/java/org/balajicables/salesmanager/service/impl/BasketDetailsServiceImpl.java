package org.balajicables.salesmanager.service.impl;

import javax.annotation.Resource;
import org.balajicables.salesmanager.repository.BasketDetailsRepository;
import org.balajicables.salesmanager.service.BasketDetailsService;
import org.springframework.stereotype.Service;

/**
 * This class demonstrates the implementation of the BasketDetails service methods
 * 
 * @author Abin Sam
 */
@Service
public class BasketDetailsServiceImpl implements BasketDetailsService {

	@Resource
	BasketDetailsRepository basketDetailsRepository;

}
