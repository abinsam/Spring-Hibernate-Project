package org.balajicables.salesmanager.service.impl;

import java.util.List;

import javax.annotation.Resource;
import org.balajicables.salesmanager.model.BunchingWOInput;
import org.balajicables.salesmanager.repository.BunchingWOInputRepository;
import org.balajicables.salesmanager.service.BunchingWOInputService;
import org.balajicables.salesmanager.utils.JPAUtility;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * This class demonstrates the implementation of the BunchingWOInput service methods
 * 
 * @author Abin Sam
 */
@Service
public class BunchingWOInputServiceImpl implements BunchingWOInputService {

	@Resource
	BunchingWOInputRepository bunchingWOInputRepository;
	
    /*Method to create and save Bunching Workorder input*/
	@Override
	@Transactional
	public BunchingWOInput create(BunchingWOInput bunchingWOInput) {
		return bunchingWOInputRepository.save(bunchingWOInput);
	}
	/*Method to fetch JQGrid paged records of Bunching Workorder input based on the workorder number*/
	@Override
	@Transactional
	public Page<BunchingWOInput> getPagedOrders(String workOrderNo,
			int pageNumber, Integer rowsPerPage, String sortColName,
			String sortOrder) {
		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);
		return bunchingWOInputRepository.findByProductionWorkOrderWorkOrderNo(
				workOrderNo, pageable);
	}
	/*Method to delete Bunching Workorder input*/
	@Override
	@Transactional
	public Boolean delete(BunchingWOInput bunchingWOInput) {
		boolean deleted = false;
		if (bunchingWOInput != null) {
			bunchingWOInputRepository.delete(bunchingWOInput);
			deleted = true;
		}//end of if (bunchingWOInput != null) condition
		return deleted;

	}
	/*Method to update Bunching Workorder input*/
	@Override
	@Transactional
	public Boolean update(BunchingWOInput bunchingWOInput) {
		BunchingWOInput saved = bunchingWOInputRepository.save(bunchingWOInput);
		if (saved == null) {
			return false;
		}//end of if (saved == null) condition
		return true;
	}
	/*Method to update Bunching Workorder input*/
	@Override
	@Transactional
	public List<BunchingWOInput> findbyWorkOrderNoBunchingSizeCustomerName(
			String bunchingWorkOrderNoTag, String inputSize, String customerName) {
		return bunchingWOInputRepository
				.findByProductionWorkOrderWorkOrderNoAndSizeAndCustomerName(
						bunchingWorkOrderNoTag, inputSize, customerName);
	}
	/*Method to fetch latest Bunching Workorder number*/
	@Override
	@Transactional
	public List<BunchingWOInput> fetchLatestByProductionWorkOrderWorkOrderNo(
			String bunchingWorkOrderNoTag) {
		return null;
	}
	/*Method to fetch latest Bunching Workorder number*/
	@Override
	@Transactional
	public List<BunchingWOInput> findBySoItemIdAndWorkOrderNo(Long soItemId,
			String workOrderNo) {
		return bunchingWOInputRepository
				.findBySalesOrderItemOrderDetailIdAndProductionWorkOrderWorkOrderNo(
						soItemId, workOrderNo);
	}
	/*Method to fetch Bunching Workorder item by its id*/
	@Override
	@Transactional
	public List<BunchingWOInput> findById(Long id) {
		return bunchingWOInputRepository.findByBunchWoInputId(id);
	}
	/*Method to fetch Bunching Workorder item by its id*/
	@Override
	@Transactional
	public List<BunchingWOInput> findByOrderIdAndItemCodeAndWorkOrderNo(
			String dummySalesOrder, String itemCode, String woNo) {
		return bunchingWOInputRepository
				.findBySalesOrderItemOrdersOrderIdAndSalesOrderItemItemsItemCodeAndProductionWorkOrderWorkOrderNo(
						dummySalesOrder, itemCode, woNo);
	}

}
