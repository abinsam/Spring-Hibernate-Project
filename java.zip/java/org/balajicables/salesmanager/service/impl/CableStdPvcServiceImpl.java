package org.balajicables.salesmanager.service.impl;

import java.util.List;
import javax.annotation.Resource;
import org.balajicables.salesmanager.model.CableStdPvc;
import org.balajicables.salesmanager.repository.CableStdPvcRepository;
import org.balajicables.salesmanager.service.CableStdPvcService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
/**
 * This class demonstrates the implementation of the CableStdPvc service methods
 * 
 * @author Abin Sam
 */
@Service
public class CableStdPvcServiceImpl implements CableStdPvcService {

	@Resource
	CableStdPvcRepository cableStdPvcRepository;
	
    /*Method to fetch list of all cable standard pvcs*/
	@Override
	@Transactional
	public List<CableStdPvc> findAll() {
		return cableStdPvcRepository.findAll();
	}
}