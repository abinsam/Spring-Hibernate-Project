package org.balajicables.salesmanager.service.impl;

import java.util.List;
import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.balajicables.salesmanager.model.CustomerPartNo;
import org.balajicables.salesmanager.repository.CustomerPartNoRepository;
import org.balajicables.salesmanager.service.CustomerPartNoService;
import org.balajicables.salesmanager.utils.JPAUtility;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
/**
 * This class demonstrates the implementation of the CustomerPartNo service methods
 * 
 * @author Abin Sam
 */
@Service
public class CustomerPartNoServiceImpl implements CustomerPartNoService {

	@PersistenceContext
	private EntityManager em;

	@Resource
	private CustomerPartNoRepository customerPartNoRepository;

	/*Method to fetch list of part numbers based on customer id and item id*/
	@Override
	@Transactional
	public List<CustomerPartNo> findByCustomerIdAndItemId(Long custId,
			Long itemId) {

		return customerPartNoRepository.findByCustomerCustomerIdAndItemsItemId(
				custId, itemId);
	}
	/*Method to fetch list of part numbers based on item id*/
	@Override
	@Transactional
	public List<CustomerPartNo> findByItemsItemId(Long itemIdToDelete) {
		return customerPartNoRepository.findByItemsItemId(itemIdToDelete);
	}
	/*Method to fetch JQGrid paged records of part numbers based on default search*/
	@Override
	@Transactional
	public Page<CustomerPartNo> getPagedTaxes(int pageNumber,
			Integer rowsPerPage, String sortColName, String sortOrder) {
		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);
		return customerPartNoRepository.findAll(pageable);
	}
	/*Method to fetch JQGrid paged records of part numbers based search parameters*/
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<CustomerPartNo> fetchBySearch(Long qCustomerId, Long qitemId,
			int pagenumber, Integer rows, String sortColName, String sortOrder) {

		String basicQuery = " from CustomerPartNo o where ";
		String customerQuery = "  o.customer.customerId = " + qCustomerId
				+ " and";
		String itemQuery = "  o.items.itemId = " + qitemId + " and";
		String finalQuery = "  o.partNoId > 0  order by  o." + sortColName
				+ " " + sortOrder;
		if (qCustomerId != 0 && qCustomerId != null)
			basicQuery += customerQuery;
		if (qitemId != 0 && qitemId != null)
			basicQuery += itemQuery;

		basicQuery += finalQuery;
		return em.createQuery(basicQuery).getResultList();
	}
    /*Method to create and save part numbers*/
	@Transactional
	@Override
	public CustomerPartNo create(CustomerPartNo itemObj) {
		return customerPartNoRepository.save(itemObj);
	}
    /*Method to update customer part numbers*/
	@Override
	@Transactional
	public Boolean update(CustomerPartNo itemObj) {
		CustomerPartNo saved = customerPartNoRepository.save(itemObj);
		if (saved == null) {
			return false;
		}//end of if (saved == null) condition
		return true;
	}
	 /*Method to fetch customer part numbers based on id*/
	@Override
	@Transactional
	public List<CustomerPartNo> findById(Integer id) {
		return customerPartNoRepository.findByPartNoId(id);
	}
	/*Method to delete customer part numbers based on id*/
	@Override
	@Transactional
	public Boolean delete(Integer partNoId) {
		customerPartNoRepository.delete(partNoId);
		return true;
	}
	/*Method to fetch list of part numbers based on customer id and item code selected*/
	@Override
	@Transactional
	public List<CustomerPartNo> findByCustomerIdAndItemCode(
			Long customerSelect, String itemCodeSelect) {
		return customerPartNoRepository
				.findByCustomerCustomerIdAndItemsItemCode(customerSelect,
						itemCodeSelect);
	}
}
