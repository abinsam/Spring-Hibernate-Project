package org.balajicables.salesmanager.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.balajicables.salesmanager.model.Customer;
import org.balajicables.salesmanager.repository.CustomerRepository;
import org.balajicables.salesmanager.service.CustomerService;
import org.balajicables.salesmanager.utils.JPAUtility;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
/**
 * This class demonstrates the implementation of the Customer service methods
 * 
 * @author Abin Sam
 */
@Service
public class CustomerServiceImpl implements CustomerService {

	@Resource
	private CustomerRepository customerRepository;

	/*Method to create and save a new customer*/
	@Override
	@Transactional
	public Boolean create(Customer customer) {
		Customer saved = customerRepository.save(customer);
		if (saved == null) {
			return false;
		}
		return true;
	}
	/*Method to update and save any customer*/
	@Override
	@Transactional
	public Boolean update(Customer customer) {
		Customer saved = customerRepository.save(customer);
		if (saved == null) {
			return false;
		}
		return true;
	}
	/*Method to delete any customer based on customer id*/
	@Override
	@Transactional
	public Boolean delete(Long customerIdToDelete) {
		customerRepository.delete(customerIdToDelete);
		return true;
	}
	/*Method to fetch JQGrid paged records of customers based on default search parameter*/
	@Override
	@Transactional
	public Page<Customer> getPagedCustomers(int pageNumber,
			Integer rowsPerPage, String sortColName, String sortOrder) {
		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);
		return customerRepository.findAll(pageable);
	}
	/*Method to fetch list of all customers*/
	@Override
	@Transactional
	public List<Customer> findAll() {
		return customerRepository.findAll(new Sort("customerName"));
	}
	/*Method to set customer id*/
	/*@Override
	@Transactional
	public void setCustomerId(Long customerId) {

	}*/
	/*Method to fetch list of customers based on customer id*/
	@Override
	@Transactional
	public List<Customer> findById(Long customerId) {
		return customerRepository.findByCustomerId(customerId);
	}
	/*Method to fetch list of customers based on customer name*/
	@Override
	@Transactional
	public List<Customer> findByCustomerName(String custName) {
		return customerRepository.findByCustomerName(custName);
	}
	/*Method to fetch JQGrid paged records of customers based on customerId parameter*/
	@Override
	@Transactional
	public Page<Customer> findById(Long customerId, int pageNumber,
			Integer rowsPerPage, String sortColName, String sortOrder) {
		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);
		return customerRepository.findByCustomerId(customerId, pageable);
	}
	/*Method to fetch list of customers based on customer code*/
	@Override
	@Transactional
	public List<Customer> findByCustomerCode(String customerCode) {
		return customerRepository.findByCustomerCode(customerCode);
	}

}