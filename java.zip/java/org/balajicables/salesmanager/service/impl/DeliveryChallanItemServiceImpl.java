package org.balajicables.salesmanager.service.impl;

import java.util.List;
import javax.annotation.Resource;
import org.balajicables.salesmanager.model.DeliveryChallanItems;
import org.balajicables.salesmanager.repository.DeliveryChallanItemsRepository;
import org.balajicables.salesmanager.service.DeliveryChallanItemsService;
import org.balajicables.salesmanager.utils.JPAUtility;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
/**
 * This class demonstrates the implementation of the DeliveryChallanItems service methods
 * 
 * @author Abin Sam
 */
@Service
public class DeliveryChallanItemServiceImpl implements
		DeliveryChallanItemsService {

	@Resource
	DeliveryChallanItemsRepository deliveryChallanItemsRepository;

	/*Method to create and save delivery challan items*/
	@Override
	@Transactional
	public DeliveryChallanItems create(DeliveryChallanItems dcItemList) {
		return deliveryChallanItemsRepository.save(dcItemList);
	}
    /*Method to fetch JQGrid paged records of delivery challan item details based on deliveryChallanNo*/
	@Override
	@Transactional
	public Page<DeliveryChallanItems> getPagedDeliveryChallanItems(
			String deliveryChallanNo, int pageNumber, Integer rowsPerPage,
			String sortColName, String sortOrder) {
		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);
		return deliveryChallanItemsRepository
				.findByDeliveryChallanDeliveryChallanNo(deliveryChallanNo,
						pageable);

	}
    /*Method to fetch JQGrid paged records of delivery challans details based on default search*/
	@Override
	@Transactional
	public Page<DeliveryChallanItems> getPagedRecords(int pageNumber,
			Integer rowsPerPage, String sortColName, String sortOrder,
			String invoiceStatus, String deliveryChallanNo) {
		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);
		return deliveryChallanItemsRepository
				.findByDeliveryChallanDeliveryChallanNoAndDeliveryChallanInvoiceStatus(
						deliveryChallanNo, invoiceStatus, pageable);
	}
    /*Method to fetch list of delivery challans details based on deliveryChallanNo and invoiceStatus*/
	@Override
	@Transactional
	public List<DeliveryChallanItems> findByDeliveryChallanDeliveryChallanNoAndDeliveryChallanInvoiceStatus(
			String deliveryChallanNo, String invoiceStatus) {
		return deliveryChallanItemsRepository
				.findByDeliveryChallanDeliveryChallanNoAndDeliveryChallanInvoiceStatus(
						deliveryChallanNo, invoiceStatus);
	}
    /*Method to fetch list of delivery challans details based on deliveryChallanNo*/
	@Override
	@Transactional
	public List<DeliveryChallanItems> findByDeliveryChallanNo(
			String deliveryChallanNo) {
		return deliveryChallanItemsRepository
				.findByDeliveryChallanDeliveryChallanNo(deliveryChallanNo);
	}
    /*Method to delete delivery challan items based on delivery challan item id*/
	@Override
	@Transactional
	public Boolean delete(Long dcItemId) {
		deliveryChallanItemsRepository.delete(dcItemId);
		return true;
	}
	@Override
	public List<DeliveryChallanItems> findByItemItemIdAndDeliveryChallanOrdersOrderId(
			Long itemId, String orderId) {
	return deliveryChallanItemsRepository.findByItemItemIdAndDeliveryChallanOrdersOrderId(itemId,orderId);
	}
	
}
