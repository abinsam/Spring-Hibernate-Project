package org.balajicables.salesmanager.service.impl;

import java.util.List;
import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.balajicables.salesmanager.model.DeliveryChallan;
import org.balajicables.salesmanager.repository.DeliveryChallanRepository;
import org.balajicables.salesmanager.service.DeliveryChallanService;
import org.balajicables.salesmanager.utils.JPAUtility;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
/**
 * This class demonstrates the implementation of the DeliveryChallanItems service methods
 * 
 * @author Abin Sam
 */
@Service
public class DeliveryChallanServiceImpl implements DeliveryChallanService {

	@PersistenceContext
	private EntityManager em;
	
	@Resource
	DeliveryChallanRepository deliveryChallanRepository;
	
	/*Method to create and save delivery challan*/
	@Override
	@Transactional
	public DeliveryChallan create(DeliveryChallan dcItem) {
		return deliveryChallanRepository.save(dcItem);
	}
	/*Method to fetch latest delivery challan number*/
	@Override
	@Transactional
	public List<DeliveryChallan> fetchLatestDeliveryChallan() {
		return em.createQuery(
				"from DeliveryChallan o order by o.createdTime desc limit 1",
				DeliveryChallan.class).getResultList();
	}
    /*Method to fetch JQGrid paged records of delivery challan based on default search*/
	@Override
	@Transactional
	public Page<DeliveryChallan> getPagedRecords(int pageNumber,
			Integer rowsPerPage, String sortColName, String sortOrder,
			String invoiceStatus, String deliveryChallanNo) {
		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);
		return deliveryChallanRepository
				.findByDeliveryChallanNoAndInvoiceStatus(deliveryChallanNo,
						invoiceStatus, pageable);
	}
	/*Method to fetch JQGrid paged records of delivery challan based on default search*/
	@Override
	@Transactional
	public Boolean delete(String dcNo) {
		Boolean deleted = false;
		if (dcNo != null) {
			deliveryChallanRepository.delete(dcNo);
			deleted = true;
		}
		return deleted;
	}
	/*Method to fetch JQGrid paged records of delivery challan based on default search*/
	@Override
	@Transactional
	public Page<DeliveryChallan> getPagedPackingSlipDetails(String dcNo,
			int pageNumber, Integer rowsPerPage, String sortColName,
			String sortOrder) {
		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);
		return deliveryChallanRepository
				.findByDeliveryChallanNo(dcNo, pageable);
	}
	/*Method to fetch JQGrid paged records of delivery challan based on default search*/
	@Override
	@Transactional
	public List<DeliveryChallan> findByDeliveryChallanNo(
			String deliveryChallanNo) {
		return deliveryChallanRepository
				.findByDeliveryChallanNo(deliveryChallanNo);
	}
	/*Method to fetch JQGrid paged records of delivery challan based on default search*/
	@Override
	@Transactional
	public List<DeliveryChallan> findByDeliveryChallanNoAndInvoiceStatus(
			String deliveryChallanNo, String invoiceStatus) {
		return deliveryChallanRepository
				.findByDeliveryChallanNoAndInvoiceStatus(deliveryChallanNo,
						invoiceStatus);
	}
	/*Method to update delivery challan based on delivery challan number*/
	@Override
	@Transactional
	public Boolean update(DeliveryChallan deliveryChallan) {
		DeliveryChallan saved = deliveryChallanRepository.save(deliveryChallan);
		if (saved == null) {
			return false;
		}
		return true;
	}
	/*Method to fetch list of delivery challan based on customer Id*/
	@Override
	@Transactional
	public List<DeliveryChallan> findByOrderCustomerCustomerId(Long customerId) {
		return deliveryChallanRepository
				.findByOrdersCustomerCustomerId(customerId);
	}
	/*Method to fetch list of delivery challan based on month and year of creation*/
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<DeliveryChallan> finddByStockOutsAndMonthYear(int month,
			int year) {
		String basicQuery = " from DeliveryChallan o where MONTH(o.createdTime)="
				+ month + " and YEAR(o.createdTime)=" + year + " ";

		return em.createQuery(basicQuery).getResultList();
	}
	/*Method to fetch list of delivery challan based on customer,month and year*/
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<DeliveryChallan> finddByCustomerAndMonthYear(Long customerId,
			int monthValue, int yearValue) {
		String basicQuery = " from DeliveryChallan o where MONTH(o.createdTime)="
				+ monthValue
				+ " and YEAR(o.createdTime)="
				+ yearValue
				+ "  and o.orders.customer.customerId =" + customerId + "";

		return em.createQuery(basicQuery).getResultList();
	}


}