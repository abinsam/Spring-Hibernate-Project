package org.balajicables.salesmanager.service.impl;

import java.util.List;

import javax.annotation.Resource;
import org.balajicables.salesmanager.model.InvoiceItems;
import org.balajicables.salesmanager.repository.InvoiceItemsRepository;
import org.balajicables.salesmanager.service.InvoiceItemsService;
import org.balajicables.salesmanager.utils.JPAUtility;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
/**
 * This class demonstrates the implementation of the InvoiceItems service methods
 * 
 * @author Abin Sam
 */
@Service
public class InvoiceItemsServiceImpl implements InvoiceItemsService {

	@Resource
	InvoiceItemsRepository invoiceItemsRepository;

	/*Method to save invoice item list*/
	@Override
	@Transactional
	public InvoiceItems save(InvoiceItems invoice) {
		return invoiceItemsRepository.save(invoice);
	}
	/*Method to fetch JQGrid paged records of invoice item based on invoice number*/
	@Override
	@Transactional
	public Page<InvoiceItems> getPagedOrders(String invoiceNo, int pageNumber,
			Integer rowsPerPage, String sortColName, String sortOrder) {
		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);
		return invoiceItemsRepository.findByInvoiceInvoiceNo(invoiceNo,
				pageable);
	}
	/*Method to fetch list of invoice items based on invoice number*/
	@Override
	@Transactional
	public List<InvoiceItems> findByInvoiceNo(String newdInvoiceNo) {
		return invoiceItemsRepository.findByInvoiceInvoiceNo(newdInvoiceNo);
	}
	/*Method to delete invoice items based on invoice item id*/
	@Override
	@Transactional
	public Boolean delete(Long invoiceId) {
		invoiceItemsRepository.delete(invoiceId);
		return true;
	}
}
