package org.balajicables.salesmanager.service.impl;

import java.util.List;
import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.balajicables.salesmanager.model.Invoice;
import org.balajicables.salesmanager.repository.InvoiceRepository;
import org.balajicables.salesmanager.service.InvoiceService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
/**
 * This class demonstrates the implementation of the Invoice service methods
 * 
 * @author Abin Sam
 */
@Service
public class InvoiceServiceImpl implements InvoiceService {

	@PersistenceContext
	private EntityManager em;
	
	@Resource
	InvoiceRepository invoiceRepository;

	/*Method to fetch latest invoice number*/
	@Override
	@Transactional
	public List<Invoice> fetchLatestInvoiceNo() {
		return em.createQuery(
				"from Invoice o order by o.createdTime desc limit 1",
				Invoice.class).getResultList();
	}
	/*Method to save invoice number*/
	@Override
	@Transactional
	public Invoice save(Invoice invoice) {
		return invoiceRepository.save(invoice);
	}
	/*Method to fetch invoice details based on newdInvoiceNo*/
	@Override
	@Transactional
	public List<Invoice> findByInvoiceNo(String newdInvoiceNo) {
		return invoiceRepository.findByInvoiceNo(newdInvoiceNo);
	}
	/*Method to fetch invoice numbers based on customer Id*/
	@Override
	@Transactional
	public List<Invoice> findByCustomerId(Long customerId) {
		return invoiceRepository.findByCustomerCustomerId(customerId);
	}
	/*Method to update and save invoices*/
	@Override
	@Transactional
	public Boolean update(Invoice invoices) {
		Invoice saved = invoiceRepository.save(invoices);
		if (saved == null) {
			return false;
		}//end of if (saved == null) condition
		return true;
	}
	/*Method to delete invoices*/
	@Override
	@Transactional
	public Boolean delete(String invoiceNo) {
		invoiceRepository.delete(invoiceNo);
		return true;
	}
	/*Method to fetch invoices based on month and year of creation*/
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<Invoice> findByMonthYear(int month, int year) {
		String basicQuery = " from Invoice o where MONTH(o.createdTime)="
				+ month + " and YEAR(o.createdTime)=" + year + " ";

		return em.createQuery(basicQuery).getResultList();
	}
	/*Method to fetch invoices based on month and year of creation*/
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<Invoice> finddByCustomerAndMonthYear(Long customerId,
			int monthValue, int yearValue) {
		String basicQuery = " from Invoice o where MONTH(o.createdTime)="
				+ monthValue + " and YEAR(o.createdTime)=" + yearValue
				+ "  and o.customer.customerId =" + customerId + "";

		return em.createQuery(basicQuery).getResultList();
	}

}