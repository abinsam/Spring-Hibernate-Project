package org.balajicables.salesmanager.service.impl;

import java.util.List;
import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.balajicables.salesmanager.dao.ItemDao;
import org.balajicables.salesmanager.model.Area;
import org.balajicables.salesmanager.model.CableStdPvc;
import org.balajicables.salesmanager.model.Colour;
import org.balajicables.salesmanager.model.CopperDiameter;
import org.balajicables.salesmanager.model.Item;
import org.balajicables.salesmanager.model.Unit;
import org.balajicables.salesmanager.model.ProductType;
import org.balajicables.salesmanager.repository.ItemRepository;
import org.balajicables.salesmanager.service.ItemService;
import org.balajicables.salesmanager.utils.JPAUtility;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
/**
 * This class demonstrates the implementation of the Items service methods
 * 
 * @author Abin Sam
 */
@Component
public class ItemServiceImpl implements ItemService {

	@PersistenceContext
	private EntityManager em;
	
	@Resource
	private ItemRepository itemRepository;

	@Autowired
	private ItemDao itemDao;

	/*Method to fetch list of all items from item master*/
	@Override
	@Transactional
	public List<Item> getAll() {
		return itemDao.getAll();
	}
	/*Method to set items in itemDao*/
	public void setItemDao(ItemDao itemDao) {
		this.itemDao = itemDao;
	}
	/*Method to update items in item master*/
	@Override
	@Transactional
	public Boolean update(Long itemId, String itemCode, String itemName,
			String color) {
		Item item = itemDao.getById(itemId);
		itemDao.update(item);
		return true;
	}
	/*Method to delete items from item master*/
	@Override
	@Transactional
	public Boolean delete(Long itemId) {
		Item item = itemDao.getById(itemId);
		itemDao.delete(item);
		return true;
	}
	/*Method to fetch Paged records of items from item master*/
	@Override
	@Transactional
	public List<Item> getPagedItems(int pageNumber, int recordsPerPage,
			String sortColName, String sortOrder) {
		return itemDao.get(pageNumber, recordsPerPage, sortColName, sortOrder);
	}
	/*Method to fetch items count from item master*/
	@Override
	@Transactional
	public long getItemsCount() {
		return itemDao.getItemsCount();
	}
	/*Method to fetch list of cable standard pvcs*/
	@Override
	@Transactional
	public List<CableStdPvc> getAllCableStdPvcs() {
		return itemDao.getAllCableStdPvcs();
	}
	/*Method to fetch list of copper diameters*/
	@Override
	@Transactional
	public List<CopperDiameter> getAllCopperDiameters() {
		return itemDao.getAllCopperDiameters();
	}
	/*Method to fetch list of colors*/
	@Override
	@Transactional
	public List<Colour> getAllColours() {
		return itemDao.getAllColours();
	}
	/*Method to fetch list of product types*/
	@Override
	@Transactional
	public List<ProductType> getAllProductTypes() {
		return itemDao.getAllProductTypes();
	}
	/*Method to fetch list of all items from item master*/
	@Override
	@Transactional
	public List<Item> getAllItems() {
		return itemDao.getAllItemId();
	}
	/*Method to fetch list of all items from item master*/
	@Override
	@Transactional(readOnly = true)
	public List<Item> findByItemCode(String itemCode) {
		return itemRepository.findByItemCode(itemCode);
	}
	/*Method to create and save items in item master*/
	@Transactional(readOnly = true)
	@Override
	public Item create(Item itemObj) {
		return itemRepository.save(itemObj);
	}
	/*Method to fetch list of all items from item master based on item code*/
	@Override
	@Transactional
	public List<Item> fetchItemId(String itemCode) {
		return em
				.createQuery(
						"  from Item o where o.itemCode='" + itemCode + "'",
						Item.class).getResultList();
	}
	/*Method to fetch list of all copper diameters from CopperDiameter based on copperkey*/
	@Override
	@Transactional
	public List<CopperDiameter> getCopperDiameter(String copperkey) {
		return em.createQuery(
				"  from CopperDiameter  cd where cd.copperkey='" + copperkey
						+ "'", CopperDiameter.class).getResultList();
	}
	/*Method to fetch list of all colors from Colour based on colour*/
	@Override
	@Transactional
	public List<Colour> getColor(String colour) {
		return em.createQuery(
				"  from Colour  cd where cd.colorKey='" + colour + "'",
				Colour.class).getResultList();
	}
	/*Method to fetch list of all cableStdPvcs from CableStdPvc based on cableStdKey*/
	@Override
	@Transactional
	public List<CableStdPvc> getCableStd(String cableStdKey) {
		return em.createQuery(
				"  from CableStdPvc  cd where cd.cableStdKey='" + cableStdKey
						+ "'", CableStdPvc.class).getResultList();
	}
	/*Method to fetch list of all productTypes from ProductType based on productType*/
	@Override
	@Transactional
	public List<ProductType> getProductType(String productType) {
		return em.createQuery(
				"  from ProductType  cd where cd.productKey='" + productType
						+ "'", ProductType.class).getResultList();

	}
	/*Method to fetch list of all raw materials*/
	@Override
	@Transactional
	public List<Item> getAllRawMaterials() {
		return itemDao.getAllRawMaterial();
	}
	/*Method to fetch list of all units*/
	@Override
	@Transactional
	public List<Unit> getAllUnits() {
		return itemDao.getAllUnit();
	}
	/*Method to fetch list of all items from item master based on item type*/
	@Override
	@Transactional
	public List<Item> findByItemType(String itemType) {
		return itemRepository.findByItemType(itemType);
	}
	/*Method to fetch list of all items from item master based on input size*/
	@Override
	@Transactional
	public List<Item> findByItemInputSize(String itemIdSelect) {
		return itemRepository.findByInputSize(itemIdSelect);
	}
	/*Method to fetch list of all items from item master*/
	@Override
	@Transactional
	public List<Item> findAll() {
		return itemRepository.findAll();
	}
	/*Method to fetch list of items from item master based on process type*/
	@Override
	@Transactional
	public List<Item> findByProductTypeProcessType(String processType) {
		return itemRepository.findByProductTypeProcessType(processType);
	}
	/*Method to fetch list of items from item master based on product key*/
	@Override
	@Transactional
	public List<Item> findByProductKey(String productKey) {
		return itemRepository.findByProductTypeProductKey(productKey);
	}
	/*Method to fetch list of items from item master based on item type and number of copper strands*/
	@Override
	@Transactional
	public List<Item> findByItemTypeAndNumberOfCuStrands(String itemType,
			Integer numberOfCopperStrand) {
		return itemRepository.findByItemTypeAndNumberOfCopperStrands(itemType,
				numberOfCopperStrand);
	}
	/*Method to fetch JQGrid paged records of all items from item master based on default search*/
	@Override
	@Transactional
	public Page<Item> getItemPagedStore(int pageNumber, Integer rowsPerPage,
			String sortColName, String sortOrder) {
		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);
		return itemRepository.findAll(pageable);
	}
	/*Method to fetch JQGrid paged records of all items from item master based on search parameters*/
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<Item> fetchBySearch(String qItemCode,
			Integer qNumberOfCopperStrands, String qCopperKey,
			String qOuterDiameter, String qOdLabel, String qMainColour,
			String qInnerColor, String qMainColourKey, String qInnerColorKey,
			String qCableStdKey, String qLayLength, String qLayType,
			String qProductKey, int pagenumber, Integer rows,
			String sortColName, String sortOrder) {
		String basicQuery = " from Item o where ";

		String itemCodeQuery = " o.itemCode='" + qItemCode + "' and ";

		String noCuStrandQuery = " o.numberOfCopperStrands="
				+ qNumberOfCopperStrands + " and ";
		String cuQuery = " o.copperStrandDiameter.copperkey= '" + qCopperKey
				+ "' and   ";
		String odQuery = " o.outerDiameter='" + qOuterDiameter + "' and  ";
		String odLabelQuery = " o.odLabel='" + qOdLabel + "' and  ";
		String mainColorQuery = " o.mainColour.color  ='" + qMainColour
				+ "' and ";
		String innerColorQuery = " o.innerColour.color = '" + qInnerColor
				+ "' and ";
		String mainColorKeyQuery = " o.mainColour.colorKey  ='"
				+ qMainColourKey + "' and ";
		String innerColorKeyQuery = " o.innerColour.colorKey = '"
				+ qInnerColorKey + "' and ";
		String cableStdQuery = " o.cableStdPvc.cableStdKey ='" + qCableStdKey
				+ "' and  ";
		String layLengthQuery = " o.layLength=" + qLayLength + " and ";
		String layTypeQuery = " o.layType='" + qLayType + "' and  ";
		String pdtQuery = " o.productType.productKey = '" + qProductKey
				+ "' and ";

		String finalQuery = "  o.itemId >0  order by  o." + sortColName + " "
				+ sortOrder;

		if (qItemCode != null && qItemCode != "")
			basicQuery += itemCodeQuery;
		if (qNumberOfCopperStrands != 0)
			basicQuery += noCuStrandQuery;
		if (qCopperKey != null && qCopperKey != "")
			basicQuery += cuQuery;
		if (qOuterDiameter != null && qOuterDiameter != "")
			basicQuery += odQuery;
		if (qOdLabel != null && qOdLabel != "")
			basicQuery += odLabelQuery;
		if (qMainColour != null && qMainColour != "")
			basicQuery += mainColorQuery;
		if (qInnerColor != null && qInnerColor != "")
			basicQuery += innerColorQuery;
		if (qMainColourKey != null && qMainColourKey != "")
			basicQuery += mainColorKeyQuery;
		if (qInnerColorKey != null && qInnerColorKey != "")
			basicQuery += innerColorKeyQuery;
		if (qCableStdKey != null && qCableStdKey != "")
			basicQuery += cableStdQuery;
		if (qLayLength != null && qLayLength != "")
			basicQuery += layLengthQuery;
		if (qLayType != null && qLayType != "")
			basicQuery += layTypeQuery;
		if (qProductKey != null && qProductKey != "")
			basicQuery += pdtQuery;

		basicQuery += finalQuery;

		return em.createQuery(basicQuery).getResultList();
	}
	/*Method to fetch list of all item codes from item master*/
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<String> selectAllItemCodes() {
		return em.createQuery("Select i.itemCode from Item i").getResultList();
	}
	/*Method to fetch list of item codes from item master based on item type*/
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<String> findByItemTypeQuery(String itemType) {
		return em.createQuery(
				" Select o.itemCode from Item o where o.itemType='" + itemType
						+ "'").getResultList();
	}
	/*Method to fetch list of items from item master based on item type,number of copper strands and copper diameter*/
	@Override
	@Transactional
	public List<Item> findByItemTypeAndNumberOfCuStrandsAndCopperStrandDia(
			String itemType, Integer numberOfCopperStrandsSelect,
			String copperDiameterSelect) {
		return itemRepository
				.findByItemTypeAndNumberOfCopperStrandsAndCopperStrandDiameterCopperkey(
						itemType, numberOfCopperStrandsSelect,
						copperDiameterSelect);
	}
	/*Method to fetch list of items from item master based on product type,lay length and copper diameter*/
	@Override
	@Transactional
	public List<Item> findByCuDiameterAndCuStrandAndLayLengthAndProductType(
			String copperDiameterSelect, Integer numberOfCopperStrandsSelect,
			Integer layLengthSelect, String productType) {
		return itemRepository
				.findByCopperStrandDiameterCopperkeyAndNumberOfCopperStrandsAndProductTypeProductTypeAndLayLength(
						copperDiameterSelect, numberOfCopperStrandsSelect,
						productType, layLengthSelect);

	}
	/*Method to fetch list of items from item master based on product type,strand diameter and copper diameter*/
	@Override
	@Transactional
	public List<Item> findByCuDiameterAndCuStrandAndProductType(
			String copperDiameterSelect, Integer numberOfCopperStrandsSelect,
			String productType) {
		return itemRepository
				.findByCopperStrandDiameterCopperkeyAndNumberOfCopperStrandsAndProductTypeProductType(
						copperDiameterSelect, numberOfCopperStrandsSelect,
						productType);
	}
	/*Method to fetch list of area of items from item master based on copper satrnd label*/
	@Override
	@Transactional
	public List<Area> getAreaValue(String cuStrandLabel) {
		return em.createQuery(
				"  from Area cd where cd.area='" + cuStrandLabel + "'",
				Area.class).getResultList();
	}
	/*Method to fetch list of product types*/
	@Override
	@Transactional
	public List<Item> getItemProductType(String productType) {
		return itemRepository.findByProductTypeProductType(productType);
	}
	/*Method to fetch list of items from item master based on productType and numberOfCopperStrand */
	@Override
	@Transactional
	public List<Item> findByProductTypeAndNumberOfCuStrands(String productType,
			Integer numberOfCopperStrand) {
		return itemRepository
				.findByProductTypeProductTypeAndNumberOfCopperStrands(
						productType, numberOfCopperStrand);
	}
	/*Method to fetch list of items from item master based on item id*/
	@Override
	@Transactional
	public List<Item> findByItemId(Long itemId) {
		return itemRepository.findByItemId(itemId);
	}
	/*Method to fetch list of all items from item master that have been stocked in*/
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<String> fetchInventoryItemCodes() {
		return em
				.createQuery(
						"Select distinct(i.itemCode) from StockIn i UNION distinct(o.itemCode) from StockOut o ")
				.getResultList();
	}
}