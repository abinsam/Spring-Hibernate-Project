package org.balajicables.salesmanager.service.impl;

import java.util.List;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.balajicables.salesmanager.model.LabelReport;
import org.balajicables.salesmanager.repository.LabelReportRepository;
import org.balajicables.salesmanager.service.LabelReportService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
/**
 * This class demonstrates the implementation of the LabelReport service methods
 * 
 * @author Abin Sam
 */
@Service
public class LabelReportServiceImpl implements LabelReportService {

	@PersistenceContext
	private EntityManager em;
	
	@Resource
	private LabelReportRepository labelReportRepository;

	/*Method to create and save labels for work order items*/
	@Override
	@Transactional
	public LabelReport create(LabelReport labelReport) {
		return labelReportRepository.save(labelReport);
	}
	/*Method to find labels based on work order*/
	@Override
	@Transactional
	public List<LabelReport> findByWorkOrderNo(String workOrderNo) {
		return labelReportRepository
				.findByWorkOrderItemsProductionWorkOrderWorkOrderNo(workOrderNo);

	}
	/*Method to delete labels based on work order*/
	@Override
	@Transactional
	public void delete(Long labelReportId) {
		labelReportRepository.delete(labelReportId);
	}
	/*Method to find labels based on work order item id*/
	@Override
	@Transactional
	public List<LabelReport> findByWorkOrderItemsWorkOrderItemId(Long woItemId) {
		return labelReportRepository
				.findByWorkOrderItemsWorkOrderItemId(woItemId);
	}
	/*Method to find all labels*/
	@Override
	@Transactional
	public List<LabelReport> findAll() {
		return labelReportRepository.findAll();
	}
	/*Method to delete labels based on work order number*/
	@Override
	@Transactional
	public Boolean deleteByWorkOrderNo(String workOrderNo) {
		String query = " Delete from LabelReport o where o.workOrderNo='"
				+ workOrderNo + "' " + "  and o.labelReportId > 0";
		int deletedCount = em.createQuery(query).executeUpdate();
		if (deletedCount > 0)
			return true;
		else
			return false;
	}

}
