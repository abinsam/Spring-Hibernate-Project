package org.balajicables.salesmanager.service.impl;
/**
 * This class demonstrates the implementation of the Machine service methods
 * 
 * @author Abin Sam
 */
import java.util.List;
import javax.annotation.Resource;
import org.balajicables.salesmanager.model.MachineDetails;
import org.balajicables.salesmanager.repository.MachineRepository;
import org.balajicables.salesmanager.service.MachineService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class MachineServiceImpl implements MachineService {

	@Resource
	MachineRepository machineRepository;

	/*Method to find all machine numbers*/
	@Override
	@Transactional
	public List<MachineDetails> findAll() {
		return machineRepository.findAll();
	}
	/*Method to find machine numbers based on hte process type*/
	@Override
	@Transactional
	public List<MachineDetails> findProcessMachineNo(String processType) {
		return machineRepository.findByProcessProcessType(processType);

	}

}
