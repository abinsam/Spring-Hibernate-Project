package org.balajicables.salesmanager.service.impl;

import java.util.List;
import javax.annotation.Resource;
import org.balajicables.salesmanager.model.MwdWorkOrder;
import org.balajicables.salesmanager.repository.MwdWorkOrderRepository;
import org.balajicables.salesmanager.service.MwdWorkOrderInputService;
import org.balajicables.salesmanager.utils.JPAUtility;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
/**
 * This class demonstrates the implementation of the MwdWorkOrderInput service methods
 * 
 * @author Abin Sam
 */
@Service
public class MwdWorkOrderInputServiceImpl implements MwdWorkOrderInputService {

	@Resource
	MwdWorkOrderRepository mwdWorkOrderRepository;

	/*Method ot create and save MMH workorder*/
	@Override
	@Transactional
	public MwdWorkOrder create(MwdWorkOrder mwdWorkOrder) {
		return mwdWorkOrderRepository.save(mwdWorkOrder);
	}
	/*Method ot fetch JQGrid paged records of MMH workorder details based on workorder number*/
	@Override
	@Transactional
	public Page<MwdWorkOrder> getPagedOrders(String workOrderNo,
			int pageNumber, Integer rowsPerPage, String sortColName,
			String sortOrder) {
		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);
		return mwdWorkOrderRepository.findByProductionWorkOrderWorkOrderNo(
				workOrderNo, pageable);
	}
    /*Method to delete MMH workorder*/
	@Override
	@Transactional
	public Boolean delete(MwdWorkOrder mwdWorkOrder) {
		boolean deleted = false;
		if (mwdWorkOrder != null) {
			mwdWorkOrderRepository.delete(mwdWorkOrder);
			deleted = true;
		}//end of if (mwdWorkOrder != null) condition
		return deleted;

	}
	/*Method to fetch MMH workorder number from production workorders*/
	@Override
	@Transactional
	public List<MwdWorkOrder> findByProductionWorkOrderWorkOrderNo(
			String workOrderNo) {
		return mwdWorkOrderRepository
				.findByProductionWorkOrderWorkOrderNo(workOrderNo);
	}
	/*Method to update and save MMH workorder number*/
	@Override
	@Transactional
	public Boolean update(MwdWorkOrder mwdWorkOrder) {
		MwdWorkOrder saved = mwdWorkOrderRepository.save(mwdWorkOrder);
		if (saved == null) {
			return false;
		}
		return true;
	}
	/*Method to fetch list of workorders based on input size and customer name*/
	@Override
	@Transactional
	public List<MwdWorkOrder> findbyWorkOrderNoSizeCUstomerName(
			String mwdWorkOrderNo, String inputSize, String customerName) {
		// TODO Auto-generated method stub
		return mwdWorkOrderRepository
				.findByProductionWorkOrderWorkOrderNoAndSizeAndCustomerName(
						mwdWorkOrderNo, inputSize, customerName);
	}
	/*Method to fetch list of workorder items based on sales order item id o and workorder*/
	@Override
	@Transactional
	public List<MwdWorkOrder> findBySoItemIdAndWorkOrderNo(Long soItemId,
			String workOrderNo) {
		// TODO Auto-generated method stub
		return mwdWorkOrderRepository
				.findBySalesOrderItemOrderDetailIdAndProductionWorkOrderWorkOrderNo(
						soItemId, workOrderNo);
	}
	/*Method to fetch list of workorder items based on workorder input id*/
	@Override
	@Transactional
	public List<MwdWorkOrder> findById(Long id) {
		// TODO Auto-generated method stub
		return mwdWorkOrderRepository.findByMwdWoInputId(id);
	}
	/*Method to fetch list of workorder items based on item code,order id and workorder number*/
	@Override
	@Transactional
	public List<MwdWorkOrder> findByOrderIdAndItemCodeAndWorkOrderNo(
			String dummySalesOrder, String itemCode, String woNo) {
		return mwdWorkOrderRepository
				.findBySalesOrderItemOrdersOrderIdAndSalesOrderItemItemsItemCodeAndProductionWorkOrderWorkOrderNo(
						dummySalesOrder, itemCode, woNo);
	}

}
