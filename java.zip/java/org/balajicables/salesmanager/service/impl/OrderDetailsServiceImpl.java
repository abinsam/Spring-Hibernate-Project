package org.balajicables.salesmanager.service.impl;

import java.util.List;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.balajicables.salesmanager.model.SalesOrderItem;
import org.balajicables.salesmanager.repository.OrderDetailsRepository;
import org.balajicables.salesmanager.service.OrderDetailsService;
import org.balajicables.salesmanager.utils.JPAUtility;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
/**
 * This class demonstrates the implementation of the OrderDetails service methods
 * 
 * @author Abin Sam
 */
@Service
public class OrderDetailsServiceImpl implements OrderDetailsService {

	@PersistenceContext
	private EntityManager em;

	@Resource
	private OrderDetailsRepository orderDetailsRepository;

	/*Method to fetch JQGrid paged records of salesorder items based on order Id*/
	@Override
	@Transactional
	public Page<SalesOrderItem> getPagedSalesOrderItems(String orderId,
			int pageNumber, Integer rowsPerPage, String sortColName,
			String sortOrder) {
		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);
		return orderDetailsRepository.findByOrdersOrderId(orderId, pageable);
	}
    /*Method to create and save salesorder items*/
	@Override
	@Transactional
	public SalesOrderItem create(SalesOrderItem soitem) {
		return orderDetailsRepository.save(soitem);

	}
	/*Method to fetch list of salesorder items based on order id and item id*/
	@Override
	public List<SalesOrderItem> findByOrderIdItemId(String orderId,
			String itemId) {
		return orderDetailsRepository.findByOrdersOrderIdAndItemsItemCode(
				orderId, itemId);
	}
	/*Method to update sales order items*/
	@Override
	@Transactional
	public Boolean update(SalesOrderItem itemObj) {
		SalesOrderItem saved = orderDetailsRepository.save(itemObj);
		if (saved == null) {
			return false;
		}
		return true;
	}
	/*Method to fetch JQGrid paged records of salesorder items based on default search*/
	@Transactional(readOnly = true)
	@Override
	public Page<SalesOrderItem> getPagedSalesOrderItems(int pageNumber,
			Integer rowsPerPage, String sortColName, String sortOrder) {
		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);
		return orderDetailsRepository.findAll(pageable);
	}
	/*Method to fetch list of salesorder items based on id*/
	@Override
	@Transactional
	public List<SalesOrderItem> findById(Long Ids) {
		return orderDetailsRepository.findByOrderDetailId(Ids);
	}
	/*Method to fetch list of salesorder items based on search parameters*/
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<SalesOrderItem> fetchBySearch(String qOrderId,
			Long qCustomerId, Integer qNumberOfCopperStrands,
			String qCopperKey, String qOdLabel, String qMainColour,
			String qInnerColor, String qCableStdKey, String qLayLength,
			String qLayType, String qProductKey, String qItemCode,
			String qOrderAcceptanceDate, String qOrderAcceptanceDateTo,
			int pagenumber, int rows, String sortColName, String sortOrder,
			String reportType) {

		String basicQuery = "from SalesOrderItem o where ";
		String orderIdQuery = " o.orders.orderId like '%" + qOrderId
				+ "%' and ";
		String customerQuery = "  o.orders.customer.customerId =" + qCustomerId
				+ " and  ";
		String noCuStrandQuery = " o.items.numberOfCopperStrands="
				+ qNumberOfCopperStrands + " and ";
		String cuQuery = " o.items.copperStrandDiameter.copperkey like '%"
				+ qCopperKey + "%' and   ";
		String odQuery = " o.items.odLabel='" + qOdLabel + "' and  ";
		String mainColorQuery = " o.items.mainColour.color like '%"
				+ qMainColour + "%' and ";
		String innerColorQuery = " o.items.innerColour.color like '%"
				+ qInnerColor + "%' and ";
		String cableStdQuery = " o.items.cableStdPvc.cableStdKey like '%"
				+ qCableStdKey + "%' and  ";
		String layLengthQuery = " o.items.layLength=" + qLayLength + " and ";
		String layTypeQuery = " o.items.layType='" + qLayType + "' and  ";
		String pdtQuery = " o.items.productType.productKey like '%"
				+ qProductKey + "%' and ";
		String itemCodeQuery = " o.items.itemCode like '% " + qItemCode
				+ "%' and ";
		String orderAcceptanceDateQuery = " o.orders.orderAcceptanceDate between '"
				+ qOrderAcceptanceDate
				+ "' and '"
				+ qOrderAcceptanceDateTo
				+ "' and ";
		String dummySalesOrderQuery = " o.orders.customer.customerId!=1 and ";
		String orderStatusQuery = " o.orders.orderStatus.status  IN ('Approved For Prodn','Approved') and  ";
		String reportTypeQuery = "";
		if (reportType.equalsIgnoreCase("Extrusion"))
			reportTypeQuery = " o.items.itemType='ITEM' and ";
		if (reportType.equalsIgnoreCase("MWD"))
			reportTypeQuery = " o.items.productType.productKey='PL' and";
		if (reportType.equalsIgnoreCase("Bunching"))
			reportTypeQuery = " o.items.productType.productKey='BC' and ";

		String finalQuery = " o.balanceQty > 0 ";

		if (qOrderId != null && qOrderId != "")
			basicQuery += orderIdQuery;
		if (qCustomerId != 0)
			basicQuery += customerQuery;
		if (qNumberOfCopperStrands != 0)
			basicQuery += noCuStrandQuery;
		if (qCopperKey != null && qCopperKey != "")
			basicQuery += cuQuery;
		if (qOdLabel != null && qOdLabel != "")
			basicQuery += odQuery;
		if (qMainColour != null && qMainColour != "")
			basicQuery += mainColorQuery;
		if (qInnerColor != null && qInnerColor != "")
			basicQuery += innerColorQuery;
		if (qCableStdKey != null && qCableStdKey != "")
			basicQuery += cableStdQuery;
		if (qLayLength != null && qLayLength != "")
			basicQuery += layLengthQuery;
		if (qLayType != null && qLayType != "")
			basicQuery += layTypeQuery;
		if (qProductKey != null && qProductKey != "")
			basicQuery += pdtQuery;
		if (qOrderAcceptanceDate != null && qOrderAcceptanceDate != "")
			basicQuery += orderAcceptanceDateQuery;
		if (qOrderAcceptanceDateTo != null && qOrderAcceptanceDate != "")
			basicQuery += orderAcceptanceDateQuery;

		basicQuery += dummySalesOrderQuery;
		if (qItemCode != null && qItemCode != "") {
			basicQuery += itemCodeQuery;
		}

		basicQuery += orderStatusQuery + reportTypeQuery + finalQuery;

		return em.createQuery(basicQuery).getResultList();
	}
	/*Method to check if the rates of salesorder items is null or not*/
	@Override
	@Transactional
	public List<SalesOrderItem> checkSoItemRates(String orderId) {
		return em.createQuery(
				" from SalesOrderItem o where o.orders.orderId='" + orderId
						+ "' and (o.rate is  null or o.rate=" + 0 + ")",
				SalesOrderItem.class).getResultList();
	}
	/*Method to fetch list of salesorder items based on order id and item code*/
	@Override
	@Transactional
	public List<SalesOrderItem> findByOrdersOrderIdItemsItemCode(
			String salesOrderId, String itemCode) {
		return orderDetailsRepository.findByOrdersOrderIdAndItemsItemCode(
				salesOrderId, itemCode);

	}
	/*Method to fetch JQGrid paged records of salesorder items based on default search*/
	@Override
	@Transactional
	public Page<SalesOrderItem> getPendingSalesOrderItems(int pageNumber,
			Integer rowsPerPage, String sortColName, String sortOrder) {
		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);
		return orderDetailsRepository
				.findByBalanceQtyGreaterThan(0.0, pageable);
	}
	/*Method to fetch list of salesorder items based on customerName,orderStatus,assortedType*/
	@Override
	@Transactional
	public List<SalesOrderItem> findByCustomerAssortedTypeStatusIn(
			String customerName, String assortedType, String[] orderStatus) {
		return orderDetailsRepository
				.findByOrdersCustomerCustomerNameAndItemsAssortedTypeAndOrdersOrderStatusStatusIn(
						customerName, assortedType, orderStatus);
	}
	/*Method to fetch list of salesorder items based on order Id*/
	@Override
	@Transactional
	public List<SalesOrderItem> findByOrderId(String orderId) {
		return orderDetailsRepository.findByOrdersOrderId(orderId);
	}
	/*Method to fetch JQGrid paged records of pending salesorder items based on orderStatus and reportType*/
	@Override
	@Transactional
	public Page<SalesOrderItem> getPendingSoItems(int pageNumber,
			Integer rowsPerPage, String sortColName, String sortOrder,
			String[] orderStatus, String reportType) {
		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);
		Double balQty = 0.0;
		Long customerId = (long) 1;
		String itemType = "";
		if (reportType.equalsIgnoreCase("Extrusion")) {
			itemType = "ITEM";
			
		} else if (reportType.equalsIgnoreCase("MWD")) {
			itemType = "Multiwire";

		} else if (reportType.equalsIgnoreCase("Bunching")) {
			itemType = "Bunching";
			}
		return orderDetailsRepository
				.findByItemsItemTypeAndBalanceQtyGreaterThanAndOrdersCustomerCustomerIdGreaterThanAndOrdersOrderStatusStatusIn(
						itemType, balQty, customerId, orderStatus, pageable);

	}
	/*Method to update quantity of salesorder items based on id,balance qty and workorder qty*/
	@Transactional
	@Override
	public Boolean updateBalQty(Long id, Double newBalanceQty, Double woQty) {
		Query q = em.createQuery(" Update  SalesOrderItem o SET o.balanceQty="
				+ newBalanceQty + " ,o.woQty=" + woQty
				+ " where o.orderDetailId=" + id);
		int updated = q.executeUpdate();
		if (updated == 1)
			return true;
		else
			return false;
	}
	/*Method to update prdn quantity of salesorder items based on id,newProductionQty and workorder qty*/
	@Transactional
	@Override
	public Boolean updatePdnQty(Long id, Double newProductionQty, Double woQty) {
		Query q = em
				.createQuery(" Update  SalesOrderItem o SET o.productionQty="
						+ newProductionQty + " ,o.woQty=" + woQty
						+ " where o.orderDetailId=" + id);
		int updated = q.executeUpdate();
		if (updated == 1)
			return true;
		else
			return false;
	}
	/*Method to fetch prdn quantity of salesorder items based on customerName and item code*/
	@Override
	@Transactional
	public Double fetchPdnQty(Long customerId, String itemCode) {
		Query queryresult = em
				.createQuery(" select sum(o.productionQty),o.itemCode from SalesOrderItem o where o.itemCode='"
						+ itemCode
						+ "' and o.orders.customer.customerId="
						+ customerId );
		Object[] qtyResult = (Object[]) queryresult.getSingleResult();
		return (Double) qtyResult[0];
	}	/*Method to fetch prdn quantity of salesorder items based on customerName and item code*/
	@Override
	@Transactional
	public Double fetchItemPdnQty(Long customerId, String itemCode) {
		Query queryresult = em
				.createQuery(" select sum(o.productionQty),o.itemCode from SalesOrderItem o where o.itemCode='"
						+ itemCode
						+ "' and o.orders.customer.customerId!="+ customerId );
		Object[] qtyResult = (Object[]) queryresult.getSingleResult();
		return (Double) qtyResult[0];
	}	/*Method to delete salesorder items based on sales order item id*/
	@Override
	@Transactional
	public Boolean delete(Long soItemId) {
		orderDetailsRepository.delete(soItemId);
		return true;
	}
	/*Method to update balance quantity items based on sales order item id*/
	@Transactional
	@Override
	public Boolean updateBalPdnQty(Long salesOrderItemId, Double totalQty,
			Double newBalQty, Double newPdnQty) {
		Query q = em
				.createQuery(" Update  SalesOrderItem o SET o.productionQty="
						+ newPdnQty + " ,o.balanceQty=" + newBalQty
						+ " ,o.quantity=" + totalQty
						+ "  where o.orderDetailId=" + salesOrderItemId);
		int updated = q.executeUpdate();
		if (updated == 1)
			return true;
		else
			return false;
	}
	/*Method to fetch JQGrid paged records of salesorder items based on order status*/
	@Override
	@Transactional
	public Page<SalesOrderItem> getSoItemPendingReport(int pageNumber,
			Integer rowsPerPage, String sortColName, String sortOrder,
			String[] orderStatus) {
		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);
		Double balQty = 0.0;
		Long customerId = (long) 1;
		return orderDetailsRepository
				.findByOrdersOrderStatusStatusInAndOrdersCustomerCustomerIdGreaterThanAndBalanceQtyGreaterThan(
						orderStatus, customerId, balQty, pageable);

	}
	/*Method to fetch JQGrid paged records of salesorder items based on order id and item type*/
	@Override
	@Transactional
	public Page<SalesOrderItem> getSoItemAssortedType(String orderId,
			int pageNumber, Integer rowsPerPage, String sortColName,
			String sortOrder, String itemType) {
		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);
		return orderDetailsRepository.findByOrdersOrderIdAndItemsAssortedType(
				orderId, itemType, pageable);
	}
    /*Method to fetch salesorder items based on item code*/
	@Override
	@Transactional
	public List<SalesOrderItem> findByItemCode(String itemCode) {
		return orderDetailsRepository.findByItemCode(itemCode);
	}
	/*Method to fetch salesorder items based on item code and customer Id*/
	@Override
	@Transactional
	public List<SalesOrderItem> findByItemCodeAndCustomerId(String itemCode,
			Long customerId) {
		return orderDetailsRepository
				.findByItemCodeAndOrdersCustomerCustomerId(itemCode, customerId);
	}
	/*Method to fetch salesorder items based on customer Id item type and status*/
	@Override
	@Transactional
	public List<SalesOrderItem> finddByCustomerIdAndScrapItem(Long customerId,
			String itemType, String status) {
		return orderDetailsRepository
				.findByItemsItemTypeAndOrdersCustomerCustomerIdAndOrdersOrderStatusStatus(
						itemType, customerId, status);
	}
	/*Method to fetch salesorder items based on item Id*/
	@Override
	@Transactional
	public List<SalesOrderItem> findByItemsItemId(Long itemIdToDelete) {
		// TODO Auto-generated method stub
		return orderDetailsRepository.findByItemsItemId(itemIdToDelete);
	}
	/*Method to fetch salesorder items based on item type,order status and balance qty greater than 0*/
	@Override
	@Transactional
	public List<SalesOrderItem> findByItemsItemTypeAndOrderStatusInAndBalanceQtyGreaterThan(
			String itemType, String[] orderStatus) {
		Double balQty = 0.0;
		return orderDetailsRepository
				.findByItemsItemTypeAndOrdersOrderStatusStatusInAndBalanceQtyGreaterThan(
						itemType, orderStatus, balQty);
	}
	/*Method to fetch salesorder items based on customer Id,item type,order status and balance qty greater than 0*/
	@Override
	@Transactional
	public List<SalesOrderItem> findByCustomerIdAndItemsItemTypeAndOrderStatusInAndBalanceQtyGreaterThan(
			Long customerId, String itemType, String[] orderStatus) {
		Double balQty = 0.0;
		return orderDetailsRepository
				.findByOrdersCustomerCustomerIdAndItemsItemTypeAndOrdersOrderStatusStatusInAndBalanceQtyGreaterThan(
						customerId, itemType, orderStatus, balQty);
	}
	/*Method to fetch salesorder items based on order status and balance qty greater than 0*/
	@Override
	@Transactional
	public List<SalesOrderItem> findByOrderStatusInAndBalanceQtyGreaterThan(
			String[] orderStatus) {
		Double balQty = 0.0;
		return orderDetailsRepository
				.findByOrdersOrderStatusStatusInAndBalanceQtyGreaterThan(
						orderStatus, balQty);
	}
	/*Method to fetch salesorder items based on customer Id,order status and balance qty greater than 0*/
	@Override
	@Transactional	
	public List<SalesOrderItem> findByCustomerIdAndOrderStatusInAndBalanceQtyGreaterThan(
			Long customerId, String[] orderStatus) {
		Double balQty = 0.0;
		return orderDetailsRepository
				.findByOrdersCustomerCustomerIdAndOrdersOrderStatusStatusInAndBalanceQtyGreaterThan(
						customerId, orderStatus, balQty);
	}
	
	/*Method to fetch salesorder items based on customer Id,order status and stock out pending*/
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<SalesOrderItem> findByOrderStatusInAndStockOutQtyPending(
			String orderStatus,String sortColName, String sortOrder) {
		String basicQuery = " from SalesOrderItem o where o.orders.orderStatus.status IN "+orderStatus+
				       " and o.quantity>o.dispatchedQty and o.orders.customer.customerId!=1 order by "+sortColName+" "+sortOrder;
		return em.createQuery(basicQuery).getResultList();
	}
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<SalesOrderItem> fetchByPendingStockOutSearch(String qOrderId,
			Long qCustomerId, Integer qNumberOfCopperStrands,
			String qCopperKey, String qOdLabel, String qMainColour,
			String qInnerColor, String qCableStdKey, String qLayLength,
			String qLayType, String qProductKey, String qItemCode,
			String qOrderAcceptanceDate, String qOrderAcceptanceDateTo, int pagenumber,
			Integer rows, String sortColName, String sortOrder) {
		String basicQuery = "from SalesOrderItem o where o.quantity>o.dispatchedQty and ";
		String orderIdQuery = " o.orders.orderId like '%" + qOrderId+ "%' and ";
		String customerQuery = "  o.orders.customer.customerId =" + qCustomerId+ " and  ";
		String noCuStrandQuery = " o.items.numberOfCopperStrands="+ qNumberOfCopperStrands + " and ";
		String cuQuery = " o.items.copperStrandDiameter.copperkey like '%"+ qCopperKey + "%' and   ";
		String odQuery = " o.items.odLabel='" + qOdLabel + "' and  ";
		String mainColorQuery = " o.items.mainColour.color like '%"	+ qMainColour + "%' and ";
		String innerColorQuery = " o.items.innerColour.color like '%"+ qInnerColor + "%' and ";
		String cableStdQuery = " o.items.cableStdPvc.cableStdKey like '%"+ qCableStdKey + "%' and  ";
		String layLengthQuery = " o.items.layLength=" + qLayLength + " and ";
		String layTypeQuery = " o.items.layType='" + qLayType + "' and  ";
		String pdtQuery = " o.items.productType.productKey like '%"+ qProductKey + "%' and ";
		String itemCodeQuery = " o.items.itemCode like '% " + qItemCode+ "%' and ";
		String orderAcceptanceDateQuery = " o.orders.orderAcceptanceDate between '"
		+ qOrderAcceptanceDate+ "' and '"+ qOrderAcceptanceDateTo+ "' and ";
		String dummySalesOrderQuery = " o.orders.customer.customerId!=1 and ";
		String orderStatusQuery = " o.orders.orderStatus.status  IN ('Approved For Prodn','Approved')   ";
       String finalSortQuery=" order by "+sortColName+" "+sortOrder;


		if (qOrderId != null && qOrderId != "")
			basicQuery += orderIdQuery;
		if (qCustomerId != 0)
			basicQuery += customerQuery;
		if (qNumberOfCopperStrands != 0)
			basicQuery += noCuStrandQuery;
		if (qCopperKey != null && qCopperKey != "")
			basicQuery += cuQuery;
		if (qOdLabel != null && qOdLabel != "")
			basicQuery += odQuery;
		if (qMainColour != null && qMainColour != "")
			basicQuery += mainColorQuery;
		if (qInnerColor != null && qInnerColor != "")
			basicQuery += innerColorQuery;
		if (qCableStdKey != null && qCableStdKey != "")
			basicQuery += cableStdQuery;
		if (qLayLength != null && qLayLength != "")
			basicQuery += layLengthQuery;
		if (qLayType != null && qLayType != "")
			basicQuery += layTypeQuery;
		if (qProductKey != null && qProductKey != "")
			basicQuery += pdtQuery;
		if (qOrderAcceptanceDate != null && qOrderAcceptanceDate != "")
			basicQuery += orderAcceptanceDateQuery;
		if (qOrderAcceptanceDateTo != null && qOrderAcceptanceDate != "")
			basicQuery += orderAcceptanceDateQuery;

		//basicQuery += dummySalesOrderQuery;
		if (qItemCode != null && qItemCode != "") {
			basicQuery += itemCodeQuery;
		}

		basicQuery += dummySalesOrderQuery+orderStatusQuery;
		basicQuery += finalSortQuery;
		return em.createQuery(basicQuery).getResultList();

	}
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<SalesOrderItem> findByCustomerIdAndOrderStatusInAndQuantityGreaterThanDispatchedQty(
			Long customerId, String orderStatus) {
	String basicQuery = " from SalesOrderItem o where o.orders.orderStatus.status IN "+orderStatus+
			       " and o.quantity>o.dispatchedQty and o.orders.customer.customerId="+customerId;
	return em.createQuery(basicQuery).getResultList();
	}
	@Override
	public List<SalesOrderItem> findByScrapItem(String itemType, String status) {
		return orderDetailsRepository
				.findByItemsItemTypeAndOrdersOrderStatusStatus(
						itemType,status);
	}
	
}
