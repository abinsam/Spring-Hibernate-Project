package org.balajicables.salesmanager.service.impl;

import java.util.Date;
import java.util.List;
import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import org.balajicables.salesmanager.model.Customer;
import org.balajicables.salesmanager.model.OrderStatus;
import org.balajicables.salesmanager.model.SalesOrder;
import org.balajicables.salesmanager.repository.OrderRepository;
import org.balajicables.salesmanager.repository.OrderStatusRepository;
import org.balajicables.salesmanager.service.OrderService;
import org.balajicables.salesmanager.utils.JPAUtility;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
/**
 * This class demonstrates the implementation of the Order service methods
 * 
 * @author Abin Sam
 */
@Service
public class OrderServiceImpl implements OrderService {

	@Resource
	OrderRepository orderRepository;

	@Resource
	OrderStatusRepository statusRepository;

	@PersistenceContext
	private EntityManager em;

	/*Method to fetch list of salesorder based on customer*/
	@Transactional(readOnly = true)
	@Override
	public List<SalesOrder> findByCustomer(Customer customer) {
		return orderRepository.findByCustomer(customer);
	}
	/*Method to create and save salesorder*/
	@Override
	@Transactional
	public SalesOrder create(SalesOrder order11) {
		return orderRepository.save(order11);
	}
	/*Method to update and save salesorder*/
	@Override
	@Transactional
	public Boolean update(SalesOrder order) {
		SalesOrder saved = orderRepository.save(order);
		if (saved == null) {
			return false;
		}//end of if (saved == null) condition
		return true;
	}
	/*Method to delete salesorder*/
	@Override
	@Transactional
	public Boolean delete(String orderIdToDelete) {
		Query q = em
				.createQuery(" Update SalesOrder o SET o.orderStatus.orderStatusId=6 where o.orderId='"
						+ orderIdToDelete + "'");

		int updated = q.executeUpdate();
		if (updated == 1)
			return true;
		else
			return false;

	}
	/*Method to fetch JQGrid paged records of salesorder based on customerId*/
	@Override
	@Transactional
	public Page<SalesOrder> getPagedOrders(long customerId, int pageNumber,
			Integer rowsPerPage, String sortColName, String sortOrder) {
		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);
		Customer customer = new Customer();
		customer.setCustomerId(customerId);
		return orderRepository.findByCustomer(customer, pageable);
	}
	/*Method to fetch JQGrid paged records of salesorder based on customerId*/
	@Override
	@Transactional
	public SalesOrder findByIdWithCustomer(String id) {
		return orderRepository.findOneWithCustomerLoaded(id);
	}
    /*Method to find all salesorder*/
	@Override
	@Transactional
	public List<SalesOrder> findAll() {
		return orderRepository.findAll();
	}
	/*Method to fetch latest salesorder*/
	@Override
	@Transactional
	public List<SalesOrder> fetchLatestSalesOrder() {
		return em.createQuery(
				"from SalesOrder o order by o.createdTime desc limit 1",
				SalesOrder.class).getResultList();
	}
	/*Method to fetch order status based on status id*/
	@Override
	@Transactional
	public List<OrderStatus> fetchStatusId(String status) {
		return statusRepository.findByStatus(status);
	}
	/*Method to update salesorder status based on order id*/
	@Transactional
	@Override
	public Boolean updateSoStatus(String orderId) {
		Query q = em
				.createQuery(" Update SalesOrder o SET o.orderStatus.orderStatusId=1 where o.orderId='"
						+ orderId + "'");

		int updated = q.executeUpdate();
		if (updated == 1)
			return true;
		else
			return false;
	}
	/*Method to update salesorder status based on order id and order status id*/
	@Transactional
	@Override
	public Boolean updateOrderStatus(String orderId, int orderStatusId) {
		Query q = em
				.createQuery(" Update SalesOrder o SET o.orderStatus.orderStatusId="
						+ orderStatusId + " where o.orderId='" + orderId + "'");
		int updated = q.executeUpdate();
		if (updated == 1)
			return true;
		else
			return false;
	}
	/*Method to fetch JQGrid paged records of salesorders based on order status*/
	@Override
	@Transactional
	public Page<SalesOrder> getSearchSalesOrder(String orderStatus,
			int pageNumber, Integer rowsPerPage, String sortColName,
			String sortOrder) {
		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);
		return orderRepository.findByOrderStatusStatus(orderStatus, pageable);
	}
	/*Method to fetch list of salesorders based on salesOrderId*/
	@Override
	@Transactional
	public List<SalesOrder> findBySalesOrderNoId(String salesOrderId) {
		return orderRepository.findByOrderId(salesOrderId);
	}
	/*Method to fetch list of salesorders based on customerId*/
	@Override
	@Transactional
	public List<SalesOrder> findByCustomerId(Long customerId) {
		return orderRepository.findByCustomerCustomerId(customerId);
	}
	/*Method to fetch JQGrid paged records of salesorders based on fromDate,toDate,status*/
	@Override
	@Transactional
	public Page<SalesOrder> getSalesOrderReport(Date fromDate, Date toDate,
			String status, int pageNumber, Integer rowsPerPage,
			String sortColName, String sortOrder) {
		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);
		return orderRepository
				.findByOrderAcceptanceDateBetweenAndOrderStatusStatusNotIn(
						fromDate, toDate, status, pageable);

	}
	/*Method to fetch JQGrid paged records of salesorders based on fromDate,toDate,status*/
	@Override
	@Transactional
	public Page<SalesOrder> getSalesOrderReportWithStatus(Date fromDate,
			Date toDate, String status, int pageNumber, Integer rowsPerPage,
			String sortColName, String sortOrder) {
		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);
		return orderRepository
				.findByOrderStatusStatusAndOrderAcceptanceDateBetween(status,
						fromDate, toDate, pageable);

	}
    /*Method to fetch list of salesorder based on order status*/
	@Override
	public List<SalesOrder> findByOrderStatusStatus(String status) {
		return orderRepository.findByOrderStatusStatus(status);
	}
	/*Method to fetch list of salesorder based on status,month and year of creation*/
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<SalesOrder> getPagedSalesOrder(String orderStatus, int month,
			int year, int pagenumber, Integer rows, String sortColName,
			String sortOrder) {
		String basicQuery = " from SalesOrder o where MONTH(o.createdTime)="
				+ month + " and YEAR(o.createdTime)=" + year
				+ " and o.orderStatus.status='" + orderStatus + "' order by "
				+ sortColName + " " + sortOrder;
		return em.createQuery(basicQuery).getResultList();

	}
	/*Method to fetch JQGrid paged records of salesorders based on customerId,salesOrderStatus*/
	@Override
	@Transactional
	public Page<SalesOrder> getPagedCustomerPendingSalesorders(long customerId,
			String[] salesOrderStatus, int pageNumber, Integer rowsPerPage,
			String sortColName, String sortOrder) {
		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);
		return orderRepository.findByCustomerCustomerIdAndOrderStatusStatusIn(
				customerId, salesOrderStatus, pageable);
	}
	
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<SalesOrder> fetchBySearch(Long qCustomerId,
			String qStatus, int month,int year,int pagenumber, Integer rows, String sortColName,
			String sortOrder) {
		
		String basicQuery = " from SalesOrder o where ";
		String customerQuery = "  o.customer.customerId = " + qCustomerId + " and  ";
		String statusQuery = " o.orderStatus.status='" + qStatus + "' and ";
		String monthYearQuery = "  MONTH(o.createdTime)="+ month + " and YEAR(o.createdTime)=" + year;
		String finalQuery = " order by  o."	+ sortColName + " " + sortOrder;
		if (qCustomerId != null)
			basicQuery += customerQuery;
		if (qStatus != null && qStatus != "")
			basicQuery += statusQuery;
		if (month!=0 && year!=0)
			basicQuery += monthYearQuery;
		basicQuery += finalQuery;
		return em.createQuery(basicQuery).getResultList();
	}
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<SalesOrder> getAllSalesOrder(int month, int year, int i,
			Integer rows, String sortColName, String sortOrder) {
		String basicQuery = " from SalesOrder o where MONTH(o.createdTime)="
				+ month + " and YEAR(o.createdTime)=" + year + "order by "
				+ sortColName + " " + sortOrder;
		return em.createQuery(basicQuery).getResultList();
	}
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<SalesOrder> findSalesOrderByMonthYear(int monthValue,
			int yearValue) {
		String basicQuery = " from SalesOrder o where MONTH(o.createdTime)="
				+ monthValue + " and YEAR(o.createdTime)=" + yearValue
				+ " ";

		return em.createQuery(basicQuery).getResultList();
	}
	
}
