package org.balajicables.salesmanager.service.impl;

import java.util.List;
import javax.annotation.Resource;
import org.balajicables.salesmanager.model.OrderStatus;
import org.balajicables.salesmanager.repository.OrderStatusRepository;
import org.balajicables.salesmanager.service.OrderStatusService;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
/**
 * This class demonstrates the implementation of the OrderStatus service methods
 * 
 * @author Abin Sam
 */
@Service
public class OrderStatusServiceImpl implements OrderStatusService {
	
	@Resource
	private OrderStatusRepository orderStatusRepository;

	/*Method to find all order status*/
	@Override
	@Transactional
	public List<OrderStatus> findAll() {
		return orderStatusRepository.findAll();
	}
	/*Method to find order status*/
	@Override
	@Transactional
	public List<OrderStatus> findByStatus(String string) {

		return orderStatusRepository.findByStatus(string);
	}

}
