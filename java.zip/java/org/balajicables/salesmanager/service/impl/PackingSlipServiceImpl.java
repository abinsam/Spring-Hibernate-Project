package org.balajicables.salesmanager.service.impl;

import java.util.List;
import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.balajicables.salesmanager.model.PackingSlip;
import org.balajicables.salesmanager.repository.PackingSlipRepository;
import org.balajicables.salesmanager.service.PackingSlipService;
import org.balajicables.salesmanager.utils.JPAUtility;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
/**
 * This class demonstrates the implementation of the PackingSlip service methods
 * 
 * @author Abin Sam
 */
@Service
public class PackingSlipServiceImpl implements PackingSlipService {

	@PersistenceContext
	private EntityManager em;

	@Resource
	PackingSlipRepository packingSlipRepository;

	/*Method to fetch JQGrid paged records of all packing slips based on default search*/
	@Override
	@Transactional
	public Page<PackingSlip> findAll(int pageNumber, Integer rowsPerPage,
			String sortColName, String sortOrder) {
		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);
		return packingSlipRepository.findAll(pageable);
	}
	/*Method to fetch JQGrid paged records of all packing slips based on deliver challan number*/
	@Override
	@Transactional
	public Page<PackingSlip> getPagedPackingSlipDetails(
			String deliveryChallanNo, int pageNumber, Integer rowsPerPage,
			String sortColName, String sortOrder) {
		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);
		return packingSlipRepository.findByDeliveryChallanDeliveryChallanNo(
				deliveryChallanNo, pageable);
	}
    /*Method to create and save packing slip*/
	@Override
	@Transactional
	public PackingSlip create(PackingSlip packingSlip) {
		return packingSlipRepository.save(packingSlip);
	}
	/*Method to fetch list of packing slips based on delivery challan number*/
	@Override
	@Transactional
	public List<PackingSlip> findByDeliveryChallanNo(String deliveryChallanNo) {
		return packingSlipRepository
				.findByDeliveryChallanDeliveryChallanNo(deliveryChallanNo);
	}
	/*Method to fetch count of packing slips based on delivery challan number*/
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<PackingSlip> findPackingSlipCount(String deliveryChallanNo) {
		String basicQuery = " select Distinct(o.packingSlipNo) from PackingSlip o where o.deliveryChallans.deliveryChallanNo='"
				+ deliveryChallanNo + "'";
		return em.createQuery(basicQuery).getResultList();
	}
	/*Method to delete packing slips based on packing slip id*/
	@Override
	@Transactional
	public Boolean delete(Integer packingSlipId) {
		packingSlipRepository.delete(packingSlipId);
		return true;
	}
}
