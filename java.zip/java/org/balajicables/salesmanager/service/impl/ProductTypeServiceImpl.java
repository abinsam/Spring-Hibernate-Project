package org.balajicables.salesmanager.service.impl;

import java.util.List;
import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.balajicables.salesmanager.model.ProductType;
import org.balajicables.salesmanager.repository.ProductTypeRepository;
import org.balajicables.salesmanager.service.ProductTypeService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
/**
 * This class demonstrates the implementation of the ProductType service methods
 * 
 * @author Abin Sam
 */
@Service
public class ProductTypeServiceImpl implements ProductTypeService {

	@PersistenceContext
	private EntityManager em;
	@Resource
	ProductTypeRepository productTypeRepository;

	/*Method to find product types based on process types*/
	@Override
	@Transactional
	public List<ProductType> findByProcessType(String processType) {
		return productTypeRepository.findByProcessType(processType);
	}
	/*Method to find product types based on process types*/
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<String> findProductTypeByProcessType(String processType) {
		return em.createQuery(
				"Select i.productType from ProductType i where i.processType='"
						+ processType + "'").getResultList();
	}
	/*Method to find all product types*/
	@Override
	@Transactional
	public List<ProductType> findAll() {
		return productTypeRepository.findAll();
	}

}
