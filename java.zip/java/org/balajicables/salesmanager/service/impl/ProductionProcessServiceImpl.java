package org.balajicables.salesmanager.service.impl;

import java.util.List;
import javax.annotation.Resource;
import org.balajicables.salesmanager.model.ProductionProcess;
import org.balajicables.salesmanager.repository.ProductionProcessRepository;
import org.balajicables.salesmanager.service.ProductionProcessService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
/**
 * This class demonstrates the implementation of the ProductionProcess service methods
 * 
 * @author Abin Sam
 */
@Service
public class ProductionProcessServiceImpl implements ProductionProcessService {

	@Resource
	private ProductionProcessRepository productionProcessRepository;

	/*Method to find all processes*/
	@Override
	@Transactional
	public List<ProductionProcess> getAllProcesses() {
		return productionProcessRepository.findAll();
	}
	/*Method to find all process based on process type*/
	@Override
	@Transactional
	public List<ProductionProcess> findByProcessType(String processType) {
		return productionProcessRepository.findByProcessType(processType);
	}

}
