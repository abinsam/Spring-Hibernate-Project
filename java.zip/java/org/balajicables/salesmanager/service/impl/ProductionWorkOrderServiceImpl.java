package org.balajicables.salesmanager.service.impl;

import java.util.List;
import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import org.balajicables.salesmanager.model.ProductionWorkOrder;
import org.balajicables.salesmanager.repository.ProductionWorkOrderRepository;
import org.balajicables.salesmanager.service.ProductionWorkOrderService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
/**
 * This class demonstrates the implementation of the ProductionWorkOrder service methods
 * 
 * @author Abin Sam
 */
@Service
public class ProductionWorkOrderServiceImpl implements ProductionWorkOrderService {

	@Resource
	private ProductionWorkOrderRepository productionWorkOrderRepository;

	@PersistenceContext
	private EntityManager em;

	/*Method to fetch latest workorder from production based on process type*/
	@Override
	@Transactional
	public List<ProductionWorkOrder> fetchLatestWorkOrder(String processType) {
		return em.createQuery(
				"from ProductionWorkOrder o where o.process.processType='"
						+ processType
						+ "'  order by o.createdTime desc limit 1 ",
				ProductionWorkOrder.class).getResultList();

	}
	/*Method to create and save production workorder*/
	@Override
	@Transactional
	public ProductionWorkOrder create(ProductionWorkOrder prdnWorkOrder) {
		return productionWorkOrderRepository.save(prdnWorkOrder);
	}
	/*Method to fetch list of production workorder based on process type,month and year of creation*/
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<ProductionWorkOrder> findByProcessType(String processType,
			int month, int year) {
		String basicQuery = " from ProductionWorkOrder o where o.process.processType='"
				+ processType
				+ "' and  MONTH(o.createdTime)="
				+ month
				+ " and YEAR(o.createdTime)=" + year + " ";
		return em.createQuery(basicQuery).getResultList();
	}
	/*Method to fetch list of production workorder*/
	@Override
	@Transactional
	public List<ProductionWorkOrder> findByProductionWorkOrderNo(
			String workOrderNo) {
		return productionWorkOrderRepository.findByWorkOrderNo(workOrderNo);
	}
	/*Method to update workorder item weights of production workorders*/
	@Override
	@Transactional
	public Boolean updateWorkOrderWeight(String newWorkOrderNo,
			Double inputWeight, Double outputWeight, Double balanceWeight) {
		Query q = em
				.createQuery(" Update  ProductionWorkOrder o SET o.inputWeight="
						+ inputWeight
						+ ",o.outputWeight="
						+ outputWeight
						+ ",o.balanceWeight="
						+ balanceWeight
						+ " where o.workOrderNo='" + newWorkOrderNo + "'");
		int updated = q.executeUpdate();
		if (updated == 1)
			return true;
		else
			return false;
	}
	/*Method to update workorder status*/
	@Override
	@Transactional
	public Boolean updateWorkOrderStatus(String workOrderNo, String updateStatus) {
		Query q = em
				.createQuery(" Update  ProductionWorkOrder o SET o.status='"
						+ updateStatus + "' where o.workOrderNo='"
						+ workOrderNo + "'");
		int updated = q.executeUpdate();
		if (updated == 1)
			return true;
		else
			return false;
	}
	/*Method to update workorder status*/
	@Override
	@Transactional
	public Boolean updateStatus(String workOrderNo) {
		Query q = em
				.createQuery(" Update ProductionWorkOrder o SET o.status='Submitted' where o.workOrderNo='"
						+ workOrderNo + "'");
		int updated = q.executeUpdate();
		if (updated == 1)
			return true;
		else
			return false;

	}
	/*Method to fetch all workorder*/
	@Override
	@Transactional
	public List<ProductionWorkOrder> findAll() {
		return productionWorkOrderRepository.findAll();
	}
	/*Method to update production workorder*/
	@Override
	@Transactional
	public Boolean update(ProductionWorkOrder pdnWorkOrder) {
		ProductionWorkOrder saved = productionWorkOrderRepository
				.save(pdnWorkOrder);
		if (saved == null) {
			return false;
		}
			return true;
	}
	/*Method to fetch list of production workorder based on process type and status*/
	@Override
	@Transactional
	public List<ProductionWorkOrder> findByProcessTypeAndStatus(
			String processType, String status) {

		return productionWorkOrderRepository.findByProcessProcessTypeAndStatus(
				processType, status);
	}
	/*Method to fetch list of production workorder based on process type,status,month and year of creation*/
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<ProductionWorkOrder> findByProcessTypeAndStatusAndMonthYear(
			String processType, String status, int month, int year) {
		String basicQuery = " from ProductionWorkOrder o where MONTH(o.createdTime)="
				+ month
				+ " and YEAR(o.createdTime)="
				+ year
				+ " and o.status='"
				+ status
				+ "' and o.process.processType='"
				+ processType + "'";

		return em.createQuery(basicQuery).getResultList();
	}
	/*Method to fetch list of production workorder based on process type,status,month and year of creation*/
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<ProductionWorkOrder> findByProcessTypeAndMonthYear(
			String processType, int month, int year) {
		String basicQuery = " from ProductionWorkOrder o where MONTH(o.createdTime)="
				+ month
				+ " and YEAR(o.createdTime)="
				+ year
				+ " and o.process.processType='" + processType + "'";

		return em.createQuery(basicQuery).getResultList();
	}
	/*Method to fetch list of production workorder based on process type*/
	@Override
	@Transactional
	public List<ProductionWorkOrder> findByProcess(String processType) {
		return productionWorkOrderRepository
				.findByProcessProcessType(processType);
	}

}
