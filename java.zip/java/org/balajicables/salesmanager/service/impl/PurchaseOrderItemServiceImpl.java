package org.balajicables.salesmanager.service.impl;

import java.util.List;
import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.balajicables.salesmanager.model.PurchaseOrderItem;
import org.balajicables.salesmanager.repository.PurchaseOrderItemRepository;
import org.balajicables.salesmanager.service.PurchaseOrderItemService;
import org.balajicables.salesmanager.utils.JPAUtility;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
/**
 * This class demonstrates the implementation of the PurchaseOrderItem service methods
 * 
 * @author Abin Sam
 */
@Service
public class PurchaseOrderItemServiceImpl implements PurchaseOrderItemService {

	@PersistenceContext
	private EntityManager em;

	@Resource
	PurchaseOrderItemRepository purchaseOrderItemRepository;

	/*Method to create and save purchase order items*/
	@Override
	@Transactional
	public PurchaseOrderItem create(PurchaseOrderItem poItemDetail) {
		return purchaseOrderItemRepository.save(poItemDetail);
	}
	/*Method to update and save purchase order items*/
	@Override
	@Transactional
	public Boolean update(PurchaseOrderItem purchaseOrderItem) {
		PurchaseOrderItem saved = purchaseOrderItemRepository
				.save(purchaseOrderItem);
		if (saved == null) {
			return false;
		}//end of if (saved == null) condition
		return true;
	}
	/*Method to delete purchase order items*/
	@Override
	@Transactional
	public Boolean delete(Long poItemToDelete) {

		purchaseOrderItemRepository.delete(poItemToDelete);

		return true;
	}
	/*Method to fetch JQGrid paged records of purchase order items based on PO number*/
	@Override
	@Transactional
	public Page<PurchaseOrderItem> getPagedPurchaseOrderItems(String poNo,
			int pageNumber, Integer rowsPerPage, String sortColName,
			String sortOrder) {
		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);

		return purchaseOrderItemRepository.findByPurchaseOrderPoNo(poNo,
				pageable);

	}
	/*Method to fetch PO item list based on PO number and item code*/
	@Override
	@Transactional
	public List<PurchaseOrderItem> findByPoNoItemId(String poNo, String itemCode) {
		return em.createQuery(
				" from PurchaseOrderItem o where o.purchaseOrder.poNo='" + poNo
						+ "' and o.item.itemCode='" + itemCode + "'",
				PurchaseOrderItem.class).getResultList();

	}
    /*Method to check prices of item based on PO number*/
	@Override
	@Transactional
	public List<PurchaseOrderItem> checkPrice(String poNo) {
		return em.createQuery(
				" from PurchaseOrderItem o where o.purchaseOrder.poNo='" + poNo
						+ "' and ( o.price is  null or o.price=0) ",
				PurchaseOrderItem.class).getResultList();
	}
	/*Method to fetch PO item list based on PO number*/
	@Override
	@Transactional
	public List<PurchaseOrderItem> findByPoNo(String poNo) {
		return purchaseOrderItemRepository.findByPurchaseOrderPoNo(poNo);
	}
	/*Method to fetch JQGrid paged records of PO items based on PO number*/
	@Override
	@Transactional
	public Page<PurchaseOrderItem> getPagedPurchaseOrderItemsByStatus(
			String poNo, int pageNumber, Integer rowsPerPage,
			String sortColName, String sortOrder) {
		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);
		int status = 0;
		return purchaseOrderItemRepository.findByPurchaseOrderPoNoAndStatus(
				poNo, status, pageable);

	}
	/*Method to find PO item by PO item id*/
	@Override
	@Transactional
	public List<PurchaseOrderItem> findByPoItemId(Long id) {
		return purchaseOrderItemRepository.findByPurchaseOrderItemId(id);

	}
	/*Method to find PO item by PO status*/
	@Override
	@Transactional
	public List<PurchaseOrderItem> findByPoNoStatus(String poNoStatus) {
		// TODO Auto-generated method stub
		return purchaseOrderItemRepository
				.findByPurchaseOrderPoStatus(poNoStatus);
	}
    /*Method to find PO item by PO item id*/
	@Override
	@Transactional
	public List<PurchaseOrderItem> findByItemItemId(Long itemIdToDelete) {
		// TODO Auto-generated method stub
		return purchaseOrderItemRepository.findByItemItemId(itemIdToDelete);
	}

}
