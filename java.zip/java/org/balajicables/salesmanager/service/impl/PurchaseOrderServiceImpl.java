package org.balajicables.salesmanager.service.impl;

import java.util.Date;
import java.util.List;
import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import org.balajicables.salesmanager.model.PurchaseOrder;
import org.balajicables.salesmanager.repository.PurchaseOrderRepository;
import org.balajicables.salesmanager.service.PurchaseOrderService;
import org.balajicables.salesmanager.utils.JPAUtility;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
/**
 * This class demonstrates the implementation of the PurchaseOrder service methods
 * 
 * @author Abin Sam
 */
@Service
public class PurchaseOrderServiceImpl implements PurchaseOrderService {

	@Resource
	PurchaseOrderRepository purchaseOrderRepository;
	
	@PersistenceContext
	private EntityManager em;

	/*Method to fetch JQGrid paged records of purchase orders based on customer id*/
	@Override
	@Transactional
	public Page<PurchaseOrder> getPagedOrders(long customerId, int pageNumber,
			Integer rowsPerPage, String sortColName, String sortOrder) {
		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);
		return purchaseOrderRepository.findByCustomerCustomerId(customerId,
				pageable);
	}
	/*Method to fetch latest PO number*/
	@Override
	@Transactional
	public List<PurchaseOrder> fetchLatestPO() {
		return em.createQuery(
				"from PurchaseOrder o order by o.createdTime desc limit 1",
				PurchaseOrder.class).getResultList();
	}
	/*Method to create and save purchase order*/
	@Override
	@Transactional
	public PurchaseOrder create(PurchaseOrder purchaseorder) {
		return purchaseOrderRepository.save(purchaseorder);
	}
	/*Method to update and save purchase order*/
	@Override
	@Transactional
	public Boolean update(PurchaseOrder purchaseOrder) {
		PurchaseOrder saved = purchaseOrderRepository.save(purchaseOrder);
		if (saved == null) {
			return false;
		}
		return true;
	}
	/*Method to delete purchase order*/
	@Override
	@Transactional
	public Boolean delete(String poToDelete) {
		purchaseOrderRepository.delete(poToDelete);
		return true;
	}
	/*Method to fetch list of purchase order*/
	@Override
	@Transactional
	public PurchaseOrder findByIdWithCustomer(String poNo) {
		return purchaseOrderRepository.findOneWithCustomerLoaded(poNo);
	}
	/*Method to fetch list of purchase order based on customer Id*/
	@Override
	@Transactional
	public List<PurchaseOrder> findByCustId(Long customerId) {
		return purchaseOrderRepository.findByCustomerCustomerId(customerId);
	}
	/*Method to update purchase order status*/
	@Transactional
	@Override
	public Boolean updatePoStatusCompleted(String poNo) {

		Query q = em
				.createQuery(" Update  PurchaseOrder o SET o.poStatus='Completed'  where o.poNo='"
						+ poNo + "'");
		int updated = q.executeUpdate();
		if (updated == 1)
			return true;
		else
			return false;

	}
	/*Method to fetch all purchase order*/
	@Override
	@Transactional
	public List<PurchaseOrder> findAll() {
		return purchaseOrderRepository.findAll();
	}
	/*Method to fetch purchase order*/
	@Override
	@Transactional
	public List<PurchaseOrder> findByPoNo(String poNo) {
		return purchaseOrderRepository.findByPoNo(poNo);
	}
	/*Method to fetch list of purchase order based on customerId and PO status*/
	@Override
	@Transactional
	public List<PurchaseOrder> findByCustIdAndPurchaseOrderStatus(
			Long customerId, String poStatus) {
		return purchaseOrderRepository.findByCustomerCustomerIdAndPoStatus(
				customerId, poStatus);
	}
	/*Method to fetch JQGrid paged records of purchase orders based on fromDate,toDate*/
	@Override
	@Transactional
	public Page<PurchaseOrder> getPurchaseOrderReport(Date fromDate,
			Date toDate, int pageNumber, Integer rowsPerPage,
			String sortColName, String sortOrder) {
		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);
		return purchaseOrderRepository.findByPoDateBetween(fromDate, toDate,
				pageable);

	}	
	/*Method to fetch JQGrid paged records of purchase orders based on fromDate,toDate and orderStatus*/
	@Override
	@Transactional
	public Page<PurchaseOrder> getPurchaseOrderReportWithStatus(Date fromDate,
			Date toDate, String orderStatus, int pageNumber,
			Integer rowsPerPage, String sortColName, String sortOrder) {
		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);
		return purchaseOrderRepository.findByPoStatusAndPoDateBetween(
				orderStatus, fromDate, toDate, pageable);
	}
	/*Method to fetch JQGrid paged records of purchase orders based on customer,fromDate,toDate and orderStatus*/
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<PurchaseOrder> findByCustIdAndPurchaseOrderStatusAndMonthYear(
			String customer, String poStatus, int monthValue, int yearValue) {
		String basicQuery = " from PurchaseOrder o where MONTH(o.createdTime)="
				+ monthValue + " and YEAR(o.createdTime)=" + yearValue
				+ " and o.poStatus='" + poStatus
				+ "' and o.customer.customerId='" + customer + "'";

		return em.createQuery(basicQuery).getResultList();

	}
    /*Method to fetch purchase order list based on orderStatus,month and year*/
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<PurchaseOrder> getPagedSalesOrder(String orderStatus,
			int month, int year, int i, Integer rowsPerPage,
			String sortColName, String sortOrder) {
		String basicQuery = " from PurchaseOrder o where MONTH(o.createdTime)="
				+ month + " and YEAR(o.createdTime)=" + year
				+ " and o.poStatus='" + orderStatus + "' order by "+sortColName+" "+sortOrder;

		return em.createQuery(basicQuery).getResultList();
	}
	/*Method to fetch purchase order list based on orderStatus,month and year*/
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<PurchaseOrder> getPagedPo(String orderStatus, String month,
			String year, Integer pageNumber, Integer rowsPerPage,
			String sortColName, String sortOrder) {
		String basicQuery = " from PurchaseOrder o where MONTH(o.createdTime)="
				+ month + " and YEAR(o.createdTime)=" + year
				+ " and o.poStatus='" + orderStatus + "'";
		return em.createQuery(basicQuery).getResultList();
	}
	/*Method to fetch purchase order list based on orderStatus*/
	@Override
	@Transactional
	public List<PurchaseOrder> findByPurchaseOrderStatus(String string) {
		// TODO Auto-generated method stub
		return purchaseOrderRepository.findByPoStatus(string);
	}
	/*Method to fetch purchase order list based on orderStatus*/
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<String> findByPoStatusDistinct() {
		// TODO Auto-generated method stub
		String basicQuery = " select Distinct(o.poStatus) from PurchaseOrder o ";
		return em.createQuery(basicQuery).getResultList();

	}
	/*Method to fetch purchase order list based on month and year*/
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<PurchaseOrder> finddByStatusMonthYear(String poStatus,
			int month, int year) {
		String basicQuery = " from PurchaseOrder o where MONTH(o.createdTime)="
				+ month + " and YEAR(o.createdTime)=" + year
				+ " and o.poStatus='" + poStatus + "'";

		return em.createQuery(basicQuery).getResultList();
	}

}
