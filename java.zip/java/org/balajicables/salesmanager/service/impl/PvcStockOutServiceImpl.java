package org.balajicables.salesmanager.service.impl;

import java.util.List;
import javax.annotation.Resource;
import org.balajicables.salesmanager.model.PvcStockOut;
import org.balajicables.salesmanager.repository.PvcStockOutRepository;
import org.balajicables.salesmanager.service.PvcStockOutService;
import org.balajicables.salesmanager.utils.JPAUtility;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
/**
 * This class demonstrates the implementation of the PvcStockOut service methods
 * 
 * @author Abin Sam
 */
@Service
public class PvcStockOutServiceImpl implements PvcStockOutService {

	@Resource
	PvcStockOutRepository pvcStockOutRepository;

	/*Method to fetch stock out items based on batch number and extrusion workorder number*/
	@Override
    @Transactional
	public List<PvcStockOut> findByBatchAndProductionWorkOrderNo(String batch,
			String extrsuionWoNo) {
		return pvcStockOutRepository
				.findByBatchAndProductionWorkOrderWorkOrderNo(batch,
						extrsuionWoNo);
	}
	/*Method to update PVC stock out items*/
	@Override
    @Transactional
	public Boolean update(PvcStockOut pvcStockOut) {
		PvcStockOut saved = pvcStockOutRepository.save(pvcStockOut);
		if (saved == null) {
			return false;
		}
		return true;
	}
	/*Method to create and save PVC stock out items*/
	@Override
	@Transactional
	public PvcStockOut create(PvcStockOut pvcStockOuts) {
		return pvcStockOutRepository.save(pvcStockOuts);
	}
	/*Method to fetch JQGrid paged records of PVC stock out items based on workorder number*/
	@Override
	@Transactional
	public Page<PvcStockOut> getPvcStockOutRecords(String woNo, int pageNumber,
			Integer rowsPerPage, String sortColName, String sortOrder) {
		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);
		return pvcStockOutRepository.findByProductionWorkOrderWorkOrderNo(woNo,
				pageable);
	}
	/*Method to fetch list of PVC stock out items based on workorder item id*/
	@Override
	@Transactional
	public List<PvcStockOut> findByItemItemId(Long itemIdToDelete) {
		// TODO Auto-generated method stub
		return pvcStockOutRepository.findByItemItemId(itemIdToDelete);
	}

}
