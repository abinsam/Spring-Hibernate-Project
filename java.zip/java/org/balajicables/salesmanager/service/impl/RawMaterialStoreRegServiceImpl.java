package org.balajicables.salesmanager.service.impl;

import java.util.Date;
import java.util.List;
import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.balajicables.salesmanager.model.RawMaterialStoreReg;
import org.balajicables.salesmanager.repository.RawMaterialStoreRegrRepository;
import org.balajicables.salesmanager.service.RawMaterialStoreRegService;
import org.balajicables.salesmanager.utils.JPAUtility;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
/**
 * This class demonstrates the implementation of the RawMaterialStoreReg service methods
 * 
 * @author Abin Sam
 */
@Service
public class RawMaterialStoreRegServiceImpl implements RawMaterialStoreRegService {
	
	@PersistenceContext
	private EntityManager em;
	
	@Resource
	private RawMaterialStoreRegrRepository rawMaterialStoreRegrRepository;

	/*Method to create and save raw material items*/
	@Override
	@Transactional
	public RawMaterialStoreReg create(RawMaterialStoreReg rawMaterialStoreReg) {
		return rawMaterialStoreRegrRepository.save(rawMaterialStoreReg);
	}
	/*Method to fetch JQGrid paged records of raw material items based on QC status*/
	@Override
	@Transactional
	public Page<RawMaterialStoreReg> getPagedStore(String[] qcStatus,
			int pageNumber, Integer rowsPerPage, String sortColName,
			String sortOrder) {
		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);
		String sendToRbd = "No";
		String stockInStatus = "Yes";
		return rawMaterialStoreRegrRepository
				.findBySendToRbdAndStockInStatusAndQcStatusIn(pageable,
						sendToRbd, stockInStatus, qcStatus);

	}
	/*Method to fetch JQGrid paged records of raw material items based on QC status*/
	@Override
	@Transactional
	public Page<RawMaterialStoreReg> getQCPagedStore(int pageNumber,
			Integer rowsPerPage, String sortColName, String sortOrder) {
		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);
		return rawMaterialStoreRegrRepository.findByQcStatus(pageable,
				"Pending");
	}
	/*Method to fetch records of raw material items based on search parameter*/
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<RawMaterialStoreReg> fetchBySearch(String qCustomerName,
			String qItemCode, int pagenumber, Integer rows, String sortColName,
			String sortOrder) {
		String basicQuery = "from RawMaterialStoreReg o where ";
		String customerQuery = "  o.purchaseOrderItem.purchaseOrder.customer.customerName = '"
				+ qCustomerName + "' and  ";
		String itemCodeQuery = " o.purchaseOrderItem.item.itemCode='"
				+ qItemCode + "' and ";

		String finalQuery = "  o.rwStoreRegId is not null  order by  "
				+ sortColName + " " + sortOrder;

		if (qCustomerName != null && qCustomerName != "")
			basicQuery += customerQuery;
		if (qItemCode != null && qItemCode != "")
			basicQuery += itemCodeQuery;

		basicQuery += finalQuery;
		return em.createQuery(basicQuery).getResultList();
	}
	/*Method to fetch records of raw material items based on id*/
	@Override
	@Transactional
	public List<RawMaterialStoreReg> findById(Long idSelected) {
		return rawMaterialStoreRegrRepository.findByRwStoreRegId(idSelected);
	}
	/*Method to fetch JQGrid paged records of raw material items based on product type*/
	@Override
	@Transactional
	public Page<RawMaterialStoreReg> getPagedStoreAndProductType(
			int pageNumber, Integer rowsPerPage, String sortColName,
			String sortOrder, String[] productType) {
		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);
		String sendToRbd = "No";
		String stockInstatus = "Yes";
		return rawMaterialStoreRegrRepository
				.findBySendToRbdAndStockInStatusAndPurchaseOrderItemItemProductTypeProductKeyIn(
						pageable, sendToRbd, stockInstatus, productType);
	}
	/*Method to fetch JQGrid paged records of raw material items based on purchase order number*/
	@Override
	@Transactional
	public Page<RawMaterialStoreReg> getRawMaterialToStock(int pageNumber,
			Integer rowsPerPage, String sortColName, String sortOrder,
			String sendToRbd, String stockInStatus, String purchaseOrderNo) {
		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);
		return rawMaterialStoreRegrRepository
				.findBySendToRbdAndStockInStatusAndPurchaseOrderItemPurchaseOrderPoNo(
						pageable, sendToRbd, stockInStatus, purchaseOrderNo);
	}
	/*Method to update an save raw material items*/
	@Override
	@Transactional
	public Boolean update(RawMaterialStoreReg rawMaterialStoreReg) {
		RawMaterialStoreReg saved = rawMaterialStoreRegrRepository
				.save(rawMaterialStoreReg);
		if (saved == null) {
			return false;
		}
		return true;
	}
	/*Method to delete raw material items*/
	@Override
	@Transactional
	public Boolean delete(Long rawMaterialIdTodelete) {
		rawMaterialStoreRegrRepository.delete(rawMaterialIdTodelete);
		return true;
	}
	/*Method to fetch list of raw material items based on stocked in status*/
	@Override
	@Transactional
	public List<RawMaterialStoreReg> findByStockedInStatus(
			String stockedInStatus) {
		// TODO Auto-generated method stub
		return rawMaterialStoreRegrRepository
				.findByStockInStatus(stockedInStatus);
	}
	/*Method to fetch JQGrid paged records of raw material items based on item id*/
	@Override
	@Transactional
	public Page<RawMaterialStoreReg> getPagedItemEntry(String itemIdSelect,
			int pageNumber, Integer rowsPerPage, String sortColName,
			String sortOrder) {
		String sendToRbd = "No";
		String stockInstatus = "Yes";
		String qcStatus = "Pending";
		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);
		return rawMaterialStoreRegrRepository
				.findByPurchaseOrderItemItemItemCodeAndSendToRbdAndStockInStatusAndQcStatus(
						itemIdSelect, sendToRbd, stockInstatus, qcStatus,
						pageable);
	}
	/*Method to fetch JQGrid paged records of raw material items based on fromDate,toDate and status*/
	@Override
	@Transactional
	public Page<RawMaterialStoreReg> getRejectOrderWithDateAndStatus(
			String status, Date fromDate, Date toDate, int pageNumber,
			Integer rowsPerPage, String sortColName, String sortOrder) {
		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);
		return rawMaterialStoreRegrRepository.findByQcStatusAndDateTimeBetween(
				status, fromDate, toDate, pageable);
	}
	/*Method to fetch JQGrid paged records of raw material items based on default search*/
	@Override
	@Transactional
	public Page<RawMaterialStoreReg> getQCRejectedPagedStore(int pageNumber,
			Integer rowsPerPage, String sortColName, String sortOrder) {
		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);
		return rawMaterialStoreRegrRepository.findByQcStatus(pageable,
				"Rejected");

	}
	/*Method to fetch JQGrid paged records of raw material items based on qcStatus,rejectStatus*/
	@Override
	@Transactional
	public Page<RawMaterialStoreReg> getRejectOrderWithRejectStatus(
			String qcStatus, String rejectStatus, int pageNumber,
			Integer rowsPerPage, String sortColName, String sortOrder) {
		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);
		return rawMaterialStoreRegrRepository.findByQcStatusAndRejectStatus(
				qcStatus, rejectStatus, pageable);

	}
	/*Method to fetch JQGrid paged records of raw material items based on fromDate,toDate,qcStatus,rejectStatus*/
	@Override
	@Transactional
	public Page<RawMaterialStoreReg> getRejectOrderWithStatusAndDate(
			String qcStatus, Date fromDate, Date toDate, String rejectStatus,
			int pageNumber, Integer rowsPerPage, String sortColName,
			String sortOrder) {
		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);
		return rawMaterialStoreRegrRepository
				.findByQcStatusAndRejectStatusAndDateTimeBetween(qcStatus,
						rejectStatus, fromDate, toDate, pageable);

	}
	/*Method to fetch JQGrid paged records of raw material items based on stockFromDate,stockToDate*/
	@Override
	@Transactional
	public Page<RawMaterialStoreReg> getStockDatePagedStore(Date stockFromDate,
			Date stockToDate, int pageNumber, Integer rowsPerPage,
			String sortColName, String sortOrder) {
		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);
		return rawMaterialStoreRegrRepository.findByDateTimeBetween(
				stockFromDate, stockToDate, pageable);

	}
    /*Method to find all raw material store register items*/
	@Override
	@Transactional
	public List<RawMaterialStoreReg> findAll() {
		return rawMaterialStoreRegrRepository.findAll();
	}
	/*Method to find all raw material store register items*/
	@Override
	@Transactional
	public Page<RawMaterialStoreReg> getPagedApprovedPvcStock(int pageNumber,
			Integer rowsPerPage, String sortColName, String sortOrder,
			String[] productType, String[] qcStatus) {
		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);
		String sendToRbd = "No";
		String stockInstatus = "Yes";
		return rawMaterialStoreRegrRepository
				.findBySendToRbdAndStockInStatusAndPurchaseOrderItemItemProductTypeProductKeyInAndQcStatusIn(
						pageable, sendToRbd, stockInstatus, productType,
						qcStatus);
	}
	/*Method to fetch JQGrid paged records of raw material items based on qcStatus,sendToRbd,stockInstatus*/
	@Override
	@Transactional
	public Page<RawMaterialStoreReg> getPagedRawMaterialStore(int pageNumber,
			Integer rowsPerPage, String sortColName, String sortOrder,
			String[] qcStatus) {
		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);
		String sendToRbd = "No";
		String stockInstatus = "Yes";
		return rawMaterialStoreRegrRepository
				.findBySendToRbdAndStockInStatusAndQcStatusIn(pageable,
						sendToRbd, stockInstatus, qcStatus);
	}
	/*Method to fetch JQGrid paged records of raw material items based on stockFromDate,stockToDate,qcStatus,sendToRbd,itemCode,stockInstatus*/
	@Override
	@Transactional
	public Page<RawMaterialStoreReg> getOnDatePagedRawMaterialStore(
			Date stockFromDate, Date stockToDate, String itemCode,
			String[] qcStatus, int pageNumber, Integer rowsPerPage,
			String sortColName, String sortOrder) {
		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);
		String sendToRbd = "No";
		String stockInstatus = "Yes";

		return rawMaterialStoreRegrRepository
				.findBySendToRbdAndStockInStatusAndPurchaseOrderItemItemItemCodeAndDateTimeBetweenAndQcStatusIn(
						pageable, sendToRbd, stockInstatus, itemCode,
						stockFromDate, stockToDate, qcStatus);
	}
	/*Method to fetch JQGrid paged records of raw material items based on stockFromDate,stockToDate,qcStatus,sendToRbd,stockInstatus*/
	@Override
	@Transactional
	public Page<RawMaterialStoreReg> getStockDatePagedQcStatusStore(
			Date stockFromDate, Date stockToDate, String[] qcStatus,
			int pageNumber, Integer rowsPerPage, String sortColName,
			String sortOrder) {
		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);
		String sendToRbd = "No";
		String stockInstatus = "Yes";
		return rawMaterialStoreRegrRepository
				.findBySendToRbdAndStockInStatusAndDateTimeBetweenAndQcStatusIn(
						pageable, sendToRbd, stockInstatus, stockFromDate,
						stockToDate, qcStatus);
	}
	/*Method to fetch JQGrid paged records of raw material items based on stockFromDate,itemCode,stockToDate,qcStatus,sendToRbd,stockInstatus*/
	@Override
	@Transactional
	public Page<RawMaterialStoreReg> getItemPagedStore(String[] qcStatus,
			String itemCode, int pageNumber, Integer rowsPerPage,
			String sortColName, String sortOrder) {
		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);
		String sendToRbd = "No";
		String stockInstatus = "Yes";
		return rawMaterialStoreRegrRepository
				.findBySendToRbdAndStockInStatusAndPurchaseOrderItemItemItemCodeAndQcStatusIn(
						pageable, sendToRbd, stockInstatus, itemCode, qcStatus);

	}
    /*Method to find raw material store register items based on QC status*/
	@Override
	@Transactional
	public List<RawMaterialStoreReg> findByQcStatus(String status) {
		return rawMaterialStoreRegrRepository.findByQcStatus(status);
	}

}
