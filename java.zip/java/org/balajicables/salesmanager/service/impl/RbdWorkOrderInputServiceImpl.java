package org.balajicables.salesmanager.service.impl;

import javax.annotation.Resource;

import org.balajicables.salesmanager.model.RbdWorkOrderInput;
import org.balajicables.salesmanager.repository.RbdWorkOrderInputRepository;
import org.balajicables.salesmanager.service.RbdWorkOrderInputService;
import org.balajicables.salesmanager.utils.JPAUtility;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
/**
 * This class demonstrates the implementation of the RbdWorkOrderInput service methods
 * 
 * @author Abin Sam
 */
@Service
public class RbdWorkOrderInputServiceImpl implements RbdWorkOrderInputService {

	@Resource
	private RbdWorkOrderInputRepository rbdWorkOrderInputRepository;

	/*Method to create and save RBD workorder input*/
	@Override
	@Transactional
	public RbdWorkOrderInput create(RbdWorkOrderInput rbdWorkOrderInput) {
		return rbdWorkOrderInputRepository.save(rbdWorkOrderInput);
	}
	/*Method to fetch JQGrid paged records of RBD workorder input based on workorder number*/
	@Override
	@Transactional
	public Page<RbdWorkOrderInput> getRbdPagedList(String workOrderNo,
			int pageNumber, Integer rowsPerPage, String sortColName,
			String sortOrder) {
		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);
		return rbdWorkOrderInputRepository
				.findByProductionWorkOrderWorkOrderNo(workOrderNo, pageable);
	}

}
