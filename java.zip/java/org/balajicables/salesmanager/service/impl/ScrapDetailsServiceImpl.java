package org.balajicables.salesmanager.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.balajicables.salesmanager.model.ScrapDetails;
import org.balajicables.salesmanager.repository.ScrapDetailsRepository;
import org.balajicables.salesmanager.service.ScrapDetailsService;
import org.balajicables.salesmanager.utils.JPAUtility;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
/**
 * This class demonstrates the implementation of the ScrapDetails service methods
 * 
 * @author Abin Sam
 */
@Service
public class ScrapDetailsServiceImpl implements ScrapDetailsService {

	@Resource
	private ScrapDetailsRepository scrapDetailsRepository;

	/*Method to create and save scrap*/
	@Override
	@Transactional
	public ScrapDetails create(ScrapDetails scrapDetails) {
		return scrapDetailsRepository.save(scrapDetails);
	}
    /*Method to fetch JQGrid paged records of scrap details based on default search*/
	@Override
	@Transactional
	public Page<ScrapDetails> getScrapDetailsPagedList(int i,
			Integer rowsPerPage, String sortColName, String sortOrder) {
		Pageable pageable = JPAUtility.constructPageSpecification(i,
				rowsPerPage, sortColName, sortOrder);
		return scrapDetailsRepository.findAll(pageable);
	}
	/*Method to update scrap*/
	@Override
	@Transactional
	public Boolean update(ScrapDetails scrapDetails) {
		if (scrapDetailsRepository.save(scrapDetails) != null) {
			return true;
		}
		return false;
	}
	/*Method to delete scrap*/
	@Override
	@Transactional
	public Boolean delete(Long id) {
		scrapDetailsRepository.delete(id);
		return true;
	}
    /*Method to update stocked in status of scrap*/
	@Override
	@Transactional
	public void updateStockedInStatusById(Long id) {

		ScrapDetails scrapDetails = scrapDetailsRepository.findOne(id);
		scrapDetails.setStockedInStatus("YES");
		scrapDetailsRepository.save(scrapDetails);

	}
	/*Method to fetch scrap by its id*/
	@Override
	@Transactional
	public List<ScrapDetails> findById(Long id) {
		return scrapDetailsRepository.findByScrapId(id);
	}
	/*Method to fetch scrap by item id and stocked in status*/
	@Override
	@Transactional
	public List<ScrapDetails> findByItemIdAndStockedInStatus(Long itemId,
			String stockedInstatus) {

		return scrapDetailsRepository.findByItemItemIdAndStockedInStatus(
				itemId, stockedInstatus);
	}
	/*Method to fetch scrap by item id*/
	@Override
	@Transactional
	public List<ScrapDetails> findByItemItemId(Long itemIdToDelete) {
		// TODO Auto-generated method stub
		return scrapDetailsRepository.findByItemItemId(itemIdToDelete);
	}
	/*Method to fetch JQGrid paged records of scrap details based on workorder number,stockedin status*/
	@Override
	@Transactional
	public Page<ScrapDetails> getPagedScrapByWorkOrderAndStockedInStatus(
			String workOrder, String stockedInstatus, int pageNumber,
			Integer rowsPerPage, String sortColName, String sortOrder) {
		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);
		return scrapDetailsRepository
				.findByProductionWorkOrderWorkOrderNoAndStockedInStatus(
						workOrder, stockedInstatus, pageable);

	}

}
