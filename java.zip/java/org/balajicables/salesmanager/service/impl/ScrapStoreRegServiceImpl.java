package org.balajicables.salesmanager.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.balajicables.salesmanager.model.ScrapStoreReg;
import org.balajicables.salesmanager.repository.ScrapStoreRegRepository;
import org.balajicables.salesmanager.service.ScrapStoreRegService;
import org.balajicables.salesmanager.utils.JPAUtility;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
/**
 * This class demonstrates the implementation of the ScrapStoreReg service methods
 * 
 * @author Abin Sam
 */
@Service
public class ScrapStoreRegServiceImpl implements ScrapStoreRegService {

	@Resource
	private ScrapStoreRegRepository scrapStoreRegRepository;

	/*Method to find all scrap items*/
	@Override
	@Transactional
	public List<ScrapStoreReg> findAll() {
		return scrapStoreRegRepository.findAll();
	}
    /*Method to find Scrap store register items based on item id*/
	@Override
	@Transactional
	public List<ScrapStoreReg> findByItemsItemId(Long itemId) {
		return scrapStoreRegRepository.findByItemsItemId(itemId);
	}
	/*Method to update and save Scrap store register items*/
	@Override
	@Transactional
	public Boolean update(ScrapStoreReg scrapStoreReg) {
		ScrapStoreReg saved = scrapStoreRegRepository.save(scrapStoreReg);
		if (saved == null) {
			return false;
		}
		return true;
	}
	/*Method to create and save Scrap store register items*/
	@Override
	@Transactional
	public ScrapStoreReg create(ScrapStoreReg scrapStoreReg) {
		return scrapStoreRegRepository.save(scrapStoreReg);
	}
    /*Method to fetch JQGrid paged records of scrap store register items based on default search*/
	@Override
	@Transactional
	public Page<ScrapStoreReg> getScrapStoreRegDetailsPagedList(int pageNumber,
			Integer rowsPerPage, String sortColName, String sortOrder) {
		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);
		return scrapStoreRegRepository.findAll(pageable);
	}
    /*Method to find Scrap store register item based on id*/
	@Override
	@Transactional
	public List<ScrapStoreReg> findByScrapStoreRegId(Long scrapStoreRegId) {
		// TODO Auto-generated method stub
		return scrapStoreRegRepository.findByScrapStoreRegId(scrapStoreRegId);
	}
    /*Method to fetch JQGrid paged records of scrap store register items based on item code*/
	@Override
	@Transactional
	public Page<ScrapStoreReg> findByItemsItemCodeIn(int pageNumber,
			Integer rowsPerPage, String sortColName, String sortOrder,
			ArrayList<String> itemCode) {
		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);

		return scrapStoreRegRepository
				.findByItemsItemCodeIn(itemCode, pageable);
	}
}
