package org.balajicables.salesmanager.service.impl;

import java.util.List;
import javax.annotation.Resource;

import org.balajicables.salesmanager.model.SalesOrderItem;
import org.balajicables.salesmanager.model.SemifinishedStockOut;
import org.balajicables.salesmanager.repository.SemifinishedStockOutRepository;
import org.balajicables.salesmanager.service.SemifinishedStockOutService;
import org.balajicables.salesmanager.utils.JPAUtility;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
/**
 * This class demonstrates the implementation of the SemifinishedStockOut service methods
 * 
 * @author Abin Sam
 */
@Service
public class SemifinishedStockOutServiceImpl implements SemifinishedStockOutService {
	
	@Resource
	private SemifinishedStockOutRepository semifinishedStockOutRepository;

    /*Method to fetch JQGrid paged records of semifinished stockout based on woNo*/
	@Override
	@Transactional
	public Page<SemifinishedStockOut> getConfirmedSemifinishedStockOut(
			String woNo, String confrimStatus, int pageNumber,
			Integer rowsPerPage, String sortColName, String sortOrder) {

		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);
		return semifinishedStockOutRepository
				.findByProductionWorkOrderWorkOrderNoAndConfirmStatus(woNo,
						confrimStatus, pageable);

	}
    /*Method to fetch JQGrid paged records of semifinished stockout based on workOrder,woStockedOutProcess,confirmStatus*/
	@Override
	@Transactional
	public Page<SemifinishedStockOut> findByStockedOutForAndWorkOrderProcess(
			String workOrder, String woStockedOutProcess, String confirmStatus,
			int pageNumber, Integer rowsPerPage, String sortColName,
			String sortOrder) {
		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);
		return semifinishedStockOutRepository
				.findByProductionWorkOrderWorkOrderNoAndProductionWorkOrdersProcessProcessTypeAndConfirmStatus(
						workOrder, woStockedOutProcess, confirmStatus, pageable);

	}
	/*Method to fetch list of Semifinished Stockout items based on workOrder for which it has been stocked out*/
	@Override
	@Transactional
	public List<SemifinishedStockOut> findByStockedOutFor(String workOrder) {
		return semifinishedStockOutRepository
				.findByProductionWorkOrderWorkOrderNo(workOrder);
	}
	/*Method to fetch list of Semifinished Stockout items based on workOrder,woStockedOutProcess*/
	@Override
	@Transactional
	public List<SemifinishedStockOut> findByStockedOutForAndProductionWo(
			String workOrder, String woStockedOutProcess) {
		return semifinishedStockOutRepository
				.findByProductionWorkOrderWorkOrderNoAndProductionWorkOrdersProcessProcessType(
						workOrder, woStockedOutProcess);
	} 
    /*Method to fetch JQGrid paged records of semifinished stockout based on confirmStatus,itemTypeArray,userName*/
	@Override
	@Transactional
	public Page<SemifinishedStockOut> getPagedNotConfirmedUserBasedSemiFinishedSotck(
			int pageNumber, Integer rowsPerPage, String sortColName,
			String sortOrder, String confirmStatus, String[] itemTypeArray,
			String userName) {
		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);
		return semifinishedStockOutRepository
				.findByConfirmStatusAndSupervisorAndSalesOrderItemItemsItemTypeIn(
						confirmStatus, userName, itemTypeArray, pageable);

	}
	/*Method to create Semifinshed items for stockout*/
	@Override
	@Transactional
	public SemifinishedStockOut create(SemifinishedStockOut semifinishedStockOut) {
		return semifinishedStockOutRepository.save(semifinishedStockOut);
	}
	/*Method to fetch list of Semifinished Stockout items based on id*/
	@Override
	@Transactional
	public List<SemifinishedStockOut> findBySemifinishedStockOutId(
			Long semifinishedStockOutId) {
		return semifinishedStockOutRepository
				.findBySemifinishedStockOutId(semifinishedStockOutId);
	}
    /*Method to fetch list of Semifinished Stockout items based on soNo,itemCode,bundleId,woNo*/
	@Override
	@Transactional
	public List<SemifinishedStockOut> findByOrderIdAndItemCodeAndBundleIdAndWorkOrderAndConfirmStatus(
			String soNo, String itemCode, String bundleId, String woNo,
			String confirmStatus) {
		return semifinishedStockOutRepository
				.findBySalesOrderItemOrdersOrderIdAndSalesOrderItemItemsItemCodeAndProductionWorkOrdersWorkOrderNoAndBundleIdAndConfirmStatus(
						soNo, itemCode, woNo, bundleId, confirmStatus);
	}
    /*Method to delete Semifinshed items from stocking out*/
	@Override
	@Transactional
	public Boolean delete(Long id) {
		Boolean deleted = false;
		if (id != null) {
			semifinishedStockOutRepository.delete(id);
			deleted = true;
		}
		return deleted;
	}
	@Override
	public void update(SemifinishedStockOut semifinishedStockOuts) {
       semifinishedStockOutRepository.save(semifinishedStockOuts);
	
	}

}
