package org.balajicables.salesmanager.service.impl;

import java.util.Date;
import java.util.List;
import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.balajicables.salesmanager.model.StockIn;
import org.balajicables.salesmanager.repository.StockInRepository;
import org.balajicables.salesmanager.service.StockInService;
import org.balajicables.salesmanager.utils.JPAUtility;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
/**
 * This class demonstrates the implementation of the StockIn service methods
 * 
 * @author Abin Sam
 */
@Service
public class StockInServiceImpl implements StockInService {

	@PersistenceContext
	private EntityManager em;
	@Resource
	StockInRepository stockInRepository;

	/*Method to fetch  list of stockin items based on salesOrderId,itemCode,bundleId*/
	@Override
	@Transactional
	public List<StockIn> findByOrderIdItemIdBundleId(String salesOrderId,
			String itemCode, String bundleId) {
		return em.createQuery(
				" from StockIn o where o.itemCode='" + itemCode
						+ "' and o.orderId='" + salesOrderId
						+ "' and o.bundleId='" + bundleId + "'", StockIn.class)
				.getResultList();
	}
    /*Method to create and save stockin*/
	@Override
	@Transactional
	public StockIn create(StockIn stockInItem) {
		return stockInRepository.save(stockInItem);
	}
	/*Method to update and save stockin*/
	@Override
	@Transactional
	public Boolean update(StockIn stockIn) {
		StockIn saved = stockInRepository.save(stockIn);
		if (saved == null) {
			return false;
		}//end of if (saved == null) condition
		return true;

	}
	/*Method to fetch list of stockin items based on orderId,itemCode,batchNo*/
	@Override
	@Transactional
	public List<StockIn> findByOrderIdItemIdBatchNo(String orderId,
			String itemCode, String batchNo) {
		return em.createQuery(
				" from StockIn o where o.itemCode='" + itemCode
						+ "' and o.orderId='" + orderId + "' and o.batchNo='"
						+ batchNo + "'", StockIn.class).getResultList();
	}
	/*Method to fetch list of stockin items based on soItemId*/
	@Override
	@Transactional
	public List<StockIn> findBySalesOrderItemOrderDetailId(Long soItemId) {
		return stockInRepository.findBySalesOrderItemOrderDetailId(soItemId);
	}
	/*Method to fetch JQGrid paged records of stockin items based on confirmStatus*/
	@Override
	@Transactional
	public Page<StockIn> getPagedStockIn(int pageNumber, Integer rowsPerPage,
			String sortColName, String sortOrder, String confirmStatus) {
		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);
		return stockInRepository.findByConfirmStatus(confirmStatus, pageable);
	}
	/*Method to fetch list of stockin items*/
	@Override
	@Transactional
	public List<StockIn> findByStockInId(Long stockInId) {
		return stockInRepository.findByStockInId(stockInId);
	}
	/*Method to delete stockin item details*/
	@Override
	@Transactional
	public Boolean delete(Long stockInId) {
		stockInRepository.delete(stockInId);
		return true;
	}
    /*Method to fetch stockin item details based on soItemDetailsId,bundleId*/
	@Override
	@Transactional
	public List<StockIn> findByOrderDetailIdBundleIdWorkOrderNo(
			Long soItemDetailsId, String bundleId, String workOrderNo) {
		return stockInRepository
				.findBySalesOrderItemOrderDetailIdAndBundleIdAndProductionWorkOrderWorkOrderNo(
						soItemDetailsId, bundleId, workOrderNo);
	}
    /*Method to fetch stockin item details based on fromDates,toDates,party,itemCode,asortedtype*/
	@Override
	@Transactional
	public List<StockIn> getStockInDetails(Date fromDates, Date toDates,
			Long party, String itemCode, String asortedtype) {
		return null;
	}
    /*Method to fetch stock details for inventorty movement report*/
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<Object[]> getStockDetails(String fromDates, String toDates,
			String party, String itemCode, String salesOrder, String workOrder,
			String mainColour, String stripeColour, String od,
			String cablesStd, String productType, Integer layLength,
			String layType, String cuDiameter, Long noOfCuStrand) {

		String startQuery = "Select stockdate,customerName,itemCode,asorted,sum(StockinQty) as StockinQty,"
				+ " sum(StockOutQty) as StockOutQty,storeAddress,itemDescription,units,salesOrder,workOrderNo,"
				+ " productType,cableStd,od,layLength,layType,cuDiameter,mainColor,stripeColor,noOfCuStrands from ( ";

		String stockInQuery = "(select date(a.stock_In_Date_Time) as stockdate,a.item_Code as itemCode,i.customer_Code as customerName,b.assorted_Type as asorted,"
				+ "  sum(a.stock_Qty) as StockinQty,0 as StockOutQty,e.store_Address as storeAddress,b.item_Description as itemDescription,g.units as units,a.order_id as salesOrder ,a.work_order_no as workOrderNo, "
				+ " b.product_type_key as productType,b.cable_std_pvc_key as cableStd,b.outer_diameter as od,b.lay_length as layLength,b.lay_type as layType,b.copper_strand_diameter as cuDiameter,b.main_colour_key as mainColor ,b.inner_colour_key as stripeColor, "
				+ " b.number_of_copper_strands as noOfCuStrands from Stock_In a join item b on a.item_Code=b.item_Code join store e on e.store_id=a.store_id join unit_master g on g.unit_id=b.unit join sales_order j on j.order_id=a.order_id join customer i on j.customer_Id=i.customer_Id "
				+ " where date(a.stock_In_Date_Time) between  '"+ fromDates	+ "' and  '" + toDates + "' ";
		String stockInPartyQuery = "";
		String stockInItemCodeQuery = "";
		String stockInSoQuery = "";
		String stockInWoQuery = "";
		String stockInMainColourQuery = "";
		String stockInStripeColourQuery = "";
		String stockInCableStdQuery = "";
		String stockInOdQuery = "";
		String stockInLayLengthquery = "";
		String stockInLayTypeQuery = "";
		String stockInProductTypeQuery = "";
		String stockInCuDiamQuery = "";
		String stockInNoOfCustrandQuery = "";
		if (!(party.equalsIgnoreCase("All")))
			stockInPartyQuery = " and a.customer_Name='" + party + "' ";
		if (!(itemCode.equalsIgnoreCase("All")))
			stockInItemCodeQuery = " and a.item_Code='" + itemCode + "' ";
		if (!(salesOrder.equalsIgnoreCase("All")))
			stockInSoQuery = " and a.order_id='" + salesOrder + "' ";
		if (!(workOrder.equalsIgnoreCase("All")))
			stockInWoQuery = " and a.work_order_no='" + workOrder + "' ";
		if (!(mainColour.equalsIgnoreCase("All")))
			stockInMainColourQuery = " and b.main_colour_key='" + mainColour
					+ "' ";
		if (!(stripeColour.equalsIgnoreCase("All")))
			stockInStripeColourQuery = " and b.inner_colour_key='"
					+ stripeColour + "' ";
		if (!(cablesStd.equalsIgnoreCase("All")))
			stockInCableStdQuery = " and b.cable_std_pvc_key='" + cablesStd
					+ "' ";

		if (!(od.equalsIgnoreCase("All")))
			stockInOdQuery = " and b.outer_diameter='" + od + "' ";
		if (!(layLength == 0))
			stockInLayLengthquery = " and b.lay_length='" + layLength + "' ";
		if (!(layType.equalsIgnoreCase("All")))
			stockInLayTypeQuery = " and b.lay_type='" + layType + "' ";
		if (!(productType.equalsIgnoreCase("All")))
			stockInProductTypeQuery = " and  b.product_type_key='"
					+ productType + "' ";
		if (!(cuDiameter.equalsIgnoreCase("All")))
			stockInCuDiamQuery = " and b.copper_strand_diameter='" + cuDiameter
					+ "' ";
		if (!(noOfCuStrand == 0))
			stockInNoOfCustrandQuery = " and b.number_of_copper_strands='"
					+ noOfCuStrand + "' ";

		String stockInGroupByQuery = " group by  date(a.stock_In_Date_Time) , a.item_Code, a.customer_Name ) UNION ";

		String stockOutQuery = "( select date(c.stock_Out_Date_Time) as stockdate,c.item_Code as itemCode,i.customer_Code as customerName, d.assorted_Type as asorted,"
				+ "  0 as StockInQty,sum(c.stockOut_Qty) as StockOutQty,f.store_Address,d.item_Description as itemDescription,h.units as units,c.order_id as salesOrder ,c.work_order_no as workOrderNo , "
				+ " d.product_type_key as productType,d.cable_std_pvc_key as cableStd,d.outer_diameter as od,d.lay_length as layLength,d.lay_type as layType,d.copper_strand_diameter as cuDiameter,d.main_colour_key as mainColor ,d.inner_colour_key as stripeColor ,"
				+ " d.number_of_copper_strands as noOfCuStrands from Stock_Out c join item d on c.item_Code=d.item_Code join store f on c.store_id=f.store_id join unit_master h on h.unit_id=d.unit join sales_order k on k.order_id=c.order_id join customer i on k.customer_Id=i.customer_Id where date(c.stock_Out_Date_Time) between  '"
				+ fromDates + "' and  '" + toDates + "' ";
		String stockOutPartyQuery = "";
		String stockOutItemCodeQuery = "";
		String stockOutSoQuery = "";
		String stockOutWoQuery = "";
		String stockOutMainColourQuery = "";
		String stockOutStripeColourQuery = "";
		String stockOutCableStdQuery = "";
		String stockOutOdQuery = "";
		String stockOutLayLengthquery = "";
		String stockOutLayTypeQuery = "";
		String stockOutProductTypeQuery = "";
		String stockOutCuDiamQuery = "";
		String stockOutNoOfCustrandQuery = "";

		if (!(party.equalsIgnoreCase("All")))
			stockOutPartyQuery = " and c.customer_Name='" + party + "' ";
		if (!(itemCode.equalsIgnoreCase("All")))
			stockOutItemCodeQuery = " and c.item_Code='" + itemCode + "' ";
		if (!(salesOrder.equalsIgnoreCase("All")))
			stockOutSoQuery = " and c.order_id='" + salesOrder + "' ";
		if (!(workOrder.equalsIgnoreCase("All")))
			stockOutWoQuery = " and c.work_order_no='" + workOrder + "' ";
		if (!(mainColour.equalsIgnoreCase("All")))
			stockOutMainColourQuery = " and d.main_colour_key='" + mainColour
					+ "' ";
		if (!(stripeColour.equalsIgnoreCase("All")))
			stockOutStripeColourQuery = " and d.inner_colour_key='"
					+ stripeColour + "' ";
		if (!(cablesStd.equalsIgnoreCase("All")))
			stockOutCableStdQuery = " and d.cable_std_pvc_key='" + cablesStd
					+ "' ";

		if (!(od.equalsIgnoreCase("All")))
			stockOutOdQuery = " and d.outer_diameter='" + od + "' ";
		if (!(layLength == 0))
			stockOutLayLengthquery = " and d.lay_length='" + layLength + "' ";
		if (!(layType.equalsIgnoreCase("All")))
			stockOutLayTypeQuery = " and d.lay_type='" + layType + "' ";
		if (!(productType.equalsIgnoreCase("All")))
			stockOutProductTypeQuery = " and  d.product_type_key='"
					+ productType + "' ";
		if (!(cuDiameter.equalsIgnoreCase("All")))
			stockOutCuDiamQuery = " and d.copper_strand_diameter='"
					+ cuDiameter + "' ";
		if (!(noOfCuStrand == 0))
			stockOutNoOfCustrandQuery = " and d.number_of_copper_strands='"
					+ noOfCuStrand + "' ";

		String stockOutGroupByQuery = " group by  date(c.stock_Out_Date_Time) , c.item_Code, c.customer_Name )) as temp   group by stockdate,customerName,itemCode ";
		String finalQuery = null;
		finalQuery = startQuery + stockInQuery + stockInPartyQuery
				+ stockInItemCodeQuery + stockInSoQuery + stockInWoQuery
				+ stockInMainColourQuery + stockInStripeColourQuery
				+ stockInCableStdQuery + stockInOdQuery + stockInLayLengthquery
				+ stockInLayTypeQuery + stockInProductTypeQuery
				+ stockInCuDiamQuery + stockInNoOfCustrandQuery
				+ stockInGroupByQuery + stockOutQuery + stockOutPartyQuery
				+ stockOutItemCodeQuery + stockOutSoQuery + stockOutWoQuery
				+ stockOutMainColourQuery + stockOutStripeColourQuery
				+ stockOutCableStdQuery + stockOutOdQuery
				+ stockOutLayLengthquery + stockOutLayTypeQuery
				+ stockOutProductTypeQuery + stockOutCuDiamQuery
				+ stockOutNoOfCustrandQuery + stockOutGroupByQuery;
		Query query = null;
		if (finalQuery != null)
			query = em.createNativeQuery(finalQuery);

		return query.getResultList();
	}
    /*Method to fetch list of stockin items based on salesOrderId,itemCode,workOrderNo,bundleId*/
	@Override
	@Transactional
	public List<StockIn> findByOrderIdAndItemCodeAndWoNoAndBundleId(
			String salesOrderId, String itemCode, String workOrderNo,
			String bundleId) {
		return stockInRepository
				.findBySalesOrderItemOrdersOrderIdAndSalesOrderItemItemsItemCodeAndProductionWorkOrderWorkOrderNoAndBundleId(
						salesOrderId, itemCode, workOrderNo, bundleId);
	}
    /*Method to fetch JQGrid paged records of stockin items based on confirmStatus,userName*/
	@Override
	@Transactional
	public Page<StockIn> getPagedStockInBySupervisor(int pageNumber,
			Integer rowsPerPage, String sortColName, String sortOrder,
			String confirmStatus, String userName) {
		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);
		return stockInRepository.findByConfirmStatusAndSupervisor(
				confirmStatus, userName, pageable);

	}
	/*Method to fetch stockin items list based on salesOrderId,itemCode,workOrderNo,bundleId,confirmStatus*/
	@Override
	@Transactional
	public List<StockIn> findByOrderIdAndItemCodeAndWoNoAndBundleIdAndConfirmStatus(
			String salesOrderId, String itemCode, String workOrderNo,
			String bundleId, String confirmStatus) {
		return stockInRepository
				.findBySalesOrderItemOrdersOrderIdAndSalesOrderItemItemsItemCodeAndProductionWorkOrderWorkOrderNoAndBundleIdAndConfirmStatus(
						salesOrderId, itemCode, workOrderNo, bundleId,
						confirmStatus);
	}
	/*Method to fetch stockin items list based on orderDetailsId,workOrderNo,confirmStatus*/
	@Override
	@Transactional
	public List<StockIn> findByOrderDetailIdAndWorkOrderNoAndConfirmStatusAndMaxBundleId(
			Long orderDetailsId, String workOrderNo, String confirmStatus) {
		return em.createQuery(
				" from StockIn o where  o.salesOrderItem.orderDetailId="
						+ orderDetailsId
						+ " and o.productionWorkOrder.workOrderNo='"
						+ workOrderNo + "' and confirmStatus='" + confirmStatus
						+ "' group by o.bundleId ", StockIn.class)
				.getResultList();

	}
	/*Method to fetch stockin items list based on newSalesOrderItemId,oldWoNo,confirmStatus*/
	@Override
	@Transactional
	public List<StockIn> findByOrderDetailIdAndWoNoAndBundleId(
			Long newSalesOrderItemId, String oldWoNo, String confirmStatus) {
		return stockInRepository
				.findBySalesOrderItemOrderDetailIdAndProductionWorkOrderWorkOrderNoAndConfirmStatus(
						newSalesOrderItemId, oldWoNo, confirmStatus);

	}
    /*Method to fetch stockin items list based on newSalesOrderNo,itemCode,oldWoNo*/
	@Override
	@Transactional
	public List<StockIn> findByOrderIdAndItemCodeAndWoNo(
			String newSalesOrderNo, String itemCode, String oldWoNo) {
		return stockInRepository
				.findBySalesOrderItemOrdersOrderIdAndSalesOrderItemItemsItemCodeAndProductionWorkOrderWorkOrderNo(
						newSalesOrderNo, itemCode, oldWoNo);
	}
	@Override
	@Transactional
	public List<StockIn> findBySoNoAndWoNoAndBundleIdAndSoItemIdAndQuantity(
			String woNo, String bundleId, Long soItemid,
			Double stockInQty, Double stockWeight,String confirmStatus) {
			return em.createQuery(
					"from StockIn o where  o.salesOrderItem.orderDetailId="+soItemid+" and o.productionWorkOrder.workOrderNo='"+woNo+"' and" +
							" o.bundleId='"+bundleId+"'  and o.stockQty="+stockInQty+" and o.weight="+stockWeight+" and o.confirmStatus='"+confirmStatus+"'  order by o.stockInDateTime desc limit 1",
					StockIn.class).getResultList();
		}

}
