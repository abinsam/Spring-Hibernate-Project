package org.balajicables.salesmanager.service.impl;

import java.util.List;
import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.balajicables.salesmanager.model.StockOut;
import org.balajicables.salesmanager.repository.StockOutRepository;
import org.balajicables.salesmanager.service.StockOutService;
import org.balajicables.salesmanager.utils.JPAUtility;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
/**
 * This class demonstrates the implementation of the StockOut service methods
 * 
 * @author Abin Sam
 */
@Service
public class StockOutServiceImpl implements StockOutService {

	@PersistenceContext
	private EntityManager em;

	@Resource
	StockOutRepository stockOutRepository;

	/*Method to fetch stockout items based on salesOrderId,itemCode and bundleId*/
	@Override
	@Transactional
	public List<StockOut> findByOrderIdItemIdBundleId(String salesOrderId,
			String itemCode, String bundleId) {
		return em
				.createQuery(
						" from StockOut o where o.itemCode='" + itemCode
								+ "' and o.orderId='" + salesOrderId
								+ "' and o.bundleId='" + bundleId + "'",
						StockOut.class).getResultList();
	}
	/*Method to create and save stockout items*/
	@Override
	@Transactional
	public StockOut create(StockOut stockOutItem) {
		return stockOutRepository.save(stockOutItem);
	}
	/*Method to update and save stockout items*/
	@Override
	@Transactional
	public Boolean update(StockOut stockOut) {
		StockOut saved = stockOutRepository.save(stockOut);
		if (saved == null) {
			return false;
		}
		return true;

	}
	/*Method to fetch list of stockout items*/
	@Override
	@Transactional
	public List<StockOut> findByStockOutId(Long stockOutId) {
		return stockOutRepository.findByStockOutId(stockOutId);
	}
	/*Method to delete stockout items*/
	@Override
	@Transactional
	public Boolean delete(Long id) {
		Boolean deleted = false;
		if (id != null) {
			stockOutRepository.delete(id);
			deleted = true;
		}
		return deleted;
	}
	/*Method to fetch list of stockout items based on orderDetailsId,workOrderNo,bundleId*/
	@Override
	@Transactional
	public List<StockOut> findByOrderDetailIdWorkOrderNoBundleId(
			Long orderDetailsId, String workOrderNo, String bundleId) {
		return stockOutRepository
				.findBySalesOrderItemOrderDetailIdAndProductionWorkOrderWorkOrderNoAndBundleId(
						orderDetailsId, workOrderNo, bundleId);
	}
	/*Method to fetch JQGrid paged records of stockout items based on confirmStatus*/
	@Override
	@Transactional
	public Page<StockOut> getPagedStockOut(int pageNumber, Integer rowsPerPage,
			String sortColName, String sortOrder, String confirmStatus) {
		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);
		return stockOutRepository.findByConfirmStatus(confirmStatus, pageable);
	}
	/*Method to fetch JQGrid paged records of stockout items based on confirmStatus and userName*/
	@Override
	@Transactional
	public Page<StockOut> getPagedStockOutUserName(int pageNumber,
			Integer rowsPerPage, String sortColName, String sortOrder,
			String confirmStatus, String userName) {
		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);
		return stockOutRepository.findByConfirmStatusAndSupervisor(
				confirmStatus, userName, pageable);
	}
	/*Method to fetch list of stockout items based on orderDetailsId*/
	@Override
	@Transactional
	public List<StockOut> findBySalesOrderItemOrderDetailId(Long orderDetailsId) {
		return stockOutRepository
				.findBySalesOrderItemOrderDetailId(orderDetailsId);
	}
	/*Method to fetch list of stockout items based on orderDetailsId,workOrderNo and bagno*/
	@Override
	@Transactional
	public List<StockOut> findByOrderDetailIdWorkOrderNoPackingSlipNo(
			Long orderDetailId, String workOrderNo, Long bagNo) {
		return stockOutRepository
				.findBySalesOrderItemOrderDetailIdAndProductionWorkOrderWorkOrderNoAndPackingSlipNo(
						orderDetailId, workOrderNo, bagNo);
	}
	/*Method to fetch list of stockout items based on qOrderId,confirmStatus*/
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<StockOut> fetchStockOutBySearch(String qOrderId,
			String confirmStatus, int pagenumber, Integer rows,
			String sortColName, String sortOrder) {
		String query = " from StockOut o where o.salesOrderItem.orders.orderId='"
				+ qOrderId + "' and o.confirmStatus='" + confirmStatus + "'";
		return em.createQuery(query).getResultList();
	}
	/*Method to fetch list of stockout items based on qOrderId,confirmStatus and userName*/
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<StockOut> fetchStockOutBySearchUserName(String qOrderId,
			String confirmStatus, String userName, int pagenumber,
			Integer rows, String sortColName, String sortOrder) {
		String query = " from StockOut o where o.salesOrderItem.orders.orderId='"
				+ qOrderId + "' and o.confirmStatus='" + confirmStatus + "' ";
		return em.createQuery(query).getResultList();
	}
	/*Method to fetch list of stockout items based on newdeliveryChallanNo*/
	@Override
	@Transactional
	public List<StockOut> findByDeliveryChallanNo(String newdeliveryChallanNo) {
		return stockOutRepository.findByDeliveryChallanNo(newdeliveryChallanNo);
	}
	/*Method to fetch list of stockout items based on customerId*/
	@Override
	@Transactional
	public List<StockOut> finddByStockOutsCustomerId(Long customerId) {
		return stockOutRepository
				.findBySalesOrderItemOrdersCustomerCustomerId(customerId);
	}
	/*Method to fetch list of stockout items based on soNo,bagNo and confirmStatus*/
	@Override
	@Transactional
	public List<StockOut> findByOrderIdoPackingSlipNoConfirmStatus(String soNo,
			Long bagNo, String confirmStatus) {
		return stockOutRepository
				.findBySalesOrderItemOrdersOrderIdAndPackingSlipNoAndConfirmStatus(
						soNo, bagNo, confirmStatus);
	}
	/*Method to fetch list of stockout items based on orderId,workOrderNo and bagNo*/
	@Override
	@Transactional
	public List<StockOut> findByOrderIdWorkOrderNoPackingSlip(String orderId,
			String workOrderNo, Long bagNo) {
		return stockOutRepository
				.findBySalesOrderItemOrdersOrderIdAndProductionWorkOrderWorkOrderNoAndPackingSlipNo(
						orderId, workOrderNo, bagNo);
	}
	/*Method to fetch list of stockout items based on salesOrderId,itemCode,workOrderNo and bundleId*/
	@Override
	@Transactional
	public List<StockOut> findByOrderIdAndItemCodeAndBundleIdAndWorkOrderNo(
			String salesOrderId, String itemCode, String bundleId,
			String workOrderNo) {
		return stockOutRepository
				.findBySalesOrderItemOrdersOrderIdAndSalesOrderItemItemsItemCodeAndProductionWorkOrderWorkOrderNoAndBundleId(
						salesOrderId, itemCode, workOrderNo, bundleId);
	}
	/*Method to fetch list of stockout items based on item id*/
	@Override
	@Transactional
	public List<StockOut> findByItemId(Long long1) {
		return em.createQuery(" from StockOut o where o.itemId=" + long1,
				StockOut.class).getResultList();
	}
	/*Method to fetch list of stockout items based on salesOrderNo,confirmStatus*/
	@Override
	@Transactional
	public List<StockOut> findBySalesOrderItemOrdersOrderIdAndConfirmStatus(
			String salesOrderNo, String confirmStatus) {
		return stockOutRepository
				.findBySalesOrderItemOrdersOrderIdAndConfirmStatus(
						salesOrderNo, confirmStatus);

	}
	/*Method to fetch list of stockout items based on orderDetailId,confirmStatus*/
	@Override
	@Transactional
	public List<StockOut> findBySalesOrderItemOrderDetailIdAndConfirmStatus(
			Long orderDetailId, String confirmStatus) {
		return stockOutRepository
				.findBySalesOrderItemOrderDetailIdAndConfirmStatus(
						orderDetailId, confirmStatus);

	}
	/*Method to fetch JQGrid paged records of stockout items based on itemType,confirmStatus*/
	@Override
	@Transactional
	public Page<StockOut> getPagedNotConfirmedSemiFinishedSotck(int pageNumber,
			Integer rowsPerPage, String sortColName, String sortOrder,
			String confirmStatus, String[] itemType) {
		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);

		return stockOutRepository
				.findByConfirmStatusAndSalesOrderItemItemsItemTypeIn(
						confirmStatus, itemType, pageable);
	}
	/*Method to fetch list of stockout items based on workOrder,process*/
	@Override
	@Transactional
	public List<StockOut> findByWorkOrderNoAndProductionProcess(
			String workOrder, String process) {
		return stockOutRepository
				.findByProductionWorkOrderWorkOrderNoAndProductionWorkOrderProcessProcessType(
						workOrder, process);
	}
	/*Method to fetch list of stockout items based on monthValue,yearValue*/
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<StockOut> finddByStockOutsAndMonthYear(int monthValue,
			int yearValue) {
		String basicQuery = " from StockOut o where MONTH(o.stockOutDateTime)="
				+ monthValue + " and YEAR(o.stockOutDateTime)=" + yearValue
				+ " ";

		return em.createQuery(basicQuery).getResultList();
	}
	/*Method to fetch list of stockout items based on customerId,monthValue,yearValue*/
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<StockOut> finddByStockOutsCustomerIdAndMonthYear(
			Long customerId, int monthValue, int yearValue) {
		String basicQuery = " from StockOut o where MONTH(o.createdTime)="
				+ monthValue + " and YEAR(o.createdTime)=" + yearValue
				+ "  and o.salesOrderItem.orders.customer.customerId ="
				+ customerId + "";

		return em.createQuery(basicQuery).getResultList();
	}
	/*Method to fetch list of stockout items based on salesOrderId,itemCode,bundleId,workOrderNo and confirmStatus*/
	@Override
	@Transactional
	public List<StockOut> findByOrderIdAndItemCodeAndBundleIdAndWorkOrderNoAndConfirmStatus(
			String salesOrderId, String itemCode, String bundleId,
			String workOrderNo, String confirmStatus) {
		return stockOutRepository
				.findBySalesOrderItemOrdersOrderIdAndSalesOrderItemItemsItemCodeAndProductionWorkOrderWorkOrderNoAndBundleIdAndConfirmStatus(
						salesOrderId, itemCode, workOrderNo, bundleId,
						confirmStatus);
	}
	@Override
	@Transactional
	public List<StockOut> findBySalesOrderItemIdAndWorkOrderNoAndConfirmStatus(
			Long salesOrderItemId, String workOrderNo, String confrimstatus) {
		return stockOutRepository
				.findBySalesOrderItemOrderDetailIdAndProductionWorkOrderWorkOrderNoAndConfirmStatus(salesOrderItemId,workOrderNo,confrimstatus);
	}
    @SuppressWarnings("unchecked")
	@Transactional
	@Override
	public List<Object[]> getStoreRegBundleDetails(Long salesOrderItemId,
			String workOrderNo, String sortColName, String sortOrder) {
		String startQuery = " Select m.storeRegisterId as stockId," +
				" m.bundleId as bundleId,m.qcSupervisor as qcSupervisor,m.qcStatus as qcStatus,m.remarks as remarks,'Instore' as status from" +
				" StoreRegister m where m.salesOrderItem.orderDetailId="+salesOrderItemId+" and" +
				" m.productionWorkOrder.workOrderNo='"+workOrderNo+"' order by "+sortColName+" "+sortOrder;
		return em.createQuery(startQuery).getResultList();
	}
	   @SuppressWarnings("unchecked")
	@Transactional
		@Override
		public List<Object[]> getStockOutBundleDetails(Long salesOrderItemId,
				String workOrderNo, String confrimstatus, String sortColName, String sortOrder) {
			String endQuery="Select n.stockOutId as stockId," +
					" n.bundleId as bundleId,n.qcSupervisor as qcSupervisor,n.qcStatus as qcStatus,n.remarks as remarks,'stockedout' as status from" +
					" StockOut n where n.salesOrderItem.orderDetailId="+salesOrderItemId+" and" +
					" n.productionWorkOrder.workOrderNo='"+workOrderNo+"' and"+
					" n.confirmStatus='"+confrimstatus+"'order by "+sortColName+" "+sortOrder;
			return em.createQuery(endQuery).getResultList();
		}
	@Override
	public List<StockOut> findDistinctDcBySalesOrderItem(Long salesOrderItemId) {
		return stockOutRepository
				.findDistinctDeliveryChallanNoBySalesOrderItemOrderDetailId(salesOrderItemId);
	}
}