package org.balajicables.salesmanager.service.impl;

import java.util.List;
import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import org.balajicables.salesmanager.model.StoreRegister;
import org.balajicables.salesmanager.repository.StoreRegisterRepository;
import org.balajicables.salesmanager.service.StoreRegisterForQcService;
import org.balajicables.salesmanager.utils.JPAUtility;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
/**
 * This class demonstrates the implementation of the StoreRegisterForQc service methods
 * 
 * @author Abin Sam
 */
@Service
public class StoreRegisterForQcServiceImpl implements StoreRegisterForQcService {
	@PersistenceContext
	private EntityManager em;
	@Resource
	private StoreRegisterRepository storeRegisterRepository;

	/*Method to fetch list of store register items based on salesorder number,item code and bundle id*/
	@Override
	@Transactional
	public List<StoreRegister> findByOrderIdItemCodeBundleId(
			String salesOrderId, String itemCode, String bundleId) {
		return em.createQuery(
				" from StoreRegister o where o.itemCode='" + itemCode
						+ "' and o.orderId='" + salesOrderId
						+ "' and o.bundleId='" + bundleId + "'",
				StoreRegister.class).getResultList();
	}

	/*Method to update and save store register quantity based on store register id*/
	@Transactional
	@Override
	public Boolean updateStoreQuantity(Long storeRegisterId, int stockQty) {
		Query q = em.createQuery(" Update  StoreRegister o SET o.stockQty="
				+ stockQty + " where o.storeRegisterId=" + storeRegisterId);
		int updated = q.executeUpdate();
		if (updated == 1)
			return true;
		else
			return false;

	}

	/*Method to create and save store register items*/
	@Override
	@Transactional
	public StoreRegister create(StoreRegister storeRegister) {
		return storeRegisterRepository.save(storeRegister);
	}

	/*Method to fetch JQGrid paged records of store register items based on default search*/
	@Override
	@Transactional
	public Page<StoreRegister> getPagedStore(int pageNumber,
			Integer rowsPerPage, String sortColName, String sortOrder) {
		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);
		return storeRegisterRepository.findAll(pageable);
	}

	/*Method to delete store register item with empty stock quantity based on store register id*/
	@Transactional
	@Override
	public Boolean deleteEmptyStock(Long storeRegisterId) {
		Query q = em
				.createQuery("DELETE  FROM StoreRegister s WHERE s.storeRegisterId ="
						+ storeRegisterId);
		int deleted = q.executeUpdate();
		if (deleted == 1)
			return true;
		else
			return false;
	}

	/*Method to find store register records based on the search parameter*/
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<StoreRegister> fetchBySearch(String qOrderId,
			String qWorkOrderNo, Long qCustomerId, String qItemCode,
			int qNumberOfCopperStrands, String qCopperKey,
			String qOuterDiameter, String qMainColour, String qInnerColor,
			String qCableStdKey, String qLayLength, String qLayType,
			String qProductKey, Integer pagenumber, Integer rows,
			String sortColName, String sortOrder) {

		String basicQuery = " from StoreRegister o where ";
		String orderIdQuery = " o.orderId = '" + qOrderId + "' and ";
		String customerQuery = "  o.salesOrderItem.orders.customer.customerId = "
				+ qCustomerId + " and  ";
		String itemCodeQuery = " o.itemCode='" + qItemCode + "' and ";

		String noCuStrandQuery = " o.salesOrderItem.items.numberOfCopperStrands="
				+ qNumberOfCopperStrands + " and ";
		String cuQuery = " o.salesOrderItem.items.copperStrandDiameter.copperkey= '"
				+ qCopperKey + "' and   ";
		String odQuery = " o.salesOrderItem.items.outerDiameter='"
				+ qOuterDiameter + "' and  ";
		String mainColorQuery = " o.salesOrderItem.items.mainColour.color  ='"
				+ qMainColour + "' and ";
		String innerColorQuery = " o.salesOrderItem.items.innerColour.color = '"
				+ qInnerColor + "' and ";
		String cableStdQuery = " o.salesOrderItem.items.cableStdPvc.cableStdKey ='"
				+ qCableStdKey + "' and  ";
		String layLengthQuery = " o.salesOrderItem.items.layLength="
				+ qLayLength + " and ";
		String layTypeQuery = " o.salesOrderItem.items.layType='" + qLayType
				+ "' and  ";
		String pdtQuery = " o.salesOrderItem.items.productType.productKey = '"
				+ qProductKey + "' and ";
		String woNoQuery = " o.productionWorkOrder.workOrderNo='"
				+ qWorkOrderNo + "' and ";

		String finalQuery = "  o.storeRegisterId >0  order by  o."
				+ sortColName + " " + sortOrder;

		if (qOrderId != null && qOrderId != "")
			basicQuery += orderIdQuery;
		if (qCustomerId != 0)
			basicQuery += customerQuery;
		if (qItemCode != null && qItemCode != "")
			basicQuery += itemCodeQuery;
		if (qNumberOfCopperStrands != 0)
			basicQuery += noCuStrandQuery;
		if (qCopperKey != null && qCopperKey != "")
			basicQuery += cuQuery;
		if (qOuterDiameter != null && qOuterDiameter != "")
			basicQuery += odQuery;
		if (qMainColour != null && qMainColour != "")
			basicQuery += mainColorQuery;
		if (qInnerColor != null && qInnerColor != "")
			basicQuery += innerColorQuery;
		if (qCableStdKey != null && qCableStdKey != "")
			basicQuery += cableStdQuery;
		if (qLayLength != null && qLayLength != "")
			basicQuery += layLengthQuery;
		if (qLayType != null && qLayType != "")
			basicQuery += layTypeQuery;
		if (qProductKey != null && qProductKey != "")
			basicQuery += pdtQuery;
		if (qWorkOrderNo != null && qWorkOrderNo != "")
			basicQuery += woNoQuery;

		basicQuery += finalQuery;
		return em.createQuery(basicQuery).getResultList();
	}

	/*Method to fetch stock quantity of store register items based on customer name and item code*/
	@Override
	@Transactional
	public Double fetchStockQty(String customerName, String itemCode) {
		Query queryresult = em
				.createQuery(" select sum(o.stockQty),o.itemCode from StoreRegister o where o.itemCode='"
						+ itemCode
						+ "' and o.customerName='"
						+ customerName
						+ "'");
		Object[] qtyResult = (Object[]) queryresult.getSingleResult();
		return (Double) qtyResult[0];
	}

	/*Method to fetch stock quantity of store register items based on customer name and item code*/
	@Override
	@Transactional
	public Double fetchItemStockQty(String customerName, String itemCode) {
		Query queryresult = em
				.createQuery(" select sum(o.stockQty),o.itemCode from StoreRegister o where o.itemCode='"
						+ itemCode
						+ "' and o.customerName!='"
						+ customerName
						+ "'");
		Object[] qtyResult = (Object[]) queryresult.getSingleResult();
		return (Double) qtyResult[0];
	}
	/*Method to find store register item by store register id*/
	@Override
	@Transactional
	public List<StoreRegister> findByOrderIdItemIdBundleId(String orderId,
			String itemCode, String bundleId) {
		return em.createQuery(
				" from StoreRegister o where o.itemCode='" + itemCode
						+ "' and o.orderId='" + orderId + "' and o.bundleId='"
						+ bundleId + "'", StoreRegister.class).getResultList();
	}

	/*Method to find store register item by store register id*/
	@Override
	@Transactional
	public List<StoreRegister> findById(Long storeRegisterId) {
		return storeRegisterRepository.findByStoreRegisterId(storeRegisterId);
	}

	/*Method to update and save store register*/
	@Override
	@Transactional
	public Boolean update(StoreRegister storeRegister) {
		Boolean saveStatus = false;
		StoreRegister savedStoreItem = storeRegisterRepository
				.save(storeRegister);
		if (savedStoreItem != null)
			saveStatus = true;
		return saveStatus;
	}

	/*Method to fetch list of store register items based on salesorder number,workorder number,item code and bundle id*/
	@Override
	@Transactional
	public List<StoreRegister> findByOrderIdAndItemCodeAndBundleIdAndWorkOrderNo(
			String salesOrderId, String itemCode, String bundleId,
			String workOrderNo) {
		// TODO Auto-generated method stub
		return storeRegisterRepository
				.findByOrderIdAndSalesOrderItemItemsItemCodeAndBundleIdAndProductionWorkOrderWorkOrderNo(
						salesOrderId, itemCode, bundleId, workOrderNo);
	}

	/*Method to fetch list of store register items based on orderdetail id*/
	@Override
	@Transactional
	public List<StoreRegister> findBySalesOrderItemOrderDetailId(
			Long orderDetailsId) {
		return storeRegisterRepository
				.findBySalesOrderItemOrderDetailId(orderDetailsId);
	}

	/*Method to delete store register item*/
	@Override
	@Transactional
	public Boolean delete(Long storeRegId) {
		storeRegisterRepository.delete(storeRegId);
		return true;
	}

	/*Method to fetch list of store register items based on orderdetail id,bundle id,workorder number*/
	@Override
	public List<StoreRegister> findByOrderDetailIdAndBundleIdAndWorkOrderNo(
			Long orderDetailId, String bundleId, String woNo) {
		return storeRegisterRepository
				.findBySalesOrderItemOrderDetailIdAndBundleIdAndProductionWorkOrderWorkOrderNo(
						orderDetailId, bundleId, woNo);

	}
	/*Method to fetch list of store register items based on salesorder number and bagno*/
	@Override
	@Transactional
	public List<StoreRegister> findByOrderDetailIdWorkOrderNoPackingSlipNo(
			Long orderDetailId, String workOrderNo, Long bagNo) {
		return storeRegisterRepository
				.findBySalesOrderItemOrderDetailIdAndProductionWorkOrderWorkOrderNoAndPackingSlipNo(
						orderDetailId, workOrderNo, bagNo);
	}

	/*Method to fetch list of store register items based on salesorder number and bagno*/
	@Override
	@Transactional
	public List<StoreRegister> findByOrderIdoPackingSlipNo(String soNo,
			Long bagNo) {
		return storeRegisterRepository
				.findBySalesOrderItemOrdersOrderIdAndPackingSlipNo(soNo, bagNo);
	}
    /*Method to find all store register items*/
	@Override
	@Transactional
	public List<StoreRegister> findAll() {
		return storeRegisterRepository.findAll();
	}

	/*Method to fetch JQGrid paged records of store register items based on item type*/
	@Override
	@Transactional
	public Page<StoreRegister> getPagedSemiFinishedStoreReg(int pageNumber,
			Integer rowsPerPage, String sortColName, String sortOrder,
			String[] itemType) {
		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);
		return storeRegisterRepository.findBySalesOrderItemItemsItemTypeIn(
				itemType, pageable);
	}
	/*Method to fetch list of store register items based on salesorder number,workorder number and item code*/
	@Override
	@Transactional
	public List<StoreRegister> findByOrderIdAndItemCodeAndWorkOrderNo(
			String soNo, String itemCode, String woNo) {
		// TODO Auto-generated method stub
		return storeRegisterRepository
				.findByOrderIdAndItemCodeAndProductionWorkOrderWorkOrderNo(
						soNo, itemCode, woNo);
	}
	/*Method to fetch list of store register items based on salesorder number,workorder number and bagno*/
	@Override
	@Transactional
	public List<StoreRegister> findByOrderIdWorkOrderNoPackingSlip(
			String orderId, String workOrderNo, Long bagNo) {
		return storeRegisterRepository
				.findBySalesOrderItemOrdersOrderIdAndProductionWorkOrderWorkOrderNoAndPackingSlipNo(
						orderId, workOrderNo, bagNo);
	}

	/*Method to fetch list of store register items based on salesorder item id*/
	@Override
	@Transactional
	public List<StoreRegister> findByOrderDetailId(Long newSalesOrderItemId) {
		// TODO Auto-generated method stub
		return storeRegisterRepository
				.findBySalesOrderItemOrderDetailId(newSalesOrderItemId);
	}

}
