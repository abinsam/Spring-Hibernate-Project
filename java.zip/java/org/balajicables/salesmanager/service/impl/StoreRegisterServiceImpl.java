package org.balajicables.salesmanager.service.impl;

import java.util.Date;
import java.util.List;
import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import org.balajicables.salesmanager.model.StoreRegister;
import org.balajicables.salesmanager.repository.StoreRegisterRepository;
import org.balajicables.salesmanager.service.StoreRegisterService;
import org.balajicables.salesmanager.utils.JPAUtility;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * This class demonstrates the implementation of the StoreRegister service methods
 * 
 * @author Abin Sam
 */
@Service
public class StoreRegisterServiceImpl implements StoreRegisterService {
	
	@PersistenceContext
	private EntityManager em;
	
	@Resource
	private StoreRegisterRepository storeRegisterRepository;
	/*Method to fetch list of store register items based on salesorder number,item code and bundle id*/
	@Override
	@Transactional
	public List<StoreRegister> findByOrderIdItemCodeBundleId(
			String salesOrderId, String itemCode, String bundleId) {
		return em.createQuery(
				" from StoreRegister o where o.itemCode='" + itemCode
						+ "' and o.orderId='" + salesOrderId
						+ "' and o.bundleId='" + bundleId + "'",
				StoreRegister.class).getResultList();
	}
	/*Method to update and save store register quantity based on store register id*/
	@Transactional
	@Override
	public Boolean updateStoreQuantity(Long storeRegisterId, int stockQty) {
		Query q = em.createQuery(" Update  StoreRegister o SET o.stockQty="
				+ stockQty + " where o.storeRegisterId=" + storeRegisterId);
		int updated = q.executeUpdate();
		if (updated == 1)
			return true;
		else
			return false;

	}
	/*Method to create and save store register items*/
	@Override
	@Transactional
	public StoreRegister create(StoreRegister storeRegister) {
		return storeRegisterRepository.save(storeRegister);
	}
	/*Method to fetch JQGrid paged records of store register items based on status rejected*/
	@Override
	@Transactional
	public Page<StoreRegister> getPagedStore(int pageNumber,
			Integer rowsPerPage, String sortColName, String sortOrder) {
		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);
		return storeRegisterRepository
				.findByQcStatusNotIn(pageable, "Rejected");
	}
	/*Method to fetch JQGrid paged records of store register items based on status Pending*/
	@Override
	@Transactional
	public Page<StoreRegister> getQCPagedStore(int pageNumber,
			Integer rowsPerPage, String sortColName, String sortOrder) {
		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);
		return storeRegisterRepository.findByQcStatus(pageable, "Pending");
	}
	/*Method to fetch JQGrid paged records of store register items based on QC status rejected*/
	@Override
	@Transactional
	public Page<StoreRegister> getQCRejectedPagedStore(int pageNumber,
			Integer rowsPerPage, String sortColName, String sortOrder) {

		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);
		return storeRegisterRepository.findByQcStatus(pageable, "Rejected");
	}
	/*Method to fetch JQGrid paged records of store register items based on QC status rejected and between fromDate and toDate */
	@Override
	@Transactional
	public Page<StoreRegister> getRejectOrderWithDate(Date fromDate,
			Date toDate, int pageNumber, Integer rowsPerPage,
			String sortColName, String sortOrder) {
		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);
		return storeRegisterRepository.findByQcStatusAndUpdatedDateTimeBetween(
				"Rejected", fromDate, toDate, pageable);

	}
	/*Method to fetch JQGrid paged records of store register items based on rejectStatus*/
	@Override
	@Transactional
	public Page<StoreRegister> getRejectOrderWithStatus(String rejectStatus,
			int pageNumber, Integer rowsPerPage, String sortColName,
			String sortOrder) {

		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);
		return storeRegisterRepository.findByRejectStatus(rejectStatus,
				pageable);

	}
	/*Method to fetch JQGrid paged records of store register items based on rejectStatus*/
	@Override
	@Transactional
	public Page<StoreRegister> getRejectOrderWithStatusAndDate(Date fromDate,
			Date toDate, String rejectStatus, int pageNumber,
			Integer rowsPerPage, String sortColName, String sortOrder) {
		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);
		return storeRegisterRepository
				.findByRejectStatusAndUpdatedDateTimeBetween(rejectStatus,
						fromDate, toDate, pageable);

	}
	/*Method to delete store register item with empty stock quantity based on store register id*/
	@Transactional
	@Override
	public Boolean deleteEmptyStock(Long storeRegisterId) {
		Query q = em
				.createQuery("DELETE  FROM StoreRegister s WHERE s.storeRegisterId ="
						+ storeRegisterId);
		int deleted = q.executeUpdate();
		if (deleted == 1)
			return true;
		else
			return false;
	}
	/*Method to find store register records based on the search parameter*/
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<StoreRegister> fetchBySearch(String qOrderId,
			String qWorkOrderNo, Long qCustomerId, String qItemCode,
			int qNumberOfCopperStrands, String qCopperKey,
			String qOuterDiameter, String qMainColour, String qInnerColor,
			String qCableStdKey, String qLayLength, String qLayType,
			String qProductKey,String qQcStatus,Integer pagenumber, Integer rows,
			String sortColName, String sortOrder) {

		String basicQuery = " from StoreRegister o where ";
		String orderIdQuery = " o.orderId = '" + qOrderId + "' and ";
		String customerQuery = "  o.salesOrderItem.orders.customer.customerId = "
				+ qCustomerId + " and  ";
		String itemCodeQuery = " o.itemCode='" + qItemCode + "' and ";

		String noCuStrandQuery = " o.salesOrderItem.items.numberOfCopperStrands="
				+ qNumberOfCopperStrands + " and ";
		String cuQuery = " o.salesOrderItem.items.copperStrandDiameter.copperkey= '"
				+ qCopperKey + "' and   ";
		String odQuery = " o.salesOrderItem.items.outerDiameter='"
				+ qOuterDiameter + "' and  ";
		String mainColorQuery = " o.salesOrderItem.items.mainColour.color  ='"
				+ qMainColour + "' and ";
		String innerColorQuery = " o.salesOrderItem.items.innerColour.color = '"
				+ qInnerColor + "' and ";
		String cableStdQuery = " o.salesOrderItem.items.cableStdPvc.cableStdKey ='"
				+ qCableStdKey + "' and  ";
		String layLengthQuery = " o.salesOrderItem.items.layLength="
				+ qLayLength + " and ";
		String layTypeQuery = " o.salesOrderItem.items.layType='" + qLayType
				+ "' and  ";
		String pdtQuery = " o.salesOrderItem.items.productType.productKey = '"
				+ qProductKey + "' and ";
		String woNoQuery = " o.productionWorkOrder.workOrderNo='"
				+ qWorkOrderNo + "' and ";
		String qcStatusQuery = " o.qcStatus ='"+ qQcStatus +"'and ";

		String finalQuery = "  o.storeRegisterId >0  order by  o."
				+ sortColName + " " + sortOrder;

		if (qOrderId != null && qOrderId != "")
			basicQuery += orderIdQuery;
		if (qCustomerId != 0)
			basicQuery += customerQuery;
		if (qItemCode != null && qItemCode != "")
			basicQuery += itemCodeQuery;
		if (qNumberOfCopperStrands != 0)
			basicQuery += noCuStrandQuery;
		if (qCopperKey != null && qCopperKey != "")
			basicQuery += cuQuery;
		if (qOuterDiameter != null && qOuterDiameter != "")
			basicQuery += odQuery;
		if (qMainColour != null && qMainColour != "")
			basicQuery += mainColorQuery;
		if (qInnerColor != null && qInnerColor != "")
			basicQuery += innerColorQuery;
		if (qCableStdKey != null && qCableStdKey != "")
			basicQuery += cableStdQuery;
		if (qLayLength != null && qLayLength != "")
			basicQuery += layLengthQuery;
		if (qLayType != null && qLayType != "")
			basicQuery += layTypeQuery;
		if (qProductKey != null && qProductKey != "")
			basicQuery += pdtQuery;
		if (qWorkOrderNo != null && qWorkOrderNo != "")
			basicQuery += woNoQuery;
		basicQuery += qcStatusQuery;

		basicQuery += finalQuery;
		return em.createQuery(basicQuery).getResultList();
	}
	/*Method to find store register records based on the search parameter*/
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<StoreRegister> fetchByRejectStatusSearch(String qOrderId,
			String qWorkOrderNo, String qCustomerName, String qItemCode,
			Integer qNumberOfCopperStrands, String qCopperKey,
			String qOuterDiameter, String qMainColour, String qInnerColor,
			String qCableStdKey, String qLayLength, String qLayType,
			String qProductKey, int pagenumber, Integer rows,
			String sortColName, String sortOrder) {

		String basicQuery = " from StoreRegister o where ";
		String orderIdQuery = " o.orderId = '" + qOrderId + "' and ";
		String customerQuery = "  o.customerName = '" + qCustomerName
				+ "' and  ";
		String itemCodeQuery = " o.itemCode='" + qItemCode + "' and ";
		String noCuStrandQuery = " o.salesOrderItem.items.numberOfCopperStrands="
				+ qNumberOfCopperStrands + " and ";
		String cuQuery = " o.salesOrderItem.items.copperStrandDiameter.copperkey= '"
				+ qCopperKey + "' and   ";
		String odQuery = " o.salesOrderItem.items.outerDiameter='"
				+ qOuterDiameter + "' and  ";
		String mainColorQuery = " o.salesOrderItem.items.mainColour.color  ='"
				+ qMainColour + "' and ";
		String innerColorQuery = " o.salesOrderItem.items.innerColour.color = '"
				+ qInnerColor + "' and ";
		String cableStdQuery = " o.salesOrderItem.items.cableStdPvc.cableStdKey ='"
				+ qCableStdKey + "' and  ";
		String layLengthQuery = " o.salesOrderItem.items.layLength="
				+ qLayLength + " and ";
		String layTypeQuery = " o.salesOrderItem.items.layType='" + qLayType
				+ "' and  ";
		String pdtQuery = " o.salesOrderItem.items.productType.productKey = '"
				+ qProductKey + "' and ";
		String woNoQuery = " o.productionWorkOrder.workOrderNo='"
				+ qWorkOrderNo + "' and ";
		String qcStatusQuery = " o.qcStatus NOT IN('Rejected') and ";
		String finalQuery = "  o.storeRegisterId >0  order by  o."
				+ sortColName + " " + sortOrder;

		if (qOrderId != null && qOrderId != "")
			basicQuery += orderIdQuery;
		if (qCustomerName != null && qCustomerName != "")
			basicQuery += customerQuery;
		if (qItemCode != null && qItemCode != "")
			basicQuery += itemCodeQuery;
		if (qNumberOfCopperStrands != 0)
			basicQuery += noCuStrandQuery;
		if (qCopperKey != null && qCopperKey != "")
			basicQuery += cuQuery;
		if (qOuterDiameter != null && qOuterDiameter != "")
			basicQuery += odQuery;
		if (qMainColour != null && qMainColour != "")
			basicQuery += mainColorQuery;
		if (qInnerColor != null && qInnerColor != "")
			basicQuery += innerColorQuery;
		if (qCableStdKey != null && qCableStdKey != "")
			basicQuery += cableStdQuery;
		if (qLayLength != null && qLayLength != "")
			basicQuery += layLengthQuery;
		if (qLayType != null && qLayType != "")
			basicQuery += layTypeQuery;
		if (qProductKey != null && qProductKey != "")
			basicQuery += pdtQuery;
		if (qWorkOrderNo != null && qWorkOrderNo != "")
			basicQuery += woNoQuery;
		basicQuery += qcStatusQuery;

		basicQuery += finalQuery;
		return em.createQuery(basicQuery).getResultList();
	}

	/*Method to fetch list of store register items based on reject status*/
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<StoreRegister> fetchByRejectStatusSearch(String rejectStatus) {
		String basicQuery = " from StoreRegister o where o.rejectStatus NOT IN('"
				+ rejectStatus + "')";
		return em.createQuery(basicQuery).getResultList();
	}
	/*Method to stock quantity of store register items based on customer name and item code*/
	@Override
	@Transactional
	public Double fetchStockQty(Long customerId, String itemCode,String unitType) {
		Query queryresult = em
				.createQuery(" select sum("+unitType+"),o.itemCode from StoreRegister o where o.itemCode='"
						+ itemCode
						+ "' and o.salesOrderItem.orders.customer.customerId="
						+ customerId);
		Object[] qtyResult = (Object[]) queryresult.getSingleResult();
		return (Double) qtyResult[0];
	}
	/*Method to stock quantity of store register items based on customer name and item code*/
	@Override
	@Transactional
	public Double fetchItemStockQty(Long customerId, String itemCode,String unitType) {
		Query queryresult = em
				.createQuery(" select sum("+unitType+"),o.itemCode from StoreRegister o where o.itemCode='"
						+ itemCode
						+ "' and o.salesOrderItem.orders.customer.customerId!="
						+ customerId);
		Object[] qtyResult = (Object[]) queryresult.getSingleResult();
		return (Double) qtyResult[0];
	}

	/*Method to fetch list of store register items based on salesorder id,item id and bundle id*/
	@Override
	@Transactional
	public List<StoreRegister> findByOrderIdItemIdBundleId(String orderId,
			String itemCode, String bundleId) {
		return em.createQuery(
				" from StoreRegister o where o.itemCode='" + itemCode
						+ "' and o.orderId='" + orderId + "' and o.bundleId='"
						+ bundleId + "'", StoreRegister.class).getResultList();
	}
	/*Method to fetch list of store register items based on salesorder id,item id and bundle id*/
	@Override
	@Transactional
	public List<StoreRegister> findById(Long storeRegisterId) {
		return storeRegisterRepository.findByStoreRegisterId(storeRegisterId);
	}
	/*Method to fetch list of store register items based on salesorder id,item id and bundle id*/
	@Override
	@Transactional
	public Boolean update(StoreRegister storeRegister) {
		Boolean saveStatus = false;
		StoreRegister savedStoreItem = storeRegisterRepository
				.save(storeRegister);
		if (savedStoreItem != null)
			saveStatus = true;
		return saveStatus;
	}

	@Override
	@Transactional
	public List<StoreRegister> findByOrderIdAndItemCodeAndBundleIdAndWorkOrderNo(
			String salesOrderId, String itemCode, String bundleId,
			String workOrderNo) {

		return storeRegisterRepository
				.findByOrderIdAndSalesOrderItemItemsItemCodeAndBundleIdAndProductionWorkOrderWorkOrderNo(
						salesOrderId, itemCode, bundleId, workOrderNo);
	}

	@Override
	@Transactional
	public List<StoreRegister> findBySalesOrderItemOrderDetailId(
			Long orderDetailsId) {
		return storeRegisterRepository
				.findBySalesOrderItemOrderDetailId(orderDetailsId);
	}

	@Override
	@Transactional
	public Boolean delete(Long storeRegId) {
		storeRegisterRepository.delete(storeRegId);
		return true;
	}

	@Override
	@Transactional
	public List<StoreRegister> findByOrderDetailIdAndBundleIdAndWorkOrderNo(
			Long orderDetailId, String bundleId, String woNo) {
		return storeRegisterRepository
				.findBySalesOrderItemOrderDetailIdAndBundleIdAndProductionWorkOrderWorkOrderNo(
						orderDetailId, bundleId, woNo);

	}

	@Override
	@Transactional
	public List<StoreRegister> findByOrderDetailIdWorkOrderNoPackingSlipNo(
			Long orderDetailId, String workOrderNo, Long bagNo) {
		return storeRegisterRepository
				.findBySalesOrderItemOrderDetailIdAndProductionWorkOrderWorkOrderNoAndPackingSlipNo(
						orderDetailId, workOrderNo, bagNo);
	}

	@Override
	@Transactional
	public List<StoreRegister> findByOrderIdoPackingSlipNo(String soNo,
			Long bagNo) {
		return storeRegisterRepository
				.findBySalesOrderItemOrdersOrderIdAndPackingSlipNo(soNo, bagNo);
	}

	@Override
	@Transactional
	public List<StoreRegister> findAll() {
		return storeRegisterRepository.findAll();
	}

	@Override
	@Transactional
	public Page<StoreRegister> getPagedSemiFinishedStoreReg(int pageNumber,
			Integer rowsPerPage, String sortColName, String sortOrder,
			String[] itemType) {
		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);
		return storeRegisterRepository.findBySalesOrderItemItemsItemTypeIn(
				itemType, pageable);
	}
	/*Method to fetch list of store register items based on salesorder number,item code and workorder number*/
	@Override
	@Transactional
	public List<StoreRegister> findByOrderIdAndItemCodeAndWorkOrderNo(
			String soNo, String itemCode, String woNo) {

		return storeRegisterRepository
				.findByOrderIdAndItemCodeAndProductionWorkOrderWorkOrderNo(
						soNo, itemCode, woNo);
	}
	/*Method to fetch list of store register items based on salesorder number,bagno and workorder number*/
	@Override
	@Transactional
	public List<StoreRegister> findByOrderIdWorkOrderNoPackingSlip(
			String orderId, String workOrderNo, Long bagNo) {
		return storeRegisterRepository
				.findBySalesOrderItemOrdersOrderIdAndProductionWorkOrderWorkOrderNoAndPackingSlipNo(
						orderId, workOrderNo, bagNo);
	}
	/*Method to fetch list of store register items based on salesorder item id*/
	@Override
	@Transactional
	public List<StoreRegister> findByOrderDetailId(Long newSalesOrderItemId) {

		return storeRegisterRepository
				.findBySalesOrderItemOrderDetailId(newSalesOrderItemId);
	}

	/*Method to fetch JQGrid paged records of store register items based on stockFromDate and stockToDate*/
	@Override
	@Transactional
	public Page<StoreRegister> getStockDatePagedStore(Date stockFromDate,
			Date stockToDate, int pageNumber, Integer rowsPerPage,
			String sortColName, String sortOrder) {
		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);
		return storeRegisterRepository.findByUpdatedDateTimeBetween(
				stockFromDate, stockToDate, pageable);

	}
	/*Method to fetch JQGrid paged records of store register items based on QC status*/
	@Override
	@Transactional
	public Page<StoreRegister> fetchByQcStatusNotIn(String qcStatus,
			int pageNumber, Integer rowsPerPage, String sortColName,
			String sortOrder) {
		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);
		return storeRegisterRepository.findByQcStatusNotIn(pageable, qcStatus);
	}
	/*Method to fetch list of store register items based on salesorder number*/
	@Override
	@Transactional
	public List<StoreRegister> findByOrderId(String salesorderNumber) {
		return storeRegisterRepository
				.findBySalesOrderItemOrdersOrderId(salesorderNumber);
	}
	/*Method to fetch list of store register items based on customer name*/
	@Override
	@Transactional
	public List<StoreRegister> findBySalesOrderItemOrdersCustomerCustomerName(
			String customerId) {
		return storeRegisterRepository
				.findBySalesOrderItemOrdersCustomerCustomerName(customerId);
	}
	/*Method to fetch list of store register items based on workorder number and process*/
	@Override
	@Transactional
	public List<StoreRegister> findByWorkOrderNoAndProductionProcess(
			String workOrder, String process) {
		// TODO Auto-generated method stub
		return storeRegisterRepository
				.findByProductionWorkOrderWorkOrderNoAndProductionWorkOrderProcessProcessType(
						workOrder, process);
	}
	/*Method to group store register items based on item code*/
	@Override
	@Transactional
	public List<StoreRegister> distinctItemCodes() {
		return em.createQuery(" from StoreRegister o group by o.itemCode",
				StoreRegister.class).getResultList();

	}
	/*Method to fetch list of store register items based on QC status*/
	@Override
	@Transactional
	public List<StoreRegister> findByQcStatus(String status) {
		return storeRegisterRepository.findByQcStatus(status);
	}
	/*Method to fetch list of store register items based on QC status which is not rejected and customerId*/
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<StoreRegister> fetchByQcStatusSearch(String qOrderId,
			Long qCustomerId, int pagenumber, Integer rows, String sortColName,
			String sortOrder) {
		String basicQuery = " from StoreRegister o where ";
		String orderIdQuery = " o.orderId = '" + qOrderId + "' and ";
		String customerQuery = "  o.salesOrderItem.orders.customer.customerId = "
				+ qCustomerId + " and  ";
		String finalQuery = "  o.qcStatus NOT IN ('Rejected') and o.storeRegisterId >0  order by  o."
				+ sortColName + " " + sortOrder;

		if (qOrderId != null && qOrderId != "")
			basicQuery += orderIdQuery;
		if (qCustomerId != 0)
			basicQuery += customerQuery;
		basicQuery += finalQuery;
		return em.createQuery(basicQuery).getResultList();
	}
	/*Method to fetch list of store register items based on QC status and customerId*/
	@Override
	@Transactional
	public List<StoreRegister> findBySalesOrderItemOrdersCustomerCustomerIdAndQcStatus(
			Long customerId, String qcStatus) {
		return storeRegisterRepository
				.findBySalesOrderItemOrdersCustomerCustomerIdAndQcStatus(
						customerId, qcStatus);
	}
	/*Method to fetch list of store register items based on process type*/
	@Override
	@Transactional
	public List<StoreRegister> findByProductionWorkOrderProcess(
			String processType) {
		return storeRegisterRepository
				.findByProductionWorkOrderProcessProcessType(processType);
	}
	/*Method to fetch list of store register items based on QC status and process type*/
	@Override
	@Transactional
	public List<StoreRegister> findByQcStatusAndProductionWorkOrderProcess(
			String qcStatus, String processType) {
		return storeRegisterRepository
				.findByQcStatusAndProductionWorkOrderProcessProcessType(
						qcStatus, processType);
	}
	@Override
	@Transactional
	public List<StoreRegister> findBySalesOrderItemIdAndWorkOrderNo(
			Long salesOrderItemId, String workOrderNo) {
		return storeRegisterRepository
				.findBySalesOrderItemOrderDetailIdAndProductionWorkOrderWorkOrderNo(salesOrderItemId,workOrderNo);

	}

	@Override
	@Transactional
	public List<StoreRegister> findBySalesorderItemItemItemId(Long itemIds) {
		return storeRegisterRepository
					.findBySalesOrderItemItemsItemId(itemIds);
	}
	

}
