package org.balajicables.salesmanager.service.impl;

import java.util.List;
import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.balajicables.salesmanager.model.TaxRate;
import org.balajicables.salesmanager.repository.TaxRateRepository;
import org.balajicables.salesmanager.service.TaxRateService;
import org.balajicables.salesmanager.utils.JPAUtility;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
/**
 * This class demonstrates the implementation of the TaxRate service methods
 * 
 * @author Abin Sam
 */
@Service
public class TaxRateServiceImpl implements TaxRateService {
	@PersistenceContext
	private EntityManager em;

	@Resource
	TaxRateRepository taxRateRepository;

	/*Method to fetch tax rates list based on customer*/
	@Override
	@Transactional
	public List<TaxRate> findByCustomerId(long customerId) {
		return taxRateRepository.findByCustomerCustomerId(customerId);
	}
	/*Method to update tax rates*/
	@Override
	@Transactional
	public Boolean update(TaxRate taxRate) {
		TaxRate saved = taxRateRepository.save(taxRate);
		if (saved == null) {
			return false;
		}
		return true;
	}
	/*Method to delete tax rates*/
	@Override
	@Transactional
	public Boolean delete(Long taxId) {
		taxRateRepository.delete(taxId);
		return true;
	}
    /*Method to fetch JQGrid paged records of taxrates based on default search*/
	@Override
	@Transactional
	public Page<TaxRate> getPagedTaxes(int pageNumber, Integer rowsPerPage,
			String sortColName, String sortOrder) {
		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);
		return taxRateRepository.findAll(pageable);
	}
    /*Method to fetch list of tax rates based on search parameters*/
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<TaxRate> fetchBySearch(Long qCustomerId, int pagenumber,
			Integer rows, String sortColName, String sortOrder) {
		String basicQuery = " from TaxRate o where ";
		String customerQuery = "  o.customer.customerId = " + qCustomerId
				+ " and";
		String finalQuery = "  o.taxRateId > 0  order by  o." + sortColName
				+ " " + sortOrder;

		if (qCustomerId != 0)
			basicQuery += customerQuery;
		basicQuery += finalQuery;
		return em.createQuery(basicQuery).getResultList();
	}
	/*Method to create and save tax rates*/
	@Override
	@Transactional
	public Boolean create(TaxRate taxRate) {
		TaxRate saved = taxRateRepository.save(taxRate);
		if (saved == null) {
			return false;
		}
		return true;

	}

}
