package org.balajicables.salesmanager.service.impl;

import java.util.List;
import javax.annotation.Resource;
import org.balajicables.salesmanager.model.Unit;
import org.balajicables.salesmanager.repository.UnitRepository;
import org.balajicables.salesmanager.service.UnitService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
/**
 * This class demonstrates the implementation of the Unit service methods
 * 
 * @author Abin Sam
 */
@Service
public class UnitServiceImpl implements UnitService {

	@Resource
	UnitRepository unitRepository;

	/*Method to find all units*/
	@Override
	@Transactional
	public List<Unit> findAll() {
		return unitRepository.findAll();
	}

}
