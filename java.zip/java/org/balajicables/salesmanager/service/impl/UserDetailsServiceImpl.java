package org.balajicables.salesmanager.service.impl;

import java.util.ArrayList;
import java.util.Collection;
import org.balajicables.salesmanager.Assembler;
import org.balajicables.salesmanager.CustomUser;
import org.balajicables.salesmanager.dao.UserDao;
import org.balajicables.salesmanager.model.Role;
import org.balajicables.salesmanager.model.User;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
/**
 * This class demonstrates the implementation of the UserDetails service methods
 * 
 * @author Abin Sam
 */
@Service("userDetailsService")
public class UserDetailsServiceImpl implements UserDetailsService {
	
	Logger logger = LoggerFactory.getLogger(UserDetailsServiceImpl.class);
	
	@Autowired
	private UserDao userDao;
	
	@Autowired
	private Assembler assembler;

	/*Method to fetch user details*/
	@Transactional(readOnly = true)
	public UserDetails loadUserByUsername(String username)
			throws UsernameNotFoundException, DataAccessException {
		logger.info("in loadUserByUsername method " + username);
		User user = null;
		try {
			user = userDao.findByName(username);
		} catch (NullPointerException e) {
			logger.error("NPE", e);
		}
		if (user == null) {
			throw new UsernameNotFoundException("user not found");
		}

		return assembler.buildUserFromUserEntity(user);
	}
	/*Method to fetch customer user details*/
	@SuppressWarnings("unused")
	private CustomUser buildUserFromUserEntity(User user) {

		String username = user.getUserName();
		String firstName = user.getFirstName();
		String lastName = user.getLastName();
		String password = user.getPassword();
		boolean enabled = user.isEnabled();
		boolean accountNonExpired = user.isEnabled();
		boolean credentialsNonExpired = user.isEnabled();
		boolean accountNonLocked = user.isEnabled();

		Collection<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
		for (Role role : user.getRoles()) {
			authorities.add(new SimpleGrantedAuthority(role.getAuthority()));
		}
        /*Creating a new instance of customer user*/
		CustomUser customUser = new CustomUser(username, firstName, lastName,
				password, enabled, accountNonExpired, credentialsNonExpired,
				accountNonLocked, authorities);
		return customUser;
	}
	/*Setter methods for UserDao class*/
	public void setUserDao(UserDao userDao) {
		this.userDao = userDao;
	}
    /*Setter methods for Assembler class*/
	public void setAssembler(Assembler assembler) {
		this.assembler = assembler;
	}

}