package org.balajicables.salesmanager.service.impl;

import java.util.List;
import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.balajicables.salesmanager.model.ProductionWorkOrder;
import org.balajicables.salesmanager.model.WorkOrderItems;
import org.balajicables.salesmanager.repository.WorkOrderItemRepository;
import org.balajicables.salesmanager.service.WorkOrderItemService;
import org.balajicables.salesmanager.utils.JPAUtility;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
/**
 * This class demonstrates the implementation of the WorkOrderItem service methods
 * 
 * @author Abin Sam
 */
@Service
public class WorkOrderItemServiceImpl implements WorkOrderItemService {

	@Resource
	WorkOrderItemRepository workOrderItemRepository;

	@PersistenceContext
	private EntityManager em;

	/*Method to create and save workorder items*/
	@Transactional
	@Override
	public WorkOrderItems create(WorkOrderItems workOrderItems) {
		return workOrderItemRepository.save(workOrderItems);
	}

	/*Method to fetch JQGrid paged records of workorder items based on workorder number*/
	@Override
	@Transactional
	public Page<WorkOrderItems> getPagedOrders(String workOrderNo,
			int pageNumber, Integer rowsPerPage, String sortColName,
			String sortOrder) {
		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);
		return workOrderItemRepository.findByProductionWorkOrderWorkOrderNo(
				workOrderNo, pageable);
	}

	/*Method to update and save workorder items*/
	@Override
	@Transactional
	public Boolean update(WorkOrderItems woItems) {
		WorkOrderItems saved = workOrderItemRepository.save(woItems);
		if (saved == null) {
			return false;
		}
		return true;
	}

	/*Method to delete workorder items*/
	@Override
	@Transactional
	public Boolean delete(Long woItemIdToDelete) {
		workOrderItemRepository.delete(woItemIdToDelete);
		return true;
	}

	/*Method to fetch list of workorder items based on salesorder item id and workorder number*/
	@Override
	@Transactional
	public List<WorkOrderItems> findBySoItemIdAndWorkOrder(Long soItemId,
			String workOrderNo) {
		return workOrderItemRepository
				.findBySalesOrderItemOrderDetailIdAndProductionWorkOrderWorkOrderNo(
						soItemId, workOrderNo);
	}

	/*Method to fetch list of workorder items based on salesorder item id*/
	@Override
	@Transactional
	public List<WorkOrderItems> findBySalesOrderItem(Long soItemId) {
		return workOrderItemRepository
				.findBySalesOrderItemOrderDetailId(soItemId);
	}
	/*Method to fetch list of workorder items based on salesorder number*/
	@Override
	@Transactional
	public List<WorkOrderItems> findBySalesOrderItemOrdersOrderId(String orderId) {
		return workOrderItemRepository
				.findBySalesOrderItemOrdersOrderId(orderId);
	}

	/*Method to get workorder items records based on workorder number*/
	@Override
	@Transactional
	public List<WorkOrderItems> getRecords(String workOrderNo) {
		return workOrderItemRepository
				.findByProductionWorkOrderWorkOrderNo(workOrderNo);
	}
	/*Method to get workorder items records of latest workorder based on workorder number*/
	@Override
	@Transactional
	public List<WorkOrderItems> fetchLatestByProductionWorkOrderWorkOrderNo(
			String bunchingWorkOrderNoTag) {
		return em.createQuery(
				"from WorkOrderItems o where o.productionWorkOrder.workOrderNo='"
						+ bunchingWorkOrderNoTag
						+ "'  order by o.workOrderItemId desc limit 1 ",
				WorkOrderItems.class).getResultList();
	}
	/*Method to fetch list of workorder items based on salesorder item id and workorder number*/
	@Override
	@Transactional
	public List<WorkOrderItems> findBySoItemIdAndWorkOrderNo(Long soItemId,
			String workOrderNo) {
		return workOrderItemRepository
				.findBySalesOrderItemOrderDetailIdAndProductionWorkOrderWorkOrderNo(
						soItemId, workOrderNo);
	}
	/*Method to fetch list of workorder items based on workorder item id*/
	@Override
	@Transactional
	public List<WorkOrderItems> findById(Long woItemId) {

		return workOrderItemRepository.findByWorkOrderItemId(woItemId);
	}
	/*Method to fetch list of workorder items based on salesorder number, item code and workorder number*/
	@Override
	@Transactional
	public List<WorkOrderItems> findByOrderIdAndItemCodeAndWorkOrderNo(
			String salesOrderId, String itemCode, String workOrderNo) {

		return workOrderItemRepository
				.findBySalesOrderItemOrdersOrderIdAndSalesOrderItemItemsItemCodeAndProductionWorkOrderWorkOrderNo(
						salesOrderId, itemCode, workOrderNo);
	}
	/*Method to fetch list of workorder items based on workorder process*/
	@Override
	@Transactional
	public List<WorkOrderItems> findByProductionWorkOrderProcessType(
			String process) {

		return workOrderItemRepository
				.findByProductionWorkOrderProcessProcessType(process);
	}
	/*Method to fetch list of workorder items based on workorder number*/
	@Override
	@Transactional
	public List<WorkOrderItems> findByProductionWorkOrderWorkOrderNo(
			String workOrderNo) {
		return workOrderItemRepository
				.findByProductionWorkOrderWorkOrderNo(workOrderNo);
	}
	/*Method to fetch list of workorder items based on workorder number*/
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<WorkOrderItems> findWoItemList(String workOrderNo) {
		String query = " from WorkOrderItems o where o.productionWorkOrder.workOrderNo='"
				+ workOrderNo
				+ "' "
				+ "   order by o.salesOrderItem.items.mainColour.orderSequence ,o.salesOrderItem.items.innerColour.orderSequence,"
				+ "   o.salesOrderItem.items.outerDiameter,o.salesOrderItem.items.numberOfCopperStrands asc";
		
		return em.createQuery(query).getResultList();
	}

	/*Method to fetch list of workorder items based on workorder item id*/
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<WorkOrderItems> findWoItemList(Long workOrderItemId) {
		String query = " from WorkOrderItems o where o.workOrderItemId='"
				+ workOrderItemId
				+ "' "
				+ "   order by o.salesOrderItem.items.mainColour.orderSequence ,o.salesOrderItem.items.innerColour.orderSequence,"
				+ "   o.salesOrderItem.items.outerDiameter,o.salesOrderItem.items.numberOfCopperStrands asc";
		return em.createQuery(query).getResultList();
	}

	/*Method to fetch list of workorder items based on workorder process,month and year of creation*/
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<ProductionWorkOrder> findByProcessTypeAndMonthYear(
			String processType, int month, int year) {
		String basicQuery = " from ProductionWorkOrder o where MONTH(o.createdTime)="
				+ month
				+ " and YEAR(o.createdTime)="
				+ year
				+ " and o.process.processType='" + processType + "'";

		return em.createQuery(basicQuery).getResultList();
	}
	/*Method to fetch list of workorder items based on workorder number,month and year of creation*/
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<WorkOrderItems> findWoItemListMonthYear(String woNo, int month,
			int year) {
		String query = " from WorkOrderItems o where o.productionWorkOrder.workOrderNo='"
				+ woNo
				+ "' and month(o.updatedTime)='"
				+ month
				+ "' and year(o.updatedTime)='"
				+ year
				+ "' "
				+ "   order by o.salesOrderItem.items.mainColour.orderSequence ,o.salesOrderItem.items.innerColour.orderSequence,"
				+ "   o.salesOrderItem.items.outerDiameter,o.salesOrderItem.items.numberOfCopperStrands asc";
		return em.createQuery(query).getResultList();
	}

	@Override
	@Transactional
	public List<WorkOrderItems> findByProductionWorkOrderWorkOrderNoAndStockInStatus(
			String workOrderNo, String status) {
		return workOrderItemRepository.findByProductionWorkOrderWorkOrderNoAndStockInStatus(workOrderNo,status);
	}

	@Override
	@Transactional
	public Page<WorkOrderItems> findByPagedSalesOrderItem(
			Long salesOrderItemId, int pageNumber, Integer rowsPerPage,
			String sortColName, String sortOrder) {
		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,rowsPerPage, sortColName, sortOrder);
		return workOrderItemRepository.findBySalesOrderItemOrderDetailId(
				salesOrderItemId, pageable);

	}

}
