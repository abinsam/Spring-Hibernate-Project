package org.balajicables.salesmanager.service.impl;

import java.util.List;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.balajicables.salesmanager.model.WorkOrderOutput;
import org.balajicables.salesmanager.repository.WorkOrderOutputRepository;
import org.balajicables.salesmanager.service.WorkOrderOutputService;
import org.balajicables.salesmanager.utils.JPAUtility;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
/**
 * This class demonstrates the implementation of the WorkOrderOutput service methods
 * 
 * @author Abin Sam
 */
@Service
public class WorkOrderOutputServiceImpl implements WorkOrderOutputService {

	@Resource
	private WorkOrderOutputRepository workOrderOutputRepository;
	
	@PersistenceContext
	private EntityManager em;


	 /*Method to fetch work order output record based on work order no */

	@Override
	@Transactional
	public List<WorkOrderOutput> fetchLatestBatchNo(String workOrderNo) {
		return em.createQuery("from WorkOrderOutput o where o.productionWorkOrder.workOrderNo='"
						+ workOrderNo
						+ "'  order by o.woOutPutId desc limit 1 ",
				WorkOrderOutput.class).getResultList();
	}
    /*Method to create and save workorder output*/
	 /*Method to create Work order Output */
	@Override
	@Transactional
	public WorkOrderOutput create(WorkOrderOutput workOrderOutput) {
		return workOrderOutputRepository.save(workOrderOutput);
	}


	/*Method to fetch JQGrid paged records of workorder output based on the default search*/
	@Override
	@Transactional
	public Page<WorkOrderOutput> getWoOutputPagedList(String workOrderNo,
			int pageNumber, Integer rowsPerPage, String sortColName,
			String sortOrder) {
		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);
		return workOrderOutputRepository.findByProductionWorkOrderWorkOrderNo(
				workOrderNo, pageable);
	}

	/*Method to update and save workorder output*/
	@Override
	@Transactional
	public Boolean update(WorkOrderOutput woOutput) {
		WorkOrderOutput saved = workOrderOutputRepository.save(woOutput);
		if (saved == null) {
			return false;
		}
		return true;
	}

	/*Method to fetch list of workorder output based on workorder number*/
	@Override
	@Transactional
	public List<WorkOrderOutput> findByWorkOrderNo(String workOrderNo) {
		return workOrderOutputRepository
				.findByProductionWorkOrderWorkOrderNo(workOrderNo);

	}

	/*Method to fetch list of workorder output based on batch number*/
	@Override
	@Transactional
	public List<WorkOrderOutput> findByBatchNo(String batchNo) {
		return workOrderOutputRepository.findByBatchNo(batchNo);
	}

	/*Methos to fetch list of workorder output based on id*/
	@Override
	@Transactional
	public List<WorkOrderOutput> findByWoOutputId(Long id) {
		return workOrderOutputRepository.findByWoOutPutId(id);
	}

	/*Method to delete workorder output based on id*/
	@Override
	@Transactional
	public Boolean delete(Long id) {
		workOrderOutputRepository.delete(id);
		return true;
	}

	/*Method to delete workorder output*/
	@Override
	@Transactional
	public Boolean delete(WorkOrderOutput workOrderOutput) {
		boolean deleted = false;
		if (workOrderOutput != null) {
			workOrderOutputRepository.delete(workOrderOutput);
			deleted = true;
		}//end of if (workOrderOutput != null) condition
		return deleted;
	}

	/*Method to update and save stocked in status of workorder output based on id*/
	@Override
	@Transactional
	public Boolean updateStockedInStatusById(Long id) {
		boolean result = false;
		WorkOrderOutput workOrderOutput = workOrderOutputRepository.findOne(id);
		workOrderOutput.setStockIn("Yes");
		if (workOrderOutputRepository.save(workOrderOutput) != null) {
			result = true;
		}

		return result;

	}

	/*Method to fetch list of workorder output based on salesorder item id and workorder number */
	@Override
	@Transactional
	public List<WorkOrderOutput> findBySoItemIdAndWorkOrderNo(Long soItemId,
			String workOrderNo) {
		// TODO Auto-generated method stub
		return workOrderOutputRepository
				.findBySalesOrderItemOrderDetailIdAndProductionWorkOrderWorkOrderNo(
						soItemId, workOrderNo);
	}

	/*Method to fetch list of workorder output based on salesorder id,item code and workorder number */
	@Override
	@Transactional
	public List<WorkOrderOutput> findByOrderIdAndItemCodeAndWorkOrderNo(
			String soNo, String itemCode, String woNo) {
		// TODO Auto-generated method stub
		return workOrderOutputRepository
				.findBySalesOrderItemOrdersOrderIdAndSalesOrderItemItemsItemCodeAndProductionWorkOrderWorkOrderNo(
						soNo, itemCode, woNo);
	}

	/*Method to fetch list of workorder output based on salesorder item id,workorder number and batch number */
	@Override
	@Transactional
	public List<WorkOrderOutput> findBySoItemIdAndWorkOrderNoAndBatchNo(
			Long orderDetailsId, String workOrderNo, String batchNo) {
		return workOrderOutputRepository
				.findBySalesOrderItemOrderDetailIdAndProductionWorkOrderWorkOrderNoAndBatchNo(
						orderDetailsId, workOrderNo, batchNo);
	}

	/*Method to fetch list of workorder output based on salesorder id,item code,workorder number and batch number*/
	@Override
	@Transactional
	public List<WorkOrderOutput> findByOrderIdAndItemCodeAndWorkOrderNoAndBatchNo(
			String soNo, String itemCode, String woNo, String batchNo) {
		return workOrderOutputRepository
				.findBySalesOrderItemOrdersOrderIdAndSalesOrderItemItemsItemCodeAndProductionWorkOrderWorkOrderNoAndBatchNo(
						soNo, itemCode, woNo, batchNo);

	}
	/*Method to fetch list of workorder output based on salesorder item id*/
	@Override
	@Transactional
	public List<WorkOrderOutput> findBySalesOrderItem(Long soItemId) {
		return workOrderOutputRepository
				.findBySalesOrderItemOrderDetailId(soItemId);
	}
	@Override
	@Transactional
	public Page<WorkOrderOutput> findByPagedSalesOrderItem(
			Long salesOrderItemId, int pageNumber, Integer rowsPerPage,
			String sortColName, String sortOrder) {
		Pageable pageable = JPAUtility.constructPageSpecification(pageNumber,
				rowsPerPage, sortColName, sortOrder);
		return workOrderOutputRepository.findBySalesOrderItemOrderDetailId(
				salesOrderItemId, pageable);
	}

}
