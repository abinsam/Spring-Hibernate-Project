package org.balajicables.salesmanager.utils;

import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

public class JPAUtility {
	 /**
     * Returns a new object which specifies the the wanted result page.
     * @param pageIndex The index of the wanted result page
     * @return
     */
    public static Pageable constructPageSpecification(int pageIndex, int rowsPerPage, String sortColName, String sortOrder) {
        Pageable pageSpecification = new PageRequest(pageIndex, rowsPerPage, sortBy(sortColName,sortOrder));
        return pageSpecification;
    }

    /**
     * Returns a Sort object which sorts persons in ascending order by using the last name.
     * @return
     */
    private static Sort sortBy(String sortField, String sortOrder) {
    	if ("desc".equalsIgnoreCase(sortOrder))  {
    		return new Sort(Sort.Direction.DESC, sortField);
    	}
    	else {
    		return new Sort(Sort.Direction.ASC, sortField);
    	}
    }
}
