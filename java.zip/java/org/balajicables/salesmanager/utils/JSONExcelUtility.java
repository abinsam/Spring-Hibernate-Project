package org.balajicables.salesmanager.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.codehaus.jackson.JsonFactory;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.JsonParser;
import org.codehaus.jackson.JsonToken;

public class JSONExcelUtility {
	public static final String exportFileName = "D:\\test.xls";
	public static final String importFileName = "D:\\test.xls";

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	/**
	 * Parse JSON String to List of Objects.
	 * @param jgGridData
	 * @param columnHeaderList
	 * @return
	 */
	public static List<List<Object>> parseJSON(String jgGridData,
			List<Object> columnHeaderList) {

		JsonFactory jfactory = new JsonFactory();
		List<List<Object>> list = new ArrayList<List<Object>>();
		try {
			JsonParser jParser = jfactory.createJsonParser(jgGridData);

			System.out.println(jParser.toString());
			list.add(columnHeaderList);
			while (jParser.nextToken() != JsonToken.END_ARRAY) {
				List<Object> columnList = new ArrayList<Object>();
				while (jParser.nextToken() != JsonToken.END_OBJECT) {

					String fieldname = jParser.getCurrentName();
					if (columnHeaderList.contains(fieldname)) {
						jParser.nextToken();
						columnList.add(jParser.getText());
						System.out.println(jParser.getText()); // display mkyong
					}
				}
				list.add(columnList);
				System.out.println("Next Array");
			}

		} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;

	}
	
	/**
	 * Create excel file using list provided.
	 * @param list
	 */
	public static void exportTOExcel(List<List<Object>> list) {

		HSSFWorkbook workbook = new HSSFWorkbook();
		HSSFSheet sheet = workbook.createSheet("Sample sheet");

		int rownum = 0;
		for (List<Object> objArr : list) {
			Row row = sheet.createRow(rownum++);
			int cellnum = 0;
			for (Object obj : objArr) {
				Cell cell = row.createCell(cellnum++);
				if (obj instanceof Date)
					cell.setCellValue((Date) obj);
				else if (obj instanceof Boolean)
					cell.setCellValue((Boolean) obj);
				else if (obj instanceof String)
					cell.setCellValue((String) obj);
				else if (obj instanceof Double)
					cell.setCellValue((Double) obj);
			}
		}

		try {
			FileOutputStream out = new FileOutputStream(new File(exportFileName));
			workbook.write(out);
			out.close();
			System.out.println("Excel written successfully..");

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
	
	/**
	 * Import data from Excel file
	 * @return
	 */
	public static List<List<Object>> importFromExcel() {
		List<List<Object>> rowList = new ArrayList<List<Object>>();
		try {
			FileInputStream file = new FileInputStream(new File(importFileName));
			// Get the workbook instance for XLS file
			HSSFWorkbook workbook = new HSSFWorkbook(file);
			// Get first sheet from the workbook
			HSSFSheet sheet = workbook.getSheetAt(0);
			// Iterate through each rows from first sheet
			Iterator<Row> rowIterator = sheet.iterator();
			
			
			while (rowIterator.hasNext()) {
				Row row = rowIterator.next();
				// For each row, iterate through each columns
				Iterator<Cell> cellIterator = row.cellIterator();
				List<Object> columnList = new ArrayList<Object>();
				while (cellIterator.hasNext()) {
					Cell cell = cellIterator.next();
					switch (cell.getCellType()) {
					case Cell.CELL_TYPE_BOOLEAN:
						columnList.add(cell.getBooleanCellValue());
						break;
					case Cell.CELL_TYPE_NUMERIC:
						columnList.add(cell.getNumericCellValue());
						break;
					case Cell.CELL_TYPE_STRING:
						columnList.add(cell.getStringCellValue());
						break;
					}
				}
				rowList.add(columnList);
			}
			 file.close(); 

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return rowList;

	}
	
}
