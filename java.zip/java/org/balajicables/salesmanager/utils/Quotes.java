package org.balajicables.salesmanager.utils;

import java.util.List;

import com.google.common.collect.Lists;

public class Quotes {
	public static List<String> quotes = Lists.newArrayList(
			"");
}
