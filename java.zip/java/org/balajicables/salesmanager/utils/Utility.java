package org.balajicables.salesmanager.utils;



import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

public class Utility {
	//.public static DateTimeFormatter formDateFormatter = DateTimeFormat.forPattern("dd/MM/yyyy");
	//public static DateTimeFormatter formDateFormatter = DateTimeFormat.forPattern("yyyy-MM-dd");
	public static DateTimeFormatter formDateFormatter = DateTimeFormat.forPattern("dd-MM-yyyy");
   
	public static DateTimeFormatter formDateTimeFormatter = DateTimeFormat.forPattern("dd-MM-yyyy-HH-MM-SS");


}
