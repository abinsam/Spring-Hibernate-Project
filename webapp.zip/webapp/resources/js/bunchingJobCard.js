var lastSelected;
var netLengthValid = true;
var grossWeightValid = true;
var tareWeightValid = true;
var lengthPerDrumValid = true;
var odValid = true;
var systemDate = new Date();
var month="";
var year="";
$(function() {

	$("#monthYearPicker").focus(function () {$(".ui-datepicker-calendar").hide();});
	$('#monthYearPicker').datepicker({
	
        changeYear: true,
        changeMonth: true,
        changeDate :false,
        showButtonPanel: true,
        dateFormat: 'MM yy',
       
        onClose: function(dateText, inst) { 
            year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
           month = $("#ui-datepicker-div .ui-datepicker-month :selected").val();
            $(this).datepicker('setDate', new Date(year,month, 1));
        }
    });	

	$('#monthYearPicker').datepicker('setDate',systemDate); 
    $("#monthYearPicker").focus(function () {$(".ui-datepicker-month").show();});
    $("#monthYearPicker").focus(function () {$(".ui-datepicker-year").show();});

	$("#bunchingWorkOrderNoSelect").chosen({no_results_text : "No results matched"});
	$("#bunchingSize").chosen({no_results_text : "No results matched"});
	$("#workOrderStatusSelect").chosen({no_results_text: "No results matched"});

	$("#viewBunchingWorkOrderGrid")
			.jqGrid(
					{
						mtype : 'POST',

						colNames : [ 'woOutPutId', 'bunchingWorkOrderNoSelect',
								'Batch No', 'Size', 'Net Length(mts)*',
								'Gross Weight(Kgs)*', 'Tare Weight(Kgs)*',
								'Net Weight(Kgs)', 'Outer Diameter*',
								'Stocked In Status', 'Stocked In Status',
								'Stock In','Label', 'Srcap Details', 'Action' ],
						colModel : [
								{
									name : "woOutPutId",
									index : "woOutPutId",
									width : 20,
									hidden : true
								},
								{
									name : "workOrderNo",
									index : "workOrderNo",
									width : 20,
									editable : false,
									hidden : true
								},
								{
									name : 'batchNo',
									index : 'batchNo',
									width : 80,
									editable : false
								},
								{
									name : 'size',
									index : 'size',
									width : 110,
									editable : false
								},
								{
									name : 'netLength',
									index : 'netLength',
									width : 100,
									editable : true,
									editoptions : {
										dataInit : function(element) {
											$(element)
													.keyup(
															function() {
																var val1 = element.value;
																var num = new Number(
																		val1);
																if (isNaN(num)) {
																	alert("Please enter valid length");
																	netLengthValid = false;
																	jQuery(
																			"#viewBunchingWorkOrderGrid")
																			.trigger(
																					'reloadGrid');
																} else
																	netLengthValid = true;

															});
										},
										maxlength : 8
									}
								},
								{
									name : 'grossWeight',
									index : 'grossWeight',
									width : 100,
									editable : true,
									editoptions : {
										dataInit : function(element) {
											$(element)
													.keyup(
															function() {
																var val1 = element.value;
																var num = new Number(
																		val1);
																if (isNaN(num)) {
																	alert("Please enter valid Gross Weight");
																	grossWeightValid = false;
																	jQuery(
																			"#viewBunchingWorkOrderGrid")
																			.trigger(
																					'reloadGrid');
																} else
																	grossWeightValid = true;

															});
										},
										maxlength : 8
									}
								},
								{
									name : 'tareWeight',
									index : 'tareWeight',
									width : 100,
									editable : true,
									editoptions : {
										dataInit : function(element) {
											$(element)
													.keyup(
															function() {
																var val1 = element.value;
																var num = new Number(
																		val1);
																if (isNaN(num)) {
																	alert("Please enter valid Tare Weight");
																	tareWeightValid = false;
																	jQuery(
																			"#viewBunchingWorkOrderGrid")
																			.trigger(
																					'reloadGrid');
																} else
																	tareWeightValid = true;

															});
										},
										maxlength : 8
									}
								},
								{
									name : 'netWeight',
									index : 'netWeight',
									width : 100,
									editable : false,
									viewable : false
								},
								{
									name : 'outerDiameter',
									index : 'outerDiameter',
									width : 100,
									editable : true,
									editoptions : {
										dataInit : function(element) {
											$(element)
													.keyup(
															function() {
																var val1 = element.value;
																var num = new Number(
																		val1);
																if (isNaN(num)) {
																	alert("Please enter Outer diamter");
																	odValid = false;
																	jQuery(
																			"#viewBunchingWorkOrderGrid")
																			.trigger(
																					'reloadGrid');
																} else
																	odValid = true;

															});
										},
										maxlength : 8
									},hidden:true
								},

								{
									name : 'stockIn',
									index : 'stockIn',
									width : 100,
									editable : false
								}, {
									name : 'stockIn',
									index : 'stockIn',
									hidden : true,
									editable : true
								}, {
									name : 'stockLink',
									index : 'stockLink',
									width : 70,
									editable : false,
									sortable : false
								}, 
								{name:'semiLink',index:'semiLink',width:100, editable:false,sortable : false},  
								{
									name : 'scrapLink',
									index : 'scrapLink',
									width : 10,
									editable : false,
									hidden : true,
									sortable : false
								}, 
								
								{
									name : 'act',
									index : 'act',
									width : 70,
									sortable : false,
									viewable : false
								} ],
						postData : {},
						rowNum : 100,
						rowList : [ 10, 20, 40, 60,100 ],
						height :300,
						width : 1400,
						footerrow : true,
						rownumbers : false,
						pager : '#viewBunchingWorkOrderPager',
						sortname : 'woOutPutId',
						viewrecords : true,
						sortorder : "desc",
						caption : "",
						emptyrecords : "Empty records",
						loadonce : false,

						jsonReader : {
							root : "rows",
							page : "page",
							total : "total",
							records : "records",
							repeatitems : false,
							cell : "cell",
							id : "woOutPutId"
						},
						ondblClickRow : function(id) {
							if (id && id !== lastSelected) {
								$('#viewBunchingWorkOrderGrid').jqGrid(
										'restoreRow', lastSelected);
								editRow2(id);
								lastSelected = id;
							}
						},
						gridComplete : function() {

							var netLength = $('#viewBunchingWorkOrderGrid')
									.jqGrid('getCol', 'netLength', false, 'sum');
							var grossWeight = $('#viewBunchingWorkOrderGrid')
									.jqGrid('getCol', 'grossWeight', false,
											'sum');
							var tareWeight = $('#viewBunchingWorkOrderGrid')
									.jqGrid('getCol', 'tareWeight', false,
											'sum');
							var netWeight = $('#viewBunchingWorkOrderGrid')
									.jqGrid('getCol', 'netWeight', false, 'sum');

							var totalNetLength = Math
									.round(parseFloat(netLength) * 100) / 100;
							var totalGross = Math
									.round(parseFloat(grossWeight) * 100) / 100;
							var totalTare = Math
									.round(parseFloat(tareWeight) * 100) / 100;
							var totalNetWeight = Math
									.round(parseFloat(netWeight) * 100) / 100;

							$('#viewBunchingWorkOrderGrid').jqGrid(
									'footerData', 'set', {
										ID : 'Total:',
										netLength : totalNetLength
									});
							$('#viewBunchingWorkOrderGrid').jqGrid(
									'footerData', 'set', {
										ID : 'Total:',
										grossWeight : totalGross
									});
							$('#viewBunchingWorkOrderGrid').jqGrid(
									'footerData', 'set', {
										ID : 'Total:',
										tareWeight : totalTare
									});
							$('#viewBunchingWorkOrderGrid').jqGrid(
									'footerData', 'set', {
										ID : 'Total:',
										netWeight : totalNetWeight
									});

							var ids = jQuery("#viewBunchingWorkOrderGrid")
									.jqGrid('getDataIDs');
							for ( var i = 0; i < ids.length; i++) {
								var cl = ids[i];
								
								 var woId = jQuery("#viewBunchingWorkOrderGrid").jqGrid ('getCell', cl, 'woOutPutId'); 
			
								
								be = "<input style='height:22px; width:35px;' type='button' value='Edit' id='editRow2"
										+ cl
										+ "' onclick=\"editRow2('"
										+ cl
										+ "');\" />";
								de = "<input style='height:22px; width:30px;' type='button' value='Del' id='delRow2"
										+ cl
										+ "' onclick=\"delRow2('"
										+ cl
										+ "');\" />";
								se = "<input style='height:22px; width: 29px;' type='button' value='Save' hidden='hidden'  id='saveRow2"
										+ cl
										+ "' onclick=\"saveRow2('"
										+ cl
										+ "');\" />";
								ce = "<input style='height:22px;width:39px;' type='button' value='Cancel' hidden='hidden' id='restoreRow2"
										+ cl
										+ "' onclick=\"restoreRow2('"
										+ cl
										+ "');\" />";
								sdLink = "<button class='btn btn-mini' id='itemDetailsLink"
										+ cl
										+ "'"
										+ "onclick=\"stockInBunching('"
										+ cl
										+ "');\" >Stock In </button>";
								sfLink = "<button class='btn btn-mini' id='semifinishedLabel"+cl+"'" +" onclick=\"location.href='viewBunchingWorkOrder/semiFinishedLabelReport?woId="+woId+"';\" >Label</button>";
								
								scrLink = "<button class='btn btn-mini' id='itemDetailsLink"
										+ cl
										+ "'"
										+ "onclick=\"scrapDetails('"
										+ cl + "');\" >Scrap Details </button>";

								$("#viewBunchingWorkOrderGrid").jqGrid(
										'setRowData', ids[i], {
											act : be + de + se + ce,
											stockLink : sdLink,
											semiLink :sfLink,
											scrapLink : scrLink

										});
								if (document.getElementById('woStatus').value == "Submitted") {
									document.getElementById('addBtn').disabled = true;
									document
											.getElementById('submitBunchingWorkOrder').disabled = true;
								}
								if ($("#viewBunchingWorkOrderGrid").getCell(cl,"stockIn") == "Yes") {
									$("#viewBunchingWorkOrderGrid").jqGrid(
											'setRowData', ids[i], false, {
												color : 'black',
												weightfont : 'bold',
												background : '#90ee90'
											});
								}
							}
						},
						editurl : "viewBunchingWorkOrder/crud"

					});
	$("#viewBunchingWorkOrderGrid").jqGrid('navGrid',
			"#viewBunchingWorkOrderPager", {
				edit : false,
				add : false,
				del : false,
				view : false,
				search : false
			});

	$("#storeRegisterForBunchingGrid")
			.jqGrid(
					{
						mtype : 'POST',
						multiselect : true,
						colNames : [ 'bunchWoInputId', 'workOrderNo',
								'Bunching Size', 'No Of Drums', 'Length/Drum(mts)','Net Length(mts)','Toatl Qty',
								'Lay Length', 'Partyhidden', 'Party','seelct','Action' ],
						colModel : [

								{
									name : 'bunchWoInputId',
									index : 'bunchWoInputId',
									width : 10,
									hidden : true
								},
								{
									name : 'workOrderNo',
									index : 'workOrderNo',
									width : 10,
									hidden : true,
									editable : true
								},
								{
									name : 'size',
									index : 'size',
									width : 50,
									editable : false
								},
								{
									name : 'noOfDrums',
									index : 'noOfDrums',
									width : 30,
									editable : false
								},
								{
									name : 'lengthPerDrum',
									index : 'lengthPerDrum',
									width : 30,
									editable : true,
									editoptions : {
										dataInit : function(element) {
											$(element)
													.keyup(
															function() {
																var val1 = element.value;
																var num = new Number(
																		val1);
																if (isNaN(num)) {
																	alert("Please enter valid Length per drum");
																	lengthPerDrumValid = false;
																	jQuery(
																			"#storeRegisterForBunchingGrid")
																			.trigger(
																					'reloadGrid');
																} else
																	lengthPerDrumValid = true;

															});
										},
										maxlength : 8
									}
								},{
									name : 'netLength',
									index : 'netLength',
									width : 30,
									editable : false
								},{
									name : 'totalQty',
									index : 'totalQty',
									width : 50,
									editable : false
							   },{
									name : 'layLength',
									index : 'layLength',
									width : 30,
									editable : false
								}, {
									name : 'customerName',
									index : 'customerName',
									width : 60,
									editable : false,
									hidden:true
								},
								{
									name : 'customerCode',
									index : 'customerCode',
									width : 50,
									editable : false
								}, 
								{
									name:'selectStatus', 
									index:'selectStatus',
									width:50,
									editable : false,
									hidden:true
									
								},{
									name : 'act',
									index : 'act',
									width : 30,
									sortable : false
								} ],
						postData : {},
						rowNum : 100,
						rowList : [ 5, 10, 20, 40, 60, 100 ],
						height :280,
						width : 700,
						rownumbers : false,
						 footerrow: true,
						pager : '#storeRegisterForBunchingPager',
						sortname : 'bunchWoInputId',
						viewrecords : true,
						sortorder : "desc",
						caption : "Work Order Input",
						emptyrecords : "Empty records",
						loadonce : false,
						jsonReader : {
							root : "rows",
							page : "page",
							total : "total",
							records : "records",
							repeatitems : false,
							cell : "cell",
							id : "bunchWoInputId"
						},
						onSelectRow : updateIdsOfSelectedRows,
						onSelectAll : function(aRowids, isSelected) {
							var i, count, id;
							for (i = 0, count = aRowids.length; i < count; i++) {
								id = aRowids[i];
								updateIdsOfSelectedRows(id, isSelected);
							}
						},
						ondblClickRow : function(id) {
							if (id && id !== lastSelected) {
								$('#storeRegisterForBunchingGrid').jqGrid(
										'restoreRow', lastSelected);
								editRow1(id);
								lastSelected = id;
							}
						},
						gridComplete : function() {
							 var totalQty = $('#storeRegisterForBunchingGrid').jqGrid('getCol','totalQty',false,'sum');
			    	   		 var netLength = $('#storeRegisterForBunchingGrid').jqGrid('getCol','netLength',false,'sum');
			    	   		 var drumCount = $('#storeRegisterForBunchingGrid').jqGrid('getCol','noOfDrums',false,'sum');

			    	   		var totQtyVal=Math.round(parseFloat(totalQty) * 100) / 100;
			    	   		var totalNet=Math.round(parseFloat(netLength) * 100) / 100;
			    	   		var totalDrums=Math.round(parseFloat(drumCount) * 100) / 100;
			    	   		
			    	   		$('#storeRegisterForBunchingGrid').jqGrid('footerData','set', {ID: 'Total:', totalQty: totQtyVal});
				   	    	$('#storeRegisterForBunchingGrid').jqGrid('footerData','set', {ID: 'Total:', netLength: totalNet});
				   	    	$('#storeRegisterForBunchingGrid').jqGrid('footerData','set', {ID: 'Total:', noOfDrums: totalDrums});
 
			    	   		 
			    	   		 
			    	   		 
							var ids = jQuery("#storeRegisterForBunchingGrid")
									.jqGrid('getDataIDs');
							for ( var i = 0; i < ids.length; i++) {
								var cl = ids[i];
								be = "<input style='height:22px; width:35px;' type='button' value='Edit' id='editRow1"
										+ cl
										+ "' onclick=\"editRow1('"
										+ cl
										+ "');\" />";
								se = "<input style='height:22px; width: 29px;' type='button' value='Save' hidden='hidden'  id='saveRow1"
										+ cl
										+ "' onclick=\"saveRow1('"
										+ cl
										+ "');\" />";
								ce = "<input style='height:22px;width:39px;' type='button' value='Cancel' hidden='hidden' id='restoreRow1"
										+ cl
										+ "' onclick=\"restoreRow1('"
										+ cl
										+ "');\" />";

								$("#storeRegisterForBunchingGrid").jqGrid(
										'setRowData', ids[i], {
											act : be + se + ce
										});
								if ($("#storeRegisterForBunchingGrid").getCell(cl,"selectStatus") == "Yes") {
									$("#storeRegisterForBunchingGrid").jqGrid('setRowData', ids[i], false, {color : 'black',weightfont : 'bold',background : '#F6E3CE'});
								}
							}
						},
						editurl : "viewBunchingWorkOrder/crudForFirstGrid"

					}).navGrid('#storeRegisterForBunchingPager', {
				view : false,
				del : false,
				edit : false,
				search : false,
				add : false
			}, {}, // use default settings for edit
			{}, // settings for add
			{}, // delete instead that del:false we need this
			{
				multipleSearch : true
			}, // enable the advanced searching
			{} /* allow the view dialog to be closed when user press ESC key */
			);

});

$("#bunchingWorkOrderNoSelect")
		.chosen()
		.change(
				function() {
					var woNo = $('#bunchingWorkOrderNoSelect').val();

					$
							.ajax({
								type : 'POST',
								url : 'viewBunchingWorkOrder/getWODetails/'
										+ encodeURIComponent(woNo),
								success : function(response) {

									document
											.getElementById('bunchingStartDate').value = response[0];
									document
											.getElementById('bunchingCompletionDate').value = response[1];
									document
											.getElementById('bunchingMachineNo').value = response[2];
									document.getElementById('woStatus').value = response[3];

									/*
									 * var valueList = response[4];
									 * $('#bunchingSize').empty(); for(var i=0;i<
									 * valueList.length;i++){
									 * $('#bunchingSize').append('<option
									 * >'+valueList[i]+'</option>');
									 * $('#bunchingSize').trigger('liszt:updated'); }
									 */
									jQuery("#storeRegisterForBunchingGrid")
											.setGridParam({
												datatype : 'json'
											});
									jQuery("#storeRegisterForBunchingGrid")
											.setGridParam(
													{
														url : 'viewBunchingWorkOrder/populateWODetailsGrid/'
																+ encodeURIComponent(woNo)
													});
									jQuery("#storeRegisterForBunchingGrid")
											.setCaption(
													'Input of Work Order :'
															+ woNo);
									jQuery("#storeRegisterForBunchingGrid")
											.trigger('reloadGrid');

									jQuery("#stockOutBunchingGrid")
											.setGridParam({
												datatype : 'json'
											});
									jQuery("#stockOutBunchingGrid")
											.setGridParam(
													{
														url : 'viewBunchingWorkOrder/woStockOutRecords/'
																+ encodeURIComponent(woNo)
													});
									jQuery("#stockOutBunchingGrid").setCaption(
											'Semi Finished Goods Stocked Out for Work Order :'
													+ woNo);
									jQuery("#stockOutBunchingGrid").trigger(
											'reloadGrid');

									jQuery("#viewBunchingWorkOrderGrid")
											.setGridParam({
												datatype : 'json'
											});
									jQuery("#viewBunchingWorkOrderGrid")
											.setGridParam(
													{
														url : 'viewBunchingWorkOrder/records/'
																+ encodeURIComponent(woNo)
													});
									jQuery("#viewBunchingWorkOrderGrid")
											.trigger('reloadGrid');

									if (document.getElementById('woStatus').value == "Submitted") {
										document.getElementById('addBtn').disabled = true;
										document
												.getElementById('submitBunchingWorkOrder').disabled = true;
									} else {
										document.getElementById('addBtn').disabled = false;
										document
												.getElementById('submitBunchingWorkOrder').disabled = false;
									}
								}
							});

				});

function editRow2(id) {
	var grid = jQuery('#viewBunchingWorkOrderGrid');
	var stockInStatus = grid.jqGrid('getCell', id, 'stockIn');
	var batchNo = grid.jqGrid('getCell', id, 'batchNo');
	if (stockInStatus != 'Yes') {
		restoreRow2(lastSelected);
		lastSelected = id;
		var woStatus = document.getElementById('woStatus').value;
		var woNo = $('#bunchingWorkOrderNoSelect').val();

		if (woStatus == 'Submitted') {
			alert("The Work Order " + woNo + " Is In Submitted State");

		} else {
			$('#viewBunchingWorkOrderGrid').jqGrid('editRow', id, {
				"keys" : true,
				"oneditfunc" : hideActButtons2,
				aftersavefunc : function(savedId, response) {
					showActButtons2(savedId);
				},
				afterrestorefunc : showActButtons2
			});
		}

	} else {
		alert("The Work Order Output " + batchNo + " is stocked in");
	}
}
function delRow2(id) {
	var grid = jQuery('#viewBunchingWorkOrderGrid');
	var stockInStatus = grid.jqGrid('getCell', id, 'stockIn');
	var batchNo = grid.jqGrid('getCell', id, 'batchNo');

	if (stockInStatus == 'Yes') {
		alert("The Work Order Output " + batchNo + " is stocked in");
	} else {
		if (confirm("Are you sure you want to delete ?")) {
			var oper = "del";
			$.ajax({
				type : 'POST',
				url : 'viewBunchingWorkOrder/crud',
				data : {
					'id' : id,
					'oper' : oper
				},
				success : function(response) {
					jQuery("#viewBunchingWorkOrderGrid").trigger('reloadGrid');
				}
			});

		}
		;
	}
}

function saveRow2(id) {
	if (netLengthValid == true && grossWeightValid == true
			&& tareWeightValid == true && lengthPerDrumValid == true) {
		$('#viewBunchingWorkOrderGrid')
				.saveRow(
						id,
						{
							aftersavefunc : function(id, response) {
								showActButtons1(id);
								var grid = jQuery('#viewBunchingWorkOrderGrid');
								var grossWt = grid.jqGrid('getCell', id,
										'grossWeight');
								var tareWt = grid.jqGrid('getCell', id,
										'tareWeight');
								if (grossWt != null
										&& tareWt != null
										&& parseFloat(grossWt) >= parseFloat(tareWt)) {
									var netWght = grossWt - tareWt;
									grid.jqGrid('setCell', id, 'netWeight',
											netWght);
								} else if (parseFloat(grossWt) < parseFloat(tareWt)) {
									alert("Gross Weight should be greater than Tare Weight");
									grid
											.jqGrid('setCell', id,
													'grossWeight', 0);
									grid.jqGrid('setCell', id, 'tareWeight', 0);
									grid.jqGrid('setCell', id, 'netWeight', 0);
								} else {
									grid.jqGrid('setCell', id, 'netWeight', 0);
								}
								jQuery("#viewBunchingWorkOrderGrid").trigger(
										'reloadGrid');
							}
						});
	} else if (netLengthValid == false) {
		alert("Enter Valid Length");
	} else if (grossWeightValid == false) {
		alert("Enter Valid Gross Weight");
	} else if (tareWeightValid == false) {
		alert("Enter Valid Tare Weight");
	} else if (lengthPerDrumValid == false) {
		alert("Enter Valid Length per Drum");
	}
}

function restoreRow2(id) {
	$('#viewBunchingWorkOrderGrid').jqGrid('restoreRow', id, {
		afterrestorefunc : showActButtons2

	});
}

function editRow1(id) {
	restoreRow1(lastSelected);
	lastSelected = id;

	var woNo = document.getElementById('bunchingWorkOrderNoSelect').value;
	var woStatus = document.getElementById('woStatus').value;

	if (woStatus == 'Submitted') {
		alert("The Work Order " + woNo + " Is In Submitted State");

	} else {
		$('#storeRegisterForBunchingGrid').jqGrid('editRow', id, {
			"keys" : true,
			"oneditfunc" : hideActButtons1,
			aftersavefunc : function(savedId, response) {
				showActButtons1(savedId);
			},
			afterrestorefunc : showActButtons1
		});
	}

}

function addOutputRow() {
	$
			.ajax({
				type : 'POST',
				url : 'viewBunchingWorkOrder/createBunchingWoOutput',
				data : {
					'idsOfSelectedRows' : idsOfSelectedRows
				},
				success : function(response) {
					var woNo = document
							.getElementById('bunchingWorkOrderNoSelect').value;

					jQuery("#viewBunchingWorkOrderGrid").setGridParam({	datatype : 'json'});
					jQuery("#viewBunchingWorkOrderGrid").setGridParam({	url : 'viewBunchingWorkOrder/records/'+ encodeURIComponent(woNo)});
					jQuery("#viewBunchingWorkOrderGrid").trigger('reloadGrid');

					jQuery("#storeRegisterForBunchingGrid").setGridParam({datatype : 'json'			});
			        jQuery("#storeRegisterForBunchingGrid")	.setGridParam({	url : 'viewBunchingWorkOrder/populateWODetailsGrid/'+ encodeURIComponent(woNo)});
			        jQuery("#storeRegisterForBunchingGrid").setCaption('Input of Work Order :'+ woNo);
			        jQuery("#storeRegisterForBunchingGrid").trigger('reloadGrid');
					idsOfSelectedRows = [];	
	 
				}
			});

}

/*
 * function delRow1(id) { var
 * woNo=document.getElementById('bunchingWorkOrderNoSelect').value; var
 * woStatus= document.getElementById('woStatus').value;
 * 
 * if(woStatus == 'Submitted'){ alert("The Work Order "+woNo+" Is In Submitted
 * State");
 * 
 * }else{ if(confirm("Are you sure you want to delete ?")){ var oper ="del";
 * $.ajax({type:'POST', url: 'viewBunchingWorkOrder/crudForFirstGrid',
 * data:{'id':id,'oper':oper}, success: function(response) {
 * jQuery("#storeRegisterForBunchingGrid").trigger('reloadGrid'); }});
 *  }; } }
 */

function saveRow1(id) {
	if (lengthPerDrumValid == true) {
		$('#storeRegisterForRBDGrid')
				.saveRow(
						id,
						{
							aftersavefunc : function(id, response) {
								var grid = jQuery('#storeRegisterForRBDGrid');
								var annealingPercent = grid.jqGrid('getCell',
										id, 'anealingPercent');
								if (annealingPercent == null
										|| annealingPercent == "") {
									alert("Enter valid annealing percent");
								}

								showActButtons2(id);
								jQuery("#storeRegisterForRBDGrid").trigger(
										'reloadGrid');
							}
						});
	} else if (lengthPerDrumValid == false) {
		alert("Enter valid Length per drum");
	}
}

function restoreRow1(id) {
	$('#storeRegisterForBunchingGrid').jqGrid('restoreRow', id, {
		afterrestorefunc : showActButtons1
	});
}

idsOfSelectedRows = [ "1", "2", "3" ];
var $StoreRegisterForRBDGrid = $("#storeRegisterForRBDGrid"), idsOfSelectedRows = [], updateIdsOfSelectedRows = function(
		id, isSelected) {
	var index = $.inArray(id, idsOfSelectedRows);
	if (!isSelected && index >= 0) {
		idsOfSelectedRows.splice(index, 1); // remove id from the list
	} else if (index < 0) {
		idsOfSelectedRows.push(id);
	}
};

/*
 * Hides the Edit and Del Row Buttons on jqGrid and activates the Save and
 * restore(cancel) button
 * 
 */

function hideActButtons1(id) {
	$('#editRow1' + id).hide();
	$('#delRow1' + id).hide();
	$('#saveRow1' + id).show();
	$('#restoreRow1' + id).show();
}

/*
 * Shows the Edit and Del Row Buttons on jqGrid and hides the Save and
 * restore(cancel) button
 * 
 */
function showActButtons1(id) {
	$('#editRow1' + id).show();
	$('#delRow1' + id).show();
	$('#saveRow1' + id).hide();
	$('#restoreRow1' + id).hide();
	lastSelected = null;
}
function hideActButtons2(id) {
	$('#editRow2' + id).hide();
	$('#delRow2' + id).hide();
	$('#saveRow2' + id).show();
	$('#restoreRow2' + id).show();
}

/*
 * Shows the Edit and Del Row Buttons on jqGrid and hides the Save and
 * restore(cancel) button
 * 
 */
function showActButtons2(id) {
	$('#editRow2' + id).show();
	$('#delRow2' + id).show();
	$('#saveRow2' + id).hide();
	$('#restoreRow2' + id).hide();
	lastSelected = null;
}

function submitBunchingWorkOrderFn() {
	var woStatus = document.getElementById('woStatus').value;
	var woNo = $('#bunchingWorkOrderNoSelect').val();
	// alert(woStatus);
	var stockInStatusCount = 0;
	var ids = jQuery("#viewBunchingWorkOrderGrid").jqGrid('getDataIDs');
	for ( var i = 0; i < ids.length; i++) {
		var cl = ids[i];
		var stockInStatus = jQuery("#viewBunchingWorkOrderGrid").jqGrid(
				'getCell', cl, 'stockIn');
		if (stockInStatus == "No")
			stockInStatusCount++;
	}
	if (woStatus == 'Submitted') {
		alert("The Work Order " + woNo + " Is Already In Submitted State");

	} else if (stockInStatusCount != 0) {
		alert("All Outputs should be stocked in for submitting " + woNo);
	} else if ($("#viewBunchingWorkOrderGrid").getGridParam("reccount") == 0) {
		alert("Output should be there for submitting " + woNo);
	} else {
		if (confirm("Are You Sure You Want To Submit?")) {
			$.ajax({
				type : 'POST',
				url : 'viewBunchingWorkOrder/submitBunchingWorkOrder/'
						+ encodeURIComponent(woNo),
				success : function(response) {
					document.getElementById('addBtn').disabled = true;
					document.getElementById('woStatus').value = "Submitted";
					alert("The Work Order " + woNo + " Is Submitted.");
				}
			});
		}
	}
}

function stockInBunching(id) {
	// restoreRow2(id);
	var grid = jQuery('#viewBunchingWorkOrderGrid');
	var stockInStatus = grid.jqGrid('getCell', id, 'stockIn');
	var batchNo = grid.jqGrid('getCell', id, 'batchNo');
	var size = grid.jqGrid('getCell', id, 'size');
	var netLength = grid.jqGrid('getCell', id, 'netLength');
	var grossWeight = grid.jqGrid('getCell', id, 'grossWeight');
	var tareWeight = grid.jqGrid('getCell', id, 'tareWeight');
//	/var od = grid.jqGrid('getCell', id, 'outerDiameter');
	// var woStatus= document.getElementById('woStatus').value;
	var woNo = $('#bunchingWorkOrderNoSelect').val();
	/*
	 * if(woStatus == 'Submitted'){ alert("The Work Order "+woNo+" Is Already In
	 * Submitted State");
	 * 
	 * }else{
	 */
	if (netLength == 0 || grossWeight == 0 || tareWeight == 0 ) {
		alert("Please Enter Essential Data for stock In i.e. Net Length, Gross Weight or Tare Weight,Od");
	} else {
		if (stockInStatus == 'Yes') {
			alert("Batch " + batchNo + " Of Size " + size
					+ " Has Already Been Stocked In.");
		} else {
			if (confirm("Are You Sure You Want To Stock In?")) {
				saveRow2(id);
				$.ajax({
					type : 'POST',
					url : 'viewBunchingWorkOrder/stockInBunching/'
							+ encodeURIComponent(id),
					success : function(response) {
						jQuery("#viewBunchingWorkOrderGrid").setGridParam({
							datatype : 'json'
						});
						jQuery("#viewBunchingWorkOrderGrid").setGridParam(
								{
									url : 'viewBunchingWorkOrder/records/'
											+ encodeURIComponent(woNo)
								});
						jQuery("#viewBunchingWorkOrderGrid").trigger(
								'reloadGrid');

					}
				});
			}
		}
	}
	// }
}

$(document)
		.keypress(
				function(e) {
					if (e.which == 13) {
						var ids = $("#viewBunchingWorkOrderGrid").jqGrid(
								'getDataIDs');
						for ( var i = 0; i < ids.length; i++) {
							var cl = ids[i];
							var grid = jQuery('#viewBunchingWorkOrderGrid');
							var grossWt = grid.jqGrid('getCell', cl,
									'grossWeight');
							var tareWt = grid.jqGrid('getCell', cl,
									'tareWeight');
							if (grossWt != null
									&& tareWt != null
									&& (parseFloat(grossWt) >= parseFloat(tareWt))) {
								var netWght = grossWt - tareWt;

								grid
										.jqGrid('setCell', cl, 'netWeight',
												netWght);
								saveRow2(cl);
							} else if (parseFloat(grossWt) < parseFloat(tareWt)) {
								alert("Gross Weight should be greater than Tare Weight");
								grid.jqGrid('setCell', cl, 'grossWeight', 0);
								grid.jqGrid('setCell', cl, 'tareWeight', 0);
								grid.jqGrid('setCell', cl, 'netWeight', 0);
							} else {
								grid.jqGrid('setCell', cl, 'netWeight', 0);
							}

						}
						jQuery("#viewBunchingWorkOrderGrid").trigger(
								'reloadGrid');
					}
				});

$(function() {
	$("#stockOutBunchingGrid").jqGrid(
			{
				mtype : 'POST',
				colNames : [ 'semifinishedStockOutId', 'WorkOrder No',
						'Item Description', 'Bundle Id', 'Stock Out Qty', 'Weight' ,'Actions'],
				colModel : [

				{
					name : 'semifinishedStockOutId',
					index : 'semifinishedStockOutId',
					width : 10,
					hidden : true
				}, {
					name : 'workOrderNo',
					index : 'workOrderNo',
					width : 40,
					editable : false
				}, {
					name : 'itemDescription',
					index : 'itemDescription',
					width : 100,
					editable : false
				}, {
					name : 'bundleId',
					index : 'bundleId',
					width : 30,
					editable : false
				}, {
					name : 'stockOutQty',
					index : 'stockOutQty',
					width : 40,
					editable : false
				}, {
					name : 'weight',
					index : 'weight',
					width : 30,
					editable : false
				},{
					name : 'act',
					index : 'act',
					width : 10,
					editable : false,
					sortable:false
				} ],
				postData : {},
				rowNum : 100,
				rowList : [ 5, 10, 20, 40, 60, 100 ],
				height : 280,
				width : 700,
				rownumbers : false,
				pager : '#stockOutBunchingPager',
				sortname : 'semifinishedStockOutId',
				viewrecords : true,
				sortorder : "desc",
				caption : "Semi Finished Goods Stock Out",
				emptyrecords : "Empty records",
				footerrow : true,
				loadonce : false,
				jsonReader : {
					root : "rows",
					page : "page",
					total : "total",
					records : "records",
					repeatitems : false,
					cell : "cell",
					id : "semifinishedStockOutId"
				},
				gridComplete : function() {
					var stockOutQty = $('#stockOutBunchingGrid').jqGrid('getCol', 'stockOutQty', false, 'sum');
					var weight = $('#stockOutBunchingGrid').jqGrid('getCol', 'weight', false,'sum');
					
						var totalStockOutQty = Math.round(parseFloat(stockOutQty) * 100) / 100;
						var totalWeight = Math.round(parseFloat(weight) * 100) / 100;
						$('#stockOutBunchingGrid').jqGrid(	'footerData', 'set', {ID : 'Total:',stockOutQty : totalStockOutQty});
						$('#stockOutBunchingGrid').jqGrid('footerData', 'set', {ID : 'Total:',	weight : totalWeight});
			
					var ids = jQuery("#stockOutBunchingGrid").jqGrid('getDataIDs');
					for ( var i = 0; i < ids.length; i++) {
							var cl = ids[i];
						de = "<input style='height:22px; width: 29px;' type='button' value='Del'   id='delsemifinished"+ cl	+ "' onclick=\"delsemifinishedStock('"+ cl+ "');\" />";
						$("#stockOutBunchingGrid").jqGrid('setRowData', ids[i], {
							act : de});
					}
				}
			}).navGrid('#stockOutBunchingPager', {
		view : false,
		del : false,
		edit : false,
		search : false,
		add : false
	});
});


function delsemifinishedStock(id) {
	 var woNo=document.getElementById('bunchingWorkOrderNoSelect').value;
	if(confirm("Are you sure you want to delete the stocked out?")){
	      $.ajax({type:'POST', 
	        url: 'stockOutSemiFinished/delete',
	        data:{'id':id},
	        success: function() {
	        alert("Semifinished items stocked out for "+woNo+" is deleted");
	        jQuery("#stockOutBunchingGrid").setGridParam({datatype : 'json'});
		    jQuery("#stockOutBunchingGrid").setGridParam({url : 'viewBunchingWorkOrder/woStockOutRecords/'+ encodeURIComponent(woNo)});
		   jQuery("#stockOutBunchingGrid").setCaption('Semi Finished Goods Stocked Out for Work Order :'+ woNo);
		   jQuery("#stockOutBunchingGrid").trigger('reloadGrid');

	    
	      }});
	    }
	   

	} 
function validateSearchParams(){

	  if($("#monthYearPicker").val()=="" || $("#monthYearPicker").val()==null){
	    	alert("Month and Year empty! please select month and year");
	    	return false;
	    }
	    else return true;
}

$("#workOrderStatusSelect")
		.chosen()
		.change(
				function() {
					
					var validSearch=validateSearchParams();
					
					if(validSearch==true){
					
					var status = $('#workOrderStatusSelect').val();
					$('#bunchingWorkOrderNoSelect').children().remove();
					$('#bunchingWorkOrderNoSelect').val('').trigger(
							'liszt:updated');
					document.getElementById('bunchingStartDate').value = "";
					document.getElementById('bunchingCompletionDate').value = "";
					document.getElementById('bunchingMachineNo').value = "";
					
					 month = $("#ui-datepicker-div .ui-datepicker-month :selected").val();
				     year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
					$
							.ajax({
								type : 'POST',
								url : 'viewMWDWorkOrder/getWorkOrderNos/'+ encodeURIComponent(status),
								data : {"processType" : "Bunching","month":month,"year":year},
								success : function(response) {
									$('#bunchingWorkOrderNoSelect').empty();
									if (response.length == 0) {

										alert("There is no Work Order for selected month,year and status");
									}

									if (response.length != 0) {
										for ( var i = 0; i < response.length; i++) {$('#bunchingWorkOrderNoSelect').append('<option selected="selected">'
																	+ ""
																	+ '</option>');
											$('#bunchingWorkOrderNoSelect')
													.append(
															'<option >'
																	+ response[i]
																	+ '</option>');
											$('#bunchingWorkOrderNoSelect')
													.trigger('liszt:updated');
										}
									} else {
										$('#bunchingWorkOrderNoSelect').empty();
										document
												.getElementById('bunchingStartDate').value = "";
										document
												.getElementById('bunchingCompletionDate').value = "";
										document
												.getElementById('bunchingMachineNo').value = "";

									}
								}
							});
					}
					else
					{
					alert("Please select month and year");
					document.getElementById('workOrderStatusSelect').value = "";
					$('#workOrderStatusSelect').trigger('liszt:updated');
					}
				});

function bunchingJobCardReport(){
	 var woNo=document.getElementById('bunchingWorkOrderNoSelect').value;
if(woNo!=null && woNo!="")
	location.href='viewBunchingWorkOrder/bunchingJobCardReport?workOrderNo='+woNo;
else
	alert("Select Work Order No");
}


$("#monthYearPicker").focus(function() {
	
	if ($("#workOrderStatusSelect").val() != "") {
		document.getElementById('workOrderStatusSelect').value = "";
		$('#workOrderStatusSelect').trigger('liszt:updated');
	}
	
	if ($("#bunchingWorkOrderNoSelect").val() != "") {
		document.getElementById('bunchingWorkOrderNoSelect').value = "";
		$('#bunchingWorkOrderNoSelect').trigger('liszt:updated');
	}
	
	if (document.getElementById('bunchingStartDate').value != "")
		document.getElementById('bunchingStartDate').value = "";
	
	if (document.getElementById('bunchingCompletionDate').value != "")
		document.getElementById('bunchingCompletionDate').value = "";
	
	if (document.getElementById('bunchingMachineNo').value != "")
		document.getElementById('bunchingMachineNo').value = "";
});

function workOrderReport(){
	 var woNo=document.getElementById('bunchingWorkOrderNoSelect').value;
	  if(woNo!=null && woNo!="")
	location.href='createBunchingWorkOrder/bunchingWorkOrderReport?workOrderNo='+woNo;
	  else
		  alert("Select Work Order No");
}