var lastSelected;
var submitStatus=false;
var lengthPerDrumValid=true;
var drumCountValid=true;


var productTypeArray;
var noOfCuStarndArray;
var cuDiamArrray;
var layLengthArray;
$(function(){ 
	

    $.ajax({
        url: 'createBunchingWorkOrder/fetchProductType',
        dataType: "json",
        data:{"processType":"Bunching"},
       
         success: function(data) {
        	 productTypeArray=data;
        }
    });
    
	$("#productTypeAutoSelect").autocomplete({
	    source: function(request, response) {
	        var results = $.ui.autocomplete.filter(productTypeArray, request.term);
	        response(results.slice(0, 15));
	    },
	    select: function (a, b) {
	      	productTypeSelectOnChange(b.item.value);
	    }
	});
	 
	$("#numberOfCopperStrandsAutoSelect").autocomplete({
	    select: function (a, b) {
	    	cuStrandsSelectOnChange(b.item.value);
	    }
	});
	$("#layLengthAutoSelect").autocomplete({
	    select: function (a, b) {
	      	layLengthSelectOnChange(b.item.value);
	    }
	});
	
	$("#copperDiameterAutoSelect").autocomplete({
	    select: function (a, b) {
	      	cuDiameterSelectOnChange(b.item.value);
	    }
	});
	
	$("#bunchingWoNoSelect").chosen({no_results_text: "No results matched"});
	
	 if($('input:radio[name=workOrderSelect]:checked').val()==0){
	     $('.newWoTableId').show();
		  $('.existingWoTableId').hide();
		  $('#resetBtn').show();
	  }else{
		  $('.existingWoTableId').show();
		  $('.newWoTableId').hide();
		  $('#resetBtn').hide();
	  }
	 
	  $("input[name=workOrderSelect]").change(function () {
		  if($('input:radio[name=workOrderSelect]:checked').val()==0){
			  $('.newWoTableId').show();
			  $('.existingWoTableId').hide();
			  $('#resetBtn').show();
			    document.getElementById('bunchingWorkOrderNoTag').value = "";
				document.getElementById('bunchingStartDate').value = "";
				document.getElementById('bunchingCompletionDate').value = "";
				document.getElementById('bunchingWoMachineNoSelect').value = "";
				$('#bunchingWoMachineNoSelect').trigger('liszt:updated');
				
				document.getElementById('bunchingStartDate').disabled = false;
				document.getElementById('bunchingCompletionDate').disabled = false;
				document.getElementById('bunchingWoMachineNoSelect').disabled = false;
				document.getElementById('numberOfCopperStrandsAutoSelect').disabled = false;
				document.getElementById('productTypeAutoSelect').disabled = false;
				document.getElementById('copperDiameterAutoSelect').disabled = false;
				
				document.getElementById('noOfDrums').disabled = false;
				document.getElementById('lengthPerDrum').disabled = false;
				document.getElementById('layLengthAutoSelect').disabled = false;
				document.getElementById('numberOfCopperStrandsAutoSelect').value = "";
				document.getElementById('copperDiameterAutoSelect').value = "";
			    document.getElementById('productTypeAutoSelect').value = "";
				
				document.getElementById('noOfDrums').value = "";
				document.getElementById('lengthPerDrum').value = "";
				document.getElementById('layLengthAutoSelect').value = "";
				
			   	document.getElementById('selectSO').disabled=false;
		   		document.getElementById('showWo').disabled=false;
		   		document.getElementById('addWorkOrderBtn').disabled=false;
		   		document.getElementById('submitBtn').disabled=false;
		   		
		   	   
		   	    jQuery("#createBunchingWorkOrderGrid").jqGrid("clearGridData", true);
				
		  }else{
				$('#resetBtn').hide();
			    $('#bunchingWoNoSelect').children().remove();
				$('#bunchingWoNoSelect').val('').trigger('liszt:updated');

				$.ajax({type:'POST', 
	        		url: 'createBunchingWorkOrder/getBunchingWoNos',
					success: function(response) {
						$('#bunchingWoNoSelect').empty();
						if(response.length != 0){
							for(var i=0;i< response.length;i++){
								$('#bunchingWoNoSelect').append('<option selected="selected">'+ "" + '</option>');
								$('#bunchingWoNoSelect').append('<option >' + response[i]+ '</option>');
								$('#bunchingWoNoSelect').trigger('liszt:updated');
							}
						}else{
							$('#bunchingWoNoSelect').empty();
						}
						
				  				
				}});
			  
			  
			  $('.existingWoTableId').show();
			  $('.newWoTableId').hide();
		
			  var woNo=$('#bunchingWoNoSelect').val();
			  if(woNo!=null && woNo!=""){
	          jQuery("#createBunchingWorkOrderGrid").setGridParam({datatype:'json'}); 
			  jQuery("#createBunchingWorkOrderGrid").setGridParam({  url : 'viewBunchingWorkOrder/populateWODetailsGrid/' + encodeURIComponent(woNo)});
			  jQuery("#createBunchingWorkOrderGrid").trigger('reloadGrid');
			  }else
				  jQuery("#createBunchingWorkOrderGrid").jqGrid("clearGridData", true);	
				
			  document.getElementById('numberOfCopperStrandsAutoSelect').value = "";
			  document.getElementById('copperDiameterAutoSelect').value = "";
			  document.getElementById('productTypeAutoSelect').value = "";
			  document.getElementById('noOfDrums').value = "";
			  document.getElementById('lengthPerDrum').value = "";
			  document.getElementById('layLengthAutoSelect').value = "";
			  
				if(document.getElementById('woStatus').value=="Submitted"){
				 	document.getElementById('saveWorkOrderExistWo').disabled=true;
			   		document.getElementById('fetchWoItemsExistWo').disabled=true;
			   		document.getElementById('addWorkOrderBtn').disabled=true;
			   		document.getElementById('submitBtn').disabled=true;
				 	submitStatus=true;

			  }else{
				 	document.getElementById('saveWorkOrderExistWo').disabled=false;
			   		document.getElementById('fetchWoItemsExistWo').disabled=false;
			   		document.getElementById('addWorkOrderBtn').disabled=false;
			   		document.getElementById('submitBtn').disabled=false;
		     		submitStatus=false;
		  
			  }
			
		  }
	  });
	  
	  	    
	$("#bunchingWoMachineNoSelect").chosen({no_results_text: "No results matched"});
	$("#bunchingSizeSelect").chosen({no_results_text: "No results matched"});
	$("#bunchingStartDate").datepicker({
		dateFormat : "dd-mm-yy",
		maxDate : 'today',
		onSelect : function(dateStr) {
			var min = $('#bunchingStartDate').datepicker('getDate');
			$('#bunchingCompletionDate').datepicker('option', {
				minDate : min
			});
		}
	});
	$("#bunchingCompletionDate").datepicker({
		dateFormat : "dd-mm-yy"
	});
	minDate: $('#bunchingStartDate').datepicker('getDate');
  
$("#createBunchingWorkOrderGrid").jqGrid({
	
	datatype : 'json',
	mtype : 'POST',
	//multiselect:true,
    colNames:['BunchWoInputId','Bunching WO No','Bunching Size','No Of Drums','Length per Drum(mts)','Net Length(mts)','Lay Length(mm)','Total Qty(Kgs)','Partyhidden','Party','Action'],
   	colModel:[
   	    
             {name:'bunchWoInputId', index:'bunchWoInputId', width:10,hidden:true}, 
             {name:'workOrderNo', index:'workOrderNo', width:10,hidden:true, editable:true},   
             {name:'size', index:'size', width:40, editable:false}, 
	          {name:'noOfDrums',index:'noOfDrums',  width:30,editable:true,
				   editoptions:{
		                  dataInit: function(element) {
		                      $(element).keyup(function(){
		                          var val1 = element.value;
		                          var num = new Number(val1);
		                          if(isNaN(num))
		                          {
		                        	  alert("Please enter valid drum count");
		                        	  drumCountValid=false;
		                         }
		                          else
		                        	  drumCountValid=true;
		                        
		                      });
		                  }
		   	      ,maxlength:8}},
	          {name:'lengthPerDrum',index:'lengthPerDrum',  width:35, editable:true,
				   editoptions:{
		                  dataInit: function(element) {
		                      $(element).keyup(function(){
		                          var val1 = element.value;
		                          var num = new Number(val1);
		                          if(isNaN(num))
		                          {
		                        	  alert("Please enter valid Length per drum");
		                        	  lengthPerDrumValid=false;
		                         }
		                          else
		                        	  lengthPerDrumValid=true;
		                        
		                      });
		                  }
		   	      ,maxlength:8}},
		   	  {name:'netLength',index:'netLength', width:35, editable:false},
	          {name:'layLength',index:'layLength', width:30, editable:false},
	          {name : 'totalQty',index : 'totalQty',width : 35,editable : false},
	          {name:'customerName',index:'customerName', width:20, editable:false,hidden:true},
	          {name:'customerCode',index:'customerCode', width:70, editable:false},
	          {name:'act',index:'act', width:20,sortable:false},
	          
	      	],
    	   	postData: {},
    		rowNum:100,
    	   	rowList:[20,30,40,60,100],
    	   	height: 270,
    	   	autowidth:true,
    	   	rownumbers: false,
    	   	pager: '#createBunchingWorkOrderPager',
    	   	sortname: 'bunchWoInputId',
    	    viewrecords: true,
    	    sortorder: "desc",
    	    caption:"Bunching Work Order",
    	    emptyrecords: "Empty records",
    	    loadonce: false,
    	    footerrow: true,
    	    loadComplete: function() {},
    	    jsonReader : {
    	        root: "rows",
    	        page: "page",
    	        total: "total",
    	        records: "records",
    	        repeatitems: false,
    	        cell: "cell",
    	        id: "bunchWoInputId"
    	    },
    	    ondblClickRow : function(id) {
    	    if (id && id !== lastSelected) {
    				editRow(id);
    			}
    		},
    		gridComplete: function(){ 
    			 var totalQty = $('#createBunchingWorkOrderGrid').jqGrid('getCol','totalQty',false,'sum');
    	   		 var netLength = $('#createBunchingWorkOrderGrid').jqGrid('getCol','netLength',false,'sum');
    	   		 var drumCount = $('#createBunchingWorkOrderGrid').jqGrid('getCol','noOfDrums',false,'sum');

    	   		var totQtyVal=Math.round(parseFloat(totalQty) * 100) / 100;
    	   		var totalNet=Math.round(parseFloat(netLength) * 100) / 100;
    	   		var totalDrums=Math.round(parseFloat(drumCount) * 100) / 100;
    	   		
    	   		$('#createBunchingWorkOrderGrid').jqGrid('footerData','set', {ID: 'Total:', totalQty: totQtyVal});
	   	    	$('#createBunchingWorkOrderGrid').jqGrid('footerData','set', {ID: 'Total:', netLength: totalNet});
	   	    	$('#createBunchingWorkOrderGrid').jqGrid('footerData','set', {ID: 'Total:', noOfDrums: totalDrums});

 	   	    	var ids = jQuery("#createBunchingWorkOrderGrid").jqGrid('getDataIDs');
 	   	    	for ( var i = 0; i < ids.length; i++) {
 					var cl = ids[i];
 					be = "<input style='height:22px; width:35px;' type='button' value='Edit'  id='editRow"+cl+"' onclick=\"editRow('"+ cl + "');\" />";
 					de = "<input style='height:22px; width:30px;' type='button' value='Del'  id='delRow"+cl+"' onclick=\"delRow('"+ cl + "');\" />";
 					se = "<input style='height:22px; width: 40px;' type='button' value='Save' hidden='hidden'  id='saveRow"+cl+"' onclick=\"saveRow('"+ cl + "');\" />";
 					ce = "<input style='height:22px;width:45px;' type='button' value='Cancel' hidden='hidden' id='restoreRow"+cl+"' onclick=\"restoreRow('"+ cl + "');\" />";
 						$("#createBunchingWorkOrderGrid").jqGrid('setRowData', ids[i],
 							{
 								act : be + de + se + ce
 							});
 				}
            },
            editurl : "createBunchingWorkOrder/crud"
    	}).navGrid('#createBunchingWorkOrderPager',{view:false, del:false, edit:false, search:false,add:false}
    
);
   
$("#bunchingWoNoSelect").chosen().change(function() {
	var woNo=$('#bunchingWoNoSelect').val();
	$.ajax({type:'POST', 
		url: 'viewworkorder/fetchWoDetails/'+ encodeURIComponent(woNo),
		success: function(response) {
			document.getElementById('woStartDate').value=response[0]; 
            document.getElementById('woEndDate').value=response[1]; 
            document.getElementById('woMachine').value=response[3];
            document.getElementById('woStatus').value=response[4];
           if(response[4]=="Submitted"){
        	document.getElementById('saveWorkOrderExistWo').disabled=true;
       		document.getElementById('fetchWoItemsExistWo').disabled=true;
       		document.getElementById('addWorkOrderBtn').disabled=true;
       		document.getElementById('submitBtn').disabled=true;
           } else{
        		document.getElementById('saveWorkOrderExistWo').disabled=false;
           		document.getElementById('fetchWoItemsExistWo').disabled=false;
           		document.getElementById('addWorkOrderBtn').disabled=false;
           		document.getElementById('submitBtn').disabled=false;
              
           }
              jQuery("#createBunchingWorkOrderGrid").setGridParam({datatype:'json'}); 
			  jQuery("#createBunchingWorkOrderGrid").setGridParam({  url : 'viewBunchingWorkOrder/populateWODetailsGrid/' + encodeURIComponent(woNo)});
			  jQuery("#createBunchingWorkOrderGrid").trigger('reloadGrid');
		
       	 jQuery("#createBunchingWorkOrderGrid").setCaption('Work Order '+woNo+' Details');

	    }});
        });

}); 
   	

function editRow(id) {
	if(submitStatus==false){
	restoreRow(lastSelected);
	lastSelected = id;
	
	$('#createBunchingWorkOrderGrid').jqGrid('editRow',id, 
			{
				"keys" :true, 
				"oneditfunc" : hideActButtons,
				aftersavefunc : function(savedId, response) {
					
					showActButtons(savedId);
				},
				afterrestorefunc : showActButtons
			});
}
}

function delRow(id) {
   	if(submitStatus==false){
   	if (confirm("Are you sure you want to delete ?")) {
		var oper = "del";
		$.ajax({
			type : 'POST',
			url : 'createBunchingWorkOrder/crud',
			data : {
				'id' : id,
				'oper' : oper
			},
			success : function(response) {
				jQuery("#createBunchingWorkOrderGrid").trigger('reloadGrid');
			}
		});

	
	;
}}}

function saveRow(id) {
if(lengthPerDrumValid==true){
	var WorkOrderNo=$('#bunchingWorkOrderNoTag').val();
    	$('#createBunchingWorkOrderGrid').saveRow(id,
    	{	aftersavefunc : function(id, response) {
    				showActButtons(id);
    			},
    			extraparam : {
    				"WorkOrderNo" : WorkOrderNo
    			}
    	});
    	jQuery("#createBunchingWorkOrderGrid").trigger('reloadGrid');
}else if(lengthPerDrumValid==false){
    alert("Enter Valid Length per Drum");
}
}
function restoreRow(id) {
    	$('#createBunchingWorkOrderGrid').jqGrid('restoreRow',id,
    			{
    				afterrestorefunc : showActButtons
    			});
}

    /*
     * Hides the Edit and Del Row Buttons on jqGrid
     * and activates the Save and restore(cancel) button
     * 
     */
function hideActButtons(id){
    	$('#editRow' + id).hide();
    	$('#delRow' + id).hide();
    	$('#saveRow' + id).show();
    	$('#restoreRow' + id).show();
}

    /*
     * Shows the Edit and Del Row Buttons on jqGrid
     * and hides the Save and restore(cancel) button
     * 
     */
function showActButtons(id) {
    	$('#editRow' + id).show();
    	$('#delRow' + id).show();
    	$('#saveRow' + id).hide();
    	$('#restoreRow' + id).hide();
    	lastSelected = null;
    	
}

function showWOItems(){
	 var woNo=null;
	  if($('input:radio[name=workOrderSelect]:checked').val()==0){
		  woNo=document.getElementById('bunchingWorkOrderNoTag').value;
	 }else{
	  woNo=  $('#bunchingWoNoSelect').val();
 }

	 
     jQuery("#createBunchingWorkOrderGrid").setGridParam({datatype:'json'}); 
	 jQuery("#createBunchingWorkOrderGrid").setGridParam({ url: 'createBunchingWorkOrder/records/'+ encodeURIComponent(woNo)});
	 jQuery("#createBunchingWorkOrderGrid").setCaption('Bunching Work Order '+woNo+' Details');
	 jQuery("#createBunchingWorkOrderGrid").trigger('reloadGrid');
	}  

function createProdWO(){
	if($('input:radio[name=workOrderSelect]:checked').val()==0){
		if (document.getElementById('bunchingWorkOrderNoTag').value == "") {
			if (validatePdnWO()) {
				 $.ajax({type:'POST', 
					 datatype:'json',
						url: 'createBunchingWorkOrder/createProdWO',
									data:'&bunchingStartDate=' + $("#bunchingStartDate").val() + 
					              		 '&bunchingCompletionDate=' + $("#bunchingCompletionDate").val() + 
					          			 '&bunchingWoMachineNoSelect=' + $("#bunchingWoMachineNoSelect").val()+
					          			'&bunchingWorkOrderNoTag=' +$("#bunchingWorkOrderNoTag").val() ,
					               	success: function(response) {
								document.getElementById('bunchingWorkOrderNoTag').value = response[0];
								 $('#bunchingWoNoSelect').append('<option>'+response[0]+'</option>');
								 $('#bunchingWoNoSelect').trigger('liszt:updated');
						         openSalesOrdersPage();
	                       }
						});
			}
		} else {
			openSalesOrdersPage();
		}}
		else{
			 var existWoNo= $('#bunchingWoNoSelect').val();
			 if(existWoNo!="" && existWoNo!=null){
				 openSalesOrdersPage(existWoNo); 
			 }else{
				 alert("Select Work Order No");
			 }
		}
 }

function openSalesOrdersPage() {
	var workOrderNo="";
	  if($('input:radio[name=workOrderSelect]:checked').val()==0){
		  workOrderNo=document.getElementById('bunchingWorkOrderNoTag').value;
	  }else{
		  workOrderNo=$('#bunchingWoNoSelect').val(); 
	  }
	url = 'viewSOForWO?workOrderNo=' + encodeURIComponent(workOrderNo)+'&reportType='+encodeURIComponent("Bunching"); 
	window.open(url,'_blank');
 }

function validatePdnWO(){
	if($("#bunchingStartDate").val()==""){
		alert("Enter Bunching Process Start Date ");
		return false;
	}
	if($("#bunchingCompletionDate").val()==""){
		alert("Enter Bunching Process Completion Date ");
		return false;
	}
	else if($("#bunchingWoMachineNoSelect").val()==""){
		alert("Select Machine ");
		return false;
	}	
	else return true;
}


function addWorkOrderItem() {
	var validWo = false;
	 var validAddItem=false;
	 var woNo="";
	 if($('input:radio[name=workOrderSelect]:checked').val()==0){
	    woNo=document.getElementById('bunchingWorkOrderNoTag').value;
	     validWo=validateWODetails();
	    if(validWo==true)
	    validAddItem=validateAddItemDetails();
	 }
	 else{
	     woNo=$('#bunchingWoNoSelect').val(); 
		 validWo=validateMwdValue();
		 if(validWo==true)
		 validAddItem=validateAddItemDetails();
	 }
	 if(validWo==true &&  validAddItem==true){
		  $.ajax({
				type : 'POST',
				url: 'createBunchingWorkOrder/createBunchingWo',
				data:'&bunchingStartDate=' + $("#bunchingStartDate").val() + 
              		 '&bunchingCompletionDate=' + $("#bunchingCompletionDate").val() + 
          			 '&bunchingWoMachineNoSelect=' + $("#bunchingWoMachineNoSelect").val() +
          			 '&numberOfCopperStrandsSelect=' + $("#numberOfCopperStrandsAutoSelect").val() +
          			 '&copperDiameterSelect=' + $("#copperDiameterAutoSelect").val() +
          			 '&layLengthSelect=' + $("#layLengthAutoSelect").val() +
          			 '&productType=' + $("#productTypeAutoSelect").val() +
          			 '&noOfDrums=' + $("#noOfDrums").val() +
          			 '&lengthPerDrum=' + $("#lengthPerDrum").val()+
          			'&bunchingWorkOrderNoTag=' +woNo ,
               	success: function(response) {
               		if(response[0]!=null && response[0]!=="" && response[0]!="undefined"){
		           document.getElementById('bunchingWorkOrderNoTag').value = response[0];
		   		           
		           
		           jQuery("#createBunchingWorkOrderGrid").setGridParam({datatype:'json'}); 
					jQuery("#createBunchingWorkOrderGrid").setGridParam({ url : 'createBunchingWorkOrder/records/' + encodeURIComponent(response[0])});
					jQuery("#createBunchingWorkOrderGrid").trigger('reloadGrid');
		
               		}}
		     });
		  var woNos;
		  if($('input:radio[name=workOrderSelect]:checked').val()==0){
			  woNos=document.getElementById('bunchingWorkOrderNoTag').value;
		  }else{
			  woNos=$('#bunchingWoNoSelect').val(); 
		  }
		   if(woNos!=null && woNos!="" && woNos!="undefined"){
	           		jQuery("#createBunchingWorkOrderGrid").setGridParam({datatype:'json'}); 
					jQuery("#createBunchingWorkOrderGrid").setGridParam({ url : 'createBunchingWorkOrder/records/' + encodeURIComponent(woNos)});
					jQuery("#createBunchingWorkOrderGrid").trigger('reloadGrid');
		   }       		
				
	 }
	
	// createBunchingWO();
	}

//Abin

function createBunchingWO(){
	var valid=validateWODetails();
	
	if(valid==true){
	
		 $.ajax({type:'POST', 
				url: 'createBunchingWorkOrder/createBunchingWo',
							data:'&bunchingStartDate=' + $("#bunchingStartDate").val() + 
			              		 '&bunchingCompletionDate=' + $("#bunchingCompletionDate").val() + 
			          			 '&bunchingWoMachineNoSelect=' + $("#bunchingWoMachineNoSelect").val() +
			       	 			 '&numberOfCopperStrandsSelect=' + $("#numberOfCopperStrandsAutoSelect").val() +
			          			 '&copperDiameterSelect=' + $("#copperDiameterAutoSelect").val() +
			          			 '&productTypeSelect=' + $("#productTypeAutoSelect").val() +  
			          			 '&layLengthSelect=' + $("#layLengthAutoSelect").val() +  
			          			 '&noOfDrums=' + $("#noOfDrums").val() +
			          			 '&lengthPerDrum=' + $("#lengthPerDrum").val()+
			          		
			          			'&bunchingWorkOrderNoTag=' +$("#bunchingWorkOrderNoTag").val() ,
			               	success: function(response) {
			               		document.getElementById('bunchingWorkOrderNoTag').value=response[0];
			               		
			               		var woNo = document.getElementById('bunchingWorkOrderNoTag').value;
			               		
			               		jQuery("#createBunchingWorkOrderGrid").setGridParam({datatype:'json'}); 
		    					jQuery("#createBunchingWorkOrderGrid").setGridParam({ url : 'createBunchingWorkOrder/records/' + encodeURIComponent(woNo)});
		    					jQuery("#createBunchingWorkOrderGrid").trigger('reloadGrid');
			            	}
			});
   /*    }
		}}); */      
}
}
//Abin

function validateAddItemDetails(){
	var  patroon = /^[+]?([0-9]+(?:[\.][0-9]*)?|\.[0-9]+)$/;
  	var numberPattern = /^(0|[1-9][0-9]*)$/;
	var length=document.getElementById('lengthPerDrum').value;
   var drumCount=document.getElementById('noOfDrums').value;
        if($("#numberOfCopperStrandsAutoSelect").val()==""){
			alert("Select number of Cu strand");
			return false;
		}
		else if($("#copperDiameterAutoSelect").val()==""){
			alert("Select Cu Strand Diameter");
			return false;
		}
		else if($("#productTypeAutoSelect").val()==""){
			alert("Select Product Type");
			return false;
		}
  

  
	else if($("#noOfDrums").val()==""){
		alert("Enter No Of Drums");
		return false;
	}	
	
	else if($("#lengthPerDrum").val()==""){
		alert("Enter Length Per Drum");
		return false;
	}	
	else if(isNaN(drumCount)){
		alert("Enter Valid No Of Drums");
		document.getElementById('noOfDrums').value="";
		return false;
   }
	else if(isNaN(length)){
		alert("Enter Valid Length Per Drum");
		document.getElementById('lengthPerDrum').value="";
		return false;
   }
	else if(!patroon.test(length)|| length==0 ){
		alert("Enter Valid Length Per Drum");
		document.getElementById('lengthPerDrum').value="";
		return false;
	 }
	else if(!numberPattern.test(drumCount)|| drumCount==0 ){
		alert("Enter Valid No Of Drums");
		document.getElementById('noOfDrums').value="";
		return false;
	 }
	
	else return true;

}


function validateWODetails(){
	if($("#bunchingStartDate").val()==""){
		alert("Enter Bunching process start date ");
		return false;
	}
	
	else if($("#bunchingCompletionDate").val()==""){
		alert("Enter Bunching process completion date");
		return false;
	}	
	else if($("#bunchingWoMachineNoSelect").val()==""){
		alert("Select Machine");
		return false;
	}	
	else return true;
}

function validateMwdValue(){
	 var bunchingWoNo= $('#bunchingWoNoSelect').val(); 
	 if(bunchingWoNo!=null && bunchingWoNo!="")
		 return true;
	 else{
		 alert("Select Bunching Work order No");
		 return false;
	 }
}

function resetValues(){
	 if($('input:radio[name=workOrderSelect]:checked').val()==0){
		   document.getElementById('bunchingWorkOrderNoTag').value = "";
			document.getElementById('bunchingStartDate').value = "";
			document.getElementById('bunchingCompletionDate').value = "";
			document.getElementById('bunchingWoMachineNoSelect').value = "";
			$('#bunchingWoMachineNoSelect').trigger('liszt:updated');
			
			document.getElementById('numberOfCopperStrandsAutoSelect').value ="";
			document.getElementById('copperDiameterAutoSelect').value ="";
			document.getElementById('productTypeAutoSelect').value ="";
			document.getElementById('layLengthAutoSelect').value ="";
			
			document.getElementById('cuWeight').value ="";
			document.getElementById('noOfDrums').value="";
			document.getElementById('lengthPerDrum').value="";
		
			document.getElementById('bunchingStartDate').disabled = false;
			document.getElementById('bunchingCompletionDate').disabled = false;
			document.getElementById('bunchingWoMachineNoSelect').disabled = false;
			
			document.getElementById('numberOfCopperStrandsAutoSelect').disabled = false;
			document.getElementById('copperDiameterAutoSelect').disabled = false;
			document.getElementById('productTypeAutoSelect').disabled = false;
			
			document.getElementById('noOfDrums').disabled = false;
			document.getElementById('lengthPerDrum').disabled = false;
			

		   	document.getElementById('selectSO').disabled=false;
	   		document.getElementById('showWo').disabled=false;
	   	    
		  }
			document.getElementById('addWorkOrderBtn').disabled=false;
	   		document.getElementById('submitBtn').disabled=false;
		   jQuery("#createBunchingWorkOrderGrid").jqGrid("clearGridData", true);
		
}

function submit() {
	 var woNo=null;
	  if($('input:radio[name=workOrderSelect]:checked').val()==0){
		  woNo=document.getElementById('bunchingWorkOrderNoTag').value;
	 }else{
	  woNo= $('#bunchingWoNoSelect').val(); 
  }

	 if(woNo=="" || woNo==null){
		 if($('input:radio[name=workOrderSelect]:checked').val()==0)
			 alert("No Work Order Is Created.");
		 else
			 alert("Select work order No");
		 submitStatus=false;
	 }
   else if($("#createBunchingWorkOrderGrid").getGridParam("reccount")==0) {
		alert("No Work Order Items added.");
		 submitStatus=false;
	}else {
		if (confirm("Are You Sure You Want To Submit?")) {
			 $.ajax({
					type:'POST',
					url: 'createMWDWorkOrder/pendingWorkOrder/'+encodeURIComponent(woNo),
					success: function(response) {
			alert("Work Order "+ woNo+ " Is Submitted.");
			  if($('input:radio[name=workOrderSelect]:checked').val()==0){
					document.getElementById('bunchingStartDate').disabled = true;
					document.getElementById('bunchingCompletionDate').disabled = true;
					document.getElementById('selectSO').disabled = true;
					document.getElementById('showWo').disabled = true;
					document.getElementById('noOfDrums').disabled = true;
					document.getElementById('lengthPerDrum').disabled = true;
					document.getElementById('layLengthAutoSelect').disabled = true;
				  }else{
					 	document.getElementById('saveWorkOrderExistWo').disabled=true;
			       		document.getElementById('fetchWoItemsExistWo').disabled=true;
					  
				  }
				document.getElementById('addWorkOrderBtn').disabled = true;
				document.getElementById('submitBtn').disabled = true;
		       	    submitStatus=true;
           }});
		}else  submitStatus=false;
	}

}

$(document).keypress(function(e) {
	if (e.which == 13) {
		var ids = $("#createBunchingWorkOrderGrid").jqGrid('getDataIDs');
		for ( var i = 0; i < ids.length; i++) {
			var cl = ids[i];
			saveRow(cl);
		}
		jQuery("#createBunchingWorkOrderGrid").trigger('reloadGrid');
	}
});


function workOrderReport(){
	 var woNo=null;
	  if($('input:radio[name=workOrderSelect]:checked').val()==0){
		  woNo=document.getElementById('bunchingWorkOrderNoTag').value;
	 }else{
	  woNo= $('#bunchingWoNoSelect').val(); 
  }

	  if(woNo!=null && woNo!="")
	location.href='createBunchingWorkOrder/bunchingWorkOrderReport?workOrderNo='+woNo;
	  else
		 alert("Work Order Number required for report");
}





function productTypeSelectOnChange(productType){
	document.getElementById('numberOfCopperStrandsAutoSelect').value="";
	document.getElementById('copperDiameterAutoSelect').value="";
	document.getElementById('layLengthAutoSelect').value="";
	document.getElementById('cuWeight').value="";
	
	$.ajax({
		url: 'createBunchingWorkOrder/fetchCuStrands',
		data:{"productType":productType},
		success: function(response) {
			noOfCuStarndArray=response;
			$("#numberOfCopperStrandsAutoSelect").autocomplete({
			    source: function(request, response) {
			        var results = $.ui.autocomplete.filter(noOfCuStarndArray, request.term);
			        response(results.slice(0, 15));
			    },
			    select: function (a, b) {
			    	cuStrandsSelectOnChange(b.item.value);
			    }
			});	
	}});
}


function cuStrandsSelectOnChange(numberOfCopperStrand){
	document.getElementById('copperDiameterAutoSelect').value="";
	document.getElementById('layLengthAutoSelect').value="";
	document.getElementById('cuWeight').value="";

	var productType=$("#productTypeAutoSelect").val();
	$.ajax({
		type:'POST',
		url: 'createBunchingWorkOrder/getCuDiamter',
		data:{"numberOfCopperStrand":numberOfCopperStrand,"productType":productType},
		success: function(response) {
	    	cuDiamArrray=response;
			$("#copperDiameterAutoSelect").autocomplete({
			    source: function(request, response) {
			        var results = $.ui.autocomplete.filter(cuDiamArrray, request.term);
			        response(results.slice(0, 15));
			    },
			    select: function (a, b) {
			    	cuDiameterSelectOnChange(b.item.value);
			    }
			});	
	}});

}
var layLengthValue=null;
function cuDiameterSelectOnChange(cudiameter){
	document.getElementById('layLengthAutoSelect').value="";
	document.getElementById('cuWeight').value="";
	$.ajax({ 
		type:'POST',
		url: 'createBunchingWorkOrder/getLayLength',
		data:  '&numberOfCopperStrandsSelect=' + $("#numberOfCopperStrandsAutoSelect").val() +
			 '&copperDiameterSelect=' + cudiameter ,
		success: function(response) {
		if(response.length==1){
			document.getElementById('layLengthAutoSelect').value=response;
			layLengthValue=$("#layLengthAutoSelect").val();
			fetchCuWeight(layLengthValue);
		}else{
			alert("Corresponding lay length values are:"+response);
			layLengthArray=response;
			$("#layLengthAutoSelect").autocomplete({
			    source: function(request, response) {
			        var results = $.ui.autocomplete.filter(layLengthArray, request.term);
			        response(results.slice(0, 15));
			    },
			    select: function (a, b) {
			    	layLengthSelectOnChange(b.item.value);
			    }
			});	
		}	
			
			
	  				
	}});
}

function layLengthSelectOnChange(layLength){
	fetchCuWeight(layLength);
}





function  fetchCuWeight(layLength){
	var productType=$("#productTypeAutoSelect").val();
	var numberOfCuStrand=$("#numberOfCopperStrandsAutoSelect").val();
	//var layLength=$("#layLengthAutoSelect").val();
	if(layLength==null || layLength=="")
		layLength=$("#layLengthAutoSelect").val();
	var cuDiameter=$("#copperDiameterAutoSelect").val();
	if(productType!=null && productType!="" && numberOfCuStrand!=null && numberOfCuStrand!="" &&
			layLength!=null && layLength!="" && cuDiameter!=null && cuDiameter!=""){
	 $.ajax({
			type:'POST',
			url: 'createBunchingWorkOrder/fetchCuWeight',
			data:{"productType":productType,"numberOfCuStrand":numberOfCuStrand,
				   "layLength":layLength,"cuDiameter":cuDiameter},
			success: function(response) {
				document.getElementById('cuWeight').value = response[0];
			}});
 }
}