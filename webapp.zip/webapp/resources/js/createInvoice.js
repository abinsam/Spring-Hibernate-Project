var lastSelected;
var systemDate = new Date();
var month="";
var year="";

$("#customerSelect").chosen({no_results_text : "No results matched"});
$("#deliveryChallanNoSelect").chosen({no_results_text : "No results matched"});
$("#invoiceDate").datepicker({dateFormat : "dd-mm-yy"});
$("#loading").dialog({
    hide: 'slide',
    show: 'slide',
    autoOpen: false
});

$("#monthYearPicker").focus(function () {$(".ui-datepicker-calendar").hide();});
$('#monthYearPicker').datepicker({
    changeYear: true,
    changeMonth: true,
    changeDate :false,
    showButtonPanel: true,
    dateFormat: 'MM yy',
    onClose: function(dateText, inst) { 
        year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
        month = $("#ui-datepicker-div .ui-datepicker-month :selected").val();
        $(this).datepicker('setDate', new Date(year,month, 1));
        changeWoOnMonthYear();
    }
});
$('#monthYearPicker').datepicker("setDate",systemDate); 
$("#monthYearPicker").focus(function () {$(".ui-datepicker-month").show();});
$("#monthYearPicker").focus(function () {$(".ui-datepicker-year").show();});

$(function(){ 
	
	/*$("#invoiceDate").datepicker({dateFormat : "dd-mm-yy"});
	$("#invoiceDate").datepicker("setDate",'today');*/
	
	$("#createInvoiceGrid").jqGrid({
		url: 'createInvoice/records',
		datatype: 'json',
		 mtype: 'POST',
		
		colNames:['dcItemId','Item Description','No Of Rolls','Qty Per Roll','Total Quantity','Units','Rate(Rs)'],
	   	colModel:[
              {name:'dcItemId', index:'dcItemId', width:15, viewable:false,hidden:true},
              {name:'itemDescription',index:'itemDescription', width:400},
              {name:'noOfRolls',index:'noOfRolls', width:100},
              {name:'qtyPerRoll',index:'qtyPerRoll', width:100},
   	          {name:'totalQty',index:'totalQty', width:100},
   	          {name:'units',index:'units', width:100},
   	          {name:'rate',index:'rate', width:100},
   	           ],
        
	   	postData: {},
		rowNum:100,
	   	rowList:[5,10,20,40,50],
	    height:300,
	    autowidth : true,
		rownumbers: false,
	   	pager: '#createInvoicePager',
	   	sortname:'dcItemId',
	    viewrecords: true,
	    sortorder: "desc",
	    caption:"Delivery Challan Records",
	    emptyrecords: "Empty records",
	    loadonce: false,
	    loadComplete: function() {},
	    jsonReader : {
	        root: "rows",
	        page: "page",
	        total: "total",
	        records: "records",
	        repeatitems: false,
	        cell: "cell",
	        id: "dcItemId"
	    },
	    ondblClickRow : function(id) {
			if (id && id !== lastSelected) {
				editRow(id);
			}
		}
		//editurl : "viewworkorder/crud",
	});
	
	 jQuery("#createInvoiceGrid").jqGrid('navGrid','#createInvoicePager',{view:false, del:false,add:false, edit:false, search:false});
});


$("#deliveryChallanNoSelect").chosen().change(function() {
	var customer = $('#customerSelect option:selected').text();
	  var deliveryChallanNo=$('#deliveryChallanNoSelect').val();
			$.ajax({
				
				type:'POST', 
		 		url: 'viewdeliverychallan/getDcDetails',
		 		data:{"deliveryChallanNo":deliveryChallanNo},
		 		success: function(response) {
		 			   var res =response[6];
		 				document.getElementById('customerSelect').value = res ;
		 	 			$('#customerSelect').trigger('liszt:updated');	
		 	 			customer= $('#customerSelect option:selected').text();
		 	 			fetchCustomerDetails();
		 		}});
        jQuery("#createInvoiceGrid").setGridParam({datatype:'json'}); 
		 jQuery("#createInvoiceGrid").setGridParam({ url: 'createInvoice/records'});
		 jQuery("#createInvoiceGrid").setGridParam({postData: {deliveryChallanNo:deliveryChallanNo}}); 
		 jQuery("#createInvoiceGrid").setCaption(	'Delivery Challan ' + deliveryChallanNo+ ' Records of '+ customer);
		 jQuery("#createInvoiceGrid").trigger('reloadGrid');

    });


function fetchCustomerDetails(){
	var customerId = $('#customerSelect').val();
    $.ajax({type:'POST',url: 'customers/taxDetails',
    	data: {'customerId': customerId},
       success: function(response) {
   		 document.getElementById('partyAddress').value=response[1];
		 document.getElementById('tinNo').value=response[2];
		 document.getElementById('cstNo').value=response[3];
		 document.getElementById('exciseDuty').value=response[5];
		 document.getElementById('eduCess').value=response[6];
		 document.getElementById('higherEduCess').value=response[7];
		 document.getElementById('vat').value=response[8];
		 document.getElementById('cst').value=response[9];
       }});
}



	    $("#customerSelect").chosen().change(function() {
	    	$("#invoiceDate").datepicker('setDate', 'today');
	    	var customerId = $('#customerSelect').val();
	    	   year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
	           month = $("#ui-datepicker-div .ui-datepicker-month :selected").val();
	       
	         $.ajax({type:'POST',url: 'customers/taxDetails',data: {'customerId': customerId}, success: function(response) {
	    				
	    				 document.getElementById('partyAddress').value=response[1];
	    				 document.getElementById('tinNo').value=response[2];
	    				 document.getElementById('cstNo').value=response[3];
	    				 document.getElementById('exciseDuty').value=response[5];
	    				 document.getElementById('eduCess').value=response[6];
	    				 document.getElementById('higherEduCess').value=response[7];
	    				 document.getElementById('vat').value=response[8];
	    				 document.getElementById('cst').value=response[9];
	    					$('#deliveryChallanNoSelect').children().remove();
	    					$('#deliveryChallanNoSelect').val('').trigger('liszt:updated');
	    					$.ajax({type:'POST', 
	    						url: 'viewdeliverychallan/getDeliveryChallanNos',
	    						data:{"customer":customerId,"month":month,"year":year},
	    						success: function(response) {
	    							$('#deliveryChallanNoSelect').empty();
	    							if (response.length == 0) {

	    								alert("There is no delivery challan created for the selected customer");
	    								$('#createInvoiceGrid').jqGrid('clearGridData');
	    							}

	    							if(response.length != 0){
	    								for(var i=0;i< response.length;i++){
	    									$('#deliveryChallanNoSelect').append('<option selected="selected">'+ "" + '</option>');
	    									$('#deliveryChallanNoSelect').append('<option >' + response[i]+ '</option>');
	    									$('#deliveryChallanNoSelect').trigger('liszt:updated');
	    								}
	    							}else{
	    								$('#deliveryChallanNoSelect').empty();
	    							}
	    	 }});
	    					}});
	         });



	    $('#generateInvoiceBtn').click(function(){
	    	var customerName = $('#customerSelect option:selected').text();
	    	var customerId = $('#customerSelect').val();
	        var deliveryChallanNo=$('#deliveryChallanNoSelect').val();
	    	 var invoiceDate=document.getElementById('invoiceDate').value;
	     var gridRowCount=jQuery("#createInvoiceGrid").getGridParam("reccount");
	    	var transportDetails=document.getElementById('transportDetails').value;
	    	var transportMode=document.getElementById('modeOfTransport').value;
            var transportCharges=document.getElementById('transportCharges').value;
       	     var  patroon = /^[+]?([0-9]+(?:[\.][0-9]*)?|\.[0-9]+)$/;
            var transportChargeValid=false;
        	if(!patroon.test(transportCharges)){
        		transportChargeValid=false;
        	}
        	else{
        		transportChargeValid=true;
        	}
	       	 if(invoiceDate!="" && deliveryChallanNo!="" && deliveryChallanNo!=null && customerId!=null && customerId!="" && gridRowCount>0 
	       			&& transportDetails!=null && transportDetails!="" && transportMode!=null && transportMode!="" && transportCharges!=null && transportCharges!="" 
	       				 && transportChargeValid==true){
	      	  if (confirm("Do you want to create invoice for selected delivery challan records ")){
	     	    $.ajax({type:'POST',
	     	    	url: 'createInvoice/crud',
	     	  	    data: {'deliveryChallanNo': deliveryChallanNo,
	     	  	    	   'invoiceDate':invoiceDate,
	     	  	    	   'customerId':customerId,
	     	  	    	   'transportDetails':transportDetails,
	     	  	        	'transportMode':transportMode,
	     	  	        	'transportCharges':transportCharges
	     	  	    	   },
	     	  	    	  beforeSend: function(){
	   			           $("#loading").dialog('open').html("<p>Processing Request...</p>");
	   			        },
	   				   
	     	  	         success: function(response) {   
	        	  	          
	     	  	       //  jQuery("#createInvoiceGrid").setGridParam({datatype:'json'}); 
	     	     	//	 jQuery("#createInvoiceGrid").setGridParam({ url: 'createInvoice/records/'+ encodeURIComponent(deliveryChallanNo)});
	     	     		 jQuery("#createInvoiceGrid").trigger('reloadGrid');
	     	     		 location.href='viewInvoice/testReport?invoiceNo='+response;
    	  	             alert("Invoice  "+response+" created for "+customerName);

	      	            	},
	      	              complete: function() {
	     		        	 $("#loading").dialog('close');
	     		        }});
	      	    	  }
	      	 }
	      	 if(invoiceDate==""){
	      		 alert("Select Invoice Date");
	      	 } 
	      	 else if(deliveryChallanNo=="" || deliveryChallanNo==null){
	      		 alert("Select Delivery challan No");
	      	 } 
	      	 else if(customerId=="" || customerId==null){
	      		 alert("Select Customer ");
	      	 } 
	      	 else if(gridRowCount==0){
	    		 alert("No items available for selected delivery challan");
	    	 }
	      	 else if(transportMode=="" || transportMode==null){
	      		 alert("Enter Mode of Transport");
	      	 } 
	      	 else if(transportDetails=="" || transportDetails==null){
	      		 alert("Enter transport details");
	      	 } 
	    	 else if(transportCharges=="" || transportCharges==null){
	      		 alert("Enter transport Charges");
	      	 }
	    	 else if(transportChargeValid==false){
	      		 alert("Enter Valid  Transport Charge Amount");
	      		document.getElementById('transportCharges').value="";
	      	 }
	    	   });


	    function changeWoOnMonthYear(){
	       $('#deliveryChallanNoSelect').children().remove();
	   		$('#deliveryChallanNoSelect').val('').trigger('liszt:updated');
	   		document.getElementById('customerSelect').value = "";
	   		$('#customerSelect').trigger('liszt:updated');
	   		$('#createInvoiceGrid').jqGrid('clearGridData');
	   		jQuery("#createInvoiceGrid").setCaption("Delivery Challan Items");
	   		document.getElementById('partyAddress').value = "";
	   		document.getElementById('tinNo').value = "";
	   		document.getElementById('cstNo').value = "";
	   		document.getElementById('exciseDuty').value = "";
	   		document.getElementById('eduCess').value = "";
	   		document.getElementById('higherEduCess').value = "";
	   		document.getElementById('vat').value = "";
	   		document.getElementById('cst').value = "";
	   		var validSearch=validateSearchParams();
	   		if(validSearch==true){
	   		 $.ajax({type:'POST',
	   			  url: 'viewdeliverychallan/fetchDeliveryChallan',
	   			  data: {"month":month,"year":year}, 
	   			  success: function(response) {
	   					
	   					if (response.length == 0) {
	          				alert("There is no Delivery Challan for the selected month and year");

	   			        }
	   					if(response.length != 0){
	   						for(var i=0;i< response.length;i++){
	   							$('#deliveryChallanNoSelect').append('<option selected="selected">'+ "" + '</option>');
	   							$('#deliveryChallanNoSelect').append('<option >' + response[i]+ '</option>');
	   							$('#deliveryChallanNoSelect').trigger('liszt:updated');
	   						}
	   					}else{
	   						$('#deliveryChallanNoSelect').empty();	
	   						$('#deliveryChallanNoSelect').children().remove();
	   						$('#deliveryChallanNoSelect').val('').trigger('liszt:updated');
	   					}
	   				
	   		 }
	   		 });
	   	 }
	   }

	    
	    function validateSearchParams(){
	  	  if($("#monthYearPicker").val()=="" || $("#monthYearPicker").val()==null){
	  	    	alert("Month and Year empty! please select month and year");
	  	    	return false;
	  	    }
	  	    else return true;
	  }

	    
	    $('#clearButton').click(function() {
	    	
	    	if (document.getElementById('customerSelect').value != "") {
	    		document.getElementById('customerSelect').value = "" ;
	    			$('#customerSelect').trigger('liszt:updated');	
	    	}
	    	$('#deliveryChallanNoSelect').empty();	
	    	$('#deliveryChallanNoSelect').children().remove();
	    	$('#deliveryChallanNoSelect').val('').trigger('liszt:updated');
	    	
	    	document.getElementById('partyAddress').value = "";
	   		document.getElementById('tinNo').value = "";
	   		document.getElementById('cstNo').value = "";
	   		document.getElementById('exciseDuty').value = "";
	   		document.getElementById('eduCess').value = "";
	   		document.getElementById('higherEduCess').value = "";
	   		document.getElementById('vat').value = "";
	   		document.getElementById('cst').value = "";
	    	
	    	$('#monthYearPicker').datepicker('setDate',systemDate);
	    	month = $("#ui-datepicker-div .ui-datepicker-month :selected").val();
	        year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
	    	$('#createInvoiceGrid').jqGrid('clearGridData');
	    	 jQuery("#createInvoiceGrid").setCaption("Delivery Challan List");
	    	 $.ajax({type:'POST',
	    		  url: 'viewdeliverychallan/fetchDeliveryChallan',
	    		  data: {"month":month,"year":year}, 
	    		  success: function(response) {
	    				if(response.length != 0){
	    					for(var i=0;i< response.length;i++){
	    						$('#deliveryChallanNoSelect').append('<option selected="selected">'+ "" + '</option>');
	    						$('#deliveryChallanNoSelect').append('<option >' + response[i]+ '</option>');
	    						$('#deliveryChallanNoSelect').trigger('liszt:updated');
	    					}
	    				}			
	    	 }
	    	 });
	    	
	    	
	    	
	    });