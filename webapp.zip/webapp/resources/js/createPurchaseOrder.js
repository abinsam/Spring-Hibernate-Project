var lastSelected;
$(function() {
	var curDate;
	if (new Date().getDate() > 9) {
		curDate = (new Date().getDate()) + "-" + (new Date().getMonth() + 1)
				+ "-" + (new Date().getFullYear());
	} else {
		curDate = "0" + (new Date().getDate()) + "-"
				+ (new Date().getMonth() + 1) + "-"
				+ (new Date().getFullYear());
	}

	$("#customerSelect").chosen({no_results_text : "No results matched"	});

	var purchaseOrderGrid = $("#purchaseOrderGrid")
			.jqGrid(
					{
						
						datatype : 'local', // initially set it as local once
						
						mtype : 'GET',
						colNames : [ 'Actions', 'Purchase Order No',
								'PO Date', 'Total Qty(Kgs)',
								'Balance Qty(Kgs)', 'postatushidden', 'CreatedBy1',
								'Created By', 'Createdtimehi', 'Createdtime',
								'Update Byhi', 'Update By', 'updatedtime',
								'PO Item Details' ,'mail sent'],
						colModel : [ {
							name : 'act',
							index : 'act',
							width : 90,
							sortable : false,
							viewable : false
						}, {
							name : 'poNo',
							index : 'poNo',
							width : 150,
							viewable : false
						}, {
							name : 'poDate',
							index : 'poDate',
							width : 180,
							editable : true
						},
						{
							name : 'quantity',
							index : 'quantity',
							width : 90
						}, {
							name : 'balanceQuantity',
							index : 'balanceQuantity',
							width : 100
						}, {
							name : 'poStatus',
							index : 'poStatushid',
							width : 10,
							viewable : false,
							editable : true,
							hidden : true
						}, {
							name : 'createdBy',
							index : 'createdBy',
							width : 10,
							editable : true,
							hidden : true
						}, {
							name : 'createdBy',
							index : 'createdBy',
							width : 150
						}, {
							name : 'createdTime',
							index : 'createdTime',
							width : 10,
							editable : true,
							hidden : true
						}, {
							name : 'createdTime',
							index : 'createdTime',
							width : 200,
							hidden : true
						}, {
							name : 'updatedBy',
							index : 'updatedBy',
							width : 10,
							editable : true,
							hidden : true
						}, {
							name : 'updatedBy',
							index : 'updatedBy',
							width : 150
						}, {
							name : 'updatedTime',
							index : 'updatedTime',
							width : 10,
							editable : true,
							hidden : true
						}, {
							name : 'orderDetailsLink',
							index : 'orderDetailsLink',
							width : 200,
							sortable:false,
							editable : false
						},{
							name : 'mailSent',
							index : 'mailSent',
							width : 10,
							editable : true,
							hidden : true
						}, ],
						postData : {},
						rowNum : 100,
						rowList : [ 5, 10, 20, 40, 60 ],
						height :425,
						autowidth : true,
						rownumbers : false,
						pager : '#purchaseOrderpager',
						sortname : 'poNo',
						viewrecords : true,
						sortorder : "desc",
						caption : "Purchase Orders",
						emptyrecords : "Empty records",
						loadonce : false,
						loadComplete : function() {
						},
						jsonReader : {
							root : "rows",
							page : "page",
							total : "total",
							records : "records",
							repeatitems : false,
							cell : "cell",
							id : "poNo"
						},
						ondblClickRow : function(id) {
							if (id && id !== lastSelected) {
								$('#purchaseOrderGrid').jqGrid('restoreRow',
										lastSelected);
								editRow(id);
								lastSelected = id;
							}
						},
						gridComplete : function() {
							var ids = $("#purchaseOrderGrid").jqGrid(
									'getDataIDs');
							for ( var i = 0; i < ids.length; i++) {
								var cl = ids[i];
								be = "<input style='height:22px; width:35px;' type='button' value='Edit' id='editRow"
										+ cl
										+ "' onclick=\"editRow('"
										+ cl
										+ "');\" />";
								de = "<input style='height:22px; width:30px;' type='button' value='Del' id='delRow"
										+ cl
										+ "' onclick=\"delRow('"
										+ cl
										+ "');\" />";
								se = "<input style='height:22px; width: 29px;' type='button' value='Save' hidden='hidden' id='saveRow"
										+ cl
										+ "' onclick=\"saveRow('"
										+ cl
										+ "');\" />";
								ce = "<input style='height:22px;width:39px;' type='button' value='Cancel' hidden='hidden' id='restoreRow"
										+ cl
										+ "' onclick=\"restoreRow('"
										+ cl
										+ "');\" />";

								odLink = "<button class='btn btn-mini' id='orderDetailLink"
										+ cl
										+ "' "
										+ "onclick=\"openPoItemDetailsPage('"
										+ cl
										+ "');\" > <b>PO Item Details</b></button>";
								$("#purchaseOrderGrid").jqGrid('setRowData',ids[i], {
											act : be + de + se + ce,
											orderDetailsLink : odLink
										});
								if(ids[i]=="new_row"){
									 $("#purchaseOrderGrid").jqGrid('setCell',ids[i],'poDate', curDate);
								}
							}
						},
						editurl : "createpurchaseorder/crud"

					});
	$("#purchaseOrderGrid").jqGrid('navGrid', "#purchaseOrderpager", {
		edit : false,
		add : false,
		del : false,view:false,search:false
	});

	$("#customerSelect").chosen().change(
			function() {
				var customerId = $('#customerSelect').val();
				var customerName = $('#customerSelect option:selected').text();
				purchaseOrderGrid.setCaption('Purchase Orders for "'
						+ customerName + '"');
				purchaseOrderGrid.setGridParam(
						{
							url : 'createpurchaseorder/records/'
									+ encodeURIComponent(customerId),
							page : 1,
							datatype : 'json'
						}).trigger('reloadGrid');
				;

			});
	$('#addPurchaseOrderBtn').click(function() {
		var custId = $('#customerSelect').val();
		if (custId == "") {
			alert("Please choose customer");
		} else {
			purchaseOrderGrid.jqGrid('addRow', {
				rowID : "new_row",
				addRowParams : {
					"keys" : true,
					"oneditfunc" : hideActButtons,
					aftersavefunc : function(savedId, response) {
						showActButtons(savedId);
					},
					afterrestorefunc : showActButtons,
					extraparam : {
						"customerId" : custId
					}
				}
			});
		}

	});
});

function openPoItemDetailsPage(poNo) {
	if (poNo == "new_row") {
		alert("Save the Purchase Order Detail");
		return false;
	} else {
		url = 'createpoitems?poNo=' + encodeURIComponent(poNo);
		window.open(url, '_blank');
	}
}

/*
 * function saveSalesOrder(orderId){ url= 'orders/saveSalesOrder'; }
 */

function pickdates(id) {
	$("#" + id + "_poDate", "#purchaseOrderGrid").datepicker({
		dateFormat : "dd-mm-yy",maxDate: 'today'
	});
}

function editRow(id) {
	var custId = $('#customerSelect').val();
	restoreRow(lastSelected);
	lastSelected = id;
	$('#purchaseOrderGrid').jqGrid('editRow', id, {
		"keys" : true,
		"oneditfunc" : hideActButtons,
		aftersavefunc : function(savedId, response) {
			showActButtons(savedId);
		},
		afterrestorefunc : showActButtons,
		extraparam : {
			"customerId" : custId
		}
	});
}

function delRow(id) {
	var grid = jQuery('#purchaseOrderGrid'); 
  var poNo=grid.jqGrid ('getCell', id, 'poNo');
 var customerId = $('#customerSelect').val();
	$.ajax({
			type : 'POST',
			url : 'createpurchaseorder/checkPOItems/' + encodeURIComponent(id),
			success : function(response) {
			if (response == "exist") {
					alert("Items exist for PO " +poNo);

				} else if (confirm("Are you sure you want to delete?")) {
				$.ajax({
					type : 'POST',
					url : 'createpurchaseorder/delete/' + encodeURIComponent(poNo),
					success : function(response) {
						alert("PO "+poNo+" Deleted sucessfully");
						jQuery("#purchaseOrderGrid").setGridParam({	datatype : 'json'});
						jQuery("#purchaseOrderGrid").setGridParam({url : 'createpurchaseorder/records/' + encodeURIComponent(customerId)});
						jQuery("#purchaseOrderGrid").trigger('reloadGrid');
					}
			});
		};}});
	
}

function saveRow(id) {
	var custId = $('#customerSelect').val();
	$('#purchaseOrderGrid').saveRow(id, {
		aftersavefunc : function(id, response) {
			showActButtons(id);
		},
		extraparam : {
			"customerId" : custId
		}
	});
	jQuery("#purchaseOrderGrid").trigger("reloadGrid");
}

function restoreRow(id) {
	$('#purchaseOrderGrid').jqGrid('restoreRow', id, {
		afterrestorefunc : showActButtons
	});
}

/*
 * Hides the Edit and Del Row Buttons on jqGrid and activates the Save and
 * restore(cancel) button
 * 
 */
function hideActButtons(id) {
	$('#editRow' + id).hide();
	$('#delRow' + id).hide();
	$('#saveRow' + id).show();
	$('#restoreRow' + id).show();
	pickdates(id);
}

/*
 * Shows the Edit and Del Row Buttons on jqGrid and hides the Save and
 * restore(cancel) button
 * 
 */
function showActButtons(id) {
	$('#editRow' + id).show();
	$('#delRow' + id).show();
	$('#saveRow' + id).hide();
	$('#restoreRow' + id).hide();
	lastSelected = null;
}

$(document).keypress(function(e) {
	if (e.which == 13) {
		var ids = $("#purchaseOrderGrid").jqGrid('getDataIDs');
		for ( var i = 0; i < ids.length; i++) {
			var cl = ids[i];
			saveRow(cl);
			var customerId = $('#customerSelect').val();
			jQuery("#purchaseOrderGrid").setGridParam({
				datatype : 'json'
			});
			jQuery("#purchaseOrderGrid").setGridParam({
				url : 'createpurchaseorder/records/' + encodeURIComponent(customerId)
			});
			jQuery("#purchaseOrderGrid").trigger('reloadGrid');

		}

	}
});
