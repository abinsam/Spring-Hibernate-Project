var price;
var lastSelected;
var gridQuantityValid=true;
var gridRateValid=true;

var itemCodeArray;


$(function() {
	
	  $.ajax({
	        url: 'createpoitems/fetchPoItemCode',
	        dataType: "json",
	         success: function(data) {
	        	 itemCodeArray=data;
	        }
	    });


		$("#itemCodesSelect").autocomplete({
		    source: function(request, response) {
		        var results = $.ui.autocomplete.filter(itemCodeArray, request.term);

		        response(results.slice(0, 15));
		    }
		});
	if (document.getElementById('poStatus').value != "Pending") {
		document.getElementById('submitPoItems').disabled = true;
		document.getElementById('addPoItemDetailsBtn').disabled = true;
	}

	var poNo = poItemDetailsForm.poNo.value;

	var poItemsGrid = $("#poItemsGrid")
			.jqGrid(
					{
						url : 'createpoitems/addedItems/'
								+ encodeURIComponent(poNo),
						datatype : 'json', // initially set it as local once
						// the customerId is selected it
						// should be updated to json.
						// http://stackoverflow.com/questions/3219734/jqgrid-posting-extra-custom-parameters-to-server
						mtype : 'GET',
						colNames : [ 'Actions', 'PO No', 'PoId', 'ItemId',
								'Item Code', 'deschiddn', 'Item Description',
								'Quantity', 'Unit', 'Rate(Rs)', 'Price(Rs)' ],
						colModel : [ {
							name : 'act',
							index : 'act',
							width : 35,
							sortable : false,
							viewable : false,
						}, {
							name : 'poNo',
							index : 'poNo',
							width : 50,
							editable : true,
							hidden:true
						}, {
							name : 'purchaseOrderItemId',
							index : 'purchaseOrderItemId',
							width : 50,
							viewable : false,
							hidden : true
						}, {
							name : 'itemId',
							index : 'itemId',
							width : 100,
							editable : true,
							hidden : true
						}, {
							name : 'itemCode',
							index : 'itemCode',
							width : 100
						}, {
							name : 'description',
							index : 'description',
							width : 10,
							hidden : true,
							editable:true
						}, {
							name : 'description',
							index : 'description',
							width : 200
						}, {
							name : 'quantity',
							index : 'quantity',
							width : 50,
							editable : true,
							editoptions:{
			                      dataInit: function(element) {
			                    	var patMatch = /^(\.\d{1,2}|\d{1,4}\.?\d{0,2}|\d{5}\.?\d?|\d{6}\.?\d?|\d{7}\.?\d?)$/;
			                          $(element).keyup(function(){
			                        	  var qtyVal = element.value;
			                        	 
			                        	 if(!patMatch.test(qtyVal)) {
			                        		 var x= alert("Please enter a valid quantity");
			                        		 x.moveBy(10,20);
			                        		 gridQuantityValid=false; 
			                        		  jQuery("#poItemsGrid").trigger('reloadGrid');
			                        	  }
			                        	  else   gridQuantityValid=true;
			                        	  
			                           });
			                      }
						,maxlength:5} 
						}, {
							name : 'unit',
							index : 'unit',
							width : 50
						}, {
							name : 'rate',
							index : 'rate',
							width : 50,
							editable : true,
							editoptions:{
			                      dataInit: function(element) {
			                    	var patMatch = /^[+]?([0-9]+(?:[\.][0-9]*)?|\.[0-9]+)$/;
			                          $(element).keyup(function(){
			                        	  var rateVal = element.value;
			                        	 if(!patMatch.test(rateVal)) {
			                        		 alert("Please enter a valid rate");
			                        		 gridRateValid=false;  
			                        		  jQuery("#poItemsGrid").trigger('reloadGrid');
			                        	  }
			                        	  else   gridRateValid=true;
			                        	  
			                           });
			                      }
			                  ,maxlength:5} 
						}, {
							name : 'price',
							index : 'price',
							width : 50
						}

						],

						postData : {},
						rowNum : 100,
						rowList : [ 5, 10, 20, 40, 60 ,100],
						height : 370,
						autowidth : true,
						rownumbers : false,
						pager : '#poitemspager',
						sortname : 'purchaseOrderItemId',
						viewrecords : true,
						sortorder : "desc",
						emptyrecords : "Empty records",
						loadonce : false,
						loadComplete : function() {
						},
						jsonReader : {
							root : "rows",
							page : "page",
							total : "total",
							records : "records",	
							repeatitems : false,
							cell : "cell",
							id : "purchaseOrderItemId"
						},
						ondblClickRow : function(id) {
							if (id && id !== lastSelected) {
								$('#poItemsGrid').jqGrid('restoreRow',
										lastSelected);
								editRow(id);
								lastSelected = id;
							}
						},
						gridComplete : function() {
							var ids = jQuery("#poItemsGrid").jqGrid(
									'getDataIDs');
							for ( var i = 0; i < ids.length; i++) {
								var cl = ids[i];
								be = "<input style='height:22px; width:35px;' type='button' value='Edit' id='editRow"
										+ cl
										+ "' onclick=\"editRow('"
										+ cl
										+ "');\" />";
								de = "<input style='height:22px; width:30px;' type='button' value='Del' id='delRow"
										+ cl
										+ "' onclick=\"delRow('"
										+ cl
										+ "');\" />";
								se = "<input style='height:22px; width: 29px;' type='button' value='Save' hidden='hidden' id='saveRow"
										+ cl
										+ "' onclick=\"saveRow('"
										+ cl
										+ "');\" />";
								ce = "<input style='height:22px;width:39px;' type='button' value='Cancel' hidden='hidden' id='restoreRow"
										+ cl
										+ "' onclick=\"restoreRow('"
										+ cl
										+ "');\" />";
								$("#poItemsGrid").jqGrid('setRowData', ids[i],
										{
											act : be + de + se + ce

										});
							}
						},

						editurl : "createpoitems/editFunc"
					});

	jQuery("#poItemsGrid").jqGrid('navGrid', '#poitemspager', {
		view : false,
		del : false,
		add : false,
		edit : false,
		search : false
	});

	$('#addPoItemDetailsBtn')
			.click(
					function() {
						var poNo = poItemDetailsForm.poNo.value;
						var itemValidate = false;
						var exciseDutyValidate = false;
						var cstValidate = false;
						if (document.getElementById('itemCodesSelect').value == "") {
							alert("Select Item");
							itemValidate = false;
						} else
							itemValidate = true;
						if (document.getElementById('exciseDuty').value == "") {
							alert("Enter excise duty");
							exciseDutyValidate = false;
						} else
							exciseDutyValidate = true;
						if (document.getElementById('cstValue').value == "") {
							alert("Enter cst tax");
							cstValidate = false;
						}

						else
							cstValidate = true;

						if (itemValidate == true && exciseDutyValidate == true
								&& cstValidate == true) {
							$
									.ajax({
										type : 'POST',
										url : 'createpoitems/create',
										data : $('#poItemDetailsForm')
												.serialize(),
										success : function(response) {
											if (response == "exist")
												alert("Added Item already exist for purchase order");
											else
												poItemsGrid.setGridParam({url : 'createpoitems/addedItems/'+ encodeURIComponent(poNo),datatype : 'json'}).trigger('reloadGrid');
											 document.getElementById('itemCodesSelect').value=""; 
											$("#itemCodesSelect").focus();
										}
									});
						}
					});
});

function editRow(id) {
	var orderStatus = document.getElementById('poStatus').value;
	if (orderStatus == "Pending") {
		restoreRow(lastSelected);
		lastSelected = id;
		$('#poItemsGrid').jqGrid('editRow', id, {
			"keys" : true,
			"oneditfunc" : hideActButtons,
			aftersavefunc : function(savedId, response) {
				showActButtons(savedId);
			},
			afterrestorefunc : showActButtons
		});
	} else {
		alert(orderStatus + " PO cannot be modified ");
	}
}

function saveRow(id) {
	if (gridQuantityValid && gridRateValid==true){	
	var orderStatus = document.getElementById('poStatus').value;
	if (orderStatus == "Pending") {
		$('#poItemsGrid').saveRow(id, {
			aftersavefunc : function(id, response) {
				showActButtons(id);
				var grid = jQuery('#poItemsGrid');
				var qty = grid.jqGrid('getCell', id, 'quantity');
				var rate = grid.jqGrid('getCell', id, 'rate');
				if (qty != null && rate != null) {
					var prd = qty * rate;
					grid.jqGrid('setCell', id, 'price', prd);
				} else
					grid.jqGrid('setCell', id, 'price', 0);
			}
		});
		 jQuery("#poItemsGrid").trigger('reloadGrid');
	} else {
		alert(orderStatus + " PO cannot be modified ");
	}
	}
}

function restoreRow(id) {
	$('#poItemsGrid').jqGrid('restoreRow', id, {
		afterrestorefunc : showActButtons
	});
}

/*
 * Hides the Edit and Del Row Buttons on jqGrid and activates the Save and
 * restore(cancel) button
 * 
 */
function hideActButtons(id) {
	$('#editRow' + id).hide();
	$('#delRow' + id).hide();
	$('#saveRow' + id).show();
	$('#restoreRow' + id).show();

}

/*
 * Shows the Edit and Del Row Buttons on jqGrid and hides the Save and
 * restore(cancel) button
 * 
 */
function showActButtons(id) {
	$('#editRow' + id).show();
	$('#delRow' + id).show();
	$('#saveRow' + id).hide();
	$('#restoreRow' + id).hide();
	lastSelected = null;
}

function delRow(id) {
	var poNo = poItemDetailsForm.poNo.value;
	var orderStatus = document.getElementById('poStatus').value;
	if (orderStatus == "Pending") {
		if (confirm(" Do you want to delete Purchase order item ?")) {
			$.ajax({
				type : 'POST',
				url : 'createpoitems/delete/' + encodeURIComponent(id),
				data : {
					"poNo" : poNo
				},
				success : function(response) {
					var poNo = poItemDetailsForm.poNo.value;

					jQuery("#poItemsGrid").setGridParam({
						datatype : 'json'
					});
					jQuery("#poItemsGrid").setGridParam(
							{
								url : 'createpoitems/addedItems/'
										+ encodeURIComponent(poNo)
							});
					jQuery("#poItemsGrid").trigger('reloadGrid');
					alert("PO Items deleted");
				}
			});
		}
	} else {
		alert(orderStatus + " PO cannot be deleted");
	}
}

$('#submitPoItems')
		.click(
				function() {

					if (confirm("Are you sure you want to submit the purchase order?")) {
						var poNo = poItemDetailsForm.poNo.value;
						$
								.ajax({
									type : 'POST',
									url : 'createpoitems/checkPrice',
									data : 'poNo=' + poNo,
									success : function(response) {
										if (response == "priceValid") {
											$
													.ajax({
														type : 'POST',
														url : 'createpurchaseorder/submitPoItems/'
																+ encodeURIComponent(poNo),
														success : function(
																response) {
															alert("Purchase Order "
																	+ poNo
																	+ "  with Item submitted");
															window.close();
														}
													});
										} else {
											alert("Price should not be empty!!");
										}
									}
								});
					}
				});

$('#closeButton').click(function() {
	window.close();
});


/*$(document).keypress(function(e) {
	if (e.which == 13) {
		var ids = $("#poItemsGrid").jqGrid('getDataIDs');
		for ( var i = 0; i < ids.length; i++) {
			var cl = ids[i];
			var grid = jQuery('#poItemsGrid');
			var qty = grid.jqGrid('getCell', cl, 'quantity');
			var rate = grid.jqGrid('getCell', cl, 'rate');
			if (qty != null && rate != null) {
				var prd = qty * rate;
				grid.jqGrid('setCell', cl, 'price', prd);
			} else
				grid.jqGrid('setCell', cl, 'price', 0);
		}
	}
});
*/
$(document).keypress(function(e) {
    if(e.which == 13) {
    	var ids = $("#poItemsGrid").jqGrid('getDataIDs');
    	for ( var i = 0; i < ids.length; i++) {
			var cl = ids[i];
			saveRow(cl);
       	} }});

$('input[name=quantity]')
		.change(
				function() {

					var quantityValue = document.getElementById('quantity').value;

					var patroon = /^[0-9](\.\d{1,2}|\d{1,4}\.?\d{0,2}|\d{5}\.?\d?|\d{6}\.?\d?|\d{7}\.?\d?)$/;
					if (quantityValue != null && quantityValue != "") {
						if (!patroon.test(quantityValue) || quantityValue == 0) {
							alert("Enter valid quantity value");
							document.getElementById('quantity').value = "";
							document.getElementById('quantity').focus();
							cstValidate = false;
						} else
							cstValidate = true;
					} else
						cstValidate = true;

				});

$('input[name=rate]').change(function() {
	var rate = document.getElementById('rate').value;
	var patroon = /^[+]?([0-9]+(?:[\.][0-9]*)?|\.[0-9]+)$/;
	if (rate != null && rate != "") {
		if (!patroon.test(rate)) {
			alert("Enter valid rate value");
			rateValid = false;
			document.getElementById('rate').value = "";
			document.getElementById('rate').focus();
			cstValidate = false;
		} else
			cstValidate = true;
	}
});


