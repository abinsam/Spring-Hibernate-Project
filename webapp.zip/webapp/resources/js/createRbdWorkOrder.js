var lastSelected;
$(function(){ 
	
	$("#rbdWoMachineNo").chosen({enable_split_word_search:true,no_results_text: "No results matched"});
	$("#rbdWorkOrderNoSelect").chosen({no_results_text: "No results matched"});
	$( "#rbdStartDate" ).datepicker({dateFormat : "dd-mm-yy",maxDate:'today',
		onSelect: function(dateStr)
                {
                var min = $('#rbdStartDate').datepicker('getDate'); 
                 $('#rbdCompletionDate').datepicker('option', {minDate : min});
          }});
    $( "#rbdCompletionDate" ).datepicker({dateFormat : "dd-mm-yy"});
    	
    $('#rbdWorkOrderNoSelect').append(""); 
	$('#rbdWorkOrderNoSelect').trigger('liszt:updated');
    
    
	$("#createRBDWorkOrderGrid").jqGrid({
	url: 'createRBDWorkOrder/records',
	datatype : 'json',
	mtype : 'POST',
	multiselect:true,
    colNames:['Id','Vendor Name','Vendor NameHidden','Item Code','Item Description','Gross Weight(Kgs)','Tare Weight(Kgs)','Net Weight(Kgs)','Batch No','No Of Bags','Total Qty','Units','QC Status'],
   	colModel:[
   	    
             {name:'rwStoreRegId', index:'rwStoreRegId', width:10,hidden:true},   
             {name:'customerCode', index:'customerCode', width:70}, 
	          {name:'customerName', index:'customerName', width:20,hidden:true},
	          {name:'itemCode',index:'itemCode', width:100},
	          {name:'itemDescription',index:'itemDescription', width:100},
	          {name:'grossWeight',index:'grossWeight', width:50},
	          {name:'tareWeight',index:'tareWeight', width:50},
	          {name:'netWeight',index:'netWeight', width:50},
	          {name:'batchNo',index:'batchNo', width:40},
	          {name:'noOfBags',index:'noOfBags', width:40},
	          {name:'totalQty',index:'totalQty', width:30},
	          {name:'units',index:'units', width:20},
	          {name:'qcStatus',index:'qcStatus', width:30}
   	       ],
	postData : {},
	rowNum : 100,
	rowList : [ 5, 10, 20, 40, 60,100 ],
	height : 300,
	autowidth : true,
	rownumbers : false,
	   	pager: '#createRBDWorkOrderPager',
	   	sortname: 'rwStoreRegId',
	    viewrecords: true,
	    sortorder: "desc",
	    caption:"Raw Materials Stock",
	    emptyrecords: "Empty records",
	    loadonce: false,
	    footerrow: true,
	    loadComplete: function() {},
	    jsonReader : {
	        root: "rows",
	        page: "page",
	        total: "total",
	        records: "records",
	        repeatitems: false,
	        cell: "cell",
	        id: "rwStoreRegId"
	    },
	    ondblClickRow : function(id) {
			if (id && id !== lastSelected) {
				$('#createRBDWorkOrderGrid').jqGrid('restoreRow',lastSelected);
				editRow(id);
				lastSelected = id;
			}
		},
	 onSelectRow: updateIdsOfSelectedRows,   
	onSelectAll : function(aRowids, status) {
		updateIdsOfStockOutAllSelectedRows(aRowids, status);
	},
    loadComplete: function () {
        var $this = $(this), i, count;
        for (i = 0, count = idsOfSelectedRows.length; i < count; i++) {
            $this.jqGrid('setSelection', idsOfSelectedRows[i], false);
        }
      },
      gridComplete: function(){ 
    	     var totalGrossWeight = $('#createRBDWorkOrderGrid').jqGrid('getCol','grossWeight',false,'sum');
	   		 var totalTareWeight = $('#createRBDWorkOrderGrid').jqGrid('getCol','tareWeight',false,'sum');
	   		 var totalNetWeight = $('#createRBDWorkOrderGrid').jqGrid('getCol','netWeight',false,'sum');
	   		 var totalBag = $('#createRBDWorkOrderGrid').jqGrid('getCol','noOfBags',false,'sum');
	   		 var totalQuantity = $('#createRBDWorkOrderGrid').jqGrid('getCol','totalQty',false,'sum');
	   	
	   		$('#createRBDWorkOrderGrid').jqGrid('footerData','set', {ID: 'Total:', grossWeight: totalGrossWeight});
   	    	$('#createRBDWorkOrderGrid').jqGrid('footerData','set', {ID: 'Total:', tareWeight: totalTareWeight});
   	    	$('#createRBDWorkOrderGrid').jqGrid('footerData','set', {ID: 'Total:', netWeight: totalNetWeight});
   	    	$('#createRBDWorkOrderGrid').jqGrid('footerData','set', {ID: 'Total:', noOfBags: totalBag});
   	    	$('#createRBDWorkOrderGrid').jqGrid('footerData','set', {ID: 'Total:', totalQty: totalQuantity});
   	    	$('#createRBDWorkOrderGrid').jqGrid('footerData','set', {ID: 'Total:', units: "Kgs"});
   	 
	   	
      },
		editurl : "viewworkorder/crud",
		beforeSelectRow: function (rowid, e) {
		    var $myGrid = $(this),
		        i = $.jgrid.getCellIndex($(e.target).closest('td')[0]),
		        cm = $myGrid.jqGrid('getGridParam', 'colModel');
		    return (cm[i].name === 'cb');
		   }
	

	 }).navGrid('#createRBDWorkOrderPager',{view:false, del:false, edit:false, search:false,add:false},
			  {}, // use default settings for edit
		    	{}, // settings for add
		    	{},  // delete instead that del:false we need this
		    	{multipleSearch : true}, // enable the advanced searching
		    	{} /* allow the view dialog to be closed when user press ESC key*/
		    	);

});



idsOfSelectedRows = ["1", "2", "3"];
var $CreateRBDWorkOrderGrid= $("#createRBDWorkOrderGrid"), idsOfSelectedRows = [],
updateIdsOfSelectedRows = function (id, isSelected) {
	   var index = $.inArray(id, idsOfSelectedRows);
        if (!isSelected && index >= 0) {
            idsOfSelectedRows.splice(index, 1); // remove id from the list
        } else if (index < 0) {
            idsOfSelectedRows.push(id);
        }  
};


function createRBDWorkOrderFn(){
	if(document.getElementById('rbdWorkOrderNoSelect').value==""){
	var validRbd=validateRbdProcess();
	if(validRbd==true){
		$.ajax({type:'POST', 
			url: 'createRBDWorkOrder/saveRbdWorkOrder', 
			data:{'rbdStartDate' : $("#rbdStartDate").val() , 
			     'rbdCompletionDate' : $("#rbdCompletionDate").val(), 
	   		     'rbdWoMachineNo' : $("#rbdWoMachineNo").val() , 
				  'idsOfSelectedRows': idsOfSelectedRows},
			success: function(response) {
				 alert("Rbd Work Order :"+response[0]+" is created");
					idsOfSelectedRows=[];

				 $('#rbdWorkOrderNoSelect').append('<option>'+response[0]+'</option>');
				 $('#rbdWorkOrderNoSelect').trigger('liszt:updated');
				    document.getElementById('rbdStartDate').value="";
			        document.getElementById('rbdCompletionDate').value="";
			        document.getElementById('rbdWoMachineNo').value="";
			        $('#rbdWoMachineNo').trigger('liszt:updated');
			         jQuery("#createRBDWorkOrderGrid").setGridParam({datatype:'json'}); 
					 jQuery("#createRBDWorkOrderGrid").setGridParam({ url: 'createRBDWorkOrder/records'});
					 jQuery("#createRBDWorkOrderGrid").trigger('reloadGrid');

		
			}});
	}
	}// end of if loop
	else{
		var validIdRbd=validateRawMaterialSelect();
		if(validIdRbd==true){
				$.ajax({type:'POST', 
				url: 'createRBDWorkOrder/updateRbdWorkOrder', 
				data:{'rbdWorkOrderNo' : $("#rbdWorkOrderNoSelect").val(),
		    		'idsOfSelectedRows': idsOfSelectedRows},
				success: function(response) {
					alert("Work Order Input is updated");
					idsOfSelectedRows=[];
			         jQuery("#createRBDWorkOrderGrid").setGridParam({datatype:'json'}); 
					 jQuery("#createRBDWorkOrderGrid").setGridParam({ url: 'createRBDWorkOrder/records'});
					 jQuery("#createRBDWorkOrderGrid").trigger('reloadGrid');
					
				}});
		}
	}// end of else loop
}

function validateRawMaterialSelect(){
	if(idsOfSelectedRows==""){
		alert("Select raw material for RBD process");
		return false;
	}	
	else return true;
}

function validateRbdProcess(){
	if(idsOfSelectedRows==""){
		alert("Select raw material for RBD process");
		return false;
	}
	else if($("#rbdStartDate").val()==""){
		alert("Enter RBD process start date ");
		return false;
	}
	else if($("#rbdWoMachineNo").val()==""){
		alert("Select Machine");
		return false;
	}	
	else
		return true;
}

$("#rbdWorkOrderNoSelect").chosen().change( function(){
	var woNo=$('#rbdWorkOrderNoSelect').val();
	$.ajax({type:'POST', 
			url: 'storeRegisterForRBD/fetchWoDetails/'+ encodeURIComponent(woNo),
			success: function(response) {
				  document.getElementById('rbdWorkOrderStatus').value=response[6];
				 if(response[6]=="Submitted")
						document.getElementById('createRBDWorkOrder').disabled=true;
				 else
					 document.getElementById('createRBDWorkOrder').disabled=false;
			}});
	
	
	
	document.getElementById('rbdWoMachineNo').value = "";
	$('#rbdWoMachineNo').trigger('liszt:updated');
	document.getElementById('rbdStartDate').value = "";
	document.getElementById('rbdCompletionDate').value = "";
});

$("#rbdWoMachineNo").chosen().change( function() {
	document.getElementById('rbdWorkOrderStatus').value = "";
	document.getElementById('rbdWorkOrderNoSelect').value = "";
	$('#rbdWorkOrderNoSelect').trigger('liszt:updated');
	 document.getElementById('createRBDWorkOrder').disabled=false;
});

$("#rbdStartDate").click(function(){
	document.getElementById('rbdWorkOrderStatus').value = "";
	document.getElementById('rbdWorkOrderNoSelect').value = "";
	$('#rbdWorkOrderNoSelect').trigger('liszt:updated');
	 document.getElementById('createRBDWorkOrder').disabled=false;

 }); 

$("#rbdCompletionDate").change(function(){
	document.getElementById('rbdWorkOrderStatus').value = "";
	document.getElementById('rbdWorkOrderNoSelect').value = "";
	$('#rbdWorkOrderNoSelect').trigger('liszt:updated');
	 document.getElementById('createRBDWorkOrder').disabled=false;

});

$('#clearSearchBox').click(function(){
	document.getElementById('rbdWorkOrderNoSelect').value ="";
	$('#rbdWorkOrderNoSelect').trigger('liszt:updated');
	
	document.getElementById('rbdWoMachineNo').value ="";
	$('#rbdWoMachineNo').trigger('liszt:updated');
	
	document.getElementById('rbdStartDate').value = "";
	document.getElementById('rbdCompletionDate').value = "";
	document.getElementById('rbdWorkOrderStatus').value = "";
});

updateIdsOfSelectedRows = function(id, isSelected) {
	var grid = jQuery('#createRBDWorkOrderGrid');
	var qcStatus = grid.jqGrid('getCell', id, 'qcStatus');
	
	if (qcStatus == "Approved") {
		var index = $.inArray(id, idsOfSelectedRows);
		if (!isSelected && index >= 0) {
			idsOfSelectedRows.splice(index, 1); // remove id from the list
		} else if (index < 0) {
			idsOfSelectedRows.push(id);
		}
	} else {
				alert("Select QC approved Items");
				$("#createRBDWorkOrderGrid").resetSelection(id);
	}

};

updateIdsOfStockOutAllSelectedRows = function(aRowids, isSelected) {
	var salesStatus = 0;
	var grid = jQuery('#createRBDWorkOrderGrid');
	for (i = 0, count = aRowids.length; i < count; i++) {
		id = aRowids[i];
		var qcStatus = grid.jqGrid('getCell', id, 'qcStatus');
		if (qcStatus == "Approved") {
			var index = $.inArray(id, idsOfSelectedRows);
			if (!isSelected && index >= 0) {
				idsOfSelectedRows.splice(index, 1); // remove id from the list
			} else if (index < 0) {
				idsOfSelectedRows.push(id);
			}
		  } else 
				salesStatus++;
      }
  if (salesStatus > 0) {
		alert("Select QC approved Items ");
		$("#createRBDWorkOrderGrid").resetSelection();

	} 
};
