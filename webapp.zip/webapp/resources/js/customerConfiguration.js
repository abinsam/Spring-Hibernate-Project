var lastSelected;
$(function() {
	
	$("#customerSelect").chosen({no_results_text : "No results matched"});
	$("#customerGrid")
			.jqGrid(
					{
						url : 'customers/records',
						datatype : 'json',
						mtype : 'POST',
						colNames : [ 'Action', 'Id', 'Customer Name*', 'Customer Code*',
								'Contact Person*', 'Contact No*',
								'Alternate Contact Number', 'Email*', 'Address',
								'City', 'State', 'Country', 'Pincode',
								'VAT Reg No', 'CST Reg No', 'ECC No', 'TIN No',
								'PAN No'],
						colModel : [ {
							name : 'act',
							index : 'act',
							width : 70,
							sortable : false,
							viewable : false
						}, {
							name : 'customerId',
							index : 'customerId',
							width : 100,
							hidden : true,
							viewable : false
						}, {
							name : 'customerName',
							index : 'customerName',
							width : 300,
							editable : true,
							editoptions : {
								size : 50,maxlength:50
							}
						}, {
							name : 'customerCode',
							index : 'customerCode',
							width : 110,
							editable : true,
							editoptions : {
								size : 20,maxlength:20
							}
						}, {
							name : 'contactPerson',
							index : 'contactPerson',
							width : 150,
							editable : true,
							editoptions : {
								size : 30,maxlength:30
							}
						}, {
							name : 'contactNo',
							index : 'contactNo',
							width : 130,
							editable : true,
						    editoptions:{size : 12,maxlength:12,
			                       dataInit: function(element) {
			                              $(element).keyup(function(){
			                                  var val1 = element.value;
			                                  var num = new Number(val1);
			                                  if(isNaN(num))
			                                  {
			                                	  alert("Please enter valid Contact Number");
			                                 }
			                                
			                              });
			                          }
			                      }
						}, {
							name : 'altContactNo',
							index : 'altContactNo',
							width : 130,
							editable : true,
							editoptions:{size : 12,maxlength:12,
			                       dataInit: function(element) {
			                              $(element).keyup(function(){
			                                  var val1 = element.value;
			                                  var num = new Number(val1);
			                                  if(isNaN(num))
			                                  {
			                                	  alert("Please enter valid Alternate Contact Number");
			                                 }
			                                
			                              });
			                          }
			                      }
						}, {
							name : 'email',
							index : 'email',
							width : 200	,
							editable : true,
							editoptions : {
								size : 50,maxlength:200
							},
							/*editrules:{custom:true, custom_func:validateEmail},*/
						}, {
							name : 'address',
							index : 'address',
							width : 300,
							edittype : 'textarea',
							editable : true,
							editoptions : {
								rows : 2,
								columns : 40
							}
						}, {
							name : 'city',
							index : 'city',
							width : 100,
							editable : true,
							editoptions : {
								size : 20,maxlength:20
							}
						}, {
							name : 'state',
							index : 'state',
							width : 100,
							editable : true,
							editoptions : {
								size : 20,maxlength:20
							}
						}, {
							name : 'country',
							index : 'country',
							width : 100,
							editable : true,
							editoptions : {
								size : 20,maxlength:20
							}
						}, {
							name : 'pincode',
							index : 'pincode',
							width : 100,
							editable : true,
							editoptions:{size : 10,maxlength:10,
			                       dataInit: function(element) {
			                              $(element).keyup(function(){
			                                  var val1 = element.value;
			                                  var num = new Number(val1);
			                                  if(isNaN(num))
			                                  {
			                                	  alert("Please enter valid Pin Code");
			                                 }
			                                
			                              });
			                          }
			                      }
						}, {
							name : 'vatRegNo',
							index : 'vatRegNo',
							width : 100,
							editable : true,
							editoptions : {
								size : 20,maxlength:20
							}
						}, {
							name : 'cstRegNo',
							index : 'cstRegNo',
							width : 100,
							editable : true,
							editoptions : {
								size : 20,maxlength:20
							}
						}, {
							name : 'eccNo',
							index : 'eccNo',
							width : 100,
							editable : true,
							editoptions : {
								size : 20,maxlength:20
							}
						}, {
							name : 'tinNo',
							index : 'tinNo',
							width : 100,
							editable : true,
							editoptions : {
								size : 20,maxlength:20
							}
						}, {
							name : 'panNo',
							index : 'panNo',
							width : 100,
							editable : true,
							editoptions : {
								size : 20,maxlength:20
							}
						}
					
						],
						postData : {},
						rowNum : 50,
						rowList : [ 5, 10, 20, 40, 60,100 ],
						height : 1000,
						autowidth : 1000,
						rownumbers : false,
						pager : '#pager',
						sortname : 'customerName',
						viewrecords : true,
						sortorder : "asc",
						caption : "Records",
						emptyrecords : "Empty records",
						loadonce : false,
						loadComplete : function() {
						},
						jsonReader : {
							root : "rows",
							page : "page",
							total : "total",
							records : "records",
							repeatitems : false,
							cell : "cell",
							id : "customerId"
						},
						ondblClickRow : function(id) {
							if (id && id !== lastSelected) {
								editRow(id);
							}
						},
						gridComplete : function() {
							var ids = $("#customerGrid").jqGrid('getDataIDs');
							for ( var i = 0; i < ids.length; i++) {
								var cl = ids[i];
								be = "<input style='height:22px; width:35px;' type='button' value='Edit' id='editRow"
										+ cl
										+ "' onclick=\"editRow('"
										+ cl
										+ "');\" />";
								de = "<input style='height:22px; width:30px;' type='button' value='Del' id='delRow"
										+ cl
										+ "' onclick=\"delRow('"
										+ cl
										+ "');\" />";
								se = "<input style='height:22px; width: 29px;' type='button' value='Save' hidden='hidden' id='saveRow"
										+ cl
										+ "' onclick=\"saveRow('"
										+ cl
										+ "');\" />";
								ce = "<input style='height:22px;width:39px;' type='button' value='Cancel' hidden='hidden' id='restoreRow"
										+ cl
										+ "' onclick=\"restoreRow('"
										+ cl
										+ "');\" />";
								$("#customerGrid").jqGrid('setRowData', ids[i],
										{
											act : be + de + se + ce
										});
							}
						},
						editurl : "customers/crud"
					}).navGrid('#pager', {
				view : true,
				del : false,
				edit : true,
				search:false
			}, 
			{
				addCaption : "Edit Customer",
				width : 500,
				height : 800
			},
			{
				addCaption : "Add Customer",
				width : 500,
				height : 800
			},
			{},
			{
				multipleSearch : true
			}, // enable the advanced searching
			{
				left : 150,
				caption : "View Customer",
				width : 600,
				bClose : "Close",
				closeOnEscape : true
			},
			// use default settings for edit
			 // settings for add
			{}
			// delete instead that del:false we need this
			 /* allow the view dialog to be closed when user press ESC key */
			);
});

$("#customerSelect").chosen().change(function() {
	
	var customerId = $('#customerSelect').val();

	    jQuery("#customerGrid").setGridParam({datatype:'json'}); 
		jQuery("#customerGrid").setGridParam({ url : 'customers/getCustomerDetails'});
	    jQuery("#customerGrid").setGridParam({postData: {customerId:customerId}}); 
    	jQuery("#customerGrid").trigger('reloadGrid');


});

$('#clearSearchBox').click(function() {
	if ($("#customerSelect").val() != "") {
		document.getElementById('customerSelect').value = "";
		$('#customerSelect').trigger('liszt:updated');
	}
	jQuery("#customerGrid").setGridParam({datatype : 'json'});
	jQuery("#customerGrid").setGridParam({ url : 'customers/records'});
	jQuery("#customerGrid").trigger('reloadGrid');

});
function editRow(id) {
	restoreRow(lastSelected);
	lastSelected = id;
	$('#customerGrid').jqGrid('editRow', id, {
		"keys" : true,
		"oneditfunc" : hideActButtons,
		aftersavefunc : function(savedId, response) {
			showActButtons(savedId);
		},
		afterrestorefunc : showActButtons
	});
}

function delRow(id) {

	$("#customerGrid").jqGrid('delGridRow', id);
}

function saveRow(id) {
	$('#customerGrid').saveRow(id, {
		aftersavefunc : function(id, response) {
			showActButtons(id);
		}
	});
}
function validateEmail(element,email) {
	
	 var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;				  

      	  var val1 = element.value;
      	 if(!reg.test(val1)) 
      		return [false,alert("Please enter valid Email Id")];
      	 else 
      		  
      			return [true,""];
  
      
}
function restoreRow(id) {
	$('#customerGrid').jqGrid('restoreRow', id, {
		afterrestorefunc : showActButtons
	});
}

/*
 * Hides the Edit and Del Row Buttons on jqGrid
 * and activates the Save and restore(cancel) button
 * 
 */
function hideActButtons(id) {
	$('#editRow' + id).hide();
	$('#delRow' + id).hide();
	$('#saveRow' + id).show();
	$('#restoreRow' + id).show();
}

/*
 * Shows the Edit and Del Row Buttons on jqGrid
 * and hides the Save and restore(cancel) button
 * 
 */
function showActButtons(id) {
	$('#editRow' + id).show();
	$('#delRow' + id).show();
	$('#saveRow' + id).hide();
	$('#restoreRow' + id).hide();
	lastSelected = null;
}