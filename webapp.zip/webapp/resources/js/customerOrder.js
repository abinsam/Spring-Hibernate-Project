var lastSelected;
$(function() {
	if (new Date().getDate() > 9) {
		curDate = (new Date().getDate()) + "-" + (new Date().getMonth() + 1)
				+ "-" + (new Date().getFullYear());
	} else {
		curDate = "0" + (new Date().getDate()) + "-"
				+ (new Date().getMonth() + 1) + "-"
				+ (new Date().getFullYear());
	}

	$("#customerSelect").chosen({
		no_results_text : "No results matched"
	});

	var orderGrid = $("#orderGrid")
			.jqGrid(
					{
						url : 'orders/records',
						datatype : 'local', // initially set it as local once
											// the customerId is selected it
											// should be updated to json.
						// http://stackoverflow.com/questions/3219734/jqgrid-posting-extra-custom-parameters-to-server
						mtype : 'GET',
						colNames : [  'SalesOrder', 'Party PO No','Receipt Mode*', 'Received On',
										 'Accepted On','Customer Target Date','Delivery On',
										'Status', 'Created By', 'Createdby hid','Created Date','createdtime hid',
										 'Updated By','Mail Status','LME','Updated Date','ADD ITEMS','Action' ],
								colModel : [
										
										{name : 'orderId',index : 'orderId',width : 100,viewable : false},
										{name : 'poDetails',index : 'poDetails',width : 100,editable : true,edittype:'text',editoptions : {size : 50,maxlength:15}},
										{name : 'modeOfReceipt',index : 'modeOfReceipt',width : 110,editable : true,edittype : 'select',editoptions : {value : "Email:Email;Telephone:Telephone;Web:Web"}}, 
										{name : 'orderRecDate',index : 'orderRecDate',width : 100,editable : true}, 
										{name : 'orderAcceptanceDate',index : 'orderAcceptanceDate',width : 100,editable : true},
										{name : 'targetDate',index : 'targetDate',width : 120}, 
										{name : 'orderDeliveryDate',index : 'orderDeliveryDate',width : 100,editable : true},
										{name : 'status',index : 'status',width : 90,viewable : false}, 
										{name : 'createdBy',index : 'createdBy',width : 110},
										{name : 'createdBy',index : 'createdBy',width : 50,editable:true,hidden:true},
										{name : 'createdTime',index : 'createdTime',width : 90,hidden : true},
										{name : 'createdTime',index : 'createdTime',width : 10,editable : true,hidden : true},
										{name : 'updatedBy',index : 'updatedBy',width : 110},
										{name : 'mailStatus',index : 'mailStatus',width : 10,editable:true,hidden:true},
										{name : 'lmeDetails',index : 'lmeDetails',width : 120,editable:true,hidden:true},
										{name : 'updatedTime',index : 'updatedTime',width : 90,hidden : true},
										{name : 'orderDetailsLink',index : 'orderDetailsLink',width : 100,sortable : false,editable : false},
										{name : 'act',index : 'act',width : 70,sortable : false,viewable : false}
										],
						postData : {},
						rowNum : 100,
						rowList : [ 5, 10, 20, 40, 50,100 ],
						height : 400,
						autowidth : true,
						rownumbers : false,
						pager : '#pager',
						sortname : 'orderId',
						viewrecords : true,
						sortorder : "desc",
						caption : "Sales Orders",
						emptyrecords : "Empty records",
						loadonce : false,
						loadComplete : function() {
						},
						jsonReader : {
							root : "rows",
							page : "page",
							total : "total",
							records : "records",
							repeatitems : false,
							cell : "cell",
							id : "orderId"
						},
						ondblClickRow : function(id) {
							if (id && id !== lastSelected) {
								$('#orderGrid').jqGrid('restoreRow',
										lastSelected);
								editRow(id);
								lastSelected = id;
							}
						},
						gridComplete : function() {
							var ids = $("#orderGrid").jqGrid('getDataIDs');
							for ( var i = 0; i < ids.length; i++) {
								var cl = ids[i];
								be = "<input style='height:22px; width:35px;' type='button' value='Edit' id='editRow"+cl+"' onclick=\"editRow('"+ cl + "');\" />";
								de = "<input style='height:22px; width:30px;' type='button' value='Del' id='delRow"+cl+"' onclick=\"delRow('"+ cl + "');\" />";
								se = "<input style='height:22px; width: 29px;' type='button' value='Save' hidden='hidden' id='saveRow"+cl+"' onclick=\"saveRow('"+ cl + "');\" />";
								ce = "<input style='height:22px;width:39px;' type='button' value='Cancel' hidden='hidden' id='restoreRow"+cl+"' onclick=\"restoreRow('"+ cl + "');\" />";
								odLink = "<button class='btn btn-mini' style='font-weight: bold;' id='orderDetailLink"
										+ cl
										+ "' "
										+ "onclick=\"openOrderDetailsPage('"
										+ cl
										+ "');\" > ADD ITEMS </button>";
								$("#orderGrid").jqGrid('setRowData', ids[i], {
									act : be + de+se + ce,
									orderDetailsLink : odLink
								});
								if(ids[i]=="new_row"){
									 $("#orderGrid").jqGrid('setCell',ids[i],'orderAcceptanceDate', curDate);
								}
								}
						},
			
					editurl : "orders/crud"

					});
	$("#orderGrid").jqGrid('navGrid', "#pager", {
		view:false,edit : false,add : false,del : false,search:false});


	$("#customerSelect").chosen().change(function() {
		var customerId = $('#customerSelect').val();
		var customerName = $('#customerSelect option:selected').text();
		orderGrid.setCaption('Orders for "' + customerName + '"');
		orderGrid.setGridParam({url : 'orders/records/' + encodeURIComponent(customerId),page : 1,datatype : 'json'}).trigger('reloadGrid');
		;

	});

	
	
	
	
	$('#addOrderBtn').click(function() {

		var custId = $('#customerSelect').val();
		if (custId == "") {
			alert("Please choose customer");
		} else {
			orderGrid.jqGrid('addRow', {
				rowID : "new_row",
				addRowParams : {
					"keys" : true,
					"oneditfunc" : hideActButtons,
					aftersavefunc : function(savedId, response) {
						showActButtons(savedId);
					},
					afterrestorefunc : showActButtons,
					extraparam : {
						"customerId" : custId
					}
				}
			});
			
		}
		
	});
});

function openOrderDetailsPage(orderId) {
	if (orderId == "new_row") {
		alert("Save the Sales Order Detail");
		return false;
	} else {
		url = 'orderdetails?orderId=' + encodeURIComponent(orderId);
		window.open(url, '_blank');
	}
}

function pickdates(id) {
    $("#" + id + "_orderRecDate", "#orderGrid").datepicker({dateFormat : "dd-mm-yy",
 
   maxDate: 'today',
   onSelect: function(dateStr)
    {
      var min =$("#" + id + "_orderRecDate", "#orderGrid").datepicker('getDate'); 
     
      $("#" + id + "_orderAcceptanceDate", "#orderGrid").datepicker('option', {minDate : min});
      
      var min1 = $("#" + id + "_orderAcceptanceDate", "#orderGrid").datepicker('getDate'); 

     $("#" + id + "_orderDeliveryDate", "#orderGrid").datepicker('option', {minDate : min1});
    } });
 

    $("#" + id + "_orderAcceptanceDate", "#orderGrid").datepicker({dateFormat : "dd-mm-yy",
      	  onSelect: function(dateStr)
  	    {
  	      var minAcceptDate =$("#" + id + "_orderAcceptanceDate", "#orderGrid").datepicker('getDate'); 
  	      if(minAcceptDate!=null || minAcceptDate!="")
  	      $("#" + id + "_orderDeliveryDate", "#orderGrid").datepicker('option', {minDate : minAcceptDate});
  	    }});
  
    $("#" + id + "_targetDate", "#orderGrid").datepicker({dateFormat : "dd-mm-yy"});
    $("#" + id + "_orderDeliveryDate", "#orderGrid").datepicker({dateFormat : "dd-mm-yy",
    	  onSelect: function(dateStr)
    	    {
    	      var minDate =$("#" + id + "_orderAcceptanceDate", "#orderGrid").datepicker('getDate'); 
    	      if(minDate!=null || minDate!="")
    	      $("#" + id + "_orderDeliveryDate", "#orderGrid").datepicker('option', {minDate : minDate});
    	    }});
    
}

function editRow(id) {
	var grid = jQuery('#orderGrid'); 
	var orderStatus = grid.jqGrid ('getCell', id, 'status'); 
  
	 if(orderStatus=="Pending" || orderStatus=="Approved For Prodn" || orderStatus=="Created"){
	var custId = $('#customerSelect').val();
	restoreRow(lastSelected);
	lastSelected = id;
	$('#orderGrid').jqGrid('editRow', id, {
		"keys" : true,
		"oneditfunc" : hideActButtons,
		aftersavefunc : function(savedId, response) {
			showActButtons(savedId);
		},
		afterrestorefunc : showActButtons,
		extraparam : {
			"customerId" : custId
		}
	});
   }
}
function delRow(id) {
	var grid = jQuery('#orderGrid'); 
	var orderStatus = grid.jqGrid ('getCell', id, 'status'); 
	  if(orderStatus=="Pending" || orderStatus=="Approved For Prodn" || orderStatus=="Created"){
 	$.ajax({type:'POST', 
 		url: 'workorder/checkOrderStatus/'+ encodeURIComponent(id),
		success: function(response) {
		if(response=="exist"){
			alert("Sales Order sent to Wo level");
		}
		else{
			 if (confirm(" Do you want to cancel Sales Order "+id)){
			$.ajax({type:'POST', 
				url: 'orders/delete/'+ encodeURIComponent(id),
				success: function(response) {
					var customerId=$('#customerSelect').val();
					     jQuery("#orderGrid").setGridParam({datatype:'json'}); 
						 jQuery("#orderGrid").setGridParam({ url : 'orders/records/' + encodeURIComponent(customerId)});
						 jQuery("#orderGrid").trigger('reloadGrid');

				}
			});
			 }
		}
	
	}});
  }
}

function saveRow(id) {
	var custId = $('#customerSelect').val();
	$('#orderGrid').saveRow(id, {
		aftersavefunc : function(id, response) {
			showActButtons(id);
		},
		extraparam : {
			"customerId" : custId
		}
	});
	jQuery("#orderGrid").trigger("reloadGrid");
}

function restoreRow(id) {
	$('#orderGrid').jqGrid('restoreRow', id, {
		afterrestorefunc : showActButtons
	});
}

/*
 * Hides the Edit and Del Row Buttons on jqGrid
 * and activates the Save and restore(cancel) button
 * 
 */
function hideActButtons(id) {
	$('#editRow' + id).hide();
	$('#delRow' + id).hide();
	$('#saveRow' + id).show();
	$('#restoreRow' + id).show();
	pickdates(id);
}

/*
 * Shows the Edit and Del Row Buttons on jqGrid
 * and hides the Save and restore(cancel) button
 * 
 */
function showActButtons(id) {
	$('#editRow' + id).show();
	$('#delRow' + id).show();
	$('#saveRow' + id).hide();
	$('#restoreRow' + id).hide();
	lastSelected = null;
}


function targetDateFormatter(cellvalue, options, rowObject){

	var grid = jQuery('#orderGrid'); 
	grid.jqGrid('setCell',options.rowId,rowObject.orderRecDate,cellvalue);
	grid.jqGrid('setCell',options.rowId,rowObject.targetDate,cellvalue);
 
}


$(document).keypress(function(e) {
    if(e.which == 13) {
    	var ids = $("#orderGrid").jqGrid('getDataIDs');
    	for ( var i = 0; i < ids.length; i++) {
			var cl = ids[i];
			saveRow(cl);
            var customerId=$('#customerSelect').val();
		    jQuery("#orderGrid").setGridParam({datatype:'json'}); 
			jQuery("#orderGrid").setGridParam({ url : 'orders/records/' + encodeURIComponent(customerId)});
		   jQuery("#orderGrid").trigger('reloadGrid');

		}
    	
    	
    }
});

