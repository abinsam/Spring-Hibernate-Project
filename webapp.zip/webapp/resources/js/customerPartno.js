var lastSelected;

$(function() {
    $.ajax({
        url: 'orderdetails/fetchItemCode',
        dataType: "json",
         success: function(data) {
        	 itemCodeArray=data;
        }
    });


	$("#itemCodesSelect").autocomplete({
	    source: function(request, response) {
	        var results = $.ui.autocomplete.filter(itemCodeArray, request.term);

	        response(results.slice(0, 15));
	    }
	});
	
	$("#customerSelect").chosen({no_results_text : "No results matched"});

	$("#customerPartNoGrid").jqGrid({
					
				       url : 'partNo/records',
				       datatype : 'json',
				       mtype : 'POST',
					   colNames : ['partNoId','customerId','itemId','Customer Name','Item Code','Item Description','Part No.','Actions'],
					   colModel : [ 
						   { name :'partNoId',index : 'partNoId',width : 100,hidden : true},
						   { name :'customerId',index : 'customerId',width : 100,hidden : true},
						   { name :'itemId',index : 'itemId',width : 100,hidden : true},
						   {name : 'customerName',index : 'customerName',width : 120,editable : false,viewable : false},
						   {name : 'itemCode',index : 'itemCode',width : 120,editable : false,viewable : false},
						   {name : 'itemDescription',index : 'itemDescription',	width : 120,editable : false,viewable : false},
						   {name : 'partNo',index : 'partNo',width : 40,editable : true,editoptions : {size : 50,maxlength:15}},
						   {name:'act',index:'act', width:25,sortable:false}
		
						],
						postData: {},
						rowNum:100,
					   	rowList:[50,100,200],
					   	height: 350,
					    autowidth : true,
						rownumbers: false,
						pager : '#customerPartNoPager',
						sortname: 'partNoId',
					    viewrecords: true,
					    sortorder: "desc",
					    caption:"Customer Part No. Details",
					    emptyrecords: "Empty records",
					    loadonce: false,
					    loadComplete: function() {},
					    jsonReader : {
					        root: "rows",
					        page: "page",
					        total: "total",
					        records: "records",
					        repeatitems: false,
					        cell: "cell",
							id : "partNoId"
						},
						 ondblClickRow : function(id) {
								if (id && id !== lastSelected) {
									$('#customerPartNoGrid').jqGrid('restoreRow',lastSelected);
									editRow(id);
									lastSelected = id;
								}
						},
							gridComplete : function() {
								var ids = $("#customerPartNoGrid").jqGrid('getDataIDs');
								for ( var i = 0; i < ids.length; i++) {
									var cl = ids[i];
									be = "<input style='height:22px; width:35px;' type='button' value='Edit' id='editRow"+cl+"' onclick=\"editRow('"+ cl + "');\" />";
									de = "<input style='height:22px; width:30px;' type='button' value='Del' id='delRow"+cl+"' onclick=\"delRow('"+ cl + "');\" />";
									se = "<input style='height:22px; width: 29px;' type='button' value='Save' hidden='hidden' id='saveRow"+cl+"' onclick=\"saveRow('"+ cl + "');\" />";
									ce = "<input style='height:22px;width:39px;' type='button' value='Cancel'  hidden='hidden' id='restoreRow"+cl+"' onclick=\"restoreRow('"+ cl + "');\" />";
									jQuery("#customerPartNoGrid").jqGrid('setRowData', ids[i],
											{
												act : be + de + se + ce
										
											});
								}
							},
							editurl : "partNo/crud"
					});
	$("#customerPartNoGrid").jqGrid('navGrid', "#customerPartNoPager", {
		edit:false,
		add : false,
		del : false,
		view:false,
		search:false
	});
});


$('#searchButton').click(function() {
	/*var customerId = document.getElementById('customerSelect').value;
	var itemId =document.getElementById('itemCodesSelect').value;*/
	
/*	if(customerId==null||customerId=="")
		{
		alert("Please Select Customer!");
		}

	else if(itemId==null||itemId=="")
		{
		alert("Please Select Item!");
		}
	else{
		
	}*/
	searchFunction();
			
});

function searchFunction() {

	var customerId = document.getElementById('customerSelect').value;
	var itemId = document.getElementById('itemCodesSelect').value;
	
	var searchOptions1 = {
		"groupOp" : "AND",
		"rules" : [ 
		            {"field" : "customerId","op" : "eq","data" : customerId},
			        {"field" : "itemCode","op" : "eq","data" : itemId}
		]
	};

	performSearch(searchOptions1, "#customerPartNoGrid");

}

function performSearch(searchOptions, gridId) {

	$(gridId).setGridParam({
		postData : {
			searchObject : JSON.stringify(searchOptions)
		}
	});
	$(gridId).trigger("reloadGrid");

}

$('#clearButton').click(function() {
	
	if ($("#customerSelect").val() != "") {
		document.getElementById('customerSelect').value = "";
		$('#customerSelect').trigger('liszt:updated');
	}
	if (document.getElementById('itemCodesSelect').value != "") {
		document.getElementById('itemCodesSelect').value = "";
	
	}
	if(document.getElementById('partNo').value != "")
     	document.getElementById('partNo').value = "";

	
	jQuery("#customerPartNoGrid").setGridParam({datatype : 'json'});
	jQuery("#customerPartNoGrid").setGridParam({postData : {searchObject : "allSearch"}});
	jQuery("#customerPartNoGrid").trigger('reloadGrid');

});

function editRow(id) {
	restoreRow(lastSelected);
	
	lastSelected = id;
	$('#customerPartNoGrid').jqGrid('editRow', id, {
		"keys" : true,
		"oneditfunc" : hideActButtons,
		aftersavefunc : function(savedId, response) {
			showActButtons(savedId);
		},
		afterrestorefunc : showActButtons
	});
}

$('#addButton').click(function() {
	var customerName = $('#customerSelect option:selected').text();
	var itemName = document.getElementById('itemCodesSelect').value;
	
		if(($("#customerSelect").val()=="")||($("#customerSelect").val()==null)){
			alert("Please Select Customer");
		}
		else if(itemName==""||itemName==null){
			alert("Please select Item");
		}	
		else if(document.getElementById('partNo').value==""){
			alert("Please enter Part No");
		}
		
		else{
			$.ajax({
				type : 'POST',
				url : 'partNo/addPartNo',
				data : {
					'customerSelect' : $("#customerSelect").val(),
					'itemIdSelect' :itemName,
					'partNo' : document.getElementById('partNo').value
				},
				success: function(response) {
			
					if (response.length>0) {
						
						if (response[0] == "Exist") {
							alert("Part No. exists for the customer and the item that has been selected!");
						}
						
						if (response[0] == "Added") {
							
							alert("Part No. for "+ customerName +" and "+ itemName +" Successfully added");
							jQuery("#customerPartNoGrid").setGridParam({datatype : 'json'});
							jQuery("#customerPartNoGrid").setGridParam({url:'partNo/records'});
							jQuery("#customerPartNoGrid").trigger('reloadGrid');
							document.getElementById('customerSelect').value = "";
							$('#customerSelect').trigger('liszt:updated');
							document.getElementById('itemCodesSelect').value = "";
							document.getElementById('partNo').value = "";
						}
					}

				}
			});

		}
	});

function delRow(id) {
		$("#customerPartNoGrid").jqGrid('delGridRow', id);
}

function saveRow(id) {
	$('#customerPartNoGrid').saveRow(id, {
		aftersavefunc : function(id, response) {
			showActButtons(id);
		}
	});
}

function restoreRow(id) {
	$('#customerPartNoGrid').jqGrid('restoreRow', id, {
		afterrestorefunc : showActButtons
	});
}

/*
 * Hides the Edit and Del Row Buttons on jqGrid
 * and activates the Save and restore(cancel) button
 * 
 */
function hideActButtons(id) {
	$('#editRow' + id).hide();
	$('#delRow' + id).hide();
	$('#saveRow' + id).show();
	$('#restoreRow' + id).show();
}

/*
 * Shows the Edit and Del Row Buttons on jqGrid
 * and hides the Save and restore(cancel) button
 * 
 */
function showActButtons(id) {
	$('#editRow' + id).show();
	$('#delRow' + id).show();
	$('#saveRow' + id).hide();
	$('#restoreRow' + id).hide();
	lastSelected = null;
}