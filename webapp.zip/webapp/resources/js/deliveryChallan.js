var lastSelected;
$("#customerSelect").chosen({no_results_text : "No results matched"});
$("#salesOrderSelect").chosen({no_results_text : "No results matched"});
$( "#deliveryDate" ).datepicker({dateFormat : "dd-mm-yy"});

$(function(){ 
	$("#deliveryChallanGrid").jqGrid({
		url: 'deliverychallan/records',
		datatype: 'json',
	    mtype: 'POST',
	    multiselect:true,
		
		colNames:['stockOutId','Item Code','Item Description','Sales Order No','Order Status',
	   	          'Party','Bundle Id','Quantity(mts)','Package No','Actions'],
	   	colModel:[
              {name:'stockOutId', index:'stockOutId', width:5, viewable:false,hidden:true}, 
   	          {name:'itemCode',index:'itemCode', width:120},
   	          {name:'itemDescription',index:'itemDescription', width:200},
   	          {name:'orderId',index:'orderId', width:70},
   	          {name:'status',index:'status', width:70},
   	          {name:'customerName',index:'customerName', width:90},
   	          {name:'bundleId',index:'bundleId', width:40}, 
   	          {name:'stockOutQty',index:'stockOutQty', width:50},
   	          {name:'packingSlipNo',index:'packingSlipNo', width:40},
   	          {name:'act',index:'act', width:40,sortable:false,viewable:false}
   	          
 	 	],
	   	postData: {},
		rowNum:100,
	   	rowList:[5,10,20,40,60,100],
	   	height: 300,
	   	autowidth: true,
		rownumbers: false,
	   	pager: '#deliveryChallanPager',
	   	sortname: 'stockOutId',
	    viewrecords: true,
	    sortorder: "desc",
	    caption:"Stock Out Items",
	    emptyrecords: "Empty records",
	    loadonce: false,
	    loadComplete: function() {},
	    jsonReader : {
	        root: "rows",
	        page: "page",
	        total: "total",
	        records: "records",
	        repeatitems: false,
	        cell: "cell",
	        id: "stockOutId"
	    },
	    ondblClickRow : function(id) {
			if (id && id !== lastSelected) {
				editRow(id);
			}
		},
		gridComplete : function() {
		},
		 onSelectRow: updateIdsOfSelectedRows,   
   		 onSelectAll: function (aRowids, status) {
   	      
   	         updateIdsOfAllSelectedRows(aRowids,status);
   	      
   	    },
   	    loadComplete: function () {
   	        var $this = $(this), i, count;
   	        for (i = 0, count = idsOfSelectedRows.length; i < count; i++) {
   	            $this.jqGrid('setSelection', idsOfSelectedRows[i], false);
   	        }
   	      },
   	   beforeSelectRow: function (rowid, e) {
		    var $myGrid = $(this),
		        i = $.jgrid.getCellIndex($(e.target).closest('td')[0]),
		        cm = $myGrid.jqGrid('getGridParam', 'colModel');
		    return (cm[i].name === 'cb');
		},
		gridComplete : function() {
			var ids = jQuery("#deliveryChallanGrid").jqGrid('getDataIDs');
			for ( var i = 0; i < ids.length; i++) {
				var cl = ids[i];
				be = "<input style='height:22px; width:35px;' type='button' value='Edit' id='editRow"+cl+"' onclick=\"editRow('"+ cl + "');\" />";
				de = "<input style='height:22px; width:30px;' type='button' value='Del' id='delRow"+cl+"' onclick=\"delRow('"+ cl + "');\" />";
				se = "<input style='height:22px; width: 29px;' type='button' value='Save' hidden='hidden' id='saveRow"+cl+"' onclick=\"saveRow('"+ cl + "');\" />";
				ce = "<input style='height:22px;width:39px;' type='button' value='Cancel' hidden='hidden'  id='restoreRow"+cl+"' onclick=\"restoreRow('"+ cl + "');\" />";
				$("#deliveryChallanGrid").jqGrid('setRowData', ids[i],
						{
							act :  de + se + ce
						
						});
			}
		},
		editurl : "stockout/crud"
	});
	
	 jQuery("#deliveryChallanGrid").jqGrid('navGrid','#deliveryChallanPager',{view:false, del:false,add:false, edit:false, search:false});
});


$("#customerSelect").chosen().change(function() {
	$("#deliveryDate").datepicker('setDate', 'today');
	var customerId = $('#customerSelect').val();
	$('#salesOrderSelect').children().remove();
	$('#salesOrderSelect').val('').trigger('liszt:updated');
	
	 $.ajax({type:'POST',url: 'customers/customerDetails',data: {'customerId': customerId}, success: function(response) {
		 document.getElementById('partyName').value=response[0];
		 document.getElementById('partyAddress').value=response[1];
		 $('#salesOrderSelect').empty();
		  $.ajax({type:'POST',url: 'stockout/orderId/'+encodeURIComponent(customerId), success: function(response) {
				if (response.length == 0) {

					alert("There is no sales order stocked out  for the selected vendor");
				}
				else{
			  for(var i=0;i< response.length;i++){
					$('#salesOrderSelect').append('<option selected="selected">'+""+'</option>');
					$('#salesOrderSelect').append('<option >'+response[i]+'</option>');
			   		$('#salesOrderSelect').trigger('liszt:updated');		
				}
				}
		  }});

	 }});
});

$("#salesOrderSelect").chosen().change(function() {
 if($('#customerSelect').val()!=null && $('#customerSelect').val()!=""){
	 var customerId=$('#customerSelect').val();
	 var salesOrderNo=$('#salesOrderSelect').val();
	   jQuery("#deliveryChallanGrid").setGridParam({datatype:'json'}); 
	   jQuery("#deliveryChallanGrid").setGridParam({ url: 'deliverychallan/records/'+ encodeURIComponent(customerId)});
	   jQuery("#deliveryChallanGrid").setGridParam({postData: {salesOrderNo:salesOrderNo}}); 
	   jQuery("#deliveryChallanGrid").trigger('reloadGrid');
 }
});




function editRow(id) {
	restoreRow(lastSelected);
	lastSelected = id;
	$('#deliveryChallanGrid').jqGrid('editRow',id, 
			{
				"keys" :true, 
				"oneditfunc" : hideActButtons,
				aftersavefunc : function(savedId, response) {
					showActButtons(savedId);
				},
				afterrestorefunc : showActButtons
			});
}


function delRow(id) {

	 var customerId=$('#customerSelect').val();
	var salesOrderNo=$('#salesOrderSelect').val();
	 if (confirm("Are you sure you want to stock in back the selected stock out from delivery challan list ")){
			$.ajax({type:'POST', 
		 		url: 'stockout/crud',
		 		data:{'id':id,'oper':"del"},
				success: function(response) {
					   jQuery("#deliveryChallanGrid").setGridParam({datatype:'json'}); 
					   jQuery("#deliveryChallanGrid").setGridParam({ url: 'deliverychallan/records/'+ encodeURIComponent(customerId)});
					   jQuery("#deliveryChallanGrid").setGridParam({postData: {salesOrderNo:salesOrderNo}}); 
					   jQuery("#deliveryChallanGrid").trigger('reloadGrid');

			     }});
		  
			   }
}

function saveRow(id) {
	$('#deliveryChallanGrid').saveRow(id,
	{	aftersavefunc : function(id, response) {
				showActButtons(id);
			}
	});
}

function restoreRow(id) {
	$('#deliveryChallanGrid').jqGrid('restoreRow',id,
			{
				afterrestorefunc : showActButtons
			});
}

/*
 * Hides the Edit and Del Row Buttons on jqGrid
 * and activates the Save and restore(cancel) button
 * 
 */
function hideActButtons(id){
	$('#editRow' + id).hide();
	$('#delRow' + id).hide();
	$('#saveRow' + id).show();
	$('#restoreRow' + id).show();
}

/*
 * Shows the Edit and Del Row Buttons on jqGrid
 * and hides the Save and restore(cancel) button
 * 
 */
function showActButtons(id) {
	$('#editRow' + id).show();
	$('#delRow' + id).show();
	$('#saveRow' + id).hide();
	$('#restoreRow' + id).hide();
	lastSelected = null;
}



idsOfSelectedRows = ["8", "9", "10"];
var $SOforWOGrid = $("#deliveryChallanGrid"), idsOfSelectedRows = [],

updateIdsOfSelectedRows = function (id, isSelected) {
	
	 var grid = jQuery('#deliveryChallanGrid'); 
	  var soOrderId=grid.jqGrid ('getCell', id, 'orderId');
      $.ajax({type:'POST',url: 'deliverychallan/checkOrderStatus',data: {'soOrderId': soOrderId}, success: function(response) {
   	  if(response[0]=="Approved" || response[0]=="Final Approved"){
	  var index = $.inArray(id, idsOfSelectedRows);
        if (!isSelected && index >= 0) {
            idsOfSelectedRows.splice(index, 1); // remove id from the list
        } else if (index < 0) {
            idsOfSelectedRows.push(id);
        } 
	  }
	  else{
		alert("Selected Sales Order Should be Approved");
		  $("#deliveryChallanGrid").resetSelection(id);
	  }
      }});// end of ajax hit

};


var display=false;
updateIdsOfAllSelectedRows = function (aRowids, isSelected) {
	var counter = 0;
	 var grid = jQuery('#deliveryChallanGrid'); 
	 var i, count, id=0;

         var soOrderId=grid.jqGrid ('getCell', id, 'orderId');
         $.ajax({type:'POST',url: 'deliverychallan/checkOrderStatus',data: {'soOrderId': soOrderId}, success: function(response) {
       	 alert(counter);
        	 if(response!="Approved"){
        		 counter=counter+1; 
        		 alert(counter);
           	 }
    	     }});// end of ajax hit

	 if(parseInt(counter)>0){
		alert("All Sales Orders Should be Approved ");
			$("#deliveryChallanGrid").resetSelection();
	 }
	 else{
		  var index = $.inArray(aRowids, idsOfSelectedRows);
		  for (i = 0, count = aRowids.length; i < count; i++) {		  
		  if (!isSelected && index >= 0) {
	            idsOfSelectedRows.splice(index, 1); // remove id from the list
	        } else if (index < 0) {
	            idsOfSelectedRows.push(aRowids[i]);
	        } 
		  }
	 }

	
};

$('#generateDeliveryChallanBtn').click(function(){
	var customerName = $('#customerSelect option:selected').text();
	var customerId = $('#customerSelect').val();
	 var challanDate=document.getElementById('deliveryDate').value;
	 if(challanDate!="" && (idsOfSelectedRows.length>0)){
	  if (confirm("Do you want to create Delivery challan for selected stock out Items ")){
	        $.ajax({type:'POST',url: 'deliverychallan/createDeliveryChallan',data: {'idsOfSelectedRows': idsOfSelectedRows,'challanDate':challanDate}, success: function(response) {
	          alert("Delivery Challan "+response[0]+" created for "+customerName);
	        	      jQuery("#deliveryChallanGrid").setGridParam({datatype:'json'}); 
	        		  jQuery("#deliveryChallanGrid").setGridParam({ url: 'deliverychallan/records/'+ encodeURIComponent(customerId)});
	        		  jQuery("#deliveryChallanGrid").trigger('reloadGrid');

	 		                        
						}});
	    	  }
	 }
	 if(challanDate==""){
		 alert("Select Challan Date");
	 } 
	 if(idsOfSelectedRows.length==0){
		 alert("Select items to create delivery challan");
	 }
	 

	   });


