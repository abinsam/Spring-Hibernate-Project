var lastSelected;

$(function(){
	
	$("#beginningDate").datepicker({
     	dateFormat : "dd-mm-yy",
		onSelect : function(dateStr) {
			var min = $('#beginningDate').datepicker('getDate');
			$('#endingDate').datepicker('option', {
				minDate : min
			});
		},
	});
	$("#endingDate").datepicker({
		dateFormat : "dd-mm-yy",
		minDate : $('#beginningDate').datepicker('getDate')
	});
	var fistdate=new Date();
	fistdate.setDate(1);
	$("#beginningDate").datepicker('setDate',fistdate);
 	$("#endingDate").datepicker('setDate', new Date());

});

	
function exciseReport(){
	
	
 	
	var fromDate=document.getElementById('beginningDate').value;
	var toDate=document.getElementById('endingDate').value;
	if(fromDate=="" || fromDate==null){
		alert("Select Beginning Date");
	}else if(toDate=="" || toDate==null){
		alert("Select End Date");
	}
	else{
	location.href='exciseReport/revenueFiguresReport?fromDate='+fromDate+'&toDate='+toDate;
	}
}