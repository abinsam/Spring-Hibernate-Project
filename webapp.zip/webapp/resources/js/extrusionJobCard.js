var lastSelected;
var pvcData="";
var systemDate = new Date();
var month="";
var year="";
$("#loading").dialog({
    hide: 'slide',
    show: 'slide',
    autoOpen: false
});
$(function(){
	
	$("#monthYearPicker").focus(function () {$(".ui-datepicker-calendar").hide();});
	$('#monthYearPicker').datepicker({
	
        changeYear: true,
        changeMonth: true,
        changeDate :false,
        showButtonPanel: true,
        dateFormat: 'MM yy',
       
        onClose: function(dateText, inst) { 
            year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
            month = $("#ui-datepicker-div .ui-datepicker-month :selected").val();
           
            $(this).datepicker('setDate', new Date(year,month, 1));
        }
    });
	
$('#monthYearPicker').datepicker('setDate',systemDate); 
$("#monthYearPicker").focus(function () {$(".ui-datepicker-month").show();});
$("#monthYearPicker").focus(function () {$(".ui-datepicker-year").show();});



$.getJSON("workorder/pvcGrade", function(data) {
			 assignPvcGradeValue(data);
		 });
	
	function assignPvcGradeValue(data){
		for(var k=0;k<data.length;k++){
			pvcData=pvcData+data[k]+":"+data[k];
			if(k<(data.length-1)){
				pvcData=pvcData+";";
			}
		}
  setUpGrid(pvcData);
	}
	$("#workOrderNoSelect").chosen({no_results_text: "No results matched"});
	$("#workOrderStatusSelect").chosen({no_results_text: "No results matched"});
	
	function  setUpGrid(pvcData){
	 $("#ViewWorkOrderGrid").jqGrid({ 
		datatype: 'json',
	    mtype: 'GET',
	   	colNames:['woitemId','WoNo','PoNo','orderno','Od Id','Size','OD','Item','Description','Main Color','Stripe Colour','No. of Coils','noOfCoilHid',
	   	           'Qty(mts per Coil)','qtypercoilHd','hiddenQty','Quantity', 'Packing Type', 'Type', 'PVC Grade',
	   	           'Master Batch', 'To be Labelled','area','Party','Partyhidden','Customer Id','StockInQty Hidd','Stock In Qty','STock In Status hid','Stock In Status','Stock In','Srcap Details','Label','Action'],
	   	colModel:[
   	          {name:'workOrderItemId', index:'workOrderItemId', width:5, viewable:false,hidden:true},
   	          {name:'workOrderNo',index:'workOrderNo', width:5,editable:true,hidden:true},
   	          {name:'poDetails',index:'poDetails', width:5,editable:true,hidden:true},
   	          {name:'orderId',index:'orderId', width:5,editable:true,hidden:true},
   	          {name:'orderDetailId',index:'orderDetailId', width:5,editable:true,hidden:true},
   	          {name:'copperlabel',index:'copperlabel', width:90},
   	          {name:'odLabel',index:'odLabel', width:40},
   	          {name:'itemCode',index:'itemCode', width:10,hidden:true}, 
   	          {name:'itemDescription',index:'itemDescription', width:5,hidden:true}, 
   	          {name:'mainColour',index:'mainColour', width:80},
   	          {name:'innerColour',index:'innerColour', width:80},
   	          {name:'noOfCoils',index:'noOfCoils', width:70},
   	          {name:'noOfCoils',index:'noOfCoilshid', width:70,editable:true,hidden:true},
   	          {name:'qtyPerCoil',index:'qtyPerCoil', width:70},
   	          {name:'qtyPerCoil',index:'qtyPerCoilhid', width:70,editable:true,hidden:true},
   	          {name:'totalQuantity',index:'totalQuantityhiddn', width:5,editable:true,hidden:true},
   	          {name:'totalQuantity',index:'totalQuantity', width:70},
   	          {name:'packingType',index:'packingType', width:70,editable:true,edittype:'select',editoptions:{value:"Coil:Coil;P.Tube:P.Tube"}},
   	          {name:'cableStd',index:'cableStd', width:50},   	  
              {name:'pvcGrade',index:'pvcGrade', width:70, editable: true,edittype:'select',editoptions:{value:pvcData}},	          
   	          {name:'masterBatch',index:'masterBatch', width:70,editable:true},
   	          {name:'toBeLabelled',index:'toBeLabelled', width:10,editable:true,hidden:true},
   	          {name:'area',index:'area',width:10,editable:true,hidden:true},
   	          {name:'customerCode',index:'customerCode', width:80},
   	          {name:'customerName',index:'customerName', width:20,hidden:true},
   	          {name:'customerId',index:'customerId', width:100,editable:true,hidden:true},
   	          {name:'stockInQty',index:'stockInQty', width:5,editable:true,hidden:true},
	          {name:'stockInQty',index:'stockInQty', width:50},
	          {name:'stockInStatus',index:'stockInStatus', width:5,editable:true,hidden:true}, 
	          {name:'stockInStatus',index:'stockInStatus', width:70},
	          {name:'stockLink',index:'stockLink', width:50, editable:false,sortable:false},
	          {name:'scrapLink',index:'scrapLink', width:100, editable:false,hidden:true},
	          {name:'itemDetailsLink',index:'itemDetailsLink', width:50, editable:false,sortable:false},
   	          {name:'act',index:'act', width:50,sortable:false, viewable:false}
  	   	],
	   	postData: {},
		rowNum:100,
	   	rowList:[5,10,20,30,40,100],
	   	autowidth:true,
	   	height: 400,
	   	rownumbers: false,
	   	pager: '#viewworkorderpager',
	   	sortname: 'salesOrderItem.items.mainColour.orderSequence',
	    viewrecords: true,
	    sortorder: "desc",
	    caption:"Work Order Details",
	    emptyrecords: "Empty records",
	    loadonce: false,
	    footerrow: true,
	    loadComplete: function() {},
	    jsonReader : {
	        root: "rows",
	        page: "page",
	        total: "total",
	        records: "records",
	        repeatitems: false,
	        cell: "cell",
	        id: "workOrderItemId"
	    },
	    ondblClickRow : function(id) {
			if (id && id !== lastSelected) {
				$('#ViewWorkOrderGrid').jqGrid('restoreRow',lastSelected);
				editRow(id);
				lastSelected = id;
			}
		},
		gridComplete : function() {
			 var totalQuantity = $('#ViewWorkOrderGrid').jqGrid('getCol','totalQuantity',false,'sum');
			 var stockInQty = $('#ViewWorkOrderGrid').jqGrid('getCol','stockInQty',false,'sum');
			 var noOfCoilsSum = $('#ViewWorkOrderGrid').jqGrid('getCol','noOfCoils',false,'sum');
			 
			  var totalQtyRoundUp=Math.round(parseFloat(totalQuantity) * 100) / 100;
	   	 	  var totalStockQtyRoundUp=Math.round(parseFloat(stockInQty) * 100) / 100;
	   	 	$('#ViewWorkOrderGrid').jqGrid('footerData','set', {ID: 'Total:', totalQuantity: totalQtyRoundUp});
   	    	$('#ViewWorkOrderGrid').jqGrid('footerData','set', {ID: 'Total:', stockInQty: totalStockQtyRoundUp});
   	    	$('#ViewWorkOrderGrid').jqGrid('footerData','set', {ID: 'Total:', noOfCoils: noOfCoilsSum});

			
			var ids = jQuery("#ViewWorkOrderGrid").jqGrid('getDataIDs');
			for ( var i = 0; i < ids.length; i++) {
				var cl = ids[i];
				 var workOrderItemId = jQuery("#ViewWorkOrderGrid").jqGrid ('getCell', cl, 'workOrderItemId'); 
				be = "<input style='height:22px; width:35px;' type='button' value='Edit' id='editRow"+cl+"' onclick=\"editRow('"+ cl + "');\" />";
				se = "<input style='height:22px; width: 29px;' type='button' value='Save' hidden='hidden'  id='saveRow"+cl+"' onclick=\"saveRow('"+ cl + "');\" />";
				ce = "<input style='height:22px;width:39px;' type='button' value='Cancel' hidden='hidden' id='restoreRow"+cl+"' onclick=\"restoreRow('"+ cl + "');\" />";
				sdLink = "<button class='btn btn-mini' id='itemDetailsLink"+cl+"'"+"onclick=\"stockInPopUp('"+ cl + "');\" >Stock In </button>";
				scrLink = "<button class='btn btn-mini' id='itemDetailsLink"+cl+"'"+"onclick=\"scrapDetails('"+ cl + "');\" >Scrap Details </button>";
				odLink = "<button class='btn btn-mini' id='itemDetailsLink"+cl+"'"+" onclick=\"location.href='labeltest/individualLabelReport?workOrderItemId="+workOrderItemId+"';\" >Label</button>";
			
				$("#ViewWorkOrderGrid").jqGrid('setRowData', ids[i],
						{
							act : be +se + ce,
							stockLink :sdLink,
							itemDetailsLink :odLink,
							scrapLink :scrLink
						});
				
				if($("#ViewWorkOrderGrid").getCell(cl,"stockInStatus")=="Completed"){
					 $("#ViewWorkOrderGrid").jqGrid('setRowData',ids[i],false, {  color:'black',weightfont:'bold',background:'#90ee90'});
				}
			}
		},
	  
	editurl : "viewworkorder/crud"
		 }).navGrid('#viewworkorderpager',{view:false, del:false, edit:false, search:false,add:false} 
		 );
	}});
	 
	 $("#workOrderNoSelect").chosen().change(function() {
		 var woNo = $('#workOrderNoSelect').val();
		 var workOrder= $('#workOrderNoSelect option:selected').text();
		jQuery("#ViewWorkOrderGrid").setCaption('Work Order Items  for "' + workOrder + '"');
		$.ajax({
			type:'POST', 
			url: 'viewworkorder/fetchWoDetails/'+ encodeURIComponent(woNo),
			success: function(response) {
				document.getElementById('woStartDate').value=response[0]; 
                document.getElementById('woCompletionDate').value=response[1]; 
                document.getElementById('supervisor').value=response[2]; 
                document.getElementById('machineNo').value=response[3];
                document.getElementById('workOrderStatusSelect').value = response[4] ;
                
 	 			$('#workOrderStatusSelect').trigger('liszt:updated');	
 	 			
                jQuery("#ViewWorkOrderGrid").setGridParam({
						url : 'viewworkorder/records/' + encodeURIComponent(woNo),
						page : 1,
					datatype : 'json'
					}).trigger('reloadGrid');	
				
				$.ajax({type:'POST', 
					url: 'viewworkorder/delete/'+ encodeURIComponent(id),
					success: function(response) {
						 jQuery("#ViewWorkOrderGrid").setGridParam({datatype:'json'}); 
							 jQuery("#ViewWorkOrderGrid").setGridParam({ url: 'viewworkorder/records/'+ encodeURIComponent(woNo)});
							 jQuery("#ViewWorkOrderGrid").trigger('reloadGrid');
							
				}});
		}});
		jQuery("#semiFinishedStockOutGrid").setGridParam({datatype:'json'}); 
		jQuery("#semiFinishedStockOutGrid").setGridParam({ url : 'viewBunchingWorkOrder/woStockOutRecords/' + encodeURIComponent(woNo)});
		jQuery("#semiFinishedStockOutGrid").setCaption('Semi Finished Goods Stocked Out for Work Order :'+woNo);
		jQuery("#semiFinishedStockOutGrid").trigger('reloadGrid');

		
});


function openOrderItemsPopUp(id) { 
	
	var grid = jQuery('#ViewWorkOrderGrid'); 
    var customerName =grid.jqGrid ('getCell', id, 'customerName');
	var customerId = grid.jqGrid ('getCell', id, 'customerId'); 
	var itemDescription= grid.jqGrid ('getCell', id, 'itemDescription'); 
	var quantity= grid.jqGrid ('getCell', id, 'totalQuantity'); 
	var itemCode= grid.jqGrid ('getCell', id, 'itemCode'); 
	var woNo=document.getElementById('workOrderNoSelect').value; 
	var orderId=grid.jqGrid ('getCell', id, 'orderId'); 
	var noOfCoils=grid.jqGrid ('getCell', id ,'noOfCoils');
	var cableStd=grid.jqGrid ('getCell', id ,'cableStd');
	var area=grid.jqGrid ('getCell', id ,'area');
	var poDetails=grid.jqGrid ('getCell', id ,'poDetails');
	var workOrderItemId=grid.jqGrid ('getCell', id ,'workOrderItemId');
	
	url = 'labeltest?woNo=' + encodeURIComponent(woNo)+'&itemCode='+ encodeURIComponent(itemCode)+'&quantity='+ encodeURIComponent(quantity)+'&orderId='+encodeURIComponent(orderId)+'&customerId='+encodeURIComponent(customerId)+'&itemDescription='+encodeURIComponent(itemDescription)+'&noOfCoils='+encodeURIComponent(noOfCoils)+'&cableStd='+encodeURIComponent(cableStd)+'&area='+encodeURIComponent(area)+'&customerName='+ encodeURIComponent(customerName)+'&poDetails='+ encodeURIComponent(poDetails)+'&workOrderItemId='+ encodeURIComponent(workOrderItemId); 
	window.open(url, '_blank'); 
	
  }

function editRow(id) {
	restoreRow(lastSelected);
	lastSelected = id;
	$('#ViewWorkOrderGrid').jqGrid('editRow',id, 
			{
				"keys" :true, 
				"oneditfunc" : hideActButtons,
				aftersavefunc : function(savedId, response) {
					showActButtons(savedId);
				},
				afterrestorefunc : showActButtons
			});
}

function delRow(id) {
	var woNo=document.getElementById('workOrderNoSelect').value;
		$.ajax({type:'POST', 
		url: 'viewworkorder/delete/'+ encodeURIComponent(id),
		success: function(response) {
			 jQuery("#ViewWorkOrderGrid").setGridParam({datatype:'json'}); 
				 jQuery("#ViewWorkOrderGrid").setGridParam({ url: 'viewworkorder/records/'+ encodeURIComponent(woNo)});
				 jQuery("#ViewWorkOrderGrid").trigger('reloadGrid');
				
	}});
}

function saveRow(id) {
	var woNo=document.getElementById('workOrderNoSelect').value;
	$('#ViewWorkOrderGrid').saveRow(id,
	{	aftersavefunc : function(id, response) {
				showActButtons(id);
			}
	});
	 jQuery("#ViewWorkOrderGrid").setGridParam({datatype:'json'}); 
	 jQuery("#ViewWorkOrderGrid").setGridParam({ url: 'viewworkorder/records/'+ encodeURIComponent(woNo)});
	 jQuery("#ViewWorkOrderGrid").trigger('reloadGrid');

}

function restoreRow(id) {
	$('#ViewWorkOrderGrid').jqGrid('restoreRow',id,
			{
				afterrestorefunc : showActButtons
			});
}

/*
 * Hides the Edit and Del Row Buttons on jqGrid
 * and activates the Save and restore(cancel) button
 * 
 */
function hideActButtons(id){
	$('#editRow' + id).hide();
	$('#delRow' + id).hide();
	$('#saveRow' + id).show();
	$('#restoreRow' + id).show();
}

/*
 * Shows the Edit and Del Row Buttons on jqGrid
 * and hides the Save and restore(cancel) button
 * 
 */
function showActButtons(id) {
	$('#editRow' + id).show();
	$('#delRow' + id).show();
	$('#saveRow' + id).hide();
	$('#restoreRow' + id).hide();
	lastSelected = null;
}


function stockInPopUp(id){
	url = 'stockinFromWo?id=' + encodeURIComponent(id),
	window.open(url, '_blank'); 
}
function submitFunction(){
	var woNo=document.getElementById('workOrderNoSelect').value;
	 if(confirm("Are you sure you want to submit work order "+workOrderNo)){
	$.ajax({type:'POST', 
		url: 'viewworkorder/submitFunction/'+ encodeURIComponent(woNo),
		success: function(response) {
			document.getElementById('bunchingSize').disabled=true;
			document.getElementById('netLength').disabled=true;
			document.getElementById('tareWeight').disabled=true;
			document.getElementById('netWeight').disabled=true;
			document.getElementById('grossWeight').disabled=true;
			document.getElementById('outerDiameter').disabled=true;
			document.getElementById('addBtn').disabled=true;
			document.getElementById('noOfStrands').disabled=true;
			document.getElementById('submitBunchingWorkOrder').disabled=true;
			
				
	}});
}}

function scrapDetails(id){
	var workOrderNo=document.getElementById('workOrderNoSelect').value;
	url = 'woScrap?workOrderNo=' + encodeURIComponent(workOrderNo)+'&process='+encodeURIComponent("Extrusion"); 
	window.open(url,'_blank');
	
}
function saveAsPopUp(){
	document.open();
	mydoc = document.open();
	mydoc.write(str);
	mydoc.execCommand("saveAs",true,".pdf");
	mydoc.close();
	return false;
}

function getFolder(){
	  return showModalDialog("folderDialog.html","","width:400px;height:400px;resizeable:yes;");
	}

$(document).keypress(function(e) {
	   if (e.which == 13) {
			var ids = $("#ViewWorkOrderGrid").jqGrid('getDataIDs');
			for ( var i = 0; i < ids.length; i++) {
				var cl = ids[i];  
				saveRow(cl);
	   }
}
});

$(function(){ 
	$("#semiFinishedStockOutGrid").jqGrid({
		mtype : 'POST',
		    colNames:['semifinishedStockOutId','WorkOrder No','Item Description','Bundle Id','Stock Out Qty(Mts)','Weight(Kg)','Actions'],
		   	colModel:[
		   	    
				{name:'semifinishedStockOutId', index:'semifinishedStockOutId', width:10,hidden:true}, 
				{name:'workOrderNo', index:'workOrderNo', width:40, editable:false},   
				 {name:'itemDescription',index:'itemDescription',  width:100, editable:false},
				 {name:'bundleId',index:'bundleId', width:30, editable:false},
				 {name:'stockOutQty',index:'stockOutQty',  width:40, editable:false},
				 {name:'weight',index:'weight', width:30, editable:false},
				 {name : 'act',index : 'act',width : 20,editable : false,sortable:false}
		   	],
		   	postData : {},
			rowNum : 100,
			rowList : [ 5, 10, 20, 40, 60,100 ],
			height : 240,
			width : 450,
			rownumbers : false,
			pager : '#semiFinishedStockOutPager',
			sortname : 'semifinishedStockOutId',
			viewrecords : true,
			sortorder : "desc",
		    caption:"Semi Finished Goods Stock Out",
		    emptyrecords : "Empty records",
			loadonce : false,
			jsonReader : {
				root : "rows",
				page : "page",
				total : "total",
				records : "records",
				repeatitems : false,
				cell : "cell",
				id : "semifinishedStockOutId"
			},
			gridComplete : function() {
				var ids = jQuery("#semiFinishedStockOutGrid").jqGrid('getDataIDs');
				for ( var i = 0; i < ids.length; i++) {
					var cl = ids[i];
					de = "<input style='height:22px; width: 29px;' type='button' value='Del'   id='delsemifinished"+ cl	+ "' onclick=\"delsemifinishedStock('"+ cl+ "');\" />";
					$("#semiFinishedStockOutGrid").jqGrid('setRowData', ids[i], {
						act : de});
				}
			}
	}).navGrid('#semiFinishedStockOutPager',{view:false, del:false, edit:false, search:false,add:false});




	$("#pvcStockOutGrid").jqGrid({
		mtype : 'POST',
		    colNames:['pvcStockOutID','WorkOrder No','PVC Item','Batch','Quantity(Kg)'],
		   	colModel:[
		   	    
				{name:'pvcStockOutID', index:'semifinishedStockOutId', width:10,hidden:true}, 
				{name:'workOrderNo', index:'workOrderNo', width:100,hidden:true}, 
				 {name:'itemDescription',index:'itemDescription',  width:250},
				 {name:'batch',index:'batch',  width:150},
				 {name:'quantity',index:'quantity', width:100}
		   	],
		   	postData : {},
			rowNum : 100,
			rowList : [ 5, 10, 20, 40, 60,100 ],
			height : 240,
			autowidth:true,
			rownumbers : false,
			pager : '#spvcStockOutPager',
			sortname : 'pvcStockOutID',
			viewrecords : true,
			sortorder : "desc",
		    caption:"PVC Stock Out",
		    emptyrecords : "Empty records",
			loadonce : false,
			jsonReader : {
				root : "rows",
				page : "page",
				total : "total",
				records : "records",
				repeatitems : false,
				cell : "cell",
				id : "pvcStockOutID"
			}	
	}).navGrid('#pvcStockOutPager',{view:false, del:false, edit:false, search:false,add:false});
	});



function openSemiFinishedStockOut() {
	var woNo = $('#workOrderNoSelect').val();
	if(woNo!=null && woNo!=""){
	jQuery("#semiFinishedStockOutGrid").setGridParam({datatype:'json'}); 
	jQuery("#semiFinishedStockOutGrid").setGridParam({ url : 'viewBunchingWorkOrder/woStockOutRecords/' + encodeURIComponent(woNo)});
	jQuery("#semiFinishedStockOutGrid").setCaption('Semi Finished Goods Stocked Out for Work Order :'+woNo);
	jQuery("#semiFinishedStockOutGrid").trigger('reloadGrid');

	$("#dialog-modal").dialog({
		width : 500,
		height : 400

	});
}else{
	alert("Select Extrusion Work Order No");
}
}

function openPvcStockOut() {
	var woNo = $('#workOrderNoSelect').val();
	if(woNo!=null && woNo!=""){
	jQuery("#pvcStockOutGrid").setGridParam({datatype:'json'}); 
	jQuery("#pvcStockOutGrid").setGridParam({ url : 'viewworkorder/pvcStockOutRecords/' + encodeURIComponent(woNo)});
	jQuery("#pvcStockOutGrid").setCaption('PVC Stocked Out for:'+woNo);
	jQuery("#pvcStockOutGrid").trigger('reloadGrid');

	$("#dialog-pvc-modal").dialog({
		width : 550,
		height : 400

	});
}else{
	alert("Select Extrusion Work Order No");
}
}

$("#workOrderStatusSelect").chosen().change(
		function() {
			var status = $('#workOrderStatusSelect').val();
			$('#workOrderNoSelect').children().remove();
			$('#workOrderNoSelect').val('').trigger('liszt:updated');
			document.getElementById('woStartDate').value = "";
			document.getElementById('woCompletionDate').value = "";
			document.getElementById('supervisor').value = "";
			document.getElementById('machineNo').value = "";
			var validSearch=validateSearchParams();
			
			if(validSearch==true){
				
				 month = $("#ui-datepicker-div .ui-datepicker-month :selected").val();
			     year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();

			$.ajax({
				type : 'POST',
				url : 'viewMWDWorkOrder/getWorkOrderNos/'+ encodeURIComponent(status),
						data : {"processType" : "Extrusion","month":month,"year":year},
						success : function(response) {
							$('#workOrderNoSelect').empty();
							if (response.length == 0) {

								alert("There is no Work Order for selected month,year and status");
								$('#ViewWorkOrderGrid').jqGrid('clearGridData');
							}
							
							if (response.length != 0) {
								for ( var i = 0; i < response.length; i++) {
									$('#workOrderNoSelect').append('<option selected="selected">'+ ""+ '</option>');
									$('#workOrderNoSelect').append('<option >'+ response[i]	+ '</option>');
									$('#workOrderNoSelect').trigger('liszt:updated');
								}
							} else {
								$('#workOrderNoSelect').empty();
								document.getElementById('woStartDate').value = "";
								document.getElementById('woCompletionDate').value = "";
								document.getElementById('supervisor').value = "";
								document.getElementById('machineNo').value = "";

							}
						}
					});
			}
		});

function validateSearchParams(){

	  if($("#monthYearPicker").val()=="" || $("#monthYearPicker").val()==null){
	    	alert("Month and Year empty! please select month and year");
	    	return false;
	    }
	    else return true;
}


$("#monthYearPicker").focus(function() {
	
	if ($("#workOrderStatusSelect").val() != "") {
		document.getElementById('workOrderStatusSelect').value = "";
		$('#workOrderStatusSelect').trigger('liszt:updated');
	}
	
	if ($("#workOrderNoSelect").val() != "") {
		document.getElementById('workOrderNoSelect').value = "";
		$('#workOrderNoSelect').trigger('liszt:updated');
	}
	
	if (document.getElementById('woStartDate').value != "")
		document.getElementById('woStartDate').value = "";
	
	if (document.getElementById('woCompletionDate').value != "")
		document.getElementById('woCompletionDate').value = "";
	
	if (document.getElementById('supervisor').value != "")
		document.getElementById('supervisor').value = "";
	
	if (document.getElementById('machineNo').value != "")
		document.getElementById('machineNo').value = "";
});
	



function delsemifinishedStock(id) {
	var woNo = $('#workOrderNoSelect').val();
	if(confirm("Are you sure you want to delete the stocked out?")){
	      $.ajax({type:'POST', 
	        url: 'stockOutSemiFinished/delete',
	        data:{'id':id},
	        success: function() {
		        alert("Semifinished items stocked out for "+woNo+" is deleted");
	        	jQuery("#semiFinishedStockOutGrid").setGridParam({datatype:'json'}); 
	        	jQuery("#semiFinishedStockOutGrid").setGridParam({ url : 'viewBunchingWorkOrder/woStockOutRecords/' + encodeURIComponent(woNo)});
	        	jQuery("#semiFinishedStockOutGrid").setCaption('Semi Finished Goods Stocked Out for Work Order :'+woNo);
	        	jQuery("#semiFinishedStockOutGrid").trigger('reloadGrid');

	    
	      }});
	    }
	   

	} 

$('#extrusionJobCardReport').click(function() {
	
	var workOrderNo=document.getElementById('workOrderNoSelect').value;
	if(workOrderNo!=null && workOrderNo!="")
	location.href='viewworkorder/extrusionJobCardReport?workOrderNo='+workOrderNo;
	else
	alert("Kindly select a WorkOrder number to view JobCard Report!");
	

});
$('#extrusionApprovalReport').click(function() {
	var workOrderNo=document.getElementById('workOrderNoSelect').value;
	if(workOrderNo!=null && workOrderNo!="")
	location.href='viewworkorder/extrusionApprovalReport?workOrderNo='+workOrderNo;
	else
	alert("Kindly select a WorkOrder number to view Extrusion Approval Report!");
	

});
$('#stockInReport').click(function() {
	
	var workOrderNo=document.getElementById('workOrderNoSelect').value;
	if(workOrderNo!=null && workOrderNo!="")
	location.href='viewworkorder/stockInReport?workOrderNo='+workOrderNo;
	else
	alert("Kindly select a WorkOrder number to view Stock In Report!");

});

function closeWorkOrder(){
	var woNo=document.getElementById('workOrderNoSelect').value;
	if(woNo!=null && woNo!=""){
		$.ajax({type:'POST', 
			url: 'storeRegisterForRBD/fetchWoDetails/'+ encodeURIComponent(woNo),
			beforeSend: function(){
		           $("#loading").dialog('open').html("<p>Processing Request...</p>");
		        },
			success: function(response) {
				 if(response[6]=="Completed"){
					 alert("Work Order :"+woNo+" is Completed");
				 }
				 else{
					workOrderCompleteion(woNo);
				 }
					
			},
			 complete: function() {
	        	 $("#loading").dialog('close');
	        }});
	}else
	alert("Select Work Order No");

}


function workOrderCompleteion(woNo){
	 month = $("#ui-datepicker-div .ui-datepicker-month :selected").val();
     year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
	var status="Completed";
    $.ajax({type:'POST', 
        url: 'viewworkorder/closeWorkOrder',
        data:{'woNo':woNo,'process':"Extrusion"},
        success: function() {
	        alert("Work Order No:"+woNo+" is Closed");
	        jQuery("#ViewWorkOrderGrid").trigger('reloadGrid');
	        document.getElementById('workOrderStatusSelect').value = status;
		    $('#workOrderStatusSelect').trigger('liszt:updated');
			$('#workOrderNoSelect').children().remove();
			$('#workOrderNoSelect').val('').trigger('liszt:updated');
			$.ajax({
				type : 'POST',
				url : 'viewMWDWorkOrder/getWorkOrderNos/'+ encodeURIComponent(status),
						data : {"processType" : "Extrusion","month":month,"year":year},
						success : function(response) {
							$('#workOrderNoSelect').empty();
							if (response.length != 0) {
								for ( var i = 0; i < response.length; i++) {
									//alert(response[i]);
									if(response[i]==woNo){
										$('#workOrderNoSelect').append('<option selected="selected">'+ response[i]+ '</option>');

									}else{
									$('#workOrderNoSelect').append('<option >'+ response[i]	+ '</option>');
									}
									$('#workOrderNoSelect').trigger('liszt:updated');
								}
							}
						}
					});
	        
   }});
 }