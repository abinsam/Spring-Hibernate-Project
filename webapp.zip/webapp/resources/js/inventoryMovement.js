var lastSelected;

$(function(){
    $.ajax({
        url: 'inventoryMovement/fetchInventoryItemCode',
        dataType: "json",
         success: function(data) {
        	 itemCodeArray=data;
        }
    });
	$("#itemCodesSelect").autocomplete({
	    source: function(request, response) {
	        var results = $.ui.autocomplete.filter(itemCodeArray, request.term);

	        response(results.slice(0, 15));
	    }
	});
    
	$("#partySelect").chosen({no_results_text : "No results matched"});
	$("#strandsSelect").chosen({no_results_text : "No results matched"});
	$("#cuDiameterSelect").chosen({no_results_text : "No results matched"});
	$("#mainColorSelect").chosen({no_results_text : "No results matched"});
	$("#innerColorSelect").chosen({no_results_text : "No results matched"});
	$("#productTypeSelect").chosen({no_results_text : "No results matched"});
	$("#cableStdPvcSelect").chosen({no_results_text : "No results matched"});
	$("#layTypeSelect").chosen({no_results_text : "No results matched"});
	$("#layLengthSelect").chosen({no_results_text : "No results matched"});
	$("#odSelect").chosen({no_results_text : "No results matched"});
	
	$("#beginningDate").datepicker({
     	dateFormat : "dd-mm-yy",
		onSelect : function(dateStr) {
			var min = $('#beginningDate').datepicker('getDate');
			$('#endingDate').datepicker('option', {
				minDate : min
			});
		}
	});
	$("#endingDate").datepicker({
		dateFormat : "dd-mm-yy",
		minDate : $('#beginningDate').datepicker('getDate')
	});
	var fistdate=new Date();
	fistdate.setDate(1);
	$("#beginningDate").datepicker('setDate',fistdate);
 	$("#endingDate").datepicker('setDate', new Date());
  	
	$("#inventoryMovementGrid").jqGrid({
						url : 'inventoryMovement/inventoryDetails',
						datatype : 'json',
						mtype: 'POST',
						colNames : [ 'Stock id','Date','PartyHidden','Party','Store','Item Description','Item Code','Assorted Type','Stock In Quantity','Stock Out Qty','Units',],
						colModel : [  
                                     {name : 'stockInId',index : 'stockInId',width :10,hidden:true}, 
						             {name : 'confirmStatus',index : 'confirmStatus',width :110},
						             {name : 'customerName',index : 'customerName',width :150,hidden:true},
						             {name : 'customerCode',index : 'customerCode',width :60},
						             {name : 'storeAddress',index : 'storeAddress',width :120}, 
						             {name : 'itemDescription',index : 'itemDescription',width :290}, 
						             {name : 'itemCode',index : 'itemCode',width :200},
						             {name : 'assortedType',index : 'assortedType',width :200},
						             {name : 'stockQty',index : 'stockQty',width : 80}, 
						             {name : 'weight',index : 'weight',width : 80}, 
						             {name : 'units',index : 'units',width : 50}
						            
						     ],
						postData : {},
						rowNum : 100,
						rowList : [ 5, 10, 20, 30, 40, 100,500,1000,2000 ],
						height : 500,
						width:1300,
						rownumbers : false,
						pager : '#inventoryMovementPager',
						sortname : 'stockInId',
						viewrecords : true,
						sortorder : "desc",
						caption : "Inventory Movement",
						emptyrecords : "Empty records",
						loadonce : false,
						footerrow : true,
						loadComplete : function() {
						},
						jsonReader : {
							root : "rows",
							page : "page",
							total : "total",
							records : "records",
							repeatitems : false,
							cell : "cell",
							id : "stockInId"
						},
						gridComplete : function() {
							 var stockQty = $('#inventoryMovementGrid').jqGrid('getCol','stockQty',false,'sum');
							 var weight = $('#inventoryMovementGrid').jqGrid('getCol','weight',false,'sum');
		        	   		
		        	   	 	  var totalStockQty=Math.round(parseFloat(stockQty) * 100) / 100;
		        	   	 	 var totalWeight=Math.round(parseFloat(weight) * 100) / 100;
		        	   	 	 
		        	   	    	$('#inventoryMovementGrid').jqGrid('footerData','set', {ID: 'Total:', stockQty: totalStockQty});
		        	   	    	$('#inventoryMovementGrid').jqGrid('footerData','set', {ID: 'Total:', weight: totalWeight});
		        	   	    	$('#inventoryMovementGrid').jqGrid('footerData','set', {ID: 'Total:', itemCode: "Item Code"});
		        	   	    	$('#inventoryMovementGrid').jqGrid('footerData','set', {ID: 'Total:', itemDescription: "Item Description"});
		        	   	    	$('#inventoryMovementGrid').jqGrid('footerData','set', {ID: 'Total:', assortedType: "Assorted Type"});
		        	   	    	$('#inventoryMovementGrid').jqGrid('footerData','set', {ID: 'Total:', confirmStatus: "Date"});
		        	   	    	$('#inventoryMovementGrid').jqGrid('footerData','set', {ID: 'Total:', customerName: "Party"});
		        	   	    	$('#inventoryMovementGrid').jqGrid('footerData','set', {ID: 'Total:', storeAddress: "Store"});
							
							} 
				});
	jQuery("#inventoryMovementGrid").jqGrid('navGrid', '#inventoryMovementPager', {
		view : false,
		del : false,
		add : false,
		edit : false,
		search : false
	});
	
	
});



function searchInventory(){
	var fromDate=document.getElementById('beginningDate').value;
	var toDate=document.getElementById('endingDate').value;
	var party;
	var itemCode;
	var cablesStd;
	var productType;
	var mainColour;
	var stripeColour;
	var noOfCuStrand;
	var layType;
	var layLength;
	var od;
	var cuDiameter;

	
	
	
	if(fromDate=="" || fromDate==null)
		alert("Select Start Date");
	else if(toDate=="" || toDate==null)
		alert("Select End Date");
	else{	
	if($("#partySelect").val()!="" && $("#partySelect").val()!=null)
		party=$('#partySelect option:selected').text();
	else
		party="All";
	if($("#itemCodesSelect").val()!="" && $("#itemCodesSelect").val()!=null)
		itemCode=$("#itemCodesSelect").val();
	else
		itemCode="All";
	
	if($("#cableStdPvcSelect").val()!="" && $("#cableStdPvcSelect").val()!=null)
		cablesStd=$("#cableStdPvcSelect").val();
	else
		cablesStd="All";
	
	if($("#productTypeSelect").val()!="" && $("#productTypeSelect").val()!=null)
		productType=$("#productTypeSelect").val();
	else
		productType="All";
	
	if($("#mainColorSelect").val()!="" && $("#mainColorSelect").val()!=null)
		mainColour=$("#mainColorSelect").val();
	else
		mainColour="All";
	if($("#innerColorSelect").val()!="" && $("#innerColorSelect").val()!=null)
		stripeColour=$("#innerColorSelect").val();
	else
		stripeColour="All";
	if($("#strandsSelect").val()!="" && $("#strandsSelect").val()!=null)
		noOfCuStrand=$("#strandsSelect").val();
	else
		noOfCuStrand=0;
	if($("#layTypeSelect").val()!="" && $("#layTypeSelect").val()!=null)
		layType=$("#layTypeSelect").val();
	else
		layType="All";
	if($("#layLengthSelect").val()!="" && $("#layLengthSelect").val()!=null)
		layLength=$("#layLengthSelect").val();
	else
		layLength=0;
	
	
	if($("#odSelect").val()!="" && $("#odSelect").val()!=null)
		od=$("#odSelect").val();
	else
		od="All";
	
	if($("#cuDiameterSelect").val()!="" && $("#cuDiameterSelect").val()!=null)
		cuDiameter=$("#cuDiameterSelect").val();
	else
		cuDiameter="All";
	
	var salesOrder="All";
	var workOrder="All";

	 jQuery("#inventoryMovementGrid").setGridParam({datatype:'json'}); 
	 jQuery("#inventoryMovementGrid").setGridParam({ url: 'inventoryMovement/inventoryDetails'});
	 jQuery("#inventoryMovementGrid").setGridParam({postData: {fromDate:fromDate,toDate:toDate,party:party,itemCode:itemCode,
		                                                        cablesStd:cablesStd,productType:productType,mainColour:mainColour,stripeColour:stripeColour,
		                                                        noOfCuStrand:noOfCuStrand,layType:layType,layLength:layLength,od:od,cuDiameter:cuDiameter,
		                                                        salesOrder:salesOrder,wokOrder:workOrder
		                                                        }}); 
	 jQuery("#inventoryMovementGrid").setCaption('Inventory Movement From ' + fromDate+ ' To '+toDate);
	 jQuery("#inventoryMovementGrid").trigger('reloadGrid');


	}
}

function clearFn(){
	var fistdate=new Date();
	fistdate.setDate(1);
	$("#beginningDate").datepicker('setDate',fistdate);
 	$("#endingDate").datepicker('setDate', new Date());
	var fromDate=document.getElementById('beginningDate').value;
	var toDate=document.getElementById('endingDate').value;
	if ($("#partySelect").val() != "") {
		document.getElementById('partySelect').value = "";
		$('#partySelect').trigger('liszt:updated');
	}
	if ($("#itemCodesSelect").val() != "") {
		document.getElementById('itemCodesSelect').value = "";
	}
	
	if ($("#cableStdPvcSelect").val() != "") {
		document.getElementById('cableStdPvcSelect').value = "";
		$('#cableStdPvcSelect').trigger('liszt:updated');
	}
	
	if ($("#productTypeSelect").val() != "") {
		document.getElementById('productTypeSelect').value = "";
		$('#productTypeSelect').trigger('liszt:updated');
	}
	
	if ($("#mainColorSelect").val() != "") {
		document.getElementById('mainColorSelect').value = "";
		$('#mainColorSelect').trigger('liszt:updated');
	}
	
	if ($("#innerColorSelect").val() != "") {
		document.getElementById('innerColorSelect').value = "";
		$('#innerColorSelect').trigger('liszt:updated');
	}
	if ($("#strandsSelect").val() != "") {
		document.getElementById('strandsSelect').value = "";
		$('#strandsSelect').trigger('liszt:updated');
	}
	
	if ($("#layTypeSelect").val() != "") {
		document.getElementById('layTypeSelect').value = "";
		$('#layTypeSelect').trigger('liszt:updated');
	}
	if ($("#layLengthSelect").val() != "") {
		document.getElementById('layLengthSelect').value = "";
		$('#layLengthSelect').trigger('liszt:updated');
	}

	
	
	if ($("#odSelect").val() != "") {
		document.getElementById('odSelect').value = "";
		$('#odSelect').trigger('liszt:updated');
	}
	
	if ($("#cuDiameterSelect").val() != "") {
		document.getElementById('cuDiameterSelect').value = "";
		$('#cuDiameterSelect').trigger('liszt:updated');
	}
	
	
	 jQuery("#inventoryMovementGrid").setGridParam({datatype:'json'}); 
	 jQuery("#inventoryMovementGrid").setGridParam({ url: 'inventoryMovement/inventoryDetails'});
	 jQuery("#inventoryMovementGrid").setGridParam({postData: {fromDate:fromDate,toDate:toDate,party:"All",itemCode:"All",
		                                                      cablesStd:"All",productType:"All",mainColour:"All",stripeColour:"All",
		                                                      noOfCuStrand:0,layType:"All",layLength:0,od:"All",cuDiameter:"All",
		                                                        salesOrder:"All",wokOrder:"All"
		                                                   }}); 
	 jQuery("#inventoryMovementGrid").setCaption('Inventory Stock In');
	 jQuery("#inventoryMovementGrid").trigger('reloadGrid');
	 
	 }