var lastSelected;
var newItemStatus=true;

var itemCodeArray;


$(function(){ 
    $.ajax({
        url: 'orderdetails/fetchItemCode',
        dataType: "json",
         success: function(data) {
        	 itemCodeArray=data;
        }
    });


	$("#itemCodesSelect").autocomplete({
	    source: function(request, response) {
	        var results = $.ui.autocomplete.filter(itemCodeArray, request.term);

	        response(results.slice(0, 15));
	    },
	    select: function (a, b) {
	      	itemCodeSelectOnChange(b.item.value);
	    }
	});
	// $("#itemIdSelect").chosen({no_results_text: "No results matched"});
		$("#productTypeSelect").chosen({no_results_text: "No results matched"});
		$("#cableStdPvcSelect").chosen({no_results_text: "No results matched"});
		$("#colourMainSelect").chosen({no_results_text: "No results matched"});
		$("#colorStripeSelect").chosen({no_results_text: "No results matched"});
		$("#copperDiameterSelect").chosen({no_results_text: "No results matched"});
		$("#maincolorKeySelect").chosen({no_results_text: "No results matched"});
		$("#stripecolorKeySelect").chosen({no_results_text: "No results matched"});
		$("#unitTypeSelect").chosen({no_results_text: "No results matched"});

	$("#itemsGrid").jqGrid({
	   	url:'items/records',
	   	datatype : 'json',
		mtype : 'POST',
	   	colNames:['Action','Item Id','Item Code', 'Item Desc','Item Label','Main Color','Inner Color',
	   	          'Product Type','Cable Std','Cu Dia','No Of cu strands','Lay Length','Lay type','OD',
	   	          'Specific Details','Area','Item Type','Assorted Type','Input size','OD Label','Cu Weight','PVC Weight'],
	   	colModel:[
   	          {name:'act',index:'act', width:75,sortable:false},
   	          {name:'itemId',index:'itemId', width:10, hidden:true, viewable:false},
   	          {name:'itemCode',index:'itemCode', width:270, editable:true, editrules:{required:true}, editoptions:{size:10}},
   	          {name:'itemDescription',index:'itemDescription', width:300, editable:true, editrules:{required:true}, editoptions:{size:10}},
   	          {name:'itemLabel',index:'itemLabel', width:100, editable:true, editrules:{required:true}, editoptions:{size:10}, hidden:true},
   	          {name:'mainColourItem',index:'mainColourItem', width:150, editable:true, editrules:{required:true}, editoptions:{size:10}},
   	          {name:'innerColourItem',index:'innerColourItem', width:150, editable:true, editrules:{required:true}, editoptions:{size:10}},
   	          {name:'productTypeKey',index:'productTypeKey', width:100, editable:true, editrules:{required:true}, editoptions:{size:10}},
   	          {name:'cableStdKey',index:'cableStdKey', width:100, editable:true, editrules:{required:true}, editoptions:{size:10}},
   	          {name:'copperKey',index:'copperKey', width:100, editable:true, editrules:{required:true}, editoptions:{size:10}},
          	  {name:'numberOfCopperStrand',index:'numberOfCopperStrand', width:100, editable:true, editrules:{required:true}, editoptions:{size:10}},
   	          {name:'layLength',index:'layLength', width:100, editable:true, editrules:{required:true}, editoptions:{size:10}},
   	          {name:'layType',index:'layType', width:100, editable:true, editrules:{required:true}, editoptions:{size:10}},
        	  {name:'outerDiameter',index:'outerDiameter', width:100, editable:true, editrules:{required:true}, editoptions:{size:10},hidden:true},
	          {name:'specificDetails',index:'specificDetails', width:100, editable:true, editrules:{required:true}, editoptions:{size:10}},
	          {name:'areaValue',index:'areaValue', width:100, editable:true, editrules:{required:true}, editoptions:{size:10}},
	          {name:'itemType',index:'itemType', width:100, editable:true, editrules:{required:true}, editoptions:{size:10}},
	          {name:'assortedType',index:'assortedType', width:100, editable:true, editrules:{required:true}, editoptions:{size:10}},
	          {name:'inputSize',index:'inputSize', width:100, editable:true, editrules:{required:true}, editoptions:{size:10}},
	          {name:'odLabel',index:'odLabel', width:100, editable:true, editrules:{required:true}, editoptions:{size:10}},
	          {name:'weight',index:'weight', width:100, editable:true, editrules:{required:true}, editoptions:{size:10}},
	          {name:'pvcWeight',index:'pvcWeight', width:100, editable:true, editrules:{required:true}, editoptions:{size:10}}
   	    
	   	],
	   	postData: {},
		rowNum:100,
	   	rowList:[50,100,200],
	   	height: 600,
	    width:1500,
		rownumbers: false,
	   	pager: '#itemPager',
	   	sortname: 'itemId',
	    viewrecords: true,
	    sortorder: "desc",
	    caption:"Records",
	    emptyrecords: "Empty records",
	    loadonce: false,
	    loadComplete: function() {},
	    jsonReader : {
	        root: "rows",
	        page: "page",
	        total: "total",
	        records: "records",
	        repeatitems: false,
	        cell: "cell",
	        id: "itemId"
	    },
	    ondblClickRow : function(id) {
	    	/*alert("Coming here Id is " + id);
			if (id && id !== lastSelected) {
				$('#itemsGrid').restoreRow(lastSelected);
				lastSelected = id;
			}
			jQuery('#itemsGrid').editRow(id, true);*/
		},
		gridComplete : function() {
			var ids = $("#itemsGrid").jqGrid('getDataIDs');
			for ( var i = 0; i < ids.length; i++) {
				var cl = ids[i];
				de = "<input style='height:22px; width:30px;' type='button' value='Del' id='delRow"+cl+"' onclick=\"delRow('"+ cl + "');\" />";
				jQuery("#itemsGrid").jqGrid('setRowData', ids[i],
						{
							/*act : be + de + se + ce*/
							act:de
						});
			}
		},
		editurl : "items/crud"
	}).navGrid('#itemPager',{view:true, del:false, edit:false, search:false,add:false}, 
	{}, // use default settings for edit
	{}, // use default settings for add
	{},  // delete instead that del:false we need this
	{multipleSearch : true}, // enable the advanced searching
	{closeOnEscape:true} /* allow the view dialog to be closed when user press ESC key*/
	);
}); 

function delRow(id) {
	$("#itemsGrid").jqGrid('delGridRow', id);
}



$('#searchButton').click(function() {
	if (document.getElementById('numberOfCopperStrands').value != "") {
		var pattern = /^[0-9]\d*$/;
		if (!pattern.test($("#numberOfCopperStrands").val())) {
			alert("Enter valid Copper Strands");
			document.getElementById('numberOfCopperStrands').value = "";

		} else {
			searchFunction();
		}
	}

	if (document.getElementById('outerDiameter').value != "") {
		 var  pattern = /^[+]?([0-9]+(?:[\.][0-9]*)?|\.[0-9]+)$/;
		if (!pattern.test($("#outerDiameter").val())) {
			alert("Enter valid OD");
			document.getElementById('outerDiameter').value = "";

		} else {
			searchFunction();
		}
	}
	else {
searchFunction();

	}

});

function searchFunction() {

	var itemId = document.getElementById('itemCodesSelect').value;
	var productTypeSelect = document.getElementById('productTypeSelect').value;
	var copperDiameterSelect = document.getElementById('copperDiameterSelect').value;
	var cableStdPvcSelect = document.getElementById('cableStdPvcSelect').value;
	var colourMainSelect = document.getElementById('colourMainSelect').text;
	var colorStripeSelect = document.getElementById('colorStripeSelect').text;
	var maincolorKeySelect = document.getElementById('maincolorKeySelect').value;
	var stripecolorKeySelect = document.getElementById('stripecolorKeySelect').value;
	var noOfCuStrand = document.getElementById('numberOfCopperStrands').value;
	var layLength = document.getElementById('layLength').value;
	var layType = document.getElementById('layType').value;
	var outerDiameter = document.getElementById('outerDiameter').value;

	if(itemId!=null && itemId!=""){
		 productTypeSelect = "";
		 copperDiameterSelect = "";
		 cableStdPvcSelect = "";
		 colourMainSelect ="";
		 colorStripeSelect =  "";
		 maincolorKeySelect = "";
		 stripecolorKeySelect =  "";
		 noOfCuStrand = "";
		 layLength =  "";
		 layType =  "";
		 outerDiameter =  "";

	}
		
		
		
		

	var searchOptions1 = {
		"groupOp" : "AND",
		"rules" : [ {
			"field" : "itemCode",
			"op" : "eq",
			"data" : itemId
		}, {
			"field" : "productKey",
			"op" : "eq",
			"data" :productTypeSelect
		}, {
			"field" : "copperkey",
			"op" : "eq",
			"data" : copperDiameterSelect
		}, {
			"field" : "cableStdKey",
			"op" : "eq",
			"data" : cableStdPvcSelect
		}, {
			"field" : "mainColour",
			"op" : "eq",
			"data" : colourMainSelect
		}, {
			"field" : "innerColour",
			"op" : "eq",
			"data" : colorStripeSelect
		}, {
			"field" : "mainColourKey",
			"op" : "eq",
			"data" : maincolorKeySelect
		}, 
		{
			"field" : "innerColourKey",
			"op" : "eq",
			"data" : stripecolorKeySelect
		}, 
		{
			"field" : "numberOfCopperStrands",
			"op" : "eq",
			"data" : noOfCuStrand
		}, 
		{
			"field" : "layLength",
			"op" : "eq",
			"data" : layLength
		}, 
		{
			"field" : "layType",
			"op" : "eq",
			"data" : layType
		}, 
		{
			"field" : "outerDiameter",
			"op" : "eq",
			"data" : outerDiameter
		}, 
		]
	};
	performSearch(searchOptions1, "#itemsGrid");

}

function performSearch(searchOptions, gridId) {
	$(gridId).setGridParam({
		postData : {
			searchObject : JSON.stringify(searchOptions)
		}
	});
	$(gridId).trigger("reloadGrid");
}

$('#clearButton').click(function() {
	
	if (document.getElementById('itemCodesSelect').value != "") {
		document.getElementById('itemCodesSelect').value = "";
	}
	if ($("#productTypeSelect").val() != "") {
		document.getElementById('productTypeSelect').value = "";
		$('#productTypeSelect').trigger('liszt:updated');
	}
	if ($("#cableStdPvcSelect").val() != "") {
		document.getElementById('cableStdPvcSelect').value = "";
		$('#cableStdPvcSelect').trigger('liszt:updated');
	}

	if ($("#colourMainSelect").val() != "") {
		document.getElementById('colourMainSelect').value = "";
		$('#colourMainSelect').trigger('liszt:updated');
	}
	if ($("#colorStripeSelect").val() != "") {
		document.getElementById('colorStripeSelect').value = "";
		$('#colorStripeSelect').trigger('liszt:updated');
	}
	if ($("#copperDiameterSelect").val() != "") {
		document.getElementById('copperDiameterSelect').value = "";
		$('#copperDiameterSelect').trigger('liszt:updated');
	}
	if ($("#maincolorKeySelect").val() != "") {
		document.getElementById('maincolorKeySelect').value = "";
		$('#maincolorKeySelect').trigger('liszt:updated');
	}
	if ($("#stripecolorKeySelect").val() != "") {
		document.getElementById('stripecolorKeySelect').value = "";
		$('#stripecolorKeySelect').trigger('liszt:updated');
	}
	
	if (document.getElementById('numberOfCopperStrands').value != "")
		document.getElementById('numberOfCopperStrands').value = "";

	if (document.getElementById('layLength').value != "")
		document.getElementById('layLength').value = "";
	
	if (document.getElementById('layType').value != "")
		document.getElementById('layType').value = "";

	if (document.getElementById('outerDiameter').value != "")
		document.getElementById('outerDiameter').value = "";
	
	jQuery("#itemsGrid").setGridParam({datatype : 'json'});
	jQuery("#itemsGrid").setGridParam({postData : {searchObject : "allSearch"}});
	jQuery("#itemsGrid").trigger('reloadGrid');

});



$("#unitTypeSelect").chosen().change( function() {
	clearItemSelect();
	updateItemCodeChosen();
});
	
$("#productTypeSelect").chosen().change( function() {
	clearItemSelect();
	updateItemCodeChosen();
});
$("#cableStdPvcSelect").chosen().change( function() {
	clearItemSelect();
	updateItemCodeChosen();
});
$("#copperDiameterSelect").chosen().change( function() {
	clearItemSelect();
	updateItemCodeChosen();
});
$("#colourMainSelect").chosen().change( function() {
	clearItemSelect();
	var mainColor=document.getElementById('colourMainSelect').value;
	document.getElementById('maincolorKeySelect').value = mainColor;
	$('#maincolorKeySelect').trigger('liszt:updated');
	updateItemCodeChosen();
	
});
$("#colorStripeSelect").chosen().change( function() {
	clearItemSelect();
	var innerColor=document.getElementById('colorStripeSelect').value;
	document.getElementById('stripecolorKeySelect').value = innerColor;
	$('#stripecolorKeySelect').trigger('liszt:updated');
	updateItemCodeChosen();
});
$("#numberOfCopperStrands").change(function(){
	var validCuStrand=false;
	var cuStrand=document.getElementById('numberOfCopperStrands').value;
	validCuStrand=validateCuStrand(cuStrand);
	if(validCuStrand==true){
	clearItemSelect();
	updateItemCodeChosen();
	}
});
$("#layLength").change(function(){
	var validLayLength=false;
	var layLength=document.getElementById('layLength').value;
	validLayLength=validateLayLength(layLength);
	if(validLayLength==true){
	clearItemSelect();
	updateItemCodeChosen();
	}
});
$("#layType").change(function(){
	var validLayType=false;
	var layType=document.getElementById('layType').value;
	validLayType=validateLayType(layType);
	if(validLayType==true){
	clearItemSelect();
	updateItemCodeChosen();
	}
});
$("#outerDiameter").change(function(){
	var validOd=false;
	var od=document.getElementById('outerDiameter').value;
	validOd=validateOd(od);
	if(validOd==true){
	clearItemSelect();
	updateItemCodeChosen();
	}
});
$("#area").change(function(){
	var validArea=false;
	var areaVal=document.getElementById('area').value;
	validArea=validateArea(areaVal);
	if(validArea==true){
	clearItemSelect();
	updateItemCodeChosen();
	}
});

$("#maincolorKeySelect").chosen().change( function() {
	clearItemSelect();
	var mainColor=document.getElementById('maincolorKeySelect').value;
	document.getElementById('colourMainSelect').value = mainColor;
	$('#colourMainSelect').trigger('liszt:updated');
	updateItemCodeChosen();

});
$("#stripecolorKeySelect").chosen().change( function() {
	clearItemSelect();
	var innerColor=document.getElementById('stripecolorKeySelect').value;
	document.getElementById('colorStripeSelect').value = innerColor;
	$('#colorStripeSelect').trigger('liszt:updated');
	updateItemCodeChosen();

});



function clearItemSelect(){
	//document.getElementById('itemIdSelect').value ="";
	//$('#itemIdSelect').trigger('liszt:updated');
	document.getElementById('itemCodesSelect').value ="";
}



function updateItemCodeChosen(){
	if(document.getElementById('stripecolorKeySelect').value!="" &&
			   document.getElementById('productTypeSelect').value!="" &&
			   document.getElementById('cableStdPvcSelect').value!="" &&
			   document.getElementById('copperDiameterSelect').value!="" &&
			   document.getElementById('maincolorKeySelect').value!="" &&
			   document.getElementById('numberOfCopperStrands').value!="" &&
			   document.getElementById('layLength').value!="" &&
			   document.getElementById('layType').value!="" &&
			   document.getElementById('outerDiameter').value!="" ){
					$.ajax({type:'POST', url: 'items/checkItemExist', 
						data:{
						'maincolorKeySelect' : $("#maincolorKeySelect").val(),
						'stripecolorKeySelect':$("#stripecolorKeySelect").val(),
						'productTypeSelect' : $("#productTypeSelect").val(),
						'cableStdPvcSelect' : $("#cableStdPvcSelect").val(),
						'copperDiameterSelect':$("#copperDiameterSelect").val(),
						'colourMainSelect' : $("#colourMainSelect").val(),
						'colorStripeSelect' : $("#colorStripeSelect").val(),
						'numberOfCopperStrands':document.getElementById('numberOfCopperStrands').value,
						'layLength' : document.getElementById('layLength').value,
						'layType' : document.getElementById('layType').value,
						'outerDiameter':document.getElementById('outerDiameter').value,
					    'unitTypeSelect':$("#unitTypeSelect").val()
						},
						success: function(response) {
			             if(response[0]!="New"){
			            	 newItemStatus=false;
			            	 document.getElementById('itemCodesSelect').value=response[0];
			             }else{
			            	newItemStatus=true;
			             }
					      }
						});	
				}
}

$('#createButton').click(function() {
	
	var itemCodeval=document.getElementById('itemCodesSelect').value;
	if(itemCodeval!=null && itemCodeval!=""){
		alert("Added Item already exist");
	}else{
		if(($("#maincolorKeySelect").val()=="")||($("#maincolorKeySelect").val()==null)){
			alert("Please select Main Color Key");
		}
		else if(($("#stripecolorKeySelect").val()=="")||($("#stripecolorKeySelect").val()==null)){
			alert("Please select Strip Color Key");
		}
		
		else if(($("#productTypeSelect").val()=="")||($("#productTypeSelect").val()==null)){
			alert("Please select Product Type");
		}
		else if(($("#cableStdPvcSelect").val()=="")||($("#cableStdPvcSelect").val()==null)){
			alert("Please select Cable Std PVC");
		}
		else if(($("#copperDiameterSelect").val()=="")||($("#copperDiameterSelect").val()==null)){
			alert("Please select Copper Diameter");
		}
		else if(($("#colourMainSelect").val()=="")||($("#colourMainSelect").val()==null)){
			alert("Please select Main Color");
		}
		else if(($("#colorStripeSelect").val()=="")||($("#colorStripeSelect").val()==null)){
			alert("Please select Stripe Color");
		}
		else if(document.getElementById('numberOfCopperStrands').value==""){
			alert("Please enter Copper Strands");
		}
		else if(document.getElementById('layLength').value==""){
			alert("Please enter Lay Length");
		}
		else if(document.getElementById('layType').value==""){
			alert("Please enter Lay Type");
		}
		else if(document.getElementById('outerDiameter').value==""){
			alert("Please enter Outer Diameter");
		}
		else if(($("#unitTypeSelect").val()=="")||($("#unitTypeSelect").val()==null)){
			alert("Please select Units");
		}
		else{
			$.ajax({
				type : 'POST',
				url : 'items/createNewItem',
				data : {
					/*'itemIdSelect' : $("#itemIdSelect").val(),*/
					'maincolorKeySelect' : $("#maincolorKeySelect").val(),
					'stripecolorKeySelect':$("#stripecolorKeySelect").val(),
					'productTypeSelect' : $("#productTypeSelect").val(),
					'cableStdPvcSelect' : $("#cableStdPvcSelect").val(),
					'copperDiameterSelect':$("#copperDiameterSelect").val(),
					'colourMainSelect' : $("#colourMainSelect").val(),
					'colorStripeSelect' : $("#colorStripeSelect").val(),
					'numberOfCopperStrands':document.getElementById('numberOfCopperStrands').value,
					'layLength' : document.getElementById('layLength').value,
					'layType' : document.getElementById('layType').value,
					'outerDiameter':document.getElementById('outerDiameter').value,
				    'unitTypeSelect':$("#unitTypeSelect").val()
					
				},
				success: function(response) {
				if (response.length>0) {
						if (response[0] == "Exist") {
							alert("Item you are trying to create already exists!");
							document.getElementById('itemCodesSelect').value=response[1];
						}
						
						if (response[0] == "Created") {
				    		alert("New Item " +response[1]+ " Successfully Created");
							document.getElementById('itemCodesSelect').value=response[1];
						}
				}

				}
			});

		}
	}

});
function validateCuStrand(cuStrand){
	var  pattern = /^(\d)*\d*$/;
			if(!pattern.test(cuStrand) || parseInt(cuStrand)>9999 ){
				alert("Enter valid No of Strands(0-9999)");
				document.getElementById('numberOfCopperStrands').value=""; 
				document.getElementById('numberOfCopperStrands').focus();
				return false;
			}
			else
				return true;
}
function validateLayLength(layLength){
    var  pattern =/^(\d)*\d*$/;
		if(!pattern.test(layLength) || parseInt(layLength)>99){
			alert("Enter valid Lay Length(0-99)");
			document.getElementById('laylength').value=""; 
			document.getElementById('laylength').focus();
			return false;
		}
		else
			return true;
}

function validateArea(areaVal){
	 var  pattern = /^[+]?([0-9]+(?:[\.][0-9]*)?|\.[0-9]+)$/;
		if(!pattern.test(areaVal)){
			alert("Enter valid Area");
			document.getElementById('area').value=""; 
			document.getElementById('area').focus();
		}
}

function validateLayType(layType){
	 var  pattern = /^[A-Z]{1}$/;
		if(!pattern.test(layType)){
			alert("Enter valid Lay Type(Caps A-Z)");
			document.getElementById('layType').value=""; 
			document.getElementById('layType').focus();
			return false;
		}
		else return true;
}

function validateOd(od){
	 
	 var pattern= /^\d(\d)?(\d)?(\d)?$/;
    if((pattern.test(od)) && (od.length==4 || od==0)){
		  return true;
	  }
	  else if(!pattern.test(od)){
			alert("Enter valid outer diameter");
			document.getElementById('outerDiameter').value=""; 
			document.getElementById('outerDiameter').focus();
			return false;

	  }
	  else if(od.length!=4){
			alert("Enter valid 4 digit as outer diameter");
			document.getElementById('outerDiameter').value=""; 
			document.getElementById('outerDiameter').focus();
			return false;
  
	  }
	else return false;

}

function itemCodeSelectOnChange(itemCodes){
	var itemCode = itemCodes;
	$.ajax(
			{
		    	 url: 'items/fetchItem',
			     contentType: "application/json; charset=utf-8",
			     dataType: "json",
				 data:{"itemCode":itemCode},
				 success: function(response) {
					document.getElementById('productTypeSelect').value = response[0];
					$('#productTypeSelect').trigger('liszt:updated');
					document.getElementById('cableStdPvcSelect').value = response[1];
					$('#cableStdPvcSelect').trigger('liszt:updated');
					document.getElementById('copperDiameterSelect').value = response[2];
					$('#copperDiameterSelect').trigger('liszt:updated');
					document.getElementById('colourMainSelect').value = response[3];
					$('#colourMainSelect').trigger('liszt:updated');
					document.getElementById('colorStripeSelect').value = response[4];
			    	$('#colorStripeSelect').trigger('liszt:updated');
					document.getElementById('numberOfCopperStrands').value = response[5];
					document.getElementById('layLength').value = response[6];
					document.getElementById('layType').value = response[7];
					document.getElementById('outerDiameter').value = response[8];
					document.getElementById('maincolorKeySelect').value = response[3];
					$('#maincolorKeySelect').trigger('liszt:updated');
					document.getElementById('stripecolorKeySelect').value =response[4];
					$('#stripecolorKeySelect').trigger('liszt:updated');
					document.getElementById('unitTypeSelect').value = response[12];    
					$('#unitTypeSelect').trigger('liszt:updated');
	  		 }
			}
			);
}