var lastSelected;
var netLengthValid=true;
var grossWeightValid=true;
var tareWeightValid=true;
var annealingValid=true;
var annealingPerValid=true;
var speedValid=true;
var systemDate = new Date();
var month="";
var year="";
	
$(function(){ 
	$("#monthYearPicker").focus(function () {$(".ui-datepicker-calendar").hide();});
	$('#monthYearPicker').datepicker({
	
        changeYear: true,
        changeMonth: true,
        changeDate :false,
        showButtonPanel: true,
        dateFormat: 'MM yy',
       
        onClose: function(dateText, inst) { 
        	 year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
             month = $("#ui-datepicker-div .ui-datepicker-month :selected").val();
            $(this).datepicker('setDate', new Date(year,month, 1));
            
        }
    });
	
$('#monthYearPicker').datepicker('setDate',systemDate); 
$("#monthYearPicker").focus(function () {$(".ui-datepicker-month").show();});
$("#monthYearPicker").focus(function () {$(".ui-datepicker-year").show();});

	
	$("#mwdWorkOrderNoSelect").chosen({no_results_text: "No results matched"});
	$("#workOrderStatusSelect").chosen({no_results_text: "No results matched"});
	
    $("#viewMWDWorkOrderGrid").jqGrid(
			{
				mtype : 'POST',
				datatype: 'local',
				 colNames:['woOutPutId','mwdWorkOrderNoSelect','Batch No','Size','Net Length(mts)*',
				           'Gross Weight(Kgs)*','Tare Weight(Kgs)*','Net Weight(Kgs)','Anealing %*',
				           'Production Speed*','Stocked In Status','Stocked In Status','Stock In','Label','Srcap Details','Action'],
				 colModel:[
				   	          {name:"woOutPutId",index:"woOutPutId",width:20,hidden:true},
				   	          {name:"workOrderNo",index:"workOrderNo",width:20,editable:true,hidden:true},
				   	          {name:'batchNo', index:'batchNo', width:100,editable : false ,viewable:false},
				   	          {name:'size', index:'size', width:100,editable :false},
				   	          {name:'netLength', index:'netLength', width:100,editable : true ,edittype:'text',editoptions:{
				                  dataInit: function(element) {
				                      $(element).keyup(function(){
				                          var val1 = element.value;
				                          var num = new Number(val1);
				                          if(isNaN(num))
				                          {
				                        	  alert("Please enter valid length");
				                        	  netLengthValid=false;
				                        	  jQuery("#viewMWDWorkOrderGrid").trigger('reloadGrid');
				                        }
				                          else
				                        	  netLengthValid=true;
				                        
				                      });
				                  }
				   	      ,maxlength:8
				              }},
				   	          {name:'grossWeight', index:'grossWeight', width:100, editable : true ,editoptions:{
				                  dataInit: function(element) {
				                      $(element).keyup(function(){
				                          var val1 = element.value;
				                          var num = new Number(val1);
				                          if(isNaN(num))
				                          {
				                        	  alert("Please enter valid Gross Weight");
				                        	  grossWeightValid=false;
				                        	  jQuery("#viewMWDWorkOrderGrid").trigger('reloadGrid');
				                         }
				                          else
				                        	  grossWeightValid=true;
				                        
				                      });
				                  }
				   	      ,maxlength:8
				              }},
				   	          {name:'tareWeight', index:'tareWeight', width:100, editable : true ,editoptions:{
				                  dataInit: function(element) {
				                      $(element).keyup(function(){
				                          var val1 = element.value;
				                          var num = new Number(val1);
				                          if(isNaN(num))
				                          {
				                        	  alert("Please enter valid Tare Weight");
				                        	  tareWeightValid=false;
				                        	  jQuery("#viewMWDWorkOrderGrid").trigger('reloadGrid');
				                         }
				                          else
				                        	  tareWeightValid=true;
				                        
				                      });
				                  }
				   	      ,maxlength:8
				              }},
				   	          {name:'netWeight', index:'netWeight', width:100, editable : false },
				   	          {name:'annealingPercent', index:'annealingPercent', width:100, editable : true,
				   	           editoptions:{
					                  dataInit: function(element) {
					                      $(element).keyup(function(){
					                          var val1 = element.value;
					                          var num = new Number(val1);
					                          if(isNaN(num))
					                          {
					                        	  alert("Please enter valid Annealing percent");
					                        	  annealingPerValid=false;
					                        	  jQuery("#viewMWDWorkOrderGrid").trigger('reloadGrid');
					                         }
					                          else
					                        	  annealingPerValid=true;
					                        
					                      });
					                  }
					   	      ,maxlength:8}}, 
				   	          {name:'speed', index:'speed', width:100, editable : true,   editoptions:{
				                  dataInit: function(element) {
				                      $(element).keyup(function(){
				                          var val1 = element.value;
				                          var num = new Number(val1);
				                          if(isNaN(num))
				                          {
				                        	  alert("Please enter valid Speed");
				                        	  speedValid=false;
				                        	  jQuery("#viewMWDWorkOrderGrid").trigger('reloadGrid');
				                         }
				                          else
				                        	  speedValid=true;
				                        
				                      });
				                  }
				   	          ,maxlength:8}},
				   	          {name:'stockIn', index:'stockIn', width:100, editable : false },
				   	          {name:'stockIn', index:'stockIn', hidden:true, editable : true },
				   	          {name:'stockLink',index:'stockLink', width:100, editable:false,sortable:false},				   	         
				   	          {name:'semiLink',index:'semiLink',width:100, editable:false,sortable:false},  
				   	          {name:'scrapLink',index:'scrapLink', width:10, editable:false,hidden:true,sortable:false},   
				   	          {name:'act',index:'act', width:70,sortable:false}
				   	      ],
				postData : {},
				rowNum : 100,
				rowList : [ 10, 20, 40, 60,100 ],
				height : 240,
			    autowidth:true,
				footerrow: true,
				rownumbers : false,
				pager : '#viewMWDWorkOrderPager',
				sortname : 'woOutPutId',
				viewrecords : true,
				sortorder : "desc",
				caption : "MWD Work Order Output",
				emptyrecords : "Empty records",
				loadonce : false,
							
				jsonReader : {
					root : "rows",
					page : "page",
					total : "total",
					records : "records",
					repeatitems : false,
					cell : "cell",
					id : "woOutPutId"
				},
				 ondblClickRow : function(id) {
						if (id && id !== lastSelected) {
							$('#viewMWDWorkOrderGrid').jqGrid('restoreRow',lastSelected);
							editRow1(id);
							lastSelected = id;
						}
					},
					gridComplete : function() {
						 var netLength = $('#viewMWDWorkOrderGrid').jqGrid('getCol','netLength',false,'sum');
	        	   		 var grossWeight = $('#viewMWDWorkOrderGrid').jqGrid('getCol','grossWeight',false,'sum');
	        	   		 var tareWeight= $('#viewMWDWorkOrderGrid').jqGrid('getCol','tareWeight',false,'sum');
	        	   		 var netWeight= $('#viewMWDWorkOrderGrid').jqGrid('getCol','netWeight',false,'sum');
	            
	        	   	  var totalNetLength=Math.round(parseFloat(netLength) * 100) / 100;
        	   	 	  var totalGross=Math.round(parseFloat(grossWeight) * 100) / 100;
        	   	 	  var totalTare=Math.round(parseFloat(tareWeight) * 100) / 100;
                      var totalNetWeight=Math.round(parseFloat(netWeight) * 100) / 100;
                
                  	$('#viewMWDWorkOrderGrid').jqGrid('footerData','set', {ID: 'Total:', netLength: totalNetLength});
    	   	    	$('#viewMWDWorkOrderGrid').jqGrid('footerData','set', {ID: 'Total:', grossWeight: totalGross});
    	   	    	$('#viewMWDWorkOrderGrid').jqGrid('footerData','set', {ID: 'Total:', tareWeight: totalTare});
    	   	    	$('#viewMWDWorkOrderGrid').jqGrid('footerData','set', {ID: 'Total:', netWeight: totalNetWeight});
    	   	    
	        	   		 
	        	   		 
						var ids = jQuery("#viewMWDWorkOrderGrid").jqGrid('getDataIDs');
					
						for ( var i = 0; i < ids.length; i++) {
							var cl = ids[i];
							 var woId = jQuery("#viewMWDWorkOrderGrid").jqGrid ('getCell', cl, 'woOutPutId'); 
				
					      
							be = "<input style='height:22px; width:35px;' type='button' value='Edit' id='editRow1"+cl+"' onclick=\"editRow1('"+ cl + "');\" />";
							de = "<input style='height:22px; width:30px;' type='button' value='Del' id='delRow1"+cl+"' onclick=\"delRow1('"+ cl + "');\" />";
							se = "<input style='height:22px; width: 29px;' type='button' value='Save' hidden='hidden'  id='saveRow1"+cl+"' onclick=\"saveRow1('"+ cl + "');\" />";
							ce = "<input style='height:22px;width:39px;' type='button' value='Cancel' hidden='hidden' id='restoreRow1"+cl+"' onclick=\"restoreRow1('"+ cl + "');\" />";
							
							sdLink = "<button class='btn btn-mini' id='itemDetailsLink"+cl+"' " +"onclick=\"stockInMWD('"+ cl + "');\" >Stock In </button>";
							sfLink = "<button class='btn btn-mini' id='semifinishedLabel"+cl+"'" +" onclick=\"location.href='viewMWDWorkOrder/semiFinishedLabelReport?woId="+woId+"';\" >Label</button>";
							scrLink = "<button class='btn btn-mini' id='itemDetailsLink"+cl+"'" +"onclick=\"scrapDetails('"+ cl + "');\" >Scrap Details </button>";
							
							$("#viewMWDWorkOrderGrid").jqGrid('setRowData', ids[i],
									{
										act : be + de + se + ce,
										stockLink :sdLink,
										semiLink :sfLink,
										scrapLink :scrLink
										
									});
							if($("#viewMWDWorkOrderGrid").getCell(cl,"stockIn")=="Yes"){
								 $("#viewMWDWorkOrderGrid").jqGrid('setRowData',ids[i],false, {  color:'black',weightfont:'bold',background:'#90ee90'});
							}
						}
						
					},
				editurl : "viewMWDWorkOrder/crud"
					
			});
		$("#viewMWDWorkOrderGrid").jqGrid('navGrid', "#viewMWDWorkOrderPager", {edit : false,add : false,del : false,search:false,view:false});

$("#storeRegisterForRBDGrid").jqGrid({
	mtype : 'POST',
	datatype: 'json',
	multiselect:true,
	    colNames:['mwdWoInputId','workOrderNo','Size','Length(mts)','Total Qty(kgs)','Anealing Percent','Partyhidden','Party','status','Action'],
	   	colModel:[
	   	    
		   {name:"mwdWoInputId",index:"mwdWoInputId",width:20,hidden:true},
		   {name:'workOrderNo', index:'workOrderNo', width:10,hidden:true, editable:true}, 
		   {name:'size', index:'size', width:100,editable : false },
		   {name:'netLength', index:'netLength', width:100,editable : false },
		   {name : 'totalQty',index : 'totalQty',width :100,editable : false},
		   {name:'anealingPercent', index:'anealingPercent', width:100, editable : true,  editoptions:{
               dataInit: function(element) {
                   $(element).keyup(function(){
                       var val1 = element.value;
                       var num = new Number(val1);
                       if(isNaN(num))
                       {
                     	  alert("Please enter valid Annealing percent");
                     	  annealingValid=false;
                     	  jQuery("#storeRegisterForRBDGrid").trigger('reloadGrid');
                      }
                       else
                     	  annealingValid=true;
                     
                   });
               }
	      ,maxlength:8}}, 
		   {name:'customerName', index:'customerName', width:100,editable : false,hidden:true },
		   {name:'customerCode', index:'customerCode', width:100,editable : false },
		   {name:'selectStatus', index:'selectStatus', width:50,editable : false,hidden:true },
		   {name:'act2',index:'act2', width:70,sortable:false}
	   	],
	   	postData : {},
		rowNum : 100,
		rowList : [ 5, 10, 20, 40, 60 ,100],
		height : 240,
		autowidth:true,
		rownumbers : false,
		pager : '#storeRegisterForRBDPager',
		sortname : 'mwdWoInputId',
		viewrecords : true,
		sortorder : "desc",
	    caption:"MWD Work Order Input",
	    emptyrecords : "Empty records",
		loadonce : false,
		footerrow: true,
					
		jsonReader : {
			root : "rows",
			page : "page",
			total : "total",
			records : "records",
			repeatitems : false,
			cell : "cell",
			id : "mwdWoInputId"
		},
		onSelectRow: updateIdsOfSelectedRows,   
		 onSelectAll: function (aRowids, isSelected) {
	        var i, count, id;
	        for (i = 0, count = aRowids.length; i < count; i++) {
	            id = aRowids[i];
	            updateIdsOfSelectedRows(id, isSelected);
	        }
	    },
	    ondblClickRow : function(id) {
				if (id && id !== lastSelected) {
					$('#storeRegisterForRBDGrid').jqGrid('restoreRow',lastSelected);
					editRow2(id);
					lastSelected = id;
				}
			},
			gridComplete : function() {
   	   		 var netLength = $('#storeRegisterForRBDGrid').jqGrid('getCol','netLength',false,'sum');
	   	 	  var totalNetLength=Math.round(parseFloat(netLength) * 100) / 100;
	   	    	$('#storeRegisterForRBDGrid').jqGrid('footerData','set', {ID: 'Total:', netLength: totalNetLength});

				
				
				var ids = jQuery("#storeRegisterForRBDGrid").jqGrid('getDataIDs');
				for ( var i = 0; i < ids.length; i++) {
					var cl2 = ids[i];
					be = "<input style='height:22px; width:35px;' type='button' value='Edit' id='editRow2"+cl2+"' onclick=\"editRow2('"+ cl2 + "');\" />";
					se = "<input style='height:22px; width: 29px;' type='button' value='Save' hidden='hidden'  id='saveRow2"+cl2+"' onclick=\"saveRow2('"+ cl2 + "');\" />";
					ce = "<input style='height:22px;width:39px;' type='button' value='Cancel' hidden='hidden' id='restoreRow2"+cl2+"' onclick=\"restoreRow2('"+ cl2 + "');\" />";
					
					$("#storeRegisterForRBDGrid").jqGrid('setRowData', ids[i],
							{
								act2 : be +se + ce
							
							});
					if ($("#storeRegisterForRBDGrid").getCell(cl2,"selectStatus") == "Yes") {
						$("#storeRegisterForRBDGrid").jqGrid('setRowData', ids[i], false, {color : 'black',weightfont : 'bold',background : '#F6E3CE'});
					}
				}
			
			
			},
		editurl : "viewMWDWorkOrder/crudForFirstGrid"
});
$("#storeRegisterForRBDGrid").jqGrid('navGrid', "#storeregisterForRBDpager", {edit : false,add : false,view:false,del : false,search:false});

});

$("#mwdWorkOrderNoSelect").chosen().change(function() {
	
	var woNo = $('#mwdWorkOrderNoSelect').val();
	
	$.ajax({type:'POST', 
		url: 'viewMWDWorkOrder/getWODetails/'+ encodeURIComponent(woNo),
		success: function(response) {
		/*	alert(response);
			alert(response[0]);*/
			document.getElementById('mwdStartDate').value=response[0];
			document.getElementById('mwdCompletionDate').value=response[1];
			document.getElementById('mwdMachineNo').value=response[2];
			document.getElementById('woStatus').value=response[3];
		
			
			jQuery("#storeRegisterForRBDGrid").setGridParam({datatype:'json'}); 
			jQuery("#storeRegisterForRBDGrid").setGridParam({ url : 'viewMWDWorkOrder/populateWODetailsGrid/' + encodeURIComponent(woNo)});
			jQuery("#storeRegisterForRBDGrid").setCaption('Input for MWD Work Order No ' + woNo);
			jQuery("#storeRegisterForRBDGrid").trigger('reloadGrid');
			
			jQuery("#viewMWDWorkOrderGrid").setGridParam({datatype:'json'}); 
			jQuery("#viewMWDWorkOrderGrid").setGridParam({ url : 'viewMWDWorkOrder/records/' + encodeURIComponent(woNo)});
			jQuery("#viewMWDWorkOrderGrid").setCaption('Output for MWD Work Order No ' + woNo);
			jQuery("#viewMWDWorkOrderGrid").trigger('reloadGrid');
			var woStatus= document.getElementById('woStatus').value;
		    
		    if(woStatus == 'Submitted'){
		    	document.getElementById('addBtn').disabled=true;
		    	document.getElementById('submitMWDWorkOrder').disabled=true;
		    }else{
		    	document.getElementById('addBtn').disabled=false;
		    	document.getElementById('submitMWDWorkOrder').disabled=false;
		    }
			
		}});

});


function editRow1(id) {
	var grid = jQuery('#viewMWDWorkOrderGrid');
	var stockInStatus=grid.jqGrid ('getCell', id, 'stockIn');	
	var batchNo=grid.jqGrid ('getCell', id, 'batchNo');
	if(stockInStatus != 'Yes'){
	restoreRow1(lastSelected);
	lastSelected = id;
	var woStatus= document.getElementById('woStatus').value;
	var woNo = $('#mwdWorkOrderNoSelect').val();

		if(woStatus == 'Submitted'){
			alert("The Work Order "+woNo+" Is In Submitted State");
			
	    }else{
    	$('#viewMWDWorkOrderGrid').jqGrid('editRow',id, 
    			{
    				"keys" :true, 
    				"oneditfunc" : hideActButtons1,
    				aftersavefunc : function(savedId, response) {
    					showActButtons1(savedId);
    				},
    				afterrestorefunc : showActButtons1
    			});
    }

}else{
	alert("The Work Order Output "+batchNo+" is stocked in");
}}

function delRow1(id) {
var grid = jQuery('#viewMWDWorkOrderGrid');
var stockInStatus=grid.jqGrid ('getCell', id, 'stockIn');
var batchNo=grid.jqGrid ('getCell', id, 'batchNo');
if(stockInStatus == 'Yes'){
		alert("The Work Order Output "+batchNo+" is stocked in");
   }else{
    	if(confirm("Are you sure you want to delete ?")){
	   		 var oper ="del";
	   		 $.ajax({type:'POST', 
	   		 		url: 'viewMWDWorkOrder/crud',
	   		 		data:{'id':id,'oper':oper},
	   				success: function(response) {
	   					jQuery("#viewMWDWorkOrderGrid").trigger('reloadGrid');
	   				}});
	   	
	   	 };
    }
	 
}

function saveRow1(id) {
	if(netLengthValid==true && grossWeightValid==true && tareWeightValid==true && annealingPerValid==true && speedValid==true){
	$('#viewMWDWorkOrderGrid').saveRow(id,
	{	aftersavefunc : function(id, response) {
				showActButtons1(id);
				var grid = jQuery('#viewMWDWorkOrderGrid');
				var grossWt = grid.jqGrid('getCell', id, 'grossWeight');
				var tareWt = grid.jqGrid('getCell', id, 'tareWeight');
				if (grossWt != null && tareWt != null && parseFloat(grossWt)>=parseFloat(tareWt)) {
			    	var netWght = grossWt-tareWt;
					grid.jqGrid('setCell', id, 'netWeight', netWght);
				}
				else if(parseFloat(grossWt)<parseFloat(tareWt)){
					alert("Gross Weight should be greater than Tare Weight");
					grid.jqGrid('setCell', id, 'grossWeight', 0);
					grid.jqGrid('setCell', id, 'tareWeight', 0);
					grid.jqGrid('setCell', id, 'netWeight', 0);
				}else{
					grid.jqGrid('setCell', id, 'netWeight', 0);
				}
				jQuery("#viewMWDWorkOrderGrid").trigger('reloadGrid');
} });   	   
	}else if(netLengthValid==false){
		alert("Enter Valid Length");
	}else if(grossWeightValid==false){
		alert("Enter Valid Gross Weight");
	}else if(tareWeightValid==false){
		alert("Enter Valid Tare Weight");
	}else if(annealingPerValid==false){
		alert("Enter Valid Annealing percent");
	}else if(speedValid==false){
		alert("Enter Valid Production Speed");
	}
}

function restoreRow1(id) {
	$('#viewMWDWorkOrderGrid').jqGrid('restoreRow',id,
			{
				afterrestorefunc : showActButtons1
				
			});
}
function editRow2(id) {
	restoreRow2(lastSelected);
	lastSelected = id;
	var woStatus= document.getElementById('woStatus').value;
	var woNo = $('#mwdWorkOrderNoSelect').val();

		if(woStatus == 'Submitted'){
			alert("The Work Order "+woNo+" Is In Submitted State");
			
	    }else{
	    	$('#storeRegisterForRBDGrid').jqGrid('editRow',id, 
	    			{
	    			
	    				"keys" :true, 
	    				"oneditfunc" : hideActButtons2,
	    				aftersavefunc : function(savedId, response) {
	    					showActButtons2(savedId);
	    				},
	    				
	    				afterrestorefunc : showActButtons2
	    				
	    			});
	    }

}

function saveRow2(id) {
if( annealingValid=true){
	$('#storeRegisterForRBDGrid').saveRow(id,
	{	aftersavefunc : function(id, response) {
		var grid = jQuery('#storeRegisterForRBDGrid');
		var annealingPercent = grid.jqGrid('getCell', id, 'anealingPercent');
	    if(annealingPercent==null || annealingPercent==""){
	    	alert("Enter valid annealing percent");
	    }

				showActButtons2(id);
				jQuery("#storeRegisterForRBDGrid").trigger('reloadGrid');
			}
	});
}else if(annealingValid==false){
	alert("Enter valid annealing percent");
}}

function restoreRow2(id) {
	$('#storeRegisterForRBDGrid').jqGrid('restoreRow',id,
			{
				afterrestorefunc : showActButtons2
			});
}

idsOfSelectedRows = ["1", "2", "3"];
var $StoreRegisterForRBDGrid= $("#storeRegisterForRBDGrid"), idsOfSelectedRows = [],
updateIdsOfSelectedRows = function (id, isSelected) {
	   var index = $.inArray(id, idsOfSelectedRows);
        if (!isSelected && index >= 0) {
            idsOfSelectedRows.splice(index, 1); // remove id from the list
        } else if (index < 0) {
            idsOfSelectedRows.push(id);
        }  
};



/*
 * Hides the Edit and Del Row Buttons on jqGrid
 * and activates the Save and restore(cancel) button
 * 
 */

function hideActButtons1(id){
	$('#editRow1' + id).hide();
	$('#delRow1' + id).hide();
	$('#saveRow1' + id).show();
	$('#restoreRow1' + id).show();
}

/*
 * Shows the Edit and Del Row Buttons on jqGrid
 * and hides the Save and restore(cancel) button
 * 
 */
function showActButtons1(id) {
	$('#editRow1' + id).show();
	$('#delRow1' + id).show();
	$('#saveRow1' + id).hide();
	$('#restoreRow1' + id).hide();
	lastSelected = null;
}
function hideActButtons2(id){
	$('#editRow2' + id).hide();
	$('#delRow2' + id).hide();
	$('#saveRow2' + id).show();
	$('#restoreRow2' + id).show();
}

/*
 * Shows the Edit and Del Row Buttons on jqGrid
 * and hides the Save and restore(cancel) button
 * 
 */
function showActButtons2(id) {
	$('#editRow2' + id).show();
	$('#delRow2' + id).show();
	$('#saveRow2' + id).hide();
	$('#restoreRow2' + id).hide();
	lastSelected = null;
}

function submitMWDWorkOrderFn(){
	var woStatus= document.getElementById('woStatus').value;
	var woNo = $('#mwdWorkOrderNoSelect').val();
	var stockInStatusCount=0;
	var ids = jQuery("#viewMWDWorkOrderGrid").jqGrid('getDataIDs');
	for ( var i = 0; i < ids.length; i++) {
		var cl = ids[i];
		 var stockInStatus=jQuery("#viewMWDWorkOrderGrid").jqGrid ('getCell', cl, 'stockIn');
		 if(stockInStatus=="No")
			 stockInStatusCount++;
	}
	if(woStatus == 'Submitted'){
			alert("The Work Order "+woNo+" Is Already In Submitted State");
		
	 }
	else if (stockInStatusCount!=0){
		alert("All Outputs should be stocked in for submitting "+woNo);
	}
	else if ($("#viewMWDWorkOrderGrid").getGridParam("reccount")==0){
		alert("Output should be there for submitting "+woNo);
	}
	else{
	    	if(confirm("Are You Sure You Want To Submit?")){
	    		$.ajax({type:'POST', 
	    			url: 'viewMWDWorkOrder/submitMWDWorkOrder/'+ encodeURIComponent(woNo),
	    			success: function(response) {
	    				
	    				document.getElementById('addBtn').disabled=true;
	    				document.getElementById('woStatus').value="Submitted";
	    				alert("The Work Order "+woNo+" Is Submitted.");
	    					
	    		}});
	    	}
	    }
	
	
}

function stockInMWD(id){

	var grid = jQuery('#viewMWDWorkOrderGrid'); 
    var stockInStatus=grid.jqGrid ('getCell', id, 'stockIn');
    var batchNo=grid.jqGrid ('getCell', id, 'batchNo');
    var size=grid.jqGrid ('getCell', id, 'size');
     
    var netLength=grid.jqGrid ('getCell', id, 'netLength');
    var grossWeight=grid.jqGrid ('getCell', id, 'grossWeight');
    var tareWeight=grid.jqGrid ('getCell', id, 'tareWeight');
    var speed=grid.jqGrid ('getCell', id, 'speed');
    var annealing=grid.jqGrid ('getCell', id, 'annealingPercent');
  
	var woNo = $('#mwdWorkOrderNoSelect').val();

    	 if(netLength== 0 || grossWeight==0 || tareWeight==0 || speed==0){
	    	    	alert("Please Enter Essential Data for stock In i.e. Net Length, Gross Weight , Tare Weight & Speed");
	    	    }
                else if(speed==null || speed==0 || speed==""){
	            alert("Please enter valid Production Speed");
              }else if(annealing==null || annealing==0 || annealing==""){
            	  alert("Please enter valid annealing percent");
              }
               else{
	    	    	if(stockInStatus == 'Yes'){
	    	        	alert("Batch "+batchNo+" Of Size "+size+" Has Already Been Stocked In.");
	    	        }else{
	    	        	if(confirm("Are You Sure You Want To Stock In?")){
	    	        		saveRow1(id);	
	    	        		$.ajax({type:'POST', 
	    	        			url: 'viewMWDWorkOrder/stockIn/'+ encodeURIComponent(id),
	    	        			success: function(response) {
	    	        				jQuery("#viewMWDWorkOrderGrid").setGridParam({datatype:'json'}); 
	    	        				jQuery("#viewMWDWorkOrderGrid").setGridParam({ url: 'viewMWDWorkOrder/records/'+ encodeURIComponent(woNo)});
	    	        				jQuery("#viewMWDWorkOrderGrid").trigger('reloadGrid');
	    	        					
	    	        			}
	    	        		});
	    	        	}
	    	        }
	    	    }

   
}


function validateDetails(){
	if(document.getElementById('netLength').value==""){
		alert("Enter Net Weight");
		return false;
    }
	if(isNaN(document.getElementById('netLength').value)){
 		alert("Enter Valid Net Length");
 		document.getElementById('netLength').value="";
		return false;
    }
	if(document.getElementById('grossWeight').value==""){
		alert("Enter Gross Weight");
		return false;
    }
	if(isNaN(document.getElementById('grossWeight').value)){
 		alert("Enter Valid Gross Weight");
 		document.getElementById('grossWeight').value="";
		return false;
    }
	if(document.getElementById('tareWeight').value==""){
		alert("Enter Tare Weight");
		return false;
    }
	if(isNaN(document.getElementById('tareWeight').value)){
 		alert("Enter Valid Tare Weight");
 		document.getElementById('tareWeight').value="";
		return false;
    }

	if(document.getElementById('anealingPercent').value==""){
		alert("Enter Annealing Percent");
		return false;
	}	
	if(isNaN(document.getElementById('anealingPercent').value)){
	 	alert("Enter Valid Annealing Percent");
	 	document.getElementById('anealingPercent').value="";
		return false;
	}
	if(document.getElementById('speed').value==""){
		alert("Enter Production Speed");
		return false;
	}	
	if(isNaN(document.getElementById('speed').value)){
	 	alert("Enter Valid Production Speed");
	 	document.getElementById('speed').value="";
		return false;
	}
	else return true;

}

function addOutputRow(){
		if(idsOfSelectedRows.length>0){
		 $.ajax({type:'POST', 
				url: 'viewMWDWorkOrder/createMWDWoOutput',
							data:{'idsOfSelectedRows': idsOfSelectedRows},
			               	success: function(response) {
			               		var woNo = document.getElementById('mwdWorkOrderNoSelect').value;
			               		jQuery("#viewMWDWorkOrderGrid").setGridParam({datatype:'json'}); 
		    					jQuery("#viewMWDWorkOrderGrid").setGridParam({ url : 'viewMWDWorkOrder/records/' + encodeURIComponent(woNo)});
		    					jQuery("#viewMWDWorkOrderGrid").trigger('reloadGrid');
		    					
		    					jQuery("#storeRegisterForRBDGrid").setGridParam({datatype:'json'}); 
		    					jQuery("#storeRegisterForRBDGrid").setGridParam({ url : 'viewMWDWorkOrder/populateWODetailsGrid/' + encodeURIComponent(woNo)});
		    					jQuery("#storeRegisterForRBDGrid").setCaption('Input for MWD Work Order No ' + woNo);
		    					jQuery("#storeRegisterForRBDGrid").trigger('reloadGrid');
		    				
		    					idsOfSelectedRows = [];	
		    	      	   	}});
	
}else{
	alert("Select MWD Input");}
}

$(document).keypress(function(e) {
	if (e.which == 13) {
		var ids = $("#viewMWDWorkOrderGrid").jqGrid('getDataIDs');
		for ( var i = 0; i < ids.length; i++) {
			var cl = ids[i];
			var grid = jQuery('#viewMWDWorkOrderGrid');
		    var grossWt = grid.jqGrid('getCell', cl, 'grossWeight');
			var tareWt = grid.jqGrid('getCell', cl, 'tareWeight');
			if (grossWt != null && tareWt != null && parseFloat(grossWt)>=parseFloat(tareWt)) {
		    	var netWght = grossWt-tareWt;
				grid.jqGrid('setCell', cl, 'netWeight', netWght);
				saveRow1(cl);
			}
			else if(parseFloat(grossWt)<parseFloat(tareWt)){
				alert("Gross Weight should be greater than Tare Weight");
				grid.jqGrid('setCell', cl, 'grossWeight', 0);
				grid.jqGrid('setCell', cl, 'tareWeight', 0);
				grid.jqGrid('setCell', cl, 'netWeight', 0);
			}else{
				grid.jqGrid('setCell', cl, 'netWeight', 0);
			}
		
		}
		
		jQuery("#viewMWDWorkOrderGrid").trigger('reloadGrid');
	}});

function semifinishedLabel(cellValue, rowId, rowData)
{

}

function validateSearchParams(){

	  if($("#monthYearPicker").val()=="" || $("#monthYearPicker").val()==null){
	    	alert("Month and Year empty! please select month and year");
	    	return false;
	    }
	    else return true;
}
$("#workOrderStatusSelect").chosen().change(function() {
	var validSearch=validateSearchParams();
	
	if(validSearch==true){
	
	var status = $('#workOrderStatusSelect').val();
	$('#mwdWorkOrderNoSelect').children().remove();
	$('#mwdWorkOrderNoSelect').val('').trigger('liszt:updated');
	document.getElementById('mwdStartDate').value="";
	document.getElementById('mwdCompletionDate').value="";
	document.getElementById('mwdMachineNo').value="";
	 month = $("#ui-datepicker-div .ui-datepicker-month :selected").val();
     year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
	$.ajax({type:'POST', 
		url: 'viewMWDWorkOrder/getWorkOrderNos/'+ encodeURIComponent(status),
		data : {"processType" : "MWD","month":month,"year":year},
		success: function(response) {
			$('#mwdWorkOrderNoSelect').empty();
			if (response.length == 0) {

				alert("There is no Work Order for selected month,year and status");
			}

			if(response.length != 0){
				for(var i=0;i< response.length;i++){
					$('#mwdWorkOrderNoSelect').append('<option selected="selected">'+ "" + '</option>');
					$('#mwdWorkOrderNoSelect').append('<option >' + response[i]+ '</option>');
					$('#mwdWorkOrderNoSelect').trigger('liszt:updated');
				}
			}else{
				$('#mwdWorkOrderNoSelect').empty();
				document.getElementById('mwdStartDate').value="";
				document.getElementById('mwdCompletionDate').value="";
				document.getElementById('mwdMachineNo').value="";

			}
		}
	});
	}
	else
	{
	alert("Please select month and year");
	}
});


function mwdJobCardReport(){
 var woNo=document.getElementById('mwdWorkOrderNoSelect').value;
if(woNo!=null && woNo!="")
	location.href='viewMWDWorkOrder/mwdJobCardReport?workOrderNo='+woNo;
else
	alert("Select Work Order No");
}


$("#monthYearPicker").focus(function() {
	
	if ($("#workOrderStatusSelect").val() != "") {
		document.getElementById('workOrderStatusSelect').value = "";
		$('#workOrderStatusSelect').trigger('liszt:updated');
	}
	
	if ($("#mwdWorkOrderNoSelect").val() != "") {
		document.getElementById('mwdWorkOrderNoSelect').value = "";
		$('#mwdWorkOrderNoSelect').trigger('liszt:updated');
		$('#mwdWorkOrderNoSelect').children().remove();
		}
	
	if (document.getElementById('mwdStartDate').value != "")
		document.getElementById('mwdStartDate').value = "";
	
	if (document.getElementById('mwdCompletionDate').value != "")
		document.getElementById('mwdCompletionDate').value = "";
	
	if (document.getElementById('mwdMachineNo').value != "")
		document.getElementById('mwdMachineNo').value = "";
	
	$('#storeRegisterForRBDGrid').jqGrid('clearGridData');
});

function workOrderReport(){
	 var woNo=document.getElementById('mwdWorkOrderNoSelect').value;
	  if(woNo!=null && woNo!="")
	location.href='createMWDWorkOrder/mwdWorkOrderReport?workOrderNo='+woNo;
	  else
			alert("Select Work Order No");
}