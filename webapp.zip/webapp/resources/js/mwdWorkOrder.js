var annealingValid=true;
var submitStatus=false;;
var productTypeArray;
var noOfCuStarndArray;
var cuDiamArrray;
$(function(){ 
	

    $.ajax({
        url: 'createBunchingWorkOrder/fetchProductType',
        dataType: "json",
        data:{"processType":"MWD"},
       
         success: function(data) {
        	 productTypeArray=data;
        }
    });
	$("#productTypeAutoSelect").autocomplete({
	    source: function(request, response) {
	        var results = $.ui.autocomplete.filter(productTypeArray, request.term);
	        response(results.slice(0, 15));
	    },
	    select: function (a, b) {
	      	productTypeSelectOnChange(b.item.value);
	    }
	});
	 
	$("#numberOfCopperStrandsAutoSelect").autocomplete({
	    select: function (a, b) {
	    	cuStrandsSelectOnChange(b.item.value);
	    }
	});
	$("#copperDiameterAutoSelect").autocomplete({
	    select: function (a, b) {
	      	cuDiameterSelectOnChange(b.item.value);
	    }
	});
	
    
	$("#mwdWoNoSelect").chosen({no_results_text: "No results matched"});
	
	 if($('input:radio[name=workOrderSelect]:checked').val()==0){
	     $('.newWoTableId').show();
		  $('.existingWoTableId').hide();
		  $('#resetBtn').show();
 	  }else{
		  $('.existingWoTableId').show();
		  $('.newWoTableId').hide();
		  $('#resetBtn').hide();
	  }


	  $("input[name=workOrderSelect]").change(function () {
		  if($('input:radio[name=workOrderSelect]:checked').val()==0){
			  $('.newWoTableId').show();
			  $('.existingWoTableId').hide();
			  $('#resetBtn').show();
			    document.getElementById('mwdWorkOrderNoTag').value = "";
				document.getElementById('mwdStartDate').value = "";
				document.getElementById('mwdCompletionDate').value = "";
				document.getElementById('mwdWoMachineNoSelect').value = "";
				$('#mwdWoMachineNoSelect').trigger('liszt:updated');
			
				document.getElementById('mwdStartDate').disabled = false;
				document.getElementById('mwdCompletionDate').disabled = false;
				document.getElementById('mwdWoMachineNoSelect').disabled = false;
				document.getElementById('numberOfCopperStrandsAutoSelect').disabled = false;
				document.getElementById('copperDiameterAutoSelect').disabled = false;
				document.getElementById('productTypeAutoSelect').disabled = false;
				document.getElementById('netLength').disabled = false;
				document.getElementById('anealingPercent').disabled = false;
	
				document.getElementById('numberOfCopperStrandsAutoSelect').value = "";
				document.getElementById('copperDiameterAutoSelect').value = "";
			    document.getElementById('productTypeAutoSelect').value = "";
				document.getElementById('netLength').value = "";
				document.getElementById('anealingPercent').value = "";
			   	document.getElementById('selectSOId').disabled=false;
		  		document.getElementById('showWOId').disabled=false;
		   		document.getElementById('createMwdWOBtn').disabled=false;
		
		   		document.getElementById('submitBtn').disabled=false;
		   	    jQuery("#MWDWorkOrderGrid").jqGrid("clearGridData", true);
				
		  }else{
				$('#resetBtn').hide();
			    $('#mwdWoNoSelect').children().remove();
				$('#mwdWoNoSelect').val('').trigger('liszt:updated');
 
				$.ajax({type:'POST', 
					url: 'createMWDWorkOrder/getMwdWoNos',
					success: function(response) {
						$('#mwdWoNoSelect').empty();
						if(response.length != 0){
							for(var i=0;i< response.length;i++){
								$('#mwdWoNoSelect').append('<option selected="selected">'+ "" + '</option>');
								$('#mwdWoNoSelect').append('<option >' + response[i]+ '</option>');
								$('#mwdWoNoSelect').trigger('liszt:updated');
							}
						}else{
							$('#mwdWoNoSelect').empty();
						}
						
				  				
				}});
			  
			  
			  $('.existingWoTableId').show();
			  $('.newWoTableId').hide();

        	  var woNo=$('#mwdWoNoSelect').val();
			  if(woNo!=null && woNo!=""){
	          jQuery("#MWDWorkOrderGrid").setGridParam({datatype:'json'}); 
			  jQuery("#MWDWorkOrderGrid").setGridParam({  url : 'viewMWDWorkOrder/populateWODetailsGrid/' + encodeURIComponent(woNo)});
			  jQuery("#MWDWorkOrderGrid").trigger('reloadGrid');
			  }else
				  jQuery("#MWDWorkOrderGrid").jqGrid("clearGridData", true);
			
			  document.getElementById('netLength').value = "";
			  document.getElementById('numberOfCopperStrandsAutoSelect').value = "";
			  document.getElementById('copperDiameterAutoSelect').value = "";
			  document.getElementById('productTypeAutoSelect').value = "";
			  document.getElementById('anealingPercent').value = "";
			  
				if(document.getElementById('woStatus').value=="Submitted"){
				 	document.getElementById('saveWorkOrderExistWo').disabled=true;
			   		document.getElementById('fetchWoItemsExistWo').disabled=true;
			   		document.getElementById('createMwdWOBtn').disabled=true;
			   		document.getElementById('submitBtn').disabled=true;
				 	submitStatus=true;

			  }else{
				 	document.getElementById('saveWorkOrderExistWo').disabled=false;
			   		document.getElementById('fetchWoItemsExistWo').disabled=false;
			   		document.getElementById('createMwdWOBtn').disabled=false;
			   		document.getElementById('submitBtn').disabled=false;
		     		submitStatus=false;
		  
			  }
			
		  }
	  });
	$("#mwdWoMachineNoSelect").chosen({no_results_text : "No results matched"});
	$("#inputSizeSelect").chosen({no_results_text : "No results matched"});
	$("#mwdStartDate").datepicker({
		dateFormat : "dd-mm-yy",
		maxDate : 'today',
		onSelect : function(dateStr) {
			var min = $('#mwdStartDate').datepicker('getDate');
			$('#mwdCompletionDate').datepicker('option', {
				minDate : min
			});
		}
	});
	$("#mwdCompletionDate").datepicker({dateFormat : "dd-mm-yy"});
	minDate: $('#mwdStartDate').datepicker('getDate');
});

var lastSelected;
$(function() {
$("#MWDWorkOrderGrid").jqGrid({
	                   datatype : 'local',
						mtype : 'POST',
						colNames : [ 'mwdWoInputId','soitem id', 'workOrder No', 'Size','Total Qty(Kgs)','Length(mts)', 'Annealing(%)', 'Partyhidden','Party','Actions' ],
						colModel : [
						   {name : 'mwdWoInputId',index : 'mwdWoInputId',width : 10,hidden : true},
						   {name:'orderDetailId',index:'orderDetailId', width:5,editable:true,hidden : true},
						   {name : "workOrderNo",index : "workOrderNo",width : 20,editable : true,hidden : true}, 
						   {name : 'size',index : 'size',width : 50,editable : false},
						   {name : 'totalQty',index : 'totalQty',width : 50,editable : false},
						   {name : 'netLength',index : 'netLength',width : 50,editable : true,
								   editoptions:{
						                  dataInit: function(element) {
						                      $(element).keyup(function(){
						                          var val1 = element.value;
						                          var num = new Number(val1);
						                          if(isNaN(num))
						                          {
						                        	  alert("Please enter valid Net Length");
						    	                     annealingValid=false;
						    	                     jQuery("#MWDWorkOrderGrid").trigger('reloadGrid');
						                        	
						                         }
						                          else
						                        	  annealingValid=true;
						                        
						                      });
						                  }
						   	      ,maxlength:8}},
						   {name : 'anealingPercent',index : 'anealingPercent',width : 40,editable : true,
							   editoptions:{
				                  dataInit: function(element) {
				                      $(element).keyup(function(){
				                          var val1 = element.value;
				                          var num = new Number(val1);
				                          if(isNaN(num))
				                          {
				                        	  alert("Please enter valid Annealing percent");//abin-1
				    	                     annealingValid=false;
				    	                     jQuery("#MWDWorkOrderGrid").trigger('reloadGrid');
				                        	
				                         }
				                          else
				                        	  annealingValid=true;
				                        
				                      });
				                  }
				   	      ,maxlength:8}}, 
						   {name : 'customerName',index : 'customerName',width : 20,editable : false,hidden:true},
						   {name : 'customerCode',index : 'customerCode',width : 50,editable : false},
						   {name : 'act',index : 'act',width : 30,viewable : false,sortable:false}

						],
						postData : {},
						rowNum : 100,
						rowList : [ 5, 10, 20, 30, 40,50,100 ],
						height : 270,
						autowidth : true,
						rownumbers : false,
						pager:'#MWDWorkOrderPager',
						sortname : 'mwdWoInputId',
						viewrecords : true,
						sortorder : "desc",
						caption : "MWD Work Order",
						emptyrecords : "Empty records",
						loadonce : false,
						footerrow: true,
						loadComplete : function() {
						},
						jsonReader : {
							root : "rows",
							page : "page",
							total : "total",
							records : "records",
							repeatitems : false,
							cell : "cell",
							id : "mwdWoInputId"
						},
						ondblClickRow : function(id) {
					    	if (id && id !== lastSelected) {
								editRow(id);
							}
						},
						gridComplete : function() {
							 var totalQty = $('#MWDWorkOrderGrid').jqGrid('getCol','totalQty',false,'sum');
		        	   		 var netLength = $('#MWDWorkOrderGrid').jqGrid('getCol','netLength',false,'sum');
		        	   		 
		        	   		var totQtyVal=Math.round(parseFloat(totalQty) * 100) / 100;
		        	   		var totalNet=Math.round(parseFloat(netLength) * 100) / 100;
		        	   		
		        	   		$('#MWDWorkOrderGrid').jqGrid('footerData','set', {ID: 'Total:', totalQty: totQtyVal});
	        	   	    	$('#MWDWorkOrderGrid').jqGrid('footerData','set', {ID: 'Total:', netLength: totalNet});
	        	   	   	
							var ids = jQuery("#MWDWorkOrderGrid").jqGrid('getDataIDs');
							for ( var i = 0; i < ids.length; i++) {
								var cl = ids[i];
								be = "<input style='height:22px; width:35px;' type='button' value='Edit'  id='editRow"+ cl	+ "' onclick=\"editRow('"+ cl+ "');\" />";
								de = "<input style='height:22px; width:30px;' type='button' value='Del'  id='delRow"+ cl+ "' onclick=\"delRow('"+ cl+ "');\" />";
								se = "<input style='height:22px; width: 29px;' type='button' value='Save' hidden='hidden'  id='saveRow"	+ cl+ "' onclick=\"saveRow('"+ cl+ "');\" />";
								ce = "<input style='height:22px;width:39px;' type='button' value='Cancel' hidden='hidden' id='restoreRow"+ cl+ "' onclick=\"restoreRow('"+ cl+ "');\" />";
								$("#MWDWorkOrderGrid").jqGrid('setRowData',	ids[i], {
											act : be + de + se + ce
										});
							}
						},
						editurl : "createMWDWorkOrder/crud"
					}).navGrid('#MWDWorkOrderPager', {view : false,	del : false,edit : false,search : false,add:false	});



$("#mwdWoNoSelect").chosen().change(function() {
	var woNo=$('#mwdWoNoSelect').val();
	$.ajax({type:'POST', 
		url: 'viewworkorder/fetchWoDetails/'+ encodeURIComponent(woNo),
		success: function(response) {
			document.getElementById('woStartDate').value=response[0]; 
            document.getElementById('woEndDate').value=response[1]; 
            document.getElementById('woMachine').value=response[3];
            document.getElementById('woStatus').value=response[4];
           if(response[4]=="Submitted"){
        	document.getElementById('saveWorkOrderExistWo').disabled=true;
       		document.getElementById('fetchWoItemsExistWo').disabled=true;
       		document.getElementById('createMwdWOBtn').disabled=true;
       		document.getElementById('submitBtn').disabled=true;
           } else{
        		document.getElementById('saveWorkOrderExistWo').disabled=false;
           		document.getElementById('fetchWoItemsExistWo').disabled=false;
           		document.getElementById('createMwdWOBtn').disabled=false;
           		document.getElementById('submitBtn').disabled=false;
              
           }
             jQuery("#MWDWorkOrderGrid").setGridParam({datatype:'json'}); 
             jQuery("#MWDWorkOrderGrid").setGridParam({  url : 'viewMWDWorkOrder/populateWODetailsGrid/' + encodeURIComponent(woNo)});
			 jQuery("#MWDWorkOrderGrid").trigger('reloadGrid');

       	 jQuery("#MWDWorkOrderGrid").setCaption('Work Order '+woNo+' Details');

	    }});
        });

});




function editRow(id) {
  	if(submitStatus==false){
	restoreRow(lastSelected);
	lastSelected = id;
	$('#MWDWorkOrderGrid').jqGrid('editRow', id, {
		"keys" : true,
		"oneditfunc" : hideActButtons,
		aftersavefunc : function(savedId, response) {

			showActButtons(savedId);
		},
		afterrestorefunc : showActButtons
	});
  	}
}

function delRow(id) {
   	if(submitStatus==false){
   	if (confirm("Are you sure you want to delete ?")) {
		var oper = "del";
		$.ajax({
			type : 'POST',
			url : 'createMWDWorkOrder/crud',
			data : {
				'id' : id,
				'oper' : oper
			},
			success : function(response) {
				jQuery("#MWDWorkOrderGrid").trigger('reloadGrid');
			}
		});

	
	;
}}}


function saveRow(id) {
	
	if(annealingValid==true){

	var WorkOrderNo = $('#mwdWorkOrderNoTag').val();
	$('#MWDWorkOrderGrid').saveRow(id, {
		aftersavefunc : function(id, response) {
			var grid = jQuery('#MWDWorkOrderGrid');
			var annealingPercent = grid.jqGrid('getCell', id, 'anealingPercent');
		    if(annealingPercent==null || annealingPercent==""){
		    	alert("Annealing Percent Cannot be empty");//abin-2
		    }
			showActButtons(id);
		},
		extraparam : {
			"WorkOrderNo" : WorkOrderNo
		}
	});
	jQuery("#MWDWorkOrderGrid").trigger('reloadGrid');
}
/*	else if(annealingValid==false){
    alert("Enter Valid Annealing percent 3");//abin-3
}*/
}

function restoreRow(id) {
	$('#MWDWorkOrderGrid').jqGrid('restoreRow', id, {
		afterrestorefunc : showActButtons
	});
}

/*
 * Hides the Edit and Del Row Buttons on jqGrid and activates the Save and
 * restore(cancel) button
 * 
 */
function hideActButtons(id) {
	$('#editRow' + id).hide();
	$('#delRow' + id).hide();
	$('#saveRow' + id).show();
	$('#restoreRow' + id).show();
}

/*
 * Shows the Edit and Del Row Buttons on jqGrid and hides the Save and
 * restore(cancel) button
 * 
 */
function showActButtons(id) {
	$('#editRow' + id).show();
	$('#delRow' + id).show();
	$('#saveRow' + id).hide();
	$('#restoreRow' + id).hide();
	lastSelected = null;

}



function showWOItems() {
	 var woNo=null;
	  if($('input:radio[name=workOrderSelect]:checked').val()==0){
		  woNo=document.getElementById('mwdWorkOrderNoTag').value;
	 }else{
	  woNo= $('#mwdWoNoSelect').val(); 
  }

	if (woNo!=null && woNo!=""){
	     jQuery("#MWDWorkOrderGrid").setGridParam({datatype:'json'}); 
		 jQuery("#MWDWorkOrderGrid").setGridParam({ url: 'createMWDWorkOrder/records/'+ encodeURIComponent(woNo)});
		 jQuery("#MWDWorkOrderGrid").setCaption('Work Order '+woNo+' Details');
		 jQuery("#MWDWorkOrderGrid").trigger('reloadGrid');
	} 
	}

function createProdWO(){
 if($('input:radio[name=workOrderSelect]:checked').val()==0){
	if (document.getElementById('mwdWorkOrderNoTag').value == "") {
		if (validatePdnWO()) {
			           $.ajax({	type : 'POST',
						url : 'createMWDWorkOrder/createProdWO',
						data : '&mwdStartDate=' + $("#mwdStartDate").val()+ 
						       '&mwdCompletionDate='+ $("#mwdCompletionDate").val()	+
						       '&mwdWoMachineNoSelect='	+ $("#mwdWoMachineNoSelect").val()+
						       '&mwdWorkOrderNoTag='+ $("#mwdWorkOrderNoTag").val(),
						success : function(response) {
							document.getElementById('mwdWorkOrderNoTag').value = response[0];
							 $('#mwdWoNoSelect').append('<option>'+response[0]+'</option>');
							 $('#mwdWoNoSelect').trigger('liszt:updated');
						
							openSalesOrdersPage();
                       }
					});
		}
	} else {
		openSalesOrdersPage();
	}}
	else{
		 var existWoNo= $('#mwdWoNoSelect').val();
		 if(existWoNo!="" && existWoNo!=null){
			 openSalesOrdersPage(existWoNo); 
		 }else{
			 alert("Select Work Order No");
		 }
	 }
}

function openSalesOrdersPage() {
	var workOrderNo ="";
	  if($('input:radio[name=workOrderSelect]:checked').val()==0){
		  workOrderNo=document.getElementById('mwdWorkOrderNoTag').value;
	  }else{
		  workOrderNo=$('#mwdWoNoSelect').val(); 
	  }

	url = 'viewSOForWO?workOrderNo=' + encodeURIComponent(workOrderNo)
			+ '&reportType=' + encodeURIComponent("MWD");
	window.open(url, '_blank');
}

function validatePdnWO() {
	if ($("#mwdStartDate").val() == "") {
		alert("Enter MWD Process Start Date ");
		return false;
	}
	if ($("#mwdCompletionDate").val() == "") {
		alert("Enter MWD Process Completion Date ");
		return false;
	} else if ($("#mwdWoMachineNoSelect").val() == "") {
		alert("Select Machine");
		return false;
	} else
		return true;
}

function createMwdWO(){
	 var validWo = false;
	 var validAddItem=false;
	 var woNo="";
	 if($('input:radio[name=workOrderSelect]:checked').val()==0){
	    woNo=document.getElementById('mwdWorkOrderNoTag').value;
	    validWo=validateWODetails();
	    if(validWo==true)
	    validAddItem=validateAddItemDetails();
	 }
	 else{
	     woNo=$('#mwdWoNoSelect').val(); 
		 validWo=validateMwdValue();
		 if(validWo==true)
		 validAddItem=validateAddItemDetails();
	 }
	 if(validWo==true &&  validAddItem==true){
	  $.ajax({
				type : 'POST',
				url : 'createMWDWorkOrder/createMWDWo',
				data : '&mwdStartDate=' + $("#mwdStartDate").val()
						+ '&mwdCompletionDate='+ $("#mwdCompletionDate").val()
						+ '&mwdWoMachineNoSelect='+ $("#mwdWoMachineNoSelect").val()
						+ '&numberOfCopperStrandsSelect=' + $("#numberOfCopperStrandsAutoSelect").val() 
          			    + '&copperDiameterSelect=' + $("#copperDiameterAutoSelect").val() 
          			    + '&productType=' + $("#productTypeAutoSelect").val() 
						+ '&netLength=' + $("#netLength").val()
						+ '&anealingPercent=' + $("#anealingPercent").val()
						+ '&mwdWorkOrderNoTag='+ woNo,
				success : function(response) {
					if(response[0]!=null && response[0]!=="" && response[0]!="undefined"){
					   document.getElementById('mwdWorkOrderNoTag').value = response[0];
					   jQuery("#MWDWorkOrderGrid").setGridParam({datatype : 'json'	});
						jQuery("#MWDWorkOrderGrid").setGridParam({url : 'createMWDWorkOrder/records/'+ encodeURIComponent(document.getElementById('mwdWorkOrderNoTag').value)});
						jQuery("#MWDWorkOrderGrid").trigger('reloadGrid');
			     	}
					}
					});
	  
	  var woNos;
	  if($('input:radio[name=workOrderSelect]:checked').val()==0){
		  woNos=document.getElementById('mwdWorkOrderNoTag').value;
	  }else{
		  woNos=$('#mwdWoNoSelect').val(); 
	  }
        if(woNos!=null && woNos!="" && woNos!="undefined"){
        jQuery("#MWDWorkOrderGrid").setGridParam({datatype : 'json'	});
		jQuery("#MWDWorkOrderGrid").setGridParam({url : 'createMWDWorkOrder/records/'+ encodeURIComponent(woNos)});
		jQuery("#MWDWorkOrderGrid").trigger('reloadGrid');
        }

	 }
	}

function validateAddItemDetails(){
	var  patroon = /^[+]?([0-9]+(?:[\.][0-9]*)?|\.[0-9]+)$/;
	var length=document.getElementById('netLength').value;
	var annealing=document.getElementById('anealingPercent').value;
	
	if($("#numberOfCopperStrandsAutoSelect").val()==""){
		alert("Select number of Cu strand");
		return false;
	}
	else if($("#copperDiameterAutoSelect").val()==""){
		alert("Select Cu Strand Diameter");
		return false;
	}
	else if($("#productTypeAutoSelect").val()==""){
		alert("Select Product Type");
		return false;
	}

	else if ($("#netLength").val() == "") {
		alert("Enter Net Length");
		return false;
	} 
	else if ($("#anealingPercent").val() == "") {
		alert("Annealing Percent cannot be empty");
		return false;
	}
	if(!patroon.test(length)|| length==0 ){
		 alert("Enter valid Length");
		 document.getElementById('netLength').value="";
		 return false;
	 }
	if(!patroon.test(annealing)|| annealing==0 ){
		 alert("Enter valid Annealing Percent");//-abin-4
		 document.getElementById('anealingPercent').value="";
		 return false;
	 }
	if (isNaN(document.getElementById('netLength').value)) {
		alert("Net Length Should be Numeric");
		document.getElementById('netLength').value = "";
		return false;
	}
	if (isNaN(document.getElementById('anealingPercent').value)) {
		alert("Annealing Percent Should be Numeric");
		document.getElementById('anealingPercent').value = "";
		return false;
	}

	else
		return true;

}


function validateWODetails() {
	
	if ($("#mwdStartDate").val() == "") {
		alert("Enter MWD process start date ");
		return false;
	}

	else if ($("#mwdWoMachineNoSelect").val() == "") {
		alert("Select Machine");
		return false;
	} 
	else return true;
}


function validateMwdValue(){
	 var mwdWoNo= $('#mwdWoNoSelect').val(); 
	 if(mwdWoNo!=null && mwdWoNo!="")
		 return true;
	 else{
		 alert("Select MWD Work order No");
		 return false;
	 }
}

function resetValues() {
	  if($('input:radio[name=workOrderSelect]:checked').val()==0){
	   document.getElementById('mwdWorkOrderNoTag').value = "";
		document.getElementById('mwdStartDate').value = "";
		document.getElementById('mwdCompletionDate').value = "";
		document.getElementById('mwdWoMachineNoSelect').value = "";
		$('#mwdWoMachineNoSelect').trigger('liszt:updated');
		
		document.getElementById('numberOfCopperStrandsAutoSelect').value ="";
		//$('#numberOfCopperStrandsSelect').trigger('liszt:updated');
		
		document.getElementById('copperDiameterAutoSelect').value ="";
		//$('#copperDiameterSelect').trigger('liszt:updated');
		
		document.getElementById('productTypeAutoSelect').value ="";
		//$('#productTypeSelect').trigger('liszt:updated');

		document.getElementById('netLength').value = "";
	   document.getElementById('anealingPercent').value = "";
	   
		document.getElementById('mwdStartDate').disabled = false;
		document.getElementById('mwdCompletionDate').disabled = false;
		document.getElementById('mwdWoMachineNoSelect').disabled = false;
		document.getElementById('numberOfCopperStrandsAutoSelect').disabled = false;
		document.getElementById('copperDiameterAutoSelect').disabled = false;
		document.getElementById('productTypeAutoSelect').disabled = false;
	
		document.getElementById('netLength').disabled = false;
		document.getElementById('anealingPercent').disabled = false;


	   	document.getElementById('selectSOId').disabled=false;
   		document.getElementById('showWOId').disabled=false;
   	    
	  }
		document.getElementById('createMwdWOBtn').disabled=false;
   		document.getElementById('submitBtn').disabled=false;
	   jQuery("#MWDWorkOrderGrid").jqGrid("clearGridData", true);
}




function submit() {
	 var woNo=null;
	  if($('input:radio[name=workOrderSelect]:checked').val()==0){
		  woNo=document.getElementById('mwdWorkOrderNoTag').value;
	 }else{
	  woNo= $('#mwdWoNoSelect').val(); 
   }

	 if(woNo=="" || woNo==null){
		 if($('input:radio[name=workOrderSelect]:checked').val()==0)
			 alert("No Work Order Is Created.");
		 else
			 alert("Select work order No");
		 submitStatus=false;
	 }
    else if($("#MWDWorkOrderGrid").getGridParam("reccount")==0) {
		alert("No Work Order Items added.");
		 submitStatus=false;
	}else {
		if (confirm("Are You Sure You Want To Submit?")) {
			 $.ajax({
					type:'POST',
					url: 'createMWDWorkOrder/pendingWorkOrder/'+encodeURIComponent(woNo),
					success: function(response) {
			alert("Work Order "+ woNo+ " Is Submitted.");
			  if($('input:radio[name=workOrderSelect]:checked').val()==0){
					document.getElementById('mwdStartDate').disabled = true;
					document.getElementById('mwdCompletionDate').disabled = true;
					document.getElementById('selectSOId').disabled = true;
					document.getElementById('showWOId').disabled = true;
					document.getElementById('netLength').disabled = true;
					document.getElementById('anealingPercent').disabled = true;
				  }else{
					 	document.getElementById('saveWorkOrderExistWo').disabled=true;
			       		document.getElementById('fetchWoItemsExistWo').disabled=true;
					  
				  }
				document.getElementById('createMwdWOBtn').disabled = true;
				document.getElementById('submitBtn').disabled = true;
		       	    submitStatus=true;
            }});
		}else  submitStatus=false;
	}

}

$(document).keypress(function(e) {
	if (e.which == 13) {
		var ids = $("#MWDWorkOrderGrid").jqGrid('getDataIDs');
		for ( var i = 0; i < ids.length; i++) {
			var cl = ids[i];
			var grid = jQuery('#MWDWorkOrderGrid');
			var annealingPercent = grid.jqGrid('getCell',cl, 'anealingPercent');
		  if(annealingPercent=="")
			annealingValid=false;
		  else
			  annealingValid=true;

			saveRow(cl);
		}
	
		jQuery("#MWDWorkOrderGrid").trigger('reloadGrid');
	}
});

function workOrderReport(){
	 var woNo=null;
	  if($('input:radio[name=workOrderSelect]:checked').val()==0){
		  woNo=document.getElementById('mwdWorkOrderNoTag').value;
	 }else{
	  woNo= $('#mwdWoNoSelect').val(); 
  }
	  if(woNo!=null && woNo!="")
	location.href='createMWDWorkOrder/mwdWorkOrderReport?workOrderNo='+woNo;
	  else
		 alert("Work Order Number required for report");
}




function productTypeSelectOnChange(productType){
	document.getElementById('numberOfCopperStrandsAutoSelect').value="";
	document.getElementById('copperDiameterAutoSelect').value="";
	document.getElementById('cuWeight').value="";
	$.ajax({
		url: 'createBunchingWorkOrder/fetchCuStrands',
		data:{"productType":productType},
		success: function(response) {
			noOfCuStarndArray=response;
			$("#numberOfCopperStrandsAutoSelect").autocomplete({
			    source: function(request, response) {
			        var results = $.ui.autocomplete.filter(noOfCuStarndArray, request.term);
			        response(results.slice(0, 15));
			    },
			    select: function (a, b) {
			    	cuStrandsSelectOnChange(b.item.value);
			    }
			});	
	}});
}


function cuStrandsSelectOnChange(numberOfCopperStrand){
	document.getElementById('copperDiameterAutoSelect').value="";
	document.getElementById('cuWeight').value="";
	var productType=$("#productTypeAutoSelect").val();
	$.ajax({
		type:'POST',
		url: 'createBunchingWorkOrder/getCuDiamter',
		data:{"numberOfCopperStrand":numberOfCopperStrand,"productType":productType},
		success: function(response) {
	    	cuDiamArrray=response;
			$("#copperDiameterAutoSelect").autocomplete({
			    source: function(request, response) {
			        var results = $.ui.autocomplete.filter(cuDiamArrray, request.term);
			        response(results.slice(0, 15));
			    },
			    select: function (a, b) {
			    	cuDiameterSelectOnChange(b.item.value);
			    }
			});	
	}});

}
var layLength;
function cuDiameterSelectOnChange(cudiameter){
	fetchCuWeight(cudiameter);

}

function  fetchCuWeight(cudiameter){
	var productType=$("#productTypeAutoSelect").val();
	var numberOfCuStrand=$("#numberOfCopperStrandsAutoSelect").val();
	var cuDiameter=cudiameter;
	if(productType!=null && productType!="" && numberOfCuStrand!=null && numberOfCuStrand!="" 
		&& cuDiameter!=null && cuDiameter!=""){
	 $.ajax({
			type:'POST',
			url: 'createMWDWorkOrder/fetchCuWeight',
			data:{"productType":productType,"numberOfCuStrand":numberOfCuStrand,
				"cuDiameter":cuDiameter},
			success: function(response) {
				document.getElementById('cuWeight').value = response[0];
			}});
 }
}