var bundleIdUpdate=true;
var lastSelected;
var gridQtyValid=true;
var newItemCreationStatus=false;

$("#sucessPopUp").dialog({
    hide: 'slide',
    show: 'slide',
    autoOpen: false,
    height:70,
});
$(".ui-dialog-titlebar").hide();
var itemCodeArray;
$("#itemCodesSelect").focus();
$(function(){ 
    $.ajax({
        url: 'orderdetails/fetchItemCode',
        dataType: "json",
         success: function(data) {
        	 itemCodeArray=data;
        }
    });


	$("#itemCodesSelect").autocomplete({
	    source: function(request, response) {
	        var results = $.ui.autocomplete.filter(itemCodeArray, request.term);

	        response(results.slice(0, 15));
	    },
	    select: function (a, b) {
	      	itemCodeSelectOnChange(b.item.value);
	    },
	});
	 
		$("#productTypeSelect").chosen({no_results_text: "No results matched"});
		$("#cableStdPvcSelect").chosen({no_results_text: "No results matched"});
		$("#colourMainSelect").chosen({no_results_text: "No results matched"});
		$("#colorStripeSelect").chosen({no_results_text: "No results matched"});
		$("#copperDiameterSelect").chosen({no_results_text: "No results matched"});
		$("#maincolorKeySelect").chosen({no_results_text: "No results matched"});
		$("#stripecolorKeySelect").chosen({no_results_text: "No results matched"});
		$("#unitTypeSelect").chosen({no_results_text: "No results matched"});

		
	if(document.getElementById('orderStatus').value!="Pending" && document.getElementById('orderStatus').value!="Approved For Prodn" && document.getElementById('orderStatus').value!="Created" ){
	
		$('#itemCodesSelect').attr('disabled','disabled');
		$('#productTypeSelect').attr('disabled','disabled');
		$('#cableStdPvcSelect').attr('disabled','disabled');
		$('#colourMainSelect').attr('disabled','disabled');
		$('#colorStripeSelect').attr('disabled','disabled');
		$('#copperDiameterSelect').attr('disabled','disabled');
		$('#maincolorKeySelect').attr('disabled','disabled');
		$('#stripecolorKeySelect').attr('disabled','disabled');
		$('#itemCodesSelect').attr('disabled','disabled');
		$("#unitTypeSelect").attr('disabled','disabled');
	
	document.getElementById('addOrderDetailsBtn').disabled=true;
    document.getElementById('numberOfCopperStrands').disabled=true;
    document.getElementById('laylength').disabled=true;
    document.getElementById('layType').disabled=true;
    document.getElementById('outerDiameter').disabled=true;
    document.getElementById('area').disabled=true;
    document.getElementById('quantity').disabled=true;
    document.getElementById('bundleSize').disabled=true;
    document.getElementById('rate').disabled=true;
	}


	var salesNo=orderDetailsForm.orderId.value;
	
	 $("#orderDetailsGrid").jqGrid({
	   	url:'orderdetails/addedItems/'+ encodeURIComponent(salesNo),
	   	datatype: 'json', //initially set it as local once the customerId is selected it should be updated to json.
	   	//http://stackoverflow.com/questions/3219734/jqgrid-posting-extra-custom-parameters-to-server
		mtype: 'GET',
		 colNames:['OrderDetail Id','Item Code','Order No','Item Code','Item Code','Item Description','','','','','Quantity',
		           'Units','Actions', 'unithiddn','Bundle Size','Bundle size','Bal','Comp','Pdn','Wo',
		             'Dispatched','Cu Weight(Kg)','PVC Weight(Kg)','Rate(Rs.)','Rate'],
		   colModel:[
	   	         
	   	       
	              {name:'orderDetailId', index:'orderDetailId', width:10, viewable:false,hidden:true}, 
	              {name:'itemCode', index:'itemCodehid', width:10, hidden:true,editable:true} ,		   	         
	              {name:'orderId', index:'orderId', width:10, editable:true,viewable:false,hidden:true}, 
	              {name:'itemId', index:'itemId', width:40, viewable:false, editable:true,hidden:true},
	              {name:'itemCode', index:'itemCode', width:60, editable:false} ,
	              {name:'itemDescription',index:'itemDescription',width:100}, 
		          {name:'numberOfCopperStrands',index:'numberOfCopperStrands', width:10, viewable:false,hidden:true},
		          {name:'outerDiameter',index:'outerDiameter',width:5,hidden:true},
		          {name:'mainColor',index:'mainColor',width:20,hidden:true},
		          {name:'innerColor',index:'innerColor',width:20,hidden:true},
		          {name:'quantity', index:'quantity', width:20,editable:true,editoptions:{
                      dataInit: function(element) {
                    	var patMatch = /^(\.\d{1,2}|\d{1,4}\.?\d{0,2}|\d{5}\.?\d?|\d{6}\.?\d?|\d{7}\.?\d?)$/;
                          $(element).keyup(function(){
                        	  var val1 = element.value;
                        	 if(!patMatch.test(val1)) {
                        		 alert("Please enter a valid quantity");
                            	  gridQtyValid=false;  
                        	  }
                        	  else   gridQtyValid=true;
                        	  
                           });
                      }
                  }},
                  {name:'unit', index:'unit', width:10},
      	          {name:'act',index:'act', width:20,sortable:false},
		          {name:'unit', index:'unit', width:20,editable:true,hidden:true},        
		          {name:'bundleSize',name:'bundleSize',width:20,editable:false},
		          {name:'bundleSize',name:'bundleSize',width:20,editable:true,hidden:true},   
		          {name:'balanceQty',index:'balanceQty',width:10,editable:true,hidden:true},
		          {name:'completedQty',index:'completedQty',width:10,editable:true,hidden:true},
		          {name:'productionQty',index:'productionQty',width:10,editable:true,hidden:true},
		          {name:'woQty',index:'woQty',width:10,editable:true,hidden:true},
		          {name:'dispatchedQty',index:'dispatchedQty',width:10,editable:true,hidden:true},
		          {name:'weight', index:'weight', width:30,editable:false},
		          {name:'pvcWeight', index:'pvcWeight', width:30,editable:false},
		          {name:'rate', index:'rate', width:20,editable:false},
		          {name:'rate', index:'rate', width:20,editable:true,hidden:true}
		         
		        
		   	      
		 	],
	   	postData: {},
		rowNum: 100,
	   	rowList:[5,10,20,40,50,100],
	   	height:293,
	   	autowidth: true,
		rownumbers: false,
	   	pager: '#orderDetailpager',
	   	sortname: 'orderDetailId',
	    viewrecords: true,
	    sortorder: "desc",
	    emptyrecords: "Empty records",
	    loadonce: false,
	    footerrow : true,
	    loadComplete: function() {},
	    jsonReader : {
	        root: "rows",
	        page: "page",
	        total: "total",
	        records: "records",
	        repeatitems: false,
	        cell: "cell",
	        id: "orderDetailId"
	    },
	    ondblClickRow : function(id) {
			if (id && id !== lastSelected) {
				$('#orderDetailsGrid').jqGrid('restoreRow',lastSelected);
				editRow(id);
				lastSelected = id;
			}
		},
		gridComplete : function() {

			var quantity = $('#orderDetailsGrid').jqGrid('getCol','quantity', false, 'sum');
			var totalQty = Math.round(parseFloat(quantity) * 100) / 100;
			$('#orderDetailsGrid').jqGrid('footerData', 'set', {ID : 'Total:',quantity : totalQty});

			
			
			
			var ids = jQuery("#orderDetailsGrid").jqGrid('getDataIDs');
			for ( var i = 0; i < ids.length; i++) {
				var cl = ids[i];
				be = "<input style='height:22px; width:35px;' type='button' value='Edit' id='editRow"+cl+"' onclick=\"editRow('"+ cl + "');\" />";
				de = "<input style='height:22px; width:30px;' type='button' value='Del' id='delRow"+cl+"' onclick=\"delRow('"+ cl + "');\" />";
				se = "<input style='height:22px; width: 29px;' type='button' value='Save' hidden='hidden' id='saveRow"+cl+"' onclick=\"saveRow('"+ cl + "');\" />";
				ce = "<input style='height:22px;width:39px;' type='button' value='Cancel' hidden='hidden'  id='restoreRow"+cl+"' onclick=\"restoreRow('"+ cl + "');\" />";
				$("#orderDetailsGrid").jqGrid('setRowData', ids[i],
						{
							act : be + de + se + ce
						
						});
			}
		},
		
	editurl : "orderdetails/editFunc"
	
});
	
	 jQuery("#orderDetailsGrid").jqGrid('navGrid','#orderDetailpager',{view:false, del:false,add:false, edit:false, search:false});

/*	 $("#orderDetailsGrid").jqGrid('navButtonAdd','#orderDetailpager', {
		    caption:"Import from Excel", 
		    onClickButton : function () {
		 	 alert("Import from Excel");
			    $.ajax({
			        type: 'GET',
			        url: 'orderdetails/import',
			        success: function(response) {
			        	
			        	//if(response!=null){
			            
			            jQuery("#orderDetailsGrid").setGridParam({datatype:'json'}); 
						jQuery("#orderDetailsGrid").setGridParam({ url : 'orderdetails/import'});
						jQuery("#orderDetailsGrid").setGridParam({ editurl : 'orderdetails/crud'});
						jQuery("#orderDetailsGrid").trigger('reloadGrid');
			      //  }
			        },
			        error: function(response) {
			        
			        }
			    });
			} 

		});*/
/*			
		$("#orderDetailsGrid").jqGrid('navButtonAdd','#orderDetailpager', {
		    caption:"Export to Excel", 
		    onClickButton : function () {
		 	 
			    var gridData = jQuery("#orderDetailsGrid").getRowData();
			    var postData = JSON.stringify(gridData);
			   	alert("Hello2");
			    //DownloadJSON2CSV(gridData);
			    alert("JSON serialized jqGrid data:\n" + postData);
			    $.ajax({
			        type: 'POST',
			        url: 'orderdetails/export',
			        data : {
			            jgGridData: postData,
			            customData: 'bla bla'
			        },
			        success: function(response) {
			            
			        },
			        error: function(response) {
			            
			        }
			    });
			} 

		});   */ 

 
$('#addOrderDetailsBtn').click(function() {
    if(newItemCreationStatus==true){
			  /* if (confirm("New Item! Do you want to add this new Item ")){
				 	$.ajax({type:'POST', url: 'items/confirmNewItemId', data:$('#orderDetailsForm').serialize(), success: function(response) {
			   		alert("New Item  "+response[0]+"  is created");
			   		newItemCreationStatus=false;
			   		//$('#itemIdSelect').append('<option selected="selected">'+response[0]+'</option>');
			   		//$('#itemIdSelect').trigger('liszt:updated');
			   		
			   		document.getElementById('itemCodesSelect').value=response[0];
			   		
			   		if(response[1]!=null)
			   			document.getElementById('rate').value=response[2];
			   		if(response[2]!=null)
			   			document.getElementById('bundleSize').value=response[3];
			   		document.getElementById('area').value=response[1];
			   //	 $.ajax({type:'POST', url: 'orderdetails/create',dataType: "json", data:$('#orderDetailsForm').serialize(), success: function(response) {
			   // $('#orderDetailsGrid').trigger("reloadGrid");
				// }// ajax 
			//	}//
			// 	);
				
				   }// ajax in else
			   	}//
			   	);
			}// end of if confirm
			   */
    	alert("New Item combination!!! Doesnt exist in Item Master");
	    }
	

    else{
		var orderStatus=document.getElementById('orderStatus').value;
		if(orderStatus=="Pending" || orderStatus=="Approved For Prodn" || orderStatus=="Created"){
		var validateResult=validationForItemParameter();
		if(validateResult==true){
		var salesOrderNo=orderDetailsForm.orderId.value;
		var itemCodeSelected=document.getElementById('itemCodesSelect').value;
		if(itemCodeSelected!=""){
		$.ajax({type:'POST', 
			url: 'orderdetails/create',
           dataType: "json", 
           data:$('#orderDetailsForm').serialize(),
           success: function(response) {
			
			if(response=="exist"){
                 alert("Added Item already exist for sales order");
              //  $("#sucessPopUp").dialog('open').html("<p>Added Item already exist for sales order</p>");
                //  $("#sucessPopUp").dialog('close');
                  document.getElementById('itemCodesSelect').value=""; 
                  $("#itemCodesSelect").focus();
			}
            else{
            	jQuery("#orderDetailsGrid").trigger('reloadGrid');
                $("#sucessPopUp").dialog('open').html("<p>Item added for sales order</p>");
              //  $("#sucessPopUp").dialog('close');
                    	

                setTimeout( function () { 
                        window.parent.$('#sucessPopUp').dialog('close'); 
                    }, 1000) ;// milliseconds delay
               document.getElementById('itemCodesSelect').value=""; 
                $("#itemCodesSelect").focus(); 
            }
         	}});
		}
	      jQuery("#orderDetailsGrid").setGridParam({datatype:'json'}); 
          jQuery("#orderDetailsGrid").setGridParam({ url: 'orderdetails/addedItems/'+ encodeURIComponent(salesOrderNo)});
           jQuery("#orderDetailsGrid").trigger('reloadGrid');
          document.getElementById('itemCodesSelect').value=""; 
           $("#itemCodesSelect").focus();
	    }// if loop of validation
	}
	else{
			alert(orderDetailsForm.orderId.value+" is in "+orderStatus+" status");
			
			document.getElementById('itemCodesSelect').value ="";
			document.getElementById('productTypeSelect').value ="";
			$('#productTypeSelect').trigger('liszt:updated');
			document.getElementById('cableStdPvcSelect').value = "";
			$('#cableStdPvcSelect').trigger('liszt:updated');
			document.getElementById('copperDiameterSelect').value ="";
			$('#copperDiameterSelect').trigger('liszt:updated');
			document.getElementById('colourMainSelect').value ="";
			$('#colourMainSelect').trigger('liszt:updated');
			document.getElementById('colorStripeSelect').value = "";
			$('#colorStripeSelect').trigger('liszt:updated');
			document.getElementById('colorStripeSelect').value = "";
			$('#colorStripeSelect').trigger('liszt:updated');
			document.getElementById('maincolorKeySelect').value = "";
			$('#maincolorKeySelect').trigger('liszt:updated');
			document.getElementById('stripecolorKeySelect').value = "";
			$('#stripecolorKeySelect').trigger('liszt:updated');
			document.getElementById('unitTypeSelect').value = "";
			$('#unitTypeSelect').trigger('liszt:updated');
			document.getElementById('numberOfCopperStrands').value ="";
			document.getElementById('laylength').value = "";
			document.getElementById('layType').value = "";
			document.getElementById('outerDiameter').value = "";
			document.getElementById('area').value = "";
			document.getElementById('CuWeight').value = "";
		}
}
	});

}); 


function validationForItemParameter(){
	if(document.getElementById('productTypeSelect').value==""){
		alert("Select Product Type");
	    return false;
	}
	
	 if(document.getElementById('cableStdPvcSelect').value==""){
		alert("Select Cable Std Type");	
		return false;
	}
    if(document.getElementById('copperDiameterSelect').value==""){
    	alert("Select Copper Diameter");
    	return false;
    }
    		
    if(document.getElementById('colourMainSelect').value==""){
    	alert("Select Main Color");
    	return false;
    }
    	
    if(document.getElementById('colorStripeSelect').value==""){
    	alert("Select Stripe Color");
    	return false;
    }
   if(document.getElementById('unitTypeSelect').value==""){
 	alert("Select Unit");
  	return false;
  }
    	
    if(document.getElementById('numberOfCopperStrands').value==""){
    	alert("Enter No of Cu Strands");
    	return false;
    }
    	
    if(document.getElementById('laylength').value ==""){
    	alert("Enter Lay Length");
    	return false;
    }	
    if(document.getElementById('outerDiameter').value ==""){
    	alert("Enter Outer Diameter");
    	return false;
    }
    if(document.getElementById('bundleSize').value ==""){
    	alert("Enter Bundle Size");
    	return false;
    }
    if(document.getElementById('quantity').value ==""){
    	alert("Enter Quantity");
    	return false;
    }
    if(document.getElementById('area').value ==""){
    	alert("Enter Area");
    	return false;
    }
    else 
    	return true;
}
   




$('#submitSoItems').click(function(){
	var itemGridCount=jQuery("#orderDetailsGrid").getGridParam("reccount");
	if(itemGridCount>0){
	if(confirm("Do you want to Submit the Items?")){
	
		var orderId=orderDetailsForm.orderId.value;;
		
			$.ajax({type:'POST',
				url: 'orders/submitSoItems/'+ encodeURIComponent(orderId), 
				success: function(response) {
					alert("Sales Order "+orderId+" with Item submitted");
					window.close();
				}});
		
	}
	}else alert("Add Items and submit for aproval");
});

function closeFn()
{
	 window.close();
}

function itemCodeSelectOnChange(itemCodes){
	var itemCode = itemCodes;
	newItemCreationStatus=false;
	var custName=document.getElementById('custName').value;
	$.ajax(
			{
		    	 url: 'items/fetchItem',
			     contentType: "application/json; charset=utf-8",
			     dataType: "json",
				 data:{"itemCode":itemCode},
				 success: function(response) {
						
					document.getElementById('productTypeSelect').value = response[0];
					$('#productTypeSelect').trigger('liszt:updated');
					document.getElementById('cableStdPvcSelect').value = response[1];
					$('#cableStdPvcSelect').trigger('liszt:updated');
					document.getElementById('copperDiameterSelect').value = response[2];
					$('#copperDiameterSelect').trigger('liszt:updated');
					document.getElementById('colourMainSelect').value = response[3];
					$('#colourMainSelect').trigger('liszt:updated');
					document.getElementById('colorStripeSelect').value = response[4];
					$('#colorStripeSelect').trigger('liszt:updated');
					document.getElementById('numberOfCopperStrands').value = response[5];
					document.getElementById('laylength').value = response[6];
					document.getElementById('layType').value = response[7];
					document.getElementById('outerDiameter').value = response[8];
					if(response[9]=="" || response[9]==null){
						  document.getElementById('area').disabled=false;
						  document.getElementById('area').editable=true;
						
					}else{
					document.getElementById('area').value = response[9];
					  document.getElementById('area').readonly=true;
					}  
					  
					  
					document.getElementById('maincolorKeySelect').value = response[3];
					$('#maincolorKeySelect').trigger('liszt:updated');
					document.getElementById('stripecolorKeySelect').value =response[4];
					$('#stripecolorKeySelect').trigger('liszt:updated');
					document.getElementById('unitTypeSelect').value = response[12];    
					$('#unitTypeSelect').trigger('liszt:updated');
				
					$.ajax({	url: 'orderdetails/fetchRate',
							     dataType: "json",
								 data:'itemCode=' + itemCode + 
							     '&custName=' + custName, 
								success: function(response) {
									if(response[0]!=null)
									document.getElementById('rate').value = response[0];
									else
									document.getElementById('rate').value = "";	
									if(response==null)
									document.getElementById('rate').value = "";		
									if(response[1]!=null)
									document.getElementById('bundleSize').value = response[1];
									else
									document.getElementById('bundleSize').value = "";			
								}});	
					document.getElementById('CuWeight').value = response[13];
		          
				 }
			}
			);
}



$("#unitTypeSelect").chosen().change( function() {
	clearItemSelect();
	updateItemCodeChosen();
});
	
$("#productTypeSelect").chosen().change( function() {
	clearItemSelect();
	updateItemCodeChosen();
});
$("#cableStdPvcSelect").chosen().change( function() {
	clearItemSelect();
	updateItemCodeChosen();
});
$("#copperDiameterSelect").chosen().change( function() {
	clearItemSelect();
	updateItemCodeChosen();
});
$("#colourMainSelect").chosen().change( function() {
	clearItemSelect();
	var mainColor=document.getElementById('colourMainSelect').value;
	document.getElementById('maincolorKeySelect').value = mainColor;
	$('#maincolorKeySelect').trigger('liszt:updated');
	updateItemCodeChosen();
	
});
$("#colorStripeSelect").chosen().change( function() {
	clearItemSelect();
	var innerColor=document.getElementById('colorStripeSelect').value;
	document.getElementById('stripecolorKeySelect').value = innerColor;
	$('#stripecolorKeySelect').trigger('liszt:updated');
	updateItemCodeChosen();
});
$("#numberOfCopperStrands").change(function(){
	var validCuStrand=false;
	var cuStrand=document.getElementById('numberOfCopperStrands').value;
	validCuStrand=validateCuStrand(cuStrand);
	if(validCuStrand==true){
	clearItemSelect();
	updateItemCodeChosen();
	}
});
$("#laylength").change(function(){
	var validLayLength=false;
	var layLength=document.getElementById('laylength').value;
	validLayLength=validateLayLength(layLength);
	if(validLayLength==true){
	clearItemSelect();
	updateItemCodeChosen();
	}
});
$("#layType").change(function(){
	var validLayType=false;
	var layType=document.getElementById('layType').value;
	validLayType=validateLayType(layType);
	if(validLayType==true){
	clearItemSelect();
	updateItemCodeChosen();
	}
});
$("#outerDiameter").change(function(){
	var validOd=false;
	var od=document.getElementById('outerDiameter').value;
	validOd=validateOd(od);
	if(validOd==true){
	clearItemSelect();
	updateItemCodeChosen();
	}
});
$("#area").change(function(){
	var validArea=false;
	var areaVal=document.getElementById('area').value;
	validArea=validateArea(areaVal);
	if(validArea==true){
	clearItemSelect();
	updateItemCodeChosen();
	}
});

$("#maincolorKeySelect").chosen().change( function() {
	clearItemSelect();
	var mainColor=document.getElementById('maincolorKeySelect').value;
    document.getElementById('colourMainSelect').value = mainColor;
	$('#colourMainSelect').trigger('liszt:updated');
	updateItemCodeChosen();

});
$("#stripecolorKeySelect").chosen().change( function() {
	clearItemSelect();
	var innerColor=document.getElementById('stripecolorKeySelect').value;
    document.getElementById('colorStripeSelect').value = innerColor;
	$('#colorStripeSelect').trigger('liszt:updated');
	updateItemCodeChosen();

});

function clearItemSelect(){
	//document.getElementById('itemIdSelect').value ="";
	//$('#itemIdSelect').trigger('liszt:updated');
	document.getElementById('itemCodesSelect').value ="";
}

function updateItemCodeChosen(){
	if(document.getElementById('stripecolorKeySelect').value!="" &&
			   document.getElementById('productTypeSelect').value!="" &&
			   document.getElementById('cableStdPvcSelect').value!="" &&
			   document.getElementById('copperDiameterSelect').value!="" &&
			   document.getElementById('maincolorKeySelect').value!="" &&
			   document.getElementById('numberOfCopperStrands').value!="" &&
			   document.getElementById('laylength').value!="" &&
			   document.getElementById('layType').value!="" &&
			   document.getElementById('outerDiameter').value!="" ){
					$.ajax({type:'POST', url: 'items/newItemId', 
						data:$('#orderDetailsForm').serialize(), 
						success: function(response) {
					if(response.length>0){
						document.getElementById('itemCodesSelect').value = response[1];
						//$('#itemIdSelect').trigger('liszt:updated');
						if(response[2]!=null){
						document.getElementById('unitTypeSelect').value = response[2];
						$('#unitTypeSelect').trigger('liszt:updated');
						}
						if(response[3]!=null && response[4]!=""){
							document.getElementById('area').value=response[4];
						}else{
							  document.getElementById('area').disabled=false;
							  document.getElementById('area').editable=true;
							  document.getElementById('area').readonly=false;
						}
							
				 		if(response[5]!=null)
				   			document.getElementById('rate').value=response[5];
				   		if(response[6]!=null)
				   			document.getElementById('bundleSize').value=response[6];
				   		newItemCreationStatus=false;
					   }//
					   else{

						   newItemCreationStatus=true;
							  document.getElementById('area').disabled=false;
							  document.getElementById('area').editable=true;

/*
						   if (confirm("New Item! Do you want to add this new Item ")){
							 	$.ajax({type:'POST', url: 'items/confirmNewItemId', data:$('#orderDetailsForm').serialize(), success: function(response) {
							   		alert("New Item  "+response[0]+"  is created");
							   		$('#itemIdSelect').append('<option selected="selected">'+response[0]+'</option>');
							   		$('#itemIdSelect').trigger('liszt:updated');
							   		if(response[1]!=null)
							   			document.getElementById('rate').value=response[2];
							   		if(response[2]!=null)
							   			document.getElementById('bundleSize').value=response[3];
							   		document.getElementById('area').value=response[1];
								
								   }// ajax in else
							   	}//
							   	);
							}// end of if confirm
*/
						  }	  
					      }//outer ajax
						});	
				}
}

/* function validateUnitArea(){
	if(document.getElementById('unitTypeSelect').value==""){
		alert("Select unit type");
		return false;
	 }
	else if(document.getElementById('unitTypeSelect').value!=""){
		  if (confirm("Are you sure you have updated units for new Item? ")){
			  return true;
		  }
		  else{
			  return false;
		  }
	}
	else
		return true;
 }*/




function editRow(id) {
	var salesOrderNo=orderDetailsForm.orderId.value;
	var orderStatus=document.getElementById('orderStatus').value;
	  if(orderStatus=="Pending" || orderStatus=="Approved For Prodn" || orderStatus=="Created"){
 	restoreRow(lastSelected);
	lastSelected = id;
	$('#orderDetailsGrid').jqGrid('editRow',id, 
			{
				"keys" :true, 
				"oneditfunc" : hideActButtons,
				aftersavefunc : function(savedId, response) {
				showActButtons(savedId);
				},
				afterrestorefunc : showActButtons
			});
	
	}
	else{
		alert(salesOrderNo+" is in  "+orderStatus+" Status");
		
	}
}

function delRow(id) {
	  var orderStatus=document.getElementById('orderStatus').value;
	  if(orderStatus=="Pending" || orderStatus=="Approved For Prodn" || orderStatus=="Created"){
	    if(confirm("Are you sure you want to delete the order?")){
	      $.ajax({type:'POST', 
	        url: 'workorder/checkStatus/'+ encodeURIComponent(id),
	        success: function(response) {
	        if(response=="exist"){
	          alert("SO Item sent to Wo level");
	        }
	        else{
	          $.ajax({type:'POST', 
	            url: 'orderdetails/delete/'+ encodeURIComponent(id),
	            success: function(response) {
	           
	              var soNo=orderDetailsForm.orderId.value;
	                 jQuery("#orderDetailsGrid").setGridParam({datatype:'json'}); 
	                 jQuery("#orderDetailsGrid").setGridParam({ url: 'orderdetails/addedItems/'+ encodeURIComponent(soNo)});
	                  jQuery("#orderDetailsGrid").trigger('reloadGrid');
	             
	            }
	          });
	        }
	      
	      }});
	    }
	   
	  }
	} 


function saveRow(id) {
	if (gridQtyValid==true){	
	$('#orderDetailsGrid').saveRow(id,
	{	aftersavefunc : function(id, response) {
				showActButtons(id);
			}
	});
	 jQuery("#orderDetailsGrid").trigger('reloadGrid');
}
	else{
		alert("Enter valid quantity");
	}
}

function restoreRow(id) {
	$('#orderDetailsGrid').jqGrid('restoreRow',id,
			{
				afterrestorefunc : showActButtons
			});
}

/*
 * Hides the Edit and Del Row Buttons on jqGrid
 * and activates the Save and restore(cancel) button
 * 
 */
function hideActButtons(id){
	$('#editRow' + id).hide();
	$('#delRow' + id).hide();
	$('#saveRow' + id).show();
	$('#restoreRow' + id).show();
	
}

/*
 * Shows the Edit and Del Row Buttons on jqGrid
 * and hides the Save and restore(cancel) button
 * 
 */
function showActButtons(id) {
	$('#editRow' + id).show();
	$('#delRow' + id).show();
	$('#saveRow' + id).hide();
	$('#restoreRow' + id).hide();
	lastSelected = null;
}



$('input[name=rate]').change(function(){
	var soNo=orderDetailsForm.orderId.value;
	var customerName=orderDetailsForm.custName.value;
	var itemCode=document.getElementById('itemCodesSelect').value;
	var rate=document.getElementById('rate').value;
	 var  patroon = /^[+]?([0-9]+(?:[\.][0-9]*)?|\.[0-9]+)$/;
	 var rateValid=true;
		if(rate!=null && rate!=""){
			if(!patroon.test(rate)){
				alert("Enter valid rate value");
				rateValid=false;
				document.getElementById('rate').value=""; 
				document.getElementById('rate').focus();
				}
		}
	
	if(rateValid==true)	{
    if(confirm("Are you sure you want to update Rate?")){
			$.ajax({type:'POST',
				
				url: 'orderdetails/updateAssortedRate', 
				data:{'customerName':customerName,'itemCode':itemCode,'rate':rate},
				success: function(response) {
					if(response[0]!=null)
						document.getElementById('rate').value = response[0];
				    jQuery("#orderDetailsGrid").setGridParam({datatype:'json'}); 
	                 jQuery("#orderDetailsGrid").setGridParam({ url: 'orderdetails/addedItems/'+ encodeURIComponent(soNo)});
	                  jQuery("#orderDetailsGrid").trigger('reloadGrid');
	    
						}});
       }
    else{
    	document.getElementById('rate').value="";
    }}
	
});
$('input[name=bundleSize]').change(function(){
	var soNo=orderDetailsForm.orderId.value;
	var quantityValue=document.getElementById('quantity').value;
	var bundleValue=document.getElementById('bundleSize').value;
	 var  patroon = /^[1-9]\d*$/;
	var bundleSizeQtyValid=true;
	if(bundleValue!=null && bundleValue!=""){
		if(!patroon.test(bundleValue) || bundleValue==0){
			alert("Enter valid bundle size value");
			document.getElementById('bundleSize').value=""; 
			document.getElementById('bundleSize').focus();
			bundleSizeQtyValid=false;
			bundleIdUpdate=false;
			}
		else
			bundleIdUpdate=true;
	}
	if(quantityValue==null || quantityValue==""){
      bundleSizeQtyValid=true;
	}

	else{
	  bundleSizeQtyValid=bundleSizeQtyValidation();
	}
	if(bundleSizeQtyValid==true && bundleIdUpdate==true){
	var customerName=orderDetailsForm.custName.value;
	var itemCode=document.getElementById('itemCodesSelect').value;
	var bundleSize=document.getElementById('bundleSize').value;
    if(confirm("Are you sure you want to update Bundle Size?")){
			$.ajax({type:'POST',
				url: 'orderdetails/updateBundleSize', 
				data:{'customerName':customerName,'itemCode':itemCode,'bundleSize':bundleSize},
				success: function(response) {
					if(response[0]!=null)
						document.getElementById('bundleSize').value = response[0];
				    jQuery("#orderDetailsGrid").setGridParam({datatype:'json'}); 
	                 jQuery("#orderDetailsGrid").setGridParam({ url: 'orderdetails/addedItems/'+ encodeURIComponent(soNo)});
	                  jQuery("#orderDetailsGrid").trigger('reloadGrid');
	    		}});
     }
    else{
    	document.getElementById('bundleSize').value="";
    }
	}
	else{
		document.getElementById('bundleSize').value="";
		document.getElementById('bundleSize').focus();
		}
});


$('input[name=quantity]').change(function(){
	var bundleValue=document.getElementById('bundleSize').value;
	var quantityValue=document.getElementById('quantity').value;
	var patroon = /^(\.\d{1,2}|\d{1,4}\.?\d{0,2}|\d{5}\.?\d?|\d{6}\.?\d?|\d{7}\.?\d?)$/;
	var bundleSizeQtyValid=true;
	if(quantityValue!=null &&  quantityValue!=""){
			if(!patroon.test(quantityValue) || quantityValue==0 ){
				alert("Enter valid quantity value");
				document.getElementById('quantity').value=""; 
				document.getElementById('quantity').focus();
			}
	  }
	if(bundleValue==null || bundleValue==""){
 	 bundleSizeQtyValid=true;
	}

	else{
	  bundleSizeQtyValid=bundleSizeQtyValidation();
	}
	if(bundleSizeQtyValid==false){
    	  document.getElementById('quantity').value="";
		  document.getElementById('quantity').focus();
    }
	
		});



function bundleSizeQtyValidation(){
	
		return true;

};



$(document).keypress(function(e) {
    if(e.which == 13) {
    	var ids = $("#orderDetailsGrid").jqGrid('getDataIDs');
    	for ( var i = 0; i < ids.length; i++) {
			var cl = ids[i];
			saveRow(cl);
       	} }});

function validateCuStrand(cuStrand){
	var  pattern = /^(\d)*\d*$/;
			if(!pattern.test(cuStrand) || parseInt(cuStrand)>9999 ){
				alert("Enter valid No of Strands(0-9999)");
				document.getElementById('numberOfCopperStrands').value=""; 
				document.getElementById('numberOfCopperStrands').focus();
				return false;
			}
			else
				return true;
}
function validateLayLength(layLength){
    var  pattern =/^(\d)*\d*$/;
		if(!pattern.test(layLength) || parseInt(layLength)>99){
			alert("Enter valid Lay Length(0-99)");
			document.getElementById('laylength').value=""; 
			document.getElementById('laylength').focus();
			return false;
		}
		else
			return true;
}

function validateArea(areaVal){
	 var  pattern = /^[+]?([0-9]+(?:[\.][0-9]*)?|\.[0-9]+)$/;
		if(!pattern.test(areaVal)){
			alert("Enter valid Area");
			document.getElementById('area').value=""; 
			document.getElementById('area').focus();
		}
}

function validateLayType(layType){
	 var  pattern = /^[A-Z]{1}$/;
		if(!pattern.test(layType)){
			alert("Enter valid Lay Type(Caps A-Z)");
			document.getElementById('layType').value=""; 
			document.getElementById('layType').focus();
			return false;
		}
		else return true;
}

function validateOd(od){
	 var  pattern = /^[+]?([0-9]+(?:[\.][0-9]*)?|\.[0-9]+)$/;
		if(!pattern.test(od) || !(parseFloat(od)>0) || !(parseFloat(od)<100)){
			alert("Enter valid outer diameter");
			document.getElementById('outerDiameter').value=""; 
			document.getElementById('outerDiameter').focus();
			return false;
		}
		else return true;
}