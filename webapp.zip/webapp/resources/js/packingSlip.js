var lastSelected;
var systemDate = new Date();
var month="";
var year="";
$("#customerSelect").chosen({no_results_text : "No results matched"});
$("#deliveryChallanNoSelect").chosen({no_results_text : "No results matched"});
$("#monthYearPicker").focus(function () {$(".ui-datepicker-calendar").hide();});
$('#monthYearPicker').datepicker({
    changeYear: true,
    changeMonth: true,
    changeDate :false,
    showButtonPanel: true,
    dateFormat: 'MM yy',
    onClose: function(dateText, inst) { 
        year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
        month = $("#ui-datepicker-div .ui-datepicker-month :selected").val();
        $(this).datepicker('setDate', new Date(year,month, 1));
        changeWoOnMonthYear();
    }
});
$('#monthYearPicker').datepicker('setDate',systemDate); 
$("#monthYearPicker").focus(function () {$(".ui-datepicker-month").show();});
$("#monthYearPicker").focus(function () {$(".ui-datepicker-year").show();});
$(function(){ 
	$("#packingSlipGrid").jqGrid({
		datatype : 'local',
		mtype:'POST',
	   	colNames:['packingSlipId','Packing Slip No','Item Type Size','No of Rolls/Reels','Rolls/Reels','Quantity per Roll/Reel', 'Total Quantity','Units', 'Weight(kg)'],
	   	colModel:[
   	         
              {name:'packingSlipId', index:'packingSlipId', width:5, viewable:false,hidden:true},     
	          {name:'packingSlipNo',index:'packingSlipNo', width:100,editable:true, editrules:{required:true}, editoptions:{size:50}},
   	          {name:'inputSize', index:'inputSize', width:130,editable : true ,viewable:false},
   	          {name:'noOfRolls',index:'noOfRolls', width:100, editable:true, editrules:{required:true}, editoptions:{size:15}},
   	           {name:'unitType', index:'unitType', width:50,editable : false },
   	          {name:'quanityPerRoll',index:'quanityPerRoll', width:150, editable:true, editrules:{required:true}, editoptions:{size:50}},
   	          {name:'totalQuantity',index:'totalQuantity', width:150,editable:true, editrules:{required:true}, editoptions:{size:50}},
   	           {name:'units', index:'units', width:50,editable : false },
   	          {name:'weight',index:'weight', width:70, editable:true, editrules:{required:true}, editoptions:{size:15}}

   	         
	   	],
	   	postData: {},
		rowNum:100,
	   	rowList:[5,10,20,40,60,100],
	   	height: 300,
	   	autowidth: true,
		rownumbers: false,
		pager: '#packingSlipPager',
	   	sortname: 'packingSlipId',
	    viewrecords: true,
	    sortorder: "desc",
	    caption:"Packing Slip Details",
	    emptyrecords: "Empty records",
	    loadonce: false,
	    footerrow : true,
	    
	    loadComplete: function() {},
	    jsonReader : {
	        root: "rows",
	        page: "page",
	        total: "total",
	        records: "records",
	        repeatitems: false,
	        cell: "cell",
	        id: "packingSlipId"
	    },
		gridComplete : function() {

			var noOfRolls = $('#packingSlipGrid').jqGrid('getCol', 'noOfRolls', false, 'sum');
			var totalNoOfRolls = Math.round(parseFloat(noOfRolls) * 100) / 100;
			$('#packingSlipGrid').jqGrid('footerData', 'set', {ID : 'Total:', noOfRolls : totalNoOfRolls});
			
			var quanityPerRoll = $('#packingSlipGrid').jqGrid('getCol', 'quanityPerRoll', false, 'sum');
			var totalQuanityPerRoll = Math.round(parseFloat(quanityPerRoll) * 100) / 100;
			$('#packingSlipGrid').jqGrid('footerData', 'set', {ID : 'Total:', quanityPerRoll : totalQuanityPerRoll});
			
			var totalQuantity = $('#packingSlipGrid').jqGrid('getCol', 'totalQuantity', false, 'sum');
			var TotalQuantity = Math.round(parseFloat(totalQuantity) * 100) / 100;
			$('#packingSlipGrid').jqGrid('footerData', 'set', {ID : 'Total:', totalQuantity : TotalQuantity});
			
			var weight = $('#packingSlipGrid').jqGrid('getCol', 'weight', false, 'sum');
			var totalweight = Math.round(parseFloat(weight) * 100) / 100;
			$('#packingSlipGrid').jqGrid('footerData', 'set', {ID : 'Total:', weight : totalweight});


		}

	});
	 jQuery("#packingSlipGrid").jqGrid('navGrid','#packingSlipPager',{view:false, del:false,add:false, edit:false, search:false});
});

function changeWoOnMonthYear(){
	
	 $('#deliveryChallanNoSelect').children().remove();
	 $('#deliveryChallanNoSelect').val('').trigger('liszt:updated');
		
		document.getElementById('customerSelect').value = "";
		$('#customerSelect').trigger('liszt:updated');
		$('#packingSlipGrid').jqGrid('clearGridData');
		jQuery("#packingSlipGrid").setCaption("Packing Slip Details");
		var validSearch=validateSearchParams();
		if(validSearch==true){
		 $.ajax({type:'POST',
			  url: 'packingSlip/fetchDeliveryChallan',
			  data: {"month":month,"year":year}, 
			  success: function(response) {
					
					if (response.length == 0) {
      				alert("There is no Delivery Challan for the selected month and year");

			        }
					if(response.length != 0){
						for(var i=0;i< response.length;i++){
							$('#deliveryChallanNoSelect').append('<option selected="selected">'+ "" + '</option>');
							$('#deliveryChallanNoSelect').append('<option >' + response[i]+ '</option>');
							$('#deliveryChallanNoSelect').trigger('liszt:updated');
						}
					}else{
						$('#deliveryChallanNoSelect').empty();	
						$('#deliveryChallanNoSelect').children().remove();
						$('#deliveryChallanNoSelect').val('').trigger('liszt:updated');
					}
				
		 }
		 });
	 }
}


$("#customerSelect").chosen().change(function() {

	$('#deliveryChallanNoSelect').empty();	
	$('#deliveryChallanNoSelect').children().remove();
	$('#deliveryChallanNoSelect').val('').trigger('liszt:updated');
	
	var customerId = $('#customerSelect').val();
	month = $("#ui-datepicker-div .ui-datepicker-month :selected").val();
    year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
  
	$.ajax({
		type:'POST', 
		url: 'packingSlip/getDeliveryChallanNos',
		data: {'customer':customerId,"month":month,"year":year}, 
		success: function(response) {
			
			$('#deliveryChallanNoSelect').empty();
			
			if (response.length == 0) {
			alert("There is no delivery challan created for the selected customer and month year");
			$('#packingSlipGrid').jqGrid('clearGridData');
		    jQuery("#packingSlipGrid").setCaption("Packing Slip List");
			}
			else

            
			if(response.length != 0){
				for(var i=0;i< response.length;i++){
					$('#deliveryChallanNoSelect').append('<option selected="selected">'+ "" + '</option>');
					$('#deliveryChallanNoSelect').append('<option >' + response[i]+ '</option>');
					$('#deliveryChallanNoSelect').trigger('liszt:updated');
				}
			}		
	}
  });

});



$("#deliveryChallanNoSelect").chosen().change(function() {

	var deliveryChallanNo = $('#deliveryChallanNoSelect').val();
	$.ajax({
		
		type:'POST', 
		url: 'packingSlip/getDcDetails',
		data:{"deliveryChallanNo":deliveryChallanNo},
		success: function(response) {
		
				 var res =response[1];
				 document.getElementById('customerSelect').value = res ;
	 			 $('#customerSelect').trigger('liszt:updated');	
                 var customerName= $('#customerSelect option:selected').text();
           	  
		     jQuery("#packingSlipGrid").setGridParam({datatype:'json'}); 
			 jQuery("#packingSlipGrid").setGridParam({ url : 'packingSlip/getPackingSlipDetails'});
			 jQuery("#packingSlipGrid").setGridParam({postData: {deliveryChallanNo:deliveryChallanNo}}); 
       	     jQuery("#packingSlipGrid").setCaption('Packing Slip for '+deliveryChallanNo+' Records of '+customerName);
			 jQuery("#packingSlipGrid").trigger('reloadGrid');

	     }});
	

});

function resetValues() {
	if (document.getElementById('customerSelect').value != "") {
		document.getElementById('customerSelect').value = "" ;
			$('#customerSelect').trigger('liszt:updated');	
	}
	$('#deliveryChallanNoSelect').empty();	
	$('#deliveryChallanNoSelect').children().remove();
	$('#deliveryChallanNoSelect').val('').trigger('liszt:updated');
	$('#monthYearPicker').datepicker('setDate',systemDate);
	month = $("#ui-datepicker-div .ui-datepicker-month :selected").val();
    year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
	$('#deliveryChallanGrid').jqGrid('clearGridData');
	 jQuery("#deliveryChallanGrid").setCaption("Packing Slip List");
	 $.ajax({type:'POST',
		  url: 'packingSlip/fetchDeliveryChallan',
		  data: {"month":month,"year":year}, 
		  success: function(response) {
				if(response.length != 0){
					for(var i=0;i< response.length;i++){
						$('#deliveryChallanNoSelect').append('<option selected="selected">'+ "" + '</option>');
						$('#deliveryChallanNoSelect').append('<option >' + response[i]+ '</option>');
						$('#deliveryChallanNoSelect').trigger('liszt:updated');
					}
				}			
	 }
	 });
	
}



