var lastSelected;

$(function() {
	
	$("#orderAcceptanceDate").datepicker({
		dateFormat : "dd-mm-yy",
		onSelect : function(dateStr) {
			var min = $('#orderAcceptanceDate').datepicker('getDate');
			$('#orderAcceptanceDateTo').datepicker('option', {
				minDate : min
			});
		}
	});
	$("#orderAcceptanceDateTo").datepicker({
		dateFormat : "dd-mm-yy",
		minDate : $('#orderAcceptanceDate').datepicker('getDate')
	});

	$("#partySelect").chosen({
		no_results_text : "No results matched"
	});
	$("#itemIdSelect").chosen({
		no_results_text : "No results matched"
	});
	$("#strandsSelect").chosen({
		no_results_text : "No results matched"
	});
	$("#cuDiameterSelect").chosen({
		no_results_text : "No results matched"
	});
	$("#mainColorSelect").chosen({
		no_results_text : "No results matched"
	});
	$("#innerColorSelect").chosen({
		no_results_text : "No results matched"
	});
	$("#productTypeSelect").chosen({
		no_results_text : "No results matched"
	});
	$("#salesOrderSelect").chosen({
		no_results_text : "No results matched"
	});
	$("#cableStdPvcSelect").chosen({
		no_results_text : "No results matched"
	});

	var reportType = "PendingReport";
	$("#SOforWOGrid")
			.jqGrid(
					{
						url : 'viewSOForWO/records/' + encodeURIComponent(reportType),
						datatype : 'json',
						mtype : 'POST',
						colNames : [ 'Id', 'Sales Order',
								'Order Acceptance Date','Party', 'PartyHidden', 'custId',
								'Status', 'Item Id', 'Item Code',
								'No of Strands', 'Cu Diam(mm)', ' OD',
								'Main Color', 'Stripe Color',
								'Item Description', 'Cable Std', 'Lay Length',
								'Lay Type', 'Product Type', 'Total Qty(mts)',
								'', 'Balance', '', 'Pdn Qty', '', 'Store Qty',
								'StockOut Qty','','Units', 'Status', 'Qty Levels' ,'Qty Exist'],

						colModel : [ {
							name : 'orderDetailId',
							index : 'orderDetailId',
							width : 10,
							hidden : true
						}, {
							name : 'orderId',
							index : 'orderId',
							width : 70,
							searchoptions : {
								sopt : [ 'eq' ]
							}
						}, {
							name : 'orderAcceptanceDate',
							index : 'orderAcceptanceDate',
							width : 70,
							searchoptions : {
								sopt : [ 'eq' ]
							}
						},{
							name:'customerCode',
							index:'customerCode', 
							width:70
						} ,	{
							name : 'customerName',
							index : 'customerName',
							width : 10,
							searchoptions : {
								sopt : [ 'eq' ]
							},hidden : true
						}, {
							name : 'customerId',
							index : 'customerId',
							width : 10,
							editable : true,
							hidden : true
						}, {
							name : 'status',
							index : 'status',
							width : 10,
							hidden : true
						}, {
							name : 'itemId',
							index : 'itemId',
							width : 10,
							hidden : true
						}, {
							name : 'itemCode',
							index : 'itemCode',
							width : 200,
							searchoptions : {
								sopt : [ 'eq' ]
							}
						}, {
							name : 'numberOfCopperStrands',
							index : 'numberOfCopperStrands',
							width : 40,
							searchoptions : {
								sopt : [ 'eq' ]
							}
						}, {
							name : 'copperkey',
							index : 'copperkey',
							width : 40,
							searchoptions : {
								sopt : [ 'eq' ]
							}
						}, {
							name : 'odLabel',
							index : 'odLabel',
							width : 40,
							searchoptions : {
								sopt : [ 'eq' ]
							}
						}, {
							name : 'mainColour',
							index : 'mainColour',
							width : 90,
							searchoptions : {
								sopt : [ 'eq' ]
							}
						}, {
							name : 'innerColor',
							index : 'innerColor',
							width : 60,
							searchoptions : {
								sopt : [ 'eq' ]
							}
						}, {
							name : 'itemDescription',
							index : 'itemDescription',
							width : 10,
							hidden : true
						}, {
							name : 'cableStdKey',
							index : 'cableStdKey',
							width : 40,
							searchoptions : {
								sopt : [ 'eq' ],
								searchhidden : true
							}
						}, {
							name : 'layLength',
							index : 'layLength',
							width : 10,
							hidden : true,
							searchoptions : {
								sopt : [ 'eq' ],
								searchhidden : true
							}
						}, {
							name : 'layType',
							index : 'layType',
							width : 10,
							hidden : true,
							searchoptions : {
								sopt : [ 'eq' ],
								searchhidden : true
							}
						}, {
							name : 'productKey',
							index : 'productKey',
							width : 10,
							hidden : true,
							searchoptions : {
								sopt : [ 'eq' ],
								searchhidden : true
							}
						}, {
							name : 'quantity',
							index : 'quantity',
							width : 50,
							search : false
						}, {
							name : 'quantity',
							index : 'quantity',
							hidden : true,
							width : 10,
							editable : true
						}, {
							name : 'balanceQty',
							index : 'balanceQty',
							width : 50,
							search : false
						}, {
							name : 'balanceQty',
							index : 'balanceQty',
							hidden : true,
							width : 10,
							editable : true
						},  {
							name : 'productionQty',
							index : 'productionQty',
							width : 50,
							search : false
						}, {
							name : 'productionQty',
							index : 'productionQty',
							hidden : true,
							width : 10,
							editable : true
						},{
							name : 'completedQty',
							index : 'completedQty',
							width : 50,
							search : false
						},{
							name : 'dispatchedQty',
							index : 'dispatchedQty',
							width : 50,
							search : false
						},  {
							name : 'dispatchedQty',
							index : 'dispatchedQty',
							hidden : true,
							width : 10,
							editable : true
						}, 
						{
							name : 'unit',
							index : 'unit',
							width : 50
						},{
							name : 'status',
							index : 'status',
							width : 90,
							editable : true
						}, {
							name : 'qtyLevelLinks',
							index : 'qtyLevelLinks',
							width : 40,
							editable : false,
							sortable : false
						},{
						name : 'delivered',
						index : 'delivered',
						width : 10,
						hidden:true
						}
						],

						postData : {},
						rowNum : 100,
						rowList : [ 5, 10, 20, 40, 60, 100,500,1000,5000 ],
						height : 400,
						autowidth : true,
						rownumbers : false,
						pager : '#soForWopager',
						sortname : 'orderDetailId',
						viewrecords : true,
						sortorder : "desc",
						sortable : true,
						caption : "Pending Sales Orders Items List",
						emptyrecords : "Empty records",
						loadonce : false,
						footerrow : true,
						loadComplete : function() {
						},
						jsonReader : {
							root : "rows",
							page : "page",
							total : "total",
							records : "records",
							repeatitems : false,
							cell : "cell",
							id : "orderDetailId"

						},

						gridComplete : function() {

							var quantity = $('#SOforWOGrid').jqGrid('getCol',
									'quantity', false, 'sum');
							var totalQuantity = Math
									.round(parseFloat(quantity) * 100) / 100;
							$('#SOforWOGrid').jqGrid('footerData', 'set', {
								ID : 'Total:',
								quantity : totalQuantity
							});

							var balanceQty = $('#SOforWOGrid').jqGrid('getCol',
									'balanceQty', false, 'sum');
							var totalBalanceQty = Math
									.round(parseFloat(balanceQty) * 100) / 100;
							$('#SOforWOGrid').jqGrid('footerData', 'set', {
								ID : 'Total:',
								balanceQty : totalBalanceQty
							});

							var completedQty = $('#SOforWOGrid').jqGrid(
									'getCol', 'completedQty', false, 'sum');
							var totalCompletedQty = Math
									.round(parseFloat(completedQty) * 100) / 100;
							$('#SOforWOGrid').jqGrid('footerData', 'set', {
								ID : 'Total:',
								completedQty : totalCompletedQty
							});

							var productionQty = $('#SOforWOGrid').jqGrid(
									'getCol', 'productionQty', false, 'sum');
							var totalProductionQty = Math
									.round(parseFloat(productionQty) * 100) / 100;
							$('#SOforWOGrid').jqGrid('footerData', 'set', {
								ID : 'Total:',
								productionQty : totalProductionQty
							});

							var dispatchedQty = $('#SOforWOGrid').jqGrid(
									'getCol', 'dispatchedQty', false, 'sum');
							var totalDispatchedQty = Math
									.round(parseFloat(dispatchedQty) * 100) / 100;
							$('#SOforWOGrid').jqGrid('footerData', 'set', {
								ID : 'Total:',
								dispatchedQty : totalDispatchedQty
							});

							var ids = $("#SOforWOGrid").jqGrid('getDataIDs');
							for ( var i = 0; i < ids.length; i++) {
								var cl = ids[i];
					/*			if ($("#SOforWOGrid").getCell(cl, "itemCode") == "") {
									$("#SOforWOGrid").jqGrid('setRowData',
											ids[i], false, {
												color : 'black',
												weightfont : 'bold',
												background : '#81DAF5'
											});
								}*/
								if ($("#SOforWOGrid").getCell(cl,	"delivered") == "Yes") {
									$("#SOforWOGrid").jqGrid('setRowData', ids[i], false, {color : 'black',weightfont : 'bold',background : '#F8F9A7'});
								}
								qtyLink = "<button class='btn btn-mini' id='qtyLevelLinks"
										+ cl
										+ "' "
										+ "onclick=\"openQtyLevelLink('"
										+ cl
										+ "');\" >Qty</button>";
								$("#SOforWOGrid").jqGrid('setRowData', ids[i],
										{
											qtyLevelLinks : qtyLink
										});
							}
						}

					});
	jQuery("#SOforWOGrid").jqGrid('navGrid', '#soForWopager', {
		view : false,
		del : false,
		add : false,
		edit : false,
		search:false
	}, {}, // use default settings for edit
	{}, // settings for add
	{}, // delete instead that del:false we need this
	{
		closeOnEscape : true,
		multipleSearch : true,
		closeAfterSearch : true
	}, // enable the advanced searching
	{
		left : 150,
		caption : "View Sales Order Items",
		width : 600,
		bClose : "Close",
		closeOnEscape : true
	} /* allow the view dialog to be closed when user press ESC key*/);

});

function openQtyLevelLink(id) {
	var grid = jQuery('#SOforWOGrid');
	var customerName = grid.jqGrid('getCell', id, 'customerName');
	//alert(customerName);
	var customerId = grid.jqGrid('getCell', id, 'customerId');
	var itemCode = grid.jqGrid('getCell', id, 'itemCode');
	var itemId = grid.jqGrid('getCell', id, 'itemId');
	$.ajax({
		type : 'POST',
		url : 'viewSOForWO/fetchQtyLevels',

		data : 'customerName=' + customerName + '&customerId=' + customerId
				+ '&itemCode=' + itemCode + '&itemId=' + itemId,
		success : function(response) {
			//alert(response[0]);
			document.getElementById('stockSameCustomer').value = response[0];
			document.getElementById('stockOtherCustomer').value = response[1];
			document.getElementById('pdnSameCustomer').value = response[2];
			document.getElementById('pdnOtherCustomer').value = response[3];
		}
	});

	$("#dialog-modal").dialog({
		width : 450,
		height : 275

	});

}

$('#searchSoItems').click(function() {
	if (document.getElementById('numberOfCopperStrands').value != "") {
		var pattern = /^[0-9]\d*$/;
		if (!pattern.test($("#numberOfCopperStrands").val())) {
			alert("Enter valid Copper Strands");
			document.getElementById('numberOfCopperStrands').value = "";

		} else {
			searchFunction();
		}
	}
	
	
	else if (document.getElementById('layLength').value != "") {
		var pattern = /^[0-9]\d*$/;
		if (!pattern.test($("#layLength").val())) {
			alert("Enter valid Lay Length");
			document.getElementById('layLength').value = "";

		} else {
			searchFunction();
		}
	}
	else {
		searchFunction();
	}
});

function searchFunction() {
	var noOfCuStrand = document.getElementById('numberOfCopperStrands').value;
	var layLength = document.getElementById('layLength').value;
	var layType = document.getElementById('layType').value;
	var od = document.getElementById('odLabel').value;
	var orderAcceptanceDate = document.getElementById('orderAcceptanceDate').value;
	var orderAcceptanceDateTo = document.getElementById('orderAcceptanceDateTo').value;
	   var dateCheckFunction=orderAcceptanceDatevalid();
       if(dateCheckFunction==true){
    	var searchOptions1 = {
		"groupOp" : "AND",
		"rules" : [ {
			"field" : "customerId",
			"op" : "eq",
			"data" : $("#partySelect").val()
		}, {
			"field" : "orderId",
			"op" : "eq",
			"data" : $("#salesOrderSelect").val()
		}, {
			"field" : "copperkey",
			"op" : "eq",
			"data" : $("#cuDiameterSelect").val()
		}, {
			"field" : "mainColour",
			"op" : "eq",
			"data" : $("#mainColorSelect").val()
		}, {
			"field" : "innerColor",
			"op" : "eq",
			"data" : $("#innerColorSelect").val()
		}, {
			"field" : "productKey",
			"op" : "eq",
			"data" : $("#productTypeSelect").val()
		}, {
			"field" : "numberOfCopperStrands",
			"op" : "eq",
			"data" : noOfCuStrand
		}, {
			"field" : "layType",
			"op" : "eq",
			"data" : layType
		}, {
			"field" : "layLength",
			"op" : "eq",
			"data" : layLength
		}, {
			"field" : "cableStdKey",
			"op" : "eq",
			"data" : $("#cableStdPvcSelect").val()
		}, {
			"field" : "odLabel",
			"op" : "eq",
			"data" : od
		}, {
			"field" : "orderAcceptanceDate",
			"op" : "eq",
			"data" : orderAcceptanceDate
		}, {
			"field" : "orderAcceptanceDateTo",
			"op" : "eq",
			"data" : orderAcceptanceDateTo
		}, ]
	};

	performSearch(searchOptions1, "#SOforWOGrid");
       }
}

function performSearch(searchOptions, gridId) {

	$(gridId).setGridParam({
		postData : {
			searchObject : JSON.stringify(searchOptions)
		}
	});
	$(gridId).trigger("reloadGrid");

}
function orderAcceptanceDatevalid(){
	var fromDate = document.getElementById('orderAcceptanceDate').value;
	var toDate = document.getElementById('orderAcceptanceDateTo').value;

	if(fromDate!=null && fromDate!="" &&(toDate==null || toDate=="")){
		alert("Select Order Acceptance To date");
		return false;
	}
	else if(toDate!=null && toDate!="" &&(fromDate==null || fromDate=="")){
		alert("Select Order Acceptance From date");
		return false;

	}else{
		return true;
	}
}	
$('#clearSearchBox').click(function() {
	if ($("#salesOrderSelect").val() != "") {
		document.getElementById('salesOrderSelect').value = "";
		$('#salesOrderSelect').trigger('liszt:updated');
	}

	if ($("#partySelect").val() != "") {
		document.getElementById('partySelect').value = "";
		$('#partySelect').trigger('liszt:updated');
	}
	if ($("#mainColorSelect").val() != "") {
		document.getElementById('mainColorSelect').value = "";
		$('#mainColorSelect').trigger('liszt:updated');
	}
	if ($("#innerColorSelect").val() != "") {
		document.getElementById('innerColorSelect').value = "";
		$('#innerColorSelect').trigger('liszt:updated');
	}
	if ($("#cableStdPvcSelect").val() != "") {
		document.getElementById('cableStdPvcSelect').value = "";
		$('#cableStdPvcSelect').trigger('liszt:updated');
	}
	if ($("#cuDiameterSelect").val() != "") {
		document.getElementById('cuDiameterSelect').value = "";
		$('#cuDiameterSelect').trigger('liszt:updated');
	}

	if ($("#productTypeSelect").val() != "") {
		document.getElementById('productTypeSelect').value = "";
		$('#productTypeSelect').trigger('liszt:updated');
	}
	if (document.getElementById('numberOfCopperStrands').value != "")
		document.getElementById('numberOfCopperStrands').value = "";

	if (document.getElementById('odLabel').value != "")
		document.getElementById('odLabel').value = "";
	if (document.getElementById('layLength').value != "")
		document.getElementById('layLength').value = "";
	if (document.getElementById('layType').value != "")
		document.getElementById('layType').value = "";
	if (document.getElementById('orderAcceptanceDate').value != "")
		document.getElementById('orderAcceptanceDate').value = "";

	if (document.getElementById('orderAcceptanceDateTo').value != "")
		document.getElementById('orderAcceptanceDateTo').value = "";
	
	searchFunction();
	$('#salesOrderSelect').children().remove();
	 $.ajax({type:'POST',
		  url: 'pendingSoItemReport/fetchSalesOrder',

		  success: function(response) {
				if(response.length != 0){
					for(var i=0;i< response.length;i++){
						$('#salesOrderSelect').append('<option selected="selected">'+ "" + '</option>');
						$('#salesOrderSelect').append('<option >' + response[i]+ '</option>');
						$('#salesOrderSelect').trigger('liszt:updated');
					}
				}			
	 }
	 });
	
	

});


$("#partySelect").chosen().change(function() {
  	var customerId = $('#partySelect').val();
   	if(customerId != "" && customerId!=null){
    	$('#salesOrderSelect').children().remove();
    	$('#salesOrderSelect').val('').trigger('liszt:updated');
    	$.ajax({type:'POST', 
    		url: 'pendingSoItemReport/getPendingSalesOrders',
    		data:{"customerId":customerId,"reportType":"All"},
    		success: function(response) {
    		//if(response.length != 0){
    				for(var i=0;i< response.length;i++){
    					$('#salesOrderSelect').append('<option selected="selected">'+ "" + '</option>');
    					$('#salesOrderSelect').append('<option >' + response[i]+ '</option>');
    					$('#salesOrderSelect').trigger('liszt:updated');
    				}
    	//	}
    	}});
    	}
    }); 

$("#salesOrderSelect").chosen().change(function() {
	var salesOrder = $('#salesOrderSelect').val();
	$.ajax({
		
		type:'POST', 
 		url: 'pendingSoItemReport/getSalesOrderDetails',
 		data:{"salesOrder":salesOrder},
 		success: function(response) {
 			if(response[0]!=null && response.length>0){
 			var res =response[0];
				document.getElementById('partySelect').value = res ;
	 			$('#partySelect').trigger('liszt:updated');	
          
 			}
 		}
    });   
});
    