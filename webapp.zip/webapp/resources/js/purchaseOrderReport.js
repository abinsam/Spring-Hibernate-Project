
$(function(){
	   $("#statusSelect").chosen({no_results_text: "No results matched"});
	   $('#statusSelect').trigger('liszt:updated');

	   $( "#startDate" ).datepicker({dateFormat : "dd-mm-yy",
	        maxDate:'today',
           onSelect: function(dateStr)
           {
           var min = $('#startDate').datepicker('getDate'); 
           $('#endDate').datepicker('option', {minDate : min});
     }});
	$( "#endDate" ).datepicker({dateFormat : "dd-mm-yy", minDate:$('#startDate').datepicker('getDate'), maxDate:'today'});

    	$("#purchaseOrderReportGrid").jqGrid({
		datatype: 'local',
	 	width:'70px',
	 	mtype: 'POST',
	   	colNames:['Purchase Order No','supplier Id', 'SupplierHidd','Supplier', 'Total Qty',
					'Balance Qty','Price','Excise Duty','CST','Amount', 'PO Date(dd-mm-yyyy)',
					'Created By', 'Created Time', 'Updated By','PO Status'],
	   	colModel:[
   	    {name : 'poNo',	index : 'poNo',width : 100},
		{name : 'customerId',index : 'customerId',width : 100,editable : true,	hidden : true},
		{name : 'customerName',	index : 'customerName',	width : 20,	hidden : true},
		{name : 'customerCode',	index : 'customerCode',	width : 70},
		{name : 'quantity',	index : 'quantity',	width : 70},
		{name : 'balanceQuantity',	index : 'balanceQuantity',width : 60},
		{name : 'totalPrice',index : 'totalPrice',width : 60},
		{name : 'exciseDuty',index : 'exciseDuty',width :60},
		{name : 'cstValue',	index : 'cstValue',	width : 60},
		{name : 'amount',	index : 'amount',	width : 60},
		{name : 'poDate',	index : 'poDate',	width : 90},
		{name : 'createdBy',	index : 'createdBy',	width : 110,hidden:true},
		{name : 'createdTime',	index : 'createdTime',	width : 10,	hidden:true},
		{name : 'updatedBy',index : 'updatedBy',width : 110,hidden:true},
		{name : 'poStatus',	index : 'poStatus',	width : 50},
		  
	   	],
	   	postData: {},
		rowNum:100,
	   	rowList:[5,10,20,30,40,100],
	   	height :330,
		autowidth : true,
		rownumbers : false,
	    pager: '#purchaseOrderReportPager',
	   	sortname: 'poNo',
	    viewrecords: true,
	    sortorder: "desc",
	    caption:"Purchase Order History",
	    emptyrecords: "Empty records",
	    loadonce: false,
	    footerrow: true,
	    loadComplete: function() {},
	    jsonReader : {
	        root: "rows",
	        page: "page",
	        total: "total",
	        records: "records",
	        repeatitems: false,
	        cell: "cell",
	        id: "poNo"
	    },
	    ondblClickRow : function(id) {},
		gridComplete : function() {
			var totalQuantity = $('#purchaseOrderReportGrid').jqGrid('getCol','quantity',false,'sum');
			$('#purchaseOrderReportGrid').jqGrid('footerData','set', {ID: 'Total:', quantity: totalQuantity});
			
	   		var totalBalanceQuantity= $('#purchaseOrderReportGrid').jqGrid('getCol','balanceQuantity',false,'sum');
	   		$('#purchaseOrderReportGrid').jqGrid('footerData','set', {ID: 'Total:', balanceQuantity: totalBalanceQuantity});
	   		
	   		var totalPrice= $('#purchaseOrderReportGrid').jqGrid('getCol','totalPrice',false,'sum');
	   		$('#purchaseOrderReportGrid').jqGrid('footerData','set', {ID: 'Total:', totalPrice: totalPrice});
	   		
	   		var totalExciseDuty= $('#purchaseOrderReportGrid').jqGrid('getCol','exciseDuty',false,'sum');
	   		$('#purchaseOrderReportGrid').jqGrid('footerData','set', {ID: 'Total:', exciseDuty: totalExciseDuty});
	   		
	   		var totalCstValue= $('#purchaseOrderReportGrid').jqGrid('getCol','cstValue',false,'sum');
	   		$('#purchaseOrderReportGrid').jqGrid('footerData','set', {ID: 'Total:', cstValue: totalCstValue});
	   		
	   		var totalAmount= $('#purchaseOrderReportGrid').jqGrid('getCol','amount',false,'sum');
	   		$('#purchaseOrderReportGrid').jqGrid('footerData','set', {ID: 'Total:', amount: totalAmount});
	   		
	   		/*$('#purchaseOrderReportGrid').jqGrid('footerData','set', {ID: 'Total:', poNo: PurchaseOrderNo});
	   		$('#purchaseOrderReportGrid').jqGrid('footerData','set', {ID: 'Total:', customerName: Supplier});
	   		$('#purchaseOrderReportGrid').jqGrid('footerData','set', {ID: 'Total:', poDate: PoDate});
	   		$('#purchaseOrderReportGrid').jqGrid('footerData','set', {ID: 'Total:', poStatus: Status});*/
	   		
		}
		
	}).navGrid('#purchaseOrderReportPager',{view:false, del:false, edit:false, search:false,add:false}
);
    	
     
});

function searchOrders(){
	var validSearch=validateSearchParams();
	if(validSearch==true){
	var fromDate=document.getElementById('startDate').value;
	var toDate=document.getElementById('endDate').value;
	var orderStatus = document.getElementById('statusSelect').value;
	   jQuery("#purchaseOrderReportGrid").setGridParam({datatype:'json'}); 
	   jQuery("#purchaseOrderReportGrid").setGridParam({ url: 'purchaseOrderReport/records'});
	   jQuery("#purchaseOrderReportGrid").setGridParam({postData: {fromDate:fromDate,toDate:toDate,orderStatus:orderStatus}}); 
	   jQuery("#purchaseOrderReportGrid").setCaption('Purchase Order History from:'+fromDate+' to:'+toDate);
       jQuery("#purchaseOrderReportGrid").trigger('reloadGrid');
	}
}

function validateSearchParams(){
	var fromDate=document.getElementById('startDate').value;
	var toDate=document.getElementById('endDate').value;
    if(fromDate==null || fromDate==""){
    	alert("Select from Date");
    	return false;
    }
    else if(toDate==null || toDate==""){
    	alert("Select to Date");
    	return false;
    }
    else return true;
}


function clearFn() {
	if ($("#statusSelect").val() != "") {
		document.getElementById('statusSelect').value = "";
		$('#statusSelect').trigger('liszt:updated');
	}
	if (document.getElementById('startDate').value != "")
		document.getElementById('startDate').value = "";
	if (document.getElementById('endDate').value != "")
		document.getElementById('endDate').value = "";
	
	jQuery("#purchaseOrderReportGrid").jqGrid('clearGridData');
}

function purchaseOrderReport(){
	var fromDate=document.getElementById('startDate').value;
	var toDate=document.getElementById('endDate').value;
	if (validateSearchParams()==true){
	location.href='purchaseOrderReport/purchaseOrderHistoryReport?fromDate='+fromDate+'&toDate='+toDate;
	}
}