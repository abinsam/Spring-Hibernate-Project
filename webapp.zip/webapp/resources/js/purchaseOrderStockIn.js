var lastSelected;
var grossWeightValid=true;
var tareWeightValid=true;
var qtyPerBagValid=true;
var noOfBagValid=true;
var systemDate = new Date();
var month="";
var year="";
$(function() {
	$("#partyNameSelect").chosen({no_results_text : "No results matched"});
	$("#poNoSelect").chosen({no_results_text : "No results matched"});
	$("#supervisorSelect").chosen({no_results_text : "No results matched"});
	$("#itemIdSelect").chosen({no_results_text : "No results matched"});
	
	$("#monthYearPicker").focus(function () {$(".ui-datepicker-calendar").hide();});
	$('#monthYearPicker').datepicker({
	
        changeYear: true,
        changeMonth: true,
        changeDate :false,
        showButtonPanel: true,
        dateFormat: 'MM yy',
       
        onClose: function(dateText, inst) { 
            year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
            month = $("#ui-datepicker-div .ui-datepicker-month :selected").val();
            $(this).datepicker('setDate', new Date(year,month, 1));
            changeWoOnMonthYear();
        }
    });
	$('#monthYearPicker').datepicker('setDate',systemDate);
$("#monthYearPicker").focus(function () {$(".ui-datepicker-month").show();});
$("#monthYearPicker").focus(function () {$(".ui-datepicker-year").show();});


	$("#stockInOrderGrid")
			.jqGrid({
						datatype : 'local',
						mtype : 'POST',
						multiselect: true,
						colNames : [ 'rwStoreRegId','purchaseOrderItemId', 'Item Code','Item Description', 'PO Qty(Kg)',
								'Balance Qty(Kg)',	'Gross Weight(Kgs) ', 'Tare Weight(Kgs)','Net Weight(Kgs)',
								 'Batch No','No of Bundles', 
								'Total Qty(Kgs)', 'Stock in status' ,'Action'],
						colModel : [ 
						   { name :'rwStoreRegId',index : 'rwStoreRegId',width : 20,hidden : true},
						   {name : 'purchaseOrderItemId',index : 'purchaseOrderItemId',width : 20,hidden : true,editable:true},
						   {name : 'itemCode',index : 'itemCode',width : 180,editable : false,viewable : false},
						   {name : 'itemDescription',index : 'itemDescription',	width : 200,editable : false},
						   {name : 'quantity',index : 'quantity',width : 100,editable : false,viewable : false},
						   {name : 'balanceQty',index : 'balanceQty',width : 120,editable : false,viewable : false},
					       {name : 'grossWeight',index : 'grossWeight',width : 100,	editable : true,
							editoptions:{
								    dataInit: function(element) {
				                      $(element).keyup(function(){
				                          var val1 = element.value;
				                          var num = new Number(val1);
				                          if(isNaN(num))
				                          {
				                        	  alert("Please enter valid Gross Weight");
				                        	  grossWeightValid=false;
				                        	  jQuery("#stockInOrderGrid").trigger('reloadGrid');
				                         }
				                          else
				                        	  grossWeightValid=true;
				                        
				                      });
				                  }
				   	      ,maxlength:8}
						},
						{name : 'tareWeight',index : 'tareWeight',width : 100,editable : true,
							editoptions:{
				                  dataInit: function(element) {
				                      $(element).keyup(function(){
				                          var val1 = element.value;
				                          var num = new Number(val1);
				                          if(isNaN(num))
				                          {
				                        	  alert("Please enter valid Tare Weight");
				                        	  tareWeightValid=false;
				                        	  jQuery("#stockInOrderGrid").trigger('reloadGrid');
				                         }
				                          else
				                        	  tareWeightValid=true;
				                        
				                      });
				                  }
				   	      ,maxlength:8}
						},
						{name : 'netWeight',index : 'netWeight',width : 100,editable : false},
						{name : 'batchNo',index : 'batchNo',width : 70,	editable : true,editoptions:{maxlength:20}},
						{name : 'noOfBags',index : 'noOfBags',width : 80,editable : true,
							editoptions:{
			                       	  dataInit: function(element) {
				                      	var patMatch = /^(0|[1-9][0-9]*)$/;
				                            $(element).keyup(function(){
				                          	  var val1 = element.value;
				                          	  if(val1!=""){
				                        	 if(!patMatch.test(val1)) {
				                          		  alert("Please enter a valid Bundle no");
				                          		noOfBagValid=false;  
				                          	  jQuery("#stockInOrderGrid").trigger('reloadGrid');
				                          	  }
				                        	 else   noOfBagValid=true;}
				                          	  
				                       });
				                  }
				   	      ,maxlength:4}
						},
						{name : 'totalQty',	index : 'totalQty',	width : 80,editable : false},
						{name : 'stockInStatus',	index : 'stockInStatus',	width : 100,editable : true,hidden:true},
						{name : 'act',index : 'act',width :70,sortable : false}
						
						],
						postData : {},
						rowNum : 100,
						rowList : [ 5, 10, 20, 40, 60,100 ],
						height : 300,
						autowidth:true,
						rownumbers : false,
						pager : '#stockInOrderpager',
						sortname : 'rwStoreRegId',
						viewrecords : true,
						sortorder : "desc",
						caption : "Raw Materials for confirming Stock In",
						emptyrecords : "Empty records",
						loadonce : false,
						 footerrow: true,
				   		    ondblClickRow : function(id) {
	        	   				if (id && id !== lastSelected) {
	        	   					$('#stockInOrderGrid').jqGrid('restoreRow',lastSelected);
	        	   					editRow(id);
	        	   					lastSelected = id;
	        	   				}
	        	   			},
	        	   		 onSelectRow: updateIdsOfSelectedRows,   
	        	   		 onSelectAll:function (aRowids, status) {
	        	      	   updateIdsOfAllSelectedRows(aRowids,status);
	        	         },
	        	  	    loadComplete: function () {
	        	   	        var $this = $(this), i, count;
	        	   	        for (i = 0, count = idsOfSelectedRows.length; i < count; i++) {
	        	   	            $this.jqGrid('setSelection', idsOfSelectedRows[i], false);
	        	   	        }
	        	   	      },

						jsonReader : {
							root : "rows",
							page : "page",
							total : "total",
							records : "records",
							repeatitems : false,
							cell : "cell",
							id : "rwStoreRegId"
						},
			  			gridComplete : function() {
	            				 var totalQty = $('#stockInOrderGrid').jqGrid('getCol','quantity',false,'sum');
	    		        	   	 var balQty = $('#stockInOrderGrid').jqGrid('getCol','balanceQty',false,'sum');
	    		        		 var grossWt = $('#stockInOrderGrid').jqGrid('getCol','grossWeight',false,'sum');
	    		        		 var tareWt = $('#stockInOrderGrid').jqGrid('getCol','tareWeight',false,'sum');
	    		        		 var netWt = $('#stockInOrderGrid').jqGrid('getCol','netWeight',false,'sum');
	    		        		 var noOfBundles = $('#stockInOrderGrid').jqGrid('getCol','noOfBags',false,'sum');
	    		        		 var totalStockInQty = $('#stockInOrderGrid').jqGrid('getCol','totalQty',false,'sum');
	 							
	    		        		 var totalQtyRoundUp = Math.round(parseFloat(totalQty) * 100) / 100;
	 							var balQtyRoundUp = Math.round(parseFloat(balQty) * 100) / 100;
	 							var grossWtRoundUp = Math.round(parseFloat(grossWt) * 100) / 100;
	 							var tareWtRoundUp = Math.round(parseFloat(tareWt) * 100) / 100;
	 							var netWtRoundUp = Math.round(parseFloat(netWt) * 100) / 100;
	 							var netTotalStockInRoundUp = Math.round(parseFloat(totalStockInQty) * 100) / 100;
	 					
	 						  	$('#stockInOrderGrid').jqGrid('footerData','set', {ID: 'Total:', quantity: totalQtyRoundUp});
	    	        	   	    $('#stockInOrderGrid').jqGrid('footerData','set', {ID: 'Total:', balanceQty: balQtyRoundUp});
	    	        	   	  	$('#stockInOrderGrid').jqGrid('footerData','set', {ID: 'Total:', grossWeight: grossWtRoundUp});
	    	        	   	    $('#stockInOrderGrid').jqGrid('footerData','set', {ID: 'Total:', tareWeight: tareWtRoundUp});
	    	        	   	    $('#stockInOrderGrid').jqGrid('footerData','set', {ID: 'Total:', netWeight: netWtRoundUp});
	    	        	   	    $('#stockInOrderGrid').jqGrid('footerData','set', {ID: 'Total:', noOfBags: noOfBundles});
	         	        	    $('#stockInOrderGrid').jqGrid('footerData','set', {ID: 'Total:', totalQty: netTotalStockInRoundUp});
	    	        	   	 
	    		        		 
	    		          	   
								var ids = $("#stockInOrderGrid").jqGrid('getDataIDs');
								for ( var i = 0; i < ids.length; i++) {
									var cl = ids[i];

									be = "<input style='height:22px; width:35px;' type='button' value='Edit' id='editRow"+cl+"' onclick=\"editRow('"+ cl + "');\" />";
									de = "<input style='height:22px; width:30px;' type='button' value='Del' id='delRow"+cl+"' onclick=\"delRow('"+ cl + "');\" />";
									se = "<input style='height:22px; width: 29px;' type='button' value='Save' hidden='hidden' id='saveRow"+cl+"' onclick=\"saveRow('"+ cl + "');\" />";
									ce = "<input style='height:22px;width:39px;' type='button' value='Cancel' hidden='hidden' id='restoreRow"+cl+"' onclick=\"restoreRow('"+ cl + "');\" />";
															

									de = "<input style='height:22px; width:40px; font-weight:bold;' type='button' value='Delete' id='delRow"+cl+"' onclick=\"delRow('"+ cl + "');\" />";
							
									$("#stockInOrderGrid").jqGrid('setRowData', ids[i], {
										act :  be + de+se + ce
									});
							}
							},	
	            			
	           		beforeSelectRow: function (rowid, e) {
						    var $myGrid = $(this),
						        i = $.jgrid.getCellIndex($(e.target).closest('td')[0]),
						        cm = $myGrid.jqGrid('getGridParam', 'colModel');
						    return (cm[i].name === 'cb');
						},
						editurl : 'poStockIn/crud'

					});
	$("#stockInOrderGrid").jqGrid('navGrid', "#stockInOrderpager", {
		edit : false,
		add : false,
		del : false,
		view:false,
		search:false
	});
});

$("#partyNameSelect").chosen().change(function() {
	//Abin
		$('#poNoSelect').empty();	
		$('#poNoSelect').children().remove();
		$('#poNoSelect').val('').trigger('liszt:updated');
		
		$('#itemIdSelect').children().remove();
	    document.getElementById('itemIdSelect').value = "";
	    $('#itemIdSelect').trigger('liszt:updated');
		
		
		document.getElementById('poQty').value="";
		document.getElementById('balQty').value="";
		
		var validSearch=validateSearchParams();
		
		if(validSearch==true){
			
		var customerId = $('#partyNameSelect').val();

	     month = $("#ui-datepicker-div .ui-datepicker-month :selected").val();
	     year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();

		$.ajax({
			type:'POST', 
			url: 'poStockIn/getPoNos',
			data: {'customer':customerId,"month":month,"year":year}, 
			success: function(response) {
				$('#poNoSelect').empty();
				
				if (response.length == 0) {
					alert("There is no Purchase Order created for the selected customer and month year");
					$('#stockInOrderGrid').jqGrid('clearGridData');
			        jQuery("#stockInOrderGrid").setCaption("Purchase Order List");
				}

				if(response.length != 0){
					for(var i=0;i< response.length;i++){
						$('#poNoSelect').append('<option selected="selected">'+ "" + '</option>');
						$('#poNoSelect').append('<option >' + response[i]+ '</option>');
						$('#poNoSelect').trigger('liszt:updated');
					}
				}		
		}
	   });
	}
	});

function validateSearchParams(){

	  if($("#monthYearPicker").val()=="" || $("#monthYearPicker").val()==null){
	    	alert("Month and Year empty! please select month and year");
	    	return false;
	    }
	    else return true;
}

function changeWoOnMonthYear(){
	    $('#poNoSelect').children().remove();
		$('#poNoSelect').val('').trigger('liszt:updated');
		
		document.getElementById('poQty').value="";
		document.getElementById('balQty').value="";
		
		document.getElementById('partyNameSelect').value = "";
		$('#partyNameSelect').trigger('liszt:updated');
		
		$('#itemIdSelect').children().remove();
	    document.getElementById('itemIdSelect').value = "";
	    $('#itemIdSelect').trigger('liszt:updated');
		
		$('#stockInOrderGrid').jqGrid('clearGridData');
	
		var validSearch=validateSearchParams();
		
		if(validSearch==true){
			
		 $.ajax({type:'POST',
			  url: 'poStockIn/fetchPurchaceOrder',
			  data: {"month":month,"year":year}, 
			  success: function(response) {
					$('#poNoSelect').empty();	
					if (response.length == 0) {
        				alert("There is no purchase order for the selected month and year");
       
			        }
					if(response.length != 0){
						for(var i=0;i< response.length;i++){
							$('#poNoSelect').append('<option selected="selected">'+ "" + '</option>');
							$('#poNoSelect').append('<option >' + response[i]+ '</option>');
							$('#poNoSelect').trigger('liszt:updated');
						}
					}else{
						$('#poNoSelect').empty();	
						$('#poNoSelect').children().remove();
						$('#poNoSelect').val('').trigger('liszt:updated');
					}
				
		 }
		 });
	 }
}

$('#poNoSelect').chosen().change(function() {
		
	$('#itemIdSelect').children().remove();
    document.getElementById('itemIdSelect').value = "";
    $('#itemIdSelect').trigger('liszt:updated');
	
	document.getElementById('poQty').value=""; 
    document.getElementById('balQty').value=""; 
	var poNo= $('#poNoSelect').val();
	$.ajax({
		        type : 'POST',
				url : 'poStockIn/getPoCustomerDetails',
				data : {"poNo" : poNo},
				success : function(response) {
					
					if(response[1]!=null)
						
	 				 document.getElementById('partyNameSelect').value = response[1] ;
	 	 			 $('#partyNameSelect').trigger('liszt:updated');
					
				}
			});

	$.ajax({
        type : 'POST',
		url : 'poStockIn/getPoItemDetails',
		data : {"poNo" : poNo},
		success : function(response) {
			$('#itemIdSelect').empty();
			if (response.length == 0) {

				alert("There is no purchase order item for the selected Purchase Order");
				$('#itemIdSelect').empty();
				document.getElementById('poQty').value=""; 
	            document.getElementById('balQty').value=""; 
				
			}
			else  {
				for ( var i = 0; i < response.length; i++) {
					$('#itemIdSelect').append('<option selected="selected">'
											+ ""
											+ '</option>');
					$('#itemIdSelect')
							.append(
									'<option >'
											+ response[i]
											+ '</option>');
					$('#itemIdSelect')
							.trigger('liszt:updated');
				}
			}
		}
	});
	 jQuery("#stockInOrderGrid").setGridParam({datatype:'json'}); 
	 jQuery("#stockInOrderGrid").setGridParam({ url: 'poStockIn/readyForStock'});
	 jQuery("#stockInOrderGrid").setGridParam({postData: {purchaseOrderNo:$('#poNoSelect').val()}}); 
	 jQuery("#stockInOrderGrid").trigger('reloadGrid');
});

function itemChangeFn(){
	
		 var poNo = $('#poNoSelect').val();
		 var itemCode = $('#itemIdSelect').val();
		 
		 document.getElementById('poQty').value=""; 
	     document.getElementById('balQty').value=""; 
		 
		 if(poNo!="" && itemCode!="" ){
		 $.ajax({
			
			type:'POST', 
			url: 'poStockIn/fetchItemDetails',
			data :{"poNo":poNo,"itemCode":itemCode},
			datatype:'json',
			success: function(response) {
				
			  	document.getElementById('poQty').value=response[0]; 
	            document.getElementById('balQty').value=response[1]; 
	           
			}
			});
	}
}

function validateItemDetails(){
	
	var  pattern = /^[+]?([0-9]+(?:[\.][0-9]*)?|\.[0-9]+)$/;
	var  test = /^[1-9]\d*$/;
	var grossWeight=document.getElementById('grossWeight').value;
	var tareWeight=document.getElementById('tareWeight').value;
    var noOfBundles=document.getElementById('noOfBundles').value;
    var poNo = $('#poNoSelect').val();
	 var itemCode = $('#itemIdSelect').val();
	 if(poNo=="" ||poNo==null){
		    alert("select Purchase order No");
		    return false;
	 }else if(itemCode=="" || itemCode==null){
	     alert("select item code");
	    return false;
     }else if(document.getElementById('grossWeight').value=="" || document.getElementById('grossWeight').value==null ){
		 alert("Enter Gross Weight");
		 return false;
		 document.getElementById('grossWeight').value="";
	 }else if(document.getElementById('grossWeight').value==0){
		 alert("Enter valid non-zero Gross Weight");
		 document.getElementById('grossWeight').value="";
		 return false;
		 
	 }
     
     
     
     else  if(document.getElementById('tareWeight').value=="" || document.getElementById('tareWeight').value==null ){
		 alert("Enter Tare Weight");
		 return false;
	 }else  if(document.getElementById('batchNo').value=="" || document.getElementById('batchNo').value==null ){
		 alert("Enter Batch No");
		 return false;
	 }else  if(document.getElementById('noOfBundles').value=="" || document.getElementById('batchNo').value==null){
		 alert("Enter No of Bundles");
		 return false;
	 }
	 else  if(!pattern.test(grossWeight)){
		 alert("Enter valid Gross Weight");
		 
		 document.getElementById('grossWeight').value="";
		 if(document.getElementById('tareWeight').value!="")
			 {
			   document.getElementById('tareWeight').value="";
			 }
		 if(document.getElementById('noOfBundles').value!="")
		 {
		   document.getElementById('noOfBundles').value="";
		 }
		 if(document.getElementById('batchNo').value!="")
		 {
		   document.getElementById('batchNo').value="";
		 }
		 return false;
	 }
	else if(!pattern.test(tareWeight)){
		 alert("Enter valid Tare Weight");
		 document.getElementById('tareWeight').value="";
		 return false;
	 }
	else if(!test.test(noOfBundles)){
		 alert("Enter valid No Of Bundles");
		 document.getElementById('noOfBundles').value="";
		 return false;
	 }
	else if(parseFloat(tareWeight)>parseFloat(grossWeight)){
		   alert("Gross should be greater than tare weight");
		   document.getElementById('grossWeight').value="";
		   document.getElementById('tareWeight').value="";
		   return false;

	}
	else return true;
 
 
}

function addToStockFn(){
	
    var validateItemDetailsResult = validateItemDetails();
   if(validateItemDetailsResult==true){
			$.ajax({type:'POST', 
				url: 'poStockIn/addToStock', 
				data:{
					 'itemIdSelect' : $("#itemIdSelect").val() , 
					 'grossWeight' : $("#grossWeight").val() , 
				     'tareWeight' : $("#tareWeight").val() , 
					 'batchNo' : $("#batchNo").val(),
					 'noOfBundles': $('#noOfBundles').val(),
					 'pOrderNoSelect': $('#poNoSelect').val()
					 },
				success: function(response) {
					     jQuery("#stockInOrderGrid").setGridParam({datatype:'json'}); 
						 jQuery("#stockInOrderGrid").setGridParam({ url: 'poStockIn/readyForStock'});
						 jQuery("#stockInOrderGrid").setGridParam({postData: {purchaseOrderNo:$('#poNoSelect').val()}}); 
						 jQuery("#stockInOrderGrid").trigger('reloadGrid');
			
				}}); 
	 }
}	
	

function editRow(id) {
	restoreRow(lastSelected);
	lastSelected = id;
	$('#stockInOrderGrid').jqGrid('editRow', id, {
		"keys" : true,
		"oneditfunc" : hideActButtons,
		aftersavefunc : function(savedId, response) {
			showActButtons(savedId);
		},
		afterrestorefunc : showActButtons
	});
   }

function delRow(id) {
   	if (confirm("Are you sure you want to delete ?")) {
		var oper = "del";
		$.ajax({
			type : 'POST',
			url : 'poStockIn/crud',
			data : {
				'id' : id,
				'oper' : oper
			},
			success : function(response) {
				jQuery("#stockInOrderGrid").trigger('reloadGrid');
			}
		});

	
	;
}}

function saveRow(id) {
		$('#stockInOrderGrid').saveRow(id, {
			aftersavefunc : function(id, response) {
				var grid = jQuery('#stockInOrderGrid');
				var grossWt = grid.jqGrid('getCell', id, 'grossWeight');
				var tareWt = grid.jqGrid('getCell', id, 'tareWeight');
				var noOfBags = grid.jqGrid('getCell', id, 'noOfBags');
	    		var batchNo = grid.jqGrid('getCell', id, 'batchNo');
       	if(noOfBags!=""  && grossWt!="" && tareWt!=""){
	    if(parseFloat(grossWt)<parseFloat(tareWt)){
			alert("Gross Weight should be greater than Tare Weight");
			grid.jqGrid('setCell', id, 'grossWeight', 0);
			grid.jqGrid('setCell', id, 'tareWeight', 0);
			grid.jqGrid('setCell', id, 'netWeight', 0);
			grid.jqGrid('setCell', id, 'noOfBags', 0);
		}else{
			grid.jqGrid('setCell', id, 'netWeight', 0);
		}
		jQuery("#stockInOrderGrid").trigger('reloadGrid');

     	}else if(grossWt==""){
		alert("Enter valid Gross weight");
	}else if(tareWt==""){
		alert("Enter valid Tare weight");
	}else if(batchNo==""){
		alert("Enter valid Batch No");
	}else if(noOfBags==""){
		alert("Enter valid No of Bundles");
	}}
});

		
	$('#stockInOrderGrid').saveRow(id, {
		aftersavefunc : function(id, response) {
			showActButtons(id);
		}
	
	});
	jQuery("#stockInOrderGrid").trigger("reloadGrid");
}




function restoreRow(id) {
	$('#stockInOrderGrid').jqGrid('restoreRow', id, {
		afterrestorefunc : showActButtons
	});
}

/*
 * Hides the Edit and Del Row Buttons on jqGrid
 * and activates the Save and restore(cancel) button
 * 
 */
function hideActButtons(id) {
	$('#editRow' + id).hide();
	$('#delRow' + id).hide();
	$('#saveRow' + id).show();
	$('#restoreRow' + id).show();
	pickdates(id);
}

/*
 * Shows the Edit and Del Row Buttons on jqGrid
 * and hides the Save and restore(cancel) button
 * 
 */
function showActButtons(id) {
	$('#editRow' + id).show();
	$('#delRow' + id).show();
	$('#saveRow' + id).hide();
	$('#restoreRow' + id).hide();
	lastSelected = null;
}


function resetValues() {

	if ($("#partyNameSelect").val() != "") {
		document.getElementById('partyNameSelect').value = "";
		$('#partyNameSelect').trigger('liszt:updated');
	}
	if ($("#poNoSelect").val() != "") {
	     document.getElementById('poNoSelect').value = "";
        $('#poNoSelect').trigger('liszt:updated');
	
	}
	if ($("#itemIdSelect").val() != "") {
		document.getElementById('itemIdSelect').value = "";
		$('#itemIdSelect').trigger('liszt:updated');
	}
	document.getElementById('poQty').value = "";
	document.getElementById('balQty').value = "";
	document.getElementById('grossWeight').value = "";
	document.getElementById('tareWeight').value = "";
	document.getElementById('batchNo').value = "";
	document.getElementById('noOfBundles').value = "";
	$('#monthYearPicker').datepicker('setDate',systemDate);			
}
idsOfSelectedRows = ["8", "9", "10"];
var $SOforWOGrid = $("#stockInOrderGrid"), idsOfSelectedRows = [],
updateIdsOfSelectedRows = function (id, isSelected) {
       var index = $.inArray(id, idsOfSelectedRows);
       if (!isSelected && index >= 0) {
	          idsOfSelectedRows.splice(index, 1); // remove id from the list
        } else if (index < 0) {
          idsOfSelectedRows.push(id);
        }  
};



updateIdsOfAllSelectedRows = function (aRowids, isSelected) {
  var i, count, id;
	 for (i = 0, count = aRowids.length; i < count; i++) {
		 id = aRowids[i];
   	     var index = $.inArray(id, idsOfSelectedRows);
           if (!isSelected && index >= 0) {
   	          idsOfSelectedRows.splice(index, 1); // remove id from the list
            } else if (index < 0) {
              idsOfSelectedRows.push(id);
            }  
	 }};





$(document).keypress(function(e) {
if (e.which == 13) {
	var ids = $("#stockInOrderGrid").jqGrid('getDataIDs');
	for ( var i = 0; i < ids.length; i++) {
		var cl = ids[i];
		var grid = jQuery('#stockInOrderGrid');
		var grossWt = grid.jqGrid('getCell', cl, 'grossWeight');
		var tareWt = grid.jqGrid('getCell', cl, 'tareWeight');
		  if(parseFloat(grossWt)<parseFloat(tareWt)){
			  alert("Gross Weight should be greater than Tare Weight");	  
		  }else
		saveRow(cl);
           
	}
}
});

function submitRawMaterials(){
	if(idsOfSelectedRows.length==0){
		alert("Select raw materials to stock in");
	}else{
		if(confirm("Do you want to Stock In the selcted Items?")){	
		$.ajax({type : 'POST',
			url : 'poStockIn/confirmStockIn',
			data : {'idsOfSelectedRows' : idsOfSelectedRows},
		success : function(response) {
			alert("Selected Item stocked in sucessfully");
			idsOfSelectedRows = [];
		     jQuery("#stockInOrderGrid").setGridParam({datatype:'json'}); 
			 jQuery("#stockInOrderGrid").setGridParam({ url: 'poStockIn/readyForStock'});
			  jQuery("#stockInOrderGrid").setGridParam({postData: {purchaseOrderNo:$('#poNoSelect').val()}}); 
			 jQuery("#stockInOrderGrid").trigger('reloadGrid');
			 var poNo = $('#poNoSelect').val();
			 var itemCode = $('#itemIdSelect').val();
			if(poNo!="" && itemCode!="" ){
			$.ajax({type:'POST', 
				url: 'poStockIn/fetchItemDetails',
				data :{'poNo':poNo,'itemCode':itemCode},
				success: function(response) {
					                 
				  	 document.getElementById('poQty').value=response[0]; 
		             document.getElementById('balQty').value=response[1]; 
		      
				}
				});
			}

		}});
	}
	}
}
