
var submitStatus=false;
var lastSelected;
$(function(){
	
	$("#extrusionWoNoSelect").chosen({no_results_text: "No results matched"});

	//alert($('#workOrderSelect').val());
  if($('input:radio[name=workOrderSelect]:checked').val()==0){
	  $('.newWoTableId').show();
	  $('.existingWoTableId').hide();
 }else{
	  $('.existingWoTableId').show();
	  $('.newWoTableId').hide();
 }
	
  $("input[name=workOrderSelect]").change(function () {
	  if($('input:radio[name=workOrderSelect]:checked').val()==0){
		  $('.newWoTableId').show();
		  $('.existingWoTableId').hide();
		  jQuery("#workorderGrid").jqGrid("clearGridData", true);
		 	document.getElementById('saveWorkOrderNewWo').disabled=false;
	   		document.getElementById('fetchWoItemsNewWo').disabled=false;
	   		document.getElementById('addNewItems').disabled=false;
	   		document.getElementById('Submit').disabled=false;


	  }else{
		  $('#extrusionWoNoSelect').children().remove();
			$('#extrusionWoNoSelect').val('').trigger('liszt:updated');

			$.ajax({type:'POST', 
				url: 'workorder/getExtrusionWoNos',
				success: function(response) {
					$('#mwdWoNoSelect').empty();
					if(response.length != 0){
						for(var i=0;i< response.length;i++){
							$('#extrusionWoNoSelect').append('<option selected="selected">'+ "" + '</option>');
							$('#extrusionWoNoSelect').append('<option >' + response[i]+ '</option>');
							$('#extrusionWoNoSelect').trigger('liszt:updated');
						}
					}else{
						$('#extrusionWoNoSelect').empty();
					}
					
			  				
			}});
		  
		   
		  
		  
		  
		  
		  
		  
		  
		  $('.existingWoTableId').show();
		  $('.newWoTableId').hide();
		  var woNo=$('#extrusionWoNoSelect').val();
			     jQuery("#workorderGrid").setGridParam({datatype:'json'}); 
				 jQuery("#workorderGrid").setGridParam({ url: 'workorder/records/'+ encodeURIComponent(woNo)});
				 jQuery("#workorderGrid").trigger('reloadGrid');
	
		    document.getElementById('workOrderNoTag').value = "";
			document.getElementById('workOrderDate').value = "";
			document.getElementById('woCompletionDate').value = "";
			document.getElementById('woMachineNo').value = "";
			$('#woMachineNo').trigger('liszt:updated');
			document.getElementById('itemIdSelect').value = "";
			$('#itemIdSelect').trigger('liszt:updated');
			document.getElementById('quantity').value = "";
			document.getElementById('bundleSize').value = "";

			 if(document.getElementById('woStatus').value=="Submitted"){
				 	document.getElementById('saveWorkOrderExistWo').disabled=true;
			   		document.getElementById('fetchWoItemsExistWo').disabled=true;
			   		document.getElementById('addNewItems').disabled=true;
			   		document.getElementById('Submit').disabled=true;
			   		submitStatus=true;

			  }else{
				 	document.getElementById('saveWorkOrderExistWo').disabled=false;
			   		document.getElementById('fetchWoItemsExistWo').disabled=false;
			   		document.getElementById('addNewItems').disabled=false;
			   		document.getElementById('Submit').disabled=false;
			   		submitStatus=false;
			  }	
			  jQuery("#workorderGrid").jqGrid("clearGridData", true);
			//  jQuery("#workorderGrid").trigger('reloadGrid');
	  }

  });
	
	var pvcData="";
    $.getJSON("workorder/pvcGrade", function(data) {
	 assignPvcGradeValue(data);
	 });
function assignPvcGradeValue(data){
	for(var k=0;k<data.length;k++){
		pvcData=pvcData+data[k]+":"+data[k];
		if(k<(data.length-1)){
			pvcData=pvcData+";";
		}
	}
   setUpGrid(pvcData);
}


	//$("#woSupervisor").chosen({no_results_text: "No results matched"});
	$("#woMachineNo").chosen({no_results_text: "No results matched"});
	$( "#workOrderDate" ).datepicker({dateFormat : "dd-mm-yy",
		        maxDate:'today',
                onSelect: function(dateStr)
                {
                var min = $('#workOrderDate').datepicker('getDate'); 
                $('#woCompletionDate').datepicker('option', {minDate : min});
          }});
    	$( "#woCompletionDate" ).datepicker({dateFormat : "dd-mm-yy", minDate:$('#workOrderDate').datepicker('getDate')});
    	$("#itemIdSelect").chosen({no_results_text: "No results matched"});


function setUpGrid(pvcData){
    	$("#workorderGrid").jqGrid({
		datatype: 'local',
	 	width:'70px',
	 	mtype: 'POST',
	   	colNames:['woitemId','WoNo','orderno','Od Id','Size','OD','Item','Description',
	   	            'Main Color','Sequence','Stripe Colour','hiddcoil','No. of Coils','hiddnqtypermts',
	   	           'Qty(mts per Coil)','hiddenQty','Quantity(mts)', 'Packing Type', 'Type', 'PVC Grade',
	   	           'Master Batch', 'To be Labelled','Party','Stock In Qty','Stock In Status','Action'],
	   	colModel:[
   	          
   	          {name:'workOrderItemId', index:'workOrderItemId', width:15, viewable:false,hidden:true},
   	          {name:'workOrderNo',index:'workOrderNo', width:5,editable:true,hidden:true},
   	          {name:'orderId',index:'orderId', width:5,editable:true,hidden:true},
   	          {name:'orderDetailId',index:'orderDetailId', width:5,editable:true,hidden:true},
   	          {name:'copperlabel',index:'copperlabel', width:90},
   	          {name:'odLabel',index:'odLabel', width:40},
   	          {name:'itemCode',index:'itemCode', width:10,hidden:true}, 
   	          {name:'itemDescription',index:'itemDescription', width:5,hidden:true}, 
   	          {name:'mainColour',index:'mainColour', width:100},
   	          {name:'mainOrderSequence',index:'mainOrderSequence',width:5,hidden:true},
   	          {name:'innerColour',index:'innerColour', width:100},
   	          {name:'noOfCoils',index:'noOfCoilshiddn', width:5,editable:true,hidden:true},
   	          {name:'noOfCoils',index:'noOfCoils', width:70},
   	          {name:'qtyPerCoil',index:'qtyPerCoilhiddn', width:5,editable:true,hidden:true},
   	          {name:'qtyPerCoil',index:'qtyPerCoil', width:70},
   	          {name:'totalQuantity',index:'totalQuantityhiddn', width:5,editable:true,hidden:true},
   	          {name:'totalQuantity',index:'totalQuantity', width:70},
   	          {name:'packingType',index:'packingType', width:70,editable:true,edittype:'select',editoptions:{value:"Coil:Coil;P.Tube:P.Tube"}},
   	          {name:'cableStd',index:'cableStd', width:50},
              {name:'pvcGrade',index:'pvcGrade', width:70, editable: true,edittype:'select',editoptions:{value:pvcData}},
   	    
   	          {name:'masterBatch',index:'masterBatch', width:70,editable:true},
   	          {name:'toBeLabelled',index:'toBeLabelled', width:10,editable:true,hidden:true},
   	          {name:'customerName',index:'customerName', width:100},
   	          {name:'stockInQty',index:'stockInQty', width:5,editable:true,hidden:true},
   	          {name:'stockInStatus',index:'stockInStatus', width:5,editable:true,hidden:true}, 
   	          {name:'act',index:'act', width:60, viewable:false},
   	   
	   	],
	   	postData: {},
		rowNum:100,
	   	rowList:[5,10,20,30,40,100],
	   	height :500,
		autowidth : true,
		rownumbers : false,
	   	pager: '#pager',
	   	sortname: 'mainColour',
	    viewrecords: true,
	    sortorder: "desc",
	    caption:"Work Order Details",
	    emptyrecords: "Empty records",
	    loadonce: false,
	    loadComplete: function() {},
	    jsonReader : {
	        root: "rows",
	        page: "page",
	        total: "total",
	        records: "records",
	        repeatitems: false,
	        cell: "cell",
	        id: "workOrderItemId"
	    },
	    ondblClickRow : function(id) {
			if (id && id !== lastSelected) {
				$('#workorderGrid').jqGrid('restoreRow',
						lastSelected);
				editRow(id);
				lastSelected = id;
			}
		},
		gridComplete : function() {
			var ids = $("#workorderGrid").jqGrid('getDataIDs');
			for ( var i = 0; i < ids.length; i++) {
				var cl = ids[i];
				be = "<input style='height:22px; width:35px;' type='button' value='Edit' id='editRow"+cl+"' onclick=\"editRow('"+ cl + "');\" />";
				de = "<input style='height:22px; width:30px;' type='button' value='Del' id='delRow"+cl+"' onclick=\"delRow('"+ cl + "');\" />";
				se = "<input style='height:22px; width: 29px;' type='button' value='Save' hidden='hidden' id='saveRow"+cl+"' onclick=\"saveRow('"+ cl + "');\" />";
				ce = "<input style='height:22px;width:39px;' type='button' value='Cancel' hidden='hidden' id='restoreRow"+cl+"' onclick=\"restoreRow('"+ cl + "');\" />";
				$("#workorderGrid").jqGrid('setRowData', ids[i],
				{
					act : be + de + se + ce,
				});
			}
		},
		editurl : "workorder/crud"
	}).navGrid('#pager',{view:false, del:false, edit:false, search:false,add:false}, 
	{}, // use default settings for edit
	{}, // settings for add
	{},  // delete instead that del:false we need this
	{multipleSearch : true}, // enable the advanced searching
	{} /* allow the view dialog to be closed when user press ESC key*/
	);
	
	$("#workorderGrid").jqGrid('navButtonAdd','#pager', {
	    caption:"Import from Excel", 
	    onClickButton : function () {
	    	
	 	 alert("Import from Excel");
	 	 popup();
		    $.ajax({
		        type: 'GET',
		        url: 'workorder/import',
               
		        success: function(response) {
		            alert("success");
		            jQuery("#workorderGrid").setGridParam({datatype:'json'}); 
					jQuery("#workorderGrid").setGridParam({ url : 'workorder/import'});
					jQuery("#workorderGrid").setGridParam({ editurl : 'workorder/crud'});
					jQuery("#workorderGrid").trigger('reloadGrid');
		        },
		        error: function(response) {
		            alert("error");
		        }
		    });
		} 

	});
	
	function popup() { 
		window.open('D:/','name','height=500,width=600');
	} 
	
	 $('#openPopUp').click(function() {
		 popup() ;
    	});
	
	$("#workorderGrid").jqGrid('navButtonAdd','#pager', {
	    caption:"Export to Excel", 
	    onClickButton : function () {
	 	 alert("Export to Excel");
		    var gridData = jQuery("#workorderGrid").getRowData();
		    var postData = JSON.stringify(gridData);
		    //DownloadJSON2CSV(gridData);
		  //  alert("JSON serialized jqGrid data:\n" + postData);
		    $.ajax({
		        type: 'POST',
		        url: 'workorder/export',
		        data : {
		            jgGridData: postData,
		            customData: 'bla bla'
		        },
		        success: function(response) {
		            alert("success");
		        },
		        error: function(response) {
		            alert("error");
		        }
		    });
		} 

	}); 
   }//
   

$("#extrusionWoNoSelect").chosen().change(function() {
	var woNo=$('#extrusionWoNoSelect').val();
	$.ajax({type:'POST', 
		url: 'viewworkorder/fetchWoDetails/'+ encodeURIComponent(woNo),
		success: function(response) {
			document.getElementById('woStartDate').value=response[0]; 
            document.getElementById('woEndDate').value=response[1]; 
            document.getElementById('woMachine').value=response[3];
            document.getElementById('woStatus').value=response[4];
           if(response[4]=="Submitted"){
        	document.getElementById('saveWorkOrderExistWo').disabled=true;
       		document.getElementById('fetchWoItemsExistWo').disabled=true;
       		document.getElementById('addNewItems').disabled=true;
       		document.getElementById('Submit').disabled=true;
           } else{
        		document.getElementById('saveWorkOrderExistWo').disabled=false;
           		document.getElementById('fetchWoItemsExistWo').disabled=false;
           		document.getElementById('addNewItems').disabled=false;
           		document.getElementById('Submit').disabled=false;
              
           }
         jQuery("#workorderGrid").setGridParam({datatype:'json'}); 
   		 jQuery("#workorderGrid").setGridParam({ url: 'workorder/records/'+ encodeURIComponent(woNo)});
   		 jQuery("#workorderGrid").setCaption('Work Order '+woNo+' Details');
   		 jQuery("#workorderGrid").trigger('reloadGrid');

	      }});
        });
   });
   


    
    function editRow(id) {
      	if(submitStatus==false){
    	restoreRow(lastSelected);
    	lastSelected = id;
    	$('#workorderGrid').jqGrid('editRow',id, 
    			{
    				"keys" :true, 
    				"oneditfunc" : hideActButtons,
    				aftersavefunc : function(savedId, response) {
    					showActButtons(savedId);
    				},
    				afterrestorefunc : showActButtons
    			});
    }
    }
    function delRow(id) {
       	if(submitStatus==false){
    	var woNo=document.getElementById('workOrderNoTag').value;
    	 if(confirm("Are you sure you want to delete selected item?")){
    	 	$.ajax({type:'POST', 
    		url: 'workorder/delete/'+ encodeURIComponent(id),
    		success: function(response) {
    			 jQuery("#workorderGrid").setGridParam({datatype:'json'}); 
 				 jQuery("#workorderGrid").setGridParam({ url: 'workorder/records/'+ encodeURIComponent(woNo)});
 				 jQuery("#workorderGrid").trigger('reloadGrid');
 				
		}});
    }}
    }
    function saveRow(id) {
    	$('#workorderGrid').saveRow(id,
    	{	aftersavefunc : function(id, response) {
    				showActButtons(id);
    			}
    	});
    	 jQuery("#workorderGrid").trigger('reloadGrid');
    }

    function restoreRow(id) {
    	$('#workorderGrid').jqGrid('restoreRow',id,
    			{
    				afterrestorefunc : showActButtons
    			});
    }

    /*
     * Hides the Edit and Del Row Buttons on jqGrid
     * and activates the Save and restore(cancel) button
     * 
     */
    function hideActButtons(id){
    	$('#editRow' + id).hide();
    	$('#delRow' + id).hide();
    	$('#saveRow' + id).show();
    	$('#restoreRow' + id).show();
    }

    /*
     * Shows the Edit and Del Row Buttons on jqGrid
     * and hides the Save and restore(cancel) button
     * 
     */
    function showActButtons(id) {
    	$('#editRow' + id).show();
    	$('#delRow' + id).show();
    	$('#saveRow' + id).hide();
    	$('#restoreRow' + id).hide();
    	lastSelected = null;
    }


    function openSalesOrdersPage(workOrderNo) {
    	url = 'viewSOForWO?workOrderNo=' + encodeURIComponent(workOrderNo)+'&reportType='+encodeURIComponent("Extrusion"); 
       	document.getElementById('workOrderNoTag').value=workOrderNo;
    	window.open(url,'_blank');
     }
   
    
    function validateWODetails(){
		 if(document.getElementById('workOrderDate').value==""){
			 alert("Enter Work Order date");
			 return false;
		 }

		 if($("#woMachineNo").val()==""){
			 alert("Enter Machine No");
			 return false;
		 }
		return true;
	 
}
    
    
    function validateAddItem(){
    	var  patroon = /^[+]?([0-9]+(?:[\.][0-9]*)?|\.[0-9]+)$/;
    	var  test = /^[1-9]\d*$/;
    	var qty=document.getElementById('quantity').value;
    	var bundle=document.getElementById('bundleSize').value;
    	
		if(qty==""|| qty==null){
			 alert("Enter Quantity");
			 return false;
		 }
		if(!patroon.test(qty)|| qty==0 ){
			 alert("Enter valid Quantity");
			 document.getElementById('quantity').value="";
			 return false;
		 }
		if(!test.test(bundle)|| bundle==0 ){
			 alert("Enter valid Bundle Size");
			 document.getElementById('bundleSize').value="";
			 return false;
		 }
		if(bundle==""|| bundle==null){
			alert("Enter Bundle Size");
			 return false;
		 }
	return true;
	 
}


function saveWorkOrderDetailsFn(){
	 if($('input:radio[name=workOrderSelect]:checked').val()==0){
	  var validateWOResult=validateWODetails();
		if(validateWOResult==true){
			if(document.getElementById('workOrderNoTag').value==""){
			$.ajax({type:'POST', 
				url: 'workorder/saveworkorder', 
				data:'workOrderDate=' + $("#workOrderDate").val() + 
				     '&workOrderTime=' + $("#woTime").val() + 
           		 '&completionDate=' + $("#woCompletionDate").val() + 
       			 '&completionTime=' + $("#woCompletionTime").val() +
            	 '&machineNo=' + $("#woMachineNo").val(),
				success: function(response) {
					 $('#extrusionWoNoSelect').append('<option>'+response[0]+'</option>');
					 $('#extrusionWoNoSelect').trigger('liszt:updated');
					
				openSalesOrdersPage(response[0]) ;
		}});
	}
			else{	
				openSalesOrdersPage(document.getElementById('workOrderNoTag').value) ;
			}
		};//end of if validate
	 }// save new work order
	 else{
		 var existWoNo= $('#extrusionWoNoSelect').val();
		 if(existWoNo!="" && existWoNo!=null){
			 openSalesOrdersPage(existWoNo); 
		 }else{
			 alert("Select Work Order No");
		 }
	 }
	}





function fetchWoItemsFn(){
		var woNo=document.getElementById('workOrderNoTag').value;
		 if(woNo!=null &&  woNo!=""){
	     jQuery("#workorderGrid").setGridParam({datatype:'json'}); 
		 jQuery("#workorderGrid").setGridParam({ url: 'workorder/records/'+ encodeURIComponent(woNo)});
		 jQuery("#workorderGrid").setCaption('Work Order '+woNo+' Details');
		 jQuery("#workorderGrid").trigger('reloadGrid');
		}  
}
function openOrderItemsPopUp(id) { 
	var grid = jQuery('#workorderGrid'); 
	var customerName = grid.jqGrid ('getCell', id, 'customerName'); 
	var itemDescription= grid.jqGrid ('getCell', id, 'itemDescription'); 
	var quantity= grid.jqGrid ('getCell', id, 'totalQuantity'); 
	var itemCode= grid.jqGrid ('getCell', id, 'itemCode'); 
	var woNo=document.getElementById('workOrderNoTag').value; 
	var orderId=grid.jqGrid ('getCell', id, 'orderId'); 
	var noOfCoils=grid.jqGrid ('getCell', id ,'noOfCoils');
	url = 'labeltest?woNo=' + encodeURIComponent(woNo)+'&itemCode='+ encodeURIComponent(itemCode)+'&quantity='+ encodeURIComponent(quantity)+'&orderId='+encodeURIComponent(orderId)+'&customerName='+encodeURIComponent(customerName)+'&itemDescription='+encodeURIComponent(itemDescription)+'&noOfCoils='+encodeURIComponent(noOfCoils); 
	window.open(url, '_blank'); 
	
  }

function addNewItemsFn(){
	 if($('input:radio[name=workOrderSelect]:checked').val()==0){
		var validation=validateWODetails();
	    var validateItem=validateAddItem();
	    if(validation==true && validateItem==true){
	    var woNo=document.getElementById('workOrderNoTag').value;
	    var itemCode=document.getElementById('itemIdSelect').value;
	    if(woNo==""){
		$.ajax({type:'POST', 
			url: 'workorder/saveworkorder', 
			data:'workOrderDate=' + $("#workOrderDate").val() + 
			     '&workOrderTime=' + $("#woTime").val() + 
       		     '&completionDate=' + $("#woCompletionDate").val() + 
   			     '&completionTime=' + $("#woCompletionTime").val() +
        	     '&machineNo=' + $("#woMachineNo").val(),
			success: function(response) {
			    document.getElementById('workOrderNoTag').value=response;
				 $('#extrusionWoNoSelect').append('<option>'+response+'</option>');
				 $('#extrusionWoNoSelect').trigger('liszt:updated');
		
				woNo=document.getElementById('workOrderNoTag').value;
				var quantity=document.getElementById('quantity').value;
				var bundleSize=document.getElementById('bundleSize').value;
				if(itemCode!=""){
					$.ajax({
						type:'POST',
						url: 'workorder/checkDummyWoItemExist',
						data:{"woNo":woNo,"itemCode":itemCode},
						success: function(response) {
                          if(response=="Exist"){
                        	  alert("Item already exist for the work oder No:"+woNo);
                          }else{
                        		$.ajax({
                					type:'POST',
                					url: 'workorder/createDummySO?woNo='+encodeURIComponent(woNo)+'&itemCode='+ encodeURIComponent(itemCode)+'&quantity='+encodeURIComponent(quantity)+'&bundleSize='+encodeURIComponent(bundleSize),
                					success: function(response) {
                						     jQuery("#workorderGrid").setGridParam({datatype:'json'}); 
                							 jQuery("#workorderGrid").setGridParam({ url: 'workorder/records/'+ encodeURIComponent(woNo)});
                							 jQuery("#workorderGrid").setCaption('Work Order '+woNo+' Details');
                							 jQuery("#workorderGrid").trigger('reloadGrid');
               						
                				}});
                           }
							
					}});
	
					
							
				
				}
				else{
					alert("Select Item to add to Work Order");
				}
				
	}});	
	}
	else{
	woNo=document.getElementById('workOrderNoTag').value;
	var quantity=document.getElementById('quantity').value;
	var bundleSize=document.getElementById('bundleSize').value;
	if(itemCode!=""){
		$.ajax({
			type:'POST',
			url: 'workorder/checkDummyWoItemExist',
			data:{"woNo":woNo,"itemCode":itemCode},
			success: function(response) {
              if(response=="Exist"){
            	  alert("Item already exist for the work oder No:"+woNo);
              }else{
            		$.ajax({
    					type:'POST',
    					url: 'workorder/createDummySO?woNo='+encodeURIComponent(woNo)+'&itemCode='+ encodeURIComponent(itemCode)+'&quantity='+encodeURIComponent(quantity)+'&bundleSize='+encodeURIComponent(bundleSize),
    					success: function(response) {
    						     jQuery("#workorderGrid").setGridParam({datatype:'json'}); 
    							 jQuery("#workorderGrid").setGridParam({ url: 'workorder/records/'+ encodeURIComponent(woNo)});
    							 jQuery("#workorderGrid").setCaption('Work Order '+woNo+' Details');
    							 jQuery("#workorderGrid").trigger('reloadGrid');
   						
    				}});
               }
				
		}});
	}
	else{
		alert("select Item to add to the Work Order");
	}
	}
	}
}else{
	 var existWoNo= $('#extrusionWoNoSelect').val();
	 if(existWoNo!=null && existWoNo!=""){
		    var itemCode=document.getElementById('itemIdSelect').value;
		    var validateItem=validateAddItem();
		    if(validateItem==true){
			var quantity=document.getElementById('quantity').value;
			var bundleSize=document.getElementById('bundleSize').value;
			if(itemCode!=""){
				$.ajax({
					type:'POST',
					url: 'workorder/checkDummyWoItemExist',
					data:{"woNo":existWoNo,"itemCode":itemCode},
					success: function(response) {
                      if(response=="Exist"){
                    	  alert("Item already exist for the work oder No:"+existWoNo);
                      }else{
                    		$.ajax({
            					type:'POST',
            					url: 'workorder/createDummySO?woNo='+encodeURIComponent(existWoNo)+'&itemCode='+ encodeURIComponent(itemCode)+'&quantity='+encodeURIComponent(quantity)+'&bundleSize='+encodeURIComponent(bundleSize),
            					success: function(response) {
            						     jQuery("#workorderGrid").setGridParam({datatype:'json'}); 
            							 jQuery("#workorderGrid").setGridParam({ url: 'workorder/records/'+ encodeURIComponent(existWoNo)});
            							 jQuery("#workorderGrid").setCaption('Work Order '+existWoNo+' Details');
            							 jQuery("#workorderGrid").trigger('reloadGrid');
           						
            				}});
                       }
						
				}});
    		}else{
				alert("Select Item to add to Work Order");
			}
		    }
		 
	 }else{
		 alert("Select work order No");
	 }
}
}


function submitFn(){
	 var woNo=null;
  if($('input:radio[name=workOrderSelect]:checked').val()==0){
  woNo=document.getElementById('workOrderNoTag').value;
  }else{
	  woNo= $('#extrusionWoNoSelect').val(); 
  }
    var rowCount=jQuery("#workorderGrid").getGridParam("reccount");
    if (confirm("Do you want to submit Work Order?")){     
    if(woNo!=null && woNo!="" && rowCount>0 ){
     $.ajax({
		type:'POST',
		url: 'workorder/submitWorkOrder/'+encodeURIComponent(woNo),
		success: function(response) {
			  alert("Work Order No -"+woNo+"  is submitted");
			  if($('input:radio[name=workOrderSelect]:checked').val()==0){
		    	document.getElementById('saveWorkOrderNewWo').disabled=true;
	       		document.getElementById('fetchWoItemsNewWo').disabled=true;
			  }else{
				 	document.getElementById('saveWorkOrderExistWo').disabled=true;
		       		document.getElementById('fetchWoItemsExistWo').disabled=true;
				  
			  }
	       		document.getElementById('addNewItems').disabled=true;
	       		document.getElementById('Submit').disabled=true;
	       	    submitStatus=true;
		   	}});
   }
    else submitStatus=false;
    
    } 
    else submitStatus=false;
}

	


$(document).keypress(function(e) {
	   if (e.which == 13) {
			var ids = $("#workorderGrid").jqGrid('getDataIDs');
			for ( var i = 0; i < ids.length; i++) {
				var cl = ids[i];  
				saveRow(cl);
	   }
  }
});


