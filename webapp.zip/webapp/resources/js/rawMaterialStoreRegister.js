var lastSelected;
$(function() {
	
	
	$.ajax({type:'POST', 
		url: 'rawMaterailStoreRegister/fetchStoreItems',
		success: function(response) {
			if(response.length != 0){
				for(var i=0;i< response.length;i++){
					$('#itemIdSelect').append('<option selected="selected">'+ "" + '</option>');
					$('#itemIdSelect').append('<option >' + response[i]+ '</option>');
					$('#itemIdSelect').trigger('liszt:updated');
				}
			}
	}});
	
	
	
	
	$("#itemIdSelect").chosen({no_results_text : "No results matched"});
	
	$( "#stockDate" ).datepicker({dateFormat : "dd-mm-yy",maxDate:'today'});

	$("#rawMaterialStoreRegisterGrid").jqGrid(
					{
						url : 'rawMaterailStoreRegister/records',
						datatype : 'json',
						mtype : 'POST',
						
						colNames : [ 'Rw Store Reg Id', 'Purchase Order Item Id', 
							 'PartyHidden','Party', 'Item Id', 'Item Code',
								'Item Description', 'Stock In date Time','Gross Weight',
								'Tare Weight', 'Net Weight', 'No Of Bags',
								'Total Quantity', 'Batch No','QC Status'],
						colModel : [ {
							name : 'rwStoreRegId',
							index : 'rwStoreRegId',
							width : 5,
							viewable : false,
							hidden : true
						}, {
							name : 'purchaseOrderItemId',
							index : 'purchaseOrderItemId',
							width : 5,
							viewable : false,
							hidden : true
						}, 
						{
							name : 'customerName',
							index : 'customerName',
							width : 180,
							hidden:true
						},
						{
							name : 'customerCode',
							index : 'customerCode',
							width : 60
						},
						{
							name : 'itemId',
							index : 'itemId',
							width : 5,
							hidden : true
						}, {
							name : 'itemCode',
							index : 'itemCode',
							width : 130	
						}, {
							name : 'itemDescription',
							index : 'itemDescription',
							width : 150
						},{
							name : 'dateTime',
							index : 'dateTime',
							width : 100
						}, {
							name : 'grossWeight',
							index : 'grossWeight',
							width : 50
						}, {
							name : 'tareWeight',
							index : 'tareWeight',
							width : 50
						}, {
							name : 'netWeight',
							index : 'netWeight',
							width : 50
						}, {
							name : 'noOfBags',
							index : 'noOfBags',
							width : 10,
							hidden : true
						}, {
							name : 'totalQty',
							index : 'totalQty',
							width : 50
						}, {
							name : 'batchNo',
							index : 'batchNo',
							width : 50
						},{
							name : 'qcStatus',
							index : 'qcStatus',
							width :50
						}

						],
						postData : {},
						rowNum : 100,
						rowList : [ 5, 10, 20, 30, 40, 100 ],
						height : 300,
						autowidth : true,
						rownumbers : false,
						pager : '#rawMaterialStoreRegisterPager',
						sortname : 'rwStoreRegId',
						viewrecords : true,
						sortorder : "desc",
						caption : "Raw Material Store Registry",
						  emptyrecords: "Empty records",
						    loadonce: false,
						    footerrow : true,
						    
						    loadComplete: function() {},
						    jsonReader : {
						        root: "rows",
						        page: "page",
						        total: "total",
						        records: "records",
						        repeatitems: false,
						        cell: "cell",
							id : "rwStoreRegId"
						},
						
						gridComplete : function() {}

      	});
	jQuery("#rawMaterialStoreRegisterGrid").jqGrid('navGrid', '#rawMaterialStoreRegisterPager', {
		view : false,
		del : false,
		add : false,
		edit : false,
		search : false
	});

});


/*$("#itemIdSelect").chosen().change(function() {
	var itemIdSelect = document.getElementById('itemIdSelect').value;
	jQuery("#rawMaterialStoreRegisterGrid").setGridParam({datatype : 'json'});
	jQuery("#rawMaterialStoreRegisterGrid").setGridParam({url : 'rawMaterailStoreRegister/searchItem'});
	jQuery("#rawMaterialStoreRegisterGrid").setGridParam({postData: {itemIdSelect:itemIdSelect}});
	jQuery("#rawMaterialStoreRegisterGrid").trigger('reloadGrid');
});*/

/*function resetValues() {
	
	alert("hiiiiiiiiiiiiiii");
	if ($("#itemIdSelect").val() != "") {
		document.getElementById('itemIdSelect').value = "";
		$('#itemIdSelect').trigger('liszt:updated');
	
	
		jQuery("#rawMaterialStoreRegisterGrid").setGridParam({datatype : 'json'});
		jQuery("#rawMaterialStoreRegisterGrid").setGridParam({url : 'rawMaterailStoreRegister/records'});
		jQuery("#rawMaterialStoreRegisterGrid").trigger('reloadGrid');
		
		if (document.getElementById('stockDate').value != "")
			document.getElementById('stockDate').value = "";

		jQuery("#rawMaterialStoreRegisterGrid").setGridParam({datatype : 'json'});
		jQuery("#rawMaterialStoreRegisterGrid").setGridParam({ url: 'rawMaterailStoreRegister/searchByDate'});
		jQuery("#rawMaterialStoreRegisterGrid").setGridParam({postData : {stockDate : ""}});
		jQuery("#rawMaterialStoreRegisterGrid").trigger('reloadGrid');		

	}
}
*/

$('#searchButton').click(function() {
	var validSearch=validateSearchParams();
	if(validSearch==true){
		var itemCode="";
		var stockDate="";
		var gridCaption="";
		if(document.getElementById('stockDate').value!="" && document.getElementById('stockDate').value!=null)
			stockDate=document.getElementById('stockDate').value;
		if(document.getElementById('itemIdSelect').value!="" && document.getElementById('itemIdSelect').value!=null)
			itemCode=document.getElementById('itemIdSelect').value;
		 if(stockDate!="" && stockDate!=null && itemCode!=null && itemCode!="")
			 gridCaption='Stock of '+itemCode+' As On:'+stockDate;
		 else if(stockDate!="" && stockDate!=null)
			 gridCaption='Stock As On '+stockDate;
		 else
			 gridCaption='Stock Of '+itemCode;
		   jQuery("#rawMaterialStoreRegisterGrid").setGridParam({datatype:'json'}); 
	  	   jQuery("#rawMaterialStoreRegisterGrid").setGridParam({ url: 'rawMaterailStoreRegister/searchByDate'});
	  	   jQuery("#rawMaterialStoreRegisterGrid").setGridParam({postData: {stockDate:stockDate,itemCode:itemCode}}); 
	  	   jQuery("#rawMaterialStoreRegisterGrid").setCaption(gridCaption);
	  	   jQuery("#rawMaterialStoreRegisterGrid").trigger('reloadGrid');
	
	} 	
});
function validateSearchParams(){
	
	var stockDate=document.getElementById('stockDate').value;
	var itemCode=document.getElementById('itemIdSelect').value;
     if((stockDate==null || stockDate=="") && (itemCode==null ||itemCode==""))
    	alert("select any of the search parameters");
    else return true;
}

$('#resetBtn').click(function() {
	
	if ($("#itemIdSelect").val() != "") {
		document.getElementById('itemIdSelect').value = "";
		$('#itemIdSelect').trigger('liszt:updated');
	}
	
	if (document.getElementById('stockDate').value != "")
		document.getElementById('stockDate').value = "";

	jQuery("#rawMaterialStoreRegisterGrid").setGridParam({datatype : 'json'});
	jQuery("#rawMaterialStoreRegisterGrid").setGridParam({ url: 'rawMaterailStoreRegister/searchByDate'});
	jQuery("#rawMaterialStoreRegisterGrid").setGridParam({postData : {stockDate : "",itemCode:""}});
	 jQuery("#rawMaterialStoreRegisterGrid").setCaption("Raw Material Store Registry");
	jQuery("#rawMaterialStoreRegisterGrid").trigger('reloadGrid');

});




