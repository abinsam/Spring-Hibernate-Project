var lastSelected;
$(function() {
		
	$("#itemIdSelect").chosen({no_results_text : "No results matched"});
	$.ajax({type:'POST', 
		url: 'rawMaterialStoreRegisterForQc/fetchStoreRawMaterialItems',
		success: function(response) {
			if(response.length != 0){
				for(var i=0;i< response.length;i++){
					$('#itemIdSelect').append('<option selected="selected">'+ "" + '</option>');
					$('#itemIdSelect').append('<option >' + response[i]+ '</option>');
					$('#itemIdSelect').trigger('liszt:updated');
				}
			}
	}});
	
	$("#rawMaterialStoreRegisterGrid").jqGrid(
					{
						url : 'rawMaterialStoreRegisterForQc/records',
						datatype : 'json',
						mtype : 'POST',
						multiselect : true,
						
						colNames : [ 'Rw Store Reg Id', 'Purchase Order Item Id', 
							 'PartyHidden','Party', 'Item Id', 'Item Code',
								'Item Description', 'Gross Weight',
								'Tare Weight', 'Net Weight', 'No Of Bags',
								'Total Quantity', 'Batch No','QC Status'],
						colModel : [ {
							name : 'rwStoreRegId',
							index : 'rwStoreRegId',
							width : 5,
							viewable : false,
							hidden : true
						}, {
							name : 'purchaseOrderItemId',
							index : 'purchaseOrderItemId',
							width : 5,
							viewable : false,
							hidden : true
						}, 
						{
							name : 'customerName',
							index : 'customerName',
							width : 90,
							hidden : true
						},
						{
							name : 'customerCode',
							index : 'customerCode',
							width : 60
						},
						{
							name : 'itemId',
							index : 'itemId',
							width : 5,
							hidden : true
						}, {
							name : 'itemCode',
							index : 'itemCode',
							width : 160
						}, {
							name : 'itemDescription',
							index : 'itemDescription',
							width : 260
						}, {
							name : 'grossWeight',
							index : 'grossWeight',
							width : 70
						}, {
							name : 'tareWeight',
							index : 'tareWeight',
							width : 40
						}, {
							name : 'netWeight',
							index : 'netWeight',
							width : 70
						}, {
							name : 'noOfBags',
							index : 'noOfBags',
							width : 10,
							hidden : true
						}, {
							name : 'totalQty',
							index : 'totalQty',
							width : 60
						}, {
							name : 'batchNo',
							index : 'batchNo',
							width : 60
						},{
							name : 'qcStatus',
							index : 'qcStatus',
							width : 60
						},
						

						],
						postData : {},
						rowNum : 100,
						rowList : [ 5, 10, 20, 30, 40, 100 ],
						height : 300,
						autowidth : true,
						rownumbers : false,
						pager : '#rawMaterialStoreRegisterPager',
						sortname : 'rwStoreRegId',
						viewrecords : true,
						sortorder : "desc",
						caption : "Raw Material Store Registry",
						  emptyrecords: "Empty records",
						    loadonce: false,
						    footerrow : true,
						    
						    loadComplete: function() {},
						    jsonReader : {
						        root: "rows",
						        page: "page",
						        total: "total",
						        records: "records",
						        repeatitems: false,
						        cell: "cell",
							id : "rwStoreRegId"
						},
						onSelectRow : function(aRowids, status){
							updateIdsOfSelectedRows(aRowids, status);
						},
						onSelectAll : function(aRowids, status) {
							updateIdsOfAllSelectedRows(aRowids, status);
						},
						gridComplete : function() {}

      	});
	jQuery("#rawMaterialStoreRegisterGrid").jqGrid('navGrid', '#rawMaterialStoreRegisterPager', {
		view : false,
		del : false,
		add : false,
		edit : false,
		search : false
	});

});


$("#itemIdSelect").chosen().change(function() {
	var itemIdSelect = document.getElementById('itemIdSelect').value;
	jQuery("#rawMaterialStoreRegisterGrid").setGridParam({datatype : 'json'});
	jQuery("#rawMaterialStoreRegisterGrid").setGridParam({url : 'rawMaterialStoreRegisterForQc/searchItem'});
	jQuery("#rawMaterialStoreRegisterGrid").setGridParam({postData: {itemIdSelect:itemIdSelect}});
	jQuery("#rawMaterialStoreRegisterGrid").trigger('reloadGrid');
});



function resetValues() {
	if ($("#itemIdSelect").val() != "") {
		document.getElementById('itemIdSelect').value = "";
		$('#itemIdSelect').trigger('liszt:updated');
		jQuery("#rawMaterialStoreRegisterGrid").setGridParam({datatype : 'json'});
		jQuery("#rawMaterialStoreRegisterGrid").setGridParam({url : 'rawMaterialStoreRegisterForQc/records'});
		jQuery("#rawMaterialStoreRegisterGrid").trigger('reloadGrid');

	}
	if (document.getElementById('remarks').value != "")
		document.getElementById('remarks').value = "";
}
idsOfSelectedRows = [ "3", "4", "5" ];
var storeRegisterGrid = $("#rawMaterialStoreRegisterGrid"), idsOfSelectedRows = [], updateIdsOfSelectedRows = function(
		id, isSelected) {
	
	var index = $.inArray(id, idsOfSelectedRows);
	
	if (!isSelected && index >= 0) {
		idsOfSelectedRows.splice(index, 1); // remove id from the list
	} else if (index < 0) {
		idsOfSelectedRows.push(id);
	}
};
updateIdsOfAllSelectedRows = function(aRowids, isSelected) {
	for (i = 0, count = aRowids.length; i < count; i++) {
		id = aRowids[i];
		var index = $.inArray(id, idsOfSelectedRows);
		if (!isSelected && index >= 0) {
			idsOfSelectedRows.splice(index, 1); // remove id from the list
		} else if (index < 0) {
			idsOfSelectedRows.push(id);
		}
	}
};
$('#approve').click(function() {
	var remarks = $('#remarks').val();
	var status="Approved";
	
	if(remarks!=null && remarks!="" && idsOfSelectedRows.length!=0){
		if(confirm("Do you want to Submit the Items?")){
	$.ajax({
		type : 'POST',
		url : 'rawMaterialStoreRegisterForQc/approveOrRejectQC',
		data : {
			'remarks' : remarks,
			'status':status,
			'idsOfSelectedRows' : idsOfSelectedRows
			
		},
		success : function(response) {
			
			idsOfSelectedRows=[];
			 jQuery("#rawMaterialStoreRegisterGrid").setGridParam({datatype:'json'}); 
			 jQuery("#rawMaterialStoreRegisterGrid").setGridParam({ url: 'rawMaterialStoreRegisterForQc/records'});
			 jQuery("#rawMaterialStoreRegisterGrid").trigger('reloadGrid');
				document.getElementById('itemIdSelect').value="";
				$('#itemIdSelect').trigger('liszt:updated');
				 alert("Selected Items QC status  Updated");

		}
	});
	}
	}
	 if(remarks==null || remarks==""){
		
		alert("Please Enter Remarks");
	}
 if(idsOfSelectedRows.length==0){
		
		alert("Please select items");
	}
});

$('#sendToScrap').click(function() {
	var remarks = $('#remarks').val();
	var status="Scrap";
	
	if(remarks!=null && remarks!="" && idsOfSelectedRows.length!=0){
		if(confirm("Do you want to Submit the Items?")){
	$.ajax({
		type : 'POST',
		url : 'rawMaterialStoreRegisterForQc/approveOrRejectQC',
		data : {
			'remarks' : remarks,
			'status':status,
			'idsOfSelectedRows' : idsOfSelectedRows
			
		},
		success : function(response) {
			
			idsOfSelectedRows=[];
			 jQuery("#rawMaterialStoreRegisterGrid").setGridParam({datatype:'json'}); 
			 jQuery("#rawMaterialStoreRegisterGrid").setGridParam({ url: 'rawMaterialStoreRegisterForQc/records'});
			 jQuery("#rawMaterialStoreRegisterGrid").trigger('reloadGrid');
				document.getElementById('itemIdSelect').value="";
				$('#itemIdSelect').trigger('liszt:updated');
				 alert("Selected Items QC status  Updated");
		}
	});
	}
	}
	 if(remarks==null || remarks==""){
		
		alert("Please Enter Remarks");
	}
 if(idsOfSelectedRows.length==0){
		
		alert("Please select items");
	}
});

$('#sendToRework').click(function() {
	var remarks = $('#remarks').val();
	var status="Rework";
	
	if(remarks!=null && remarks!="" && idsOfSelectedRows.length!=0){
		if(confirm("Do you want to Submit the Items?")){
	$.ajax({
		type : 'POST',
		url : 'rawMaterialStoreRegisterForQc/approveOrRejectQC',
		data : {
			'remarks' : remarks,
			'status':status,
			'idsOfSelectedRows' : idsOfSelectedRows
			
		},
		success : function(response) {
			
			idsOfSelectedRows=[];
			 jQuery("#rawMaterialStoreRegisterGrid").setGridParam({datatype:'json'}); 
			 jQuery("#rawMaterialStoreRegisterGrid").setGridParam({ url: 'rawMaterialStoreRegisterForQc/records'});
			 jQuery("#rawMaterialStoreRegisterGrid").trigger('reloadGrid');
			
				document.getElementById('itemIdSelect').value="";
				$('#itemIdSelect').trigger('liszt:updated');
				 alert("Selected Items QC status  Updated");
		}
	});
	}
	}
	 if(remarks==null || remarks==""){
		
		alert("Please Enter Remarks");
	}
 if(idsOfSelectedRows.length==0){
		
		alert("Please select items");
	}
});
