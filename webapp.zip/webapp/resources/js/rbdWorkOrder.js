var lastSelected;
var systemDate = new Date();
var month="";
var year="";
var netLengthValid=true;
var grossWeightValid=true;
var tareWeightValid=true;

$("#loading").dialog({
    hide: 'slide',
    show: 'slide',
    autoOpen: false
});

$(function(){ 

	$("#monthYearPicker").focus(function () {$(".ui-datepicker-calendar").hide();});
	$('#monthYearPicker').datepicker({
	
        changeYear: true,
        changeMonth: true,
        changeDate :false,
        showButtonPanel: true,
        dateFormat: 'MM yy',
       
        onClose: function(dateText, inst) { 
            var year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
            var month = $("#ui-datepicker-div .ui-datepicker-month :selected").val();
            $(this).datepicker('setDate', new Date(year,month, 1));
            populateRbdWorkOrderNo();
        }
    });

$('#monthYearPicker').datepicker('setDate',systemDate); 
$("#monthYearPicker").focus(function () {$(".ui-datepicker-month").show();});
$("#monthYearPicker").focus(function () {$(".ui-datepicker-year").show();});
	
	$("#rbdWorkOrderNoSelect").chosen({no_results_text: "No results matched"});
	$("#itemIdSelect").chosen({no_results_text: "No results matched"});
	$( "#rbdStartDate" ).datepicker({dateFormat : "dd-mm-yy",
     	      
                onSelect: function(dateStr)
                {
                var min = $('#rbdStartDate').datepicker('getDate'); 
                 $('#rbdCompletionDate').datepicker('option', {minDate : min});
          }});
    $( "#rbdCompletionDate" ).datepicker({dateFormat : "dd-mm-yy"});
    $("#rbdWoInputGrid").jqGrid(
			{
				datatype : 'local',
				mtype : 'POST',
				//url:'rawMaterialStoreRegister/getPoItemDetails',
				colNames:['Id','Vendor code','Vendor Name','Item Description','Gross Weight(Kgs)','Tare Weight(Kgs)','Net Weight(Kgs)','Batch No','No Of Bags','Qty Per Bag','Total Qty','Units'],
				colModel:[
				   	    
				              {name:'rbdWoInputId', index:'rbdWoInputId', width:10,hidden:true},   
				              {name:'customerCode', index:'customerCode', width:10,hidden:true}, 
					          {name:'customerName', index:'customerName', width:130},
					          {name:'itemDescription', index:'itemDescription', width:80},
					          {name:'grossWeight',index:'grossWeight', width:60},
					          {name:'tareWeight',index:'tareWeight', width:60},
					          {name:'netWeight',index:'netWeight', width:60},
					          {name:'batchNo',index:'batchNo', width:50},
					          {name:'noOfBags',index:'noOfBags', width:50},
					          {name:'qtyPerBag',index:'qtyPerBag', width:50},
					          {name:'totalQty',index:'totalQty', width:50},
					          {name:'units',index:'units', width:20},
					          
				   	       ],
	            postData : {},
				rowNum : 100,
				rowList : [ 5, 10, 20, 40, 60,100 ],
				height : 100,
				autowidth : true,
				rownumbers : false,
				   	pager: '#rbdWoInputpager',
				   	sortname: 'rbdWoInputId',
				    viewrecords: true,
				    sortorder: "desc",
				    caption:"Raw Materials Stock",
				    emptyrecords: "Empty records",
				    loadonce: false,
				    footerrow: true,
				    loadComplete: function() {},
				    jsonReader : {
				        root: "rows",
				        page: "page",
				        total: "total",
				        records: "records",
				        repeatitems: false,
				        cell: "cell",
				        id: "rbdWoInputId"
				    },
				      gridComplete: function(){ 
				    	     var grossWeightValue = $('#rbdWoInputGrid').jqGrid('getCol','grossWeight',false,'sum');
					   		 var tareWeightValue = $('#rbdWoInputGrid').jqGrid('getCol','tareWeight',false,'sum');
					   		 var netWeightValue = $('#rbdWoInputGrid').jqGrid('getCol','netWeight',false,'sum');
					   		 var bagNoValue = $('#rbdWoInputGrid').jqGrid('getCol','noOfBags',false,'sum');
					   		 var quantityValue = $('#rbdWoInputGrid').jqGrid('getCol','totalQty',false,'sum');
		
					   	   	  var totalGrossWeight=Math.round(parseFloat(grossWeightValue) * 100)/100;
		        	   	 	  var totalTareWeight=Math.round(parseFloat(tareWeightValue) * 100)/100;
		        	   	 	  var totalNetWeight=Math.round(parseFloat(netWeightValue) * 100)/100;
		                      var totalBag=Math.round(parseFloat(bagNoValue) * 100)/100; 
		                      var totalQuantity=Math.round(parseFloat(quantityValue) * 100)/100; 
		 
					   		$('#rbdWoInputGrid').jqGrid('footerData','set', {ID: 'Total:', grossWeight: totalGrossWeight});
				   	    	$('#rbdWoInputGrid').jqGrid('footerData','set', {ID: 'Total:', tareWeight: totalTareWeight});
				   	    	$('#rbdWoInputGrid').jqGrid('footerData','set', {ID: 'Total:', netWeight: totalNetWeight});
				   	    	$('#rbdWoInputGrid').jqGrid('footerData','set', {ID: 'Total:', noOfBags: totalBag});
				   	    	$('#rbdWoInputGrid').jqGrid('footerData','set', {ID: 'Total:', totalQty: totalQuantity});
				   	    	$('#rbdWoInputGrid').jqGrid('footerData','set', {ID: 'Total:', units: "Kgs"});
				   	 
					   	
				      }
					
			}).navGrid('#rbdWoInputpager',{view:false, del:false, edit:false, search:false,add:false},
					  {}, // use default settings for edit
				    	{}, // settings for add
				    	{},  // delete instead that del:false we need this
				    	{multipleSearch : true}, // enable the advanced searching
				    	{} /* allow the view dialog to be closed when user press ESC key*/
				    	);

  
  
    $("#rbdWorkOrderNoSelect").chosen().change( function(){
    	 var woNo = $('#rbdWorkOrderNoSelect').val();
    	 jQuery("#rbdWoInputGrid").setCaption('Input For RBD Work Order"' + woNo + '"');
 		$.ajax({type:'POST', 
 			url: 'storeRegisterForRBD/fetchWoDetails/'+ encodeURIComponent(woNo),
 			success: function(response) {
 				                 
 			  	 document.getElementById('rbdStartDate').value=response[0]; 
                 document.getElementById('rbdCompletionDate').value=response[1]; 
                 document.getElementById('rbdMachineNo').value=response[2];
                 document.getElementById('rbdInputWeight').value=response[3];
                 document.getElementById('rbdOutputWeight').value=response[5];
                 document.getElementById('rbdWorkOrderStatus').value=response[6];
                 
                 jQuery("#rbdWoInputGrid").setGridParam({datatype:'json'}); 
				 jQuery("#rbdWoInputGrid").setGridParam({ url: 'storeRegisterForRBD/rbdRecords/'+ encodeURIComponent(woNo)});
				 jQuery("#rbdWoInputGrid").trigger('reloadGrid');
				 jQuery("#rbdWoOutputGrid").setGridParam({datatype:'json'}); 
				 jQuery("#rbdWoOutputGrid").setGridParam({ url: 'storeRegisterForRBD/rbdOutputRecords/'+ encodeURIComponent(woNo)});
				 jQuery("#rbdWoOutputGrid").setCaption('Receipt From Production of RBD Work Order'+ woNo);
				 jQuery("#rbdWoOutputGrid").trigger('reloadGrid');
				
				 $.ajax({type:'POST', 
				 		url: 'storeRegisterForRBD/itemCodeList/'+ encodeURIComponent(woNo),
						success: function(response) {
						
							$('#itemIdSelect').empty();
						
							 for ( var i = 0; i < response.length; i++) {
									$('#itemIdSelect').append(
											'<option selected="selected">'
													+ "" + '</option>');
									$('#itemIdSelect').append(
											'<option >' + response[i]
													+ '</option>');
									$('#itemIdSelect').trigger(
											'liszt:updated');
								}

					}}); 
				 
				 
					 
                 if(response[6]=="Submitted"){
                		document.getElementById('addBtn').disabled=true;  	
                		document.getElementById('sizeSelect').disabled=true;
						document.getElementById('netLength').disabled=true;
						document.getElementById('grossWeight').disabled=true;
						document.getElementById('tareWeight').disabled=true;
						document.getElementById('submitRBDWorkOrder').disabled=true;
				 
                 }
                 else{
                		document.getElementById('addBtn').disabled=false;  	
                		document.getElementById('sizeSelect').disabled=false;
						document.getElementById('netLength').disabled=false;
						document.getElementById('grossWeight').disabled=false;
						document.getElementById('tareWeight').disabled=false;
						document.getElementById('submitRBDWorkOrder').disabled=false;
				 
        
                 }

            	 

		
 			
 		}});
 		
 	
    });
    
			
$("#rbdWoOutputGrid").jqGrid({
	//url: 'storeRegisterForRBD/rbdOutputRecords',
	datatype: 'local',
	  mtype: 'POST',
	 	    colNames:['Id','So ItemId','Work Order No','Batch No','Size','Size hiddn','batch','Net Length(m)','Gross Weight(Kgs)','Tare Weight(Kgs)','Net Weight(Kgs)','Stocked In Status','Stocked In Status','Stock In','Srcap Details','Actions'],
	   	colModel:[
   	          {name:'woOutPutId', index:'woOutPutId', width:10,hidden:true},
   	          {name:'orderDetailId', index:'orderDetailId', width:10,editable:true,hidden:true},
   	          {name:'workOrderNo', index:'workOrderNo', width:10,hidden:true,editable:true},
   	          {name:'batchNo',index:'batchNo', width:40},
   	          {name:'size',index:'size', width:60},
   	          {name:'size',index:'size', width:10,editable:true,hidden:true},
   	          {name:'batchNo',index:'batchNo', width:60,editable:true,hidden:true},
   	          {name:'netLength',index:'netLength', width:30,editable:true,editoptions:{
                  dataInit: function(element) {
                      $(element).keyup(function(){
                          var val1 = element.value;
                          var num = new Number(val1);
                          if(isNaN(num))
                          {
                        	  alert("Please enter valid length");
                        	  netLengthValid=false;
                        	  jQuery("#rbdWoOutputGrid").trigger('reloadGrid');
                         }
                          else
                        	  netLengthValid=true;
                        
                      });
                  }
   	      ,maxlength:8
              }},
   	          {name:'grossWeight',index:'grossWeight', width:40,editable:true,editoptions:{
                  dataInit: function(element) {
                      $(element).keyup(function(){
                          var val1 = element.value;
                          var num = new Number(val1);
                          if(isNaN(num))
                          {
                        	  alert("Please enter valid Gross Weight");
                        	  grossWeightValid=false;
                        	  jQuery("#rbdWoOutputGrid").trigger('reloadGrid');
                         }
                          else
                        	  grossWeightValid=true;
                        
                      });
                  }
   	      ,maxlength:8
              }},
   	          {name:'tareWeight',index:'tareWeight', width:40,editable:true,editoptions:{
                  dataInit: function(element) {
                      $(element).keyup(function(){
                          var val1 = element.value;
                          var num = new Number(val1);
                          if(isNaN(num))
                          {
                        	  alert("Please enter valid Tare Weight");
                        	  tareWeightValid=false;
                        	  jQuery("#rbdWoOutputGrid").trigger('reloadGrid');
                         }
                          else
                        	  tareWeightValid=true;
                        
                      });
                  }
   	      ,maxlength:8
              }},
   	          {name:'netWeight',index:'netWeight', width:40,editable:false},
   	          {name:'stockIn', index:'stockIn', width:30, editable : false },
	          {name:'stockIn', index:'stockIn', hidden:true, editable : true },
	          {name:'stockLink',index:'stockLink', width:30, editable:false,sortable:false},
	          {name:'scrapLink',index:'scrapLink', width:50, editable:false,hidden:true,sortable:false},
   	          {name:'act',index:'act', width:30,sortable:false}
   	   	],
	   	postData : {},
		rowNum : 10,
		rowList : [ 5, 10, 20, 40, 60 ],
		height : 240,
		autowidth : true,
		rownumbers : false,
		pager : '#rbdWoOutputPager',
		sortname : 'woOutPutId',
		viewrecords : true,
		sortorder : "desc",
	    caption:"Receipt From Production of RBD Work Order",
	    emptyrecords : "Empty records",
		loadonce : false,
		footerrow: true,
					
		jsonReader : {
			root : "rows",
			page : "page",
			total : "total",
			records : "records",
			repeatitems : false,
			cell : "cell",
			id : "woOutPutId"
		},
		ondblClickRow : function(id) {
			if (id && id !== lastSelected) {
				$('#rbdWoOutputGrid').jqGrid('restoreRow',
						lastSelected);
				editRow(id);
				lastSelected = id;
			}
		},
   	    gridComplete: function(){ 
   	     var netLength = $('#rbdWoOutputGrid').jqGrid('getCol','netLength',false,'sum');
   	     var grossWeight = $('#rbdWoOutputGrid').jqGrid('getCol','grossWeight',false,'sum');
   		 var tareWeight = $('#rbdWoOutputGrid').jqGrid('getCol','tareWeight',false,'sum');
   		 var netWeight = $('#rbdWoOutputGrid').jqGrid('getCol','netWeight',false,'sum');
 	   	 
   		 var totalNetLength=Math.round(parseFloat(netLength) * 100) / 100;
   	 	  var totalGrossWeight=Math.round(parseFloat(grossWeight) * 100) / 100;
   	 	  var totalTareWeight=Math.round(parseFloat(tareWeight) * 100) / 100;
          var totalNetWeight=Math.round(parseFloat(netWeight) * 100) / 100;
    

   		 
   		 
     		$('#rbdWoOutputGrid').jqGrid('footerData','set', {ID: 'Total:', grossWeight: totalGrossWeight});
	    	$('#rbdWoOutputGrid').jqGrid('footerData','set', {ID: 'Total:', tareWeight: totalTareWeight});
	    	$('#rbdWoOutputGrid').jqGrid('footerData','set', {ID: 'Total:', netWeight: totalNetWeight});
	    	$('#rbdWoOutputGrid').jqGrid('footerData','set', {ID: 'Total:', netLength: totalNetLength});
	   
   	    	var ids = jQuery("#rbdWoOutputGrid").jqGrid('getDataIDs');
   	    	for ( var i = 0; i < ids.length; i++) {
				var cl = ids[i];
				be = "<input style='height:22px; width:35px;' type='button' value='Edit' id='editRow"+cl+"' onclick=\"editRow('"+ cl + "');\" />";
				de = "<input style='height:22px; width:30px;' type='button' value='Del' id='delRow"+cl+"' onclick=\"delRow('"+ cl + "');\" />";
				se = "<input style='height:22px; width: 29px;' type='button' value='Save' hidden='hidden' id='saveRow"+cl+"' onclick=\"saveRow('"+ cl + "');\" />";
				ce = "<input style='height:22px;width:39px;' type='button' value='Cancel' hidden='hidden' id='restoreRow"+cl+"' onclick=\"restoreRow('"+ cl + "');\" />";
				sdLink = "<button class='btn btn-mini' id='itemDetailsLink"+cl+"' " +
				"onclick=\"stockInRBD('"+ cl + "');\" >Stock In </button>";
				
				scrLink = "<button class='btn btn-mini' id='itemDetailsLink"+cl+"'" +"onclick=\"scrapDetails('"+ cl + "');\" >Scrap Details </button>";
				
				
				$("#rbdWoOutputGrid").jqGrid('setRowData', ids[i],
						{
							act : be + de + se + ce,
							stockLink :sdLink,
							scrapLink :scrLink
						});
				if($("#rbdWoOutputGrid").getCell(cl,"stockIn")=="Yes"){
					 $("#rbdWoOutputGrid").jqGrid('setRowData',ids[i],false, {  color:'black',weightfont:'bold',background:'#90ee90'});
				}
			}
       },
	editurl : "storeRegisterForRBD/crud"
	
}).navGrid('#rbdWoOutputPager',{view:false, del:false, edit:false, search:false,add:false},
			  {}, // use default settings for edit
		    	{}, // settings for add
		    	{},  // delete instead that del:false we need this
		    	{multipleSearch : true}, // enable the advanced searching
		    	{} /* allow the view dialog to be closed when user press ESC key*/
		    	);

});


function editRow(id) {
	var grid = jQuery('#rbdWoOutputGrid');
	var stockStatus = grid.jqGrid('getCell', id, 'stockIn');

	var woStatus=document.getElementById('rbdWorkOrderStatus').value; 
	if(woStatus=="Created" && stockStatus!="Yes"){
	restoreRow(lastSelected);
	lastSelected = id;
	$('#rbdWoOutputGrid').jqGrid('editRow', id, {
		"keys" : true,
		"oneditfunc" : hideActButtons,
		aftersavefunc : function(savedId, response) {
			showActButtons(savedId);
		},
		afterrestorefunc : showActButtons

	});
	}else if (woStatus=="Submitted"){
		alert("Submitted Work Order Outputs cannot be updated");
	}else if (stockStatus=="Yes"){
		alert("Selected Work Order Output has been already stocked in");
	}
}


function delRow(id) {
	var grid = jQuery('#rbdWoOutputGrid');
	var stockStatus = grid.jqGrid('getCell', id, 'stockIn');

	var woStatus=document.getElementById('rbdWorkOrderStatus').value; 
	if(woStatus=="Created" && stockStatus!="Yes"){
	
	var workOrderNo=$('#rbdWorkOrderNoSelect').val();
	 if(confirm("Are you sure you want to delete ?")){
		 $.ajax({type:'POST', 
		 		url: 'storeRegisterForRBD/delRow/'+ encodeURIComponent(id),
				success: function(response) {
					 document.getElementById('rbdOutputWeight').value=response[0];
			         jQuery("#rbdWoOutputGrid").setGridParam({datatype:'json'}); 
					 jQuery("#rbdWoOutputGrid").setGridParam({ url: 'storeRegisterForRBD/rbdOutputRecords/'+ encodeURIComponent(workOrderNo)});
					 jQuery("#rbdWoOutputGrid").trigger('reloadGrid');

			}});
	
	 }
	}else if (woStatus=="Submitted"){
		alert("Submitted Work Orders cannot be deleted");
	}else if (stockStatus=="Yes"){
		alert("Selected Work Order Output has been already stocked in");
	}
}

function saveRow(id) {
	 var woNo = $('#rbdWorkOrderNoSelect').val();
	if(netLengthValid==true && grossWeightValid==true && tareWeightValid==true){
	$('#rbdWoOutputGrid').saveRow(id,
	{	aftersavefunc : function(id, response) {
				showActButtons(id);
				var grid = jQuery('#rbdWoOutputGrid');
				var grossWt = grid.jqGrid('getCell', id, 'grossWeight');
				var tareWt = grid.jqGrid('getCell', id, 'tareWeight');
				if (grossWt != null && tareWt != null && parseFloat(grossWt)>parseFloat(tareWt)) {
			    	var netWght = grossWt-tareWt;
					grid.jqGrid('setCell', id, 'netWeight', netWght);
				}
				else if(parseFloat(grossWt)<=parseFloat(tareWt)){
					alert("Gross Weight should be greater than Tare Weight");
					grid.jqGrid('setCell', id, 'grossWeight', 0);
					grid.jqGrid('setCell', id, 'tareWeight', 0);
					grid.jqGrid('setCell', id, 'netWeight', 0);
				}else{
					grid.jqGrid('setCell', id, 'netWeight', 0);
				}
				jQuery("#rbdWoOutputGrid").trigger('reloadGrid');
				$.ajax({type:'POST', 
		 			url: 'storeRegisterForRBD/fetchWoDetails/'+ encodeURIComponent(woNo),
		 			success: function(response) {
		 	             document.getElementById('rbdOutputWeight').value=response[5];
		 			}});       		
} });   	   
	}else if(netLengthValid==false){
		alert("Enter Valid Length");
	}else if(grossWeightValid==false){
		alert("Enter Valid Gross Weight");
	}else if(tareWeightValid==false){
		alert("Enter Valid Tare Weight");
	}
}
function restoreRow(id) {
	$('#rbdWoOutputGrid').jqGrid('restoreRow',id,
			{
				afterrestorefunc : showActButtons
			});
}

/*
 * Hides the Edit and Del Row Buttons on jqGrid
 * and activates the Save and restore(cancel) button
 * 
 */
function hideActButtons(id){
	$('#editRow' + id).hide();
	$('#delRow' + id).hide();
	$('#saveRow' + id).show();
	$('#restoreRow' + id).show();
}

/*
 * Shows the Edit and Del Row Buttons on jqGrid
 * and hides the Save and restore(cancel) button
 * 
 */
function showActButtons(id) {
	$('#editRow' + id).show();
	$('#delRow' + id).show();
	$('#saveRow' + id).hide();
	$('#restoreRow' + id).hide();
	lastSelected = null;
}


$("#netLength").keypress(function(){
	checkRbdWorkOrderNo();
});
$("#grossWeight").keypress(function(){
	checkRbdWorkOrderNo();;
});
$("#tareWeight").keypress(function(){
	checkRbdWorkOrderNo();
});


function checkRbdWorkOrderNo(){
	if($('#rbdWorkOrderNoSelect').val()==""){
		alert("Select Work Order No");
 }
}
  function validateRbdEntries(){
	  
	  if(document.getElementById('itemIdSelect').value==""){
	 		alert("Select Item Code");
			return false;
	    }
	  
	 	if(document.getElementById('netLength').value==""){
	 		alert("Enter Net Length");
			return false;
	    }
		if(document.getElementById('grossWeight').value==""){
			alert("Enter Gross Weight");
			return false;
	    }
		if(document.getElementById('tareWeight').value==""){
			alert("Enter Tare Weight");
			return false;
	    }

		if(isNaN(document.getElementById('netLength').value) || !(parseFloat(document.getElementById('netLength').value)>0)){
	 		alert("Enter Valid Net Length");
	 		document.getElementById('netLength').value="";
			return false;
	    }
		if(isNaN(document.getElementById('tareWeight').value) || !(parseFloat(document.getElementById('tareWeight').value)>0)){
	 		alert("Enter Valid Tare Weight");
	 		document.getElementById('tareWeight').value="";
			return false;
	    }
		if(isNaN(document.getElementById('grossWeight').value) || !(parseFloat(document.getElementById('grossWeight').value)>0)){
	 		alert("Enter Valid Gross Weight");
	 		document.getElementById('grossWeight').value="";
			return false;
	    }
	    if(parseFloat(document.getElementById('tareWeight').value) >=parseFloat(document.getElementById('grossWeight').value)){
	    	alert("Gross Weight should be greater than Tare Weight");
	 		document.getElementById('grossWeight').value="";
	 		document.getElementById('tareWeight').value="";
			return false;
	    }
		else return true;
  }
  
  
  function addWorkOrderOutputFn(){
	 var woNo=$('#rbdWorkOrderNoSelect').val();
	 var validRbd=validateRbdEntries();
	 if(validRbd==true){
			$.ajax({type:'POST', 
				url: 'storeRegisterForRBD/saveWorkOrderOutput', 
				
				data:{
					'itemIdSelect' : $("#itemIdSelect").val() , 
					 'netLength' : $("#netLength").val() , 
				     'tareWeight' : $("#tareWeight").val() , 
					 'grossWeight' : $("#grossWeight").val(),
					 'workOrderNo': $('#rbdWorkOrderNoSelect').val()
					 },
				beforeSend: function(){
					           $("#loading").dialog('open').html("<p>Processing Request...</p>");
				       },
				success: function(response) {
					     document.getElementById('rbdOutputWeight').value=response[0];
				         jQuery("#rbdWoOutputGrid").setGridParam({datatype:'json'}); 
						 jQuery("#rbdWoOutputGrid").setGridParam({ url: 'storeRegisterForRBD/rbdOutputRecords/'+ encodeURIComponent(woNo)});
						 jQuery("#rbdWoOutputGrid").trigger('reloadGrid');
			
				},
				 complete: function() {
		        	 $("#loading").dialog('close');
		        }}); 
	 }
 }	
  

  
  function submitRBDWorkOrderFn(){
	  var workOrderNo=$('#rbdWorkOrderNoSelect').val();
	  if(document.getElementById('rbdWorkOrderStatus').value!="Submitted"){
		 if(confirm("Are you sure you want to submit work order "+workOrderNo)){
				$.ajax({type:'POST', 
					url: 'storeRegisterForRBD/submitWorkOrder/'+ encodeURIComponent(workOrderNo), 
					success: function(response) {
						alert("Work Order "+workOrderNo+" is submitted");
						document.getElementById('rbdWorkOrderStatus').value=response[0]; 
						document.getElementById('addBtn').disabled=true;  	
						document.getElementById('sizeSelect').disabled=true;  	
						document.getElementById('netLength').disabled=true;
						document.getElementById('grossWeight').disabled=true;
						document.getElementById('tareWeight').disabled=true;
						document.getElementById('submitRBDWorkOrder').disabled=true;
					}}); 
		 }}else{
			 alert("Work Order "+workOrderNo+" already submitted");
		 }
  }
  
  
  function stockInRBD(id){
		var woNo=document.getElementById('rbdWorkOrderNoSelect').value;
		var grid = jQuery('#rbdWoOutputGrid'); 
	    var stockInStatus=grid.jqGrid ('getCell', id, 'stockIn');
	    var batchNo=grid.jqGrid ('getCell', id, 'batchNo');
	     var netWeight=grid.jqGrid ('getCell', id, 'netWeight');
	    if(stockInStatus == 'Yes'){
	    	alert("Batch "+batchNo+" Has Already Been Stocked In.");
	    }
	    else if(netWeight==0){
	    	alert("Batch "+batchNo+" Should have a valid net weight for stock in");
	    } else{
	    	if(confirm("Are You Sure You Want To Stock In?")){
	    		$.ajax({type:'POST', 
	    			url: 'storeRegisterForRBD/stockIn/'+ encodeURIComponent(id),
	    			success: function(response) {
	    				alert("RBD output stocked in sucessfully");
	    				jQuery("#rbdWoOutputGrid").setGridParam({datatype:'json'}); 
	    				jQuery("#rbdWoOutputGrid").setGridParam({ url: 'storeRegisterForRBD/rbdOutputRecords/'+ encodeURIComponent(woNo)});
	    				jQuery("#rbdWoOutputGrid").trigger('reloadGrid');
	    					
	    			}
	    		});
	    	}
	    }
		
		
	}
  
  $(document).keypress(function(e) {
		if (e.which == 13) {
			var ids = $("#rbdWoOutputGrid").jqGrid('getDataIDs');
			for ( var i = 0; i < ids.length; i++) {
				var cl = ids[i];
				var grid = jQuery('#rbdWoOutputGrid');
				var grossWt = grid.jqGrid('getCell', cl, 'grossWeight');
				var tareWt = grid.jqGrid('getCell', cl, 'tareWeight');
				if (grossWt != null && tareWt != null && parseFloat(grossWt)>=parseFloat(tareWt)) {
			    	var netWght = grossWt-tareWt;
					grid.jqGrid('setCell', cl, 'netWeight', netWght);
				}
				else if(parseFloat(grossWt)<parseFloat(tareWt)){
					alert("Gross Weight should be greater than Tare Weight");
					grid.jqGrid('setCell', cl, 'grossWeight', 0);
					grid.jqGrid('setCell', cl, 'tareWeight', 0);
					grid.jqGrid('setCell', cl, 'netWeight', 0);
				}else{
					grid.jqGrid('setCell', cl, 'netWeight', 0);
				}
			}
			jQuery("#rbdWoOutputGrid").trigger('reloadGrid');
			 var woNo = $('#rbdWorkOrderNoSelect').val();
			$.ajax({type:'POST', 
	 			url: 'storeRegisterForRBD/fetchWoDetails/'+ encodeURIComponent(woNo),
	 			success: function(response) {
	 	             document.getElementById('rbdOutputWeight').value=response[5];
	 			}}); 
		}
	});

  
  
  function scrapDetails(id){
		var workOrderNo=document.getElementById('rbdWorkOrderNoSelect').value;
		url = 'woScrap?workOrderNo=' + encodeURIComponent(workOrderNo)+'&process='+encodeURIComponent("RBD"); 
		
		window.open(url,'_blank');
		
	}
  
  
  function rbdJobCardReport(){
		 var woNo=document.getElementById('rbdWorkOrderNoSelect').value;

	 if(woNo!=null && woNo!="")
		location.href='storeRegisterForRBD/rbdJobCardReport?workOrderNo='+woNo;
	else
		alert("Select Work Order No");
	}
  
function populateRbdWorkOrderNo(){
		$('#rbdWorkOrderNoSelect').children().remove();
		$('#rbdWorkOrderNoSelect').val('').trigger('liszt:updated');
		document.getElementById('rbdStartDate').value="";
		document.getElementById('rbdCompletionDate').value="";
		document.getElementById('rbdMachineNo').value="";
		document.getElementById('rbdInputWeight').value="";
		document.getElementById('rbdOutputWeight').value="";
		document.getElementById('rbdWorkOrderStatus').value="";
		 month = $("#ui-datepicker-div .ui-datepicker-month :selected").val();
	     year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
		$.ajax({type:'POST', 
			url: 'storeRegisterForRBD/getWorkOrderNo',
			data : {"processType" : "RBD","month":month,"year":year},
			success: function(response) {
				$('#rbdWorkOrderNoSelect').empty();
				if (response.length == 0) {

					alert("There is no Work Order for selected month & year");
				}

				if(response.length != 0){
					for(var i=0;i< response.length;i++){
						$('#rbdWorkOrderNoSelect').append('<option selected="selected">'+ "" + '</option>');
						$('#rbdWorkOrderNoSelect').append('<option >' + response[i]+ '</option>');
						$('#rbdWorkOrderNoSelect').trigger('liszt:updated');
					}
				}else{
					$('#rbdWorkOrderNoSelect').empty();
					document.getElementById('rbdStartDate').value="";
					document.getElementById('rbdCompletionDate').value="";
					document.getElementById('rbdMachineNo').value="";
					document.getElementById('rbdInputWeight').value="";
					document.getElementById('rbdOutputWeight').value="";
					document.getElementById('rbdWorkOrderStatus').value="";

				}
			}
		});
  }