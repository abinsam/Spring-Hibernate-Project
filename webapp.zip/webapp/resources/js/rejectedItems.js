var lastSelected;

$(function() {
	
	$("#sentToStatusSelect").chosen({no_results_text: "No results matched"});

	$( "#startDate" ).datepicker({dateFormat : "dd-mm-yy",
        maxDate:'today',
        onSelect: function(dateStr)
        {
        var min = $('#startDate').datepicker('getDate'); 
        $('#endDate').datepicker('option', {minDate : min});
  }});
$( "#endDate" ).datepicker({dateFormat : "dd-mm-yy", minDate:$('#startDate').datepicker('getDate')});

if($('input:radio[name=storeRegTypeSelect]:checked').val()==0){
	  $("#rejectedItems").show();
	  $("#poStoreRejectedItems").hide();
 }else{
	 $("#poStoreRejectedItems").show();
	 $("#rejectedItems").hide();
 }


$("input[name=storeRegTypeSelect]").change(function () {
	if($('input:radio[name=storeRegTypeSelect]:checked').val()==0){
		  $("#rejectedItems").show();
		  $("#poStoreRejectedItems").hide();
	 }else{
		 $("#poStoreRejectedItems").show();
		 $("#rejectedItems").hide();
	 }

});

$("#rejectedItemsGrid")
			.jqGrid({
						url : 'rejectedItems/records',
						datatype : 'json',
						mtype : 'POST',
						 multiselect: true,
						colNames : [ 'Store Reg Id', 'Store', 'Sales Order No',
								'Sales Order Status', 'PartyHidden','Party', 'Item Id', 'Item Code',
								'Item Description', 'Work Order No',
								'Bundle Id', 'Stock Qty(mts)', 'Units',
								'Weight(Kg)','Reject Status','Qc Supervisor','QC Remarks'],
						colModel : [
				{name : 'storeRegisterId',index : 'storeRegisterId',width : 5,viewable : false,hidden : true},
				{name : 'storeAddress',	index : 'storeAddress',		width : 5,viewable : false,hidden : true},
				{name : 'orderId',index : 'orderId',width : 90},
				{name : 'status',index : 'status',width : 110},
				{name : 'customerName',index : 'customerName',width : 120,hidden : true},
				{name : 'customerCode',index : 'customerCode',width : 70},
                {name : 'itemId',index : 'itemId',width : 5,hidden : true},
			    {name : 'itemCode',	index : 'itemCode',width : 160},
			    {name : 'itemDescription',index : 'itemDescription',width : 260},
				{name : 'workOrderNo',index : 'workOrderNo',width : 90},
				{name : 'bundleId',	index : 'bundleId',width : 60},
				{name : 'stockQty',	index : 'stockQty',	width : 70},
				{name : 'unit',	index : 'unit',width : 10,hidden : true},
				{name : 'weight',index : 'weight',width : 60},
				{name : 'rejectStatus',index : 'rejectStatus',width : 80},
				{name : 'qcSupervisor',index : 'qcSupervisor',width : 80},
				{name : 'remarks',index : 'remarks',width : 80}
            	],
						postData : {},
						rowNum : 100,
						rowList : [1, 5, 10, 20, 30, 40, 100,500,1000,2000 ],
						height : 300,
						autowidth:true,
						rownumbers : false,
						pager : '#rejectedItemsPager',
						sortname : 'storeRegisterId',
						viewrecords : true,
						sortorder : "desc",
						caption : "Rejected Items",
						emptyrecords : "Empty records",
						loadonce : false,
						footerrow : true,
						loadComplete : function() {
						},
						jsonReader : {
							root : "rows",
							page : "page",
							total : "total",
							records : "records",
							repeatitems : false,
							cell : "cell",
							id : "storeRegisterId"
						},
				   		 onSelectRow: updateIdsOfSelectedRows,   
	        	   		 onSelectAll:function (aRowids, status) {
	        	      	   updateIdsOfAllSelectedRows(aRowids,status);
	        	         },
	        		   	  loadComplete: function () {
	            	   	        var $this = $(this), i, count;
	            	   	        for (i = 0, count = idsOfSelectedRows.length; i < count; i++) {
	            	   	            $this.jqGrid('setSelection', idsOfSelectedRows[i], false);
	            	   	        }
	            	   	      },
						gridComplete : function() {

							var stockQty = $('#rejectedItemsGrid').jqGrid('getCol', 'stockQty', false, 'sum');
							var totalStockQty = Math.round(parseFloat(stockQty) * 100) / 100;
							$('#rejectedItemsGrid').jqGrid('footerData', 'set',	{ID : 'Total:',	stockQty : totalStockQty});

							var weight = $('#rejectedItemsGrid').jqGrid('getCol', 'weight', false, 'sum');
							var totalWeight = Math.round(parseFloat(weight) * 100) / 100;
							$('#rejectedItemsGrid').jqGrid('footerData', 'set',	{ID : 'Total:',	weight : totalWeight});

							var weight = $('#rejectedItemsGrid').jqGrid('getCol', 'weight', false, 'sum');
							var totalWeight = Math.round(parseFloat(weight) * 100) / 100;
							$('#rejectedItemsGrid').jqGrid('footerData', 'set',{ID : 'Total:',weight : totalWeight});

						}

					

					});
	jQuery("#rejectedItemsGrid").jqGrid('navGrid', '#rejectedItemsPager', {
		view : false,
		del : false,
		add : false,
		edit : false,
		search : false
	});


	$("#poStoreRejectedItemsGrid")
	.jqGrid(
			{
				url : 'rejectedItems/poRecords',
				datatype : 'json',
				mtype : 'POST',
				
				colNames : [ 'Store Reg Id', 'Store', 'Purchase Order No',
						'Purchase Order Status', 'PartyHidden','Party','Item Code',
						'Item Description','Batch No','No Of bags','Total Qty','','Reject Status','Qc Supervisor','Remarks'],
				colModel : [
		{name : 'rwStoreRegId',index : 'rwStoreRegId',width : 5,viewable : false,hidden : true},
		{name : 'storeId',	index : 'storeId',		width : 5,viewable : false,hidden : true},
		{name : 'poNo',index : 'poNo',width : 90},
		{name : 'poStatus',index : 'poStatus',width : 90},
		{name : 'customerName',index : 'customerName',width : 110,hidden : true},
		{name : 'customerCode',index : 'customerCode',width : 60},
        {name : 'itemCode',	index : 'itemCode',width : 180},
	    {name : 'itemDescription',index : 'itemDescription',width : 240},
	    {name : 'batchNo',index : 'batchNo',width : 60},
	    {name : 'noOfBags',index : 'noOfBags',width : 60},
	    {name : 'totalQty',index : 'totalQty',width : 60},
	    {name : 'units',index : 'units',width : 20},
		{name : 'rejectStatus',index : 'rejectStatus',width : 60},
		{name : 'qcSupervisor',index : 'qcSupervisor',width : 60},
		{name : 'remarks',index : 'remarks',width : 80}

    	],
				postData : {},
				rowNum : 100,
				rowList : [ 5, 10, 20, 30, 40, 100,500,1000,2000 ],
				height : 300,
				width: 1200,
				rownumbers : false,
				pager : '#poStoreRejectedItemsPager',
				sortname : 'rwStoreRegId',
				viewrecords : true,
				sortorder : "desc",
				caption : "Rejected PO Items",
				emptyrecords : "Empty records",
				loadonce : false,
				footerrow : true,
				loadComplete : function() {
				},
				jsonReader : {
					root : "rows",
					page : "page",
					total : "total",
					records : "records",
					repeatitems : false,
					cell : "cell",
					id : "rwStoreRegId"
				}

			});
jQuery("#poStoreRejectedItemsGrid").jqGrid('navGrid', '#poStoreRejectedItemsPager', {
view : false,
del : false,
add : false,
edit : false,
search : false
});
	
	$('#searchButton').click(function() {
		
		var validSearch=validateSearchParams();
		if(validSearch==true){
		
			var fromDate=document.getElementById('startDate').value;
			var toDate=document.getElementById('endDate').value;
			var orderStatus = document.getElementById('sentToStatusSelect').value;
			if($('input:radio[name=storeRegTypeSelect]:checked').val()==0){
			   jQuery("#rejectedItemsGrid").setGridParam({datatype:'json'}); 
		  	   jQuery("#rejectedItemsGrid").setGridParam({ url: 'rejectedItems/records'});
		  	   jQuery("#rejectedItemsGrid").setGridParam({postData: {fromDate:fromDate,toDate:toDate,orderStatus:orderStatus}}); 
		  	   jQuery("#rejectedItemsGrid").setCaption('Store Register Rejected Items from:'+fromDate+' to:'+toDate);
		  	   jQuery("#rejectedItemsGrid").trigger('reloadGrid');
		   }else{
			   jQuery("#poStoreRejectedItemsGrid").setGridParam({datatype:'json'}); 
		  	   jQuery("#poStoreRejectedItemsGrid").setGridParam({ url: 'rejectedItems/poRecords'});
		  	   jQuery("#poStoreRejectedItemsGrid").setGridParam({postData: {fromDate:fromDate,toDate:toDate,orderStatus:orderStatus}}); 
		  	   jQuery("#poStoreRejectedItemsGrid").setCaption('Purchase Order Stock Rejected Items from:'+fromDate+' to:'+toDate);
		  	   jQuery("#poStoreRejectedItemsGrid").trigger('reloadGrid');
		 
		   }
		} 
		
	});
	function validateSearchParams(){
		
		var fromDate=document.getElementById('startDate').value;
		var toDate=document.getElementById('endDate').value;
		var orderStatus = document.getElementById('sentToStatusSelect').value;
		
	    if(orderStatus!=null && orderStatus!=""){
	    	
	    	return true;
	    }
	    else if(fromDate==null || fromDate==""){
	    	alert("Select from Date");
	    	
	    }
	    else if(toDate==null || toDate==""){
	    	alert("Select to Date");
	    	
	    }
	    
	    else return true;
	}

	$('#clearButton').click(function() {
		if ($("#sentToStatusSelect").val() != "") {
			document.getElementById('sentToStatusSelect').value = "";
			$('#sentToStatusSelect').trigger('liszt:updated');
		}
		
		if (document.getElementById('startDate').value != "")
			document.getElementById('startDate').value = "";
		
		if (document.getElementById('endDate').value != "")
			document.getElementById('endDate').value = "";
		
		jQuery("#rejectedItemsGrid").setGridParam({datatype : 'json'});
		jQuery("#rejectedItemsGrid").setGridParam({ url: 'rejectedItems/records'});
		jQuery("#rejectedItemsGrid").setGridParam({postData : {fromDate : "",toDate : "",orderStatus : ""}});
		jQuery("#rejectedItemsGrid").trigger('reloadGrid');
		
		jQuery("#poStoreRejectedItemsGrid").setGridParam({datatype : 'json'});
		jQuery("#poStoreRejectedItemsGrid").setGridParam({url : 'rejectedItems/poRecords'});
		jQuery("#poStoreRejectedItemsGrid").setGridParam({postData : {fromDate : "",toDate : "",orderStatus : ""}});
		jQuery("#poStoreRejectedItemsGrid").trigger('reloadGrid');
	});
});


idsOfSelectedRows = ["8", "9", "10"];
var $rejectedItemsGrid = $("#rejectedItemsGrid"), idsOfSelectedRows = [],
updateIdsOfSelectedRows = function (id, isSelected) {
      var index = $.inArray(id, idsOfSelectedRows);
       if (!isSelected && index >= 0) {
	          idsOfSelectedRows.splice(index, 1); // remove id from the list
        } else if (index < 0) {
        	   idsOfSelectedRows.push(id);
        }  
};



updateIdsOfAllSelectedRows = function (aRowids, isSelected) {
	 var i, count, id;
	 for (i = 0, count = aRowids.length; i < count; i++) {
		 id = aRowids[i];
		     var index = $.inArray(id, idsOfSelectedRows);
           if (!isSelected && index >= 0) {
   	          idsOfSelectedRows.splice(index, 1); // remove id from the list
            } else if (index < 0) {
              idsOfSelectedRows.push(id);
   
         }
  	 }
};

$('#scrapButton').click(function() {
$.ajax({type:'POST', 
	url: 'rejectedItems/scrapItems',
	data:{'idsOfSelectedRows':idsOfSelectedRows},
	success: function(response) {
		 alert("Selected Items Scrapped");
		jQuery("#rejectedItemsGrid").setGridParam({datatype:'json'}); 
    	jQuery("#rejectedItemsGrid").setGridParam({ url : 'rejectedItems/records'});
    	jQuery("#rejectedItemsGrid").trigger('reloadGrid');


  }});
});