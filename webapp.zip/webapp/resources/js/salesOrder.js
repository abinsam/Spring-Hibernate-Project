var lastSelected;
var validRates=true;
var systemDate = new Date();
var month="";
var year="";
$(function() {
	

	$("#statusValueSelect").chosen({no_results_text : "No results matched"});
	$("#partySelect").chosen({no_results_text : "No results matched"});
	$("#monthYearPicker").focus(function () {$(".ui-datepicker-calendar").hide();});
	$('#monthYearPicker').datepicker({
	
        changeYear: true,
        changeMonth: true,
        changeDate :false,
        showButtonPanel: true,
        dateFormat: 'MM yy',
        onClose: function(dateText, inst) { 
            year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
            month = $("#ui-datepicker-div .ui-datepicker-month :selected").val();
            $(this).datepicker('setDate', new Date(year,month, 1));
         //   changeWoOnMonthYear();
        }
    });

	$('#monthYearPicker').datepicker('setDate',systemDate); 
	
$("#monthYearPicker").focus(function () {$(".ui-datepicker-month").show();});
$("#monthYearPicker").focus(function () {$(".ui-datepicker-year").show();});

 var statusData="Pending:Pending;Approved:Approved;Dispatched:Dispatched;Approved For Prodn:Approved For Prodn;Final Approval:Final Approval";
	$("#statusValueSelect").chosen({no_results_text: "No results matched"});
	//document.getElementById('statusValueSelect').value = "Pending";
	//$('#statusValueSelect').trigger('liszt:updated');

	if(new Date().getDate()>9){
        curDate= (new Date().getDate()) + "-"  +(new Date().getMonth()+1) + "-" + (new Date().getFullYear());     
 }
 else{
        curDate="0"+(new Date().getDate()) + "-" +(new Date().getMonth()+1) + "-" + (new Date().getFullYear());
 }
    
 	  $("#SalesOrderGrid").jqGrid({
        	  url:'viewSalesOrders/records',
        	  datatype: 'json',
        	  mtype: 'POST',
         
        	   colNames:['Sales Order','PartyHidden','Party','Id','Party PO No','Received Date(dd-MM-yyyy)',
        	             'Acceptance Date(dd-MM-yyyy)','Delivery Date(dd-MM-yyyy)',
        	             'Receipt Mode','Created By','createdby hidd',
        	             'Created Time','Created time hid',
        	             'Updated By','Updated Time','Input Qty','i/p hidd','Item Details','Status','ststushid','mailStatus','LME','Actions'],
        	   colModel:[
           
   		              {name:'orderId', index:'orderId',key:true, width:50},
                      {name:'customerName', index:'customerName', width:20,hidden:true},
                      {name:'customerCode', index:'customerCode', width:50},
        	          {name:'customerId',index:'customerId',editable:true,hidden:true},
        	          {name:'poDetails', index:'poDetails', width:40,editable:true, editoptions : {size : 50,maxlength:15}},
        	          {name:'orderRecDate', index:'orderRecDate', width:65,editable:true}, 
        	   	      {name:'orderAcceptanceDate', index:'orderAcceptanceDate', width:70,editable:true}, 
        	   	      {name:'orderDeliveryDate', index:'orderDeliveryDate', width:65,editable:true} ,
        	   	      {name:'modeOfReceipt', index:'modeOfReceipt', width:60,editable:true,edittype:'select',editoptions:{value:"Email:Email;Verbal:Verbal"}},
        	   	      {name:'createdBy', index:'createdBy', width:70}, 
        	   	      {name:'createdBy', index:'createdBy',hidden:true,editable:true,width:10}, 
        	   	      {name:'createdTime', index:'createdTime', width:60,hidden:true}, 
     	   	          {name:'createdTime', index:'createdTime',hidden:true,editable:true,width:10}, 
        	   	      {name:'updatedBy', index:'updatedBy', width:70}, 
        	   	      {name:'updatedTime', index:'updatedTime', width:40,hidden:true}, 
        	   	      {name:'inputQuantity', index:'inputQuantity', width:70,hidden:true}, 

     	   	          {name:'inputQuantity', index:'inputQuantity', width:10,editable:true,hidden:true}, 
 	   	  
        	   	      
        	   	      {name:'itemDetailsLink',index:'itemDetailsLink', width:50, editable:false,hidden:true},
        	     	   {name:'status',index:'status', width:90},
        	   	      {name:'status', index:'status', width:50,editable:true,edittype:'select',editoptions:{value:statusData},hidden:true},
        	   	      {name : 'mailStatus',index : 'mailStatus',width : 10,editable:true,hidden:true},
        	   	      {name : 'lmeDetails',index : 'lmeDetails',width : 90,editable:true,hidden:true},
        	   	      {name:'act',index:'act', width:40,sortable:false, viewable:false}
        	   	       ],        	   	       
        	   	   	  
        	   		   	postData: {},
        	   			rowNum:100,
        	   		   	rowList:[5,10,20,40,50,100,500,1000],
        	   		   	height: 400,
        	   		   	autowidth: true,
        	   			rownumbers: false,
        	   		   	pager: '#salesorderpager',
        	   		   	sortname: 'orderId',
        	   		    viewrecords: true,
        	            sortorder: "desc",
        	   		    caption:"Sales Orders List",
        	   		    emptyrecords: "Empty records",
        	   		    loadonce: false,
        	   		     loadComplete: function() {
        	   		    	//$("#SalesOrderGrid td:eq(2)", grid[0]).css({color:'red'});
        	   		    	jQuery("#SalesOrderGrid").jqGrid('setCell',"0","orderId","",{color:'red'});
        	   		     },
        	   		    jsonReader : {
        	   		        root: "rows",
        	   		        page: "page",
        	   		        total: "total",
        	   		        records: "records",
        	   		        repeatitems: false,
        	   		        cell: "cell",
        	   		        id: "orderId"
        	   		    },
        	   		 ondblClickRow : function(id) {
        	   	   	 if (id && id !== lastSelected) {
        	 				editRow(id);
        	 			}
        	 		},
        	
        	   	    gridComplete: function(){ 
        	   	    	var ids = jQuery("#SalesOrderGrid").jqGrid('getDataIDs');
        	   	    	for ( var i = 0; i < ids.length; i++) {
        					var cl = ids[i];
        					be = "<input style='height:22px; width:35px;' type='button' value='Edit' id='editRow"+cl+"' onclick=\"editRow('"+ cl + "');\" />";
        					de = "<input style='height:22px; width:30px;' type='button' value='Del' id='delRow"+cl+"' onclick=\"delRow('"+ cl + "');\" />";
        					se = "<input style='height:22px; width: 29px;' type='button' value='Save' hidden='hidden' id='saveRow"+cl+"' onclick=\"saveRow('"+ cl + "');\" />";
        					ce = "<input style='height:22px;width:39px;' type='button' value='Cancel' hidden='hidden' id='restoreRow"+cl+"' onclick=\"restoreRow('"+ cl + "');\" />";
        					odLink = "<button class='btn btn-mini' style='font-weight: bold;font-size:1.2em;'  id='itemDetailsLink"+cl+"' " +
        							"onclick=\"openOrderItemsPopUp('"+ cl + "');\"  >"+ cl+" </button>";
        					
        					$("#SalesOrderGrid").jqGrid('setRowData', ids[i],
        							{
        								act : be + de + se + ce,
        								orderId :odLink
        							});
        					 //jQuery("#SalesOrderGrid").setCell(ids[i], 'orderId', '', 'myLink');
        				}
	               },
	               editurl : "viewSalesOrders/modifyorders"
  	   	    	                   });
 			 jQuery("#SalesOrderGrid").jqGrid('navGrid','#salesorderpager',{view:false, del:false,add:false, edit:false, search:false},   
                		 {}, // use default settings for edit
                                    			{}, // settings for add
                                    			{},  // delete instead that del:false we need this
                                    			{multipleSearch : true}, // enable the advanced searching
                                    			{
                                    				left : 150,
                                    				caption: "View Sales Orders",
                                    				width : 600,
                                    				bClose: "Close",
                                    				closeOnEscape:true} /* allow the view dialog to be closed when user press ESC key*/);        
  
    var status=document.getElementById('statusValueSelect').value;
    if(status==null || status=="")
    	jQuery("#SalesOrderGrid").setCaption("Pending Sales Order list");
    	else
    		jQuery("#SalesOrderGrid").setCaption(status+" Sales Order list");	
}); 
          
          
             
      function editRow(id) {
    	  var grid = jQuery('#SalesOrderGrid'); 
    		var orderStatus = grid.jqGrid ('getCell', id, 'status'); 
    		  if(orderStatus=="Pending" || orderStatus=="Approved For Prodn" || orderStatus=="Created"){
    	   restoreRow(lastSelected);
    		lastSelected = id;
    		$('#SalesOrderGrid').jqGrid('editRow',id, 
    				{
    					"keys" :true, 
    					"oneditfunc" : hideActButtons,
    					aftersavefunc : function(savedId, response) {
    						showActButtons(savedId);
    					},
    					afterrestorefunc : showActButtons
    				});
    	}}

    	function delRow(id) {
    		var grid = jQuery('#SalesOrderGrid'); 
    		var orderStatus = grid.jqGrid ('getCell', id, 'status'); 
    		  if(orderStatus=="Pending" || orderStatus=="Approved For Prodn" || orderStatus=="Created"){
    	 	$.ajax({type:'POST', 
    	 		url: 'workorder/checkOrderStatus/'+ encodeURIComponent(id),
    			success: function(response) {
    			if(response=="exist"){
    				//alert("Sales Order sent to Wo level.Cannot delete Sales Order!");
    				alert("Note - you cannot modify the quantities");
    			}
    			else{
    				 if (confirm(" Do you want to cancel Sales Order "+id)){
    				$.ajax({type:'POST', 
    					url: 'orders/delete/'+ encodeURIComponent(id),
    					success: function(response) {
    						//var customerId=$('#customerSelect').val();
    						     jQuery("#SalesOrderGrid").setGridParam({datatype:'json'}); 
    							 jQuery("#SalesOrderGrid").setGridParam({ url : 'viewSalesOrders/records'});
    							 jQuery("#SalesOrderGrid").setGridParam({postData: {month:month,year:year,orderStatus:orderStatus}}); 
    							 jQuery("#SalesOrderGrid").trigger('reloadGrid');

    					}
    				});
    				 }
    			}
    		
    		}});
    	  }
    	}

    	function saveRow(id) {
    		$('#SalesOrderGrid').saveRow(id,
    		{	aftersavefunc : function(id, response) {
    					showActButtons(id);
    	} });   	   
    	}

    	function restoreRow(id) {
    		$('#SalesOrderGrid').jqGrid('restoreRow',id,
    				{
    					afterrestorefunc : showActButtons
    				});
    	}

    	/*
    	 * Hides the Edit and Del Row Buttons on jqGrid
    	 * and activates the Save and restore(cancel) button
    	 * 
    	 */
    	function hideActButtons(id){
    		$('#editRow' + id).hide();
    		$('#delRow' + id).hide();
    		$('#saveRow' + id).show();
    		$('#restoreRow' + id).show();
    		pickdates(id);
    	}

    	/*
    	 * Shows the Edit and Del Row Buttons on jqGrid
    	 * and hides the Save and restore(cancel) button
    	 * 
    	 */
    	function showActButtons(id) {
    		$('#editRow' + id).show();
    		$('#delRow' + id).show();
    		$('#saveRow' + id).hide();
    		$('#restoreRow' + id).hide();
    		lastSelected = null;
    	}
     	
    	function openOrderItemsPopUp(id) {
   			var orderId=id;
      		restoreRow(orderId);

    		url = 'salesItemsDetails?orderId=' + encodeURIComponent(orderId);
			window.open(url,'_blank');
    		
    	}

    	function pickdates(id) {

	$("#" + id + "_orderRecDate", "#SalesOrderGrid").datepicker(
			{
				dateFormat : "dd-mm-yy",
				maxDate : 'today',
				onSelect : function(dateStr) {
					var min = $("#" + id + "_orderRecDate", "#SalesOrderGrid")
							.datepicker('getDate');
					$("#" + id + "_orderAcceptanceDate", "#SalesOrderGrid")
							.datepicker('option', {
								minDate : min
							});
					var min1 = $("#" + id + "_orderAcceptanceDate",
							"#SalesOrderGrid").datepicker('getDate');
					$("#" + id + "_orderDeliveryDate", "#SalesOrderGrid")
							.datepicker('option', {
								minDate : min1
							});
				}
			});
	$("#" + id + "_orderAcceptanceDate", "#SalesOrderGrid").datepicker(
			{
				dateFormat : "dd-mm-yy",
				minDate : 'orderRecDate',
				onSelect : function(dateStr) {
					var minAcceptDate = $("#" + id + "_orderAcceptanceDate",
							"#SalesOrderGrid").datepicker('getDate');
					if (minAcceptDate != null || minAcceptDate != "")
						$("#" + id + "_orderDeliveryDate", "#SalesOrderGrid")
								.datepicker('option', {
									minDate : minAcceptDate
								});
				}
			});
	$("#" + id + "_targetDate", "#SalesOrderGrid").datepicker({
		dateFormat : "dd-mm-yy"
	});
	$("#" + id + "_orderDeliveryDate", "#SalesOrderGrid").datepicker(
			{
				dateFormat : "dd-mm-yy",
				onSelect : function(dateStr) {
					var minDate = $("#" + id + "_orderAcceptanceDate",
							"#SalesOrderGrid").datepicker('getDate');
					if (minDate != null || minDate != "")
						$("#" + id + "_orderDeliveryDate", "#SalesOrderGrid")
								.datepicker('option', {
									minDate : minDate
								});
				}
			});
}  	                
   
    	function changeWoOnMonthYear(){
    		
    	    $('#partySelect').children().remove();
    		$('#partySelect').val('').trigger('liszt:updated');
    		
    		$('#SalesOrderGrid').jqGrid('clearGridData');
    		jQuery("#deliveryChallanGrid").setCaption("Sales Order List");
    		
    		var validSearch=validateSearchParams();
    		if(validSearch==true){
    			
    		 $.ajax({type:'POST',
    			  url: 'viewSalesOrders/fetchCustomers',
    			  data: {"month":month,"year":year}, 
    			  success: function(response) {
    					
    					if (response.length == 0) {
           				alert("There is no customer with any salesorder in this month and year");

    			        }
    					if(response.length != 0){
    						for(var i=0;i< response.length;i++){
    							$('#partySelect').append('<option selected="selected">'+ "" + '</option>');
    							$('#partySelect').append('<option >' + response[i]+ '</option>');
    							$('#partySelect').trigger('liszt:updated');
    						}
    					}else{
    						$('#partySelect').empty();	
    						$('#partySelect').children().remove();
    						$('#partySelect').val('').trigger('liszt:updated');
    					}
    				
    		 }
    		 });
    	 }
    }    	
    	
    	$('#searchOrders').click(function() {
    		
    		var validSearch=validateSearchParams();
    		if(validSearch==true){
    				searchFunction();
    		}

    	});

    	function searchFunction() {
    		var customerId = document.getElementById('partySelect').value;
    		 var orderStatus = document.getElementById('statusValueSelect').value;
    		
    		var searchOptions1 = {
    			"groupOp" : "AND",
    			"rules" : [ {
    				"field" : "customerId",
    				"op" : "eq",
    				"data" : customerId
    			},
    			{
    				"field" : "orderStatus",
    				"op" : "eq",
    				"data" : orderStatus
    			},
    			{
    				"field" : "month",
    				"op" : "eq",
    				"data" : month
    			},
    			{
    				"field" : "year",
    				"op" : "eq",
    				"data" : year
    			}
    			]
    		};
    		performSearch(searchOptions1, "#SalesOrderGrid");
    	}
   	function performSearch(searchOptions, gridId) {
    		
    		$(gridId).setGridParam({
    			postData : {
    				searchObject : JSON.stringify(searchOptions)
    			}
    		});
    		
    		$(gridId).trigger("reloadGrid");
    	}        

    	function validateSearchParams(){
    	  if($("#monthYearPicker").val()=="" || $("#monthYearPicker").val()==null){
    	    	alert("Month and Year empty! please select month and year");
    	    	return false;
    	    }
   
    	    else return true;
    	}

    	function clearFn() {
    		var customerId = null;
   		    var orderStatus =null;
    		year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
            month = $("#ui-datepicker-div .ui-datepicker-month :selected").val();
    		var searchObj = {
        			"groupOp" : "AND",
        			"rules" : [ {
        				"field" : "customerId",
        				"op" : "eq",
        				"data" : customerId
        			},
        			{
        				"field" : "orderStatus",
        				"op" : "eq",
        				"data" : orderStatus
        			},
        			{
        				"field" : "month",
        				"op" : "eq",
        				"data" : month
        			},
        			{
        				"field" : "year",
        				"op" : "eq",
        				"data" : year
        			}
        			]
        		};
    		if ($("#statusValueSelect").val() != "") {
    			document.getElementById('statusValueSelect').value = "";
    			$('#statusValueSelect').trigger('liszt:updated');
    		}
    		
    		if ($("#partySelect").val() != "") {
    			document.getElementById('partySelect').value = "";
    			$('#partySelect').trigger('liszt:updated');
    		}
    		performSearch(searchObj, "#SalesOrderGrid");
    	}
  