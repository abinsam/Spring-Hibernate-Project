
$(function(){
	   $("#statusSelect").chosen({no_results_text: "No results matched"});
	   $('#statusSelect').trigger('liszt:updated');

	   $( "#startDate" ).datepicker({dateFormat : "dd-mm-yy",
	        maxDate:'today',
           onSelect: function(dateStr)
           {
           var min = $('#startDate').datepicker('getDate'); 
           $('#endDate').datepicker('option', {minDate : min});
     }});
	$( "#endDate" ).datepicker({dateFormat : "dd-mm-yy", minDate:$('#startDate').datepicker('getDate'), maxDate:'today'});

	   
	   
	   
    	$("#salesOrderReportGrid").jqGrid({
		datatype: 'local',
	 	width:'70px',
	 	mtype: 'POST',
	   	colNames:['Sales Order No','PartyHidden','Party','Id','PO No','Received Date(dd-MM-yyyy)','Acceptance Date(dd-MM-yyyy)','Delivery Date(dd-MM-yyyy)',
	             'Receipt Mode','Quanity','Mail status','Order Status'],
	   	colModel:[
   	          
   	        
   	          {name:'orderId',index:'orderId',width:50},
   	          {name:'customerName', index:'customerName', width:90,hidden:true} ,
   	           {name:'customerCode', index:'customerCode', width:70} ,
	          {name:'customerId',index:'customerId',width:50,editable:true,hidden:true},
   	          {name:'poDetails', index:'poDetails', width:30},
	          {name:'orderRecDate', index:'orderRecDate', width:60}, 
	   	      {name:'orderAcceptanceDate', index:'orderAcceptanceDate', width:60}, 
	   	      {name:'orderDeliveryDate', index:'orderDeliveryDate', width:60} ,
	   	      {name:'modeOfReceipt', index:'modeOfReceipt', width:50},
	   	      {name:'inputQuantity', index:'inputQuantity', width:50},
	   	      {name:'mailStatus',index : 'mailStatus',width : 10,hidden:true},
	   	      {name:'status', index:'status', width:40}
   	   
	   	],
	   	postData: {},
		rowNum:100,
	   	rowList:[5,10,20,30,40,100],
	   	height :330,
		autowidth : true,
		rownumbers : false,
	    pager: '#salesOrderReportPager',
	   	sortname: 'orderId',
	    viewrecords: true,
	    sortorder: "desc",
	    caption:"Sales Order History",
	    emptyrecords: "Empty records",
	    loadonce: false,
	    loadComplete: function() {},
	    jsonReader : {
	        root: "rows",
	        page: "page",
	        total: "total",
	        records: "records",
	        repeatitems: false,
	        cell: "cell",
	        id: "orderId"
	    },
	    ondblClickRow : function(id) {},
		gridComplete : function() {

		}
		
	}).navGrid('#salesOrderReportPager',{view:false, del:false, edit:false, search:false,add:false}
);
    	
     
});

function searchOrders(){
	var validSearch=validateSearchParams();
	if(validSearch==true){
	var fromDate=document.getElementById('startDate').value;
	var toDate=document.getElementById('endDate').value;
	var orderStatus = document.getElementById('statusSelect').value;
	   jQuery("#salesOrderReportGrid").setGridParam({datatype:'json'}); 
	   jQuery("#salesOrderReportGrid").setGridParam({ url: 'salesOrderReport/records'});
	   jQuery("#salesOrderReportGrid").setGridParam({postData: {fromDate:fromDate,toDate:toDate,orderStatus:orderStatus}}); 
	   jQuery("#salesOrderReportGrid").setCaption('Sales Order History from:'+fromDate+' to:'+toDate);
	   jQuery("#salesOrderReportGrid").trigger('reloadGrid');
	}
}

function validateSearchParams(){
	var fromDate=document.getElementById('startDate').value;
	var toDate=document.getElementById('endDate').value;
    if(fromDate==null || fromDate==""){
    	alert("Select from Date");
    	return false;
    }
    else if(toDate==null || toDate==""){
    	alert("Select to Date");
    	return false;
    }
    else return true;
}


function clearFn() {
	if ($("#statusSelect").val() != "") {
		document.getElementById('statusSelect').value = "";
		$('#statusSelect').trigger('liszt:updated');
	}
	if (document.getElementById('startDate').value != "")
		document.getElementById('startDate').value = "";
	if (document.getElementById('endDate').value != "")
		document.getElementById('endDate').value = "";
	

	jQuery("#salesOrderReportGrid").jqGrid('clearGridData');
}

function salesOrderReport(){
	var fromDate=document.getElementById('startDate').value;
	var toDate=document.getElementById('endDate').value;
	if (validateSearchParams()==true){
	location.href='salesOrderReport/salesOrderHistoryReport?fromDate='+fromDate+'&toDate='+toDate;
	}
}