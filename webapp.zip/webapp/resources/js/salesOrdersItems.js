$("#sucessPopUp").dialog({
    hide: 'slide',
    show: 'slide',
    autoOpen: false,
    height:70
});
$(".ui-dialog-titlebar").hide();
$("#loading").dialog({
    hide: 'slide',
    show: 'slide',
    autoOpen: false
});


var gridQtyValid=true;
var lastSelected;
var sentToWo=true;
$(function(){ 
		
   $("#statusSelect").chosen({no_results_text: "No results matched"});
   document.getElementById('statusSelect').value =document.getElementById('statusValue').value;
   $('#statusSelect').trigger('liszt:updated');
   $("#itemTypeSelect").chosen({no_results_text: "No results matched"});
   
   
    var orderId=document.getElementById('orderId').value;
		  $("#SalesOrderItemGrid").jqGrid({
			  url: 'salesItemsDetails/items/'+encodeURIComponent(orderId), 
			  datatype: 'json',
        	  mtype: 'POST',
        	   colNames:['OrderDetail Id','Order No','Item Id','hid','Item Code','Item Description',
        	             'Rate(Rs)','Quantity','Unit','Unithidd','Bundle','Balance Qty',
        	              'balHidden','Cu Weight(Kg)','PVC Weight(Kg)','woQty','Qty in Prodn','Store Qty',
        	              'Stocked Out qty','pdnQtyHiddn','StoreQtyHdn','outQtyHdn','WOs','DCs','Actions'],
	          	 colModel:[
	  		            
	  		              {name:'orderDetailId', index:'orderDetailId', width:10, viewable:false,hidden:true}, 
	  		              {name:'orderId', index:'orderId', width:10, viewable:false,editable:true,hidden:true}, 
	  		              {name:'itemId', index:'itemId', width:10, viewable:false,editable:true,hidden:true} ,
	  		              {name:'itemCode', index:'itemhidCode', width:10, viewable:false,editable:true,hidden:true} ,
	  		              {name:'itemCode', index:'itemCode', width:145, viewable:false} ,
	  		              {name:'itemDescription', index:'itemDescription', width:190, viewable:false} ,
	  			   	   
	  		              
	  			          {name:'rate', index:'rate', width:45,editable:true,editoptions :{maxlength:7,
 			            	  dataInit: function(element) {
 		                          $(element).keyup(function(){
 		                        		var  pattern =/^[+]?([0-9]+(?:[\.][0-9]*)?|\.[0-9]+)$/;
 		                                  var val1 = element.value;
		                                      if(!(pattern.test(val1)) && !(val1>0))
 		                                      {
 		                                    	  alert("Please enter  valid rate");
 		                                    	  gridQtyValid=false;
 		                                    	 jQuery("#SalesOrderItemGrid").trigger('reloadGrid');
 		                                     }else   gridQtyValid=true;
 		                                   });
 		                              }
	  		               ,maxlength:6}},
	  		              {name:'quantity', index:'quantity', width:40,editable:true,editoptions : {
	  			            dataInit: function(element) {
	  	                    	var patMatch = /^(\.\d{1,2}|\d{1,4}\.?\d{0,2}|\d{5}\.?\d?|\d{6}\.?\d?|\d{7}\.?\d?)$/;
	  	                          $(element).keyup(function(){
	  	                        	  var val1 = element.value;
	  	                        	 if(!patMatch.test(val1)) {
	  	                        		 alert("Please enter a valid quantity");
	  	                             	  gridQtyValid=false; 
	  	                        	  }
	  	                        	  else   gridQtyValid=true;
	  	                        	  
	  	                           });
	  	                      }}}, 
	                     {name:'unit', index:'unit', width:20} ,
	     			     {name:'unit', index:'unit', width:20,editable:true,hidden:true} ,

	  			       
	  			   	      {name:'bundleSize', index:'bundleSize', width:45,editable:true,editoptions : {size : 50,maxlength:8,
	  			        	  dataInit: function(element) {
		                          $(element).keyup(function(){
		                        		var  pattern = /^[1-9]\d*$/;
		                                  var val1 = element.value;
		                                      if(!(pattern.test(val1)))
		                                      {
		                                    	  alert("Please enter  valid bundle size");
		                                    	  gridQtyValid=false;
		                                    	  jQuery("#SalesOrderItemGrid").trigger('reloadGrid');
		                                     }else   gridQtyValid=true;
		                                   });
		                              } ,maxlength:6}}, 
 			   	    
	  			   	      
	  			   	      
	  			   	      {name:'balanceQty',index:'balanceQty', width:60, editable:false},
	      			      {name:'balanceQty',index:'balanceQty', width:10,editable:true,hidden:true},
	      			      {name:'weight', index:'weight', width:60},
	      			      {name:'pvcWeight', index:'pvcWeight', width:60, editable:true,editoptions : {size : 50,maxlength:8,
	  			        	  dataInit: function(element) {
		                          $(element).keyup(function(){
		                        		var  pattern = /^[+]?([0-9]+(?:[\.][0-9]*)?|\.[0-9]+)$/;
		                                  var val1 = element.value;
		                                      if(!(pattern.test(val1)))
		                                      {
		                                    	  alert("Please enter  valid PVC weight");
		                                    	  gridQtyValid=false;
		                                    	  jQuery("#SalesOrderItemGrid").trigger('reloadGrid');
		                                     }else   gridQtyValid=true;
		                                   });
		                              } ,maxlength:6}}, 
	      			      {name:'woQty',index:'woQty', width:10, editable:true,hidden:true},
	      			      {name:'productionQty',index:'productionQty', width:50},
	      			      {name:'completedQty',index:'completedQty', width:50},
	      			      {name:'dispatchedQty',index:'dispatchedQty', width:50},
	      			      {name:'productionQty',index:'productionQty', width:10, editable:true,hidden:true},
	      			      {name:'completedQty',index:'completedQty', width:10, editable:true,hidden:true},
	      			      {name:'dispatchedQty',index:'dispatchedQty', width:10, editable:true,hidden:true},
	      				  {name:'workOrderLink',index : 'workOrderLink',width : 50,sortable : false,editable : false},
	      				  {name:'dcLink',index : 'dcLink',width : 50,sortable : false,editable : false},
	      				  {name:'act',index:'act', width:50,sortable:false, viewable:false}
	  			   	     ],   
	  			    	postData: {},
			   			rowNum:100,
			   			rowList:[5,10,20,40,50,100,500,1000],
			   		   	height: 300,
			   		   	autowidth: true,
			   			rownumbers: false,
			   		   	pager: '#salesitempager',
			   		   	sortname: 'orderDetailId',
			   		    viewrecords: true,
			   		    sortorder: "desc",
			   		    caption:"Item List for Sales Order:"+orderId,
			   		    emptyrecords: "Empty records",
			   		    loadonce: false,
			   		    footerrow: true,
     		   		    jsonReader : {
			   		        root: "rows",
			   		        page: "page",
			   		        total: "total",
			   		        records: "records",
			   		        repeatitems: false,
			   		        cell: "cell",
			   		        id: "orderDetailId"
			   		    },
			   		    
        	   		 ondblClickRow : function(id) {
        	   	   	 if (id && id !== lastSelected) {
        	 				editRow(id);
        	 			}
        	 		},
        	 		
        	   	    gridComplete: function(){ 
        	   		 var totalWeight = $('#SalesOrderItemGrid').jqGrid('getCol','weight',false,'sum');
        	   		 var pvcWeight = $('#SalesOrderItemGrid').jqGrid('getCol','pvcWeight',false,'sum');
        	   		 var totalQuantity= $('#SalesOrderItemGrid').jqGrid('getCol','quantity',false,'sum');
        	   		 var balanceQuantity= $('#SalesOrderItemGrid').jqGrid('getCol','balanceQty',false,'sum');
                     var productionQuantity=$('#SalesOrderItemGrid').jqGrid('getCol','productionQty',false,'sum');
                     var storeQty=$('#SalesOrderItemGrid').jqGrid('getCol','completedQty',false,'sum');
                     var stockOutQty=$('#SalesOrderItemGrid').jqGrid('getCol','dispatchedQty',false,'sum');
        	   	 	  var totalCuWeight=Math.round(parseFloat(totalWeight) * 100) / 100;
        	   	 	  var totalQty=Math.round(parseFloat(totalQuantity) * 100) / 100;
        	   	 	  var balQty=Math.round(parseFloat(balanceQuantity) * 100) / 100;
                      var totalPdnQty=Math.round(parseFloat(productionQuantity) * 100) / 100;
                      var totalStoreQty=Math.round(parseFloat(storeQty) * 100) / 100;
                      var totalStockOutQty=Math.round(parseFloat(stockOutQty) * 100) / 100;
                      var totalPvcWt=Math.round(parseFloat(pvcWeight) * 100) / 100;
        	   	    	$('#SalesOrderItemGrid').jqGrid('footerData','set', {ID: 'Total:', weight: totalCuWeight});
        	   	    	$('#SalesOrderItemGrid').jqGrid('footerData','set', {ID: 'Total:', pvcWeight: totalPvcWt});
        	   	    	$('#SalesOrderItemGrid').jqGrid('footerData','set', {ID: 'Total:', quantity: totalQty});
        	   	    	$('#SalesOrderItemGrid').jqGrid('footerData','set', {ID: 'Total:', balanceQty: balQty});
        	   	    	$('#SalesOrderItemGrid').jqGrid('footerData','set', {ID: 'Total:', itemCode: "Item Code"});
        	   	    	$('#SalesOrderItemGrid').jqGrid('footerData','set', {ID: 'Total:', itemDescription: "Item Description"});
        	   	    	$('#SalesOrderItemGrid').jqGrid('footerData','set', {ID: 'Total:', rate: "Rate"});
        	   	    	$('#SalesOrderItemGrid').jqGrid('footerData','set', {ID: 'Total:', unit: "-"});
        	   	    	$('#SalesOrderItemGrid').jqGrid('footerData','set', {ID: 'Total:', bundleSize: "-"});

        	   	    	$('#SalesOrderItemGrid').jqGrid('footerData','set', {ID: 'Total:', productionQty: totalPdnQty});
        	   	    	$('#SalesOrderItemGrid').jqGrid('footerData','set', {ID: 'Total:', completedQty: totalStoreQty});
        	   	    	$('#SalesOrderItemGrid').jqGrid('footerData','set', {ID: 'Total:', dispatchedQty: totalStockOutQty});


        	   	    	var ids = jQuery("#SalesOrderItemGrid").jqGrid('getDataIDs');
        	   	    	for ( var i = 0; i < ids.length; i++) {
        					var cl = ids[i];
        					be = "<input style='height:22px; width:35px;' type='button' value='Edit' id='editRow"+cl+"' onclick=\"editRow('"+ cl + "');\" />";
        					de = "<input style='height:22px; width:30px;' type='button' value='Del' id='delRow"+cl+"' onclick=\"delRow('"+ cl + "');\" />";
        					se = "<input style='height:22px; width: 29px;' type='button' value='Save' hidden='hidden'  id='saveRow"+cl+"' onclick=\"saveRow('"+ cl + "');\" />";
        					ce = "<input style='height:22px;width:39px;' type='button' value='Cancel' hidden='hidden' id='restoreRow"+cl+"' onclick=\"restoreRow('"+ cl + "');\" />";
        					woLink = "<button class='btn btn-mini' style='font-weight: bold;' id='workOrderLink"
								+ cl
								+ "' "
								+ "onclick=\"openWorkOrderPage('"
								+ cl
								+ "');\" >WO</button>";
        					
        					dcLink = "<button class='btn btn-mini' style='font-weight: bold;' id='dcLink"
								+ cl
								+ "' "
								+ "onclick=\"openDcPage('"
								+ cl
								+ "');\" >DC</button>";
        					$("#SalesOrderItemGrid").jqGrid('setRowData', ids[i],
        							{
        								act : be + de + se + ce,
        								workOrderLink : woLink,
        								dcLink:dcLink
        							});

        				}
	               },
		   		    loadComplete: function() {},
	               editurl : "salesItemsDetails/modifyitems"
  	   	    	   });
		  jQuery("#SalesOrderItemGrid").jqGrid('navGrid','#salesitempager',{view:false, del:false,add:false, edit:false, search:false});


});

function editRow(id) {
	  var orderStatus = document.getElementById('statusValue').value;
	  
	  if(orderStatus=="Pending" || orderStatus=="Approved For Prodn" || orderStatus=="Created"){
	     $.ajax({type:'POST', 
	        url: 'workorder/checkStatus/'+ encodeURIComponent(id),
	       success: function(response) {
	           if(response=="exist"){
                 alert("Note - you cannot modify the quantities");
	           sentToWo==false;
	           }else{
	           sentToWo=true;
	           }
	             restoreRow(lastSelected);
	         	 lastSelected = id;
	        	$('#SalesOrderItemGrid').jqGrid('editRow', id, {
					"keys" : true,
					"oneditfunc" : hideActButtons,
					aftersavefunc : function(savedId, response) {
						showActButtons(savedId);
					},
					afterrestorefunc : showActButtons
				});
       }});
  		} else {
			alert(orderStatus + " Sales Order cannot be modified ");

}}
function delRow(id) {
	  var orderStatus=document.getElementById('statusValue').value;
	
	  if(orderStatus=="Pending" || orderStatus=="Approved For Prodn" || orderStatus=="Created"){
	    if(confirm("Are you sure you want to delete the order?")){
	      $.ajax({type:'POST', 
	        url: 'workorder/checkStatus/'+ encodeURIComponent(id),
	        success: function(response) {
	            if(response=="exist"){
	          alert("SO Item sent to Wo level.Cannot delete Sales Order!");
	        }
	        else{
	          $.ajax({type:'POST', 
	            url: 'orderdetails/delete/'+ encodeURIComponent(id),
	            success: function(response) {
	           
	              var soNo=document.getElementById('orderId').value;;
	            jQuery("#SalesOrderItemGrid").setGridParam({datatype:'json'}); 
	                 jQuery("#SalesOrderItemGrid").setGridParam({ url: 'salesItemsDetails/items/'+ encodeURIComponent(soNo)});
	                  jQuery("#SalesOrderItemGrid").trigger('reloadGrid');             
	            }
	          });
	        }
	      
	      }});
	    }
	   
	  }else alert("Note- "+orderStatus+" cannot be deleted");

	  }

	function saveRow(id) {
	    if (gridQtyValid==true){
		  var orderStatus = document.getElementById('statusValue').value;
		if (orderStatus == "Pending" || orderStatus == "Approved For Prodn" ) {
		$('#SalesOrderItemGrid').saveRow(id, {
				aftersavefunc : function(id, response) {
					showActButtons(id);
			}
			});
		jQuery("#SalesOrderItemGrid").trigger("reloadGrid");
		} /*else {
			alert(orderStatus + " Sales Order cannot be modified");
		}*/
	}else alert("Enter valid numbers");
	}


    	function restoreRow(id) {
    		$('#SalesOrderItemGrid').jqGrid('restoreRow',id,
    				{
    					afterrestorefunc : showActButtons
    				});
    	}

    	/*
    	 * Hides the Edit and Del Row Buttons on jqGrid
    	 * and activates the Save and restore(cancel) button
    	 * 
    	 */
    	function hideActButtons(id){
    		$('#editRow' + id).hide();
    		$('#delRow' + id).hide();
    		$('#saveRow' + id).show();
    		$('#restoreRow' + id).show();
    		pickdates(id);
    	}

    	/*
    	 * Shows the Edit and Del Row Buttons on jqGrid
    	 * and hides the Save and restore(cancel) button
    	 * 
    	 */
    	function showActButtons(id) {
    		$('#editRow' + id).show();
    		$('#delRow' + id).show();
    		$('#saveRow' + id).hide();
    		$('#restoreRow' + id).hide();
    		lastSelected = null;
    	}
   
    	
    	$('#saveOrderStatus').click(function(){
    		var orderStatus=document.getElementById('statusSelect').value;
    		var orderId=document.getElementById('orderId').value;
    		var customer=document.getElementById('customerName').value;
    		var lmeDetails=document.getElementById('lmeDetails').value;
    	
    		if(orderStatus=="Approved"){
    			$.ajax({type:'POST',
    				url: 'salesItemsDetails/checkRates',
    				data:'orderId=' + orderId,
    				success: function(response) {
    				if(response!="rateValid"){
    						alert("Valid rates should be there for Approval");
    				}else{
    					if(lmeDetails==null ||lmeDetails=="" || lmeDetails==0){
    		    			alert("Please update LME details before approving");
    		    		}else{
    		        		$.ajax({type:'POST',
    		        			url: 'viewSalesOrders/updateOrderStatus',
    		        			data:'orderId=' + orderId + 
    		    			     '&orderStatus=' + orderStatus+
    		    			     '&lmeDetails=' + lmeDetails,
    		        			success: function(response) {
    	    		           document.getElementById('statusValue').value=orderStatus;
    		                   $("#sucessPopUp").dialog('open').html("<p>Order Details Updated</p>");
    		                  setTimeout( function () { 
    		                             window.parent.$('#sucessPopUp').dialog('close'); 
    		                         }, 1000) ;// milliseconds delay
    		                   if(orderStatus=="Approved"){
    		                	   if (confirm("Do you want send mail to "+customer+" ? ")){
    		                   	    sendSalesOrderMail();
    		                	   }}
    		               	 jQuery("#SalesOrderItemGrid").trigger('reloadGrid');
    		                    }});	
    		    	    }
    		    	}
    			  }});
 
     		
    	}else{
      		$.ajax({type:'POST',
    			url: 'viewSalesOrders/updateOrderStatus',
    			data:'orderId=' + orderId + 
			     '&orderStatus=' + orderStatus+
			     '&lmeDetails=' + lmeDetails,
    			success: function(response) {
               $("#sucessPopUp").dialog('open').html("<p>Order Details Updated</p>");
               document.getElementById('statusValue').value==orderStatus;
              setTimeout( function () { 
                         window.parent.$('#sucessPopUp').dialog('close'); 
                     }, 1000) ;// milliseconds delay
          	 jQuery("#SalesOrderItemGrid").trigger('reloadGrid');
                }});	
    	}
       	});

   function validateRateFunction(){
	  	var orderId=document.getElementById('orderId').value;
  		$.ajax({type:'POST',
			url: 'salesItemsDetails/checkRates',
			data:'orderId=' + orderId,
			success: function(response) {
			if(response!="rateValid"){
					alert("Valid rates should be there for Approval");
					return false;
			}else{
				return true;
			}
           }});

   }

   	$('#backToOrder').click(function(){
   	 window.close();
	});
   	
   	$(document).keypress(function(e) {
   		var key = e.charCode ? e.charCode : e.keyCode ? e.keyCode : 0;
   	    if(e.which == 13 || key==13) {
   	    	var ids = $("#SalesOrderItemGrid").jqGrid('getDataIDs');
   	    	for ( var i = 0; i < ids.length; i++) {
   				var cl = ids[i];
   				saveRow(cl);
   	       	} }
   	   });

   	
   	function clearFn(){
   		var orderNos=document.getElementById('orderId').value;
  	  if($("#itemTypeSelect").val()!=""){ 
  		document.getElementById('itemTypeSelect').value ="";
     	$('#itemTypeSelect').trigger('liszt:updated');
  	  }
   
	     jQuery("#SalesOrderItemGrid").setGridParam({datatype:'json'}); 
		 jQuery("#SalesOrderItemGrid").setGridParam({ url: 'salesItemsDetails/items/'+ encodeURIComponent(orderNos)});
		  jQuery("#SalesOrderItemGrid").setGridParam({postData: {itemType:""}}); 
		 jQuery("#SalesOrderItemGrid").trigger('reloadGrid');
	}
   	
   	$("#itemTypeSelect").chosen().change( function() {
   		var orderNo=document.getElementById('orderId').value;
   		var itemType=document.getElementById('itemTypeSelect').value;
   	     jQuery("#SalesOrderItemGrid").setGridParam({datatype:'json'}); 
		 jQuery("#SalesOrderItemGrid").setGridParam({ url: 'salesItemsDetails/items/'+ encodeURIComponent(orderNo)});
		  jQuery("#SalesOrderItemGrid").setGridParam({postData: {itemType:itemType}}); 
		 jQuery("#SalesOrderItemGrid").trigger('reloadGrid');

   	});
   	
   	function sendSalesOrderMail(){
   		var orderStatus=document.getElementById('statusSelect').value;
   		var mailSendStatus=document.getElementById('mailSent').value;
   		if(orderStatus=="Approved"){
   			if(mailSendStatus=="Yes"){
   			  if(confirm("Do you want to resend the Sales Order mail?"))
   				sendCustomermailAjaxCall();
   			}else{
   				sendCustomermailAjaxCall();
   			}

   		}else{
   			alert("Please approve sales order");
   		}
   	}
   	
   	function sendCustomermailAjaxCall(){
   		var orderNo=document.getElementById('orderId').value;
		$.ajax({type:'POST',
			url: 'salesItemsDetails/sendSalesOrderMail',
			data:'orderId=' + orderNo,

			   beforeSend: function(){
		           $("#loading").dialog('open').html("<p>Processing Request...</p>");
		        },
				success : function(response) {
					alert("Order Acceptance mail sent successfully");
					document.getElementById('mailSent').value ="Yes";
				},
			    error:function(e){
	            	alert("Error!!!");
	        },
	        complete: function() {
	        	 $("#loading").dialog('close');
	        }
           });
   	} 	
   	
   	function closeFn() {
   		window.close();
   	}

   	function openWorkOrderPage(soItemid) {
 		var count = $('#workOrderTable tr').length;
   		var table = document.getElementById("workOrderTable");
   		if(count>0){
   			for(var k=0;k<count;k++)
					document.getElementById("workOrderTable").deleteRow(0);
   		}
   		
   		var salesOrderItemId = soItemid;
   		if(salesOrderItemId!=null){
   			$.ajax({type:'POST',
   				url: 'salesItemsDetails/workOrderRecords',
   				data:'salesOrderItemId=' + salesOrderItemId,
  					success : function(response) {
  						if(response!=null && response.length>0){
  			     		for(var k=0;k<response.length;k++){
  								var row = table.insertRow(0);
  						        var cell = row.insertCell(0);
  						        cell.innerHTML = response[k];
  						  }
  						}else{
  							   var row = table.insertRow(0);
						        var cell = row.insertCell(0);
						      cell.innerHTML = "No Work Orders";
  						}
   					},
   				    error:function(e){
   		            	alert("Error!!!");
   		        }
   	           });

   		$("#dialog-pvc-modal").dialog({
   			width : 200,
   			height : 200

   		});
   	}
   	}
	function openDcPage(soItemid) {
 		var count = $('#dcTable tr').length;
   		var table = document.getElementById("dcTable");
   		if(count>0){
   			for(var k=0;k<count;k++)
					document.getElementById("dcTable").deleteRow(0);
   		}
   		
   		var salesOrderItemId = soItemid;
   		if(salesOrderItemId!=null){
   			$.ajax({type:'POST',
   				url: 'salesItemsDetails/deliverychallanRecords',
   				data:'salesOrderItemId=' + salesOrderItemId,
  					success : function(response) {
  				
  						if(response!=null && response.length>0){
  							
  			     		for(var k=0;k<response.length;k++){
  			     		
  								var row = table.insertRow(0);
  						        var cell = row.insertCell(0);
  						        cell.innerHTML = response[k];
  						     
  			     		}
  						}else{
  							   var row = table.insertRow(0);
						        var cell = row.insertCell(0);
						      cell.innerHTML = "Item does not belong to any delivery challan";
  						}
   					},
   				    error:function(e){
   		            	alert("Error!!!");
   		        }
   	           });

   		$("#dialog-dc-modal").dialog({
   			width : 350,
   			height : 200

   		});
   	}
   	}
   	function openWoPage(){
   		alert("hello");
   	}
