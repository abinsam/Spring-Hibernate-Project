var gridQtyValid = true;
var systemDate = new Date();
var month="";
var year="";
$(function() {

	$("#monthYearPicker").focus(function () {$(".ui-datepicker-calendar").hide();});
	$('#monthYearPicker').datepicker({
	    changeYear: true,
	    changeMonth: true,
	    changeDate :false,
	    showButtonPanel: true,
	    dateFormat: 'MM yy',
	    onClose: function(dateText, inst) { 
	        year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
	        month = $("#ui-datepicker-div .ui-datepicker-month :selected").val();
	        $(this).datepicker('setDate', new Date(year,month, 1));
	        changeWoOnMonthYear();
	    }
	});
	$('#monthYearPicker').datepicker('setDate',systemDate); 
	$("#monthYearPicker").focus(function () {$(".ui-datepicker-month").show();});
	$("#monthYearPicker").focus(function () {$(".ui-datepicker-year").show();});
	
	$("#processTypeSelect").chosen({
		no_results_text : "No results matched"
	});
	$("#scrapItemSelect").chosen({
		no_results_text : "No results matched"
	});
	$("#workOrderNoSelect").chosen({
		no_results_text : "No results matched"
	});
	$("#mwdWoMachineNoSelect").chosen({
		no_results_text : "No results matched"
	});
	$("#itemSelect").chosen({
		no_results_text : "No results matched"
	});
	$("#shiftSelect").chosen({
		no_results_text : "No results matched"
	});
	document.getElementById('itemDescription').disabled = true;
	document.getElementById('copperScrap').disabled = true;
	document.getElementById('pvcScrap').disabled = true;
	$("#scrapDate").datepicker({
		dateFormat : "dd-mm-yy",
		maxDate : 'today'
	});

});
$.ajax({
	type : 'POST',
	url : 'scrap/showTotalScrap',
	success : function(response) {
		document.getElementById('copperScrap').value = response[0];
		document.getElementById('pvcScrap').value = response[1];

	}
});

var lastSelected;
$(function() {

	$("#ScrapGrid")
			.jqGrid(
					{

						datatype : 'json',
						url : 'scrap/records',
						mtype : 'POST',
						colNames : [ 'scrapId', 'Work Order No', 'WO hidd',
								'itemid', 'Item Code', 'Pdt type',
								'Item Description', 'Scrap Date', 'Shift',
								'Supervisor', 'Sup', 'MchNo', 'Machine',
								'Quantity', 'stockStatus', 'Stocked In Status',
								'Stock In', 'Action' ],
						colModel : [
								{
									name : 'scrapId',
									index : 'scrapId',
									width : 10,
									hidden : true
								},
								{
									name : 'workOrderNo',
									index : 'workOrderNo',
									width : 50
								},
								{
									name : 'workOrderNo',
									index : 'workOrderNo',
									width : 10,
									editable : true,
									hidden : true
								},
								{
									name : 'itemId',
									index : 'itemId',
									width : 50,
									editable : true,
									hidden : true
								},
								{
									name : 'itemCode',
									index : 'itemCode',
									width : 100,
									sortable : true
								},
								{
									name : 'productKey',
									index : 'productKey',
									width : 50
								},
								{
									name : 'itemDescription',
									index : 'itemDescription',
									width : 100
								},
								{
									name : 'scrapDate',
									index : 'scrapDate',
									width : 50,
									editable : true
								},
								{
									name : 'shiftPattern',
									index : 'shiftPattern',
									width : 50,
									editable : true,
									edittype : 'select',
									editoptions : {
										value : "Day:Day;Night:Night"
									}
								},
								{
									name : 'supervisor',
									index : 'supervisor',
									width : 50
								},
								{
									name : 'supervisor',
									index : 'supervisor',
									width : 10,
									hidden : true,
									editable : true
								},
								{
									name : 'machineNo',
									index : 'machineNo',
									width : 10,
									hidden : true,
									editable : true
								},
								{
									name : 'machineDesciption',
									index : 'machineDesciption',
									width : 50
								},
								{
									name : 'quantity',
									index : 'quantity',
									width : 50,
									editable : true,
									editoptions : {
										dataInit : function(element) {
											$(element)
													.keyup(
															function() {
																var val1 = element.value;
																var num = new Number(
																		val1);
																if (isNaN(num)
																		|| !(parseInt(num) > 0)) {
																	alert("Please enter a valid quantity");
																	gridQtyValid = false;
																} else
																	gridQtyValid = true;
															});
										}
									}
								}, {
									name : 'stockedInStatus',
									index : 'stockedInStatus',
									width : 10,
									editable : true,
									hidden : true
								}, {
									name : 'stockedInStatus',
									index : 'stockedInStatus',
									width : 50,
									editable : false
								}, {
									name : 'stockLink',
									index : 'stockLink',
									width : 40,
									editable : false,
									sortable:false
								}, {
									name : 'act',
									index : 'act',
									width : 60,sortable : false,editable : false
								}

						],
						postData : {},
						rowNum : 100,
						rowList : [ 5, 10, 20, 30, 40,100 ],
						height : 300,
						autowidth : true,
						rownumbers : false,
						pager : '#ScrapPager',
						sortname : 'scrapId',
						viewrecords : true,
						sortorder : "desc",
						caption : "Scrap Details",
						emptyrecords : "Empty records",
						loadonce : false,
						footerrow : true,
						loadComplete : function() {
						},
						jsonReader : {
							root : "rows",
							page : "page",
							total : "total",
							records : "records",
							repeatitems : false,
							cell : "cell",
							id : "scrapId"
						},
						ondblClickRow : function(id) {
							if (id && id !== lastSelected) {
								editRow(id);
							}
						},
						gridComplete : function() {

							var totalQuantity = $('#ScrapGrid').jqGrid(
									'getCol', 'quantity', false, 'sum');

							var totalScrapWeight = Math
									.round(parseFloat(totalQuantity) * 100) / 100;

							$('#ScrapGrid').jqGrid('footerData', 'set', {
								ID : 'Total:',
								quantity : totalScrapWeight
							});

							var pvcScrap = parseFloat(0);
							var cuScrap = parseFloat(0);
							var ids = jQuery("#ScrapGrid").jqGrid('getDataIDs');
							for ( var i = 0; i < ids.length; i++) {
								var cl = ids[i];
								be = "<input style='height:22px; width:35px;' type='button' value='Edit' id='editRow"
										+ cl
										+ "' onclick=\"editRow('"
										+ cl
										+ "');\" />";
								de = "<input style='height:22px; width:30px;' type='button' value='Del' id='delRow"
										+ cl
										+ "' onclick=\"delRow('"
										+ cl
										+ "');\" />";
								se = "<input style='height:22px; width: 29px;' type='button' value='Save' hidden='hidden'  id='saveRow"
										+ cl
										+ "' onclick=\"saveRow('"
										+ cl
										+ "');\" />";
								ce = "<input style='height:22px;width:39px;' type='button' value='Cancel' hidden='hidden' id='restoreRow"
										+ cl
										+ "' onclick=\"restoreRow('"
										+ cl
										+ "');\" />";
								sdLink = "<button class='btn btn-mini' id='itemDetailsLink"
										+ cl
										+ "' "
										+ "onclick=\"stockInScrap('"
										+ cl
										+ "');\" >Stock In </button>";

								$("#ScrapGrid").jqGrid('setRowData', ids[i], {
									act : be + de + se + ce,
									stockLink : sdLink

								});
								if (jQuery('#ScrapGrid').jqGrid('getCell',
										ids[i], 'stockedInStatus') == "Yes") {
									if (jQuery('#ScrapGrid').jqGrid('getCell',
											ids[i], 'productKey') == "CS") {
										cuScrap = parseFloat(cuScrap)
												+ parseFloat(jQuery(
														'#ScrapGrid').jqGrid(
														'getCell', ids[i],
														'quantity'));
									}
									if (jQuery('#ScrapGrid').jqGrid('getCell',
											ids[i], 'productKey') == "PS") {
										pvcScrap = parseFloat(pvcScrap)
												+ parseFloat(jQuery(
														'#ScrapGrid').jqGrid(
														'getCell', ids[i],
														'quantity'));
									} // var balQty=grid.jqGrid ('getCell',
										// id, 'balanceQty');
								}
								if ($("#ScrapGrid").getCell(cl,
										"stockedInStatus") == "Yes") {
									$("#ScrapGrid").jqGrid('setRowData',
											ids[i], false, {
												color : 'black',
												weightfont : 'bold',
												background : ' #3BB9FF'
											});
								}
							}
							document.getElementById('copperScrap').value = cuScrap;
							document.getElementById('pvcScrap').value = pvcScrap;

						},
						editurl : "scrap/crud"
					}).navGrid('#ScrapPager', {
				view : false,
				del : false,
				edit : false,
				search : false,
				add:false
			}

			);

	$('#addBtn').click(function() {
		{
			scrapGrid.jqGrid('addRow', {
				rowID : "new_row",
				addRowParams : {
					"keys" : true,
					"oneditfunc" : hideActButtons,
					aftersavefunc : function(savedId, response) {
						showActButtons(savedId);
					},
					afterrestorefunc : showActButtons

				}
			});
		}

	});
});
function validateSearchParams(){

	  if($("#monthYearPicker").val()=="" || $("#monthYearPicker").val()==null){
	    	alert("Month and Year empty! please select month and year");
	    	return false;
	    }
	  if($("#processTypeSelect").val()=="" || $("#processTypeSelect").val()==null){
	    	alert("Process Type empty! please select Process Type");
	    	return false;
	    }
	    else return true;
}

function changeWoOnMonthYear(){
	
	    $('#workOrderNoSelect').children().remove();
		$('#workOrderNoSelect').val('').trigger('liszt:updated');
		var processType = $('#processTypeSelect').val();
		
		$('#ScrapGrid').jqGrid('clearGridData');
		jQuery("#ScrapGrid").setCaption("Scrap Details");
		
		var validSearch=validateSearchParams();
		if(validSearch==true){
		 $.ajax({type:'POST',
			 url : 'scrap/getWorkOrders',
				data: {'processType':processType,"month":month,"year":year}, 
			  success: function(response) {
					
					if (response.length == 0) {
						alert("There is no work order created for "+processType+" in "+monthText+" "+year+"");

			        }
					if(response.length != 0){
						for(var i=0;i< response.length;i++){
							$('#workOrderNoSelect').append('<option selected="selected">'+ "" + '</option>');
							$('#workOrderNoSelect').append('<option >' + response[i]+ '</option>');
							$('#workOrderNoSelect').trigger('liszt:updated');
						}
					}else{
						$('#workOrderNoSelect').empty();	
						$('#workOrderNoSelect').children().remove();
						$('#workOrderNoSelect').val('').trigger('liszt:updated');
					}
				
		 }
		 });
	 }
}


$("#processTypeSelect").chosen().change(
				function() {
					var processType = $('#processTypeSelect').val();
				     month = $("#ui-datepicker-div .ui-datepicker-month :selected").val();
				     year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();

				     monthText = $("#ui-datepicker-div .ui-datepicker-month :selected").text();
					$('#workOrderNoSelect').children().remove();
					$('#workOrderNoSelect').val('').trigger('liszt:updated');
					$.ajax({
								type : 'POST',
								url : 'scrap/getWorkOrders',
								data: {'processType':processType,"month":month,"year":year}, 
								success : function(response) {
									$('#workOrderNoSelect').empty();
									if (response.length == 0) {
										alert("There is no work order created for "+processType+" in "+monthText+" "+year+"");
									}
									if (response.length != 0) {
										for ( var i = 0; i < response.length; i++) {
											$('#workOrderNoSelect').append('<option selected="selected">'+ "" + '</option>');
											$('#workOrderNoSelect').append('<option >' + response[i]+ '</option>');
											$('#workOrderNoSelect').trigger('liszt:updated');
										}
									} else {
										$('#workOrderNoSelect').empty();
									}

								}
							});

				});

$("#workOrderNoSelect").chosen().change(function() {
	var workOrderNo = $('#workOrderNoSelect').val();
	
	$.ajax({
		type : 'POST',
		url : 'scrap/getMachineDesc/' + encodeURIComponent(workOrderNo),
		success : function(response) {

			if (response[0] != null)
				document.getElementById('machineNo').value = response[0];

			jQuery("#ScrapGrid").setGridParam({datatype : 'json'});
			jQuery("#ScrapGrid").setGridParam({url : 'scrap/records/' + encodeURIComponent(deliveryChallanNo)});
			jQuery("#ScrapGrid").trigger('reloadGrid');

		}
	});

});
function editRow(id) {
	var grid = jQuery('#ScrapGrid');
	var stockInStatus = grid.jqGrid('getCell', id, 'stockedInStatus');
	if (stockInStatus != "Yes") {
		restoreRow(lastSelected);
		lastSelected = id;
		$('#ScrapGrid').jqGrid('editRow', id, {
			"keys" : true,
			"oneditfunc" : hideActButtons,
			aftersavefunc : function(savedId, response) {
				showActButtons(savedId);
			},
			afterrestorefunc : showActButtons
		});
	} else {
		alert("Selected Item already stocked In");
	}
}

function delRow(id) {

	var grid = jQuery('#ScrapGrid');
	var stockInStatus = grid.jqGrid('getCell', id, 'stockedInStatus');
	if (stockInStatus == "No") {
		if (confirm("Are you sure you want to delete ?")) {
			var oper = "del";
			$.ajax({
				type : 'POST',
				url : 'scrap/crud',
				data : {
					'id' : id,
					'oper' : oper
				},
				success : function(response) {
					jQuery("#ScrapGrid").trigger('reloadGrid');
				}
			});

		}
		;
	} else {
		alert("Selected Item already stocked In");
	}
}

function saveRow(id) {
	if (gridQtyValid == true) {
		$('#ScrapGrid').saveRow(id, {
			aftersavefunc : function(id, response) {
				showActButtons(id);
			}
		});
	} else {
		alert("Enter valid quanity");
	}
}

function restoreRow(id) {
	$('#ScrapGrid').jqGrid('restoreRow', id, {
		afterrestorefunc : showActButtons
	});
}

/*
 * Hides the Edit and Del Row Buttons on jqGrid and activates the Save and
 * restore(cancel) button
 * 
 */
function hideActButtons(id) {
	$('#editRow' + id).hide();
	$('#delRow' + id).hide();
	$('#saveRow' + id).show();
	$('#restoreRow' + id).show();
	pickdates(id);
}

/*
 * Shows the Edit and Del Row Buttons on jqGrid and hides the Save and
 * restore(cancel) button
 * 
 */
function showActButtons(id) {
	$('#editRow' + id).show();
	$('#delRow' + id).show();
	$('#saveRow' + id).hide();
	$('#restoreRow' + id).hide();
	lastSelected = null;
}

$("#itemSelect").chosen().change(function() {

	var itemCode = $('#itemSelect').val();

	$.ajax({
		type : 'POST',
		url : 'scrap/getItemDescription/' + encodeURIComponent(itemCode),
		success : function(response) {
			var valueList = response;
			document.getElementById('itemDescription').value = "";
			document.getElementById('itemDescription').value = valueList[0];

		}
	});

});

function addScrapDetails() {
	var valid = validateDetails();
	if (valid == true) {
		$.ajax({
			type : 'POST',
			url : 'scrap/createScrapEntry',
			data : '&workOrderNoSelect=' + $("#workOrderNoSelect").val()
					+ '&machine=' + $("#machineNo").val()
					+'&scrapDate='+ $("#scrapDate").val() +
					'&shiftSelect='	+ $("#shiftSelect").val() +
					'&quantity='+ $("#quantity").val() +
					'&itemSelect='+ $("#itemSelect").val(),
			success : function(response) {
				jQuery("#ScrapGrid").setGridParam({
					datatype : 'json'
				});
				jQuery("#ScrapGrid").setGridParam({
					url : 'scrap/records'
				});
				jQuery("#ScrapGrid").trigger('reloadGrid');
			}
		});
	}
}
function validateDetails() {
	if (document.getElementById('processTypeSelect').value == "") {
		alert("Select Process Type");
		return false;
	}
	if (document.getElementById('workOrderNoSelect').value == "") {
		alert("Select Work Order No");
		return false;
	}
	if (document.getElementById('scrapDate').value == "") {
		alert("Select Scrap Date");
		return false;
	}
	if (document.getElementById('shiftSelect').value == "") {
		alert("Select Shift");
		return false;
	}
	if (document.getElementById('quantity').value == "") {
		alert("Enter Quantity");
		document.getElementById('quantity').value = "";
		return false;
	}

	if (isNaN(document.getElementById('quantity').value)) {
		alert("Enter Valid Quantity");
		document.getElementById('quantity').value = "";
		return false;
	}

	if (document.getElementById('itemSelect').value == "") {
		alert("Select Item Code");
		return false;
	}

	else
		return true;
}

function stockInScrap(id) {
	var grid = jQuery('#ScrapGrid');
	var stockInStatus = grid.jqGrid('getCell', id, 'stockedInStatus');
	var quantity = grid.jqGrid('getCell', id, 'quantity');

	if (stockInStatus == 'Yes') {
		alert("Scrap Has Already Been Stocked In.");
	} else {
		if (confirm("Are You Sure You Want To Stock In?")) {
			$.ajax({
				type : 'POST',
				datatype : 'json',
				url : 'scrap/stockInScrap/' + encodeURIComponent(id),
				data : {
					"quantity" : quantity
				},
				success : function(response) {
					jQuery("#ScrapGrid").setGridParam({datatype : 'json'});
					jQuery("#ScrapGrid").setGridParam({	url : 'scrap/records'});
					jQuery("#ScrapGrid").trigger('reloadGrid');
					var itemCode=$("#scrapItemSelect").val();
					$.ajax({
						type : 'POST',
						url : 'scrap/fetchScrapQuantity',
						data:{"itemCode":itemCode},
						success : function(response) {
						if(response!="")
						document.getElementById('scrapQuantity').value=response[0];
						}
					});

				}
			});
		}
	}
}

$('#clearSearchBox').click(function() {
	if ($("#processTypeSelect").val() != "") {
		document.getElementById('processTypeSelect').value = "";
		$('#processTypeSelect').trigger('liszt:updated');
	}
	
	if ($("#itemSelect").val() != "") {
		document.getElementById('itemSelect').value = "";
		$('#itemSelect').trigger('liszt:updated');
	}
	if ($("#shiftSelect").val() != "") {
		document.getElementById('shiftSelect').value = "";
		$('#shiftSelect').trigger('liszt:updated');
	}
	
	if ($("#workOrderNoSelect").val() != "") {
		document.getElementById('workOrderNoSelect').value = "";
		$('#workOrderNoSelect').trigger('liszt:updated');
	}

	if (document.getElementById('itemDescription').value != "")
		document.getElementById('itemDescription').value = "";

	if (document.getElementById('scrapDate').value != "")
		document.getElementById('scrapDate').value = "";

	if (document.getElementById('quantity').value != "")
		document.getElementById('quantity').value = "";

	if (document.getElementById('machineNo').value != "")
		document.getElementById('machineNo').value = "";
	
	$('#monthYearPicker').datepicker('setDate',systemDate);
	month = $("#ui-datepicker-div .ui-datepicker-month :selected").val();
    year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
	$('#ScrapGrid').jqGrid('clearGridData');
	 jQuery("#ScrapGrid").setCaption("Scrap Details");
		
});

function createSalesOrder() {
	url = 'orders';
	window.open(url, '_blank');

}

function pickdates(id) {
	$("#" + id + "_scrapDate", "#ScrapGrid").datepicker({
		dateFormat : "dd-mm-yy"
	});
}

$("#scrapItemSelect").chosen().change(function() {
	var itemCode=$("#scrapItemSelect").val();
	$.ajax({
		type : 'POST',
		url : 'scrap/fetchScrapQuantity',
		data:{"itemCode":itemCode},
		success : function(response) {
			document.getElementById('scrapQuantity').value=response[0];
		}
	});
});
