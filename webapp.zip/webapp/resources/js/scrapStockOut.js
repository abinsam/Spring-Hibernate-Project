var woQtyValid=true;
var lastSelected;
$(function() {
	$("#customerSelect").chosen({
		no_results_text : "No results matched"
	});
	$("#salesOrderNoSelect").chosen({
		no_results_text : "No results matched"
	});
	$("#deliveryDate").datepicker({
		dateFormat : "dd-mm-yy",
		maxDate : 'today'
	});

});

$(function() {

	$("#ScrapStockOutGrid")
			.jqGrid(
					{
						datatype : 'json',
						url : 'scrapStockOut/records',
						mtype : 'POST',
						multiselect : true,
						colNames : [ 'scrapStoreRegId', 'Item Id', 'Item Code',
								'Description', 'Stock Quantity','Stock Out Quantity','Actions'],
						colModel : [
								{name : 'scrapStoreRegId',index : 'scrapStoreRegId',width : 10,hidden:true},
								{name : 'itemId',index : 'itemId',width : 30,editable : true,hidden : true},
								{name : 'itemCode',index : 'itemCode',width : 60},
								{name : 'itemDescription',index : 'itemDescription',width : 100},
								{name : 'stockQuantity',index : 'stockQuantity',width : 50,editable : false},
								{name:'stockOutQuantity', index:'stockOutQuantity',width:50,editable:true,search: false,editoptions:{
				                       dataInit: function(element) {
				                              $(element).keyup(function(){
				                                  var val1 = element.value;
				                                  var num = new Number(val1);
				                                  if(isNaN(num))
				                                  {
				                                	  alert("Please enter a valid number");
				                                	  woQtyValid=false;
				                                 }
				                                  else
				                                	  woQtyValid=true;
				                                
				                              });
				                          }
				                      }},
				            	        {name:'act',index:'act', width:30, viewable:false,sortable:false},

						],
						postData : {},
						rowNum : 100,
						rowList : [ 5, 10, 20, 30, 40, 100 ],
						height : 300,
						width:1000,
						//autowidth : true,
						rownumbers : false,
						pager : '#scrapStockOutPager',
						sortname : 'scrapStoreRegId',
						viewrecords : true,
						sortorder : "desc",
						caption : "Scrap Store Details",
						emptyrecords : "Empty records",
						loadonce : false,
						footerrow : true,
						loadComplete : function() {
						},
						jsonReader : {
							root : "rows",
							page : "page",
							total : "total",
							records : "records",
							repeatitems : false,
							cell : "cell",
							id : "scrapStoreRegId"
						},
						onSelectRow : updateIdsOfSelectedRows,
						onSelectAll : function(aRowids, status) {
							updateIdsOfAllSelectedRows(aRowids, status);
						},
						loadComplete : function() {
							var $this = $(this), i, count;
							for (i = 0, count = idsOfSelectedRows.length; i < count; i++) {
								$this.jqGrid('setSelection',
										idsOfSelectedRows[i], false);
							}
						},
						  ondblClickRow : function(id) {
	        	   				if (id && id !== lastSelected) {
	        	   					$('#ScrapStockOutGrid').jqGrid('restoreRow',lastSelected);
	        	   					editRow(id);
	        	   					lastSelected = id;
	        	   				}
	        	   		},
						gridComplete : function() {
							
						//	var ids = $("#ScrapStockOutGrid").jqGrid('getDataIDs');
							var totalQty = $('#ScrapStockOutGrid').jqGrid('getCol', 'totalQuantity', false, 'sum');
							var balQty = $('#ScrapStockOutGrid').jqGrid('getCol', 'balanceQty', false, 'sum');
							var stockedOutQty = $('#ScrapStockOutGrid').jqGrid('getCol', 'stockedOutQty', false, 'sum');
							var totalQtyRoundUp = Math.round(parseFloat(totalQty) * 100) / 100;
							var balQtyRoundUp = Math.round(parseFloat(balQty) * 100) / 100;
							var stockedOutQtyRoundUp = Math.round(parseFloat(stockedOutQty) * 100) / 100;

							$('#ScrapStockOutGrid').jqGrid('footerData', 'set',{ID : 'Total:',totalQuantity : totalQtyRoundUp});
							$('#ScrapStockOutGrid').jqGrid('footerData', 'set',{ID : 'Total:',balanceQty : balQtyRoundUp});
							$('#ScrapStockOutGrid').jqGrid('footerData', 'set',{ID : 'Total:',stockedOutQty : stockedOutQtyRoundUp});

							var ids = $("#ScrapStockOutGrid").jqGrid('getDataIDs');
							for ( var i = 0; i < ids.length; i++) {
								var cl = ids[i];
	        					be = "<input style='height:22px; width:35px;' type='button' value='Edit' id='editRow"+cl+"' onclick=\"editRow('"+ cl + "');\" />";
	        					se = "<input style='height:22px; width: 29px;' type='button' value='Save' hidden='hidden' id='saveRow"+cl+"' onclick=\"saveRow('"+ cl + "');\" />";
	        					ce = "<input style='height:22px;width:39px;' type='button' value='Cancel' hidden='hidden' id='restoreRow"+cl+"' onclick=\"restoreRow('"+ cl + "');\" />";
	        					$("#ScrapStockOutGrid").jqGrid('setRowData', ids[i],{
	            					act : be + se + ce
	            				});
	            			}},
							beforeSelectRow : function(rowid, e) {
							var $myGrid = $(this), i = $.jgrid.getCellIndex($(
									e.target).closest('td')[0]), cm = $myGrid
									.jqGrid('getGridParam', 'colModel');
							return (cm[i].name === 'cb');
						},
						editurl : "scrapStockOut/crud"
					}).navGrid('#scrapStockOutPager', {
				view : false,
				del : false,
				edit : false,
				search : false,
				add:false
			}

			);

});


idsOfSelectedRows = [ "8", "9", "10" ];
var $ScrapStockOutGrid = $("#ScrapStockOutGrid"), idsOfSelectedRows = [],
updateIdsOfSelectedRows = function(id, isSelected) {
 	var salesOrderNo = $('#salesOrderNoSelect').val();
 	  var grid = jQuery('#ScrapStockOutGrid'); 
 	 var stockOutQuantity=grid.jqGrid ('getCell', id, 'stockOutQuantity');
 	if(salesOrderNo!="" && salesOrderNo!=null){
 		 if (isNaN(stockOutQuantity)){  
	         saveRow(id);
 		}
 		else{
 			editRow(id);
 			 saveRow(id);
 		}
		var index = $.inArray(id, idsOfSelectedRows);
		if (!isSelected && index >= 0) {
			idsOfSelectedRows.splice(index, 1); // remove id from the list
		} else if (index < 0) {
			idsOfSelectedRows.push(id);
		}
 	}else{
 		alert("Select Sales Order no for stock out process");
 		 $("#ScrapStockOutGrid").resetSelection(id);
 	}
};

updateIdsOfAllSelectedRows = function(aRowids, isSelected) {
	 var salesNo=0;
	 var salesOrderNo = $('#salesOrderNoSelect').val();
     var grid = jQuery('#ScrapStockOutGrid'); 
  	 var i, count, id;
	for (i = 0, count = aRowids.length; i < count; i++) {
		id = aRowids[i];
		 var stockOutQuantity=grid.jqGrid ('getCell', id, 'stockOutQuantity');
		if(salesOrderNo!="" && salesOrderNo!=null){
			 if (isNaN(stockOutQuantity)){  
      	         saveRow(id);
       		}
       		else{
       			editRow(id);
       			 saveRow(id);
       		}
			
		var index = $.inArray(id, idsOfSelectedRows);
			if (!isSelected && index >= 0) {
				idsOfSelectedRows.splice(index, 1); // remove id from the list
			} else if (index < 0) {
				idsOfSelectedRows.push(id);
			}
	
	}else{
		salesNo++;
	}
	}if(salesNo>0){
        alert("Select Sales Order ");
        $("#ScrapStockOutGrid").resetSelection();
  	 }
};


$("#customerSelect").chosen().change(function() {
	var customerId = $('#customerSelect').val();
	$('#salesOrderNoSelect').children().remove();
	$('#salesOrderNoSelect').val('').trigger('liszt:updated');
	$.ajax({type:'POST',
		    url: 'scrapStockOut/fetchSalesOrder',
		    dataType: "json",
		    data:{"customerId":customerId}, 
		    success: function(response) {
		    	$('#salesOrderNoSelect').empty();
				if (response.length == 0) {

					alert("There is no sales order for the selected customer");
				}

				if(response.length != 0){
					for(var i=0;i< response.length;i++){
						$('#salesOrderNoSelect').append('<option selected="selected">'+ "" + '</option>');
						$('#salesOrderNoSelect').append('<option >' + response[i]+ '</option>');
						$('#salesOrderNoSelect').trigger('liszt:updated');
					}
				}else{
					$('#salesOrderNoSelect').empty();
				}
				
		  				
     	}});

});

$("#salesOrderNoSelect").chosen().change(function() {
   	var salesOrderNo = $('#salesOrderNoSelect').val();
	$.ajax({type:'POST',
		url: 'pendingSoItemReport/getSalesOrderDetails',
 		data:{"salesOrder":salesOrderNo},
 		success: function(response) {
 			if(response[0]!=null && response.length>0){
 			var res =response[0];
				document.getElementById('customerSelect').value = res ;
	 			$('#customerSelect').trigger('liszt:updated');	
           // $('#partySelect option:selected').text()=response[1];
 			}
 		}
    });  


	   jQuery("#ScrapStockOutGrid").setGridParam({datatype:'json'}); 
	   jQuery("#ScrapStockOutGrid").setGridParam({ url: 'scrapStockOut/records'});
	   jQuery("#ScrapStockOutGrid").setGridParam({postData: {salesOrderNo:salesOrderNo}}); 
	   jQuery("#ScrapStockOutGrid").trigger('reloadGrid');

});




$('#clearSearchBox').click(function() {
        document.getElementById('customerSelect').value = "";
	    $('#customerSelect').trigger('liszt:updated');
	    document.getElementById('salesOrderNoSelect').value = "";
	    $('#salesOrderNoSelect').trigger('liszt:updated');
	    $('#salesOrderNoSelect').children().remove();
		$('#salesOrderNoSelect').val('').trigger('liszt:updated');
		$.ajax({type:'POST',
		    url: 'scrapStockOut/fetchAllSalesOrder',
		    dataType: "json",
		    success: function(response) {
		 		if(response.length != 0){
					for(var i=0;i< response.length;i++){
						$('#salesOrderNoSelect').append('<option selected="selected">'+ "" + '</option>');
						$('#salesOrderNoSelect').append('<option >' + response[i]+ '</option>');
						$('#salesOrderNoSelect').trigger('liszt:updated');
					}
				}else{
					$('#salesOrderNoSelect').empty();
				}
				
		  				
     	}});
		
	   jQuery("#ScrapStockOutGrid").setGridParam({datatype:'json'}); 
	   jQuery("#ScrapStockOutGrid").setGridParam({ url: 'scrapStockOut/records'});
	   jQuery("#ScrapStockOutGrid").setGridParam({postData: {salesOrderNo:""}}); 
	   jQuery("#ScrapStockOutGrid").trigger('reloadGrid');

});


function editRow(id) {
	 	restoreRow(lastSelected);
		lastSelected = id;
		$('#ScrapStockOutGrid').jqGrid('editRow',id, 
		{
			"keys" :true, 
			"oneditfunc" : hideActButtons,
			aftersavefunc : function(savedId, response) {
				showActButtons(savedId);
			},
			afterrestorefunc : showActButtons
		});
	}



function saveRow(id) {
 if(woQtyValid==true){
 	 $('#ScrapStockOutGrid').saveRow(id,
		{	aftersavefunc : function(id, response) {showActButtons(id);}
		});
	// jQuery("#SOforWOGrid").trigger('reloadGrid'); 
	}

}

	function restoreRow(id) {
		$('#ScrapStockOutGrid').jqGrid('restoreRow',id,
		{
			afterrestorefunc : showActButtons
		});
	}

    /*
     * Hides the Edit and Del Row Buttons on jqGrid
     * and activates the Save and restore(cancel) button
     * 
     */
    function hideActButtons(id){
    	$('#editRow' + id).hide();
    	$('#saveRow' + id).show();
    	$('#restoreRow' + id).show();
    }

    /*
     * Shows the Edit and Del Row Buttons on jqGrid
     * and hides the Save and restore(cancel) button
     * 
     */
    function showActButtons(id) {
    	$('#editRow' + id).show();
    	$('#saveRow' + id).hide();
    	$('#restoreRow' + id).hide();
    	lastSelected = null;
    }

    
    
    function scrapStockOut() {
    	 var salesOrderNo = $('#salesOrderNoSelect').val();
    	 var challanDate=document.getElementById('deliveryDate').value;
    	 if(salesOrderNo!="" && salesOrderNo!=null && idsOfSelectedRows.length>0 && challanDate!=null && challanDate!=""){
   		if (confirm("Do you want to confirm the stock Out of selected scrap items")) {
    			$.ajax({
    				type : 'POST',
    				url : 'scrapStockOut/stockOut',
    				data: {'idsOfSelectedRows': idsOfSelectedRows,"salesOrderNo":salesOrderNo,"challanDate":challanDate},
 				   success: function(response) {
 				   alert("Delivery Challan "+response +" is created");
					  jQuery("#ScrapStockOutGrid").setGridParam({datatype:'json'}); 
					   jQuery("#ScrapStockOutGrid").setGridParam({ url: 'scrapStockOut/records'});
					   jQuery("#ScrapStockOutGrid").trigger('reloadGrid');
 					document.getElementById('salesOrderNoSelect').value ="";
 					$('#salesOrderSelect').trigger('liszt:updated');
 				    $('#salesOrderNoSelect').children().remove();
 					$('#salesOrderNoSelect').val('').trigger('liszt:updated');
 				    document.getElementById('customerSelect').value ="";
 					$('#customerSelect').trigger('liszt:updated');
 					idsOfSelectedRows=[];

                 }});
    		}
    	}else if(salesOrderNo=="" || salesOrderNo==null){
        	alert("Select sales Order");
        }
    	else if(idsOfSelectedRows.length==0){
    		alert("Select scrap items for stock out");
    	}
    	else if(challanDate==null || challanDate==""){
			alert("Select Challan Date");
       }
    }
    

