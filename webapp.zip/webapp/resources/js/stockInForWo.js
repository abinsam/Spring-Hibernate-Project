$("#loading").dialog({
    hide: 'slide',
    show: 'slide',
    autoOpen: false
});



$(function() {
	$("#datepicker").datepicker({
		dateFormat : "dd-mm-yy"
	});
	$("#orderIdSelect").chosen({
		no_results_text : "No results matched"
	});
	$("#customerSelect").chosen({
		no_results_text : "No results matched"
	});

});

function stockInFn() {
	var validateSaveStocIn = false;
	validateSaveStocIn = saveStockInValidation();
	if (validateSaveStocIn == true) {
		$.ajax({
			type : 'POST',
			url : 'stockin/saveStock',

			data : '&ItemCode=' + $("#itemCode").val() + '&SalesOrderId='
					+ $("#salesOrderId").val() + '&WorkOrderNo='
					+ $("#workOrderNo").val() + '&BundleId='
					+ $("#bundleId").val() + '&CustomerName='
					+ $("#customerName").val() + '&ItemDesc='
					+ $("#itemDesc").val() + '&Quantity=' + $("#qty").val()
					+ '&Weight=' + $("#weight").val(),
			beforeSend: function(){
				           $("#loading").dialog('open').html("<p>Processing Request...</p>");
				        },
					   
			success : function(response) {
				if (response[0] == "created") {
					alert("Stock IN Items Updated ");
					document.getElementById('bundleId').value = response[1];
				} 
				else if(response[0] == "exist")
					alert("Stock IN Items already added in Stores ");
				else
					alert("Stock IN Items already Updated");
				document.getElementById('bundleId').value = response[1];
				jQuery("#stockInGrid").setGridParam({
					datatype : 'json'
				});
				jQuery("#stockInGrid").setGridParam({
					url : 'stockin/records'
				});
				jQuery("#stockInGrid").trigger('reloadGrid');
			},
			 complete: function() {
	        	 $("#loading").dialog('close');
	        }
		});

	}
}
function saveStockInValidation() {
	var patroon = /^[0-9]\d*$/;
	var wtPattern = /^[+]?([0-9]+(?:[\.][0-9]*)?|\.[0-9]+)$/;

	if ($("#itemCode").val() == "" || $("#itemCode").val() == null) {
		alert("Enter Item Code");
		return false;
	} else if ($("#salesOrderId").val() == ""
			|| $("#salesOrderId").val() == null) {
		alert("Enter Sales order");
		return false;
	} else if ($("#workOrderNo").val() == "" || $("#workOrderNo").val() == null) {
		alert("Enter Work Order No");
		return false;
	} else if ($("#bundleId").val() == "" || $("#bundleId").val() == null) {
		alert("Enter Bundle Id");
		return false;
	} else if ($("#qty").val() == "" || $("#qty").val() == null) {
		alert("Enter Qunatity");
		return false;
	} else if ($("#weight").val() == "" || $("#weight").val() == null) {
		alert("Enter Weight");
		return false;
	} else if (!wtPattern.test($("#weight").val())) {
		alert("Enter valid Weight");
		document.getElementById('weight').value = "";
		return false;

	} else if (!(parseFloat($("#weight").val()) > 0)) {
		alert("Enter valid Weight");
		document.getElementById('weight').value = "";
		return false;
	} else if (!patroon.test($("#qty").val())) {
		alert("Enter valid Qunatity");
		document.getElementById('qty').value = "";
		return false;
	}
		else if (!patroon.test($("#bundleId").val())) {
			alert("Enter valid Bundle Id");
			document.getElementById('bundleId').value = "";
			return false;
		}
	else if (!(parseInt($("#qty").val()) > 0)) {
		alert("Enter valid Quantity");
		document.getElementById('qty').value = "";
		return false;
	} else {
		return true;
	}
}

function closeFn() {
	window.close();
}

$(function() {

	$("#stockInGrid")
			.jqGrid(
					{
						url : 'stockin/records',
						datatype : 'json',
						mtype : 'POST',
						multiselect : true,
						colNames : [ 'Stock In Id', 'Sales Order No', 'Party',
								'Work Order No', 'Item Id', 'Item Code',
								'Item Description', 'Bundle Id', 'Stock Qty',
								'Units', 'Weight(kg)', 'Actions' ],
						colModel : [ {
							name : 'stockInId',
							index : 'stockInId',
							width : 5,
							viewable : false,
							hidden : true
						}, {
							name : 'orderId',
							index : 'orderId',
							width : 70
						}, {
							name : 'customerName',
							index : 'customerName',
							width : 90
						}, {
							name : 'workOrderNo',
							index : 'workOrderNo',
							width : 70
						}, {
							name : 'itemId',
							index : 'itemId',
							width : 5,
							hidden : true
						}, {
							name : 'itemCode',
							index : 'itemCode',
							width : 120
						}, {
							name : 'itemDescription',
							index : 'itemDescription',
							width : 200
						}, {
							name : 'bundleId',
							index : 'bundleId',
							width : 40
						}, {
							name : 'stockQty',
							index : 'stockQty',
							width : 50
						}, {
							name : 'units',
							index : 'units',
							width : 40
						}, {
							name : 'weight',
							index : 'weight',
							width : 50
						},

						{
							name : 'act',
							index : 'act',
							width : 30,sortable : false,editable : false
						}

						],
						postData : {},
						autowidth : true,
						rowNum : 100,
						rowList : [ 5, 10, 20, 30, 40, 100 ],
						height : 300,
						rownumbers : false,
						pager : '#stockInPager',
						sortname : 'stockInId',
						viewrecords : true,
						footerrow : true,
						sortorder : "desc",
						caption : "Item List For Confirming Stock In",
						emptyrecords : "Empty records",
						loadonce : false,
						loadComplete : function() {
						},
						jsonReader : {
							root : "rows",
							page : "page",
							total : "total",
							records : "records",
							repeatitems : false,
							cell : "cell",
							id : "stockInId"
						},
						onSelectRow : updateIdsOfSelectedRows,
						onSelectAll : function(aRowids, status) {
							updateIdsOfAllSelectedRows(aRowids, status);
						},
						loadComplete : function() {
							var $this = $(this), i, count;
							for (i = 0, count = idsOfSelectedRows.length; i < count; i++) {
								$this.jqGrid('setSelection',
										idsOfSelectedRows[i], false);
							}
						},
						gridComplete : function() {
							
							var stockQty = $('#stockInGrid').jqGrid('getCol', 'stockQty', false, 'sum');
							var totalStockQty = Math.round(parseFloat(stockQty) * 100) / 100;
							$('#stockInGrid').jqGrid('footerData', 'set',	{ID : 'Total:',	stockQty : totalStockQty});
							
							var weight = $('#stockInGrid').jqGrid('getCol', 'weight', false, 'sum');
							var totalWeight = Math.round(parseFloat(weight) * 100) / 100;
							$('#stockInGrid').jqGrid('footerData', 'set',	{ID : 'Total:',	weight : totalWeight});
							
							$('#stockInGrid').jqGrid('footerData','set', {ID: 'Total:', units: "mts"});
							
							var ids = $("#stockInGrid").jqGrid('getDataIDs');
							for ( var i = 0; i < ids.length; i++) {
								var cl = ids[i];
								de = "<input style='height:22px; width:30px;' type='button' value='Del' id='delRow"
										+ cl
										+ "' onclick=\"delRow('"
										+ cl
										+ "');\" />";
								$("#stockInGrid").jqGrid('setRowData', ids[i],
										{
											act : de
										});
							}
						},
						beforeSelectRow : function(rowid, e) {
							var $myGrid = $(this), i = $.jgrid.getCellIndex($(
									e.target).closest('td')[0]), cm = $myGrid
									.jqGrid('getGridParam', 'colModel');
							return (cm[i].name === 'cb');
						}
					//editurl : "stockin/crud",
					});
	jQuery("#stockInGrid").jqGrid('navGrid', '#stockInPager', {
		view : false,
		del : false,
		add : false,
		edit : false,
		search : false
	});
});

idsOfSelectedRows = [ "8", "9", "10" ];
var $StockInGrid = $("#stockInGrid"), idsOfSelectedRows = [], updateIdsOfSelectedRows = function(
		id, isSelected) {
	var index = $.inArray(id, idsOfSelectedRows);
	if (!isSelected && index >= 0) {
		idsOfSelectedRows.splice(index, 1); // remove id from the list
	} else if (index < 0) {
		idsOfSelectedRows.push(id);
	}
};
updateIdsOfAllSelectedRows = function(aRowids, isSelected) {
	for (i = 0, count = aRowids.length; i < count; i++) {
		id = aRowids[i];
		var index = $.inArray(id, idsOfSelectedRows);
		if (!isSelected && index >= 0) {
			idsOfSelectedRows.splice(index, 1); // remove id from the list
		} else if (index < 0) {
			idsOfSelectedRows.push(id);
		}
	}
};

function confirmStockFn() {
	if (idsOfSelectedRows.length > 0) {
		if (confirm("Do you want to confirm the stock in of selected items")) {
			$.ajax({
				type : 'POST',
				url : 'stockin/crud',
				data : {
					'idsOfSelectedRows' : idsOfSelectedRows
				},
				success : function(response) {
					alert("Selected Items are stocked in");
					jQuery("#stockInGrid").setGridParam({
						datatype : 'json'
					});
					jQuery("#stockInGrid").setGridParam({
						url : 'stockin/records'
					});
					jQuery("#stockInGrid").trigger('reloadGrid');
					idsOfSelectedRows = [];

				}
			});
		}

	}
}
$('#changeLabelBtn')
.click(function(){
	
	if ($("#itemCode").val() != "") {
		$("#dialog-modal").dialog({
			width : 450,
			height : 250,
		});

		$("#customerSelect").chosen().change(
				function() {
					
					$('#orderIdSelect').children().remove();
					$('#orderIdSelect').val('').trigger('liszt:updated');
					$.ajax({
						type : 'POST',
						url : 'stockIn/fetchSalesOrder',
						data : {
							"itemCode" : $("#itemCode").val(),
							"customerId" : $("#customerSelect").val()
						},
						success : function(response) {
							
							$('#orderIdSelect').empty();
							if (response.length != 0) {
								for ( var i = 0; i < response.length; i++) {
									$('#orderIdSelect').append(
											'<option selected="selected">' + ""
													+ '</option>');
									$('#orderIdSelect').append(
											'<option >' + response[i]
													+ '</option>');
									$('#orderIdSelect')
											.trigger('liszt:updated');
								}
							} else {
								$('#orderIdSelect').empty();
							}
						}
					});
				});

	}// end of if loop
	else {
		alert("Enter Item Code for Stock In");
	}
});
$('#changeBtn')
		.click(
				function() {
					var oldSoNo = $("#salesOrderId").val();
					var newSoNo = $("#orderIdSelect").val();
					var oldWoNo = $("#workOrderNo").val();
					if (newSoNo != null && newSoNo != "" && oldSoNo != null
							&& oldSoNo != "") {
						if (oldSoNo == newSoNo) {
							alert("No Label Change");
						} else {
							if (confirm("Do you want to change the labels?")) {
								$
										.ajax({
											type : 'POST',
											url : 'stockIn/changeLabel',
											data : {
												"itemCode" : $("#itemCode")
														.val(),
												"oldSoNo" : oldSoNo,
												"newSoNo" : newSoNo,
												"oldWoNo" : oldWoNo
											},
											success : function(response) {
												alert("Label has been changed for the item to be stocked in");
												if (response.length > 0) {
													document
															.getElementById('customerName').value = response[1];
													document
															.getElementById('salesOrderId').value = response[0];
													$('#dialog-modal').dialog(
															'close');
												}
											}
										});
							}
						}
						$('#dialog-modal').dialog('close');
					}
				});

$('#cancelBtn').click(function() {
	$('#dialog-modal').dialog('close');
});

function delRow(id) {
	$("#stockInGrid").resetSelection(id);
	if (confirm("Do you want to delete this items")) {
		$.ajax({
			type : 'POST',
			url : 'stockin/delete',
			data : {
				'id' : id
			},
			success : function(response) {
				jQuery("#stockInGrid").setGridParam({
					datatype : 'json'
				});
				jQuery("#stockInGrid").setGridParam({
					url : 'stockin/records'
				});
				jQuery("#stockInGrid").trigger('reloadGrid');

				alert("Selected Item deleted from stock in list");

			}
		});

	}
}
