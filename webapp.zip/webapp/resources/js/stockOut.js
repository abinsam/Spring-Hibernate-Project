$("#loading").dialog({
    hide: 'slide',
    show: 'slide',
    autoOpen: false
});
var lastSelected;
var newDcNo;
var gridBagNoValid=true;
var gridBagWeightValid=true;

$("#barCodeInput").keydown (function () {
	  window.setTimeout(function () {
    	  var barCode=$("#barCodeInput").val();
		  var itemCode=barCode.substring(0,23).toUpperCase();
		  var soNo=barCode.substring(23,31).toUpperCase();
		  var woNo=barCode.substring(31,39).toUpperCase();
		  var bundleId=barCode.substring(39,42);
		    document.getElementById('itemCode').value =itemCode;
			document.getElementById('salesOrderId').value =soNo;
			document.getElementById('workOrderNo').value =woNo;
			document.getElementById('bundleId').value =bundleId;
		if( $("#barCodeInput").val().length==42){
    	$.ajax({type : 'POST',
	    	url : 'stockout/barCode',
            data : {"itemCode":itemCode,"soNo":soNo,"woNo":woNo,"bundleId":bundleId},
        	success : function(response) {
        	document.getElementById('itemDesc').value = response[0];
			document.getElementById('customerName').value = response[1];
			document.getElementById('qty').value = response[2];
			document.getElementById('units').value = response[3];
			document.getElementById('weight').value = response[4];
			// $("#bagNo").focus();
		   },
            complete: function() {
   	    	 if( $("#barCodeInput").val().length==42){
   	    		 $("#bagNo").focus();
   	    		}
   	       }
	});
		} else{
			   document.getElementById('itemCode').value ="";
				document.getElementById('salesOrderId').value ="";
				document.getElementById('workOrderNo').value ="";
				document.getElementById('bundleId').value ="";
				document.getElementById('itemDesc').value ="";
				document.getElementById('customerName').value="";
				document.getElementById('qty').value ="";
				document.getElementById('units').value ="";
				document.getElementById('weight').value ="";
				document.getElementById('bagNo').value ="";
				document.getElementById('bagWeight').value ="";
		} }, 0);
	  
});

//Abin dated@June 1,2013
/*$('input[name=salesOrderId]').change(function(){
		  populateItemDetails(); }); 
	$('input[name=itemCode]').change(function(){ 
		  populateItemDetails();  });
	$('input[name=workOrderNo]').change(function(){ 
		  populateItemDetails();  });
	$('input[name=bundleId]').change(function(){ 
		  populateItemDetails();  });
          $.ajax({type:'GET', url: 'stockin/changeCust', 
                 
                 data: '&SalesOrderId=' + $("#salesOrderId").val() 
         });  
  
   function  populateItemDetails(){
	     if(!(document.getElementById('salesOrderId').value=="") && document.getElementById('salesOrderId').value!=null &&
       		!(document.getElementById('itemCode').value=="") && document.getElementById('itemCode').value!=null &&
        	!(document.getElementById('workOrderNo').value=="") && document.getElementById('workOrderNo').value!=null &&
        	!(document.getElementById('bundleId').value=="") && document.getElementById('bundleId').value!=null){
        	   $.ajax({type:'POST', url: 'stockout/populateStockOutDetails', 
                       data: {"salesOrderId":document.getElementById('salesOrderId').value,
                    	       "itemCode":document.getElementById('itemCode').value,
                    	        "workOrderNo":document.getElementById('workOrderNo').value,
                    	        "bundleId":document.getElementById('bundleId').value},
                    	        success: function(response) {
                    	        	document.getElementById('itemDesc').value=response[0];
                    	        	document.getElementById('customerName').value=response[1];
                    	        	document.getElementById('qty').value=response[2];
                    	        	document.getElementById('weight').value=response[3];

                    	     }
           });}	 
    
   }*/

$(function(){ 
	 $("#barCodeInput").focus();
	//$("#partySelect").chosen({no_results_text: "No results matched"});
	//$("#salesOrderSelect").chosen({no_results_text: "No results matched"});
	/*$( "#deliveryDate" ).datepicker({dateFormat : "dd-mm-yy"});
	$("#deliveryDate").datepicker('setDate', 'today');*/
	

	
   $("#stockOutGrid").jqGrid({
		url: 'stockout/records',
		datatype: 'json',
	    mtype: 'POST',
	    multiselect:true,
	   	colNames:['Stock In Id','Sales Order No','SO Status','Customer','Party','Work Order No',
	   	             'Item Id','Item Code','Item Description','Bundle Id','StockOut Qty',
	   	             'Units','Weight(Kg)','Packing No','Bag Weight','QC Status','Actions'],
    	colModel:[
	   	    
    	          {name:'stockOutId', index:'stockOutId', width:5, viewable:false,hidden:true}, 
	   	          {name:'orderId',index:'orderId', width:70},
	   	          {name:'status',index:'status', width:70},
	   	          {name:'customerName',index:'customerName', width:10,hidden:true},
	   	          {name:'customerCode',index:'customerCode', width:90},
	   	          {name:'workOrderNo',index:'workOrderNo', width:70},
     	          {name:'itemId',index:'itemId', width:5,hidden:true},
	   	          {name:'itemCode',index:'itemCode', width:120},
	   	          {name:'itemDescription',index:'itemDescription', width:200},
	   	          {name:'bundleId',index:'bundleId', width:40}, 
	   	          {name:'stockOutQty',index:'stockOutQty', width:50},
	   	          {name:'units',index:'units', width:40},
	   	          {name:'weight',index:'weight', width:50},
		          {name:'packingSlipNo',index:'packingSlipNo', width:40,editable:true,editoptions:{
                      dataInit: function(element) {
                      	var patMatch = /^[1-9]\d*$/;
                            $(element).keyup(function(){
                          	  var val1 = element.value;
                          	 if(!patMatch.test(val1)) {
                          		 alert("Please enter a valid quantity");
                              	  gridBagNoValid=false;  
                          	  }
                          	  else   gridBagNoValid=true;
                          	  
                             });
                        }
                    }},
		          {name:'bagWeight',index:'bagWeight', width:40,editable:true,editoptions:{
                      dataInit: function(element) {
                      	var patMatch = /^(\.\d{1,2}|\d{1,4}\.?\d{0,2}|\d{5}\.?\d?|\d{6}\.?\d?|\d{7}\.?\d?)$/;
                            $(element).keyup(function(){
                          	  var val1 = element.value;
                          	 if(!patMatch.test(val1)) {
                          		 alert("Please enter  valid bag weight");
                              	  gridBagWeightValid=false;  
                          	  }
                          	  else   gridBagWeightValid=true;
                          	  
                             });
                        }
                    }},
		          {name:'qcStatus',index:'qcStatus', width:70},
		          {name :'act',index : 'act',width :60,sortable:false}
	   	  	          
	 	          
   	          
	   	],
	   	postData: {},
	    autowidth:true,	
	    height:350,	
		rowNum:1000,
	   	rowList:[5,10,20,30,40,100,200,500,1000,10000],
	   	rownumbers: false,
	   	pager: '#stockOutPager',
	   	sortname: 'stockOutId',
	    viewrecords: true,
	    sortorder: "desc",
	    caption:"Item List For Confirming Stock Out",
	    emptyrecords: "Empty records",
	    loadonce: false,
	    footerrow : true,
	    loadComplete: function() {},
	    jsonReader : {
	        root: "rows",
	        page: "page",
	        total: "total",
	        records: "records",
	        repeatitems: false,
	        cell: "cell",
	        id: "stockOutId"
	    },
	    ondblClickRow : function(id) {
			if (id && id !== lastSelected) {
				$('#stockOutGrid').jqGrid('restoreRow',lastSelected);
				editRow(id);
				lastSelected = id;
			}
		},
	    onSelectRow: updateIdsOfSelectedRows,   
  		 onSelectAll:function (aRowids, status) {
  			updateIdsOfAllSelectedRows(aRowids,status);
        },
        loadComplete: function () {
	   	        var $this = $(this), i, count;
	   	        for (i = 0, count = idsOfSelectedRows.length; i < count; i++) {
	   	            $this.jqGrid('setSelection', idsOfSelectedRows[i], false);
	   	        }
	   	      },
			gridComplete : function() {
					var stockQty = $('#stockOutGrid').jqGrid('getCol','stockOutQty', false, 'sum');
					var totalStockQty = Math.round(parseFloat(stockQty) * 100) / 100;
					$('#stockOutGrid').jqGrid('footerData', 'set', {ID : 'Total:',stockOutQty : totalStockQty});

					var weight = $('#stockOutGrid').jqGrid('getCol','weight', false, 'sum');
					var totalWeight = Math.round(parseFloat(weight) * 100) / 100;
					$('#stockOutGrid').jqGrid('footerData', 'set', {ID : 'Total:',weight : totalWeight});
			
			var ids = $("#stockOutGrid").jqGrid('getDataIDs');
			for ( var i = 0; i < ids.length; i++) {
				var cl = ids[i];
				de = "<input style='height:22px; width:30px;' type='button' value='Del' id='delRow"+cl+"' onclick=\"delRow('"+ cl + "');\" />";
			
				be = "<input style='height:22px; width:35px;' type='button' value='Edit' id='editRow"+cl+"' onclick=\"editRow('"+ cl + "');\" />";
				se = "<input style='height:22px; width: 29px;' type='button' value='Save' hidden='hidden' id='saveRow"+cl+"' onclick=\"saveRow('"+ cl + "');\" />";
				ce = "<input style='height:22px;width:39px;' type='button' value='Cancel' hidden='hidden'  id='restoreRow"+cl+"' onclick=\"restoreRow('"+ cl + "');\" />";
		
				
				
				$("#stockOutGrid").jqGrid('setRowData', ids[i],{
					act : be + de + se + ce
				});
			}
			if(ids.length>0){
     			document.getElementById('salesOrderSelected').value=$('#stockOutGrid').jqGrid ('getCell', ids[0], 'orderId');
		      	document.getElementById('partySelected').value=$('#stockOutGrid').jqGrid ('getCell', ids[0], 'customerName');
		     }
		 },
		beforeSelectRow: function (rowid, e) {
		    var $myGrid = $(this),
	        i = $.jgrid.getCellIndex($(e.target).closest('td')[0]),
	        cm = $myGrid.jqGrid('getGridParam', 'colModel');
	    return (cm[i].name === 'cb');
	},
	editurl : "stockout/modify",
	});
	 jQuery("#stockOutGrid").jqGrid('navGrid','#stockOutPager',{view:false, del:false,add:false, edit:false, search:false});

});





function stockOutFn(){
	var gridFlag=false;
	 var data = jQuery("#stockOutGrid").getRowData(); 
	 var orderId;
	 if(data.length>0)
		 orderId = data[0].orderId;
	else
	    orderId=$("#salesOrderId").val(); 

	//for (var i = 0; i < data.length; i++) {
	    if($("#salesOrderId").val()!=orderId){
	    	gridFlag=true;
	    	//alert("Items cannot be stocked out for SalesOrderID:"+$("#salesOrderId").val());
	    	alert("Stock out Items of SalesOrderID:"+orderId);
	    } 	   
	//}
	if(gridFlag==false){
	var validateSaveStocOut=false;
	validateSaveStocOut=saveStockOutValidation();
	if(validateSaveStocOut==true){
	$.ajax({type:'POST', url: 'stockout/saveStockOut', 
			 data:'&ItemCode=' + $("#itemCode").val()+
			 '&SalesOrderId=' + $("#salesOrderId").val()+
			 '&WorkOrderNo=' + $("#workOrderNo").val()+
			 '&BundleId=' + $("#bundleId").val()+
			'&CustomerName=' + $("#customerName").val()+
			'&ItemDesc=' + $("#itemDesc").val()+
			'&Quantity=' + $("#qty").val()+
			'&Weight=' + $("#weight").val()+
			'&bagNo=' + $("#bagNo").val()+
			'&bagWeight=' + $("#bagWeight").val(),
			
			 
			 success: function(response){
				 if(response[0]=="created")
				    alert("Stock Items Added "); 
				 else if(response[0]=="SO Status Not Approved")
					 alert("Stock out items of Approved Sales Order");
				 else if(response[0]=="QC Status Not Approved")
					 alert("Stock out QC Approved Items");
				 else if(response[0]=="added")
				  alert("Stock  Items already Updated ");
				 else if(response[0]=="Dont exist")
					  alert("Stock Out Items prsent in stores ");
				 
			 jQuery("#stockOutGrid").setGridParam({datatype:'json'}); 
			 jQuery("#stockOutGrid").setGridParam({ url: 'stockout/records'});
			 jQuery("#stockOutGrid").trigger('reloadGrid');
			 $("#barCodeInput").focus();
			 clearFn();
/*	        	document.getElementById('itemDesc').value="";
	        	document.getElementById('customerName').value="";
	        	document.getElementById('qty').value="";
	        	document.getElementById('weight').value="";
	   	        document.getElementById('salesOrderId').value="";
	   	        document.getElementById('itemCode').value="";
	   	        document.getElementById('itemCode').value="";
	   	        document.getElementById('workOrderNo').value="";
	   	        document.getElementById('bundleId').value="";	*/			 
				}});}

}
}

function saveStockOutValidation(){
	
	var  patroon = /^[1-9]\d*$/;

	 var  wtPattern = /^[+]?([0-9]+(?:[\.][0-9]*)?|\.[0-9]+)$/;
	if($("#itemCode").val()=="" || $("#itemCode").val()==null){
		alert("Enter Item Code");
		return false;
	}
	else  if($("#salesOrderId").val()=="" || $("#salesOrderId").val()==null){
     	alert("Enter Sales order");
		return false;
	}
	else  if($("#workOrderNo").val()=="" || $("#workOrderNo").val()==null){
		alert("Enter Work Order No");
		return false;
	}
	else  if($("#bundleId").val()=="" || $("#bundleId").val()==null){
		alert("Enter Bundle Id");
		return false;
	}
	else  if($("#qty").val()=="" || $("#qty").val()==null){
		alert("Enter Qunatity");
		return false;
	}
	else  if($("#bagNo").val()=="" || $("#bagNo").val()==null){
		alert("Enter Bag No");
		return false;
	}
	else if(!patroon.test($("#bagNo").val())){
	alert("Enter valid bag No");
	document.getElementById('bagNo').value="";
	return false;
		
	}
	else  if($("#bagWeight").val()!="" &&  $("#bagWeight").val()!=null){
		if(!wtPattern.test($("#bagWeight").val())){
			alert("Enter valid bag Weight");
			document.getElementById('bagWeight').value="";
			return false;
			}
		else return true;
	}
	
	else{
		return true;
	}
}





function changeLabelFn()
{
	
	   $( "#dialog-modal" ).dialog({ 
	   width: 450,
       height: 275
	   });
	  	   

	   $('#changeBtn').click(function() {
		   
		  /*  alert("customer selected is====" +document.getElementById('customerSelect').value);
		   alert("Sales Order selected is====" +document.getElementById('orderIdSelect').value); */
		   $('#dialog-modal').dialog('close');
		   document.getElementById('customerName').value=document.getElementById('customerSelect').value;
		   document.getElementById('salesOrderId').value=document.getElementById('orderIdSelect').value;
		   document.getElementById('qty').value=document.getElementById('quantity').value;
		   });
	   
	   $('#cancelBtn').click(function() {
		   $('#dialog-modal').dialog('close');
		   });
}

   
idsOfSelectedRows = ["8", "9", "10"];
var $StockOutGrid = $("#stockOutGrid"), idsOfSelectedRows = [],
updateIdsOfSelectedRows = function (id, isSelected) {
	  // var soNo=document.getElementById('salesOrderSelect').value;	
	   var grid = jQuery('#stockOutGrid'); 
      var status=grid.jqGrid ('getCell', id, 'status');
      var bagWeight=grid.jqGrid ('getCell', id, 'bagWeight');
   	  var qcStatus=grid.jqGrid ('getCell', id, 'qcStatus');
	//   alert(soNo);
	if(bagWeight!=null && bagWeight!="" && status=="Approved" && qcStatus=="Approved" ){
	var index = $.inArray(id, idsOfSelectedRows);
       if (!isSelected && index >= 0) {
    	  idsOfSelectedRows.splice(index, 1); // remove id from the list
        } else if (index < 0) {
          idsOfSelectedRows.push(id);
        }  
  }
	else if (status!="Approved") {
	  alert(" Sales Order should be Approved");
  	  $("#stockOutGrid").resetSelection(id);
	}
	else if(bagWeight==null || bagWeight==""){
		  alert("Selected Items should have Bag weight");
    	  $("#stockOutGrid").resetSelection(id);
	}
	else if (qcStatus!="Approved") {
		  alert("Select Qc approved Items");
	  	  $("#stockOutGrid").resetSelection(id);
		}
	/*else if(soNo==null || soNo==""){
		  alert("Select Sales Order");
  	  $("#stockOutGrid").resetSelection(id);
	}
*/
	
};
  updateIdsOfAllSelectedRows = function (aRowids, isSelected) {
	 // var salesNo=0;
	  var salesStatus=0;
	  var qcStatusCount=0;
	  var bagWeightStatus=0;
   	 for (i = 0, count = aRowids.length; i < count; i++) {
   		 id = aRowids[i];
   	 // var so=document.getElementById('salesOrderSelect').value;
   	 var grid = jQuery('#stockOutGrid'); 
     var status=grid.jqGrid ('getCell', id, 'status');
     var bagWeight=grid.jqGrid ('getCell', id, 'bagWeight');
     var qcStatus=grid.jqGrid ('getCell', id, 'qcStatus');
     
   	//  if( bagWeight!=null && bagWeight!="" && so!=null && so!="" && status=="Approved"){
   		  if( bagWeight!=null && bagWeight!=""  && status=="Approved"  && qcStatus=="Approved" ){
      	     var index = $.inArray(id, idsOfSelectedRows);
              if (!isSelected && index >= 0) {
      	          idsOfSelectedRows.splice(index, 1); // remove id from the list
               } else if (index < 0) {
                 idsOfSelectedRows.push(id);
            }
   	  }
   	  if(bagWeight==null || bagWeight==""){
   		bagWeightStatus++;
   	  }
   	 if(status!="Approved"){
   		salesStatus++;
   	  }
  	 if(qcStatus!="Approved"){
  		qcStatusCount++;
     }
/*   	 if (so==null || so==""){
   		salesNo++;
   	  }*/
     	 }
/*   	 if(salesNo>0){
         alert("Select Sales Order ");
         $("#stockOutGrid").resetSelection();
   	 }
 	 else{*/
 	  	 if(salesStatus>0){
 	   	     alert("Selected Sales Orders should be Approved ");
 	         $("#stockOutGrid").resetSelection(); 
 	   	 }
 	  	 else if(qcStatusCount>0){
 	   	     alert("Selected Sales Orders Items should be QC Approved ");
 	         $("#stockOutGrid").resetSelection(); 
 	   	 }
 	  	 else if(bagWeightStatus>0){
 	   	     alert("Selected Items should have Bag weight ");
 	         $("#stockOutGrid").resetSelection(); 
 	   	 }
 	//}
};







function confirmStockOutFn() {
}	


function delRow(id){
	  $("#stockOutGrid").resetSelection(id);
if (confirm("Do you want to delete this items")){
	   $.ajax(
			   {
				   type:'POST',
				   url: 'stockout/delete',
				   data: {'id': id},
				   success: function(response) {
  		            jQuery("#stockOutGrid").setGridParam({datatype:'json'}); 
  					jQuery("#stockOutGrid").setGridParam({ url : 'stockout/records'});
  					jQuery("#stockOutGrid").trigger('reloadGrid');

				   alert("Selected Item deleted from stock out list");
				   $("#barCodeInput").focus();
				   
			  }
			   }
			   );
	 
}}




$(function(){ 
	$("#orderIdSelect").chosen({no_results_text: "No results matched"});
 $("#customerSelect").chosen({no_results_text: "No results matched"});
	 
});


function performSearch(searchOptions,gridId){
    $(gridId).setGridParam({postData: {searchObject: JSON.stringify(searchOptions)}});
   $(gridId).trigger("reloadGrid");

}
function clearFunction(){ 
	  for(var k=0;k<idsOfSelectedRows.length;k++){
		  jQuery("#stockOutGrid").resetSelection(idsOfSelectedRows[k]);
	  }
	 idsOfSelectedRows = [];
	 document.getElementById('deliveryDate').value="";
    // jQuery("#stockOutGrid").setGridParam({datatype:'json'}); 
    // jQuery("#stockOutGrid").setGridParam({postData: {searchObject:"allSearch"}});
   //  jQuery("#stockOutGrid").trigger('reloadGrid');
   //  });
	}
function stockOutChallanFn(){
 var challanDate=document.getElementById('deliveryDate').value;
 //var salesOrderNo=$('#salesOrderSelect').val();
    var grid = jQuery('#stockOutGrid'); 
    var salesOrderNo=grid.jqGrid ('getCell', idsOfSelectedRows[0], 'orderId');
 var validateStockOut=false;
 validateStockOut=stockOutChallanValidation();
 if(validateStockOut==true){
	  if (confirm("Do you want to confirm the stock Out of selected items")){
   	   $.ajax(
			   {
				   
						   
				   type:'POST',
				   url: 'stockout/crud',
				   data: {'idsOfSelectedRows': idsOfSelectedRows,"challanDate":challanDate,"salesOrderNo":salesOrderNo},
			
				   beforeSend: function(){
			           $("#loading").dialog('open').html("<p>Processing Request...</p>");
			        },
				   
				   success: function(response) {
					 newDcNo=response;
					location.href='viewdeliverychallan/deliveryChallanReport?deliveryChallanNo='+newDcNo;
                    alert("Delivery Challan "+response +" is created");
				  
				   document.getElementById('salesOrderSelected').value="";
			    	document.getElementById('partySelected').value="";
					//document.getElementById('salesOrderSelect').value ="";
					//$('#salesOrderSelect').trigger('liszt:updated');
					  //document.getElementById('partySelect').value ="";
						//$('#partySelect').trigger('liszt:updated');
						idsOfSelectedRows=[];
				      jQuery("#stockOutGrid").setGridParam({datatype:'json'}); 
				     jQuery("#stockOutGrid").setGridParam({postData: {searchObject:"allSearch"}});
				     jQuery("#stockOutGrid").trigger('reloadGrid');
				     $("#barCodeInput").focus();
			  },	
		
		        complete: function() {
		        	 $("#loading").dialog('close');
		        }
			   }
			   );

} 
 }
}

function stockOutChallanValidation(){
	 var challanDate=document.getElementById('deliveryDate').value;
	if(idsOfSelectedRows.length==0){
		alert("Select items of an approved sales order");
		return false;
	}
	 if($("#salesOrderSelect").val()==""){
			alert("Select approved sales order");
			return false;
 	 }
	 if(challanDate==null || challanDate==""){
			alert("Select Challan Date");
			return false;
 	 
	 }
	 else
		 return true;
}


function clearFn() {
 $("#barCodeInput").focus();
   document.getElementById('barCodeInput').value="";
   document.getElementById('itemCode').value ="";
	document.getElementById('salesOrderId').value ="";
	document.getElementById('workOrderNo').value ="";
	document.getElementById('bundleId').value ="";
	document.getElementById('itemDesc').value ="";
	document.getElementById('customerName').value="";
	document.getElementById('qty').value ="";
	document.getElementById('units').value ="";
	document.getElementById('weight').value ="";
	document.getElementById('bagNo').value ="";
	document.getElementById('bagWeight').value ="";

}

function editRow(id) {
	$('#stockOutGrid').jqGrid('editRow',id, 
			{
				"keys" :true, 
				"oneditfunc" : hideActButtons,
				aftersavefunc : function(savedId, response) {
				showActButtons(savedId);
				},
				afterrestorefunc : showActButtons
			});
	
	}





function saveRow(id) {
	if(gridBagNoValid==true && gridBagWeightValid==true){
	$('#stockOutGrid').saveRow(id,
	{	aftersavefunc : function(id, response) {
				showActButtons(id);
			}
	});
	}
	else if(gridBagNoValid==false){
		alert("Enter valid Bag No");
	}
	else if(gridBagWeightValid==false){
		alert("Enter valid Bag Weight");
	}
	 jQuery("#stockOutGrid").trigger('reloadGrid');
}

function restoreRow(id) {
	$('#stockOutGrid').jqGrid('restoreRow',id,
			{
				afterrestorefunc : showActButtons
			});
}

/*
 * Hides the Edit and Del Row Buttons on jqGrid
 * and activates the Save and restore(cancel) button
 * 
 */
function hideActButtons(id){
	$('#editRow' + id).hide();
	$('#delRow' + id).hide();
	$('#saveRow' + id).show();
	$('#restoreRow' + id).show();
	
}

/*
 * Shows the Edit and Del Row Buttons on jqGrid
 * and hides the Save and restore(cancel) button
 * 
 */
function showActButtons(id) {
	$('#editRow' + id).show();
	$('#delRow' + id).show();
	$('#saveRow' + id).hide();
	$('#restoreRow' + id).hide();
	lastSelected = null;
}

$(document).keypress(function(e) {
    if(e.which == 13) {
    	var ids = $("#stockOutGrid").jqGrid('getDataIDs');
    	for ( var i = 0; i < ids.length; i++) {
			var cl = ids[i];
			saveRow(cl);
       	} }});


