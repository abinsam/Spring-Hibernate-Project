var lastSelected;
var woQtyValid=true;
var year="";
var month="";
$(function() {
	
	$("#workOrderNoSelect").chosen({no_results_text : "No results matched"});
	
	$("#monthYearPicker").focus(function () {$(".ui-datepicker-calendar").hide();});
	$('#monthYearPicker').datepicker({
	
        changeYear: true,
        changeMonth: true,
        changeDate :false,
        showButtonPanel: true,
        dateFormat: 'MM yy',
  
        onClose: function(dateText, inst) { 
           year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
           month = $("#ui-datepicker-div .ui-datepicker-month :selected").val();
            $(this).datepicker('setDate', new Date(year,month, 1));
            monthYearSelect(month,year);
        }

    });
	
$("#monthYearPicker").focus(function () {$(".ui-datepicker-month").show();});
$("#monthYearPicker").focus(function () {$(".ui-datepicker-year").show();});

	$("#stockOutOfPVCGrid").jqGrid(
					{
						url : 'stockOutOfPVC/records',
						datatype : 'json',
						mtype : 'POST',
						multiselect: true,
						
						colNames : [ 'Rw Store Reg Id', 'Purchase Order Item Id', 
							    'Party', 'Item Id', 'Item Code',
								'Item Description', 'Gross Weight',
								'Tare Weight', 'Net Weight', 'No Of Bags',
								'Total Quantity','Total qty hid','Batch No','Stock Out Qty','QC Status','Actions'],
						colModel : [ {
							name : 'rwStoreRegId',
							index : 'rwStoreRegId',
							width : 5,
							viewable : false,
							hidden : true
						}, {
							name : 'purchaseOrderItemId',
							index : 'purchaseOrderItemId',
							width : 5,
							viewable : false,
							hidden : true
						}, 
						{
							name : 'customerName',
							index : 'customerName',
							width : 150
						},

						{
							name : 'itemId',
							index : 'itemId',
							width : 5,
							hidden : true
						}, {
							name : 'itemCode',
							index : 'itemCode',
							width : 160
						}, {
							name : 'itemDescription',
							index : 'itemDescription',
							width : 180
						}, {
							name : 'grossWeight',
							index : 'grossWeight',
							width : 60
						}, {
							name : 'tareWeight',
							index : 'tareWeight',
							width : 60
						}, {
							name : 'netWeight',
							index : 'netWeight',
							width : 60
						}, {
							name : 'noOfBags',
							index : 'noOfBags',
							width : 10,
							hidden : true
						}, {
							name : 'totalQty',
							index : 'totalQty',
							width : 60
						},  {
							name : 'totalQty',
							index : 'totalQty',
							width : 10,
							editable:true,
							hidden:true
						},{
							name : 'batchNo',
							index : 'batchNo',
							width : 50
						},
						 {
							name : 'stockOutQty',
							index : 'stockOutQty',
							width : 60,
							editable:true,
							editoptions:{
			                       dataInit: function(element) {
			                              $(element).keyup(function(){
			                                  var val1 = element.value;
			                                  var num = new Number(val1);
			                                  if(isNaN(num))
			                                  {
			                                	  alert("Please enter a valid number");
			                                	  woQtyValid=false;
			                                 }
			                                  else
			                                	  woQtyValid=true;
			                                
			                              });
			                          }
			                      }
						},
						{
							name : 'qcStatus',
							index : 'qcStatus',
							width : 60
						},
						{name:'act',index:'act', width:68,sortable:false}


						],
						postData : {},
						rowNum : 100,
						rowList : [ 5, 10, 20, 30, 40, 100 ],
						height : 300,
						autowidth : true,
						rownumbers : false,
						pager : '#stockOutOfPVCPager',
						sortname : 'rwStoreRegId',
						viewrecords : true,
						sortorder : "desc",
						caption : "Stock Out Of PVC",
						  emptyrecords: "Empty records",
						    loadonce: false,
						    footerrow : true,
						    
						    loadComplete: function() {},
						    jsonReader : {
						        root: "rows",
						        page: "page",
						        total: "total",
						        records: "records",
						        repeatitems: false,
						        cell: "cell",
							id : "rwStoreRegId"
						},
						 ondblClickRow : function(id) {
	        	   				if (id && id !== lastSelected) {
	        	   					$('#SOforWOGrid').jqGrid('restoreRow',lastSelected);
	        	   					editRow(id);
	        	   					lastSelected = id;
	        	   				}
	        	   			},
	        	   		 onSelectRow: updateIdsOfSelectedRows,   
	        	   		 onSelectAll:function (aRowids, status) {
	        	      	   updateIdsOfAllSelectedRows(aRowids,status);
	        	         },
	        	   	    loadComplete: function () {
	        	   	        var $this = $(this), i, count;
	        	   	        for (i = 0, count = idsOfSelectedRows.length; i < count; i++) {
	        	   	            $this.jqGrid('setSelection', idsOfSelectedRows[i], false);
	        	   	        }
	        	   	      },
						gridComplete : function() {	
						var ids = $("#stockOutOfPVCGrid").jqGrid('getDataIDs');
						for ( var i = 0; i < ids.length; i++) {
							var cl = ids[i];
        					be = "<input style='height:24px; width:35px;' type='button' value='Edit' id='editRow"+cl+"' onclick=\"editRow('"+ cl + "');\" />";
        					se = "<input style='height:24px; width:40px;' type='button' value='Save' hidden='hidden' id='saveRow"+cl+"' onclick=\"saveRow('"+ cl + "');\" />";
        					ce = "<input style='height:24px;width:50px;' type='button' value='Cancel' hidden='hidden' id='restoreRow"+cl+"' onclick=\"restoreRow('"+ cl + "');\" />";
            				$("#stockOutOfPVCGrid").jqGrid('setRowData', ids[i],{
            					act : be + se + ce
            				});
            			}},
            			beforeSelectRow: function (rowid, e) {
						    var $myGrid = $(this),
						        i = $.jgrid.getCellIndex($(e.target).closest('td')[0]),
						        cm = $myGrid.jqGrid('getGridParam', 'colModel');
						    return (cm[i].name === 'cb');
						},
        	   		editurl : "stockOutOfPVC/crud"
				

      	});
	jQuery("#stockOutOfPVCGrid").jqGrid('navGrid', '#stockOutOfPVCPager', {
		view : false,
		del : false,
		add : false,
		edit : false,
		search : false
	});

});

function monthYearSelect(month,year){
	
	$('#workOrderNoSelect').children().remove();
	$('#workOrderNoSelect').val('').trigger('liszt:updated');
	

	$.ajax({
		
		type:'POST', 
		url: 'stockOutOfPVC/getWorkOrderNos',
		data : {"processType" : "Extrusion","month":month,"year":year},
		success: function(response) {
			$('#mwdWorkOrderNoSelect').empty();
			if (response.length == 0) {

				alert("There is no Work Order for selected month and year");
			}

			if(response.length != 0){
				for(var i=0;i< response.length;i++){
					$('#workOrderNoSelect').append('<option selected="selected">'+ "" + '</option>');
					$('#workOrderNoSelect').append('<option >' + response[i]+ '</option>');
					$('#workOrderNoSelect').trigger('liszt:updated');
				}
			
			}
		}
	});
}

idsOfSelectedRows = ["8", "9", "10"];
var $SOforWOGrid = $("#stockOutOfPVCGrid"), idsOfSelectedRows = [],
updateIdsOfSelectedRows = function (id, isSelected) {
	    var grid = jQuery('#stockOutOfPVCGrid'); 
   	   var woQty=grid.jqGrid ('getCell', id, 'stockOutQty');
   	var qcStatus = grid.jqGrid('getCell', id, 'qcStatus');
 	    if (isNaN(woQty)){  
	         saveRow(id);
		}
		else{
			editRow(id);
			 saveRow(id);
		}
 	   if (qcStatus=="Approved"){  
	     var index = $.inArray(id, idsOfSelectedRows);
       if (!isSelected && index >= 0) {
	          idsOfSelectedRows.splice(index, 1); // remove id from the list
        } else if (index < 0) {
          idsOfSelectedRows.push(id);
        }  
 	   } else{
 		   alert("PVC Item Quality should be approved for stock out");
 		  $("#stockOutOfPVCGrid").resetSelection(id);
 	   }
       
};



updateIdsOfAllSelectedRows = function (aRowids, isSelected) {
	var counter = 0;
   var grid = jQuery('#stockOutOfPVCGrid'); 
	 var i, count, id;
	 for (i = 0, count = aRowids.length; i < count; i++) {
		 id = aRowids[i];
    var woQty=grid.jqGrid ('getCell', id, 'stockOutQty');
	var qcStatus = grid.jqGrid('getCell', id, 'qcStatus');
      	    if (isNaN(woQty)){  
    	         saveRow(id);
     		}
     		else{
     			editRow(id);
     			 saveRow(id);
     		}
        	  if (qcStatus == "Approved") {
    	     var index = $.inArray(id, idsOfSelectedRows);
           if (!isSelected && index >= 0) {
   	          idsOfSelectedRows.splice(index, 1); // remove id from the list
            } else if (index < 0) {
              idsOfSelectedRows.push(id);
            }  
        	  }else counter++;
         }
	  if (counter > 0) {
			alert("Select QC approved Items ");
			$("#stockOutOfPVCGrid").resetSelection();

		} 

};

 
function editRow(id) {
	 	restoreRow(lastSelected);
		lastSelected = id;
		$('#stockOutOfPVCGrid').jqGrid('editRow',id, 
		{
			"keys" :true, 
			"oneditfunc" : hideActButtons,
			aftersavefunc : function(savedId, response) {
				showActButtons(savedId);
			},
			afterrestorefunc : showActButtons
		});
}   


function saveRow(id) {
 if(woQtyValid==true){
 	 $('#stockOutOfPVCGrid').saveRow(id,
		{	aftersavefunc : function(id, response) {showActButtons(id);}
		});
	}
  else{
	 alert("Quantity entered should be valid");
}
}

	function restoreRow(id) {
		$('#stockOutOfPVCGrid').jqGrid('restoreRow',id,
		{
			afterrestorefunc : showActButtons
		});
	}


	$(document).keypress(function(e) {
	   if (e.which == 13) {
			var ids = $("#stockOutOfPVCGrid").jqGrid('getDataIDs');
			for ( var i = 0; i < ids.length; i++) {
				var cl = ids[i];
			    if(woQtyValid==true){
			    	 saveRow(cl);
			    }
			    else{
			    	alert("Enter valid quantity");
			    	break;
			    }
			}
	   }
	});
    /*
     * Hides the Edit and Del Row Buttons on jqGrid
     * and activates the Save and restore(cancel) button
     * 
     */
    function hideActButtons(id){
    	$('#editRow' + id).hide();
    	$('#delRow' + id).hide();
    	$('#saveRow' + id).show();
    	$('#restoreRow' + id).show();
    }

    /*
     * Shows the Edit and Del Row Buttons on jqGrid
     * and hides the Save and restore(cancel) button
     * 
     */
    function showActButtons(id) {
    	$('#editRow' + id).show();
    	$('#delRow' + id).show();
    	$('#saveRow' + id).hide();
    	$('#restoreRow' + id).hide();
    	lastSelected = null;
    }

    function confirmPvcStockOut(){
    	var extrusionWoNo= $('#workOrderNoSelect').val();
    	if(extrusionWoNo!=null && extrusionWoNo!=""){
    		if( idsOfSelectedRows.length>0){
    	     	   $.ajax({
    				   type:'POST',
    				   url: 'stockOutOfPVC/pvcStockOut',
    				   data: {'idsOfSelectedRows': idsOfSelectedRows,'extrusionWoNo':extrusionWoNo },
    				   success: function(response) {
    				   alert("Selected PVC stocked out for Work Order "+extrusionWoNo);
    				     jQuery("#stockOutOfPVCGrid").setGridParam({datatype:'json'}); 
    					 jQuery("#stockOutOfPVCGrid").setGridParam({ url : 'stockOutOfPVC/records'});
    					 jQuery("#stockOutOfPVCGrid").trigger('reloadGrid');

    				   idsOfSelectedRows = [];
    			      }
    			   }
    			   );
    		}else
    			alert("Select PVC for stock out");
    	}else
    		alert("Select Extrusion Work Order No");	
    	
    
    }

    $("#monthYearPicker").focus(function() {
    	
    	if ($("#workOrderNoSelect").val() != "") {
    		document.getElementById('workOrderNoSelect').value = "";
    		$('#workOrderNoSelect').trigger('liszt:updated');
    	}
    
    }); 
  function resetValues()
  {
	  if ($("#workOrderNoSelect").val() != "") {
  		document.getElementById('workOrderNoSelect').value = "";
  		$('#workOrderNoSelect').trigger('liszt:updated');
  	}  
	  if (document.getElementById('monthYearPicker').value != "")
			document.getElementById('monthYearPicker').value = "";
	  
		$('#workOrderNoSelect').children().remove();
  }
