var lastSelected;
var lastBarCodeSelected;
var stockOutQtyValid=true;

var year="";
var month="";
$(function() {
	 if($('input:radio[name=stockOutSelect]:checked').val()==0){
		  $('.barCodeTextId').show();
		  $('.barCodeInputId').show();
		  $("#manualStockOut").hide();
		  $("#barCodeStockOut").show();
		  var processValues=$('#processTypeSelect').val();
		  if(processValues!=null && processValues!=""){
		  if(processValues=="MWD")
			  itemType="Multiwire";
		  else if(processValues=="Bunching")
			  itemType="Bunching";
		  else
			  itemType="";
		   jQuery("#stockOutBarCodeGrid").setGridParam({datatype:'json'}); 
		   jQuery("#stockOutBarCodeGrid").setGridParam({ url: 'stockOutSemiFinished/semiFinishedStockOutRecords'});
		   jQuery("#stockOutBarCodeGrid").setGridParam({postData: {itemType:itemType}}); 
		   jQuery("#stockOutBarCodeGrid").trigger('reloadGrid');
		  }
		  }else{
	 		  $('.barCodeTextId').hide();
			  $('.barCodeInputId').hide();
			  $("#manualStockOut").show();
			  $("#barCodeStockOut").hide();
			  var processValue=$('#processTypeSelect').val();
			  if(processValue!="" && processValue!=null){
			   jQuery("#StockOutSemiFinshedGrid").setGridParam({datatype:'json'}); 
			   jQuery("#StockOutSemiFinshedGrid").setGridParam({ url: 'stockOutSemiFinished/storeReg'});
			   jQuery("#StockOutSemiFinshedGrid").setGridParam({postData: {process:processValue}}); 
			   jQuery("#StockOutSemiFinshedGrid").trigger('reloadGrid');
			  }
	  	 }
	 
	  $("input[name=stockOutSelect]").change(function () {
		  if($('input:radio[name=stockOutSelect]:checked').val()==0){
			  $('.barCodeTextId').show();
			  $('.barCodeInputId').show();
			  $("#manualStockOut").hide();
			  $("#barCodeStockOut").show();
			  var processValue=$('#processTypeSelect').val();
              if(processValue!=null && processValue!=""){
			  if(processValue=="MWD")
				  itemType="Multiwire";
			  else if(processValue=="Bunching")
				  itemType="Bunching";
			  else
				  itemType="";
			   jQuery("#stockOutBarCodeGrid").setGridParam({datatype:'json'}); 
			   jQuery("#stockOutBarCodeGrid").setGridParam({ url: 'stockOutSemiFinished/semiFinishedStockOutRecords'});
			   jQuery("#stockOutBarCodeGrid").setGridParam({postData: {itemType:itemType}}); 
			   jQuery("#stockOutBarCodeGrid").trigger('reloadGrid');
              }
			  }else{
			  $('.barCodeTextId').hide();
			  $('.barCodeInputId').hide();
			  $("#manualStockOut").show();
			  $("#barCodeStockOut").hide();
			  var processValue=$('#processTypeSelect').val();
			  if(processValue!="" && processValue!=null){
			   jQuery("#StockOutSemiFinshedGrid").setGridParam({datatype:'json'}); 
			   jQuery("#StockOutSemiFinshedGrid").setGridParam({ url: 'stockOutSemiFinished/storeReg'});
			   jQuery("#StockOutSemiFinshedGrid").setGridParam({postData: {process:processValue}}); 
			   jQuery("#StockOutSemiFinshedGrid").trigger('reloadGrid');
			  }
		 }
	  });

	 
		$("#monthYearPicker").focus(function () {$(".ui-datepicker-calendar").hide();});
		$('#monthYearPicker').datepicker({
		
	        changeYear: true,
	        changeMonth: true,
	        changeDate :false,
	        showButtonPanel: true,
	        dateFormat: 'MM yy',
	       
	        onClose: function(dateText, inst) { 
	            year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
	            month = $("#ui-datepicker-div .ui-datepicker-month :selected").val();
	          $(this).datepicker('setDate', new Date(year,month, 1));
	            changeWoOnMonthYear();
	        }
	    });
	$("#monthYearPicker").focus(function () {$(".ui-datepicker-month").show();});
	$("#monthYearPicker").focus(function () {$(".ui-datepicker-year").show();});


	$("#processTypeSelect").chosen({no_results_text : "No results matched"});
	$("#workOrderNoSelect").chosen({no_results_text : "No results matched"});
	

	
	
    $("#StockOutSemiFinshedGrid").jqGrid(
			            {
						url : 'stockOutSemiFinished/storeReg',
						datatype : 'json',
						mtype : 'POST',
						multiselect: true,
						colNames : [ 'Store Reg Id', 'Store', 'Sales Order No',
								'Order Status', 'PartyHidden','Party', 'Item Id', 'Item Code',
								'Item Description', 'Work Order No','Batch No',
								 'Stock Qty(mts)', 'Units',	'QC Status','Stock Qty(Kg)'],
						colModel : [ 
						  {	name : 'storeRegisterId',index : 'storeRegisterId',	width : 5,hidden : true}, 
						  {	name : 'storeAddress',index : 'storeAddress',width : 5,	hidden : true},
						  {name : 'orderId',index : 'orderId',	width : 80},
						  {name : 'status',index : 'status',width :90}, 
						  {name : 'customerName',index : 'customerName',width : 10,hidden : true},
						  {name : 'customerCode',index : 'customerCode',width : 60},
						  {	name : 'itemId',index : 'itemId',width : 5,hidden : true}, 
						  {	name : 'itemCode',index : 'itemCode',width : 150}, 
						  {	name : 'itemDescription',index : 'itemDescription',	width : 180	},
						  {	name : 'workOrderNo',index : 'workOrderNo',	width : 90},
						  {	name : 'bundleId',index : 'bundleId',	width : 90},
					      {name : 'stockQty',index : 'stockQty',	width : 90},
					      {name : 'units',index : 'units',width : 10,hidden : true}, 
					      {name : 'qcStatus',index : 'qcStatus',width :90}, 
					      {name : 'weight',index : 'weight',	width : 90},
	
						],
						postData : {},
						rowNum : 100,
						rowList : [ 5, 10, 20, 30, 40, 100 ],
						height : 400,
						autowidth : true,
						rownumbers : false,
						pager : '#StockOutSemiFinishedPager',
						sortname : 'storeRegisterId',
						viewrecords : true,
						sortorder : "desc",
						caption : "Semi Finshed Goods Stock Out",
						emptyrecords : "Empty records",
						loadonce : false,
						footerrow : true,
						loadComplete : function() {
						},
						jsonReader : {
							root : "rows",
							page : "page",
							total : "total",
							records : "records",
							repeatitems : false,
							cell : "cell",
							id : "storeRegisterId"
						},
			   		    ondblClickRow : function(id) {
        	   				if (id && id !== lastSelected) {
        	   					$('#StockOutSemiFinshedGrid').jqGrid('restoreRow',lastSelected);
        	   					editRow(id);
        	   					lastSelected = id;
        	   				}
        	   			
        	   			},
        	   		 onSelectRow: updateIdsOfSelectedRows,   
        	   		 onSelectAll:function (aRowids, status) {
        	      	 updateIdsOfAllSelectedRows(aRowids,status);
        	      },
        	   	    loadComplete: function () {
        	   	        var $this = $(this), i, count;
        	   	        for (i = 0, count = idsOfSelectedRows.length; i < count; i++) {
        	   	            $this.jqGrid('setSelection', idsOfSelectedRows[i], false);
        	   	        }
        	   	      },
			
					
						gridComplete : function() {	
							var totalStockQty= $('#StockOutSemiFinshedGrid').jqGrid('getCol','stockQty',false,'sum');
        	   		   		$('#StockOutSemiFinshedGrid').jqGrid('footerData','set', {ID: 'Total:', stockQty: totalStockQty});
        	   		     	var totalWeight= $('#StockOutSemiFinshedGrid').jqGrid('getCol','weight',false,'sum');
    	   		   		    $('#StockOutSemiFinshedGrid').jqGrid('footerData','set', {ID: 'Total:', weight: totalWeight});	
			
            			},
						beforeSelectRow: function (rowid, e) {
						    var $myGrid = $(this),
						        i = $.jgrid.getCellIndex($(e.target).closest('td')[0]),
						        cm = $myGrid.jqGrid('getGridParam', 'colModel');
						    return (cm[i].name === 'cb');
						}
				
				});
	jQuery("#StockOutSemiFinshedGrid").jqGrid('navGrid', '#StockOutSemiFinishedPager', {
		view : false,
		del : false,
		add : false,
		edit : false,
		search : false,reload:true
	});

	
	 
	 $("#stockOutBarCodeGrid").jqGrid(
	            {
	            	url : 'stockOutSemiFinished/semiFinishedStockOutRecords',
				datatype : 'json',
				mtype : 'POST',
				multiselect: true,
				colNames : [ 'SemiFinishedStockOutId', 'Store', 'Sales Order No',
						'Order Status', 'Party', 'Item Id', 'Item Code',
						'Item Description', 'Work Order No','Batch No',
						 'Stock Qty(mts)', 'Units',	'QC Status','Stock Qty(Kg)','type','Action'],
				colModel : [ 
				  {	name : 'semifinishedStockOutId',index : 'semifinishedStockOutId',	width : 5,hidden : true}, 
				  {	name : 'storeAddress',index : 'storeAddress',width : 5,	hidden : true},
				  {name : 'orderId',index : 'orderId',	width : 50},
				  {name : 'status',index : 'status',width : 70}, 
				  {name : 'customerName',index : 'customerName',width : 220},
				  {	name : 'itemId',index : 'itemId',width : 5,hidden : true}, 
				  {	name : 'itemCode',index : 'itemCode',width : 140}, 
				  {	name : 'itemDescription',index : 'itemDescription',	width : 110	},
				  {	name : 'workOrderNo',index : 'workOrderNo',	width : 50},
				  {	name : 'bundleId',index : 'bundleId',	width : 30},
			      {name : 'stockOutQty',index : 'stockOutQty',	width : 70},
			      {name : 'units',index : 'units',width : 10,hidden : true}, 
			      {name : 'qcStatus',index : 'qcStatus',width :60}, 
			      {name : 'weight',index : 'weight',	width : 60},
			      {name : 'itemType',index : 'itemType',hidden:true, width : 10},
                  {name :'act',index:'act', width:40}
				],
				postData : {},
				rowNum : 100,
				rowList : [ 5, 10, 20, 30, 40, 100 ],
				height : 400,
				autowidth:true,
				rownumbers : false,
				pager : '#stockOutBarCodePager',
				sortname : 'semifinishedStockOutId',
				viewrecords : true,
				sortorder : "desc",
				caption : "Semi Finshed Goods Selected For Stock Out",
				emptyrecords : "Empty records",
				loadonce : false,
				footerrow : true,
				loadComplete : function() {
				},
				jsonReader : {
					root : "rows",
					page : "page",
					total : "total",
					records : "records",
					repeatitems : false,
					cell : "cell",
					id : "semifinishedStockOutId"
				},
	   		    ondblClickRow : function(id) {
	   				if (id && id !== lastSelected) {
	   					$('#stockOutBarCodeGrid').jqGrid('restoreRow',lastSelected);
	   					lastBarCodeSelected = id;
	   				}
	   			},
	   		 onSelectRow: updateIdsOfBarCodeSelectedRows,   
	   		onSelectAll:function (aRowids, status) {
	      	  updateIdsOfAllBarCodeSelectedRows(aRowids,status);
	      },
	   	    loadComplete: function () {
	   	        var $this = $(this), i, count;
	   	        for (i = 0, count = idsOfBarCodeSelectedRows.length; i < count; i++) {
	   	            $this.jqGrid('setSelection', idsOfBarCodeSelectedRows[i], false);
	   	        }
	   	      },
	
			
				gridComplete : function() {	
					var ids = $("#stockOutBarCodeGrid").jqGrid('getDataIDs');
			    	for ( var i = 0; i < ids.length; i++) {
					var cl = ids[i];
					de = "<input style='height:22px; width: 38px;' type='button' value='Delete'  id='delRow"+cl+"' onclick=\"delRow('"+ cl + "');\" />";
					$("#stockOutBarCodeGrid").jqGrid('setRowData', ids[i],{
 					act : de
 				});
 			}},
				beforeSelectRow: function (rowid, e) {
				    var $myGrid = $(this),
				        i = $.jgrid.getCellIndex($(e.target).closest('td')[0]),
				        cm = $myGrid.jqGrid('getGridParam', 'colModel');
				    return (cm[i].name === 'cb');
				}
		

			// editurl : "viewworkorder/crud",
			});
jQuery("#stockOutBarCodeGrid").jqGrid('navGrid', '#stockOutBarCodePage', {
view : false,
del : false,
add : false,
edit : false,
search : false,reload:true
});
});




idsOfSelectedRows = ["8", "9", "10"];
var $SOforWOGrid = $("#StockOutSemiFinshedGrid"), idsOfSelectedRows = [],
updateIdsOfSelectedRows = function (id, isSelected) {
	var workOrderNo = $('#workOrderNoSelect').val();
	    var grid = jQuery('#StockOutSemiFinshedGrid'); 
	 	var qcStatus = grid.jqGrid('getCell', id, 'qcStatus');
  	   
 	if(workOrderNo!="" && workOrderNo!=null){
 		  if (qcStatus=="Approved"){  
	     var index = $.inArray(id, idsOfSelectedRows);
       if (!isSelected && index >= 0) {
	          idsOfSelectedRows.splice(index, 1); // remove id from the list
        } else if (index < 0) {
          idsOfSelectedRows.push(id);
        }  }else{
  		   alert("Selected Item Quality should be approved for stock out");
  		  $("#StockOutSemiFinshedGrid").resetSelection(id);
  	   }
 	} else{
     		alert("Select Work Order for stock out process");
     		 $("#StockOutSemiFinshedGrid").resetSelection(id);
     	}
  };



updateIdsOfAllSelectedRows = function (aRowids, isSelected) {
	var qcStatusCounter=0;
	var woNos=0;
	var workOrderNo = $('#workOrderNoSelect').val();
	   var grid = jQuery('#StockOutSemiFinshedGrid'); 
   	 var i, count, id;
	 for (i = 0, count = aRowids.length; i < count; i++) {
		 id = aRowids[i];
		 var qcStatus = grid.jqGrid('getCell', id, 'qcStatus');
		 if(workOrderNo!="" && workOrderNo!=null && qcStatus=="Approved"){
  	     var index = $.inArray(id, idsOfSelectedRows);
          if (!isSelected && index >= 0) {
   	     idsOfSelectedRows.splice(index, 1); // remove id from the list
            } else if (index < 0) {
            idsOfSelectedRows.push(id);
            }  

  	 }else if(qcStatus!="Approved"){
  		qcStatusCounter++;
  	 }else {
  		woNos++;
  	 }}
  	 if(woNos>0){
         alert("Select Work Order ");
         $("#StockOutSemiFinshedGrid").resetSelection();
   	 }else if(qcStatusCounter>0){
   		alert("Select QC approved Items ");
		$("#StockOutSemiFinshedGrid").resetSelection();
   	 }
};



idsOfBarCodeSelectedRows = ["8", "9", "10"];
var $SOforWOBarCodeGrid = $("#stockOutBarCodeGrid"), idsOfBarCodeSelectedRows = [],
updateIdsOfBarCodeSelectedRows = function (id, isSelected) {
	var workOrderNo = $('#workOrderNoSelect').val();
	    var grid = jQuery('#stockOutBarCodeGrid'); 
	 	var qcStatus = grid.jqGrid('getCell', id, 'qcStatus');
  	   
 	if(workOrderNo!="" && workOrderNo!=null){
 		  if (qcStatus=="Approved"){  
	     var index = $.inArray(id, idsOfBarCodeSelectedRows);
       if (!isSelected && index >= 0) {
    	   idsOfBarCodeSelectedRows.splice(index, 1); // remove id from the list
        } else if (index < 0) {
        	idsOfBarCodeSelectedRows.push(id);
        }  }else{
  		   alert("Selected Item Quality should be approved for stock out");
  		  $("#stockOutBarCodeGrid").resetSelection(id);
  	   }
 	} else{
     		 alert("Select Work Order for stock out process");
     		 $("#stockOutBarCodeGrid").resetSelection(id);
     	}
  };



  updateIdsOfAllBarCodeSelectedRows = function (aRowids, isSelected) {
	var qcStatusCounter=0;
	var woNos=0;
	var workOrderNo = $('#workOrderNoSelect').val();
	   var grid = jQuery('#stockOutBarCodeGrid'); 
   	 var i, count, id;
	 for (i = 0, count = aRowids.length; i < count; i++) {
		 id = aRowids[i];
		 var qcStatus = grid.jqGrid('getCell', id, 'qcStatus');
		 if(workOrderNo!="" && workOrderNo!=null && qcStatus=="Approved"){
  	     var index = $.inArray(id, idsOfBarCodeSelectedRows);
          if (!isSelected && index >= 0) {
        	  idsOfBarCodeSelectedRows.splice(index, 1); // remove id from the list
            } else if (index < 0) {
            	idsOfBarCodeSelectedRows.push(id);
            }  

  	 }else if(qcStatus!="Approved"){
  		qcStatusCounter++;
  	 }else {
  		woNos++;
  	 }}
  	 if(woNos>0){
         alert("Select Work Order ");
         $("#stockOutBarCodeGrid").resetSelection();
   	 }else if(qcStatusCounter>0){
   		alert("Select QC approved Items ");
		$("#stockOutBarCodeGrid").resetSelection();
   	 }
};

function delRow(id){
	 var process=$('#processTypeSelect').val();
	 var itemType="";
	 if(process=="MWD")
		 itemType="Multiwire";
	 else if(process=="Bunching")
		 itemType="Bunching"; 
	  $("#stockOutBarCodeGrid").resetSelection(id);
if (confirm("Do you want to delete this items")){
	   $.ajax(
			   {
				   type:'POST',
				   url: 'stockOutSemiFinished/delete',
				   data: {'id': id},
				   success: function(response) {
					   jQuery("#stockOutBarCodeGrid").setGridParam({datatype:'json'}); 
					   jQuery("#stockOutBarCodeGrid").setGridParam({ url: 'stockOutSemiFinished/semiFinishedStockOutRecords'});
					   jQuery("#stockOutBarCodeGrid").setGridParam({postData: {itemType:itemType}}); 
					   jQuery("#stockOutBarCodeGrid").trigger('reloadGrid');
				
					   jQuery("#StockOutSemiFinshedGrid").setGridParam({datatype:'json'}); 
					   jQuery("#StockOutSemiFinshedGrid").setGridParam({ url: 'stockOutSemiFinished/storeReg'});
					   jQuery("#StockOutSemiFinshedGrid").setGridParam({postData: {process:process}}); 
					   jQuery("#StockOutSemiFinshedGrid").trigger('reloadGrid');
			
				   alert("Selected Item deleted from stock out list");
				   $("#barCodeInput").focus();
				   
			  }
			   }
			   );
	 
}} 

$("#processTypeSelect").chosen().change(function() {

	 var process=$('#processTypeSelect').val();
	 $('#workOrderNoSelect').empty();
	 $.ajax({type:'POST',
			  url: 'stockOutSemiFinished/fetchWorkOrder',
			  data: {'process': process,"month":month,"year":year}, 
			  success: function(response) {
					//$('#workOrderNoSelect').empty();	
						if(response.length != 0){
						for(var i=0;i< response.length;i++){
							$('#workOrderNoSelect').append('<option selected="selected">'+ "" + '</option>');
							$('#workOrderNoSelect').append('<option >' + response[i]+ '</option>');
							$('#workOrderNoSelect').trigger('liszt:updated');
						}
					}else{
						$('#workOrderNoSelect').empty();	
						$('#workOrderNoSelect').children().remove();
						$('#workOrderNoSelect').val('').trigger('liszt:updated');
			
					}
					
					  if($('input:radio[name=stockOutSelect]:checked').val()==1){
						   jQuery("#StockOutSemiFinshedGrid").setGridParam({datatype:'json'}); 
						   jQuery("#StockOutSemiFinshedGrid").setGridParam({ url: 'stockOutSemiFinished/storeReg'});
						   jQuery("#StockOutSemiFinshedGrid").setGridParam({postData: {process:process}}); 
						   jQuery("#StockOutSemiFinshedGrid").trigger('reloadGrid');
					  }else{
						  if(process!=null && process!=""){
							  if(process=="MWD")
								  itemType="Multiwire";
							  else if(process=="Bunching")
								  itemType="Bunching";
							  else
								  itemType="";
							   jQuery("#stockOutBarCodeGrid").setGridParam({datatype:'json'}); 
							   jQuery("#stockOutBarCodeGrid").setGridParam({ url: 'stockOutSemiFinished/semiFinishedStockOutRecords'});
							   jQuery("#stockOutBarCodeGrid").setGridParam({postData: {itemType:itemType}}); 
							   jQuery("#stockOutBarCodeGrid").trigger('reloadGrid');
								  }
					  }
		 }
		 });
	
});

function changeWoOnMonthYear(){
	 var process=$('#processTypeSelect').val();
		 $('#workOrderNoSelect').empty();
	 if(process!=null && process!=""){
		 $.ajax({type:'POST',
			  url: 'stockOutSemiFinished/fetchWorkOrder',
			  data: {'process': process,"month":month,"year":year}, 
			  success: function(response) {
			
					$('#workOrderNoSelect').empty();	
					if(response.length != 0){
						for(var i=0;i< response.length;i++){
							$('#workOrderNoSelect').append('<option selected="selected">'+ "" + '</option>');
							$('#workOrderNoSelect').append('<option >' + response[i]+ '</option>');
							$('#workOrderNoSelect').trigger('liszt:updated');
						}
					}else{
						$('#workOrderNoSelect').empty();	
						$('#workOrderNoSelect').children().remove();
						$('#workOrderNoSelect').val('').trigger('liszt:updated');
					}
					  if($('input:radio[name=stockOutSelect]:checked').val()==1){
							   jQuery("#StockOutSemiFinshedGrid").setGridParam({datatype:'json'}); 
							   jQuery("#StockOutSemiFinshedGrid").setGridParam({ url: 'stockOutSemiFinished/storeReg'});
							   jQuery("#StockOutSemiFinshedGrid").setGridParam({postData: {process:process}}); 
							   jQuery("#StockOutSemiFinshedGrid").trigger('reloadGrid');
					  }else{
						  if(process!=null && process!=""){
							  if(process=="MWD")
								  itemType="Multiwire";
							  else if(process=="Bunching")
								  itemType="Bunching";
							  else
								  itemType="";
						   jQuery("#stockOutBarCodeGrid").setGridParam({datatype:'json'}); 
						   jQuery("#stockOutBarCodeGrid").setGridParam({ url: 'stockOutSemiFinished/semiFinishedStockOutRecords'});
						   jQuery("#stockOutBarCodeGrid").setGridParam({postData: {itemType:itemType}}); 
						   jQuery("#stockOutBarCodeGrid").trigger('reloadGrid');
						  }
					  }
		 }
		 });
	 }else{
		 alert("Select Item Type to be stocked out");
	 }

}

function stockOut(){
	var workOrderNo= $('#workOrderNoSelect').val();
	 var process=$('#processTypeSelect').val();
	 if(workOrderNo!="" && workOrderNo!=null){
	 if($('input:radio[name=stockOutSelect]:checked').val()==1){
			if(idsOfSelectedRows.length>0){
				 if (confirm("Are you sure you want to stock out slected items ? ")){
					 $.ajax({
							   type:'POST',
							   url: 'stockOutSemiFinished/stockOutManual',
							   data: {'idsOfSelectedRows': idsOfSelectedRows,'workOrderNo':workOrderNo },
							   success: function(response) {
							   alert("Selected Items are stocked out for Work Order: "+workOrderNo);
							   idsOfSelectedRows=[];
							   jQuery("#StockOutSemiFinshedGrid").setGridParam({datatype:'json'}); 
							   jQuery("#StockOutSemiFinshedGrid").setGridParam({ url: 'stockOutSemiFinished/storeReg'});
							   jQuery("#StockOutSemiFinshedGrid").setGridParam({postData: {process:process}}); 
							   jQuery("#StockOutSemiFinshedGrid").trigger('reloadGrid');
			
						  }
						   }
						   );
			}}else{
				alert("Select items to stock out for work order : "+workOrderNo);
			}
	 }
	 else{
			 var itemType="";
		 if(process=="MWD")
			 itemType="Multiwire";
		 else if(process=="Bunching")
			 itemType="Bunching"; 
			if(idsOfBarCodeSelectedRows.length>0){
				 if (confirm("Are you sure you want to stock out slected items ? ")){
						 $.ajax({
							   type:'POST',
							   url: 'stockOutSemiFinished/stockOutBarCode',
							   data: {'idsOfSelectedRows': idsOfBarCodeSelectedRows,'workOrderNo':workOrderNo },
							   success: function(response) {
							   alert("Selected Items are stocked out for Work Order: "+workOrderNo);
							   idsOfBarCodeSelectedRows=[];
							   jQuery("#stockOutBarCodeGrid").setGridParam({datatype:'json'}); 
							   jQuery("#stockOutBarCodeGrid").setGridParam({ url: 'stockOutSemiFinished/semiFinishedStockOutRecords'});
							   jQuery("#stockOutBarCodeGrid").setGridParam({postData: {itemType:itemType}}); 
							   jQuery("#stockOutBarCodeGrid").trigger('reloadGrid');
					
						  }
						   }
						   );
			}}else{
				alert("Select items to stock out for work order : "+workOrderNo);
			} 
	 }

	}else{
		alert("Select Work Order for which items have to be stocked out");
	}
}


$("#barCodeInput").keydown(function() {
	window.setTimeout(function() {
		var barCode = $("#barCodeInput").val();
		 var process=$('#processTypeSelect').val();
		 var woNo=$('#workOrderNoSelect').val();
		 if(process==null || process==""){
			 alert("Select Item type");
			 document.getElementById('barCodeInput').value = "";
		 }else if(woNo==null || woNo==""){
			 alert("Select Work Order for which items to be stocked out");
			 document.getElementById('barCodeInput').value = "";
		 }
		 else{
			// if(barCode!=null && barCode!=""){
		     if( $("#barCodeInput").val().length==42){
				$.ajax({
					type : 'POST',
					url : 'stockOutSemiFinished/barCodeStockOutScan',
					data : {"barCode":barCode,"process":process,"workOrderNo":woNo},
					success : function(response) {
					
						var item="";
                     if(response[0]=="Valid"){
               		  if(process=="MWD")
               			item="Multiwire";
            		  else if(process=="Bunching")
            			  item="Bunching";
                    	   jQuery("#stockOutBarCodeGrid").setGridParam({datatype:'json'}); 
						   jQuery("#stockOutBarCodeGrid").setGridParam({ url: 'stockOutSemiFinished/semiFinishedStockOutRecords'});
						   jQuery("#stockOutBarCodeGrid").setGridParam({postData: {itemType:item}}); 
						   jQuery("#stockOutBarCodeGrid").trigger('reloadGrid');
	                    	 alert("Items Selected for stock out");

                     }else if(response[0]=="Exist"){
                      	 alert("Items already selected for stock out");
                  	       jQuery("#stockOutBarCodeGrid").setGridParam({datatype:'json'}); 
						   jQuery("#stockOutBarCodeGrid").setGridParam({ url: 'stockOutSemiFinished/semiFinishedStockOutRecords'});
						   jQuery("#stockOutBarCodeGrid").setGridParam({postData: {itemType:process}}); 
						   jQuery("#stockOutBarCodeGrid").trigger('reloadGrid');
		 
                    	 
                     }
                     else{
                    	 alert("Select valid items for stock out"); 
                     }
				 } ,
			     complete: function() {
			    	 document.getElementById('barCodeInput').value = "";
			       }
				});
			 }}
	},0);

});


