var lastSelected;

$("#loading").dialog({
    hide: 'slide',
    show: 'slide',
    autoOpen: false
});
$(function() {
	
	$.ajax({type:'POST', 
		url: 'storeRegister/fetchStoreItems',
		success: function(response) {
			if(response.length != 0){
				for(var i=0;i< response.length;i++){
					$('#itemIdSelect').append('<option selected="selected">'+ "" + '</option>');
					$('#itemIdSelect').append('<option >' + response[i]+ '</option>');
					$('#itemIdSelect').trigger('liszt:updated');
				}
			}
	}});
	
	 $('.storeRegIdClass').hide();
	
	$("#customerSelect").chosen({no_results_text : "No results matched"});
	$("#orderIdSelect").chosen({no_results_text : "No results matched"});
	$("#partySelect").chosen({no_results_text : "No results matched"});
	$("#itemIdSelect").chosen({no_results_text : "No results matched"});
	$("#salesOrderSelect").chosen({no_results_text : "No results matched"});
	$("#strandsSelect").chosen({no_results_text : "No results matched"});
	$("#cuDiameterSelect").chosen({no_results_text : "No results matched"});
	$("#mainColorSelect").chosen({no_results_text : "No results matched"});
	$("#innerColorSelect").chosen({no_results_text : "No results matched"});
	$("#productTypeSelect").chosen({no_results_text : "No results matched"});
	$("#cableStdPvcSelect").chosen({no_results_text : "No results matched"});
	$("#workOrderNoSelect").chosen({no_results_text : "No results matched"});
	$("#deliveryChallanPartySelect").chosen({no_results_text : "No results matched"});
	$("#deleiveryChallanOrderSelect").chosen({no_results_text : "No results matched"});
	$("#processTypeSelect").chosen({no_results_text : "No results matched"});
	
	$("#storeRegisterGrid")
			.jqGrid(
					{
						url : 'storeRegister/records',
						datatype : 'json',
						mtype : 'POST',
						multiselect : true,
						colNames : [ 'Store Reg Id', 'Store', 'Sales Order No',
								'SO Status', 'PartyHidden','Party', 'Item Id', 'Item Code',
								'Item Description', 'Work Order No',
								'Bundle Id', 'Stock Qty(mts)', 'Units',
								'Stock Qty(Kg)', 'Change Label','Label','Bag No', 'Bag Weight','QC Status' ],
						colModel : [ {
							name : 'storeRegisterId',
							index : 'storeRegisterId',
							width : 5,
							viewable : false,
							hidden : true
						}, {
							name : 'storeAddress',
							index : 'storeAddress',
							width : 5,
							viewable : false,
							hidden : true
						}, {
							name : 'orderId',
							index : 'orderId',
							width : 60
						}, {
							name : 'status',
							index : 'status',
							width : 70
						}, {
							name : 'customerName',
							index : 'customerName',
							width : 20,
							hidden:true
						},
						{
							name : 'customerCode',
							index : 'customerCode',
							width : 50
						},
						{
							name : 'itemId',
							index : 'itemId',
							width : 5,
							hidden : true
						}, {
							name : 'itemCode',
							index : 'itemCode',
							width : 160
						}, {
							name : 'itemDescription',
							index : 'itemDescription',
							width : 230
						}, {
							name : 'workOrderNo',
							index : 'workOrderNo',
							width : 70
						}, {
							name : 'bundleId',
							index : 'bundleId',
							width : 40
						}, {
							name : 'stockQty',
							index : 'stockQty',
							width : 70
						}, {
							name : 'unit',
							index : 'unit',
							width : 10,
							hidden : true
						}, {
							name : 'weight',
							index : 'weight',
							width : 60
						}, 
						  {name : 'changeLabelLink',
							index : 'changeLabelLink',
							width : 100,
							editable : false,
							sortable:false
							},
							 {name:'labelLink',
								index:'labelLink',
								width:50, 
								editable:false,
								sortable:false
							},
                         {
							name : 'packingSlipNo',
							index : 'packingSlipNo',
							width : 60
						}, {
							name : 'bagWeight',
							index : 'bagWeight',
							width : 60
						},{
							name : 'qcStatus',
							index : 'qcStatus',
							width : 70
						},

						],
						postData : {},
						rowNum : 100,
						rowList : [ 5, 10, 20, 30, 40, 100,500,1000,2000 ],
						height : 300,
						autowidth : true,
						rownumbers : false,
						pager : '#storeregisterpager',
						sortname : 'storeRegisterId',
						viewrecords : true,
						sortorder : "desc",
						caption : "Store Registry",
						emptyrecords : "Empty records",
						loadonce : false,
						footerrow : true,
						loadComplete : function() {
						},
						jsonReader : {
							root : "rows",
							page : "page",
							total : "total",
							records : "records",
							repeatitems : false,
							cell : "cell",
							id : "storeRegisterId"
						},
						onSelectRow : updateIdsOfSelectedRows,
						onSelectAll : function(aRowids, status) {
							updateIdsOfAllSelectedRows(aRowids, status);
						},
						loadComplete : function() {
							var $this = $(this), i, count;
							for (i = 0, count = idsOfSelectedRows.length; i < count; i++) {
								$this.jqGrid('setSelection',
										idsOfSelectedRows[i], false);
							}
						},
						gridComplete : function() {

							var stockQty = $('#storeRegisterGrid').jqGrid('getCol', 'stockQty', false, 'sum');
							var totalStockQty = Math.round(parseFloat(stockQty) * 100) / 100;
							$('#storeRegisterGrid').jqGrid('footerData', 'set',	{ID : 'Total:',	stockQty : totalStockQty});

							var weight = $('#storeRegisterGrid').jqGrid('getCol', 'weight', false, 'sum');
							var totalWeight = Math.round(parseFloat(weight) * 100) / 100;
							$('#storeRegisterGrid').jqGrid('footerData', 'set',	{ID : 'Total:',	weight : totalWeight});

							var weight = $('#storeRegisterGrid').jqGrid('getCol', 'weight', false, 'sum');
							var totalWeight = Math.round(parseFloat(weight) * 100) / 100;
							$('#storeRegisterGrid').jqGrid('footerData', 'set',{ID : 'Total:',weight : totalWeight});

							var ids = jQuery("#storeRegisterGrid").jqGrid(
									'getDataIDs');
							for ( var i = 0; i < ids.length; i++) {
								var cl = ids[i];
								var storeRegisterId = jQuery("#storeRegisterGrid").jqGrid ('getCell', cl, 'storeRegisterId'); 
								clLink = "<button class='btn btn-mini' id='changeLabelLink"	+ cl+ "' "+ "onclick=\"openChangeLabelPage('"+ cl+ "');\" >Change Label </button>";
								laLink = "<button class='btn btn-mini' id='labelLink"+cl+"'"+" onclick=\"location.href='labeltest/storeRegLabelReport?storeRegisterId="+storeRegisterId+"';\" >Label</button>";

								$("#storeRegisterGrid").jqGrid('setRowData', ids[i], {
									changeLabelLink : clLink,
									labelLink :laLink
								});
								
								if ($("#storeRegisterGrid").getCell(cl,	"status") == "Approved") {
									$("#storeRegisterGrid").jqGrid('setRowData', ids[i], false, {color : 'black',weightfont : 'bold',background : '#FB3232'});
								}
								
								if ($("#storeRegisterGrid").getCell(cl,	"status") == "Approved" && $("#storeRegisterGrid").getCell(cl,	"qcStatus") == "Approved" ) {
									$("#storeRegisterGrid").jqGrid('setRowData', ids[i], false, {color : 'black',weightfont : 'bold',background : '#89D879'});
								}
								
								
							}
						},

						beforeSelectRow : function(rowid, e) {
							var $myGrid = $(this), i = $.jgrid.getCellIndex($(
									e.target).closest('td')[0]), cm = $myGrid
									.jqGrid('getGridParam', 'colModel');
							return (cm[i].name === 'cb');
						}

					});
	jQuery("#storeRegisterGrid").jqGrid('navGrid', '#storeregisterpager', {
		view : false,
		del : false,
		add : false,
		edit : false,
		search : false
	});

	$("#stockOutGrid").jqGrid(
					{
						url : 'stockout/records',
						datatype : 'json',
						mtype : 'POST',
						
						colNames : [ 'Stock In Id', 'Sales Order No', 'Party',
								'Item Id', 'Item Code', 'Item Description',
								'Work Order No', 'Bundle Id', 'StockOut Qty',
								'Units', 'Weight(Kg)', 'Packing No',
								'Bag Weight', 'Actions' ],
						colModel : [

						{
							name : 'stockOutId',
							index : 'stockOutId',
							width : 5,
							viewable : false,
							hidden : true
						}, {
							name : 'orderId',
							index : 'orderId',
							width : 70
						}, {
							name : 'customerName',
							index : 'customerName',
							width : 90
						},

						{
							name : 'itemId',
							index : 'itemId',
							width : 5,
							hidden : true
						}, {
							name : 'itemCode',
							index : 'itemCode',
							width : 160
						}, {
							name : 'itemDescription',
							index : 'itemDescription',
							width : 260
						}, {
							name : 'workOrderNo',
							index : 'workOrderNo',
							width : 70
						}, {
							name : 'bundleId',
							index : 'bundleId',
							width : 40
						}, {
							name : 'stockOutQty',
							index : 'stockOutQty',
							width : 40
						}, {
							name : 'units',
							index : 'units',
							width : 20
						}, {
							name : 'weight',
							index : 'weight',
							width : 40
						}, {
							name : 'packingSlipNo',
							index : 'packingSlipNo',
							width : 40
						}, {
							name : 'bagWeight',
							index : 'bagWeight',
							width : 40
						}, {
							name : 'act',
							index : 'act',
							width : 30,sortable : false,editable : false
						}

						],
						postData : {},
						autowidth : true,
						height : 150,
						rowNum : 100,
						rowList : [ 5, 10, 20, 30, 40, 100 ],
						height : 300,
						rownumbers : false,
						pager : '#stockOutPager',
						sortname : 'stockOutId',
						viewrecords : true,
						sortorder : "desc",
						caption : "Item List For Confirming Stock Out",
						emptyrecords : "Empty records",
						loadonce : false,
						footerrow : true,
						loadComplete : function() {
						},
						jsonReader : {
							root : "rows",
							page : "page",
							total : "total",
							records : "records",
							repeatitems : false,
							cell : "cell",
							id : "stockOutId"
						},
						onSelectRow : updateIdsOfStockOutSelectedRows,
						onSelectAll : function(aRowids, status) {
							updateIdsOfStockOutAllSelectedRows(aRowids, status);
						},
						loadComplete : function() {
							var $this = $(this), i, count;
							for (i = 0, count = idsOfSelectedRows.length; i < count; i++) {
								$this.jqGrid('setSelection',
										idsOfSelectedRows[i], false);
							}
						},
						gridComplete : function() {

							var stockOutQty = $('#stockOutGrid').jqGrid(
									'getCol', 'stockOutQty', false, 'sum');
							var totalStockOutQty = Math
									.round(parseFloat(stockOutQty) * 100) / 100;
							$('#stockOutGrid').jqGrid('footerData', 'set', {
								ID : 'Total:',
								stockOutQty : totalStockOutQty
							});

							var weight = $('#stockOutGrid').jqGrid('getCol',
									'weight', false, 'sum');
							var totalWeight = Math
									.round(parseFloat(weight) * 100) / 100;
							$('#stockOutGrid').jqGrid('footerData', 'set', {
								ID : 'Total:',
								weight : totalWeight
							});

							var bagWeight = $('#stockOutGrid').jqGrid('getCol',
									'bagWeight', false, 'sum');
							var totalBagWeight;
							if(isNaN(bagWeight)){
								totalBagWeight=0;
							}else{
								 totalBagWeight = Math
									.round(parseFloat(bagWeight) * 100) / 100;
							
							}
								$('#stockOutGrid').jqGrid('footerData', 'set', {
								ID : 'Total:',
								bagWeight : totalBagWeight
							});

							var ids = $("#stockOutGrid").jqGrid('getDataIDs');
							for ( var i = 0; i < ids.length; i++) {
								var cl = ids[i];
								de = "<input style='height:22px; width:30px;' type='button' value='Del' id='delRow"
										+ cl
										+ "' onclick=\"delRow('"
										+ cl
										+ "');\" />";
								$("#stockOutGrid").jqGrid('setRowData', ids[i],
										{
											act : de
										});
							}
						},
						beforeSelectRow : function(rowid, e) {
							var $myGrid = $(this), i = $.jgrid.getCellIndex($(
									e.target).closest('td')[0]), cm = $myGrid
									.jqGrid('getGridParam', 'colModel');
							return (cm[i].name === 'cb');
						}
					// editurl : "stockin/crud",
					});
	jQuery("#stockOutGrid").jqGrid('navGrid', '#stockOutPager', {
		view : true,
		del : false,
		add : false,
		edit : false,
		search : false
	});

});

function editRow(id) {
	restoreRow(lastSelected);
	lastSelected = id;
	$('#storeRegisterGrid').jqGrid('editRow', id, {
		"keys" : true,
		"oneditfunc" : hideActButtons,
		aftersavefunc : function(savedId, response) {
			showActButtons(savedId);
		},
		afterrestorefunc : showActButtons
	});
}

function delRow(id) {

}

function saveRow(id) {
	$('#storeRegisterGrid').saveRow(id, {
		aftersavefunc : function(id, response) {
			showActButtons(id);
		}
	});
}

function restoreRow(id) {
	$('#storeRegisterGrid').jqGrid('restoreRow', id, {
		afterrestorefunc : showActButtons
	});
}

/*
 * Hides the Edit and Del Row Buttons on jqGrid and activates the Save and
 * restore(cancel) button
 * 
 */
function hideActButtons(id) {
	$('#editRow' + id).hide();
	$('#delRow' + id).hide();
	$('#saveRow' + id).show();
	$('#restoreRow' + id).show();
}

/*
 * Shows the Edit and Del Row Buttons on jqGrid and hides the Save and
 * restore(cancel) button
 * 
 */
function showActButtons(id) {
	$('#editRow' + id).show();
	$('#delRow' + id).show();
	$('#saveRow' + id).hide();
	$('#restoreRow' + id).hide();
	lastSelected = null;
}

$("#processTypeSelect").chosen().change(
		function() {
			
				var processType = $('#processTypeSelect').val();
				$.ajax({
					type : 'POST',
					url : 'storeRegister/getWorkOrders',
					data : {"processType" : processType},
					success : function(response) {
						$('#workOrderNoSelect').empty();
						if (response.length == 0) {

							alert("There is no Work Order for selected process type");
						}
						if (response.length != 0) {
							for ( var i = 0; i < response.length; i++) {
								$('#workOrderNoSelect').append('<option selected="selected">'+ "" + '</option>');
								$('#workOrderNoSelect').append('<option >' + response[i]+ '</option>');
								$('#workOrderNoSelect').trigger('liszt:updated');
							}
						} else {
							$('#workOrderNoSelect').empty();
						}

					}
				});
			
});

$("#partySelect").chosen().change(function() {

	var customerId = $('#partySelect').val();
	if(customerId != "" && customerId!=null)
	{
	$('#salesOrderSelect').children().remove();
	$('#salesOrderSelect').val('').trigger('liszt:updated');
	$.ajax({type:'POST', 
		url: 'storeRegister/getSalesOrders',
		data : {"customerId" : customerId},
		success: function(response) {
			
			if (response.length == 0) {

				alert("There is no Sales Order for the selected customer");
			}

			if(response.length != 0){
				for(var i=0;i< response.length;i++){
					$('#salesOrderSelect').append('<option selected="selected">'+ "" + '</option>');
					$('#salesOrderSelect').append('<option >' + response[i]+ '</option>');
					$('#salesOrderSelect').trigger('liszt:updated');
				}
			}
	}});
	}

});


$('#searchSoItems').click(function() {
	if (document.getElementById('numberOfCopperStrands').value != "") {
		var pattern = /^[0-9]\d*$/;
		if (!pattern.test($("#numberOfCopperStrands").val())) {
			alert("Enter valid Copper Strands");
			document.getElementById('numberOfCopperStrands').value = "";

		} else {
			searchFunction();
		}
	}
	
	
	else if (document.getElementById('layLength').value != "") {
		var pattern = /^[0-9]\d*$/;
		if (!pattern.test($("#layLength").val())) {
			alert("Enter valid Lay Length");
			document.getElementById('layLength').value = "";

		} else {
			searchFunction();
		}
	}
	else {
		searchFunction();
	}

});

function searchFunction() {
	var customerName = document.getElementById('partySelect').value;
	var workOrderNo= document.getElementById('workOrderNoSelect').value;
	var orderId = document.getElementById('salesOrderSelect').value;
	var itemCode = document.getElementById('itemIdSelect').value;
	var noOfCuStrand = document.getElementById('numberOfCopperStrands').value;
	var layLength = document.getElementById('layLength').value;
	var layType = document.getElementById('layType').value;
	var od = document.getElementById('outerDiameter').value;
	var searchOptions1 = {
		"groupOp" : "AND",
		"rules" : [ {"field" : "customerName","op" : "eq","data" : customerName}, 
			        {"field" : "orderId","op" : "eq","data" : orderId}, 
			        {"field" : "itemCode","op" : "eq","data" : itemCode},
		            {"field" : "copperkey","op" : "eq","data" : $("#cuDiameterSelect").val()}, 
		            {"field" : "mainColour","op" : "eq","data" : $("#mainColorSelect").val()}, 
		            {"field" : "innerColor","op" : "eq","data" : $("#innerColorSelect").val()}, 
		            {"field" : "productKey","op" : "eq","data" : $("#productTypeSelect").val()}, 
		            {"field" : "numberOfCopperStrands","op" : "eq","data" : noOfCuStrand}, 
		            {"field" : "layType","op" : "eq","data" : layType}, 
		            {"field" : "layLength","op" : "eq",	"data" : layLength}, 
		            {"field" : "cableStdKey","op" : "eq","data" : $("#cableStdPvcSelect").val()},
		            {"field" : "outerDiameter","op" : "eq","data" : od},
		            {"field" : "workOrderNo","op" : "eq","data" : workOrderNo}
		]
	};
	performSearch(searchOptions1, "#storeRegisterGrid");

}

function performSearch(searchOptions, gridId) {
	// Set Enity object as post data
	$(gridId).setGridParam({
		postData : {
			searchObject : JSON.stringify(searchOptions)
		}
	});
	// $(gridId).setGridParam({postData: {searchObject:searchOptions}});
	// Reload the grid with given search criteria
	$(gridId).trigger("reloadGrid");
}
$('#clearSearchBox').click(function() {
	if ($("#salesOrderSelect").val() != "") {
		document.getElementById('salesOrderSelect').value = "";
		$('#salesOrderSelect').trigger('liszt:updated');
	}
	if ($("#partySelect").val() != "") {
		document.getElementById('partySelect').value = "";
		$('#partySelect').trigger('liszt:updated');
	}
	if ($("#itemIdSelect").val() != "") {
		document.getElementById('itemIdSelect').value = "";
		$('#itemIdSelect').trigger('liszt:updated');
	}

	if ($("#cuDiameterSelect").val() != "") {
		document.getElementById('cuDiameterSelect').value = "";
		$('#cuDiameterSelect').trigger('liszt:updated');
	}
	if ($("#mainColorSelect").val() != "") {
		document.getElementById('mainColorSelect').value = "";
		$('#mainColorSelect').trigger('liszt:updated');
	}
	if ($("#innerColorSelect").val() != "") {
		document.getElementById('innerColorSelect').value = "";
		$('#innerColorSelect').trigger('liszt:updated');
	}
	if ($("#productTypeSelect").val() != "") {
		document.getElementById('productTypeSelect').value = "";
		$('#productTypeSelect').trigger('liszt:updated');
	}
	if ($("#cableStdPvcSelect").val() != "") {
		document.getElementById('cableStdPvcSelect').value = "";
		$('#cableStdPvcSelect').trigger('liszt:updated');
	}
	
	if ($("#processTypeSelect").val() != "") {
		document.getElementById('processTypeSelect').value = "";
		$('#processTypeSelect').trigger('liszt:updated');
	}

	if ($("#workOrderNoSelect").val() != "") {
		document.getElementById('workOrderNoSelect').value = "";
		$('#workOrderNoSelect').trigger('liszt:updated');
	}

	if (document.getElementById('numberOfCopperStrands').value != "")
		document.getElementById('numberOfCopperStrands').value = "";

	if (document.getElementById('layLength').value != "")
		document.getElementById('layLength').value = "";

	if (document.getElementById('layType').value != "")
		document.getElementById('layType').value = "";

	if (document.getElementById('outerDiameter').value != "")
		document.getElementById('outerDiameter').value = "";

	jQuery("#storeRegisterGrid").setGridParam({datatype : 'json'});
	jQuery("#storeRegisterGrid").setGridParam({postData : {searchObject : "allSearch"}});
	jQuery("#storeRegisterGrid").trigger('reloadGrid');
	
	$('#salesOrderSelect').children().remove();
	
	 $.ajax({type:'POST',
		  url: 'pendingSoItemReport/fetchSalesOrder',

		  success: function(response) {
				if(response.length != 0){
					for(var i=0;i< response.length;i++){
						$('#salesOrderSelect').append('<option selected="selected">'+ "" + '</option>');
						$('#salesOrderSelect').append('<option >' + response[i]+ '</option>');
						$('#salesOrderSelect').trigger('liszt:updated');
					}
				}			
	 }
	 });
	

});

function stockOutPopUp(id) {
	
	$.ajax({
		type : 'POST',
		url : 'stockout/storeStockOut' + encodeURIComponent(id),
		success : function(response) {
			if (response != null) {
				if (response == "Exist") {
					alert("Selected Item already added to stock out List");
				}
				if (response == "Created") {
					alert("Selected Item  added to stock out List");
				}
			}
		}
	});

}

idsOfSelectedRows = [ "8", "9", "10" ];
var $StoreRegGrid = $("#storeRegisterGrid"), idsOfSelectedRows = [], updateIdsOfSelectedRows = function(
		id, isSelected) {
	var grid = jQuery('#storeRegisterGrid');
	var packingSlipNo = grid.jqGrid('getCell', id, 'packingSlipNo');
	var soNo = document.getElementById('salesOrderSelect').value;
	var grid = jQuery('#storeRegisterGrid');
	var status = grid.jqGrid('getCell', id, 'status');
    var qcStatus=grid.jqGrid('getCell', id, 'qcStatus');
	if ((packingSlipNo == null || packingSlipNo == "") && status == "Approved"
			&& soNo != "" && soNo != null && qcStatus=="Approved") {
		var index = $.inArray(id, idsOfSelectedRows);
		if (!isSelected && index >= 0) {
			idsOfSelectedRows.splice(index, 1); // remove id from the list
		} else if (index < 0) {
			idsOfSelectedRows.push(id);
		}
	} else {

		if (document.getElementById('salesOrderSelect').value == ""
				|| document.getElementById('salesOrderSelect').value == null) {
			alert("Select Sales Order");
			$("#storeRegisterGrid").resetSelection(id);
		} else {
			if (packingSlipNo != null && packingSlipNo != "") {
				alert("Item has been already selected for stock out");
				$("#storeRegisterGrid").resetSelection(id);
			}
			if (status != "Approved") {
				alert("Approved sales order can only be stocked out");
				$("#storeRegisterGrid").resetSelection(id);

			}
			if (qcStatus != "Approved") {
				alert("QC Approved Items can only be stocked out");
				$("#storeRegisterGrid").resetSelection(id);

			}
		}

	}

};
updateIdsOfAllSelectedRows = function(aRowids, isSelected) {
	var counter = 0;
	var salesNo = 0;
	var salesStatus = 0;
	var qcStatusCounter=0;
	var grid = jQuery('#storeRegisterGrid');
	for (i = 0, count = aRowids.length; i < count; i++) {
		id = aRowids[i];
		var packingNo = grid.jqGrid('getCell', id, 'packingSlipNo');
		var status = grid.jqGrid('getCell', id, 'status');
		var qcStatus=grid.jqGrid('getCell', id, 'qcStatus');
		var so = document.getElementById('salesOrderSelect').value;
		if ((packingNo == null || packingNo == "") && so != null && so != ""
				&& status == "Approved" && qcStatus=="Approved") {
			var index = $.inArray(id, idsOfSelectedRows);
			if (!isSelected && index >= 0) {
				idsOfSelectedRows.splice(index, 1); // remove id from the list
			} else if (index < 0) {
				idsOfSelectedRows.push(id);
			}
		} else {
			if (packingNo != null && packingNo != "") {
				counter++;
			}
			if (so == null || so == "") {
				salesNo++;
			}
			if (status != "Approved") {
				salesStatus++;
			}
			if (qcStatus != "Approved") {
				qcStatusCounter++;
			}

		}
	}// for loop
	if (salesNo > 0) {
		alert("Select Sales Order ");
		$("#storeRegisterGrid").resetSelection();
	} else if (salesStatus > 0) {
		alert("Select Items of approved sales order for stock out ");
		$("#storeRegisterGrid").resetSelection();

	} else if (counter > 0) {
		alert("Select Items which do not have bag no for stock out ");
		$("#storeRegisterGrid").resetSelection();
	} else if (qcStatusCounter > 0) {
		alert("Select QC approved items for stock out ");
		$("#storeRegisterGrid").resetSelection();
	}

};

function stockOutFn() {
	var bagWeight = document.getElementById('bagWeight').value;
	var validateStockOut = false;
	validateStockOut = validateStockOutFn();
	if (validateStockOut == true) {
		$.ajax({
			type : 'POST',
			url : 'stockout/storeStockOut',
			data : {
				"idsOfSelectedRows" : idsOfSelectedRows,
				"bagNo" : document.getElementById('packingNo').value,
				"bagWeight" : bagWeight
			},
			   beforeSend: function(){
		           $("#loading").dialog('open').html("<p>Processing Request...</p>");
		        },
			success : function(response) {
				
				jQuery("#stockOutGrid").trigger('reloadGrid');
				

				jQuery("#storeRegisterGrid").trigger('reloadGrid');
				alert("Selected Items are added to stock out list");
				for ( var k = 0; k < idsOfSelectedRows.length; k++) {
					jQuery("#storeRegisterGrid").resetSelection(
							idsOfSelectedRows[k]);
				}
				idsOfSelectedRows = [];
				

			},
			complete: function() {
	        	 $("#loading").dialog('close');
	        },
		  error: function() {
		        alert("error!");
		    }
		});
	}

}
function validateStockOutFn() {
	var soNo = document.getElementById('salesOrderSelect').value;
	var packNo = document.getElementById('packingNo').value;
	var bagWt = document.getElementById('bagWeight').value;
	var patroon = /^[1-9]\d*$/;
	var wtPattern = /^[+]?([0-9]+(?:[\.][0-9]*)?|\.[0-9]+)$/;
	if (soNo == "" || soNo == null) {
		alert("Select sales Order No");
		$("#storeRegisterGrid").resetSelection();
		return false;
	} else if (document.getElementById('packingNo').value == ""
			|| document.getElementById('packingNo').value == null) {
		alert("Enter packing bag no");
		return false;
	}

	else if (document.getElementById('bagWeight').value == ""
			|| document.getElementById('bagWeight').value == null) {
		alert("Enter Bag weight");
		return false;
	}

	else if (idsOfSelectedRows.length == 0) {
		alert("Select items for stock out");
		return false;
	} else if (!patroon.test(packNo)) {
		alert("Enter valid bag No");
		document.getElementById('bagNo').value = "";
		return false;

	} else if (!wtPattern.test(bagWt)) {
		alert("Enter valid bag weight");
		document.getElementById('bagWeight').value = "";
		return false;

	} else
		return true;
}

///////////////////////

idsOfStockOutSelectedRows = [ "8", "9", "10" ];
var $StockOutGrid = $("#stockOutGrid"), idsOfStockOutSelectedRows = [], updateIdsOfStockOutSelectedRows = function(
		id, isSelected) {
	var index = $.inArray(id, idsOfStockOutSelectedRows);
	if (!isSelected && index >= 0) {
		idsOfStockOutSelectedRows.splice(index, 1); // remove id from the list
	} else if (index < 0) {
		idsOfStockOutSelectedRows.push(id);
	}
};
updateIdsOfStockOutAllSelectedRows = function(aRowids, isSelected) {
	for (i = 0, count = aRowids.length; i < count; i++) {
		id = aRowids[i];
		var index = $.inArray(id, idsOfStockOutSelectedRows);
		if (!isSelected && index >= 0) {
			idsOfStockOutSelectedRows.splice(index, 1); // remove id from the
														// list
		} else if (index < 0) {
			idsOfStockOutSelectedRows.push(id);
		}
	}
};

function confirmStockOutFn() {
	if (idsOfStockOutSelectedRows.length > 0) {
		if (confirm("Do you want to confirm the stock Out of selected items")) {
			$.ajax({
				type : 'POST',
				url : 'stockout/crud',
				data : {
					'idsOfSelectedRows' : idsOfStockOutSelectedRows
				},
				success : function(response) {
					alert("Selected Items are stocked Out");
					jQuery("#stockOutGrid").setGridParam({
						datatype : 'json'
					});
					jQuery("#stockOutGrid").setGridParam({
						url : 'stockout/records'
					});
					jQuery("#stockOutGrid").trigger('reloadGrid');

				}
			});
		}

	}
}

function delRow(id) {
	for ( var k = 0; k < idsOfSelectedRows.length; k++) {
		jQuery("#storeRegisterGrid").resetSelection(idsOfSelectedRows[k]);
	}
	if (confirm("Do you want to delete this items")) {
		$.ajax({
			type : 'POST',
			url : 'stockout/delete',
			data : {
				'id' : id
			},
			success : function(response) {
				jQuery("#stockOutGrid").setGridParam({
					datatype : 'json'
				});
				jQuery("#stockOutGrid").setGridParam({
					url : 'stockout/records'
				});
				jQuery("#stockOutGrid").trigger('reloadGrid');

				alert("Selected Item deleted from stock out list");

				document.getElementById('salesOrderSelect').value = "";
				$('#salesOrderSelect').trigger('liszt:updated');
				jQuery("#storeRegisterGrid").setGridParam({
					datatype : 'json'
				});
				jQuery("#storeRegisterGrid").setGridParam({
					postData : {
						searchObject : "allSearch"
					}
				});
				jQuery("#storeRegisterGrid").trigger('reloadGrid');
			}
		});

	}
}

$("#salesOrderSelect").chosen().change( function() {
	  for(var k=0;k<idsOfSelectedRows.length;k++){
		  jQuery("#storeRegisterGrid").resetSelection(idsOfSelectedRows[k]);
	  }
	 idsOfSelectedRows = [];
	 searchFunction();

});

function openChangeLabelPage(storeRegId) {
	$("#dialog-modal").dialog({
		width : 600,
		height : 400
	});
	document.getElementById('storeRegisterId').value = storeRegId;
	$("#customerSelect").chosen().change(
			function() {
				var customerId= $("#customerSelect").val();
				$('#orderIdSelect').children().remove();
				$('#orderIdSelect').val('').trigger('liszt:updated');
				$.ajax({
					type : 'POST',
					url : 'storeRegister/fetchSalesOrder',
					data : {"storeRegId" : storeRegId,"customerId":customerId},
					success : function(response) {
						$('#orderIdSelect').empty();
						if (response.length != 0) {
							for ( var i = 0; i < response.length; i++) {
								$('#orderIdSelect').append('<option selected="selected">' + ""+ '</option>');
								$('#orderIdSelect').append('<option >' + response[i]+ '</option>');
								$('#orderIdSelect').trigger('liszt:updated');
							}
						} else {
							$('#salesOrderSelect').empty();
						}
					}
				});
			});
}

$('#changeBtn')
.click(
		function() {
			var newSoNo = $("#orderIdSelect").val();
			var storeRegId=document.getElementById('storeRegisterId').value;
			
			 var grid = jQuery('#storeRegisterGrid'); 
           	  var oldSoNo=grid.jqGrid ('getCell', storeRegId, 'orderId');
			
			if (newSoNo != null && newSoNo != "" && storeRegId != null	&& storeRegId != "") {
				if(newSoNo==oldSoNo){
					alert("No change in Sales Order");
				}else
				if (confirm("Do you want to change the labels?")) {
						$
								.ajax({
									type : 'POST',
									url : 'storeRegister/changeLabel',
									data : {"newSoNo" : newSoNo,"storeRegId" : storeRegId},
									success : function(response) {
										alert("Label has been changed for the item ");
									     jQuery("#storeRegisterGrid").setGridParam({datatype:'json'}); 
            							 jQuery("#storeRegisterGrid").setGridParam({ url: 'storeRegister/records'});
            							 jQuery("#storeRegisterGrid").trigger('reloadGrid');
           				
										$('#dialog-modal').dialog('close');
					
									}
								});
					}

				$('#dialog-modal').dialog('close');
			}
		});

$('#cancelBtn').click(function() {
	$('#dialog-modal').dialog('close');
});
