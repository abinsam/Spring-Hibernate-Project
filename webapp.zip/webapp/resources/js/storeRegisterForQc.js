var lastSelected;
var stockQtyValid=true;
var weightValid=true;

$(function() {

	$("#orderIdSelect").chosen({no_results_text : "No results matched"});
	$("#partySelect").chosen({no_results_text : "No results matched"});
	$("#itemIdSelect").chosen({no_results_text : "No results matched"});
	$("#salesOrderSelect").chosen({no_results_text : "No results matched"});
	$("#strandsSelect").chosen({no_results_text : "No results matched"});
	$("#cuDiameterSelect").chosen({no_results_text : "No results matched"});
	$("#mainColorSelect").chosen({no_results_text : "No results matched"});
	$("#innerColorSelect").chosen({no_results_text : "No results matched"});
	$("#productTypeSelect").chosen({no_results_text : "No results matched"});
	$("#cableStdPvcSelect").chosen({no_results_text : "No results matched"});
	$("#processTypeSelect").chosen({no_results_text : "No results matched"});
	$("#qcStatusSelect").chosen({no_results_text : "No results matched"});
	$("#workOrderNoSelect").chosen({no_results_text : "No results matched"});
	$("#deliveryChallanPartySelect").chosen({no_results_text : "No results matched"});
	$("#deleiveryChallanOrderSelect").chosen({no_results_text : "No results matched"});

	$.ajax({type:'POST', 
		url: 'storeRegisterForQc/fetchStoreItems',
		success: function(response) {
			if(response.length != 0){
				for(var i=0;i< response.length;i++){
					$('#itemIdSelect').append('<option selected="selected">'+ "" + '</option>');
					$('#itemIdSelect').append('<option >' + response[i]+ '</option>');
					$('#itemIdSelect').trigger('liszt:updated');
				}
			}
	}});
	
	$("#storeRegisterGrid").jqGrid(
					{
						url : 'storeRegisterForQc/records',
						datatype : 'json',
						mtype : 'POST',
						multiselect : true,
						colNames : [ 'Store Reg Id', 'Store', 'Sales Order No',
								'Status', 'PartyHidden','Party', 'Item Id', 'Item Code',
								'Item Description', 'Work Order No',
								'Bundle Id', 'Stock Qty(mts)', 'Units',
								'Weight(Kg)','QC status','Change Label', 'Bag No',
								'Bag Weight','Action' ],
						colModel : [ {name : 'storeRegisterId',index : 'storeRegisterId',width : 5,viewable : false,hidden : true}, 
						             {name : 'storeAddress',index : 'storeAddress',width : 5,viewable : false,hidden : true}, 
						             {name : 'orderId',index : 'orderId',width : 60}, 
						             {name : 'status',index : 'status',width : 70}, 
						             {name : 'customerName',index : 'customerName',	width : 90,hidden : true},
						             {name : 'customerCode',index : 'customerCode',	width : 70},
						             {name : 'itemId',index : 'itemId',width : 5,hidden : true}, 
						             {name : 'itemCode',index : 'itemCode',width : 160}, 
						             {name : 'itemDescription',index : 'itemDescription',width : 210}, 
						             {name : 'workOrderNo',index : 'workOrderNo',width : 70}, 
						             {name : 'bundleId',index : 'bundleId',width : 40}, 
						             {name : 'stockQty',index : 'stockQty',	width : 70,editable:true,editoptions:{
						                  dataInit: function(element) {
				                              $(element).keyup(function(){
				                                  var val1 = element.value;
				                                  var num = new Number(val1);
				                                  if(isNaN(num))
				                                  {
				                                	  alert("Please enter valid Stock Qty");
				                                	  stockQtyValid=false;
				                                 }
				                                  else
				                                	  stockQtyValid=true;
				                                
				                              });
						                  }
				                          }}, 
						             {name : 'unit',index : 'unit',width : 10,hidden : true}, 
						             {name : 'weight',index : 'weight',width : 60,editable:true,editoptions:{
						                 dataInit: function(element) {
				                              $(element).keyup(function(){
				                                  var val1 = element.value;
				                                  var num = new Number(val1);
				                                  if(isNaN(num))
				                                  {
				                                	  alert("Please enter valid weight");
				                                	  weightValid=false;
				                                 }
				                                  else
				                                	 weightValid=true;
				                                
				                              });
						                 }
				                          }}, 
				                     {name : 'qcStatus',index : 'qcStatus',width : 70}, 
						             {name : 'changeLabelLink',index : 'changeLabelLink',width : 100,editable : false,hidden : true}, 
						             {name : 'packingSlipNo',index : 'packingSlipNo',width : 60,viewable : false,hidden : true}, 
						             {name : 'bagWeight',index : 'bagWeight',width : 60,viewable : false,hidden : true},
						             {name : 'act',index:'act', width:60,sortable:false, viewable:false}
						],
						postData : {},
						rowNum : 100,
						rowList : [ 5, 10, 20, 30, 40, 100, 500, 1000, 2000 ],
						height : 300,
						autowidth : true,
						rownumbers : false,
						pager : '#storeregisterpager',
						sortname : 'storeRegisterId',
						viewrecords : true,
						sortorder : "desc",
						caption : "Store Registry For QC Approval",
						emptyrecords : "Empty records",
						loadonce : false,
						footerrow : true,
						loadComplete : function() {
						},
						jsonReader : {
							root : "rows",
							page : "page",
							total : "total",
							records : "records",
							repeatitems : false,
							cell : "cell",
							id : "storeRegisterId"
						},
						onSelectRow : function(aRowids, status){
							updateIdsOfSelectedRows(aRowids, status);
						},
						onSelectAll : function(aRowids, status) {
							updateIdsOfAllSelectedRows(aRowids, status);
						},
						loadComplete : function() {
							var $this = $(this), i, count;
							for (i = 0, count = idsOfSelectedRows.length; i < count; i++) {
								$this.jqGrid('setSelection',
										idsOfSelectedRows[i], false);
							}
						},
						gridComplete : function() {

							var stockQty = $('#storeRegisterGrid').jqGrid('getCol', 'stockQty', false, 'sum');
							var totalStockQty = Math.round(parseFloat(stockQty) * 100) / 100;
							$('#storeRegisterGrid').jqGrid('footerData', 'set',	{ID : 'Total:',stockQty : totalStockQty});

							var weight = $('#storeRegisterGrid').jqGrid('getCol', 'weight', false, 'sum');
							var totalWeight = Math.round(parseFloat(weight) * 100) / 100;
							$('#storeRegisterGrid').jqGrid('footerData', 'set',{ID : 'Total:',weight : totalWeight});

							var weight = $('#storeRegisterGrid').jqGrid('getCol', 'weight', false, 'sum');
							var totalWeight = Math.round(parseFloat(weight) * 100) / 100;
							$('#storeRegisterGrid').jqGrid('footerData', 'set',{ID : 'Total:',weight : totalWeight});

							var ids = jQuery("#storeRegisterGrid").jqGrid('getDataIDs');
							for ( var i = 0; i < ids.length; i++) {
								var cl = ids[i];
								be = "<input style='height:22px; width:35px;' type='button' value='Edit' id='editRow"+cl+"' onclick=\"editRow('"+ cl + "');\" />";
	        					se = "<input style='height:22px; width: 35px;' type='button' value='Save' hidden='hidden' id='saveRow"+cl+"' onclick=\"saveRow('"+ cl + "');\" />";
	        					ce = "<input style='height:22px;width:39px;' type='button' value='Cancel' hidden='hidden' id='restoreRow"+cl+"' onclick=\"restoreRow('"+ cl + "');\" />";
	            		
								clLink = "<button class='btn btn-mini' id='changeLabelLink"
										+ cl
										+ "' "
										+ "onclick=\"openChangeLabelPage('"
										+ cl + "');\" >Change Label </button>";
								$("#storeRegisterGrid").jqGrid('setRowData',
										ids[i], {
								         	act : be + se + ce,
											changeLabelLink : clLink
										});
								if ($("#storeRegisterGrid").getCell(cl,"status") == "Approved") {
									$("#storeRegisterGrid").jqGrid(
											'setRowData', ids[i], false, {
												color : 'black',
												weightfont : 'bold',
												background : '#89D879'
											});
									$("#storeRegisterGrid").setColProp('stockQty',{editable:false});
									$("#storeRegisterGrid").setColProp('weight',{editable:false});
								}
								if ($("#storeRegisterGrid").getCell(cl,"qcStatus") == "Pending") {
									$("#storeRegisterGrid").jqGrid(
											'setRowData', ids[i], false, {
												color : 'black',
												weightfont : 'bold',
												background : '#FB3232'
											});
									$("#storeRegisterGrid").setColProp('stockQty',{editable:true});
									$("#storeRegisterGrid").setColProp('weight',{editable:true});
								}
							}
						},

						editurl : "storeRegisterForQc/crud"

					});
jQuery("#storeRegisterGrid").jqGrid('navGrid', '#storeregisterpager', {view : false,del : false,add : false,edit : false,search : false});


$("#processTypeSelect").chosen().change(
					function() {
						
						var processType = $('#processTypeSelect').val();
						$('#workOrderNoSelect').children().remove();
			
						$('#workOrderNoSelect').val('').trigger('liszt:updated');
						$.ajax({
									type : 'POST',
									url : 'storeRegisterForQc/getWorkOrders/'+ encodeURIComponent(processType),
									success : function(response) {
										$('#workOrderNoSelect').empty();
										if (response.length == 0) {
											alert("There is no work order created for the selected process");
										}
										if (response.length != 0) {
											for ( var i = 0; i < response.length; i++) {
												$('#workOrderNoSelect').append('<option selected="selected">'+ "" + '</option>');
												$('#workOrderNoSelect').append('<option >' + response[i]+ '</option>');
												$('#workOrderNoSelect').trigger('liszt:updated');
											}
										} else {
											$('#workOrderNoSelect').empty();
										}

									}
								});

});

	function performSearch(searchOptions, gridId) {
		$(gridId).setGridParam({
			postData : {
				searchObject : JSON.stringify(searchOptions)
			}
		});

		$(gridId).trigger("reloadGrid");
	}

	idsOfSelectedRows = [ "3", "4", "5" ];
	/*var storeRegisterGrid =*/ $("#storeRegisterGrid"), idsOfSelectedRows = [], updateIdsOfSelectedRows = function(
			id, isSelected) {
		
		var index = $.inArray(id, idsOfSelectedRows);
		
		if (!isSelected && index >= 0) {
			idsOfSelectedRows.splice(index, 1); // remove id from the list
		} else if (index < 0) {
			idsOfSelectedRows.push(id);
		}
	};
	updateIdsOfAllSelectedRows = function(aRowids, isSelected) {
		for (i = 0, count = aRowids.length; i < count; i++) {
			id = aRowids[i];
			var index = $.inArray(id, idsOfSelectedRows);
			if (!isSelected && index >= 0) {
				idsOfSelectedRows.splice(index, 1); // remove id from the list
			} else if (index < 0) {
				idsOfSelectedRows.push(id);
			}
		}
	};
	$('#approve').click(function() {
		var remarks = $('#remarks').val();
		var status="Approved";
		
		if(remarks!=null && remarks!="" && idsOfSelectedRows.length!=0){
			if(confirm("Do you want to Submit the Items for Approval?")){
		$.ajax({
			type : 'POST',
			url : 'storeRegisterForQc/approveOrRejectQC',
			data : {
				'remarks' : remarks,
				'status':status,
				'idsOfSelectedRows' : idsOfSelectedRows
				
			},
			success : function(response) {
				
				idsOfSelectedRows=[];
				 jQuery("#storeRegisterGrid").setGridParam({datatype:'json'}); 
				 jQuery("#storeRegisterGrid").setGridParam({ url: 'storeRegisterForQc/records'});
				 jQuery("#storeRegisterGrid").trigger('reloadGrid');
				 alert("Selected Items Approved By QC");
				 document.getElementById('remarks').value = "";
			}
		});
		}
		}
 if(remarks==null || remarks==""){
			
			alert("Please Enter Remarks");
		}
 if(idsOfSelectedRows.length==0){
			
			alert("Please select items");
		}
	});
	$('#pending').click(function() {
		var remarks = $('#remarks').val();
		var status="Pending";
		
		if(remarks!=null && remarks!="" && idsOfSelectedRows.length!=0){
			if(confirm("Do you want reset the QC status to Pending?")){
		$.ajax({
			type : 'POST',
			url : 'storeRegisterForQc/approveOrRejectQC',
			data : {
				'remarks' : remarks,
				'status':status,
				'idsOfSelectedRows' : idsOfSelectedRows
				
			},
			success : function(response) {
				
				idsOfSelectedRows=[];
				 jQuery("#storeRegisterGrid").setGridParam({datatype:'json'}); 
				 jQuery("#storeRegisterGrid").setGridParam({ url: 'storeRegisterForQc/records'});
				 jQuery("#storeRegisterGrid").trigger('reloadGrid');
				 alert("QC status has been reverted to Pending status for the selected items");
				 document.getElementById('remarks').value = "";
			}
		});
		}
		}
 if(remarks==null || remarks==""){
			
			alert("Please Enter Remarks");
		}
 if(idsOfSelectedRows.length==0){
			
			alert("Please select items");
		}
	});
	$('#sendToScrap').click(function() {
		var remarks = $('#remarks').val();
		var status="Scrap";
		
		if(remarks!=null && remarks!="" && idsOfSelectedRows.length!=0){
			if(confirm("Do you want to Send the Items to Scrap?")){
		$.ajax({
			type : 'POST',
			url : 'storeRegisterForQc/approveOrRejectQC',
			data : {
				'remarks' : remarks,
				'status':status,
				'idsOfSelectedRows' : idsOfSelectedRows
				
			},
			success : function(response) {
				
				idsOfSelectedRows=[];
				 jQuery("#storeRegisterGrid").setGridParam({datatype:'json'}); 
				 jQuery("#storeRegisterGrid").setGridParam({ url: 'storeRegisterForQc/records'});
				 jQuery("#storeRegisterGrid").trigger('reloadGrid');
				 alert("Selected Items Successfully Sent For Scrap");
				 document.getElementById('remarks').value = "";
			}
		});
		}
		}
		 if(remarks==null || remarks==""){
			
			alert("Please Enter Remarks");
		}
 if(idsOfSelectedRows.length==0){
			
			alert("Please select items");
		}
	});
	$('#sendToRework').click(function() {
		var remarks = $('#remarks').val();
		var status="Rework";
		
		if(remarks!=null && remarks!="" && idsOfSelectedRows.length!=0){
			if(confirm("Do you want to Submit the Items For Rework?")){
		$.ajax({
			type : 'POST',
			url : 'storeRegisterForQc/approveOrRejectQC',
			data : {
				'remarks' : remarks,
				'status':status,
				'idsOfSelectedRows' : idsOfSelectedRows
				
			},
			success : function(response) {
				
				idsOfSelectedRows=[];
				 jQuery("#storeRegisterGrid").setGridParam({datatype:'json'}); 
				 jQuery("#storeRegisterGrid").setGridParam({ url: 'storeRegisterForQc/records'});
				 jQuery("#storeRegisterGrid").trigger('reloadGrid');
				 alert("Selected Items Successfully Sent For Rework ");
				 document.getElementById('remarks').value = "";
			}
		});
		}
		}
		 if(remarks==null || remarks==""){
			
			alert("Please Enter Remarks");
		}
 if(idsOfSelectedRows.length==0){
			
			alert("Please select items");
		}
	});

});
$('#searchSoItems').click(function() {
	if (document.getElementById('numberOfCopperStrands').value != "") {
		var pattern = /^[0-9]\d*$/;
		if (!pattern.test($("#numberOfCopperStrands").val())) {
			alert("Enter valid Copper Strands");
			document.getElementById('numberOfCopperStrands').value = "";

		} else {
			searchFunction();
		}
	}
	
	
	else if (document.getElementById('layLength').value != "") {
		var pattern = /^[0-9]\d*$/;
		if (!pattern.test($("#layLength").val())) {
			alert("Enter valid Lay Length");
			document.getElementById('layLength').value = "";

		} else {
			searchFunction();
		}
	}
	else {
		searchFunction();
	}

});

function searchFunction() {
	var customerId = document.getElementById('partySelect').value;
	var workOrderNo= document.getElementById('workOrderNoSelect').value;
	var orderId = document.getElementById('salesOrderSelect').value;
	var itemCode = document.getElementById('itemIdSelect').value;
	var noOfCuStrand = document.getElementById('numberOfCopperStrands').value;
	var layLength = document.getElementById('layLength').value;
	var layType = document.getElementById('layType').value;
	var od = document.getElementById('outerDiameter').value;
	var searchOptions1 = {
		"groupOp" : "AND",
		"rules" : [ {
			"field" : "customerId",
			"op" : "eq",
			"data" : customerId
		}, {
			"field" : "orderId",
			"op" : "eq",
			"data" : orderId
		}, {
			"field" : "itemCode",
			"op" : "eq",
			"data" : itemCode
		},

		{
			"field" : "copperkey",
			"op" : "eq",
			"data" : $("#cuDiameterSelect").val()
		}, {
			"field" : "mainColour",
			"op" : "eq",
			"data" : $("#mainColorSelect").val()
		}, {
			"field" : "innerColor",
			"op" : "eq",
			"data" : $("#innerColorSelect").val()
		}, {
			"field" : "productKey",
			"op" : "eq",
			"data" : $("#productTypeSelect").val()
		}, {
			"field" : "numberOfCopperStrands",
			"op" : "eq",
			"data" : noOfCuStrand
		}, {
			"field" : "layType",
			"op" : "eq",
			"data" : layType
		}, {
			"field" : "layLength",
			"op" : "eq",
			"data" : layLength
		}, {
			"field" : "cableStdKey",
			"op" : "eq",
			"data" : $("#cableStdPvcSelect").val()
		}, {
			"field" : "outerDiameter",
			"op" : "eq",
			"data" : od
		},{
			"field" : "workOrderNo",
			"op" : "eq",
			"data" : workOrderNo
		},{
			"field" : "qcStatus",
			"op" : "eq",
			"data" : $("#qcStatusSelect").val()
		}

		]
	};
	performSearch(searchOptions1, "#storeRegisterGrid");

}

function performSearch(searchOptions, gridId) {
	// Set Enity object as post data
	$(gridId).setGridParam({
		postData : {
			searchObject : JSON.stringify(searchOptions)
		}
	});
	// $(gridId).setGridParam({postData: {searchObject:searchOptions}});
	// Reload the grid with given search criteria
	$(gridId).trigger("reloadGrid");
}

$('#clearSearchBox').click(function() {
	if ($("#salesOrderSelect").val() != "") {
		document.getElementById('salesOrderSelect').value = "";
		$('#salesOrderSelect').trigger('liszt:updated');
		$('#salesOrderSelect').children().remove();
		$('#salesOrderSelect').val('').trigger('liszt:updated');
		$.ajax({type:'POST', 
			url: 'storeRegisterForQc/getSalesOrders',
			data:{'customerId':0},
			success: function(response) {
				if(response.length != 0){
					for(var i=0;i< response.length;i++){
						$('#salesOrderSelect').append('<option selected="selected">'+ "" + '</option>');
						$('#salesOrderSelect').append('<option >' + response[i]+ '</option>');
						$('#salesOrderSelect').trigger('liszt:updated');
					}
				}
		}});
	}
	if ($("#partySelect").val() != "") {
		document.getElementById('partySelect').value = "";
		$('#partySelect').trigger('liszt:updated');
	}
	if ($("#itemIdSelect").val() != "") {
		document.getElementById('itemIdSelect').value = "";
		$('#itemIdSelect').trigger('liszt:updated');
	}

	if ($("#cuDiameterSelect").val() != "") {
		document.getElementById('cuDiameterSelect').value = "";
		$('#cuDiameterSelect').trigger('liszt:updated');
	}
	if ($("#mainColorSelect").val() != "") {
		document.getElementById('mainColorSelect').value = "";
		$('#mainColorSelect').trigger('liszt:updated');
	}
	if ($("#innerColorSelect").val() != "") {
		document.getElementById('innerColorSelect').value = "";
		$('#innerColorSelect').trigger('liszt:updated');
	}
	if ($("#productTypeSelect").val() != "") {
		document.getElementById('productTypeSelect').value = "";
		$('#productTypeSelect').trigger('liszt:updated');
	}
	if ($("#cableStdPvcSelect").val() != "") {
		document.getElementById('cableStdPvcSelect').value = "";
		$('#cableStdPvcSelect').trigger('liszt:updated');
	}

	if ($("#processTypeSelect").val() != "") {
		document.getElementById('processTypeSelect').value = "";
		$('#processTypeSelect').trigger('liszt:updated');
	}
	
	if ($("#workOrderNoSelect").val() != "") {
		document.getElementById('workOrderNoSelect').value = "";
		$('#workOrderNoSelect').trigger('liszt:updated');
	}
	if ($("#qcStatusSelect").val() != "") {
		document.getElementById('qcStatusSelect').value = "Pending";
		$('#qcStatusSelect').trigger('liszt:updated');
	}
	if (document.getElementById('numberOfCopperStrands').value != "")
		document.getElementById('numberOfCopperStrands').value = "";

	if (document.getElementById('layLength').value != "")
		document.getElementById('layLength').value = "";

	if (document.getElementById('layType').value != "")
		document.getElementById('layType').value = "";

	if (document.getElementById('outerDiameter').value != "")
		document.getElementById('outerDiameter').value = "";

	jQuery("#storeRegisterGrid").setGridParam({
		datatype : 'json'
	});
	jQuery("#storeRegisterGrid").setGridParam({
		postData : {
			searchObject : "allSearch"
		}
	});
	jQuery("#storeRegisterGrid").trigger('reloadGrid');

});


$("#partySelect").chosen().change(function() {

	var customerId = $('#partySelect').val();

	if(customerId != "" && customerId!=null)
	{
	$('#salesOrderSelect').children().remove();
	$('#salesOrderSelect').val('').trigger('liszt:updated');
	$.ajax({type:'POST', 
		url: 'storeRegisterForQc/getSalesOrders',
		data:{'customerId':customerId},
		success: function(response) {
			
			if (response.length == 0) {

				alert("There is no Sales Order for the selected customer");
			}

			if(response.length != 0){
				for(var i=0;i< response.length;i++){
					$('#salesOrderSelect').append('<option selected="selected">'+ "" + '</option>');
					$('#salesOrderSelect').append('<option >' + response[i]+ '</option>');
					$('#salesOrderSelect').trigger('liszt:updated');
				}
			}
	}});
	}

});


function editRow(id) {
	restoreRow(lastSelected);
	lastSelected = id;
	$('#storeRegisterGrid').jqGrid('editRow', id, {
		"keys" : true,
		"oneditfunc" : hideActButtons,
		aftersavefunc : function(savedId, response) {
			showActButtons(savedId);
		},
		afterrestorefunc : showActButtons
	});
}



function saveRow(id) {
    if(stockQtyValid==true && weightValid==true){
	$('#storeRegisterGrid').saveRow(id, {
		aftersavefunc : function(id, response) {
			showActButtons(id);
		}
	});
    }
    else if(stockQtyValid==false){
    	 alert("Stock Quantity entered should be valid");
    }
    else if(weightValid==false){
   	 alert("Weight entered should be valid");
   }
}

function restoreRow(id) {
	$('#storeRegisterGrid').jqGrid('restoreRow', id, {
		afterrestorefunc : showActButtons
	});
}

/*
 * Hides the Edit and Del Row Buttons on jqGrid and activates the Save and
 * restore(cancel) button
 * 
 */
function hideActButtons(id) {
	$('#editRow' + id).hide();
 	$('#saveRow' + id).show();
	$('#restoreRow' + id).show();
}

/*
 * Shows the Edit and Del Row Buttons on jqGrid and hides the Save and
 * restore(cancel) button
 * 
 */
function showActButtons(id) {
	$('#editRow' + id).show();
	$('#saveRow' + id).hide();
	$('#restoreRow' + id).hide();
	lastSelected = null;
}