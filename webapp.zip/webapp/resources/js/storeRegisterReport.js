var lastSelected;
var systemDate = new Date();

$(function() {
	
	$("#partySelect").chosen({no_results_text : "No results matched"});
	$("#salesOrderSelect").chosen({no_results_text : "No results matched"});
	
	$("#storeRegisterGrid").jqGrid(
					{
						url : 'storeRegisterReport/records',
						datatype : 'json',
						mtype : 'POST',
				
						colNames : [ 'Store Reg Id', 'Store', 'Sales Order No',
								'SO Status', 'PartyHidden','Party', 'Item Id', 'Item Code',
								'Item Description', 'Work Order No',
								'Bundle Id', 'Stock Qty(mts)', 'Units',
								'Stock Qty(Kg)', 'Change Label','Bag No', 'Bag Weight','QC Status' ],
						colModel : [ {
							name : 'storeRegisterId',
							index : 'storeRegisterId',
							width : 5,
							viewable : false,
							hidden : true
						}, {
							name : 'storeAddress',
							index : 'storeAddress',
							width : 5,
							viewable : false,
							hidden : true
						}, {
							name : 'orderId',
							index : 'orderId',
							width : 70
						}, {
							name : 'status',
							index : 'status',
							width : 70
						}, {
							name : 'customerName',
							index : 'customerName',
							width : 90,
							hidden : true
						},
						{
							name : 'customerCode',
							index : 'customerCode',
							width : 75
						},
						{
							name : 'itemId',
							index : 'itemId',
							width : 5,
							hidden : true
						}, {
							name : 'itemCode',
							index : 'itemCode',
							width : 150
						}, {
							name : 'itemDescription',
							index : 'itemDescription',
							width : 220
						}, {
							name : 'workOrderNo',
							index : 'workOrderNo',
							width : 70
						}, {
							name : 'bundleId',
							index : 'bundleId',
							width : 40
						}, {
							name : 'stockQty',
							index : 'stockQty',
							width : 70
						}, {
							name : 'unit',
							index : 'unit',
							width : 10,
							hidden : true
						}, {
							name : 'weight',
							index : 'weight',
							width : 60
						}, 
						  {name : 'changeLabelLink',
							index : 'changeLabelLink',
							width : 100,
							editable : false,
							hidden : true
							},
                         {
							name : 'packingSlipNo',
							index : 'packingSlipNo',
							width : 60,
							hidden : true
						}, {
							name : 'bagWeight',
							index : 'bagWeight',
							width : 60,
							hidden : true
						},{
							name : 'qcStatus',
							index : 'qcStatus',
							width : 70
						},

						],
						postData : {},
						rowNum : 100,
						rowList : [ 5, 10, 20, 30, 40, 100,500,1000,2000 ],
						height : 300,
						autowidth : true,
						rownumbers : false,
						pager : '#storeregisterpager',
						sortname : 'storeRegisterId',
						viewrecords : true,
						sortorder : "desc",
						caption : "Store Register Report",
						emptyrecords : "Empty records",
						loadonce : false,
						footerrow : true,
						loadComplete : function() {
						},
						jsonReader : {
							root : "rows",
							page : "page",
							total : "total",
							records : "records",
							repeatitems : false,
							cell : "cell",
							id : "storeRegisterId"
						},

						gridComplete : function() {

							var stockQty = $('#storeRegisterGrid').jqGrid('getCol', 'stockQty', false, 'sum');
							var totalStockQty = Math.round(parseFloat(stockQty) * 100) / 100;
							$('#storeRegisterGrid').jqGrid('footerData', 'set',	{ID : 'Total:',	stockQty : totalStockQty});

							var weight = $('#storeRegisterGrid').jqGrid('getCol', 'weight', false, 'sum');
							var totalWeight = Math.round(parseFloat(weight) * 100) / 100;
							$('#storeRegisterGrid').jqGrid('footerData', 'set',	{ID : 'Total:',	weight : totalWeight});

							var weight = $('#storeRegisterGrid').jqGrid('getCol', 'weight', false, 'sum');
							var totalWeight = Math.round(parseFloat(weight) * 100) / 100;
							$('#storeRegisterGrid').jqGrid('footerData', 'set',{ID : 'Total:',weight : totalWeight});

							var ids = jQuery("#storeRegisterGrid").jqGrid(
									'getDataIDs');
							for ( var i = 0; i < ids.length; i++) {
								var cl = ids[i];
								clLink = "<button class='btn btn-mini' id='changeLabelLink"
									+ cl
									+ "' "
									+ "onclick=\"openChangeLabelPage('"
									+ cl
									+ "');\" >Change Label </button>";
								$("#storeRegisterGrid").jqGrid('setRowData', ids[i], {
									changeLabelLink : clLink
								});
				
							}
						}

					});
	jQuery("#storeRegisterGrid").jqGrid('navGrid', '#storeregisterpager', {
		view : false,
		del : false,
		add : false,
		edit : false,
		search : false
	});

});



$("#partySelect").chosen().change(function() {
  	var customerId = $('#partySelect').val();
   	if(customerId != "" && customerId!=null){
    	$('#salesOrderSelect').children().remove();
    	$('#salesOrderSelect').children().remove();
    	$('#salesOrderSelect').val('').trigger('liszt:updated');
    	$.ajax({type:'POST', 
    		url: 'pendingSoItemReport/getSalesOrders/',
    		data:{"customerId":customerId},
    		success: function(response) {
    		if (response.length == 0) {
         	alert("There is no Sales Order for the selected customer");
    		}
    		if(response.length != 0){
    				for(var i=0;i< response.length;i++){
    					$('#salesOrderSelect').append('<option selected="selected">'+ "" + '</option>');
    					$('#salesOrderSelect').append('<option >' + response[i]+ '</option>');
    					$('#salesOrderSelect').trigger('liszt:updated');
    				}
    			}
    	}});
    	}
    });    

function editRow(id) {
	restoreRow(lastSelected);
	lastSelected = id;
	$('#storeRegisterGrid').jqGrid('editRow', id, {
		"keys" : true,
		"oneditfunc" : hideActButtons,
		aftersavefunc : function(savedId, response) {
			showActButtons(savedId);
		},
		afterrestorefunc : showActButtons
	});
}



function saveRow(id) {
	$('#storeRegisterGrid').saveRow(id, {
		aftersavefunc : function(id, response) {
			showActButtons(id);
		}
	});
}

function restoreRow(id) {
	$('#storeRegisterGrid').jqGrid('restoreRow', id, {
		afterrestorefunc : showActButtons
	});
}

/*
 * Hides the Edit and Del Row Buttons on jqGrid and activates the Save and
 * restore(cancel) button
 * 
 */
function hideActButtons(id) {
	$('#editRow' + id).hide();
	$('#delRow' + id).hide();
	$('#saveRow' + id).show();
	$('#restoreRow' + id).show();
}

/*
 * Shows the Edit and Del Row Buttons on jqGrid and hides the Save and
 * restore(cancel) button
 * 
 */
function showActButtons(id) {
	$('#editRow' + id).show();
	$('#delRow' + id).show();
	$('#saveRow' + id).hide();
	$('#restoreRow' + id).hide();
	lastSelected = null;
}

$('#searchButton').click(function() {
	
	searchFunction();
});

function searchFunction() {

    	var searchOptions1 = {
		"groupOp" : "AND",
		"rules" : [ {
			"field" : "customerId",
			"op" : "eq",
			"data" : $("#partySelect").val()
		}, {
			"field" : "orderId",
			"op" : "eq",
			"data" : $("#salesOrderSelect").val()
		},  ]
	};

	performSearch(searchOptions1, "#storeRegisterGrid");

}

function performSearch(searchOptions, gridId) {

	$(gridId).setGridParam({
		postData : {
			searchObject : JSON.stringify(searchOptions)
		}
	});
	$(gridId).trigger("reloadGrid");

}

function validateSearchParams(){
	

 if ($("#partySelect").val() == "") {
		alert("Please select party");
	}
	if ($("#salesOrderSelect").val() == "") {
		alert("Please select SalesOrder");
	}
	else 
		
		return true;
}

$("#salesOrderSelect").chosen().change(function() {

	var salesOrderNo = $('#salesOrderSelect').val();
	$.ajax({
		
		type:'POST', 
 		url: 'storeRegisterReport/getDcDetails',
 		data:{"salesOrderNo":salesOrderNo},
 		success: function(response) {

 				var res =response[0];
 			    document.getElementById('partySelect').value = res ;
 	 		   $('#partySelect').trigger('liszt:updated');	
               var customerName= $('#partySelect option:selected').text();
            	  
 		     jQuery("#storeRegisterGrid").setGridParam({datatype:'json'}); 
			 jQuery("#storeRegisterGrid").setGridParam({ url : 'storeRegisterReport/records'});
			 jQuery("#storeRegisterGrid").setGridParam({postData: {salesOrderNo:salesOrderNo}}); 
        	 jQuery("#storeRegisterGrid").setCaption('Store Register  '+salesOrderNo+' Records of '+customerName);
			 jQuery("#storeRegisterGrid").trigger('reloadGrid');

	     }});
	

});

$('#clearButton').click(function() {
	
	if ($("#salesOrderSelect").val() != "") {
		document.getElementById('salesOrderSelect').value = "";
		$('#salesOrderSelect').trigger('liszt:updated');
	}

	if ($("#partySelect").val() != "") {
		document.getElementById('partySelect').value = "";
		$('#partySelect').trigger('liszt:updated');
	}

	searchFunction();
});

function storeRegisterReportFn(){

	if ($("#salesOrderSelect").val() != "" && $("#salesOrderSelect").val() != null) {
	
	       location.href='storeRegisterReport/stockSalesOrderReport?salesOrderNo='+$('#salesOrderSelect').val();
	}
	else if($("#partySelect").val() != "" && $("#partySelect").val() != null){
        
         var customerName= $('#partySelect option:selected').text();
		 location.href='storeRegisterReport/stockPartyReport?customerName='+customerName;
	}
	else{
		location.href='storeRegisterReport/stockReport';
	}	
}