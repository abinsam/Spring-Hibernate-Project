var lastSelected;
var validExciseDuty = true;
var validEduCess = true;
var validHigherEduCess = true;
var validVat = true;
var validCst = true;
$(function() {

	$("#partySelect").chosen({no_results_text : "No results matched"});
	
	$("#taxDetailsGrid")
			.jqGrid(
					{
						url : 'taxDetails/records',
						datatype : 'json',
						mtype : 'POST',
						colNames : ['Tax Rate Id','custId', 'Name', 'Code','Excise Duty','Edu Cess','Higher Edu Cess','VAT','CST','Freight','Payment Terms','Action'],
						colModel : [  
						              
						            {
										name : 'taxRateId',
										index : 'taxRateId',
										width : 100,
									hidden:true,
										viewable : false
									},            
						              {
							name : 'customerId',
							index : 'customerId',
							width : 100,
							editable : true,
							hidden:true,
							viewable : false
						}, {
							name : 'customerName',
							index : 'customerName',
							width : 300,
							editable : false
						}, {
							name : 'customerCode',
							index : 'customerCode',
							width : 200,
							editable : false
						}, 
							
						{
							name : 'exciseDuty',
							index : 'exciseDuty',
							width : 100,
							editable : true,
							editrules : {
								required : true
							},
							editoptions : {
								dataInit : function(element) {
									$(element)
											.keyup(
													function() {
														var val1 = element.value;
														var num = new Number(
																val1);
														if (isNaN(num)) {
															alert("Excise Duty has to be a numeric value");
															validExciseDuty = false;
															jQuery("#taxDetailsGrid").trigger('reloadGrid');
														} else
															validExciseDuty = true;

													});
								},
								maxlength : 5
							}
						},{
							name : 'eduCess',
							index : 'eduCess',
							width : 100,
							editable : true,
							editrules : {
								required : true
							},
							editoptions : {
								dataInit : function(element) {
									$(element).keyup(
													function() {
														var val1 = element.value;
														var num = new Number(val1);
														if (isNaN(num)) {
															alert("Educational Cess has to be a numeric value");
															validEduCess = false;
															jQuery("#taxDetailsGrid").trigger('reloadGrid');
														} else
															validEduCess = true;

													});
								},
								maxlength : 5
							}
						},
						{
							name : 'higherEduCess',
							index : 'higherEduCess',
							width : 100,
							editable : true,
							editrules : {
								required : true
							},
							editoptions : {
								dataInit : function(element) {
									$(element).keyup(
													function() {
														var val1 = element.value;
														var num = new Number(val1);
														if (isNaN(num)) {
															alert("Higher Educational Cess has to be a numeric value");
															validHigherEduCess = false;
															jQuery("#taxDetailsGrid").trigger('reloadGrid');
														} else
															validHigherEduCess = true;

													});
								},
								maxlength : 5
							}
						},
						{
							name : 'vat',
							index : 'vat',
							width : 100,
							editable : true,
							editrules : {
								required : true
							},
							editoptions : {
								dataInit : function(element) {
									$(element).keyup(
													function() {
														var val1 = element.value;
														var num = new Number(val1);
														if (isNaN(num)) {
															alert("VAT has to be a numeric value");
															validVat = false;
															jQuery("#taxDetailsGrid").trigger('reloadGrid');
														} else
															validVat = true;

													});
								},
								maxlength : 5
							}
						},
						{
							name : 'cst',
							index : 'cst',
							width : 100,
							editable : true,
							editrules : {
								required : true
							},
							editoptions : {
								dataInit : function(element) {
									$(element)
											.keyup(
													function() {
														var val1 = element.value;
														var num = new Number(
																val1);
														if (isNaN(num)) {
															alert("CST has to be a numeric value");
															validCst = false;
															jQuery("#taxDetailsGrid").trigger('reloadGrid');
														} else
															validCst = true;

													});
								},
								maxlength : 5
							}
						},
						{
							name : 'freight',
							index : 'freight',
							width : 300,
							editable : true,
							editoptions : {
								size : 50,maxlength:40
							}
						},
						{
							name : 'paymentTerms',
							index : 'paymentTerms',
							width : 300,
							editable : true,
							editoptions : {
								size : 100,maxlength:40
							}
						},
						{
							name : 'act',
							index : 'act',
							width : 100,
							sortable : false,
							viewable : false
						}
						
						],
						postData : {},
						rowNum : 100,
						rowList : [ 5, 10, 20, 40, 60,100 ],
						height : 600,
						autowidth : true,
						rownumbers : false,
						pager : '#taxDetailsPager',
						sortname : 'taxRateId',
						viewrecords : true,
						sortorder : "asc",
						caption : "Records",
						emptyrecords : "Empty records",
						loadonce : false,
						loadComplete : function() {
						},
						jsonReader : {
							root : "rows",
							page : "page",
							total : "total",
							records : "records",
							repeatitems : false,
							cell : "cell",
							id : "taxRateId"
						},
						ondblClickRow : function(id) {
							if (id && id !== lastSelected) {
								editRow(id);
							}
						},
			    		gridComplete: function(){ 
			 	   	    	var ids = jQuery("#taxDetailsGrid").jqGrid('getDataIDs');
			 
			 	   	    	for ( var i = 0; i < ids.length; i++) {
			 	   	    		
			 					var cl = ids[i];
			 			
			 					be = "<input style='height:22px; width:35px; font-weight:bold;' type='button' value='Edit'  id='editRow"+cl+"' onclick=\"editRow('"+ cl + "');\" />";
/*			 					de = "<input style='height:22px; width:30px; font-weight: bold;' type='button' value='Del'  id='delRow"+cl+"' onclick=\"delRow('"+ cl + "');\" />";
*/			 					se = "<input style='height:22px; width: 29px; font-weight: bold;' type='button' value='Save' hidden='hidden'  id='saveRow"+cl+"' onclick=\"saveRow('"+ cl + "');\" />";
			 					ce = "<input style='height:22px;width:39px; font-weight: bold;' type='button' value='Cancel' hidden='hidden' id='restoreRow"+cl+"' onclick=\"restoreRow('"+ cl + "');\" />";
			 						$("#taxDetailsGrid").jqGrid('setRowData', ids[i],
			 							{
			 								act : be + se + ce
			 							});
			 				}
			            },
			    		editurl : "taxDetails/crud"
			    	}).navGrid('#taxDetailsPager',{view:false, del:false, edit:false, add:false,search:false}
			    	
			);
});

$('#clearSearchBox').click(function() {
	if ($("#partySelect").val() != "") {
		document.getElementById('partySelect').value = "";
		$('#partySelect').trigger('liszt:updated');
	}
	jQuery("#taxDetailsGrid").setGridParam({datatype : 'json'});
	jQuery("#taxDetailsGrid").setGridParam({postData : {searchObject : "allSearch"}});
	jQuery("#taxDetailsGrid").trigger('reloadGrid');

});

$('#searchSoItems').click(function() {
	var customerId = document.getElementById('partySelect').value;
	if(customerId==null||customerId=="")
		{
		alert("Please Select Customer!");
		}
	else{searchFunction();}
		
	
});

function searchFunction() {

	var customerId = document.getElementById('partySelect').value;

	var searchOptions1 = {
		"groupOp" : "AND",
		"rules" : [ {
			"field" : "customerId",
			"op" : "eq",
			"data" : customerId
		} ]
	};

	performSearch(searchOptions1, "#taxDetailsGrid");

}

function performSearch(searchOptions, gridId) {

	$(gridId).setGridParam({
		postData : {
			searchObject : JSON.stringify(searchOptions)
		}
	});
	$(gridId).trigger("reloadGrid");

}

function editRow(id) {
	restoreRow(lastSelected);
	lastSelected = id;
	$('#taxDetailsGrid').jqGrid('editRow', id, {
		"keys" : true,
		"oneditfunc" : hideActButtons,
		aftersavefunc : function(savedId, response) {
			showActButtons(savedId);
		},
		afterrestorefunc : showActButtons
	});
}

function delRow(id) {
	$("#taxDetailsGrid").jqGrid('delGridRow', id);
}

function saveRow(id) {
	$('#taxDetailsGrid').saveRow(id, {
		aftersavefunc : function(id, response) {
			showActButtons(id);
		}
	});
}

function restoreRow(id) {
	$('#taxDetailsGrid').jqGrid('restoreRow', id, {
		afterrestorefunc : showActButtons
	});
}

/*
 * Hides the Edit and Del Row Buttons on jqGrid
 * and activates the Save and restore(cancel) button
 * 
 */
function hideActButtons(id) {
	$('#editRow' + id).hide();
	$('#delRow' + id).hide();
	$('#saveRow' + id).show();
	$('#restoreRow' + id).show();
}

/*
 * Shows the Edit and Del Row Buttons on jqGrid
 * and hides the Save and restore(cancel) button
 * 
 */
function showActButtons(id) {
	$('#editRow' + id).show();
	$('#delRow' + id).show();
	$('#saveRow' + id).hide();
	$('#restoreRow' + id).hide();
	lastSelected = null;
}