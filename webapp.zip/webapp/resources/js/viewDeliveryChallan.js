var lastSelected;
var systemDate = new Date();
var month="";
var year="";
$("#partyNameSelect").chosen({no_results_text: "No results matched"});
$("#deliveryChallanNoSelect").chosen({no_results_text: "No results matched"});

$("#monthYearPicker").focus(function () {$(".ui-datepicker-calendar").hide();});
$('#monthYearPicker').datepicker({
    changeYear: true,
    changeMonth: true,
    changeDate :false,
    showButtonPanel: true,
    dateFormat: 'MM yy',
    onClose: function(dateText, inst) { 
        year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
        month = $("#ui-datepicker-div .ui-datepicker-month :selected").val();
        $(this).datepicker('setDate', new Date(year,month, 1));
        changeWoOnMonthYear();
    }
});
$('#monthYearPicker').datepicker('setDate',systemDate); 
$("#monthYearPicker").focus(function () {$(".ui-datepicker-month").show();});
$("#monthYearPicker").focus(function () {$(".ui-datepicker-year").show();});

$(function(){ 
	$("#deliveryChallanGrid").jqGrid({
		url: 'deliverychallan/records',
		datatype : 'local',
	    mtype: 'POST',
	   	colNames:['dcItemId','Delivery Challan No','Item Description ','No Of Rolls',
	   	           'Quantity per Roll','Total Quantity','Units'],
	   	colModel:[
              {name:'dcItemId', index:'dcItemId', width:5, viewable:false,hidden:true}, 
              {name:'deliveryChallanNo',index:' deliveryChallanNo', width:70,hidden:true},   
              {name:'itemDescription',index:'itemDescription', width:180},
   	          {name:'noOfRolls',index:'noOfRolls', width:50},
   	          {name:'qtyPerRoll',index:'qtyPerRoll', width:60},
   	          {name:'totalQty',index:'totalQty', width:40},
   	          {name:'units',index:'units', width:20}
 	 	],
	   	postData: {},
		rowNum:100,
	   	rowList:[5,10,20,40,50,100],
	   	height: 300,
	   	autowidth: true,
		rownumbers: false,
	   	pager: '#deliveryChallanPager',
	   	sortname: 'itemDescription',
	    viewrecords: true,
	    sortorder: "desc",
	    caption:"Delivery Challan",
	    emptyrecords: "Empty records",
	    loadonce: false,
	    footerrow: true,
	    loadComplete: function() {},
	    jsonReader : {
	        root: "rows",
	        page: "page",
	        total: "total",
	        records: "records",
	        repeatitems: false,
	        cell: "cell",
	        id: "dcItemId"
	    },
	    ondblClickRow : function(id) {
			if (id && id !== lastSelected) {
				$('#deliveryChallanGrid').jqGrid('restoreRow',lastSelected);
				editRow(id);
				lastSelected = id;
			}
		},
		gridComplete : function() {
		    var ids = jQuery("#deliveryChallanGrid").jqGrid('getDataIDs');
			for ( var i = 0; i < ids.length; i++) {
				var cl = ids[i];
				be = "<input style='height:22px; width:35px;' type='button' value='Edit' id='editRow"+cl+"' onclick=\"editRow('"+ cl + "');\" />";
				de = "<input style='height:22px; width:30px;' type='button' value='Del' id='delRow"+cl+"' onclick=\"delRow('"+ cl + "');\" />";
				se = "<input style='height:22px; width: 29px;' type='button' value='Save' hidden='hidden' id='saveRow"+cl+"' onclick=\"saveRow('"+ cl + "');\" />";
				ce = "<input style='height:22px;width:39px;' type='button' value='Cancel' hidden='hidden'  id='restoreRow"+cl+"' onclick=\"restoreRow('"+ cl + "');\" />";
				$("#deliveryChallanGrid").jqGrid('setRowData', ids[i],
						{
							act : be + de + se + ce
						
						});
			}
			 var totalNoOfRolls = $('#deliveryChallanGrid').jqGrid('getCol','noOfRolls',false,'sum');
	   		 var totalQty= $('#deliveryChallanGrid').jqGrid('getCol','totalQty',false,'sum');
	   		var totalQtyRound = Math.round(parseFloat(totalQty) * 100) / 100;
	   		$('#deliveryChallanGrid').jqGrid('footerData','set', {ID: 'Total:', noOfRolls: totalNoOfRolls});
   	    	$('#deliveryChallanGrid').jqGrid('footerData','set', {ID: 'Total:', totalQty: totalQtyRound});
   	    	$('#deliveryChallanGrid').jqGrid('footerData','set', {ID: 'Total:', itemDescription: "Total"});
   	     		 	
		}
		//editurl : "viewdeliverychallan/crud",   
	});
	
	 jQuery("#deliveryChallanGrid").jqGrid('navGrid','#deliveryChallanPager',{view:false, del:false,add:false, edit:false, search:false});
});

function changeWoOnMonthYear(){
	
	    $('#deliveryChallanNoSelect').children().remove();
		$('#deliveryChallanNoSelect').val('').trigger('liszt:updated');
		
		document.getElementById('orderId').value="";
		document.getElementById('challanDate').value="";
		document.getElementById('bagNo').value="";
		document.getElementById('partyNameSelect').value = "";
		$('#partyNameSelect').trigger('liszt:updated');
		$('#deliveryChallanGrid').jqGrid('clearGridData');
		jQuery("#deliveryChallanGrid").setCaption("Delivery Challan List");
		var validSearch=validateSearchParams();
		if(validSearch==true){
		 $.ajax({type:'POST',
			  url: 'viewdeliverychallan/fetchDeliveryChallan',
			  data: {"month":month,"year":year}, 
			  success: function(response) {
					
					if (response.length == 0) {
       				alert("There is no Delivery Challan for the selected month and year");

			        }
					if(response.length != 0){
						for(var i=0;i< response.length;i++){
							$('#deliveryChallanNoSelect').append('<option selected="selected">'+ "" + '</option>');
							$('#deliveryChallanNoSelect').append('<option >' + response[i]+ '</option>');
							$('#deliveryChallanNoSelect').trigger('liszt:updated');
						}
					}else{
						$('#deliveryChallanNoSelect').empty();	
						$('#deliveryChallanNoSelect').children().remove();
						$('#deliveryChallanNoSelect').val('').trigger('liszt:updated');
					}
				
		 }
		 });
	 }
}


$("#partyNameSelect").chosen().change(function() {
//Abin
	$('#deliveryChallanNoSelect').empty();	
	$('#deliveryChallanNoSelect').children().remove();
	$('#deliveryChallanNoSelect').val('').trigger('liszt:updated');
	
	document.getElementById('orderId').value="";
	document.getElementById('challanDate').value="";
	document.getElementById('bagNo').value="";
	
	var validSearch=validateSearchParams();
	
	if(validSearch==true){
		
	var customerId = $('#partyNameSelect').val();

     month = $("#ui-datepicker-div .ui-datepicker-month :selected").val();
     year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();

	$.ajax({
		type:'POST', 
		url: 'viewdeliverychallan/getDeliveryChallanNos',
		data: {'customer':customerId,"month":month,"year":year}, 
		success: function(response) {
			$('#deliveryChallanNoSelect').empty();
			
			if (response.length == 0) {
				alert("There is no delivery challan created for the selected customer and month year");
				$('#deliveryChallanGrid').jqGrid('clearGridData');
		 jQuery("#deliveryChallanGrid").setCaption("Delivery Challan List");
			}

			if(response.length != 0){
				for(var i=0;i< response.length;i++){
					$('#deliveryChallanNoSelect').append('<option selected="selected">'+ "" + '</option>');
					$('#deliveryChallanNoSelect').append('<option >' + response[i]+ '</option>');
					$('#deliveryChallanNoSelect').trigger('liszt:updated');
				}
			}		
	}
   });
}
});

function validateSearchParams(){

	  if($("#monthYearPicker").val()=="" || $("#monthYearPicker").val()==null){
	    	alert("Month and Year empty! please select month and year");
	    	return false;
	    }
	    else return true;
}


$("#deliveryChallanNoSelect").chosen().change(function() {

	var deliveryChallanNo = $('#deliveryChallanNoSelect').val();
	$.ajax({
		
		type:'POST', 
 		url: 'viewdeliverychallan/getDcDetails',
 		data:{"deliveryChallanNo":deliveryChallanNo},
 		success: function(response) {
 			
				
 			if(response[0]!=null){
 			if(response[0]!="Cancelled DeliveryChallan")
 			document.getElementById('orderId').value=response[0];
 			else
 			alert(deliveryChallanNo+ " is Cancelled");
 			}
 		     if(response[1]!=null)
 			 document.getElementById('challanDate').value=response[1].substring(8,10)+"-"+response[1].substring(5,7)+"-"+response[1].substring(0,4);
 			 if(response[2]!=null)
 			document.getElementById('bagNo').value=response[2];	 
 			 if(response[3]!=null)
 				document.getElementById('invoiceNo').value=response[3];
 				
 			 if(response[4]!=null)
  				document.getElementById('invoiceStatus').value=response[4];	
 				
 				 var res =response[6];
 				 document.getElementById('partyNameSelect').value = res ;
 	 			 $('#partyNameSelect').trigger('liszt:updated');	
                 var customerName= $('#partyNameSelect option:selected').text();
            	  
 		     jQuery("#deliveryChallanGrid").setGridParam({datatype:'json'}); 
			 jQuery("#deliveryChallanGrid").setGridParam({ url : 'viewdeliverychallan/records'});
			 jQuery("#deliveryChallanGrid").setGridParam({postData: {deliveryChallanNo:deliveryChallanNo}}); 
        	 jQuery("#deliveryChallanGrid").setCaption('Delivery Challan  '+deliveryChallanNo+' Records of '+customerName);
			 jQuery("#deliveryChallanGrid").trigger('reloadGrid');

	     }});
	

});


$('#clearButton').click(function() {
	
	if (document.getElementById('partyNameSelect').value != "") {
		document.getElementById('partyNameSelect').value = "" ;
			$('#partyNameSelect').trigger('liszt:updated');	
	}
	$('#deliveryChallanNoSelect').empty();	
	$('#deliveryChallanNoSelect').children().remove();
	$('#deliveryChallanNoSelect').val('').trigger('liszt:updated');
	
	if (document.getElementById('orderId').value != "")
		document.getElementById('orderId').value = "";

	if (document.getElementById('challanDate').value != "")
		document.getElementById('challanDate').value = "";
	
	if (document.getElementById('bagNo').value != "")
		document.getElementById('bagNo').value = "";
	
	$('#monthYearPicker').datepicker('setDate',systemDate);
	
	month = $("#ui-datepicker-div .ui-datepicker-month :selected").val();
    year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
    
	$('#deliveryChallanGrid').jqGrid('clearGridData');
	 jQuery("#deliveryChallanGrid").setCaption("Delivery Challan List");
	 $.ajax({type:'POST',
		  url: 'viewdeliverychallan/fetchDeliveryChallan',
		  data: {"month":month,"year":year}, 
		  success: function(response) {
				if(response.length != 0){
					for(var i=0;i< response.length;i++){
						$('#deliveryChallanNoSelect').append('<option selected="selected">'+ "" + '</option>');
						$('#deliveryChallanNoSelect').append('<option >' + response[i]+ '</option>');
						$('#deliveryChallanNoSelect').trigger('liszt:updated');
					}
				}			
	 }
	 });
	
});

$('#woTrackButton').click(function() {
	
	
	var dcNo=document.getElementById('deliveryChallanNoSelect').value;
	if(dcNo!=null && dcNo!="")
	    location.href='viewdeliverychallan/workOrderTrackReport?deliveryChallanNo='+dcNo;
	else
		alert("Kindly select a delivery challan number to see the work order tracking!");
	

});

$('#deleteDeliveryChallanBtn').click(function() {
	var deliveryChallanNo = $('#deliveryChallanNoSelect').val();
	var invoiceStatus=document.getElementById('invoiceStatus').value;
	var invoiceNo=document.getElementById('invoiceNo').value;
	if((deliveryChallanNo!="" ||deliveryChallanNo!=null) && invoiceStatus=="No" && (invoiceNo=="" || invoiceNo==null)){
		if (confirm("Are you sure you want to delete delievery challan "+deliveryChallanNo+" ?")) {
			$.ajax({
				type : 'POST',
				url : 'viewdeliverychallan/delete',
				data : {'deliveryChallanNo' : deliveryChallanNo},
				success : function(response) {
					alert("Delivery Challan "+deliveryChallanNo+" deleted successfully");
					jQuery("#deliveryChallanGrid").trigger('reloadGrid');
					document.getElementById('deliveryChallanNoSelect').value ="";
					document.getElementById('orderId').value ="";
					document.getElementById('challanDate').value ="";
					document.getElementById('bagNo').value ="";
					
					$('#deliveryChallanNoSelect').children().remove();
					$('#deliveryChallanNoSelect').val('').trigger('liszt:updated');
					for ( var i = 0; i < response.length; i++) {
						$('#deliveryChallanNoSelect').append('<option selected="selected">'+ ""+ '</option>');
						$('#deliveryChallanNoSelect').append('<option >'+ response[i]+ '</option>');
						$('#deliveryChallanNoSelect').trigger('liszt:updated');
						}
				
				}});
		}
	}
	else if (invoiceNo!="" || invoiceNo!=null || invoiceStatus=="Yes"){
		alert("Invoice "+invoiceNo+" has been generated for delivery challan "+deliveryChallanNo);
	}
	else if(deliveryChallanNo==""){
		alert("Select delivery challan  for deletion");
	}

});
