var lastSelected;
var systemDate = new Date();
var month="";
var year="";
$("#customerSelect").chosen({no_results_text : "No results matched"});
$("#invoiceNoSelect").chosen({no_results_text : "No results matched"});
$("#monthYearPicker").focus(function () {$(".ui-datepicker-calendar").hide();});
$('#monthYearPicker').datepicker({

    changeYear: true,
    changeMonth: true,
    changeDate :false,
    showButtonPanel: true,
    dateFormat: 'MM yy',
    onClose: function(dateText, inst) { 
        year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
        month = $("#ui-datepicker-div .ui-datepicker-month :selected").val();
        $(this).datepicker('setDate', new Date(year,month, 1));
        changeWoOnMonthYear();
    }
});
$('#monthYearPicker').datepicker('setDate',systemDate); 
$("#monthYearPicker").focus(function () {$(".ui-datepicker-month").show();});
$("#monthYearPicker").focus(function () {$(".ui-datepicker-year").show();});

$("#loading").dialog({
    hide: 'slide',
    show: 'slide',
    autoOpen: false
});
$(".ui-dialog-titlebar").hide();

$(function() {
	$("#invoiceGrid")
			.jqGrid(
					{
						// url: 'viewInvoice',
						datatype : 'json',
						mtype : 'POST',
						colNames : [ 'Id', 'Item Description', 'No Of Rolls',
								'Total Qty', 'Units', 'Rate/ Unit(Rs)',
								'Total Assessable Value(Rs)',
								'Total Duty Paid(Rs)', 'Edu Cess (Rs)',
								'Higher Edu Cess(Rs)', 'Cst(Rs)','Vat(Rs)',
								'Amount(Rs)'],
						colModel : [ {
							name : 'invoiceId',
							index : 'invoiceId',
							width : 15,
							viewable : false,
							hidden : true
						}, {
							name : 'assortedItem',
							index : 'assortedItem',
							width : 170
						}, {
							name : 'noOfRolls',
							index : 'noOfRolls',
							width : 70
						}, {
							name : 'totalQuantity',
							index : 'totalQuantity',
							width : 60
						}, {
							name : 'units',
							index : 'units',
							width : 50
						}, {
							name : 'ratePerUnit',
							index : 'ratePerUnit',
							width : 70
						}, {
							name : 'totalValue',
							index : 'totalValue',
							width : 190
						}, {
							name : 'totalDuty',
							index : 'totalDuty',
							width : 140
						}, {
							name : 'totalEduCess',
							index : 'totalEduCess',
							width : 120
						}, {
							name : 'totalHigherEduCess',
							index : 'totalHigherEduCess',
							width : 120
						},  {
							name : 'totalCst',
							index : 'totalCst',
							width : 100
						},{
							name : 'totalVat',
							index : 'totalVat',
							width : 100
						}, {
							name : 'amount',
							index : 'amount',
							width : 100
						}
						],
						postData : {},
						rowNum : 100,
						rowList : [ 5, 10, 20, 40, 50 ,100],
						height : 300,
						autowidth : true,
						rownumbers : false,
						pager : '#invoicePager',
						sortname : 'assortedItem',
						viewrecords : true,
						sortorder : "desc",
						caption : "Invoice Details",
						emptyrecords : "Empty records",
						loadonce : false,
						footerrow : true,
						loadComplete : function() {
						},
						jsonReader : {
							root : "rows",
							page : "page",
							total : "total",
							records : "records",
							repeatitems : false,
							cell : "cell",
							id : "invoiceId"
						},

						gridComplete : function() {
							var totalAmount = $('#invoiceGrid').jqGrid(
									'getCol', 'amount', false, 'sum');
							var totalVat = $('#invoiceGrid').jqGrid('getCol',
									'totalVat', false, 'sum');
							var totalHigherEduCess = $('#invoiceGrid').jqGrid(
									'getCol', 'totalHigherEduCess', false,
									'sum');
							var totalEduCess = $('#invoiceGrid').jqGrid(
									'getCol', 'totalEduCess', false, 'sum');
							var totalDuty = $('#invoiceGrid').jqGrid('getCol',
									'totalDuty', false, 'sum');
							var totalValue = $('#invoiceGrid').jqGrid('getCol',
									'totalValue', false, 'sum');
							var totalQuantity = $('#invoiceGrid').jqGrid(
									'getCol', 'totalQuantity', false, 'sum');
							var totalRoll = $('#invoiceGrid').jqGrid('getCol',
									'noOfRolls', false, 'sum');
							var qtyTotal = $('#invoiceGrid').jqGrid('getCol',
									'quantity', false, 'sum');

							var amountRoundUp = Math
									.round(parseFloat(totalAmount) * 100) / 100;
							var vatRoundUp = Math
									.round(parseFloat(totalVat) * 100) / 100;
							var highEduCessRoundUp = Math
									.round(parseFloat(totalHigherEduCess) * 100) / 100;
							var eduCessRoundUp = Math
									.round(parseFloat(totalEduCess) * 100) / 100;
							var dutyRoundUp = Math
									.round(parseFloat(totalDuty) * 100) / 100;
							var valueRoundUp = Math
									.round(parseFloat(totalValue) * 100) / 100;
							var qtyRoundUp = Math
									.round(parseFloat(totalQuantity) * 100) / 100;
							var qtyValueRound = Math
									.round(parseFloat(qtyTotal) * 100) / 100;

							$('#invoiceGrid').jqGrid('footerData', 'set', {
								ID : 'Total:',
								amount : amountRoundUp
							});
							$('#invoiceGrid').jqGrid('footerData', 'set', {
								ID : 'Total:',
								totalVat : vatRoundUp
							});
							$('#invoiceGrid').jqGrid('footerData', 'set', {
								ID : 'Total:',
								totalHigherEduCess : highEduCessRoundUp
							});
							$('#invoiceGrid').jqGrid('footerData', 'set', {
								ID : 'Total:',
								totalEduCess : eduCessRoundUp
							});
							$('#invoiceGrid').jqGrid('footerData', 'set', {
								ID : 'Total:',
								totalDuty : dutyRoundUp
							});
							$('#invoiceGrid').jqGrid('footerData', 'set', {
								ID : 'Total:',
								totalValue : valueRoundUp
							});
							$('#invoiceGrid').jqGrid('footerData', 'set', {
								ID : 'Total:',
								totalQuantity : qtyRoundUp
							});
							$('#invoiceGrid').jqGrid('footerData', 'set', {
								ID : 'Total:',
								noOfRolls : totalRoll
							});
							$('#invoiceGrid').jqGrid('footerData', 'set', {
								ID : 'Total:',
								quantity : qtyValueRound
							});

							$('#invoiceGrid').jqGrid('footerData', 'set', {
								ID : 'Total:',
								units : "-"
							});
							$('#invoiceGrid').jqGrid('footerData', 'set', {
								ID : 'Total:',
								ratePerUnit : "-"
							});
							$('#invoiceGrid').jqGrid('footerData', 'set', {
								ID : 'Total:',
								assortedItem : "Total"
							});
							}
					// editurl : "viewworkorder/crud",
					});

	jQuery("#invoiceGrid").jqGrid('navGrid', '#invoicePager', {
		view : false,
		del : false,
		add : false,
		edit : false,
		search : false
	});
});

function changeWoOnMonthYear(){
	 $('#invoiceNoSelect').children().remove();
		$('#invoiceNoSelect').val('').trigger('liszt:updated');
		document.getElementById('deliveryChallanNos').value="";
		document.getElementById('transportDetails').value="";
		document.getElementById('lrDetails').value="";
		document.getElementById('mailStatus').value = "";
		document.getElementById('lrmailStatus').value = "";
		document.getElementById('transportCharge').value = "";
		document.getElementById('grossTotal').value = "";
		document.getElementById('customerSelect').value = "";
		$('#customerSelect').trigger('liszt:updated');
		$('#invoiceGrid').jqGrid('clearGridData');
		jQuery("#invoiceGrid").setCaption("Invoice List");
		var validSearch=validateSearchParams();
		if(validSearch==true){
		 $.ajax({type:'POST',
			  url: 'viewInvoice/fetchInvoiceNos',
			  data: {"month":month,"year":year}, 
			  success: function(response) {
					
					if (response.length == 0) {
      				alert("There are no invoices for the selected month and year");

			        }
					if(response.length != 0){
						for(var i=0;i< response.length;i++){
							$('#invoiceNoSelect').append('<option selected="selected">'+ "" + '</option>');
							$('#invoiceNoSelect').append('<option >' + response[i]+ '</option>');
							$('#invoiceNoSelect').trigger('liszt:updated');
						}
					}else{
						$('#invoiceNoSelect').empty();	
						$('#invoiceNoSelect').children().remove();
						$('#invoiceNoSelect').val('').trigger('liszt:updated');
					}
				
		 }
		 });
	 }
}


function validateSearchParams(){

	  if($("#monthYearPicker").val()=="" || $("#monthYearPicker").val()==null){
	    	alert("Month and Year empty! please select month and year");
	    	return false;
	    }
	    else return true;
}

$("#customerSelect").chosen().change(function() {

	$('#invoiceNoSelect').empty();	
	$('#invoiceNoSelect').children().remove();
	$('#invoiceNoSelect').val('').trigger('liszt:updated');
	
	document.getElementById('deliveryChallanNos').value="";
	document.getElementById('transportDetails').value="";
	document.getElementById('lrDetails').value="";
	document.getElementById('mailStatus').value = "";
	document.getElementById('lrmailStatus').value = "";
	document.getElementById('transportCharge').value = "";
	document.getElementById('grossTotal').value = "";
	
	var validSearch=validateSearchParams();
	
	if(validSearch==true){
		
	var customerId = $('#customerSelect').val();
     month = $("#ui-datepicker-div .ui-datepicker-month :selected").val();
     year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
   
						$.ajax({type : 'POST',
								url : 'customers/customerDetails',
								data : {'customerId' : customerId},
							
								success : function(response) {
									document.getElementById('partyAddress').value = response[1];
									document.getElementById('paymentTerms').value = response[4];
									$.ajax({type : 'POST',
										url: 'viewInvoice/getInvoiveNos',
										data: {'customer':customerId,"month":month,"year":year}, 
									/*		success : function(response) {
											for ( var i = 0; i < response.length; i++) {
											$('#invoiceNoSelect').append('<option selected="selected">'+ ""+ '</option>');
											$('#invoiceNoSelect').append('<option >'+ response[i]+ '</option>');
											$('#invoiceNoSelect').trigger('liszt:updated');
											}
                 							}*/
										success: function(response) {
											$('#invoiceNoSelect').empty();
											
											if (response.length == 0) {
												alert("There is no invoice created for the selected customer and month year");
											/*	document.getElementById('customerSelect').value = "";
												$('#customerSelect').trigger('liszt:updated');
										*/		$('#invoiceGrid').jqGrid('clearGridData');
											}

											if(response.length != 0){
												for(var i=0;i< response.length;i++){
													$('#invoiceNoSelect').append('<option selected="selected">'+ "" + '</option>');
													$('#invoiceNoSelect').append('<option >' + response[i]+ '</option>');
													$('#invoiceNoSelect').trigger('liszt:updated');
												}
											}		
									}
											});
								}
							});
	}
});

$("#invoiceNoSelect").chosen().change(function() {
	document.getElementById('lrDetails').value="";
						var invoiceNo = $('#invoiceNoSelect').val();
						$.ajax({	
							type : 'POST',
									url : 'viewInvoice/invoiceDetails',
									data : {'invoiceNo' : invoiceNo},
									success : function(response) {
							if (response[0] != null)
								document.getElementById('invoiceDate').value = response[0].substring(8, 10)+ "-"
													+ response[0].substring(5,7)+ "-"+ response[0].substring(0,	4)
													+ " "+ response[0].substring(11,19);
										if (response[1] != null	&& response[1] != "") {
											document.getElementById('transportDetails').value = response[1];
											}
										if (response[2] != null	&& response[2] != "") {
											document.getElementById('lrDetails').value = response[2];
										}
										if (response[3] != null	&& response[3] != "") {
											document.getElementById('mailStatus').value = response[3];
										}
										if (response[4] != null	&& response[4] != "") {
											document.getElementById('deliveryChallanNos').value = response[4];
										}
										if (response[5] != null	&& response[5] != "") {
										   document.getElementById('transportCharge').value = response[5];
										}
										if (response[6] != null	&& response[6] != "") {
											document.getElementById('grossTotal').value = response[6];
										}
										if (response[8] != null	&& response[8] != "") {
											document.getElementById('status').value = response[8];
										}
										if (response[9] != null	&& response[9] != "") {
											document.getElementById('lrmailStatus').value = response[9];
										}
										 var res =response[7];
							 				document.getElementById('customerSelect').value = res ;
							 	 			$('#customerSelect').trigger('liszt:updated');	
							               var customerName= $('#customerSelect option:selected').text();
							                  	var customerId = $('#customerSelect').val();
							                    $.ajax({type:'POST',url: 'customers/taxDetails',
							            	   data: {'customerId': customerId},
							                  success: function(response) {
							           		 document.getElementById('partyAddress').value=response[1];
							           		 document.getElementById('paymentTerms').value=response[10];
							                  }});
										var invoiceNo = $('#invoiceNoSelect').val();										
										jQuery("#invoiceGrid").setGridParam({datatype : 'json'});
										jQuery("#invoiceGrid").setGridParam({url : 'viewInvoice/records'});
										jQuery("#invoiceGrid").setGridParam({postData: {invoiceNo:invoiceNo}}); 
                                    	jQuery("#invoiceGrid").setCaption('Invoice ' + invoiceNo+ ' Records of '+ customerName);
										jQuery("#invoiceGrid").trigger('reloadGrid');
									}
								});
					
				});

$('#clearButton').click(function() {
	
	if (document.getElementById('customerSelect').value != "") {
		document.getElementById('customerSelect').value = "" ;
			$('#customerSelect').trigger('liszt:updated');	
	}
	$('#invoiceNoSelect').empty();	
	$('#invoiceNoSelect').children().remove();
	$('#invoiceNoSelect').val('').trigger('liszt:updated');
	
	if (document.getElementById('deliveryChallanNos').value != "")
		document.getElementById('deliveryChallanNos').value = "";

	if (document.getElementById('transportDetails').value != "")
		document.getElementById('transportDetails').value = "";
	
	if (document.getElementById('lrDetails').value != "")
		document.getElementById('lrDetails').value = "";
	
	if (document.getElementById('mailStatus').value != "")
		document.getElementById('mailStatus').value = "";
	
	if (document.getElementById('transportCharge').value != "")
		document.getElementById('transportCharge').value = "";
	
	if (document.getElementById('grossTotal').value != "")
		document.getElementById('grossTotal').value = "";
	
	if (document.getElementById('lrmailStatus').value != "")
		document.getElementById('lrmailStatus').value = "";
	
	$('#monthYearPicker').datepicker('setDate',systemDate);
	month = $("#ui-datepicker-div .ui-datepicker-month :selected").val();
    year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
	$('#invoiceGrid').jqGrid('clearGridData');
	 jQuery("#invoiceGrid").setCaption("Invoice List");
	 $.ajax({type:'POST',
		 url: 'viewInvoice/fetchInvoiceNos',
		  data: {"month":month,"year":year}, 
		  success: function(response) {
				if(response.length != 0){
					for(var i=0;i< response.length;i++){
						$('#invoiceNoSelect').append('<option selected="selected">'+ "" + '</option>');
						$('#invoiceNoSelect').append('<option >' + response[i]+ '</option>');
						$('#invoiceNoSelect').trigger('liszt:updated');
					}
				}			
	 }
	 });
	
	
	
});


$('#deleteInvoiceBtn').click(function() {
	var invoiceNo = $('#invoiceNoSelect').val();
	var mailStatus = document.getElementById('mailStatus').value;
	var status= document.getElementById('status').value;
	if(mailStatus=="No" && (invoiceNo!="" || invoiceNo!=null ) && status=="Created" ){
		if (confirm("Are you sure you want to delete this invoice?")) {
			$.ajax({
				type : 'POST',
				url : 'viewInvoice/delete',
				data : {'invoiceNo' : invoiceNo},
				success : function(response) {
					alert("Invoice "+invoiceNo+" deleted successfully");
					jQuery("#invoiceGrid").trigger('reloadGrid');
					document.getElementById('deliveryChallanNos').value ="";
					$('#invoiceNoSelect').children().remove();
					$('#invoiceNoSelect').val('').trigger('liszt:updated');
					for ( var i = 0; i < response.length; i++) {
						$('#invoiceNoSelect').append('<option selected="selected">'+ ""+ '</option>');
						$('#invoiceNoSelect').append('<option >'+ response[i]+ '</option>');
						$('#invoiceNoSelect').trigger('liszt:updated');
						}
				
				}});
		}
	}
	else if(invoiceNo==""){
		alert("Select invoice for deletion");
	}
	else if(status=="Cancelled"){
		alert("Invoice already cancelled");	
	}
	else if(status=="Submitted"){
		alert("Invoice is Submitted and cannot be deleted");	
	}
	else if(mailStatus=="Yes"){
		alert("Invoice already submited to customer cannot be deleted");
	}
	
});




$('#submitInvoiceBtn').click(function() {
	var invoiceNo = $('#invoiceNoSelect').val();
	var lrDetails = document.getElementById('lrDetails').value;
	if(lrDetails!=null && lrDetails!=""){
	$.ajax({
		type : 'POST',
		url : 'viewInvoice/submitInvoice',
		data : {
			'invoiceNo' : invoiceNo,
			'lrDetails' : lrDetails
		},
		   beforeSend: function(){
	           $("#loading").dialog('open').html("<p>Sending Mail...</p>");
	        },
		success : function(response) {
			alert("Invoice " + invoiceNo + " is submitted and mail sent");
			document.getElementById('mailStatus').value = "Yes";
			
		},
        error:function(e){
            	alert("Error, email not sent");
        },
        complete: function() {
       	 $("#loading").dialog('close');
       }
	});
	}
	else{
		alert("Enter LR Details");
	}
});








$('#cancelInvoiceBtn').click(function() {
	var remarks=document.getElementById('remarks').value;
	var customerName=$('customerSelect').val();
	var invoiceNo = $('#invoiceNoSelect').val();
	if(remarks!=null && remarks!="" && invoiceNo!=null && invoiceNo!=""){
		var invoiceStatus=document.getElementById('status').value;
		if(invoiceStatus=="Submitted"){
		$.ajax({
			type : 'POST',
			url : 'viewInvoice/cancelInvoice',
			data : {
				'invoiceNo' : invoiceNo,
				'remarks' : remarks
			},
			   beforeSend: function(){
		           $("#loading").dialog('open').html("<p>Cancelling Invoice..</p>");
		        },
			success : function(response) {
				if(response[0]=="Cancelled"){
				alert("Invoice " + invoiceNo + " is Cancelled");
				jQuery("#invoiceGrid").setGridParam({datatype : 'json'});
				jQuery("#invoiceGrid").setGridParam({url : 'viewInvoice/records'});
				jQuery("#invoiceGrid").setGridParam({postData: {invoiceNo:invoiceNo}}); 
            	jQuery("#invoiceGrid").setCaption('Invoice ' + invoiceNo+ ' Records of '+ customerName);
				jQuery("#invoiceGrid").trigger('reloadGrid');

				}
				else if(response[0]=="Not Submitted")
				 alert("Invoice " + invoiceNo + " cannot be Cancelled as it is should be Submitted before cancellation");
			},
	         complete: function() {
	       	 $("#loading").dialog('close');
	       }
		});	

		}else{
			alert("Invoice "+invoiceNo+" should be Submitted for cancellation");
		}
		}else if(invoiceNo==null || invoiceNo==""){
		alert("Select invoice");
	}else{
		alert("Enter remarks");
	}
});
/*$('#invoiceReport').click(function() {
			var invoiceNo = $('#invoiceNoSelect').val();
			$("#invoiceReport").attr("action", 'viewInvoice/testReport?invoiceNo='+invoiceNo);
			$('#invoiceReport').submit();

	var invoiceNo = $('#invoiceNoSelect').val();
	if(invoiceNo!=null && invoiceNo!=""){
	$.ajax({
		type : 'POST',
		url : 'viewInvoice/testReport',
		data : {"invoiceNo" : invoiceNo},
		success : function(response) {
			if(response=="notexist"){
				alert("Please save the generated PDF at desired location");
			}
			
		}
		
	});
	}else{
		alert("Select Invoice number");
	}
});
*/
$('#invoicePrint').click(function() {
	var invoiceNo = $('#invoiceNoSelect').val();
	if(invoiceNo!=null && invoiceNo!=""){
		if (confirm("Do You want to Submit the Invoice: "+invoiceNo)){	
			location.href='viewInvoice/invoicePrintReport?invoiceNo='+$('#invoiceNoSelect').val();
			document.getElementById('status').value = "Submitted";
    	}
	 }else{
		alert("Select Invoice number");
	}
});

$('#invoiceMialBtn').click(function() {
	var invoiceNo = $('#invoiceNoSelect').val();
	var mailStatus = document.getElementById('mailStatus').value;
	if(invoiceNo!=null && invoiceNo!=""){
		if(mailStatus=="Yes"){
			if (confirm("Do You want to Resend Invoice: "+invoiceNo+" mail to party")){	
				sendInvoiceMail(invoiceNo);
			}
		}else{
			sendInvoiceMail(invoiceNo);
		}
	}else{
		alert("Select Invoice No");
	}
	
});





function sendInvoiceMail(invoiceNo){
	$.ajax({
		type : 'POST',
		url : 'viewInvoice/invoiceMail',
		data : {'invoiceNo' : invoiceNo},
		   beforeSend: function(){
	           $("#loading").dialog('open').html("<p>Sending Invoice Mail..</p>");
	        },
		success : function(response) {
			alert("Invoice " + invoiceNo + " Mail sent sucessfully");
			document.getElementById('mailStatus').value = "Yes";
			},
	   error:function(e){
            	alert("Error, email not sent");
        },
        complete: function() {
       	 $("#loading").dialog('close');
       }
	});	
}



$('#lrMailBtn').click(function() {
	var invoiceNo = $('#invoiceNoSelect').val();
	var lrDetails=document.getElementById('lrDetails').value;
	var lrmailStatus=document.getElementById('lrmailStatus').value;
	if(invoiceNo!=null && invoiceNo!="" && lrDetails!=null && lrDetails!=""){
		if(lrmailStatus=="Yes"){
			if (confirm("Do You want to Resend LR details of Invoice: "+invoiceNo+" to party")){	
			sendLrMail(invoiceNo);
			}
		}else{
			sendLrMail(invoiceNo);
		}
	
	}else if(invoiceNo==null || invoiceNo==""){
		alert("Select Invoice No");
	}
	else if(lrDetails==null || lrDetails==""){
		alert("Enter LR Details");
	}
	
});



function sendLrMail(invoiceNo){
	var lrDetails=document.getElementById('lrDetails').value;
	$.ajax({
		type : 'POST',
		url : 'viewInvoice/lrMaill',
		data : {'invoiceNo' : invoiceNo,"lrDetails":lrDetails},
		   beforeSend: function(){
	           $("#loading").dialog('open').html("<p>Sending LR Mail..</p>");
	        },
		success : function(response) {
			alert("LR Details Mail for " + invoiceNo + "  sent sucessfully");
			document.getElementById('lrmailStatus').value = "Yes";
			},
	   error:function(e){
            	alert("Error!!!");
        },
        complete: function() {
       	 $("#loading").dialog('close');
       }
	});	
}