var lastSelected;
var month="";
var year="";
$(function() {
	var systemDate = new Date();

	$("#statusValueSelect").chosen({
		no_results_text : "No results matched"
	});
	$("#monthYearPicker").focus(function () {$(".ui-datepicker-calendar").hide();});
	$('#monthYearPicker').datepicker({
	
        changeYear: true,
        changeMonth: true,
        changeDate :false,
        showButtonPanel: true,
        dateFormat: 'MM yy',
        onClose: function(dateText, inst) { 
            year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
            month = $("#ui-datepicker-div .ui-datepicker-month :selected").val();
           $(this).datepicker('setDate', new Date(year,month, 1));
        }
    });
	

	$('#monthYearPicker').datepicker('setDate',systemDate); 
	
$("#monthYearPicker").focus(function () {$(".ui-datepicker-month").show();});
$("#monthYearPicker").focus(function () {$(".ui-datepicker-year").show();});

	//var orderStatus = document.getElementById('statusValueSelect').value;
	$("#viewPurchaseOrderGrid")
			.jqGrid(
					{
						url: 'viewpurchaseorder/defaultRecords',
						mtype:'POST',
						datatype : "json",
						height : '300px',
						colNames : [ 'Purchase Order No',
								'supplier Id', 'SupplierHidden', 'Supplier','Toatl Qty',
								'Balance Qty','Price','Excise Duty','CST','Amount', 'PO Date',
								'Created By', 'Created Time', 'Updated By',
								'PO Status', 'PO Items','Mail sent','Mail Sent', 'Actions'],
						colModel : [
								
								{
									name : 'poNo',
									index : 'poNo',
									width : 105											
								},
								{
									name : 'customerId',
									index : 'customerId',
									width : 50,
									editable : true,
									hidden : true
								},
								{
									name : 'customerName',
									index : 'customerName',
									width : 20,
									hidden : true
								},
								{
									name : 'customerCode',
									index : 'customerCode',
									width : 80
								},
								{
									name : 'quantity',
									index : 'quantity',
									width : 70
								},
								{
									name : 'balanceQuantity',
									index : 'balanceQuantity',
									width : 70
								},
								{
									name : 'totalPrice',
									index : 'totalPrice',
									width : 80
								},
								{
									name : 'exciseDuty',
									index : 'exciseDuty',
									width : 70
								},
								{
									name : 'cstValue',
									index : 'cstValue',
									width : 70
								},
								{
									name : 'amount',
									index : 'amount',
									width : 70
								},
								{
									name : 'poDate',
									index : 'poDate',
									width : 120,
									editable : true
								},
								{
									name : 'createdBy',
									index : 'createdBy',
									width : 100
								},
								{
									name : 'createdTime',
									index : 'createdTime',
									width : 10,
									hidden:true
								},
								{
									name : 'updatedBy',
									index : 'updatedBy',
									width : 110
								},
								{
									name : 'poStatus',
									index : 'poStatus',
									width : 10,
									editable : false,
									edittype : 'select',
									editoptions : {
										value : "Approved:Approved;Pending:Pending;Submitted:Submitted;Completed:Completed"
									},
									hidden : true
								}, {
									name : 'itemDetailsLink',
									index : 'itemDetailsLink',
									width : 10,
									hidden:true,
									editable : false
								}, {
									name : 'mailSent',
									index : 'mailSent',
									width : 10,
									editable : true,
									hidden : true
								}, {
									name : 'mailSent',
									index : 'mailSent',
									width : 70,
									editable : false
								},{
									name : 'act',
									index : 'act',
									width : 80,
									sortable : false,
									viewable : false
								}

						],
						rowNum : 100,
						height: 500,
						autowidth : true,
						rowList : [ 8, 10, 20, 30 ,50,100],
						pager : '#viewpurchaseOrderpager',
						sortname : 'poNo',
						viewrecords : true,
						sortorder : "desc",
						multiselect : false,
						caption : "Purchase Orders List",
						emptyrecords : "Empty records",
						loadonce : false,
						loadComplete : function() {
						},
						jsonReader : {
							root : "rows",
							page : "page",
							total : "total",
							records : "records",
							repeatitems : false,
							cell : "cell",
							id : "poNo"
						},
						ondblClickRow : function(id) {
							if (id && id !== lastSelected) {
								editRow(id);
							}
						},

						gridComplete : function() {
							var ids = jQuery("#viewPurchaseOrderGrid").jqGrid('getDataIDs');
							for ( var i = 0; i < ids.length; i++) {
								var cl = ids[i];
								be = "<input style='height:22px; width:35px;' type='button' value='Edit' id='editRow"+ cl+ "' onclick=\"editRow('"+ cl+ "');\" />";
								de = "<input style='height:22px; width:30px;' type='button' value='Del' id='delRow"	+ cl+ "' onclick=\"delRow('"+ cl+ "');\" />";
								se = "<input style='height:22px; width: 29px;' type='button' value='Save' hidden='hidden' id='saveRow"+ cl+ "' onclick=\"saveRow('"	+ cl+ "');\" />";
								ce = "<input style='height:22px;width:39px;' type='button' value='Cancel' hidden='hidden' id='restoreRow"+ cl+ "' onclick=\"restoreRow('"+ cl+ "');\" />";
								odLink = "<button class='btn btn-mini' style='font-weight: bold;font-size:1.2em;' id='itemDetailsLink"	+ cl+ "' "+ "onclick=\"openPoItemsPopUp('"+ cl	+ "');\" >"+ cl+" </button>";
								$("#viewPurchaseOrderGrid").jqGrid(
										'setRowData', ids[i], {
											act : be + de + se + ce,
											poNo : odLink
										});
								 jQuery("#viewPurchaseOrderGrid").setCell(ids[i], 'poNo', '', 'myLink');
							}
						},
						editurl : "viewpurchaseorder/crudPO"
					});
	jQuery("#viewPurchaseOrderGrid").jqGrid('navGrid',
			'#viewpurchaseOrderpager', {
				add : false,
				edit : false,
				del : false,
				search:false,
				view:false
			});
	
	});
function editRow(id) {
	var grid = jQuery('#viewPurchaseOrderGrid');
	var poStatus = grid.jqGrid('getCell', id, 'poStatus');
	if(poStatus!="Approved"){
	restoreRow(lastSelected);
	lastSelected = id;
	$('#viewPurchaseOrderGrid').jqGrid('editRow', id, {
		"keys" : true,
		"oneditfunc" : hideActButtons,
		aftersavefunc : function(savedId, response) {
			showActButtons(savedId);
		},
		afterrestorefunc : showActButtons
	});
	}else{
		alert(poStatus+" PO cannot be modified");
	}
}

function delRow(id) {
	var grid = jQuery('#viewPurchaseOrderGrid');
	var poStatus = grid.jqGrid('getCell', id, 'poStatus');
  
	if(poStatus=="Pending" || poStatus=="Submitted"){
	var orderStatus=document.getElementById('statusValueSelect').value;
	var poNo= grid.jqGrid('getCell', id, 'poNo');
	$.ajax({
		type : 'POST',
		url : 'createpurchaseorder/checkPOItems/' + encodeURIComponent(id),
		success : function(response) {
		if (response == "exist") {
				alert("Items exist for PO " +poNo);

			} else if (confirm("Are you sure you want to delete?")) {
				$.ajax({type:'POST', 
					url : 'createpurchaseorder/delete/' + encodeURIComponent(poNo),
						success: function(response) {
						alert("PO "+poNo+" deleted sucessfully");
						jQuery("#viewPurchaseOrderGrid").setGridParam({	datatype : 'json'});
						jQuery("#viewPurchaseOrderGrid").setGridParam({url : 'viewpurchaseorder/records/'+ encodeURIComponent(orderStatus)});
						jQuery("#viewPurchaseOrderGrid").trigger('reloadGrid');
				 	 }
				});
			}}});}
	else{
		alert(poStatus+" PO cannot be deleted");
	}	

}

function saveRow(id) {
	$('#viewPurchaseOrderGrid').saveRow(id, {
		aftersavefunc : function(id, response) {
			showActButtons(id);
		}
	});
}


$(document).keypress(function(e) {
if(e.which == 13) {
	var ids = $("#viewPurchaseOrderGrid").jqGrid('getDataIDs');
	for ( var i = 0; i < ids.length; i++) {
		var cl = ids[i];
		saveRow(cl);
   	} }});

function restoreRow(id) {
	$('#viewPurchaseOrderGrid').jqGrid('restoreRow', id, {
		afterrestorefunc : showActButtons
	});
}

/*
 * Hides the Edit and Del Row Buttons on jqGrid and activates the Save and
 * restore(cancel) button
 * 
 */
function hideActButtons(id) {
	$('#editRow' + id).hide();
	$('#delRow' + id).hide();
	$('#saveRow' + id).show();
	$('#restoreRow' + id).show();
	pickdates(id);
}

/*
 * Shows the Edit and Del Row Buttons on jqGrid and hides the Save and
 * restore(cancel) button
 * 
 */
function showActButtons(id) {
	$('#editRow' + id).show();
	$('#delRow' + id).show();
	$('#saveRow' + id).hide();
	$('#restoreRow' + id).hide();
	lastSelected = null;
}

function pickdates(id) {
	$("#" + id + "_poDate", "#viewPurchaseOrderGrid").datepicker({
		dateFormat : "dd-mm-yy",maxDate: 'today'
	});
}

function openPoItemsPopUp(id) {
    // var row = id.split("=");
	var poNo = id;
	
	var grid = jQuery('#viewPurchaseOrderGrid');
	var status = grid.jqGrid('getCell', poNo, 'poStatus');
	url = 'viewpoitems?poNo=' + encodeURIComponent(poNo) + '&status='
			+ encodeURIComponent(status);
	window.open(url,'_self');

}
function searchOrders(){
	var validSearch=validateSearchParams();
	if(validSearch==true){
		var orderStatus = document.getElementById('statusValueSelect').value;
	   jQuery("#viewPurchaseOrderGrid").setGridParam({datatype:'json'}); 
	   jQuery("#viewPurchaseOrderGrid").setGridParam({ url: 'viewpurchaseorder/records'});
	   jQuery("#viewPurchaseOrderGrid").setGridParam({postData: {month:month,year:year,orderStatus:orderStatus}}); 
	   jQuery("#viewPurchaseOrderGrid").trigger('reloadGrid');
	}

}

function validateSearchParams(){

  if($("#monthYearPicker").val()=="" || $("#monthYearPicker").val()==null){
    	alert("Month and Year empty! please select month and year");
    	return false;
    }
    else if(document.getElementById('statusValueSelect').value == ""){
    	alert("Select the status");
    	return false;
    }
    else if((month==""||month==null) && (year==""||year==null)){
    	var selectedDate = $("#monthYearPicker").datepicker('getDate');
    	month=selectedDate.getMonth();
    	year=selectedDate.getFullYear();
    	return true;
    }
    else return true;
}


function clearFn() {

	document.getElementById('monthYearPicker').value = "";
	
	if ($("#statusSelect").val() != "") {
		document.getElementById('statusSelect').value = "";
		$('#statusSelect').trigger('liszt:updated');
	}
	
	jQuery("#viewPurchaseOrderGrid").jqGrid('clearGridData');
}
/*$("#statusValueSelect").chosen().change(function() {
	var orderStatus = document.getElementById('statusValueSelect').value;
	alert(month);
	alert(year);
	if((month!=null||month!="")&&(year!=null||year!=""))
	{

		$.ajax({
					type : 'POST',
					success : function(response) {
					
						if (response.length == 0) {

							alert("There is no Purchase Order for selected month,year and status");
						}

						if (response.length != 0) {
							for ( var i = 0; i < response.length; i++) 
							{
								jQuery("#viewPurchaseOrderGrid").setGridParam({datatype : 'json'});
								jQuery("#viewPurchaseOrderGrid").setGridParam({url : 'viewpurchaseorder/records/'});
								jQuery("#viewPurchaseOrderGrid").setGridParam({data : {"orderStatus" : orderStatus,"month":month,"year":year}});
								jQuery("#viewPurchaseOrderGrid").trigger('reloadGrid');
							}
						} 
					}
				});	
		
	}
	else{
		
		alert("Month Year not selected, Please select month and year");
		document.getElementById('statusValueSelect').value = "";
		$('#statusValueSelect').trigger('liszt:updated');
	}
});
*/

/*jQuery("#viewPurchaseOrderGrid").setGridParam({datatype : 'json'});
jQuery("#viewPurchaseOrderGrid").setGridParam({url : 'viewpurchaseorder/records/' + encodeURIComponent(orderStatus)});
jQuery("#viewPurchaseOrderGrid").trigger('reloadGrid');*/