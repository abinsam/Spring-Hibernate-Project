var gridQuantityValid=true;
var gridRateValid=true;
var lastSelected;
var poNo=document.getElementById('poNo').value;
var poStatus=document.getElementById('poStatusValue').value;	
$("#sucessPopUp").dialog({
    hide: 'slide',
    show: 'slide',
    autoOpen: false,
    height:70
});
$(".ui-dialog-titlebar").hide();
$("#loading").dialog({
    hide: 'slide',
    show: 'slide',
    autoOpen: false
});
$(function(){ 
	        $("#statusSelect").chosen({no_results_text: "No results matched"});
	        $("#viewPoItemsGrid").jqGrid({
	        url: 'viewpoitems/items/'+ encodeURIComponent(poNo),
	        datatype: "json",
	        height:'300px',
	        mtype: 'POST',
   		 colNames: ['Action','Po No','poItemId','item Id','Item Code','Item Description','desc','Quantity','Units','Rate(Rs)','Price(Rs)','Balance Qty'],
   		 colModel: [
   		          {name:'act',index:'act', width:40,sortable:false,viewable:false,},
	   	          {name:'poNo', index:'poNo', width:50, editable:true,viewable:false,hidden:true},
	   	          {name:'purchaseOrderItemId', index:'purchaseOrderItemId', width:50,viewable:false,hidden:true}, 	   	         
	              {name:'itemId', index:'itemId', width:100, editable:true,hidden:true}, 
	              {name:'itemCode', index:'itemCode', width:100}, 
	              {name:'description', index:'description', width:200,editable:true},
	              {name:'description', index:'description', width:10,editable:true,hidden:true},
		          {name:'quantity',index:'quantity', width:50,editable:true,
	          		editoptions:{
	                      dataInit: function(element) {
	                    	var patMatch = /^(\.\d{1,2}|\d{1,4}\.?\d{0,2}|\d{5}\.?\d?|\d{6}\.?\d?|\d{7}\.?\d?)$/;
	                          $(element).keyup(function(){
	                        	  var qtyVal = element.value;
	                        	 // alert("quanity====" +qtyVal);
	                        	 if(!patMatch.test(qtyVal)) {
	                        		 alert("Please enter a valid quantity");
	                        		 gridQuantityValid=false; 
	                        		  jQuery("#viewPoItemsGrid").trigger('reloadGrid');
	                        	  }
	                        	  else   gridQuantityValid=true;
	                        	  
	                           });
	                      }
				,maxlength:5} 
				},
		          {name:'unit',index:'unit', width:40},
		          {name:'rate',index:'rate',width:50,editable:true,
		        	  editoptions:{
	                      dataInit: function(element) {
	                    	var patMatch = /^[+]?([0-9]+(?:[\.][0-9]*)?|\.[0-9]+)$/;
	                          $(element).keyup(function(){
	                        	  var rateVal = element.value;
	                        	 if(!patMatch.test(rateVal)) {
	                        		 alert("Please enter a valid rate");
	                        		 gridRateValid=false;  
	                        		  jQuery("#viewPoItemsGrid").trigger('reloadGrid');
	                        	  }
	                        	  else   gridRateValid=true;
	                        	  
	                           });
	                      }
	                  ,maxlength:5} 
				}, 
		          {name:'price',index:'price',width:50},
		          {name:'balanceQty',index:'balanceQty', width:50}
      ],
   		            rowNum:5, 
   		            autowidth:true,
   		            pager: viewpoitemspager,
   		            sortname: 'purchaseOrderItemId',
   		            sortorder: "desc",
   		            viewrecords: true, 
   		            caption:"Item List of PO: "+poNo,
        	   		    emptyrecords: "Empty records",
        	   		 footerrow : true,
        	   		    jsonReader : {
        	   		        root: "rows",
        	   		        page: "page",
        	   		        total: "total",
        	   		        records: "records",
        	   		        repeatitems: false,
        	   		        cell: "cell",
        	   		        id: "purchaseOrderItemId"
        	   		    },
     	   		 ondblClickRow : function(id) {
     	   	   	 if (id && id !== lastSelected) {
     	 				editRow(id);
     	 			}
     	 		},
			         
			      
			        gridComplete: function(){ 
			       	 var totalQuantity= $('#viewPoItemsGrid').jqGrid('getCol','quantity',false,'sum');
        	   		 var totalBalanceQuantity= $('#viewPoItemsGrid').jqGrid('getCol','balanceQty',false,'sum');
                     var totalPrice=$('#viewPoItemsGrid').jqGrid('getCol','price',false,'sum');
                
			        	  var totalQuantityRoundUp=Math.round(parseFloat(totalQuantity) * 100) / 100;
	        	   	 	  var totalPriceRoundUp=Math.round(parseFloat(totalPrice) * 100) / 100;
	        	   	 	  var totalBalQtyRoundUp=Math.round(parseFloat(totalBalanceQuantity) * 100) / 100;
	                   
			          	$('#viewPoItemsGrid').jqGrid('footerData','set', {ID: 'Total:', quantity: totalQuantityRoundUp});
        	   	    	$('#viewPoItemsGrid').jqGrid('footerData','set', {ID: 'Total:', price: totalPriceRoundUp});
        	   	    	$('#viewPoItemsGrid').jqGrid('footerData','set', {ID: 'Total:', balanceQty: totalBalQtyRoundUp});

	        	   	    	var ids = jQuery("#viewPoItemsGrid").jqGrid('getDataIDs');
	        	   	    	for ( var i = 0; i < ids.length; i++) {
	        					var cl = ids[i];
	        					be = "<input style='height:22px; width:35px;' type='button' value='Edit' id='editRow"+cl+"' onclick=\"editRow('"+ cl + "');\" />";
	        					de = "<input style='height:22px; width:30px;' type='button' value='Del' id='delRow"+cl+"' onclick=\"delRow('"+ cl + "');\" />";
	        					se = "<input style='height:22px; width: 29px;' type='button' value='Save' hidden='hidden' id='saveRow"+cl+"' onclick=\"saveRow('"+ cl + "');\" />";
	        					ce = "<input style='height:22px;width:39px;' type='button' value='Cancel'  hidden='hidden' id='restoreRow"+cl+"' onclick=\"restoreRow('"+ cl + "');\" />";
	        					$("#viewPoItemsGrid").jqGrid('setRowData', ids[i],
	        							{
	        								act : be + de + se + ce
	        							});
	        				}
		               },
		              editurl : "viewpoitems/crudPOItems"
	        });
	        jQuery("#viewPoItemsGrid").jqGrid('navGrid','#viewpoitemspager',{add:false,edit:false,del:false,search:false,view:false});
     }); 


function editRow(id) {
	var poStatus=document.getElementById('poStatusValue').value;	
	if(poStatus=="Pending" || poStatus=="Submitted" ){
	    restoreRow(lastSelected);
		lastSelected = id;
		$('#viewPoItemsGrid').jqGrid('editRow',id, 
				{
					"keys" :true, 
					"oneditfunc" : hideActButtons,
					aftersavefunc : function(savedId, response) {
						showActButtons(savedId);
					},
					afterrestorefunc : showActButtons
				});
	}
	else{
		alert(poStatus+" PO cannot be modified");
	}
}

function delRow(id) {
	var poStatus=document.getElementById('poStatusValue').value;	
	if(poStatus=="Pending" || poStatus=="Submitted" ){
	var purchaseOrderNo=document.getElementById('poNo').value;
	 if (confirm(" Do you want to delete Purchase order item ?")){
			$.ajax({type:'POST', 
				url: 'viewpoitems/delete/'+ encodeURIComponent(id),
				data:{'purchaseOrderNo':purchaseOrderNo},
				success: function(response) {
				 jQuery("#viewPoItemsGrid").trigger('reloadGrid');
		 	 }
			});
}}
	else{
		alert(poStatus+" PO cannot be deleted");
	}	

}


function saveRow(id) {
	if (gridQuantityValid && gridRateValid==true){	
	$('#viewPoItemsGrid').saveRow(id, {	
			aftersavefunc : function(id, response) {
			showActButtons(id);
			var grid = jQuery('#viewPoItemsGrid'); 
	        var qty = grid.jqGrid ('getCell', id, 'quantity');
	        var rate = grid.jqGrid ('getCell', id, 'rate'); 
	        if(qty!=null && rate!=null) {
	     	var prd = qty*rate;
			grid.jqGrid('setCell',id,'price',prd);
	        }
	        else
		    grid.jqGrid('setCell',id,'price',0);
	        url: 'viewpoitems/crudPOItems/'+ encodeURIComponent(id);
	  }
  });
	 jQuery("#viewPoItemsGrid").trigger('reloadGrid');
}}

function restoreRow(id) {
	$('#viewPoItemsGrid').jqGrid('restoreRow',id,
				{
					afterrestorefunc : showActButtons
				});
   }

/*
	* Hides the Edit and Del Row Buttons on jqGrid
	* and activates the Save and restore(cancel) button
	* 
*/
function hideActButtons(id){
		$('#editRow' + id).hide();
		$('#delRow' + id).hide();
		$('#saveRow' + id).show();
		$('#restoreRow' + id).show();
		pickdates(id);
	}

	/*
	 * Shows the Edit and Del Row Buttons on jqGrid
	 * and hides the Save and restore(cancel) button
	 * 
	 */
function showActButtons(id) {
		
		$('#editRow' + id).show();
		$('#delRow' + id).show();
		$('#saveRow' + id).hide();
		$('#restoreRow' + id).hide();
		lastSelected = null;
}
$('#closeButton').click(function() {
	window.close();
});

$('#saveOrderStatus').click(function(){
var orderStatus=document.getElementById('poStatusValue').value;
var purchaseOrderNo=document.getElementById('poNo').value;
var updatedStatus=document.getElementById('statusSelect').value;
var vendors=document.getElementById('vendor').value;
if(orderStatus=="Submitted" || orderStatus=="Approved"){
$.ajax({type:'POST',
	url: 'viewpurchaseorder/updateOrderStatus',
	data:{"purchaseOrderNo":purchaseOrderNo,"orderStatus":orderStatus,"updatedStatus":updatedStatus},
	success: function(response) {
        $("#sucessPopUp").dialog('open').html("<p>Order Details Updated</p>");
        document.getElementById('poStatusValue').value=updatedStatus;
        setTimeout( function () { 
                   window.parent.$('#sucessPopUp').dialog('close'); 
               }, 1000) ;// milliseconds delay
         if(updatedStatus=="Approved"){
      	   if (confirm("Do you want send mail to "+vendors+" ? ")){
      		 sendPoMail();
      	   }}
    document.getElementById('poStatusValue').value=updatedStatus;
	jQuery("#viewPoItemsGrid").trigger('reloadGrid');
    }});
}else {
	alert("Submitted Purchase Orders status can only be updated");
}
});



	function sendPoMail(updatedStatus){
		var postatus=document.getElementById('poStatusValue').value;
		var mailSendStatus=document.getElementById('mailSent').value;
   		if(postatus=="Approved"){
   			if(mailSendStatus=="Yes"){
   			  if(confirm("Do you want to resend the Purcahse Order mail?"))
   				sendCustomermailAjaxCall();
   			}else{
   				sendCustomermailAjaxCall();
   			}

   		}else{
   			alert("Purchase Order Order should be approved");
   		}
   	}

 	function sendCustomermailAjaxCall(){
 		var purchaseOrderNo=document.getElementById('poNo').value;
		$.ajax({type:'POST',
			url: 'viewpurchaseorder/sendPoMail',
			data:{"purchaseOrderNo":purchaseOrderNo},

			   beforeSend: function(){
		           $("#loading").dialog('open').html("<p>Processing Request...</p>");
		        },
			   
			success: function(response) {
				alert("PO Mail sent successfully");
				document.getElementById('mailSent').value ="Yes";
			},	
	        error:function(e){
	        	alert("Error!!!");
	        },
	        complete: function() {
	        	 $("#loading").dialog('close');
	        }
           });
   	}
   	
	
	
	
	
 

/*$('#sentMail').click(function(){
	var mailSent=document.getElementById('mailSent').value;
	var purchaseOrderNo=document.getElementById('poNo').value;
	$.ajax({type:'POST',
		url: 'viewpurchaseorder/checkOrderStatus',
		data:{"purchaseOrderNo":purchaseOrderNo},
		success: function(response) {
		if(response=="Approved" && (mailSent=="No"|| mailSent=="" || mailSent==null)){
				$.ajax({type:'POST',
					url: 'viewpurchaseorder/sendPoMail',
					data:{"purchaseOrderNo":purchaseOrderNo},
					   beforeSend: function(){
				           $("#loading").dialog('open').html("<p>Processing Request...</p>");
				        },
					success: function(response) {
					alert("Mail sent successfully")	;
					},
					error:function(e){
		            	alert("Error!Mail not send");
			        }
					,
			        complete: function() {
			       	 $("#loading").dialog('close');
			       },
					
					
				});
			}else if(response!="Approved"){
				alert("Po should be approved");
			}else if(mailSent=="Yes"){
			    if(confirm("Mail has been send to the vendor.Are you sure you want to resend the mail ?")){
			    	$.ajax({type:'POST',
						url: 'viewpurchaseorder/sendPoMail',
						data:{"purchaseOrderNo":purchaseOrderNo},
						 beforeSend: function(){
					           $("#loading").dialog('open').html("<p>Processing Request...</p>");
					        },
						success: function(response) {
						alert("Mail sent successfully")	;
						},error:function(error){
							alert("Error!Mail not send");
						},
				        complete: function() {
				       	 $("#loading").dialog('close');
				       },});
			    }
			}
		}});
});
*/


$(document).keypress(function(e) {
    if(e.which == 13) {
    
    	var ids = $("#viewPoItemsGrid").jqGrid('getDataIDs');
    	for ( var i = 0; i < ids.length; i++) {
			var cl = ids[i];
			saveRow(cl);
       	} }});

	$('#backToOrder').click(function(){
   		url = 'viewpurchaseorder';
		window.open(url,'_self');
	});
	
	
	
  	$('#purchaseOrderReport').click(function() {
   		var purchaseOrderNo =document.getElementById('poNo').value;
   		if(purchaseOrderNo!=null && purchaseOrderNo!=""){
   		$.ajax({
   			type : 'POST',
   			url : 'viewpoitems/purchaseOrderReport',
   			data : {"purchaseOrderNo" : purchaseOrderNo},
   			success : function(response) {
   				if(response=="notexist"){
   					alert("Please save the generated PDF at desired location");
   				}
   			}
   			
   		});
   		}else{
   			alert("Select Purchase Order Number");
   		}
   	});
