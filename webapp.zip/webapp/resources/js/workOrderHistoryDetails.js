var year="";
var month="";

$(function() {
	
	var systemDate = new Date();
	
	$("#monthYearPicker").focus(function () {$(".ui-datepicker-calendar").hide();});
	$('#monthYearPicker').datepicker({
	
        changeYear: true,
        changeMonth: true,
        changeDate :false,
        showButtonPanel: true,
        dateFormat: 'MM yy',
       
        onClose: function(dateText, inst) { 
            year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
           month = $("#ui-datepicker-div .ui-datepicker-month :selected").val();
            $(this).datepicker('setDate', new Date(year,month, 1));
        }
    });
	$('#monthYearPicker').datepicker('setDate',systemDate); 
$("#monthYearPicker").focus(function () {$(".ui-datepicker-month").show();});
$("#monthYearPicker").focus(function () {$(".ui-datepicker-year").show();});
$("#processTypeSelect").chosen({no_results_text : "No results matched"});
$("#workOrderNoSelect").chosen({no_results_text : "No results matched"});

	$("#extrusionGrid")
			.jqGrid(
					{
			        	url : 'workOrderHistory/extrusionRecords',
						datatype : 'json',
						mtype : 'POST',
						colNames : [ 'workOrderItemId', 'Extrusion WoNo','soitemid ','Item Description', 'Total Qty','Customer Name','Updated By','Qc Details'
						 ],
						colModel : [  {name:'workOrderItemId', index:'workOrderItemId', width:15, viewable:false,hidden:true},
						   	          {name:'workOrderNo',index:'workOrderNo', width:30},
						   	          {name:'orderDetailId',index:'orderDetailId', width:10,hidden:true},
						   	          {name:'itemDescription',index:'itemDescription', width:100}, 
						   	          {name:'totalQuantity',index:'totalQuantity', width:30},
						              {name:'customerName',index:'customerName', width:80},
						   	          {name:'updatedBy',index:'updatedBy', width:80},
						   	          {name :'qcDetailsLink',index : 'qcDetailsLink',width :60,sortable:false},
						],
						postData : {},
						rowNum : 100,
						rowList : [ 5, 10, 20, 30, 40, 100,500],
						height : 150,
						width:700,
						rownumbers : false,
						pager : '#extrusionPager',
						sortname : 'workOrderItemId',
						viewrecords : true,
						sortorder : "desc",
						caption : "Extrusion WO Details",
						emptyrecords : "Empty records",
						loadonce : false,
						footerrow : true,
						loadComplete : function() {
						},
						jsonReader : {
							root : "rows",
							page : "page",
							total : "total",
							records : "records",
							repeatitems : false,
							cell : "cell",
							id : "workOrderItemId"
						},
	
						gridComplete : function() {
							var ids = $("#extrusionGrid").jqGrid('getDataIDs');
							for ( var i = 0; i < ids.length; i++) {
								var cl = ids[i];
	        					qcLink = "<button class='btn btn-mini' id='qcDetailsLink"	+ cl + "' "+ "onclick=\"openQcDetailslLink('"+ cl	+ "');\" > QC Details </button>";
								$("#extrusionGrid").jqGrid('setRowData', ids[i],{
								qcDetailsLink : qcLink
            				});
	            			}
							var totalQuantity = $('#extrusionGrid').jqGrid('getCol', 'totalQuantity', false, 'sum');
							var sumOfTotalQuantity = Math.round(parseFloat(totalQuantity) * 100) / 100;
							$('#extrusionGrid').jqGrid('footerData', 'set', {ID : 'Total:',totalQuantity : sumOfTotalQuantity});
							
						}
			});
	jQuery("#extrusionGrid").jqGrid('navGrid', '#extrusionPager', {
		view : false,
		del : false,
		add : false,
		edit : false,
		search : false
	});

	$("#bunchingGrid").jqGrid(
					{
						datatype : 'json',
						mtype : 'POST',
						
						colNames : [ 'woOutPutId','Bunching WoNo','Item Description','Batch No','Net Length','Net Weight','Created By',
						             'QC Status','QC SupervisorHid','Remarks'],
						colModel : [
						             {name:'woOutPutId', index:'woOutPutId', width:10,hidden:true}, 
						             {name:'workOrderNo', index:'workOrderNo', width:30}, 
						             {name:'size', index:'size', width:60}, 
						         	 {name : 'batchNo',index : 'batchNo',width : 80},
						             {name : 'netLength',index : 'netLength',width : 50},
						             {name : 'netWeight',index : 'netWeight',width : 50},
						        	 {name:'updatedBy',index:'updatedBy', width:80},
						        	 {name:'speed',index:'speed', width:80,hidden:true},
						        	 {name:'annealingPercent',index:'annealingPercent', width:80,hidden:true},
						          	 {name:'remarks',index:'remarks', width:80,sortable:false}
						],
						postData : {},
						rowNum : 100,
						rowList : [ 5, 10, 20, 30, 40, 100,500],
						height : 150,
						width:700,
						rownumbers : false,
						pager : '#bunchingPager',
						sortname : 'woOutPutId',
						viewrecords : true,
						sortorder : "desc",
						caption : "Bunching WO Details",
						emptyrecords : "Empty records",
						loadonce : false,
						footerrow : true,
						loadComplete : function() {
						},
						jsonReader : {
							root : "rows",
							page : "page",
							total : "total",
							records : "records",
							repeatitems : false,
							cell : "cell",
							id : "woOutPutId"
						},
						gridComplete : function() {
							var netLength = $('#bunchingGrid').jqGrid('getCol', 'netLength', false, 'sum');
							var sumOfNetLength = Math.round(parseFloat(netLength) * 100) / 100;
							$('#bunchingGrid').jqGrid('footerData', 'set', {ID : 'Total:',netLength : sumOfNetLength});
							
							var netWeight = $('#bunchingGrid').jqGrid('getCol', 'netWeight', false, 'sum');
							var sumOfNetWeight = Math.round(parseFloat(netWeight) * 100) / 100;
							$('#bunchingGrid').jqGrid('footerData', 'set', {ID : 'Total:',netWeight : sumOfNetWeight});
						}
					});
	jQuery("#bunchingGrid").jqGrid('navGrid', '#bunchingPager', {
		view : true,
		del : false,
		add : false,
		edit : false,
		search : false
	});

	$("#multiWireGrid").jqGrid(
			{
				datatype : 'json',
				mtype : 'POST',
				
				colNames : [ 'woOutPutId','Mutiwire WoNo','Item Description','Batch No','Net Length','Net Weight','Created By'
				             ,'QC StatusHidden','QC Supervisor','Remarks'],
				colModel : [
				             {name:'woOutPutId', index:'woOutPutId', width:10,hidden:true}, 
				             {name:'workOrderNo', index:'workOrderNo', width:30}, 
				             {name:'size', index:'size', width:60}, 
				             {name : 'batchNo',index : 'batchNo',width : 80},
				             {name : 'netLength',index : 'netLength',width : 50},
				             {name : 'netWeight',index : 'netWeight',width : 50},
				             {name:'updatedBy',index:'updatedBy', width:80},
				          	 {name:'speed',index:'speed', width:80,hidden:true},
				        	 {name:'annealingPercent',index:'annealingPercent', width:80},
				          	 {name:'remarks',index:'remarks', width:80,sortable:false}
				
				],
				postData : {},
				rowNum : 150,
				rowList : [ 5, 10, 20, 30, 40, 100,500],
				height : 150,
				width:700,
				rownumbers : false,
				pager : '#mutliWirePager',
				sortname : 'woOutPutId',
				viewrecords : true,
				sortorder : "desc",
				caption : "MWD WO Details",
				emptyrecords : "Empty records",
				loadonce : false,
				footerrow : true,
				loadComplete : function() {
				},
				jsonReader : {
					root : "rows",
					page : "page",
					total : "total",
					records : "records",
					repeatitems : false,
					cell : "cell",
					id : "woOutPutId"
				},		
				gridComplete : function() {
					var netLength = $('#multiWireGrid').jqGrid('getCol', 'netLength', false, 'sum');
					var sumOfNetLength = Math.round(parseFloat(netLength) * 100) / 100;
					$('#multiWireGrid').jqGrid('footerData', 'set', {ID : 'Total:',netLength : sumOfNetLength});
					
					var netWeight = $('#multiWireGrid').jqGrid('getCol', 'netWeight', false, 'sum');
					var sumOfNetWeight = Math.round(parseFloat(netWeight) * 100) / 100;
					$('#multiWireGrid').jqGrid('footerData', 'set', {ID : 'Total:',netWeight : sumOfNetWeight});
				}
		});
jQuery("#multiWireGrid").jqGrid('navGrid', '#mutliWirePager', {
view : true,
del : false,
add : false,
edit : false,
search : false
});	

$("#pvcStockOutGrid").jqGrid({
	mtype : 'POST',
	    colNames:['pvcStockOutID','WorkOrder No','PVC Item','Batch','Quantity'],
	   	colModel:[
	   	    
			{name:'pvcStockOutID', index:'semifinishedStockOutId', width:10,hidden:true}, 
			{name:'workOrderNo', index:'workOrderNo', width:100,hidden:true}, 
			 {name:'itemDescription',index:'itemDescription',  width:250},
			 {name:'batch',index:'batch',  width:150},
			 {name:'quantity',index:'quantity', width:100}
	   	],
	   	postData : {},
		rowNum : 150,
		rowList : [ 5, 10, 20, 40, 60,100,500],
		height : 175,
		width:700,
		rownumbers : false,
		pager : '#pvcStockOutPager',
		sortname : 'pvcStockOutID',
		viewrecords : true,
		sortorder : "desc",
	    caption:"PVC Stock Out",
	    emptyrecords : "Empty records",
		loadonce : false,
		footerrow : true,
		jsonReader : {
			root : "rows",
			page : "page",
			total : "total",
			records : "records",
			repeatitems : false,
			cell : "cell",
			id : "pvcStockOutID"
		},
		gridComplete : function() {
			var quantity = $('#pvcStockOutGrid').jqGrid('getCol', 'quantity', false, 'sum');
			var totalQuantity = Math.round(parseFloat(quantity) * 100) / 100;
			$('#pvcStockOutGrid').jqGrid('footerData', 'set', {ID : 'Total:',quantity : totalQuantity});
			
		}
});
jQuery("#pvcStockOutGrid").jqGrid('navGrid', '#pvcStockOutPager', {
view : false,
del : false,
add : false,
edit : false,
search : false
});

$("#scrapDetailsGrid")
.jqGrid(
		{
        	url : 'workOrderHistory/scrapRecords',
			datatype : 'json',
			mtype : 'POST',
			colNames : [ 'scrapId', 'WoNo','Item Description', 'Quantity','Date','Machine','Shift','Supervisor'
			 ],
			colModel : [  {name:'scrapId', index:'scrapId', width:15, viewable:false,hidden:true},
			   	          {name:'workOrderNo',index:'workOrderNo', width:30},
			   	       {name:'itemDescription',index:'itemDescription', width:100}, 
			   	    {name:'quantity',index:'quantity', width:30},
			   	 {name:'scrapDate',index:'scrapDate', width:80},
			   	 {name:'machineDesciption',index:'machineDesciption', width:80},
			   	{name:'shiftPattern',index:'shiftPattern', width:30},
			   	 {name:'supervisor',index:'supervisor', width:80},
			],
			postData : {},
			rowNum : 100,
			rowList : [ 5, 10, 20, 30, 40, 100,500],
			height : 150,
			width:700,
			rownumbers : false,
			pager : '#scrapDetailsPager',
			sortname : 'scrapId',
			viewrecords : true,
			sortorder : "desc",
			caption : "Scrap Details",
			emptyrecords : "Empty records",
			loadonce : false,
			footerrow : true,
			loadComplete : function() {
			},
			jsonReader : {
				root : "rows",
				page : "page",
				total : "total",
				records : "records",
				repeatitems : false,
				cell : "cell",
				id : "scrapId"
			},
			gridComplete : function() {
				var quantity = $('#scrapDetailsGrid').jqGrid('getCol', 'quantity', false, 'sum');
				var totalQuantity = Math.round(parseFloat(quantity) * 100) / 100;
				$('#scrapDetailsGrid').jqGrid('footerData', 'set', {ID : 'Total:',quantity : totalQuantity});
				
			}
		});
jQuery("#scrapDetailsGrid").jqGrid('navGrid', '#scrapDetailsPager', {
view : false,
del : false,
add : false,
edit : false,
search : false
});



$("#extrusionQualityGrid").jqGrid({
	mtype : 'POST',
	    colNames:['stockOutId','Bundle Id','QC Status','Qc Supervisor','Remarks','Stock Status'],
	   	colModel:[
	   	    
			{name:'stockOutId', index:'stockOutId', width:10,hidden:true}, 
			{name:'bundleId', index:'bundleId', width:70}, 
			{name:'qcStatus',index:'qcStatus',  width:100},
			 {name:'qcSupervisor',index:'qcSupervisor',width:150},
			 {name:'remarks',index:'remarks',  width:200},
			 {name:'status',index:'status',  width:80}

	   	],
	   	postData : {},
		rowNum : 100,
		rowList : [ 5, 10, 20, 40, 60,100 ],
		height :280,
		width:700,
		rownumbers : false,
		pager : '#extrusionQualityPager',
		sortname : 'stockOutId',
		viewrecords : true,
		sortorder : "desc",
	    emptyrecords : "Empty records",
		loadonce : false,
		jsonReader : {
			root : "rows",
			page : "page",
			total : "total",
			records : "records",
			repeatitems : false,
			cell : "cell",
			id : "stockOutId"
		}	
}).navGrid('#extrusionQualityPager',{view:false, del:false, edit:false, search:false,add:false});

});
$("#processTypeSelect").chosen().change(function() {
	month = $("#ui-datepicker-div .ui-datepicker-month :selected").val();
    year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
			if(month!=null && month!="" && year!=null && year!=""){
				var processType = $('#processTypeSelect').val();
				$('#workOrderNoSelect').children().remove();
				$('#workOrderNoSelect').val('').trigger('liszt:updated');
				$('#pvcStockOutGrid').jqGrid('clearGridData');
				$('#extrusionGrid').jqGrid('clearGridData');
				$('#multiWireGrid').jqGrid('clearGridData');
				$('#bunchingGrid').jqGrid('clearGridData');
				$("#scrapDetailsGrid").jqGrid('clearGridData');
				$.ajax({
					type : 'POST',
					url : 'workOrderHistory/getWorkOrders/'+ encodeURIComponent(processType),
					data : {"month":month,"year":year},
					success : function(response) {
						$('#workOrderNoSelect').empty();
						if (response.length == 0) {

							alert("There is no Work Order for selected month,year and process type");
						}
						if (response.length != 0) {
							for ( var i = 0; i < response.length; i++) {
								$('#workOrderNoSelect').append('<option selected="selected">'+ "" + '</option>');
								$('#workOrderNoSelect').append('<option >' + response[i]+ '</option>');
								$('#workOrderNoSelect').trigger('liszt:updated');
							}
						} else {
							$('#workOrderNoSelect').empty();
						}

					}
				});
			}
			else
			{
			alert("Please select month and year");
			}
		
});

$("#monthYearPicker").focus(function() {
	
	if ($("#processTypeSelect").val() != "") {
		document.getElementById('processTypeSelect').value = "";
		$('#processTypeSelect').trigger('liszt:updated');
	}
	
	if ($("#workOrderNoSelect").val() != "") {
		document.getElementById('workOrderNoSelect').value = "";
		$('#workOrderNoSelect').trigger('liszt:updated');
	}
	$('#pvcStockOutGrid').jqGrid('clearGridData');
	$('#extrusionGrid').jqGrid('clearGridData');
	$('#multiWireGrid').jqGrid('clearGridData');
	$('#bunchingGrid').jqGrid('clearGridData');
	$("#scrapDetailsGrid").jqGrid('clearGridData');
});
$("#workOrderNoSelect").chosen().change(function() {
	 var workOrder = $('#workOrderNoSelect').val();

	 jQuery("#extrusionGrid").setGridParam({datatype:'json'}); 
	 jQuery("#extrusionGrid").setGridParam({ url: 'workOrderHistory/extrusionRecords'});
	 jQuery("#extrusionGrid").setGridParam({postData: {workOrder:workOrder}}); 
	 jQuery("#extrusionGrid").setCaption('Extrusion Details:' +workOrder );
	 jQuery("#extrusionGrid").trigger('reloadGrid');
	
	 jQuery("#bunchingGrid").setGridParam({datatype:'json'}); 
	 jQuery("#bunchingGrid").setGridParam({ url: 'workOrderHistory/bunchingRecords'});
	 jQuery("#bunchingGrid").setGridParam({postData: {workOrder:workOrder}}); 
	 jQuery("#bunchingGrid").setCaption('Bunching Details:' +workOrder );
	 jQuery("#bunchingGrid").trigger('reloadGrid'); 
	
	 jQuery("#multiWireGrid").setGridParam({datatype:'json'}); 
	 jQuery("#multiWireGrid").setGridParam({ url: 'workOrderHistory/multiwireRecords'});
	 jQuery("#multiWireGrid").setGridParam({postData: {workOrder:workOrder}}); 
	 jQuery("#multiWireGrid").setCaption('MWD Details:' +workOrder );
	 jQuery("#multiWireGrid").trigger('reloadGrid');
	 
	 jQuery("#pvcStockOutGrid").setGridParam({datatype:'json'}); 
	 jQuery("#pvcStockOutGrid").setGridParam({ url : 'viewworkorder/pvcStockOutRecords/' + encodeURIComponent(workOrder)});
	 jQuery("#pvcStockOutGrid").setCaption('PVC Stock Out Details:' +workOrder );
	 jQuery("#pvcStockOutGrid").trigger('reloadGrid');

	 jQuery("#scrapDetailsGrid").setGridParam({datatype:'json'}); 
	 jQuery("#scrapDetailsGrid").setGridParam({ url: 'workOrderHistory/scrapRecords'});
	 jQuery("#scrapDetailsGrid").setGridParam({postData: {workOrder:workOrder}}); 
	 jQuery("#scrapDetailsGrid").setCaption('Scrap Details:' +workOrder );
	 jQuery("#scrapDetailsGrid").trigger('reloadGrid');

	});

function openQcDetailslLink(id){
var workOrderItemId=id;
		jQuery("#extrusionQualityGrid").setGridParam({datatype:'json'}); 
		jQuery("#extrusionQualityGrid").setGridParam({ url : 'workOrderHistory/extrusionQualityRecords'});
		jQuery("#extrusionQualityGrid").setGridParam({postData: {workOrderItemId:workOrderItemId}}); 
		jQuery("#extrusionQualityGrid").trigger('reloadGrid');
		$("#dialog-pvc-modal").dialog({
			width : 750,
			height :400

		});

	   
   }